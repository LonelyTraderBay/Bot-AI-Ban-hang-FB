# Quy tắc AI — phụ lục riêng cho BotSales AI

**Kit 1.1 | 29/09/2026 | Universal nguồn: AI_RULES.md 3.1, giữ nguyên byte.**
Đây là quy định riêng của Bot bán hàng, không phải phiên bản sửa của Universal.
Nguồn quy tắc code là docs/18; nguồn quyết định dark-only là docs/19; quy trình nạp,
đồng bộ và cổng kiểm tra ở docs/20. Bản tóm tắt này chỉ dẫn đường, không tạo chuẩn thứ hai.

## 1. Tiếp nhận nhiệm vụ
Đọc nguồn instructions thật, hai phần LUÔN ĐỌC của Universal, hồ sơ hiện hữu,
revision/diff và task. Phân biệt docs_only / implement / review / integrate.
Giữ riêng ĐÃ QUAN SÁT, ĐỀ XUẤT CHƯA DUYỆT, ĐÃ DUYỆT, CHƯA XÁC ĐỊNH.
Người dùng đã chốt dark-only; chưa có repo được khảo sát trong gói này. Không coi
một nhiệm vụ cập nhật tài liệu là quyền code, mua dịch vụ, gửi tin hoặc deploy thật.

## 2. Dark-only là bất biến sản phẩm
Tuân DARK-001..DARK-012 tại docs/19. Một palette dark, một theme provider dùng chung,
tokens chuẩn; không light/system/toggle/persisted theme preference. Không scaffold
khả năng đổi theme để “chuẩn bị tương lai”. Tôn trọng forced-colors, zoom và reduced motion.
CSS bootstrap có màu nền đúng trước JavaScript; login, lỗi và portal vẫn cùng dark theme.

## 3. Một nền tảng code
Repo mới: áp dụng baseline được ủy quyền tại docs/02 và khóa phiên bản thực trong G0.
Repo cũ: giữ stack/quyền/contract hiện có, map ranh giới; chuyển dark theo từng phần
có kiểm chứng, không nhân tiện thay framework. Không nhiều thư viện cùng vai trò.
Không sửa generated outputs bằng tay. Không copy DTO, logic tiền, quyền hoặc theme
thành các bản riêng cho từng agent. Chi tiết CODE-001..CODE-024 tại docs/18.

## 4. Trách nhiệm và dữ liệu
App ghép public module API; module không nhập module khác; shared không nhập nghiệp vụ.
Backend có thẩm quyền về quyền, giá, kho, tiền, quota và policy kênh; UI chỉ hiển thị
và gửi ý định theo contract. Không SDK AI/Meta hoặc secret trong browser.
Query/stream scope gồm principal, shop và permission context; loại late responses.
Timeout là kết quả chưa xác định, không tự coi thất bại rồi gửi lệnh mới.

## 5. Không hoàn thành giả
Không nút giả, random KPI, catch-return-success, fallback ngầm về mocks hoặc bất hoạt
kiểm thử để xanh. TypeScript strict, input IO được validate; lỗi, quyền và conflict
có trạng thái thật. Dùng Complexity/Abstraction Gate và Change Budget của Universal.
Không đặt một số lượng use-case cứng thay cho phân tích nhu cầu và rủi ro.

## 6. Nhiều AI
Mỗi task có owner thực, scope, baseline và hợp đồng hiệu lực. Phần dùng chung có một
writer chủ động; integrator là trách nhiệm phải được giao, không quyền tự xưng.
Worktree/clone riêng nếu phù hợp; không có cô lập thì ghi tuần tự. Không coi bảng
việc trong từng nhánh là cơ chế khóa. Sau tích hợp chạy kiểm tra trên bản kết hợp.

## 7. Nghiệm thu
Cổng chất lượng ở governance/quality-gates.json cần được nối vào CI thật tại G1,
kèm ca sai chứng minh cổng bắt lỗi. Có file quy định không có nghĩa đã enforcement.
Trạng thái bốn mức theo Universal 19.5; NOT_RUN tương đương CHƯA XÁC MINH, không phải
KHÔNG ÁP DỤNG. Production Claim Gate 19.6 chặn tuyên bố production khi thiếu evidence.
Bàn giao: phạm vi, diff, lệnh/cwd/exit code thực, evidence, giới hạn và việc tiếp theo.
Không tự commit/push/merge/deploy ngoài quyền. Không nhận đã đồng bộ các AI khác.
