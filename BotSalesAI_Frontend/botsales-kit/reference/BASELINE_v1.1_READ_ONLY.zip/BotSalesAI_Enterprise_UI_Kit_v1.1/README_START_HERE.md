# BẮT ĐẦU TẠI ĐÂY — BotSales AI / Enterprise UI Build Kit

**Bản 1.1 | Ngày 29/09/2026 | Ngôn ngữ: tiếng Việt**

Đây là bộ đặc tả triển khai dành cho AI lập trình giao diện quản lý Bot bán hàng qua Facebook Messenger: sản phẩm, khách hàng, hội thoại, đơn hàng, tồn kho, thu/chi, lợi nhuận quản trị, kiến thức, cấu hình AI và quản trị shop. Tên “BotSales AI” chỉ là tên kỹ thuật tạm; không phải thương hiệu đã được chủ dự án chốt.

## Bộ này làm được gì?

AI có thể dùng ngay để khảo sát repo, lập kế hoạch PR và code từng lát cắt UI hoàn chỉnh với API mock theo hợp đồng. Các quy định về kiến trúc, dữ liệu, permission, trạng thái, lỗi và nghiệm thu giúp nhiều AI làm việc nhất quán. Bộ tài liệu không phải mã nguồn ứng dụng và không chứng nhận rằng một hệ thống đã đạt production.

**Không có tài liệu hay kiến trúc nào bảo đảm “không bao giờ vỡ”.** Mục tiêu ở đây là phát hiện thay đổi phá vỡ bằng máy, giới hạn ảnh hưởng theo module, giữ dữ liệu đúng và có đường quay lui.

## Cách dùng cho chủ dự án

1. Giải nén toàn bộ thư mục vào `docs/botsales-blueprint/` của repo hoặc đính kèm nguyên gói cho AI có môi trường code. Không chỉ đưa PDF.
2. Đọc `docs/00_PROVENANCE_AND_DECISIONS.md` để biết phần kế thừa và phần chuẩn hóa mới. Không ghi đè `AGENTS.md` hay `AI_RULES.md` đang tồn tại.
3. Dán toàn bộ `PROJECT_BUILD_PROMPT_VI.txt`. AI bắt đầu G0 khảo sát rồi G1 nền tảng và một lát cắt sản phẩm thật; không dừng lại chỉ để viết thêm kế hoạch.
4. Mỗi PR yêu cầu evidence theo `templates/RELEASE_EVIDENCE_TEMPLATE.md`. Chưa chạy test phải ghi `NOT_RUN`; không chấp nhận “đã xong” chỉ vì có ảnh đẹp.

Nếu repo chưa có gì, dùng đúng stack greenfield của tài liệu kiến trúc. Nếu repo đang phát triển, bảo toàn stack, contract, dữ liệu và quy tắc hiện hữu; lập mapping sang baseline thay vì viết lại dự án.

## Thứ tự đọc cho AI

| Vai trò | Tài liệu bắt buộc |
|---|---|
| Mọi AI | Instructions repo → README này → AI_RULES.md (phần luôn đọc) → AI_RULES_PROJECT → docs/18/19/20 → hồ sơ/task và module liên quan |
| UI/UX & frontend | Thêm docs/03, docs/04, docs/09, route manifest, tokens |
| API & backend integration | Thêm docs/05, docs/06, docs/07, docs/08, contracts |
| QA & release | Thêm docs/10, docs/12, docs/15, docs/17 và scenarios |
| Người tích hợp nhiều đội | Thêm docs/11, docs/13, docs/14 và templates |

Mỗi tác vụ chỉ nạp thêm tài liệu module liên quan; không sao chép cả bộ vào từng prompt làm mất ngân sách ngữ cảnh.

## Nguồn chuẩn và thứ tự ưu tiên

Tuân thủ thứ tự chỉ dẫn thực sự của môi trường/repo; bộ kit không tự hạ quyền nguồn chuẩn. Universal hướng dẫn cách ra quyết định; ADR đã duyệt, contracts chuẩn và đặc tả module xác định phần dự án. Code hiện có là bằng chứng quan sát, không tự động là quyết định thiết kế đã duyệt. Mâu thuẫn phải được ghi và xử lý đúng phạm vi.

Trong gói mới này: `contracts/openapi.yaml` là hợp đồng HTTP chuẩn; `.json` là bản sinh đồng nhất. `contracts/route-manifest.json` là danh mục route; `contracts/permission-catalog.json` là permission/vai trò mẫu; `design/tokens.json` là token chuẩn, CSS là bản sinh. Sửa nguồn rồi sinh lại và chạy kiểm tra, không sửa hai bản độc lập.

## Chế độ và giới hạn

- **UI_MOCK:** dựng và kiểm thử UI bằng dữ liệu giả; không gửi Messenger thật, không tiêu tiền AI, không ghi dữ liệu shop thật.
- **INTEGRATED_STAGING:** chạy backend thật với tài khoản thử, quyền và chính sách xác thực.
- **PRODUCTION:** chỉ mở khi G5 có bằng chứng backend, bảo mật, Meta, chi phí, restore và người chịu trách nhiệm ký duyệt.

UI không giữ Page Access Token, API key hay secret trong localStorage, bundle, URL, log. Nhập key là thao tác gửi một lần đến backend có bảo vệ; API chỉ trả metadata đã che. Một bản demo không có backend không thể đảm bảo phân quyền, tính đúng tồn kho hay lợi nhuận thực tế.

## Kiểm tra gói tài liệu

```bash
python scripts/validate_kit.py
```

Bộ kiểm tra này dùng thư viện chuẩn Python, kiểm tra cấu trúc nguồn JSON/OpenAPI, tham chiếu, route–operation–permission, scenario, token và checksum. Đây KHÔNG phải kiểm thử UI hay kiểm thử backend. Kiểm định schema chuyên dụng được ghi riêng trong `evidence/KIT_VALIDATION_REPORT.md`.

## Hồ sơ đi kèm

`docs/00..20`: phạm vi, kiến trúc, UI, nghiệp vụ, API, AI, security, state, test, đa AI, vận hành, mở rộng, backlog và truy vết. `contracts/`: đầu vào cho codegen/mocks. `fixtures/`: tình huống và payload giả. `design/`: tokens. `templates/`: mẫu PR/ADR/handoff/evidence.

Tài liệu tham khảo cũ được dùng làm đầu vào, không phải mọi đề xuất trong đó đều được giữ nguyên. Link share chỉ trả tiêu đề khi truy xuất trong phiên này; nội dung sử dụng được lấy từ hai báo cáo nghiên cứu lưu trong Library và ngữ cảnh yêu cầu. Chi tiết provenance và các điểm đã sửa được công bố trong docs/00.

## Cập nhật file sinh tự động

```bash
python scripts/refresh_generated.py
python scripts/validate_schemas.py
# Sau review và kiểm tra nội dung, làm mới checksum cho bản nội bộ đã sửa:
python scripts/refresh_generated.py --manifest
python scripts/validate_kit.py
```

Lệnh refresh không tự sửa route/spec khi API thay đổi; validator sẽ báo lệch để người phụ trách cập nhật đúng. Checksum giúp phát hiện thay đổi file, không thay chữ ký tin cậy hay review bảo mật. Bản Markdown tổng hợp là tiện ích đọc; khi code luôn lấy nguồn module/contracts trong thư mục gốc.

Bản hướng dẫn cập nhật 1.1: `HUONG_DAN_TRIEN_KHAI.pdf`. Công cụ kiểm tra đi kèm yêu cầu Python 3.10 trở lên.

## Cập nhật 1.1 — dark-only và quy định cho mọi AI

Dark-only đã được Jokertrader chốt trực tiếp: không light/system/toggle/preference storage.
Xem docs/19. Bộ AI_RULES.md 3.1 đính kèm giữ nguyên; docs/18 chứa 24 quy tắc code,
docs/20 quy định tiếp nhận và 16 cổng kiểm; governance chứa 24 kịch bản kiểm tra bổ sung.
AGENTS.md trong kit chỉ là điểm vào phạm vi thư mục; AI phải kiểm loader ở repo thật.

Hai kiểm tra tài liệu mới: `python scripts/validate_governance.py` và
`python scripts/test_governance_validator.py`. Chúng không kiểm mã ứng dụng hoặc
khóa CI. Companion Universal PROJECT_BOOTSTRAP_PROMPT.txt chưa được cung cấp trong
lần cập nhật này; không nhận đã có đủ cặp. Prompt code riêng vẫn ở PROJECT_BUILD_PROMPT_VI.txt.

Không cần đưa bản 1.0 và 1.1 đồng thời như hai nguồn hiệu lực. Kit 1.1 là gói đầy đủ,
giữ các hợp đồng/nghiệp vụ cũ và mở rộng governance; không cần tự ghép từng file.
Nếu repo đã áp dụng 1.0, AI đối chiếu CHANGELOG.md và giữ các tùy chỉnh/quyết định thật.
