# Dữ liệu và kịch bản kiểm thử

`shop-seed.json` là snapshot synthetic để khởi tạo MSW state. Shop A/B có SKU giống nhau để bắt lỗi isolation. Đây không là DB migration hay shop thật. `api-examples.json` có request, response, error, event và negative schema examples; `expectedValid=false` nghĩa validator phải từ chối shape, không phải ca test hỏng.

`acceptance-scenarios.json` mô tả 55 ca bằng Given/When/Then; chưa chạy trên ứng dụng. AI triển khai MSW handlers có state/version/idempotency đúng contract, có scenario selector DEV ONLY cho slow response, 403, 412, 429, unknown command và realtime gap. Không chọn fixture success cố định cho mọi POST.

Seed đang ở trạng thái đã nhập10, bán2, nhận300000 VND. Khi test từ đầu phải reset và replay chuỗi nghiệp vụ phù hợp; không chạy lại fulfillment trên seed đã fulfilled. Dữ liệu chỉ cover vài ví dụ chuẩn; scenario generator bổ sung large datasets không chứa PII. Payment/refund trong v1 là ghi nhận thủ công, không thực hiện chuyển tiền.
