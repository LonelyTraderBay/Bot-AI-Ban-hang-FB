# Ánh xạ token sang MUI

`tokens.json` là nguồn chuẩn; CSS là output. AI tạo MUI theme bridge tại G1: canvas→background.default, surface→background.paper, accent→primary.main, textPrimary/textSecondary→text, success/warning/danger→semantic colors. onAccent là chữ trên CTA accent. Không dùng chữ trắng trên mọi nền semantic. Control border dùng borderControl; borderDecorative chỉ phân cách trang trí, không đảm nhiệm dấu hiệu nhận biết control.

Giữ spacing/radius/typography theo token; icon và status có text/shape, không chỉ màu. Dialog, Select, Tooltip, Table, menu portal, disabled/focus/hover và biểu đồ cần theme đầy đủ. Token contrast được kiểm trên nền opaque quy định; hover/alpha/overlay thực tế vẫn phải đo trên UI. CSS media giảm motion chỉ là primitive, component animation cũng phải tôn trọng preference.

Đơn vị CSS cho font/space ở bản sinh là px; bridge có thể dùng rem tương đương cho khả năng scale. Không khóa browser zoom. Breakpoint đăng ký ở theme từ JSON; không hardcode giá trị khác trong từng module. Không đưa font binary vào gói bàn giao.

## Dark-only 1.1

Docs/19 chốt hành vi; không tạo getTheme(mode), light palette hay switcher.
Bridge tạo theme cố định ở root, nằm ngoài session/router để login và boot error
cùng theme. CSS từ tokens phải tải trước JS; html/body/#root có background/color
đúng. Không dùng color-scheme CSS như thay thế theme component; không ép tắt
forced-colors. `primary.light` là sắc độ được thư viện sử dụng, không app light mode.
