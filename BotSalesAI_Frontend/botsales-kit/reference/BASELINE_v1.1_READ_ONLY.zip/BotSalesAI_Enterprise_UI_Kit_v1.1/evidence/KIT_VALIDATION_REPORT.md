# Kiểm tra bộ tài liệu BotSales AI — bản 1.1

Ngày thực hiện: 29/09/2026. Phạm vi: snapshot tài liệu tại thư mục kit 1.1.
Không có repo ứng dụng hay Git revision sản phẩm được khảo sát/chỉnh trong nhiệm vụ này.

## Kết quả đã chạy

| Kiểm tra | Kết quả và phạm vi |
|---|---|
| Universal 3.1 nguyên bản | ĐẠT: đối chiếu byte/SHA-256 với AI_RULES.md người dùng tải lên |
| Policy governance | ĐẠT: 24 CODE, 12 DARK, 16 gate QG, 24 case QA; refs/hash/config nhất quán |
| Self-test validator governance | ĐẠT: 23 test trên bản sao tạm, gồm hợp lệ, vi phạm và lỗi CLI |
| Negative validator cấu trúc | ĐẠT: operation không tồn tại và token text contrast sai đều bị từ chối |
| Cấu trúc đặc tả | ĐẠT: 21 tài liệu đánh số, 36 routes, 12 modules, 34 permissions, 7 role presets |
| API/traceability | ĐẠT trong kiểm cấu trúc: 116 operations, 164 schemas, 2.219 refs được phân giải |
| YAML/JSON và fixtures | ĐẠT: objects đồng nhất, schema syntax, 27 case valid và 5 case invalid đúng kỳ vọng |
| Token/số học mẫu | ĐẠT: 22 cặp contrast opaque theo ngưỡng kit; số học mẫu kho/thu-chi nhất quán |
| Nguồn nghiệp vụ bản cũ | ĐẠT: OpenAPI, route, permission và các fixtures nghiệp vụ được đối chiếu giữ nguyên byte |
| PDF hướng dẫn | 6 trang; đã render PNG và kiểm bố cục/font tiếng Việt; không thấy cắt/chồng chữ |
| OpenAPI conformance đầy đủ | CHƯA XÁC MINH: chưa chạy công cụ conformance đầy đủ; JSON Schema syntax không thay nó |
| Lint/type/build/browser app | CHƯA XÁC MINH: chưa có mã nguồn ứng dụng được kiểm trong nhiệm vụ này |
| Loader/CI/branch protection trên repo | CHƯA XÁC MINH: đặc tả đã có, chưa cấu hình hoặc xác minh có hiệu lực |
| Backend/security/Meta/load/restore | CHƯA XÁC MINH: cần hệ thống và môi trường thật |

## Bằng chứng tái lập

Lệnh chạy từ thư mục kit bằng Python 3.10+; môi trường thực ở validation-environment.json.

```bash
python scripts/validate_governance.py
python scripts/test_governance_validator.py
python scripts/validate_kit.py
python scripts/validate_schemas.py
```

Các lệnh trên đã chạy thành công cho phạm vi tài liệu. Log self-test nêu từng test;
validator-negative-check.json ghi nonzero exit của mẫu sai (đó là kết quả mong đợi).
Không gọi 23 self-test của validator là 23 test sản phẩm. 24 QA specifications và
55 SC specifications vẫn giữ trạng thái NOT_RUN_PRODUCT_TEST.

Nguồn/hash Universal và sự nguyên vẹn nghiệp vụ: update-integrity.json. Gói có
MANIFEST.sha256 bao phủ file bàn giao, không bao gồm chính manifest. Manifest được
sinh sau report; structure-check.json trước đóng gói có checkedChecksums=0 đúng
phạm vi thời điểm kiểm. Sau đóng gói kiểm lại checksum trên bản giải nén; không
sửa log trước đó để làm như đã kiểm checksum từ đầu.

## Giới hạn và sử dụng

Đây là kiểm tính nhất quán và dữ liệu mẫu của kit, không là chứng nhận bảo mật,
a11y, kế toán, hiệu năng hoặc production của ứng dụng. Gate QG mới ở SPECIFIED;
AI triển khai phải cấu hình lệnh/coverage source, chạy test đúng revision, thêm
negative tests và chứng minh required checks trước gọi ENFORCED.

Không nhận đã đọc companion Universal: PROJECT_BOOTSTRAP_PROMPT.txt chưa được
cung cấp trong đầu vào cập nhật này. AI_RULES.md được giữ nguyên, không có bản giả
companion. Các nguồn public mới đã đối chiếu ở docs/16; nguồn 1.0 được ghi là kế thừa.
