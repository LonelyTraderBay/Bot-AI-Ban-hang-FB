# BotSales AI — điểm vào cho AI trong thư mục bộ tài liệu

Kit 1.1, 29/09/2026. Thư mục này là đặc tả, không phải ứng dụng đã chạy.

Tuân thủ thứ tự chỉ dẫn thật của môi trường và repo cha. File này không tự cấp quyền
sửa code ngoài phạm vi, không tự làm quy tắc áp dụng trên toàn repo nếu kit nằm trong docs/.

Trước ghi, đọc `README_START_HERE.md`, hai phần LUÔN ĐỌC của `AI_RULES.md` 3.1,
`AI_RULES_PROJECT.md`, `docs/18_CODING_STANDARDS.md`, `docs/19_DARK_ONLY_POLICY.md`
và `docs/20_AI_BOOTSTRAP_AND_ENFORCEMENT.md`; sau đó mở đúng đặc tả của task.

Yêu cầu đã chốt: UI DARK-ONLY từ lần render đầu. Không light theme, system mode,
switch, preference storage hay framework đổi theme. Không sửa Universal để chèn yêu cầu này.

Chỉ một chuẩn stack/API/token có hiệu lực trong mỗi phạm vi. Không tự thay thư viện,
viết DTO song song, import chéo nội bộ module, sửa file chung không có ownership,
tắt kiểm thử hay gắn nhãn production từ kết quả mock.

Khi được giao áp dụng vào repo, tận dụng điểm nạp instructions hiện có; chỉ thêm
tham chiếu nhỏ theo `templates/AGENTS_REPO_SNIPPET.md` sau khảo sát. Không ghi đè
AGENTS.md, không tự tạo đồng thời cấu hình cho mọi hãng AI, không nhận đã tự nạp
nếu chưa quan sát cơ chế và phạm vi của công cụ thực dùng.

Task docs-only dừng ở tài liệu. Task implement thực hiện đúng quyền và gate G0/G1.
Bốn trạng thái nghiệm thu: ĐẠT / CHƯA ĐẠT / CHƯA XÁC MINH / KHÔNG ÁP DỤNG có lý do.
