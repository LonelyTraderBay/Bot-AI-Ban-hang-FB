# 08 — Bảo mật, tenant isolation và phân quyền

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Ranh giới tin cậy

Browser không tin cậy; backend/BFF quyết định authorization và nghiệp vụ. Nhà cung cấp AI/Meta/attachment là bên ngoài. Shop là tenant boundary. Permission và field access kiểm ở API, worker, stream, export, search/index và object storage; route guard chỉ là UX. Mục tiêu kiểm soát tham khảo OWASP ASVS [S09], chưa chứng nhận đạt level nào.

Permission catalog chuẩn nằm trong `contracts/permission-catalog.json`; vai trò là preset để khởi tạo, không hardcode `role==='admin'` trong component. Backend trả effective permissions + permissionVersion. UI so permission string, feature/capability và resource allowedActions; cả ba phải cho phép. Jobs/exports còn phải kiểm quyền với resource nguồn, không chỉ jobs.read.

## 2. Vai trò baseline

Owner quản trị toàn shop, kể cả đặc quyền. Manager quản vận hành, không mặc định được post tài chính hoặc quản secret. Sales xử lý inbox/khách/đơn, không cost/P&L. Warehouse xem kho và fulfillment, không xem thông tin khách hoặc giá vốn ngoài quyền. Accountant thu/chi, thanh toán/hoàn tiền và báo cáo. BotAdmin quản tri thức/cấu hình, không ledger. Viewer chỉ đọc phạm vi được cấp. Các preset đề xuất có trong JSON; owner có thể điều chỉnh sau khi workflow permission management được triển khai và kiểm thử.

Quyền đọc order không mặc nhiên được xem address đầy đủ, chi phí hay margin. Backend masking tùy role/purpose: finance fields/contact có thể null với redaction metadata. Test response body, không chỉ DOM. Customer details chỉ được render đúng dữ liệu được API trả cho principal đó.

## 3. Tenant isolation checklist

Session membership trước route data fetch; queries/streams scoped. Path shopId không đủ: mỗi entity reference kiểm thuộc shop; join/filter server bắt buộc. Cache key backend, query key frontend, vector retrieval metadata filter, file object prefix+authorization, signed URL và export job đều có tenant boundary. Không sử dụng một retrieval corpus chung rồi lọc sau khi LLM đã đọc.

User chuyển shop: prompt discard unsaved draft; cancel requests → close stream → clear old query client/forms/PII → bootstrap session/new shop → mount new scoped client. Late response phải so scope generation. Logout/permission revoke qua nhiều tab dùng broadcast chỉ metadata và session invalidation; tuyệt đối không broadcast secret/chat contents.

Chính sách cross-tenant resource trả 404 hoặc phản hồi không tiết lộ sự tồn tại thống nhất ở backend. Test role A đoán URL/B identifier, download signed URL của B, SSE của B, export job của B, lookup conversation của B, vector hits của B. Kết quả phải fail-closed.

## 4. Secrets và nội dung không tin cậy

Không API key, Meta token hoặc signing secret trong VITE_ env, public runtime config, bundle, local/sessionStorage, IndexedDB, URL, analytics hoặc screenshots. Nhập secret giữ transient local state, clear khi submit/cancel/unmount; sau submit chỉ metadata. JavaScript không thể bảo đảm xóa memory vật lý; giảm bề mặt phơi lộ và TTL, không hứa zeroization tuyệt đối.

Backend vault/KMS, rotate/revoke, least privilege, audit thay secret. Key test không trả raw error chứa credential. Log redaction trước network export; session replay mặc định tắt cho inbox/finance/key form. Không dùng demo credentials có thể nhầm với key thật.

Render message/knowledge plain text hoặc sanitize allowlist. Link dùng safe schemes; file/image qua upload pipeline và authorized serving, không mở arbitrary SVG/HTML active content. CSV exports escape formula injection khi mở spreadsheet; import không chạy macros/formula/external links. File validation MIME + extension + signature, size/quota, malware/quarantine server.

## 5. Web controls và supply chain

HTTPS, secure headers, CSP theo allowlist thực (không `*`/unsafe-eval tùy tiện), clickjacking protection, CSRF+origin cho cookie writes, CORS chặt cho topology đã chọn, upload/download authorization. Dependency/secret scans, SBOM, license check, pinned lockfile, protected branch/CI, verified build artifact và review third-party code.

Frontend chỉ đọc public runtime schema: API same-origin base, releaseId, telemetry endpoint public, mode UI_MOCK/staging/production, capability bootstrap. Unknown/invalid config làm startup fail-safe với lỗi có hướng dẫn; không fallback demo ở production.

## 6. Privacy và audit

Data inventory phân loại PII (message, phone/address), tài chính, secret và public catalog. Retention policy là release decision theo thị trường, hợp đồng, mục đích và legal hold; không tự tuyên bố một thời hạn chung đáp ứng luật. V1 có UI cho policy/requests với trạng thái pending/running/completed/rejected/legal_hold và audit, nhưng pháp lý cần người có trách nhiệm đánh giá.

Delete/export request kiểm identity và authority, phạm vi shop/customer, source files, vector index, summaries, cache và downstream providers khi có nghĩa vụ. Backups có expiration/restore controls; khi restore cần replay deletion ledger để không hồi sinh dữ liệu đã xóa. Không hứa xóa vật lý mọi backup ngay lập tức. Audit không chứa raw secret/chat; giữ metadata cần thiết trong phạm vi được duyệt.

## 7. Threat model và evidence

| Nguy cơ | Kiểm soát trọng tâm | Gate |
|---|---|---|
| IDOR/rò tenant | authz mọi object, join/index/export/stream scoped | negative integration tests + backend review |
| Key/PII leak | transient secret, log scrub, bundle/storage scan | security test + captured sanitized requests |
| XSS/prompt injection | encode/sanitize, tools allowlist, untrusted retrieval | adversarial fixtures + review |
| Double order/refund | server idempotency, source uniqueness, transaction | concurrency/replay tests |
| Lost update | ETag/version, conflict UI | two-session test |
| SSRF custom endpoint | DNS/IP/redirect/egress allowlist | backend security test |
| Supply-chain | pin/audit/SBOM/review | CI reports |
| Unauthorized AI publish | permission + eval + approval + rollback | audit/eval evidence |

Không coi button hidden, TypeScript types, client-side filter hoặc prompt “đừng làm điều xấu” là security boundary. Không tự tuyên bố GDPR/PDPA/SOC2/ISO chỉ vì có các control này.
