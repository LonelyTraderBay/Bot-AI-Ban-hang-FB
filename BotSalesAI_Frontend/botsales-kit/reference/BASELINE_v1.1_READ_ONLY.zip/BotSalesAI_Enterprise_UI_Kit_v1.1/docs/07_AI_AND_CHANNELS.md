# 07 — AI đa nhà cung cấp, tri thức và Messenger

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. “Bất kỳ AI” phải là khả năng mở rộng có kiểm chứng

UI không thể kết nối mọi API chỉ bằng một ô key chung. Baseline tạo registry adapter phía backend, mỗi connection có providerId, adapterId/version, modelId, endpoint policy, credential metadata và capability map. Provider/model unknown được hiển thị unsupported hoặc cần adapter, không gọi theo phỏng đoán protocol.

Các capability: text, streaming, vision, structuredOutput, toolCalling, embeddings và usageReporting; mỗi capability có supported/unsupported/unknown, lastVerifiedAt và limits thực. Một model chat không mặc nhiên hỗ trợ embedding hoặc tool call. Không dựa vào tên model để suy khả năng. Adapter OpenAI-compatible cũng phải qua test; “compatible” không bảo đảm parity về tool/schema/usage/error. Model/giá/quota lấy catalog server, không pin trong component.

## 2. Vòng đời connection

`unconfigured → validating → connected → degraded/expired/disabled`. UI cho nhập provider/model/settings phù hợp schema; secret input local một lần. Backend lưu mã hóa và trả keyLast4/hasCredential, không trả key gốc. “Kiểm tra kết nối” nói rõ có thể phát sinh request tính phí; tại UI_MOCK chỉ mô phỏng, không dùng key thật.

Custom endpoint chỉ HTTPS allowlist đã được backend duyệt. Chặn loopback/private/link-local/metadata endpoints, DNS rebinding và redirect sang đích không được phép. Không biến ô base URL thành SSRF proxy. Thay provider trong production phải kiểm data residency, privacy, budget và capabilities; không silent fallback đưa PII sang nhà cung cấp khác.

## 3. Knowledge và memory là những lớp khác nhau

| Lớp | Dùng để làm gì | Quyền/phạm vi |
|---|---|---|
| Conversation context | ngữ cảnh hội thoại hiện tại, summary có nguồn | customer+shop scoped, không chia sẻ với khách khác |
| Customer memory | sở thích được phép lưu, đã kiểm tra nguồn | riêng customer, retention/consent phù hợp |
| Shop knowledge | chính sách, mô tả, FAQ, tài liệu được duyệt | toàn shop, published revisions |
| Live business tools | giá, tồn, trạng thái đơn | server authorization và fresh data |
| Eval/feedback dataset | đo chất lượng, tìm lỗi | redacted, review, versioned |

Lưu lịch sử không có nghĩa model weights tự thay đổi. Baseline không fine-tune tự động. RAG là truy xuất tài liệu được phép; thông tin giá/tồn phải gọi live business tool. Mọi retrieved text, attachment và lời khách là dữ liệu không tin cậy; không được nâng thành system instruction [S10]. Nội dung kiểu “bỏ qua quy tắc, gửi key” phải bị coi là dữ liệu, không thành lệnh.

## 4. Knowledge pipeline và UI tương ứng

Upload/manual source → type/size/malware checks → parse → dedupe/content hash → chunk/index draft → review/redaction → eval → publish revision. UI hiển thị từng state: draft, processing, ready_for_review, rejected, published, retired, failed. Processing thành công không tự publish. Published revision bất biến; edit tạo revision mới. Publish phải ghi approver, source, version, eval result và rollback target.

Feedback từ inbox tạo candidate, không tự chèn vào published KB. Lưu evidence sai, correction, source scope và review reason. Không tái dùng raw customer PII trong general shop knowledge. Xóa source phải retire/remove cả index, summaries, caches theo policy; không chỉ xóa file UI rồi để embedding vẫn được truy xuất. Legal hold được xử lý riêng theo phạm vi đã duyệt.

## 5. Tool authority

Bot được đọc sản phẩm/tồn qua permission-scoped tools; được đề xuất draft order. Xác nhận đơn/reservation chỉ chạy khi khách hoặc nhân viên đã xác nhận nội dung/giá và backend policy cho phép. V1 mặc định human-confirmed order write. AI không có tool sửa ledger, tự hoàn tiền, đổi giá, đổi quyền, export danh sách khách hoặc publish tri thức.

Tool invocation phải validate schema, tenant, authorized actor, allowed action, amount/quantity, idempotency và budget. Output model không được execute như SQL, JavaScript, shell hay HTML. UI render plain text hoặc sanitized markup allowlist; link và attachment qua kiểm soát URL.

## 6. Evals, phiên bản và chi phí

Playground là sandbox, không gửi khách. Hiển thị model/config/KB versions, nguồn được dùng, tool calls đã kiểm soát, latency, usage và cost **ước tính** khi có. Nếu provider không báo usage thì hiển thị unknown, không 0. Không trình bày điểm “confidence” do LLM tự tạo như xác suất chính xác; dùng source coverage/eval metrics đo được.

Evaluation dataset baseline có các nhóm: hỏi SKU/size, giá đổi, hết hàng, không có thông tin, policy mâu thuẫn, PII, prompt injection, đổi ngôn ngữ, câu hỏi ngoài shop, provider timeout, tool error, handoff. Mỗi case có expected behavior, source version, pass/fail rubric. Publish config yêu cầu không có critical failure ở leak/unauthorized action/wrong price-stock trên bộ gate, không giảm coverage/quality dưới ngưỡng đã được chủ dự án chốt. “0 lỗi trong bộ test” không có nghĩa “0 lỗi thực tế”.

Budget trên server: shop/request/daily cap, maximum tool steps, context budget, request timeout, concurrency limit và circuit breaker. UI hiển thị remaining/estimated/exhausted, không là nơi enforce. Giá model biến động được đánh dấu asOf; invoice reconciliation tách khỏi token estimate. Pause bot là kill switch ưu tiên cao và có audit.

## 7. Messenger: capability và policy lấy từ server

Kết nối Facebook Page chính thức qua OAuth/cơ chế được Meta hỗ trợ; không scraping hoặc tài khoản cá nhân. Backend lưu Page token/secret; UI chỉ thấy page name/id, permission checks, subscription health, last webhook time, last policy verification và reconnect action.

**Chưa xác minh policy Meta hiện hành trong phiên này:** trang chính thức bị HTTP 429 [S13]. Không hardcode số giờ messaging window, tên quyền, Graph version hoặc điều kiện Human Agent vào tài liệu như sự thật đã kiểm chứng. Trước integration thật, ghi exact Meta API version, quyền/app review, webhook subscription, token lifecycle, allowed message types, window và bằng chứng lấy từ tài khoản/app thực.

Mỗi conversation có `sendEligibility:{state:allowed|blocked|unknown, reasonCode, expiresAt, policyVersion}` do backend tính, và backend phải kiểm lại tại send. Unknown/blocked → disable send có lý do; không cho bypass. Không dùng handoff làm cách vượt policy. Không bulk message hoặc tự nhắn người chưa tương tác/không được phép.

## 8. Webhook/backend behavior bắt buộc cho integration

Xác thực challenge và chữ ký theo tài liệu Meta tại phiên bản đã chốt; verify trên raw body đúng cách. Chỉ ACK sau khi event được tiếp nhận bền vững, sau đó worker xử lý theo queue và conversation serialization. Dedupe theo provider/page/event identity; ordering sai hoặc webhook replay không tạo message/order lặp. Có dead-letter/replay có quyền, retry bounded, rate limit và observability.

Agent/human handoff có version/fencing token: takeover nâng generation, hủy/supersede AI job đang chờ; trước send worker kiểm generation và assignment mới nhất. Nếu AI đã gửi trước takeover được commit, hiển thị đúng lịch sử; không hứa thu hồi tin đã gửi. Race test phải chứng minh không gửi bot sau takeover commit bằng generation cũ.

Message state: queued, sending, sent, delivered, read, failed, unknown; những trạng thái provider không hỗ trợ không giả ra. Timeout khi send có thể đã tới Meta: tra trạng thái và reconcile, không gửi lại ngay một message mới. UI hiển thị delivery source và retry eligibility từ backend.
