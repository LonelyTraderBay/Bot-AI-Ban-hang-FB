# 00 — Nguồn, phạm vi kế thừa và quyết định chuẩn hóa

Phiên bản 1.1 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Điều đã biết và điều chưa biết

Yêu cầu trực tiếp: tạo bộ tài liệu đủ để AI code UI theo hướng production-ready, enterprise-grade, có nền tảng mở rộng. Ngữ cảnh dự án: Bot bán hàng tự động qua Facebook, API key đa AI provider, lưu kiến thức/hội thoại để cải thiện có kiểm soát, quản lý sản phẩm, nhập hàng, tồn kho, thu/chi và lợi nhuận; UI đơn giản sang trọng, theme tối.

Nguồn nội bộ đã đọc toàn văn ngày 29/09/2026: **“Tóm tắt điều hành(3)”**, 256 dòng nội dung, file_id `file_000000005ba481fb98c619a521620fb4`; và **“Tóm tắt điều hành(1)”**, 274 dòng nội dung, file_id `file_000000003cd0820993ce47d6e25176a8`. Các nghiên cứu này là nội dung AI tạo trước, dùng làm yêu cầu đầu vào chứ không coi là bằng chứng kỹ thuật đã kiểm chứng.

Link share được người dùng cung cấp có tiêu đề “Phân tích tính năng Bot AI bán hàng”, nhưng công cụ không đọc được toàn văn hội thoại qua trang share. Không tuyên bố đã đối chiếu từng lượt chat hoặc toàn bộ sự phê duyệt cũ. Các trích dẫn đánh số bên trong báo cáo cũ không được sao chép như nguồn đã xác minh.

Chưa có repo code thực tế, backend đang chạy, thương hiệu cuối, target traffic, KPI latency đo được, chính sách tài chính, thị trường pháp lý hoặc tài khoản Meta được kiểm tra trong phiên này. Không tự suy ra từ dự án trading hoặc blockchain khác. Bản cập nhật 1.1 đã nhận AI_RULES.md Universal 3.1; chỉ áp dụng hành vi dùng chung, không nhập nghiệp vụ từ repo khác.

## 2. Những điểm giữ nguyên

Facebook Messenger là kênh đầu tiên. Provider AI mở rộng qua adapter và capability. Chủ shop có chỗ nhập sản phẩm và tài liệu. Có inbox/human handoff, khách hàng, đơn hàng, quản lý tồn theo biến thể, thu/chi và lợi nhuận quản trị. Dark-only, tiếng Việt trước, đáp ứng desktop/tablet/mobile. Có bảo mật, audit, kiểm thử, CI/CD và quy tắc phát triển lâu dài ngay từ nền tảng.

## 3. Các điểm phải sửa khi chuyển nghiên cứu thành đặc tả

| Nội dung nghiên cứu còn rộng/rủi ro | Baseline của kit | Lý do và trạng thái |
|---|---|---|
| React/Vue/Angular và nhiều bộ UI để AI tự chọn | Một stack greenfield ở docs/02; repo cũ giữ stack | Quyết định đề xuất để tránh mỗi AI chọn một kiểu |
| Microservices/microfrontend mặc định | Modular frontend, một deployment | Không đánh đồng “enterprise” với nhiều dịch vụ |
| “API key bất kỳ AI nào là dùng được” | Adapter + capability + compatibility test | Không giả định mọi provider có cùng protocol/quyền/model |
| Lưu toàn bộ chat rồi tự học | Feedback → redaction → review → eval → publish | Không biến dữ liệu khách hoặc prompt injection thành tri thức tin cậy |
| Giá/tồn lấy từ vector DB | Giá và available từ API nghiệp vụ live | RAG không là nguồn chân lý giao dịch |
| Tạo đơn là doanh thu, thu tiền là lợi nhuận | Tách order/fulfillment/payment/cashflow/P&L | Ngăn báo cáo sai và tính trùng |
| Optimistic khi tạo đơn/sửa kho | Chờ xác nhận server; timeout → reconcile | Không làm UI che mất xung đột tồn hoặc trùng lệnh |
| Offline cache chat/PII và tự sync ghi | Không persisted PII, offline chỉ xem tạm dữ liệu đã tải | Offline write engine hoãn cho đến khi có nhu cầu thật |
| Ghi cứng model, giá, quota và Meta window | Catalog/capability/policy lấy từ backend | Phụ thuộc ngoài thay đổi; không đoán hỗ trợ |
| “Tuân thủ GDPR/PDPA”, tốc độ/tải đạt sẵn | Mục tiêu kiểm soát + release gate có evidence | Chưa có đánh giá pháp lý, pentest hay load test |

## 4. Sổ quyết định nền tảng

| ADR | Quyết định | Phạm vi | Trạng thái |
|---|---|---|---|
| ADR-001 | Modular frontend, không microfrontend giai đoạn đầu | Greenfield | BASELINE ĐỀ XUẤT |
| ADR-002 | React/TS/Vite/React Router/MUI/Query, không CRA | Greenfield | BASELINE ĐỀ XUẤT |
| ADR-003 | REST contract-first OpenAPI 3.1.0, SSE event invalidation | UI↔backend | BASELINE ĐỀ XUẤT |
| ADR-004 | Shop là security boundary; Membership tách User | Mọi dữ liệu | BASELINE ĐỀ XUẤT |
| ADR-005 | Không key hoặc business-truth trong browser | An toàn | RÀNG BUỘC THIẾT KẾ |
| ADR-006 | Dữ liệu giả tại network, không trong JSX | UI_MOCK | BASELINE ĐỀ XUẤT |
| ADR-007 | Human-reviewed knowledge, live tools cho giá/tồn | AI | BASELINE ĐỀ XUẤT |
| ADR-008 | Kế toán quản trị, không phần mềm kê khai thuế | Finance v1 | BASELINE ĐỀ XUẤT |
| ADR-009 | Single-writer cho contract/router/tokens/lockfile | Nhiều AI | BASELINE ĐỀ XUẤT |
| ADR-010 | Giữ kiến trúc repo cũ, migrate từng lát cắt | Brownfield | RÀNG BUỘC TIẾP NHẬN |

Dùng bộ kit để bắt đầu UI_MOCK không đồng nghĩa phê duyệt thay đổi phá vỡ repo hoặc được phép phát hành production. Khi chủ dự án phê duyệt, ghi ngày, người, phạm vi và ADR; không sửa lịch sử để làm như quyết định đã được duyệt từ đầu.

## 5. Không làm trong phiên tạo tài liệu

Chưa build UI, chưa gọi backend/Meta/AI provider thật, chưa kiểm thử trình duyệt, chưa đo tải, chưa thử restore hay chứng minh tính đúng kế toán. Bằng chứng kiểm tra đi kèm chỉ là kiểm tra chính bộ tài liệu/schema/fixtures. Đây là giới hạn công khai, không phải lý do trì hoãn dựng UI.

## 6. Bổ sung nguồn và quyết định 1.1

Đầu vào mới: yêu cầu Jokertrader 2026-09-29T06:44:43Z chốt UI dark ngay từ đầu và
bổ sung quy định code/AI; file AI_RULES.md Universal 3.1 đính kèm. File gốc được giữ
nguyên byte và đối chiếu SHA-256 tại governance/universal-source.json.

| ADR | Quyết định | Trạng thái và phạm vi |
|---|---|---|
| ADR-011 | UI dark-only, không light/system/toggle hoặc preference | ĐÃ DUYỆT bằng yêu cầu trực tiếp; chi tiết docs/19 |
| ADR-012 | Áp dụng Universal nguyên bản, đặt coding/AI policy riêng trong dự án | Yêu cầu tích hợp đã được giao; cơ chế cụ thể docs/18/20, chưa cài trên repo thật |

Đây không phải phê duyệt mọi ADR cũ, mọi ngưỡng coverage/tải hoặc quyền deploy.
Companion PROJECT_BOOTSTRAP_PROMPT.txt không được cung cấp trong lần này. Không
phục dựng nó từ trí nhớ. Những nguồn public mới kiểm ở docs/16 và source-register;
nguồn nghiên cứu/kiểm tra 1.0 kế thừa như provenance của bản trước, không nhận đã
đọc lại toàn bộ trong lần 1.1. Không thay endpoint/data model nghiệp vụ ở lần này.
