# 11 — Quy trình triển khai và phối hợp nhiều AI

Phiên bản 1.1 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Luồng triển khai bắt buộc

**G0 — Discover & align.** Xác định greenfield/brownfield từ file thật. Ghi cấu trúc repo, framework/versions/lockfile, commands, test baseline, auth/tenant model, API contracts, style system, CI và khu vực đang sửa. Tạo `REPO_ADOPTION.md`, `STACK_LOCK.md`, `IMPLEMENTATION_STATUS.md` trong docs dự án; phân loại OBSERVED/PROPOSED/APPROVED/UNKNOWN. Không xóa code hoặc nâng framework tự tiện.

**G1 — Foundation + vertical slice.** Có app khởi động, auth mock, shop scope hai tenant, route guards, query lifecycle, HTTP client, generated DTOs, tokens/MUI theme, error boundary và Product list → create → edit → archive chạy qua HTTP mock. Hoàn thành đủ states/keyboard/conflict và CI baseline. Không chỉ tạo 36 trang rỗng rồi tuyên bố xong UI.

**G2 — Operations.** Customer/inbox/handoff, catalog import, inventory và order commands. Làm từng lát cắt có dữ liệu/permission/test, không chia việc kiểu “một AI viết hết HTML, AI khác tự đoán API sau”.

**G3 — Management & AI.** Finance cashflow/P&L, knowledge revisions/review, providers/capabilities, bot eval/publish, reports, team/privacy/audit/jobs. Các nút tác động bên ngoài vẫn disabled hoặc mock có banner rõ.

**G4 — Real integration.** Thay transport/mock bằng backend staging đáp ứng contract; giữ module UI. Kiểm auth/tenant/object/field permissions, concurrency, webhook/policy, jobs và provider cost controls. Chênh lệch API phải được giải quyết qua change request, không cast bỏ lỗi.

**G5 — Release.** Hoàn tất docs/12, không unresolved critical risk; ownership/on-call và rollback thật; owner ký hiệu lực nghiệp vụ/cost/policy. Không tự triển khai production khi chỉ được giao code UI.

## 2. Phân công và vùng sở hữu

| Lane | Vùng ghi mặc định | Vùng cần Integrator duyệt |
|---|---|---|
| Integrator/Platform | app shell, routing, auth scope, shared HTTP, CI, lockfile, packages/contracts, design tokens | Thay đổi kiến trúc hoặc quyền cần owner review |
| Commerce UI | modules/catalog, inventory, orders; tests tương ứng | contracts, finance semantics, shared components |
| Conversation UI | modules/inbox, customers; tests tương ứng | handoff authority, integration policy, shared transport |
| AI UI | modules/knowledge, bot, integrations; tests tương ứng | secrets, eval/publish rules, custom provider endpoints |
| Finance/Governance UI | modules/finance, reports, workspace, dashboard | Money/accounting policy, permissions, export rules |
| QA | tests/fixtures/E2E/acceptance report | Không tự sửa sản phẩm để che test; proposal được owner nhận |

Lane là nhóm trách nhiệm, không yêu cầu đủ sáu người. Nhóm nhỏ có thể một người nhiều lane nhưng mỗi file/task vẫn một owner hiện tại. Mọi thay đổi `package.json`, lockfile, API schema, permission catalog, route registry, design tokens, root configs và CI đều qua Integrator. Không nhiều agent cùng regenerate lockfile.

## 3. Task contract trước khi code

Dùng TASK_TEMPLATE: mục tiêu observable, input docs tối thiểu, FR/SC IDs, file allowlist, dependency contracts/versions, non-goals, commands, expected tests và rủi ro. Nếu thiếu endpoint/model/permission: mở CONTRACT_CHANGE_REQUEST; không tự thêm cách đặt tên thứ hai trong module.

Mỗi agent dùng branch/worktree riêng. Kiểm `git status` trước làm; giữ nguyên thay đổi không thuộc mình, không `reset --hard`, không stash/checkout file người khác. Chỉ stage file trong task. Dừng đúng điểm khi hợp đồng đang có xung đột và chuyển sang phần độc lập; không chờ vô thời hạn hoặc tự sửa shared file lén.

## 4. Trình tự merge

Shared contract + fixtures + compatibility tests merge trước; module consumption merge sau. Với breaking change cần expand/contract hai phiên bản thay vì bắt mọi đội merge một lần. Integrator kiểm dependency DAG và giữ một queue cho file chung. Cập nhật task state `ready/in_progress/blocked/in_review/merged`, owner và blocking reason trong file dự án hoặc issue tracker hiện hữu; không tự dựng một hệ quản lý thứ hai.

Giới hạn task theo một hành vi kiểm chứng được, ví dụ “confirm order conflict”, không “code toàn bộ order module”. PR quá lớn cần tách nhưng không bỏ test để đạt số dòng đẹp. Cross-module flow nằm ở app composition/read model, không cho module gọi sâu nội bộ module khác.

## 5. Báo cáo cuối mỗi lượt AI

Ghi: đã sửa gì, đường dẫn chính xác, task/FR/SC đã đáp ứng; lệnh thật đã chạy và PASS/FAIL/NOT_RUN; commit/base revision khi có; còn rủi ro gì; tác vụ tiếp theo đã đủ dependency chưa. Dùng HANDOFF_TEMPLATE. Không nói “tested thoroughly” nếu chỉ chạy typecheck. Không tự tạo số coverage/Lighthouse hay ảnh mô phỏng như ảnh app đã chạy.

## 6. Tái sử dụng cho repo đang làm dở

Không ghi đè bộ AI_RULES/PROJECT_BOOTSTRAP đa dự án đang có. `AI_RULES_PROJECT.md` của kit chỉ bổ sung phạm vi BotSales. G0 lập bảng baseline hiện tại ↔ đề xuất mới ↔ cách bridge ↔ điều cần approve. Tiếp tục hiện thực sau khảo sát ở phần an toàn; không biến nhiệm vụ code thành docs-only vô hạn. Nếu bước bootstrap riêng trong repo quy định docs-only, hoàn thành bước đó và báo rõ ranh giới; chỉ chuyển code khi instruction của chủ dự án cho phép.

## 7. Quy tắc dùng chung có hiệu lực từ đầu (1.1)

Đọc AI_RULES.md nguyên bản và docs/18–20. Integrator/owner là vai trò được giao thật,
không mặc định Lead AI có quyền merge hoặc tự sở hữu mọi file. Mỗi shared surface
một writer chủ động hoặc phân vùng đã xác nhận; thiếu cô lập thì làm tuần tự.
Bộ kit không tự cài loader/branch protection và không tự đồng bộ phiên khác.

G0 ghi nguồn/hash/version đã tiếp nhận; G1 cấu hình và kiểm các gate đã chọn. Khóa
nền tảng dark và một vertical slice trước chia rộng. Bản thân việc đọc hướng dẫn
không thay ca kiểm sai chứng minh enforcement. Task docs-only không tự mở rộng
thành code; task implement được giao tiếp tục phần an toàn sau khảo sát.
