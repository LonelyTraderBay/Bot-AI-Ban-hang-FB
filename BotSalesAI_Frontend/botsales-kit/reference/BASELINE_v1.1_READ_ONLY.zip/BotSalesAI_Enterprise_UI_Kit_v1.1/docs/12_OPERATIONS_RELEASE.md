# 12 — Vận hành, phát hành và phục hồi

Phiên bản 1.0 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Phân chia trách nhiệm UI/backend

UI build phát hành static assets qua HTTPS cùng origin với BFF/API reverse proxy theo baseline. Backend giữ session, CSRF, authorization, secrets, quotas, audit, durable jobs, inventory transactions và AI/channel workers. Một deployment UI thành công không chứng minh các phần backend này đã sẵn sàng.

Cấu hình public runtime chỉ có API path, environment label, release ID, feature flags không nhạy. Private credentials ở server secret manager. App từ chối config thiếu/sai; không bật demo data để “cứu” production. MSW/browser dev controls phải bị loại khỏi production initialization; CI scan registration và assets. `VITE_*` được xem là public.

## 2. Môi trường và migration

Development/mock, staging và production tách dữ liệu, keys, provider quota và Meta app/page thử phù hợp. Không copy raw conversation/PII production về fixture. Auth/session domains và cookie flags được verify theo môi trường; không lấy staging insecure setting làm default production.

Phát hành backend tương thích contract cũ trước; phát hành UI sau. Giữ support ít nhất N và N-1 trong cửa sổ chuyển tiếp đề xuất 30 ngày, điều chỉnh theo usage/thỏa thuận. Hashed assets cache immutable; HTML/bootstrap config kiểm cập nhật; giữ assets cũ qua cửa sổ rollout để tab cũ không lỗi chunk. Thông báo refresh khi version quá cũ, bảo toàn draft an toàn và reconcile command trước refresh.

Database dùng expand → backfill có quan sát → chuyển reads/writes → kiểm nhất quán → contract. Không rollback schema bằng drop dữ liệu khi còn worker/UI cũ. DB migration owner phải phê duyệt; kit không cung cấp migration SQL production.

## 3. Telemetry tối thiểu

Frontend logs: releaseId, route template (không full URL chứa query nhạy), error code, requestId, scope đã pseudonymize, browser class và elapsed time. Không raw message/prompt, API key, phone/email, payload finance, auth headers hoặc upload content. Theo dõi route errors, failed chunks, API 4xx/5xx, permission-denied ratio, long tasks, web vitals, realtime reconnects/gaps, job failures và UI actions critical.

Backend phải bổ sung queue age, webhook verification/dedupe, message send status unknown, handoff stale generation rejection, provider latency/error/quota/cost, stock conflicts, command reconciliation, export access denial, deletion backlog và audit integrity. Trace/request IDs nối UI → API → job; không nhét PII vào trace tags. Sampling không làm mất security audit bắt buộc.

## 4. SLO và cảnh báo — đề xuất, cần chủ hệ thống duyệt

| Phạm vi | Mục tiêu khởi điểm | Ghi chú |
|---|---|---|
| UI/API quản trị | Availability 99.9% theo tháng trên synthetic + real request đã định nghĩa | Không gộp provider outage thành số UI availability không giải thích |
| API đọc thông thường | p95 ≤800ms tại workload G4 đã chốt | Báo cáo/export/LLM tách lớp; không hứa LLM trả lời <2s |
| Webhook durable accept | p95 ≤1s trong workload thử | ACK sau lưu bền; xử lý nền tách khỏi ACK |
| Incident dữ liệu/auth/secrets | Alert ngay khi có tín hiệu critical xác thực được | Có owner trực nhận; không dựa vào bot chat hỗ trợ |
| DB business data | RPO ≤15 phút, RTO ≤4 giờ | Mục tiêu đề xuất phải chứng minh bằng restore drill |

Threshold alert phải có volume floor, rolling window và runbook, tránh một lỗi khách lẻ thành paging. Cảnh báo budget AI theo ngưỡng shop do owner duyệt; worker enforce hard cap/daily quota độc lập UI. Demo hardcoded quota không là kiểm soát chi phí thật.

## 5. Runbook tối thiểu

**Lộ secret:** disable integration/rotate server key, revoke sessions liên quan, xác định phạm vi theo audit, scrub nơi log sai, thông báo quy trình incident và retest; không hiển thị key trong ticket.

**Bot gửi sai hoặc runaway cost:** pause global/shop/conversation theo phạm vi, fence pending jobs bằng config generation, giữ inbox human-only theo policy; kiểm các message đã accepted/unknown, không gửi lại hàng loạt; rollback config/prompt revision đã eval và kiểm dữ liệu nguồn.

**Tồn kho/tiền lệch:** khóa các command bị ảnh hưởng, giữ reads có warning, reconcile từ source/command/movement; correction qua reversal/compensation có audit, không sửa số trên UI hay SQL ad-hoc chưa duyệt.

**Meta/provider outage:** hiển thị connection degraded, ngừng retries vượt budget, giữ queue có TTL/policy, không fallback provider chưa được phép dùng dữ liệu; resume kiểm lại policy/send eligibility hiện hành.

**Chunk/API mismatch:** rollback UI immutable release, giữ backend compatible; refresh guidance, kiểm stale tabs và request IDs. Không đổi public API schema để hết lỗi một frontend cũ mà phá frontend mới.

## 6. Backup, restore và dữ liệu riêng tư

Backend backup quan hệ, file blobs và cấu hình revision, mã hóa và phân quyền. Vector index có thể rebuild từ nguồn đã duyệt; trước rebuild phải apply deletion/retention tombstones để không hồi sinh PII. Tài liệu restore chỉ rõ thứ tự secrets → DB → blob → queue/job reconcile → index → API/UI smoke; không restore queue rồi gửi lại tin đã gửi.

Thực hiện restore drill trong môi trường cô lập, ghi thời điểm backup, recovered point, actual RPO/RTO, job duplicates prevented, row totals và người kiểm chứng. UI không thể chứng minh RPO/RTO. Legal hold/retention và thời gian backup còn giữ dữ liệu do policy được duyệt quyết định; không hứa purge ngay mọi backup.

## 7. Checklist G5 (mọi mục phải có evidence/owner)

Contract và schema đã triển khai thật; auth/tenant/object/field tests pass; stock/finance concurrency và reconciliation pass; Meta app review/permissions/API version/policy đã xác minh; provider data handling/quota/rotation được duyệt; không secret/mock trong bundle; responsive/a11y/performance đã đo; dependencies/security review không còn critical; backup restore drill; rollback app/config có rehearsal; audit và incident owner; SOP nhập liệu và kế toán quản trị được chủ shop chấp nhận; user acceptance và release approval ghi thời gian/commit.

G5 không cho blanket “all done”. Evidence thiếu được đánh dấu blocker; UI vẫn có thể bàn giao riêng dưới nhãn UI_MOCK_VERIFIED hoặc INTEGRATED_STAGING.
