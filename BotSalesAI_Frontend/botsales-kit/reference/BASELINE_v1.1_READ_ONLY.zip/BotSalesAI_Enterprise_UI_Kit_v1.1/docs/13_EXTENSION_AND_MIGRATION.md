# 13 — Mở rộng không phá nền tảng

Phiên bản 1.0 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Thêm một module

Định nghĩa business owner và bounded responsibility trước. Viết ADR khi thay dependency graph. Thêm permission/catalog và backend checks → hợp đồng API + schema + error model → fixtures/scenarios → route manifest → module API/model/UI public exports → app composition → tests/bundle budgets/observability → docs/traceability. Giữ backwards compatibility; không thêm dữ liệu vào `shared` chỉ để tránh thiết kế boundary.

Một extension hoàn thành phải có migration/rollout/rollback và ảnh hưởng tới authorization/cache/export. Feature flag quyết định khả năng hiển thị/rollout nhưng không thay authorization. Server không hỗ trợ capability thì UI read-only/not-supported, không đoán từ provider/model name.

## 2. Thêm provider AI

Implement adapter phía server theo capability contract, secret storage, timeout/rate-limit/error taxonomy, streaming normalization và usage reporting. Chạy capability test và eval chuẩn, xác nhận data region/retention và fallback policy. UI chỉ thêm metadata/config schema đã cho phép, không nhúng SDK/key trực tiếp vào bundle. OpenAI-compatible endpoint không được coi hỗ trợ đủ tool calling/structured output/embeddings; unknown phải disable tính năng tương ứng.

Provider change có thể thay token accounting hoặc embedding dimension. Không trộn vectors khác model/revision/index namespace. Re-index vào collection mới, eval, chuyển pointer atomically, giữ rollback trong retention được duyệt. Không tự fine-tune từ toàn bộ hội thoại.

## 3. Thêm kênh bán hàng

Chuẩn hóa channel connection, identities, message types, policy/sendEligibility, dedupe identity, webhook provenance và media handling. Customer có thể có nhiều channel identities nhưng việc merge phải có căn cứ; không tự đồng nhất hai người chỉ vì cùng tên hiển thị. Adapter mới phải qua app review/policy cụ thể của nền tảng, không sao chép policy Facebook sang Zalo/WhatsApp.

UI inbox giữ core conversation/command semantics; composer render theo capabilities. Không giả mọi kênh hỗ trợ buttons, attachments hoặc window như nhau. Không để logic platform rải trong 12 modules.

## 4. Từ một kho sang nhiều kho

Baseline đã có warehouseId, stock snapshot và movement scoped. Khi mở nhiều kho: thêm quyền/phạm vi kho, transfer với source/destination, trạng thái in-transit, atomicity/compensation, chọn kho fulfillment và cost attribution. Có ADR cho partial fulfillment/backorder. Không cộng available toàn kho thành lời hứa giao được từ một kho. UI phải phân biệt hàng đang chuyển, giữ hàng, hỏng và có thể bán.

## 5. Từ một tiền tệ sang nhiều tiền tệ

V1 mỗi shop một base currency. Mở đa tiền tệ cần Money gốc + FX rate/source/timestamp + base amount + rounding policy + realized/unrealized rules đã được chuyên gia nghiệp vụ duyệt. Báo cáo tách currency khi chưa có conversion hợp lệ; không cộng 100 USD và 100 VND thành 200. Contract đổi additive, data migration kiểm lịch sử, không đổi currency trên đơn cũ.

## 6. Khi nào tách microservice/microfrontend?

Chỉ xem xét khi có evidence: đội độc lập cần release cadence khác, workload cần scale biệt lập, failure/security boundary rõ, và chi phí deployment/observability/contracts đã được chấp nhận. Số file lớn hoặc từ “enterprise” không đủ lý do. Bắt đầu modular application và boundary kiểm bằng CI; worker có thể scale riêng phía backend mà không buộc UI microfrontend.

Nếu tách UI: một owner cho auth/session/design tokens, không nhân bản React/query caches tùy tiện; versioned public contract, compatibility matrix, integration tests liên-app, loading/error isolation và coordinated rollback. Lập migration strangler theo route/capability; không big-bang rewrite.

## 7. Migration repo cũ

Lập inventory imports/API/types/styles/state stores thực tế. Chọn một module ít rủi ro để tạo adapter cũ→mới và test golden behavior. Giữ endpoint/user flows, dùng feature flag staged; migrate shared primitives có compatibility wrappers; deprecated exports có owner và deadline; xóa sau xác minh không còn consumer.

Không tạo song song hai folder `components/common/shared` không ranh giới, hai client API hoặc hai global stores cho cùng dữ liệu. Ghi nợ kỹ thuật đã biết trong risk register với task kiểm chứng, không “dọn sạch tất cả” trong PR tính năng.
