# 17 — Ma trận truy vết yêu cầu → route → API → kiểm thử

Phiên bản 1.0 • Sinh từ route-manifest, operation-index và acceptance-scenarios. Test trong bảng là đặc tả chưa chạy trên sản phẩm.

| Requirement | Màn hình/route | Module | Operations | Scenario trọng tâm |
|---|---|---|---|---|
| FR-001 | R01 / Đăng nhập | workspace | getCsrfToken, login | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-002 | R02 / Chọn cửa hàng | workspace | listShops, getSession | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-003 | R03 / Thiết lập cửa hàng | workspace | getSession, createShop | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-004 | R04 / Tổng quan | dashboard | getDashboard, getShop, pauseBot | SC-053 |
| FR-005 | R05 / Hộp thư | inbox | listConversations, getInboxMetadata | SC-033, SC-034, SC-035, SC-036, SC-037 |
| FR-006 | R06 / Chi tiết hội thoại | inbox | getConversation, listMessages, getCommand, getInboxMetadata, sendMessage, addInternalNote, takeoverConversation, releaseConversation, assignConversation, resolveConversation, createFeedback | SC-033, SC-034, SC-035, SC-036, SC-037 |
| FR-007 | R07 / Khách hàng | customers | listCustomers, createCustomer | SC-038 |
| FR-008 | R08 / Hồ sơ khách | customers | getCustomer, updateCustomer | SC-038 |
| FR-009 | R09 / Sản phẩm | catalog | listProducts, listCategories | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-010 | R10 / Thêm sản phẩm | catalog | listCategories, createProduct, uploadFile | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-011 | R11 / Chi tiết sản phẩm | catalog | getProduct, listCategories, getFile, updateProduct, archiveProduct, uploadFile | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-012 | R12 / Danh mục hàng | catalog | listCategories, getCategory, createCategory, updateCategory, archiveCategory | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-013 | R13 / Nhập dữ liệu | catalog | listJobs, getFile, uploadFile, createProductImport | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-014 | R14 / Kết quả nhập dữ liệu | catalog | getJob, commitProductImport | SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018 |
| FR-015 | R15 / Tồn kho | inventory | listStockSnapshots, getShop, createInventoryAdjustment | SC-019, SC-020, SC-021 |
| FR-016 | R16 / Lịch sử kho | inventory | listStockMovements | SC-019, SC-020, SC-021 |
| FR-017 | R17 / Đơn hàng | orders | listOrders | SC-022, SC-023, SC-024, SC-025, SC-026, SC-027 |
| FR-018 | R18 / Tạo đơn nháp | orders | listCustomers, listProducts, getShop, createOrder | SC-022, SC-023, SC-024, SC-025, SC-026, SC-027 |
| FR-019 | R19 / Chi tiết đơn hàng | orders | getOrder, getCommand, updateOrderDraft, quoteOrder, confirmOrder, fulfillOrder, cancelOrder, returnOrder, payOrder, refundOrder | SC-022, SC-023, SC-024, SC-025, SC-026, SC-027 |
| FR-020 | R20 / Thu/chi tổng quan | finance | getCashflow | SC-028, SC-029, SC-030, SC-031, SC-032 |
| FR-021 | R21 / Sổ thu/chi | finance | listFinanceEntries, getFinanceEntry, getCommand, createFinanceEntry, updateFinanceEntry, postFinanceEntry, reverseFinanceEntry | SC-028, SC-029, SC-030, SC-031, SC-032 |
| FR-022 | R22 / Lợi nhuận quản trị | finance | getProfitLoss | SC-028, SC-029, SC-030, SC-031, SC-032 |
| FR-023 | R23 / Nguồn kiến thức | knowledge | listKnowledge, getFile, createKnowledge, uploadFile | SC-039, SC-040, SC-041, SC-042 |
| FR-024 | R24 / Chi tiết kiến thức | knowledge | getKnowledge, listKnowledgeRevisions, getKnowledgeRevision, updateKnowledge, createKnowledgeRevision, submitKnowledgeReview, publishKnowledge, retireKnowledge, restoreKnowledgeRevision | SC-039, SC-040, SC-041, SC-042 |
| FR-025 | R25 / Đánh giá và phản hồi | knowledge | listFeedback, reviewFeedback | SC-039, SC-040, SC-041, SC-042 |
| FR-026 | R26 / Cấu hình bot | bot | getBotConfig, listAIConnections, listKnowledge, listBotRevisions, getBotRevision, updateBotDraft, publishBotConfig, pauseBot, restoreBotRevision | SC-043, SC-044, SC-045, SC-046 |
| FR-027 | R27 / Thử bot an toàn | bot | getBotConfig, runPlayground | SC-043, SC-044, SC-045, SC-046 |
| FR-028 | R28 / Kiểm thử chất lượng AI | bot | listEvaluations, getEvaluation, getJob, createEvaluation | SC-043, SC-044, SC-045, SC-046 |
| FR-029 | R29 / Kết nối Facebook | integrations | listChannels, getChannel, getJob, beginChannelConnect, reconnectChannel, disconnectChannel, checkChannelHealth | SC-047, SC-048, SC-049, SC-050 |
| FR-030 | R30 / Nhà cung cấp AI | integrations | listAIConnections, getAIConnection, getProviderCatalog, getJob, createAIConnection, updateAIConnection, testAIConnection, deleteAIConnection | SC-047, SC-048, SC-049, SC-050 |
| FR-031 | R31 / Báo cáo và xuất dữ liệu | reports | getReportSummary, listJobs, createExport | SC-051, SC-052 |
| FR-032 | R32 / Nhân sự và quyền | workspace | listMembers, getMember, inviteMember, updateMemberRoles, revokeMembership | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-033 | R33 / Thiết lập cửa hàng | workspace | getShop, updateShop | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-034 | R34 / Nhật ký kiểm toán | workspace | listAuditEvents | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-035 | R35 / Quyền riêng tư và lưu trữ | workspace | getPrivacyPolicy, listPrivacyRequests, getCommand, updatePrivacyPolicy, createPrivacyRequest, stepUp, approvePrivacyRequest | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |
| FR-036 | R36 / Theo dõi công việc nền | workspace | getJob | SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055 |

## Bất biến liên module

Auth/tenant, decimal, idempotency, versioning, source integrity, secret/privacy, accessibility và mock/real separation áp dụng cho mọi route/operation liên quan, không chỉ module mang tên scenario. Mỗi PR phải ghi requirement và scenario IDs, evidence path và trạng thái PASS/FAIL/NOT_RUN.


## Bổ sung truy vết governance 1.1

CODE-001..024 được định nghĩa tại docs/18; DARK-001..012 tại docs/19.
24 case QA và 16 gate QG có liên kết hai chiều trong governance/acceptance-scenarios.json
và governance/quality-gates.json. Bộ validator kiểm ID, nguồn, mapping và trạng thái
chưa chạy sản phẩm. Đây là tập bổ sung, không đổi 55 case SC nghiệp vụ ở trên.
