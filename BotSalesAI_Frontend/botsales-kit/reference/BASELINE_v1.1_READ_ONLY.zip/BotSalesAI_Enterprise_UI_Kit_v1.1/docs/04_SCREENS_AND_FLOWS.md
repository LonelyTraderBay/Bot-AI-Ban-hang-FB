# 04 — Màn hình, bố cục, hành vi và luồng người dùng

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất

## 1. Quy tắc chung

Danh mục route chuẩn nằm trong `contracts/route-manifest.json`. Mỗi route bên dưới có mục đích, dữ liệu, actions, lỗi và kiểm thử. Quyền ở đây chỉ là điều kiện UI; backend kiểm operation + resource + field. `getSession/getShop`, cleanup scope, error boundary và telemetry áp dụng chung. Detail route private không tải data trước authz bootstrap.

Loading dùng skeleton theo cấu trúc; empty có lý do + CTA đúng quyền; error có requestId/retry phù hợp; forbidden gỡ data nhạy; offline/stale có asOf; conflict giữ bản nháp. Pending Command khác complete. Actions không đủ quyền ẩn; actions đúng quyền nhưng chưa đủ capability/state thì disabled kèm lý do. Cấm success toast giả.

Các route `new`/`review` phải dùng matching được xếp hạng hoặc ưu tiên route tĩnh trước dynamic `:id`. URL query được schema validate, canonicalize và reset cursor khi đổi filters. Chi tiết state và giá trị mặc định xem docs/03 và docs/09.

## 2. Bản đồ điều hướng

Sidebar gồm: Tổng quan; Bán hàng (Hộp thư, Khách hàng, Đơn hàng); Hàng hóa (Sản phẩm, Danh mục, Tồn kho, Nhập dữ liệu); AI (Nguồn kiến thức, Phản hồi, Cấu hình, Thử bot, Evals); Tài chính (Thu/chi, Sổ quỹ, Lợi nhuận, Báo cáo); Cài đặt (Facebook, AI providers, Nhân sự, Shop, Audit, Privacy). Chỉ hiện mục đủ permission. Trang tạo/chi tiết là child route, không thành hàng sidebar riêng. Có breadcrumbs/back giữ filter; navigation không phụ thuộc tên provider hoặc ID cứng.

| ID | Đường dẫn | Màn hình | Module | Permission đọc |
|---|---|---|---|---|
| R01 | `/login` | Đăng nhập | workspace | `session/public theo flow` |
| R02 | `/workspaces` | Chọn cửa hàng | workspace | `session/public theo flow` |
| R03 | `/onboarding` | Thiết lập cửa hàng | workspace | `session/public theo flow` |
| R04 | `/s/:shopId/overview` | Tổng quan | dashboard | `dashboard.read` |
| R05 | `/s/:shopId/inbox` | Hộp thư | inbox | `conversations.read` |
| R06 | `/s/:shopId/inbox/:conversationId` | Chi tiết hội thoại | inbox | `conversations.read` |
| R07 | `/s/:shopId/customers` | Khách hàng | customers | `customers.read` |
| R08 | `/s/:shopId/customers/:customerId` | Hồ sơ khách | customers | `customers.read` |
| R09 | `/s/:shopId/products` | Sản phẩm | catalog | `catalog.read` |
| R10 | `/s/:shopId/products/new` | Thêm sản phẩm | catalog | `catalog.write` |
| R11 | `/s/:shopId/products/:productId` | Chi tiết sản phẩm | catalog | `catalog.read` |
| R12 | `/s/:shopId/categories` | Danh mục hàng | catalog | `catalog.read` |
| R13 | `/s/:shopId/imports` | Nhập dữ liệu | catalog | `catalog.import` |
| R14 | `/s/:shopId/imports/:jobId` | Kết quả nhập dữ liệu | catalog | `catalog.import` |
| R15 | `/s/:shopId/inventory` | Tồn kho | inventory | `inventory.read` |
| R16 | `/s/:shopId/inventory/movements` | Lịch sử kho | inventory | `inventory.read` |
| R17 | `/s/:shopId/orders` | Đơn hàng | orders | `orders.read` |
| R18 | `/s/:shopId/orders/new` | Tạo đơn nháp | orders | `orders.write` |
| R19 | `/s/:shopId/orders/:orderId` | Chi tiết đơn hàng | orders | `orders.read` |
| R20 | `/s/:shopId/finance` | Thu/chi tổng quan | finance | `finance.read` |
| R21 | `/s/:shopId/finance/entries` | Sổ thu/chi | finance | `finance.read` |
| R22 | `/s/:shopId/finance/profit-loss` | Lợi nhuận quản trị | finance | `finance.read` |
| R23 | `/s/:shopId/knowledge` | Nguồn kiến thức | knowledge | `knowledge.read` |
| R24 | `/s/:shopId/knowledge/:knowledgeId` | Chi tiết kiến thức | knowledge | `knowledge.read` |
| R25 | `/s/:shopId/knowledge/review` | Đánh giá và phản hồi | knowledge | `knowledge.read` |
| R26 | `/s/:shopId/bot` | Cấu hình bot | bot | `bot.read` |
| R27 | `/s/:shopId/bot/playground` | Thử bot an toàn | bot | `bot.configure` |
| R28 | `/s/:shopId/bot/evaluations` | Kiểm thử chất lượng AI | bot | `bot.read` |
| R29 | `/s/:shopId/integrations/channels` | Kết nối Facebook | integrations | `integrations.read` |
| R30 | `/s/:shopId/integrations/ai` | Nhà cung cấp AI | integrations | `integrations.read` |
| R31 | `/s/:shopId/reports` | Báo cáo và xuất dữ liệu | reports | `reports.read` |
| R32 | `/s/:shopId/settings/team` | Nhân sự và quyền | workspace | `members.manage` |
| R33 | `/s/:shopId/settings/shop` | Thiết lập cửa hàng | workspace | `shop.manage` |
| R34 | `/s/:shopId/settings/audit` | Nhật ký kiểm toán | workspace | `audit.read` |
| R35 | `/s/:shopId/settings/privacy` | Quyền riêng tư và lưu trữ | workspace | `privacy.manage` |
| R36 | `/s/:shopId/jobs/:jobId` | Theo dõi công việc nền | workspace | `jobs.read` |

## 3. Đặc tả từng màn hình

### R01 — Đăng nhập (FR-001)

**Route:** `/login`. **Owner:** `workspace`. **Quyền đọc:** `public/session theo flow`.

Xác thực vào ứng dụng quản trị; không nhầm với đăng nhập Facebook Page.

**Nội dung và dữ liệu:** Email, mật khẩu, submit; nhãn UI_MOCK/DEMO khi mô phỏng.

**Hành vi:** Validate field; login success lấy session rồi tới shop/returnTo được allowlist. Không persist mật khẩu.

**Trường hợp phải xử lý:** Sai thông tin; rate limit; expired pre-session CSRF; network error; không tiết lộ email tồn tại.

**Read operations:** `getCsrfToken`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Đăng nhập | `login` | `session + quyền nguồn/policy` |

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R02 — Chọn cửa hàng (FR-002)

**Route:** `/workspaces`. **Owner:** `workspace`. **Quyền đọc:** `public/session theo flow`.

Chọn shop người dùng có membership hợp lệ.

**Nội dung và dữ liệu:** Shop name, role summary, trạng thái; không hiện dữ liệu doanh thu của shop khác.

**Hành vi:** Đổi shop mount scope mới; có guard bản nháp chưa lưu; cache và stream cũ bị dọn.

**Trường hợp phải xử lý:** Không shop; membership revoked; late response của shop trước; không tự fallback sang shop không có quyền.

**Read operations:** `listShops`, `getSession`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R03 — Thiết lập cửa hàng (FR-003)

**Route:** `/onboarding`. **Owner:** `workspace`. **Quyền đọc:** `public/session theo flow`.

Tạo thông tin shop ban đầu trong môi trường được cấp quyền.

**Nội dung và dữ liệu:** Tên, currency, timezone, locale; xác nhận base currency trước tạo.

**Hành vi:** Wizard có thể quay lại giữ input memory; chỉ complete sau backend tạo default warehouse/membership.

**Trường hợp phải xử lý:** Tên trống, mã currency sai, timezone không hợp lệ, submit lặp; create permission/policy server mới quyết định.

**Read operations:** `getSession`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Tạo cửa hàng | `createShop` | `session + quyền nguồn/policy` |

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R04 — Tổng quan (FR-004)

**Route:** `/s/:shopId/overview`. **Owner:** `dashboard`. **Quyền đọc:** `dashboard.read`.

Thấy ngay việc cần xử lý và dữ liệu nào đang chưa đầy đủ.

**Nội dung và dữ liệu:** Hội thoại chờ, đơn chờ, hàng sắp hết, bot health; revenue/cash chỉ theo finance permission; asOf.

**Hành vi:** KPI mở trang tương ứng với bộ lọc; pause có xác nhận/reason và command status.

**Trường hợp phải xử lý:** Null tiền hiển thị bị hạn chế/chưa có, không 0; partial dashboard và stale; widget lỗi không làm trắng toàn trang.

**Read operations:** `getDashboard`, `getShop`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Tạm dừng bot | `pauseBot` | `bot.publish` |

**Acceptance:** SC-053, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R05 — Hộp thư (FR-005)

**Route:** `/s/:shopId/inbox`. **Owner:** `inbox`. **Quyền đọc:** `conversations.read`.

Tìm hội thoại cần phản hồi hoặc được phân công.

**Nội dung và dữ liệu:** Search, status, mode bot/human, channel/assignee filter được backend hỗ trợ; preview và unread.

**Hành vi:** Chọn row tới R06; URL giữ filter/cursor; bàn phím tới từng hội thoại, không đọc raw PII qua toast.

**Trường hợp phải xử lý:** Không kết quả khác inbox trống; event mới không giật vị trí; slow response không đổi shop đang xem.

**Read operations:** `listConversations`, `getInboxMetadata`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-033, SC-034, SC-035, SC-036, SC-037, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R06 — Chi tiết hội thoại (FR-006)

**Route:** `/s/:shopId/inbox/:conversationId`. **Owner:** `inbox`. **Quyền đọc:** `conversations.read`.

Hỗ trợ khách và kiểm soát bot/human rõ ràng.

**Nội dung và dữ liệu:** Message timeline, delivery status, composer, sendEligibility, mode/assignee, source evidence, customer/order panel theo quyền.

**Hành vi:** Lịch sử phân trang giữ scroll; draft reply không persist; Enter gửi chỉ theo setting, Shift+Enter xuống dòng; internal note có nhãn nổi bật.

**Trường hợp phải xử lý:** Policy unknown/blocked disable gửi; takeover race; send timeout unknown; duplicate/out-of-order event; 403 gỡ messages; không tự gửi lại.

**Read operations:** `getConversation`, `listMessages`, `getCommand`, `getInboxMetadata`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Gửi tin | `sendMessage` | `conversations.reply` |
| Ghi chú nội bộ | `addInternalNote` | `conversations.reply` |
| Tiếp quản | `takeoverConversation` | `conversations.assign` |
| Trả lại bot | `releaseConversation` | `conversations.assign` |
| Phân công | `assignConversation` | `conversations.assign` |
| Đánh dấu xong | `resolveConversation` | `conversations.assign` |
| Đánh giá câu trả lời | `createFeedback` | `conversations.read` |

**Acceptance:** SC-033, SC-034, SC-035, SC-036, SC-037, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R07 — Khách hàng (FR-007)

**Route:** `/s/:shopId/customers`. **Owner:** `customers`. **Quyền đọc:** `customers.read`.

Danh sách khách theo shop, không phải tài khoản nhân viên.

**Nội dung và dữ liệu:** Tên, thông tin liên hệ masked, external identity khi được phép; search/cursor.

**Hành vi:** Tạo khách qua form validate; chọn vào R08; không gộp khách tự động theo tên.

**Trường hợp phải xử lý:** Khách trùng số điện thoại chỉ cảnh báo/policy server; masked contact; special characters không XSS.

**Read operations:** `listCustomers`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Thêm khách | `createCustomer` | `customers.write` |

**Acceptance:** SC-038, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R08 — Hồ sơ khách (FR-008)

**Route:** `/s/:shopId/customers/:customerId`. **Owner:** `customers`. **Quyền đọc:** `customers.read`.

Xem và sửa dữ liệu chăm sóc khách được cấp quyền.

**Nội dung và dữ liệu:** Tên, phone/email, notes, trường bị che; links tới orders/inbox scoped filter thay vì tải chéo tự do.

**Hành vi:** Edit chờ server + ETag; notes plain/sanitized text; đổi customer reset form.

**Trường hợp phải xử lý:** 412 giữ draft và cho tải phiên bản mới; contact null không bị ghi đè thành chuỗi rỗng; permission change.

**Read operations:** `getCustomer`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu hồ sơ | `updateCustomer` | `customers.write` |

**Acceptance:** SC-038, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R09 — Sản phẩm (FR-009)

**Route:** `/s/:shopId/products`. **Owner:** `catalog`. **Quyền đọc:** `catalog.read`.

Quản lý danh mục sản phẩm với search/filter thật toàn dataset.

**Nội dung và dữ liệu:** Tên, SKU/biến thể summary, category, status, price range theo quyền; search/category/status/sort.

**Hành vi:** Nút thêm điều hướng R10; row tới R11; mọi phân trang ở server; không tính tổng tồn từ product DTO.

**Trường hợp phải xử lý:** 0/1/100k records; long Vietnamese names; product archived; invalid cursor/filter; không fetch tất cả rồi lọc browser.

**Read operations:** `listProducts`, `listCategories`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R10 — Thêm sản phẩm (FR-010)

**Route:** `/s/:shopId/products/new`. **Owner:** `catalog`. **Quyền đọc:** `catalog.write`.

Tạo Product và tối thiểu một Variant.

**Nội dung và dữ liệu:** Tên 1–160 ký tự, mô tả, category, status draft/active; mỗi variant có SKU, options, name, currency/price, active; ảnh.

**Hành vi:** Client validation và server errors theo field; submit idempotent; thành công tới detail. Giá decimal string, không nhập stock ở form này.

**Trường hợp phải xử lý:** SKU trùng scoped; variant options trùng; upload quarantined; currency khác shop; mạng đứt không reset form.

**Read operations:** `listCategories`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Tạo sản phẩm | `createProduct` | `catalog.write` |
| Tải ảnh | `uploadFile` | `session + quyền nguồn/policy` |

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R11 — Chi tiết sản phẩm (FR-011)

**Route:** `/s/:shopId/products/:productId`. **Owner:** `catalog`. **Quyền đọc:** `catalog.read`.

Sửa danh mục mà không phá lịch sử đơn/kho.

**Nội dung và dữ liệu:** Overview, variants/prices/images, version và updatedAt; links kho theo variant chỉ khi có quyền.

**Hành vi:** Edit dùng ETag; archive confirm nêu tác động; variants đã có order không xóa lịch sử; image chỉ dùng ready file.

**Trường hợp phải xử lý:** 412; SKU conflict; product archived; unauthorized field; thay giá không đổi giá snapshot order cũ.

**Read operations:** `getProduct`, `listCategories`, `getFile`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu sản phẩm | `updateProduct` | `catalog.write` |
| Lưu trữ sản phẩm | `archiveProduct` | `catalog.write` |
| Tải ảnh | `uploadFile` | `session + quyền nguồn/policy` |

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R12 — Danh mục hàng (FR-012)

**Route:** `/s/:shopId/categories`. **Owner:** `catalog`. **Quyền đọc:** `catalog.read`.

Sắp xếp sản phẩm theo nhóm mà không tạo cây vô hạn.

**Nội dung và dữ liệu:** Tên, parent, active, phiên bản; table hoặc tree bounded.

**Hành vi:** Create/edit parent selection chống cycle server; archive hiển thị tác động với sản phẩm đang tham chiếu.

**Trường hợp phải xử lý:** Parent khác shop; cycle; danh mục đang dùng; 412; không xóa hàng hóa theo cascade ở UI.

**Read operations:** `listCategories`, `getCategory`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Thêm danh mục | `createCategory` | `catalog.write` |
| Sửa danh mục | `updateCategory` | `catalog.write` |
| Lưu trữ danh mục | `archiveCategory` | `catalog.write` |

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R13 — Nhập dữ liệu (FR-013)

**Route:** `/s/:shopId/imports`. **Owner:** `catalog`. **Quyền đọc:** `catalog.import`.

Import catalog có kiểm tra trước khi ghi, không import âm thầm vào kho.

**Nội dung và dữ liệu:** File CSV/XLSX không macro, purpose, mapping sku/name/description/category/price/currency/variantName, duplicate strategy.

**Hành vi:** Upload→validate→preview; nút commit ở R14. File quá hạn/quarantine không được parse. Giới hạn do backend trả và tối đa baseline.

**Trường hợp phải xử lý:** Sai encoding/cột/currency; formula/external link; file size/rows over-limit; không đẩy toàn file parsed vào DOM.

**Read operations:** `listJobs`, `getFile`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Tải file | `uploadFile` | `session + quyền nguồn/policy` |
| Kiểm tra file | `createProductImport` | `catalog.import` |

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R14 — Kết quả nhập dữ liệu (FR-014)

**Route:** `/s/:shopId/imports/:jobId`. **Owner:** `catalog`. **Quyền đọc:** `catalog.import`.

Cho người dùng quyết định rõ trước commit kết quả dry-run.

**Nội dung và dữ liệu:** Số dòng hợp lệ/lỗi, paginated errors/export lỗi, validationToken, strategy, progress và thành công một phần.

**Hành vi:** Confirm đúng validation snapshot; key cùng payload; job chạy backend, đóng tab không hủy lệnh đã tiếp nhận.

**Trường hợp phải xử lý:** File/dữ liệu đổi sau preview; partial commit; retry chỉ failed rows với intent mới có preview; không ghi lại dòng đã thành công.

**Read operations:** `getJob`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Ghi các dòng hợp lệ | `commitProductImport` | `catalog.import` |

**Acceptance:** SC-012, SC-013, SC-014, SC-015, SC-016, SC-017, SC-018, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R15 — Tồn kho (FR-015)

**Route:** `/s/:shopId/inventory`. **Owner:** `inventory`. **Quyền đọc:** `inventory.read`.

Thấy onHand, reserved và available theo SKU/warehouse.

**Nội dung và dữ liệu:** SKU, warehouse, onHand, reserved, available, low-stock, asOf; unitCost chỉ khi server cho phép.

**Hành vi:** Điều chỉnh drawer delta + reason + expectedVersion + cost cần thiết; chờ command rồi refetch; v1 default warehouse.

**Trường hợp phải xử lý:** Oversell/negative available, version conflict, thiếu cost, unknown command; không optimistic và không PUT absolute stock.

**Read operations:** `listStockSnapshots`, `getShop`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Điều chỉnh tồn | `createInventoryAdjustment` | `inventory.adjust` |

**Acceptance:** SC-019, SC-020, SC-021, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R16 — Lịch sử kho (FR-016)

**Route:** `/s/:shopId/inventory/movements`. **Owner:** `inventory`. **Quyền đọc:** `inventory.read`.

Truy nguyên mỗi thay đổi kho đến nguồn nghiệp vụ.

**Nội dung và dữ liệu:** Thời gian, SKU, warehouse, onHand delta, reserved delta, kind, actor, reason, source link.

**Hành vi:** Read-only, cursor/search/filter; links order chỉ mở khi có quyền; chỉnh sai bằng adjustment bù, không edit movement.

**Trường hợp phải xử lý:** Event lặp không tạo row lặp; source archived vẫn có history; timezone và sort stable.

**Read operations:** `listStockMovements`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-019, SC-020, SC-021, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R17 — Đơn hàng (FR-017)

**Route:** `/s/:shopId/orders`. **Owner:** `orders`. **Quyền đọc:** `orders.read`.

Theo dõi đơn mà không trộn trạng thái giao hàng/thanh toán.

**Nội dung và dữ liệu:** Order/customer refs, createdAt, order/fulfillment/payment states riêng, tổng tiền nếu được phép.

**Hành vi:** Filter qua URL, tạo đơn tới R18, row tới R19; bulk mutation chưa hỗ trợ phải ẩn.

**Trường hợp phải xử lý:** Enum mới fallback read-only; stale paid badge; redacted total; phân trang không tự cộng thành doanh thu shop.

**Read operations:** `listOrders`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-022, SC-023, SC-024, SC-025, SC-026, SC-027, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R18 — Tạo đơn nháp (FR-018)

**Route:** `/s/:shopId/orders/new`. **Owner:** `orders`. **Quyền đọc:** `orders.write`.

Tạo draft theo nhu cầu khách, chưa giữ hàng/chưa ghi nhận doanh thu.

**Nội dung và dữ liệu:** Customer, optional conversation ref, variant selection, quantities integer, warehouse mặc định, notes.

**Hành vi:** Product picker remote search; preview giá có nhãn chưa chốt; request gửi IDs/qty, server trả authoritative snapshots.

**Trường hợp phải xử lý:** Variant archived/out of stock; customer/variant khác shop; trùng submit; thiếu quyền xem khách; intent seeded từ inbox vẫn revalidate.

**Read operations:** `listCustomers`, `listProducts`, `getShop`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Tạo đơn nháp | `createOrder` | `orders.write` |

**Acceptance:** SC-022, SC-023, SC-024, SC-025, SC-026, SC-027, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R19 — Chi tiết đơn hàng (FR-019)

**Route:** `/s/:shopId/orders/:orderId`. **Owner:** `orders`. **Quyền đọc:** `orders.read`.

Vận hành workflow dựa trên allowedActions và quyền, không sửa status tùy ý.

**Nội dung và dữ liệu:** Snapshot dòng hàng, totals, ba state, source customer/conversation, version, các action server cho phép.

**Hành vi:** Quote→confirm có giá và expiry; fulfill/pay/return/refund/cancel có impact summary/reason và pending command. Payment/refund v1 là ghi nhận thủ công, không tự chuyển tiền.

**Trường hợp phải xử lý:** Chiếc cuối bị người khác giữ; price changed/quote expired; double fulfill/refund; full-return restock lỗi; unknown command phải reconcile trước intent mới.

**Read operations:** `getOrder`, `getCommand`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu đơn nháp | `updateOrderDraft` | `orders.write` |
| Lấy báo giá | `quoteOrder` | `orders.write` |
| Xác nhận giữ hàng | `confirmOrder` | `orders.confirm` |
| Xác nhận giao hàng | `fulfillOrder` | `orders.fulfill` |
| Hủy đơn | `cancelOrder` | `orders.write` |
| Nhận hàng trả | `returnOrder` | `orders.return` |
| Ghi nhận đã thu tiền | `payOrder` | `finance.post` |
| Ghi nhận hoàn tiền | `refundOrder` | `finance.refund` |

**Acceptance:** SC-022, SC-023, SC-024, SC-025, SC-026, SC-027, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R20 — Thu/chi tổng quan (FR-020)

**Route:** `/s/:shopId/finance`. **Owner:** `finance`. **Quyền đọc:** `finance.read`.

Phân biệt tiền vào/ra trong kỳ với lợi nhuận.

**Nội dung và dữ liệu:** From/to/timezone, receipts, disbursements, netCashMovement, asOf/warnings.

**Hành vi:** Bộ lọc kỳ dùng [from,to); drilldown sang entries với context; currency shop duy nhất.

**Trường hợp phải xử lý:** Negative cashflow không tự gọi lỗ; incomplete period; timezone boundary; zero có thật khác null.

**Read operations:** `getCashflow`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-028, SC-029, SC-030, SC-031, SC-032, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R21 — Sổ thu/chi (FR-021)

**Route:** `/s/:shopId/finance/entries`. **Owner:** `finance`. **Quyền đọc:** `finance.read`.

Theo dõi phiếu có phân loại và nguồn, không sửa sổ đã ghi.

**Nội dung và dữ liệu:** Kind receipt/disbursement, classification, amount/currency, occurredAt, description, sourceRef, status, reversal link.

**Hành vi:** Draft edit ETag; post/reverse explicit confirmation; capital/loan/inventory_purchase không tự tính vào operating expense.

**Trường hợp phải xử lý:** SourceRef trùng đơn; tiền âm/0 không hợp lệ cho phiếu; posted không edit; double post; reversal có lý do và audit.

**Read operations:** `listFinanceEntries`, `getFinanceEntry`, `getCommand`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Thêm phiếu nháp | `createFinanceEntry` | `finance.post` |
| Sửa phiếu nháp | `updateFinanceEntry` | `finance.post` |
| Ghi sổ | `postFinanceEntry` | `finance.post` |
| Đảo phiếu đã ghi | `reverseFinanceEntry` | `finance.post` |

**Acceptance:** SC-028, SC-029, SC-030, SC-031, SC-032, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R22 — Lợi nhuận quản trị (FR-022)

**Route:** `/s/:shopId/finance/profit-loss`. **Owner:** `finance`. **Quyền đọc:** `finance.read`.

Trình bày lãi/lỗ quản trị có nguồn và mức đầy đủ dữ liệu.

**Nội dung và dữ liệu:** Gross/net sales, discounts/returns, COGS, gross profit, shipping/fees/AI/opex, operating profit, policyVersion/asOf.

**Hành vi:** Kỳ/timezone server; null/unknown hiện chưa xác định; provisional badge và drilldown; không recompute từ list entries trên client.

**Trường hợp phải xử lý:** Thiếu unit cost; hoàn hàng khác hoàn tiền; invoice AI chưa đối soát; không gọi báo cáo là tuân thủ thuế quốc gia.

**Read operations:** `getProfitLoss`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-028, SC-029, SC-030, SC-031, SC-032, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R23 — Nguồn kiến thức (FR-023)

**Route:** `/s/:shopId/knowledge`. **Owner:** `knowledge`. **Quyền đọc:** `knowledge.read`.

Tách tri thức đã duyệt với file đang xử lý.

**Nội dung và dữ liệu:** Tên, sourceKind, status, revision, publishedAt, warnings; search/status filter.

**Hành vi:** Manual source hoặc file ready; tạo draft; trạng thái processing không có nghĩa đã đưa vào bot.

**Trường hợp phải xử lý:** Duplicate/content hash; parse failed/quarantine; dữ liệu PII; published vs indexed hiển thị khác nhau.

**Read operations:** `listKnowledge`, `getFile`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Thêm nguồn | `createKnowledge` | `knowledge.write` |
| Tải tài liệu | `uploadFile` | `session + quyền nguồn/policy` |

**Acceptance:** SC-039, SC-040, SC-041, SC-042, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R24 — Chi tiết kiến thức (FR-024)

**Route:** `/s/:shopId/knowledge/:knowledgeId`. **Owner:** `knowledge`. **Quyền đọc:** `knowledge.read`.

Quản lý nội dung và vòng đời revision có review/evaluation.

**Nội dung và dữ liệu:** Content/source, draft/live IDs, history, approver, warnings và evaluation reference.

**Hành vi:** Published immutable; sửa tạo revision; restore tạo draft mới; publish cần eval đúng revision, không auto-live từ restore.

**Trường hợp phải xử lý:** Eval stale so với revision/model; người sửa không có publish permission; retired source còn được trích cần warning/cache cleanup.

**Read operations:** `getKnowledge`, `listKnowledgeRevisions`, `getKnowledgeRevision`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu bản nháp | `updateKnowledge` | `knowledge.write` |
| Tạo revision mới | `createKnowledgeRevision` | `knowledge.write` |
| Gửi kiểm tra và duyệt | `submitKnowledgeReview` | `knowledge.write` |
| Publish revision | `publishKnowledge` | `knowledge.publish` |
| Ngừng sử dụng | `retireKnowledge` | `knowledge.publish` |
| Khôi phục thành nháp | `restoreKnowledgeRevision` | `knowledge.write` |

**Acceptance:** SC-039, SC-040, SC-041, SC-042, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R25 — Đánh giá và phản hồi (FR-025)

**Route:** `/s/:shopId/knowledge/review`. **Owner:** `knowledge`. **Quyền đọc:** `knowledge.read`.

Biến phản hồi có ích thành đề xuất đã kiểm soát, không tự học mọi chat.

**Nội dung và dữ liệu:** Conversation/message reference, rating, correction, trạng thái; redaction và review reason.

**Hành vi:** Review yêu cầu correction đã loại PII; approve chỉ tạo candidate/reference cho KB draft, không publish tự động.

**Trường hợp phải xử lý:** Prompt injection trong correction; wrong shop evidence; concurrent reviewer; rejected có lý do; không lộ raw khách cho người thiếu quyền.

**Read operations:** `listFeedback`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Duyệt hoặc từ chối | `reviewFeedback` | `knowledge.write` |

**Acceptance:** SC-039, SC-040, SC-041, SC-042, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R26 — Cấu hình bot (FR-026)

**Route:** `/s/:shopId/bot`. **Owner:** `bot`. **Quyền đọc:** `bot.read`.

Tách cấu hình đang dùng với cấu hình đang soạn.

**Nội dung và dữ liệu:** Connection/model capability, instructions, knowledge revisions, limits/budget, human-confirm flag, live/draft/version.

**Hành vi:** Save draft dùng ETag; publish cần eval chính xác; pause explicit; restore không tự active, phải qua eval/publish.

**Trường hợp phải xử lý:** Provider unsupported/degraded, budget hết, stale eval, config conflict; UI không tự bypass human-confirmation.

**Read operations:** `getBotConfig`, `listAIConnections`, `listKnowledge`, `listBotRevisions`, `getBotRevision`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu cấu hình nháp | `updateBotDraft` | `bot.configure` |
| Publish cấu hình | `publishBotConfig` | `bot.publish` |
| Tạm dừng | `pauseBot` | `bot.publish` |
| Khôi phục revision thành nháp | `restoreBotRevision` | `bot.configure` |

**Acceptance:** SC-043, SC-044, SC-045, SC-046, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R27 — Thử bot an toàn (FR-027)

**Route:** `/s/:shopId/bot/playground`. **Owner:** `bot`. **Quyền đọc:** `bot.configure`.

Kiểm tra phản hồi mà không gửi khách thật.

**Nội dung và dữ liệu:** Input giả, model/config revision, answer, sources, warnings, tools summary, latency/usage/cost estimate.

**Hành vi:** Banner sandbox; không external send; nguồn live price/stock tool backend scope; reset history khỏi scope cũ.

**Trường hợp phải xử lý:** Missing sources; hallucination rubric; provider timeout; unsupported capability; usage unknown không 0; không nhập PII thật trong demo.

**Read operations:** `getBotConfig`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Chạy thử | `runPlayground` | `bot.configure` |

**Acceptance:** SC-043, SC-044, SC-045, SC-046, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R28 — Kiểm thử chất lượng AI (FR-028)

**Route:** `/s/:shopId/bot/evaluations`. **Owner:** `bot`. **Quyền đọc:** `bot.read`.

Theo dõi kết quả theo dataset/config revision để chặn hồi quy.

**Nội dung và dữ liệu:** Run ID, config/dataset versions, status, total/pass/critical failures, report link.

**Hành vi:** Chạy async, poll/stream progress; retry failed run tạo run mới giữ history; không dùng rate tự tin do LLM tạo.

**Trường hợp phải xử lý:** Evaluation pending/error; critical failure blocks publish; dataset thay đổi làm kết quả cũ không đủ; partial output không coi passed.

**Read operations:** `listEvaluations`, `getEvaluation`, `getJob`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Chạy evaluation | `createEvaluation` | `bot.configure` |

**Acceptance:** SC-043, SC-044, SC-045, SC-046, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R29 — Kết nối Facebook (FR-029)

**Route:** `/s/:shopId/integrations/channels`. **Owner:** `integrations`. **Quyền đọc:** `integrations.read`.

Theo dõi kênh chính thức và điều kiện gửi tin thực.

**Nội dung và dữ liệu:** Page name/id, trạng thái, lastWebhookAt, policyVersion/verification, capability/warnings.

**Hành vi:** OAuth do backend khởi tạo; chỉ dùng authorizationUrl validated, callback kiểm state server; không nhập Page token công khai vào UI settings.

**Trường hợp phải xử lý:** Chưa app review/quyền; token revoked; webhook stale; policy unknown; disconnect không xóa lịch sử khách/đơn.

**Read operations:** `listChannels`, `getChannel`, `getJob`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Kết nối Page | `beginChannelConnect` | `integrations.manage` |
| Kết nối lại | `reconnectChannel` | `integrations.manage` |
| Ngắt kết nối | `disconnectChannel` | `integrations.manage` |
| Kiểm tra sức khỏe | `checkChannelHealth` | `integrations.manage` |

**Acceptance:** SC-047, SC-048, SC-049, SC-050, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R30 — Nhà cung cấp AI (FR-030)

**Route:** `/s/:shopId/integrations/ai`. **Owner:** `integrations`. **Quyền đọc:** `integrations.read`.

Quản lý adapter/model/capability, không giả định mọi key dùng được.

**Nội dung và dữ liệu:** Provider/model catalog, capabilities, status, keyLast4, hasCredential, endpoint theo policy, lastCheckedAt.

**Hành vi:** Secret nhập một lần local; clear submit/unmount; test tính phí có xác nhận khi real; xoá connection đang được bot dùng bị server chặn hoặc cần đổi trước.

**Trường hợp phải xử lý:** Protocol mismatch; custom endpoint SSRF; expired key; quota; unknown model capability; response/log không chứa credential.

**Read operations:** `listAIConnections`, `getAIConnection`, `getProviderCatalog`, `getJob`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Thêm kết nối | `createAIConnection` | `integrations.manage` |
| Cập nhật/đổi key | `updateAIConnection` | `integrations.manage` |
| Kiểm tra kết nối | `testAIConnection` | `integrations.manage` |
| Gỡ kết nối | `deleteAIConnection` | `integrations.manage` |

**Acceptance:** SC-047, SC-048, SC-049, SC-050, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R31 — Báo cáo và xuất dữ liệu (FR-031)

**Route:** `/s/:shopId/reports`. **Owner:** `reports`. **Quyền đọc:** `reports.read`.

Chọn báo cáo theo quyền và xuất snapshot nhất quán.

**Nội dung và dữ liệu:** Report type inventory/orders/cashflow/profit_loss, kỳ/timezone/asOf, format CSV, trạng thái job.

**Hành vi:** Report view điều hướng route nghiệp vụ tương ứng; export cần cả reports.export và permission nguồn; tải qua URL authorized ngắn hạn.

**Trường hợp phải xử lý:** Mixed currency không cộng; signed URL hết hạn; export khác tenant; formula injection; partial/error job không phát file giả.

**Read operations:** `getReportSummary`, `listJobs`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Xuất báo cáo | `createExport` | `reports.export` |

**Acceptance:** SC-051, SC-052, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R32 — Nhân sự và quyền (FR-032)

**Route:** `/s/:shopId/settings/team`. **Owner:** `workspace`. **Quyền đọc:** `members.manage`.

Quản lý membership scoped theo shop.

**Nội dung và dữ liệu:** Email/user, roles, permission preview, status, permissionVersion; không trộn Customer.

**Hành vi:** Đổi role/revoke dùng ETag; server bảo vệ owner cuối; session/stream bị revoke ở tab người bị đổi.

**Trường hợp phải xử lý:** Mời trùng; role escalation; tự xóa owner cuối; stale form; không hiện token/email invitation secret trong log.

**Read operations:** `listMembers`, `getMember`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Mời nhân viên | `inviteMember` | `members.manage` |
| Đổi vai trò | `updateMemberRoles` | `members.manage` |
| Thu hồi quyền | `revokeMembership` | `members.manage` |

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R33 — Thiết lập cửa hàng (FR-033)

**Route:** `/s/:shopId/settings/shop`. **Owner:** `workspace`. **Quyền đọc:** `shop.manage`.

Sửa thông tin hoạt động không phá lịch sử tiền tệ.

**Nội dung và dữ liệu:** Tên, locale, timezone; currency/default warehouse/policyVersion read-only sau onboarding.

**Hành vi:** ETag và preview ảnh hưởng timezone tới báo cáo; base currency đổi là migration riêng, không inline select tùy tiện.

**Trường hợp phải xử lý:** Invalid timezone/locale; 412; đổi shop giữa lúc save; không fallback currency bằng browser locale.

**Read operations:** `getShop`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu thiết lập | `updateShop` | `shop.manage` |

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R34 — Nhật ký kiểm toán (FR-034)

**Route:** `/s/:shopId/settings/audit`. **Owner:** `workspace`. **Quyền đọc:** `audit.read`.

Truy nguyên hành động mà không lộ raw secret/PII.

**Nội dung và dữ liệu:** Actor, action, time, resource ref, requestId, sanitized summary; search/filter/cursor.

**Hành vi:** Read-only; links được permission guard; không cho sửa/xóa audit từ UI; giữ context filter.

**Trường hợp phải xử lý:** Long messages; deleted resource; unauthorized cross-shop; raw key/phone có trong summary phải bị scrub ở server.

**Read operations:** `listAuditEvents`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R35 — Quyền riêng tư và lưu trữ (FR-035)

**Route:** `/s/:shopId/settings/privacy`. **Owner:** `workspace`. **Quyền đọc:** `privacy.manage`.

Quản lý policy và request xóa/xuất theo phạm vi đã duyệt.

**Nội dung và dữ liệu:** Retention draft/active, jurisdiction note, customer request type/reason/status, legal_hold và job result.

**Hành vi:** Xác nhận scope, step-up khi approve; server xét legal hold/authority; deletion bao gồm index/cache/downstream theo policy.

**Trường hợp phải xử lý:** Retention chưa được legal approve; hold; job failed một phần; không hứa xóa toàn bộ backup ngay; token step-up không persist.

**Read operations:** `getPrivacyPolicy`, `listPrivacyRequests`, `getCommand`.

| Thao tác | Operation | Quyền ghi/điều kiện |
|---|---|---|
| Lưu policy | `updatePrivacyPolicy` | `privacy.manage` |
| Tạo yêu cầu dữ liệu | `createPrivacyRequest` | `privacy.manage` |
| Xác thực lại | `stepUp` | `session + quyền nguồn/policy` |
| Phê duyệt yêu cầu | `approvePrivacyRequest` | `privacy.manage` |

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

### R36 — Theo dõi công việc nền (FR-036)

**Route:** `/s/:shopId/jobs/:jobId`. **Owner:** `workspace`. **Quyền đọc:** `jobs.read`.

Theo dõi import/export/index/eval/privacy được phép từ mọi module.

**Nội dung và dữ liệu:** Kind/status, progress, counts/errors, result ref, downloadUrl khi ready.

**Hành vi:** Refetch stream/poll bounded; source-specific permission ngoài jobs.read; trở về trang nguồn; download không chứa permanent public URL.

**Trường hợp phải xử lý:** Không thấy job người khác/tenant khác; unknown total progress; partial/failed; link expired và unauthorized data không còn cache.

**Read operations:** `getJob`.

Trang read-only hoặc điều hướng sang form/route liên quan; không dựng nút mutation chưa có contract.

**Acceptance:** SC-001, SC-002, SC-003, SC-004, SC-005, SC-006, SC-007, SC-008, SC-009, SC-010, SC-011, SC-054, SC-055, cộng các scenario cross-cutting về auth/tenant/a11y/build. Traceability chuẩn ở docs/17.

## 4. Kịch bản liên màn hình cần nghiệm thu

**Từ inbox thành đơn:** R06 chọn tạo đơn → app composition đưa customerId/conversationId vào R18 → draft request chỉ IDs/quantities → R19 quote và confirm → inventory reservation cập nhật R15 → fulfill và payment theo quyền → R20/R22 nhận read model server. Back về inbox không mất filter, không tự gửi tin thông báo cho khách nếu chưa có capability/authorization.

**Từ feedback thành tri thức:** R06 đánh dấu sai → R25 review/redaction → R24 tạo revision → R28 evaluation đúng revision/config/dataset → R24 publish → R26 chọn revision live → R28 test config → R26 publish. Hai bước publish (knowledge và bot config) không được nhập nhằng thành “AI học ngay”.

**Từ nhập file đến catalog:** R13 upload/validate → R14 preview counts/errors → explicit commit snapshot → R36 theo dõi → R09 refresh. Mỗi lần commit có key riêng cho intent, retry cùng intent dùng cùng key. Stock khởi tạo bằng workflow inventory riêng, không âm thầm sửa qua cột sản phẩm.

**Từ thu hồi quyền đến mọi tab:** `/settings/team` update/revoke → permissionVersion mới và session invalidation → backend stream authorization refresh → người bị revoke mất dữ liệu đã cache và action, kể cả đang có dialog mở. API cuối vẫn reject write cũ đang tới.

**Từ báo cáo đến đối chiếu nguồn:** R22 period/currency/asOf → drilldown đúng scope → `/reports` export cùng snapshot; nếu snapshot không còn tồn tại backend báo rõ, không xuất số mới dưới nhãn số cũ.

Các mã route trong văn bản luồng chỉ hỗ trợ đọc; route manifest là nguồn chuẩn. Khi thêm/bớt route phải sinh lại bảng và cập nhật các đường dẫn liên quan.
