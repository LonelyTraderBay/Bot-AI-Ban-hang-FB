# 14 — Backlog triển khai theo dependency

Phiên bản 1.1 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Cách sử dụng backlog

Đây là thứ tự theo dependency, không phải cam kết số tuần. Chia mỗi T thành PR nhỏ có TASK_TEMPLATE và SC IDs thực tế từ fixtures. Chỉ sau G1 pass mới mở rộng song song các lane độc lập. Trạng thái ban đầu tất cả là **NOT_STARTED**; kit không tự đánh dấu công việc đã code.

| Task | Gate | Deliverable | Phụ thuộc | File/module scope | Nghiệm thu tối thiểu |
|---|---|---|---|---|---|
| T01 | G0 | Khảo sát và mapping repo | — | REPO_ADOPTION, STACK_LOCK, IMPLEMENTATION_STATUS | Rules/version/hash và loader scope đúng; commands thật/NOT_RUN; không sửa ngoài phạm vi. |
| T02 | G1 | Workspace, strict TS, boundary và CI | T01 | app/bootstrap, packages contracts/tokens, CI | CODE-001..024 và QG map vào lệnh thật; illegal imports/cycles/no-tests fail; clean install. |
| T03 | G1 | Theme, primitives, i18n, accessibility shell | T02 | shared/ui, shared/config, design bridge | DARK-001..012; OS light vẫn dark, first paint/portal/a11y; QA-001..006,021..024. |
| T04 | G1 | Session, hai shop, RBAC, routing | T02,T03 | workspace, app/router, scope lifecycle | SC-001–004, không late response shop cũ; no secret persistence. |
| T05 | G1 | HTTP, generated types, problem, MSW, fixtures | T02,T04 | shared/api plumbing, module api, mocks | Schema parse, 401/403/412/422/429/timeout states; mock không production. |
| T06 | G1 | Product vertical slice + category | T03,T04,T05 | catalog; R09–R12 | CRUD qua mock HTTP; SKU/ETag/decimal; SC-012–015 và category cycle. |
| T07 | G2 | Customer và hồ sơ theo quyền | T05,T06 | customers; R07–R08 | Contact masking và note validation; không leak response/telemetry. |
| T08 | G2 | Realtime scope và inbox lists/detail | T04,T05,T07 | inbox; R05–R06 | Pagination/scroll, event dedupe/gap; connect/reconnect/dispose. |
| T09 | G2 | Composer, takeover và send command | T08 | inbox commands | SendEligibility unknown block, timeout reconcile; handoff race fixture. |
| T10 | G2 | Jobs, uploads và catalog import | T05,T06 | workspace jobs + catalog; R13–R14,R36 | Preview/mapping/errors/commit/reload; size/quarantine; không silently overwrite. |
| T11 | G2 | Inventory snapshots và adjustment | T05,T06 | inventory; R15–R16 | Available/expectedVersion/cost/reason; không sửa raw quantity. |
| T12 | G2 | Order draft, quote, confirm | T07,T11 | orders; R17–R19 | Quote revalidation, concurrent last item và idempotency intent. |
| T13 | G2 | Fulfill, return, payment/refund UI | T12 | orders command composition | Ba trục trạng thái, full-only; payment UI ghi nhận thủ công, không chuyển tiền. |
| T14 | G3 | Finance entries, cashflow và P&L | T11,T13 | finance; R20–R22 | Cash≠revenue; nullcost≠0; post/reversal/source uniqueness fixtures. |
| T15 | G3 | Knowledge sources, revisions và feedback | T09,T10 | knowledge; R23–R25 | Draft/index/review/eval/publish/retire; private chat không tự thành tri thức. |
| T16 | G3 | AI adapters UI và channel connections | T05,T10 | integrations; R29–R30 | Write-only key, capabilities, provider test, Meta policy not-ready banner. |
| T17 | G3 | Bot playground, eval, publish/rollback | T15,T16 | bot; R26–R28 | Sandbox không gửi tin; eval bind đúng revision; pause/fencing UI. |
| T18 | G3 | Reports/export và dashboard | T10,T14,T17 | reports,dashboard; R04,R31 | Snapshot/date/currency, partial widgets và access checked export. |
| T19 | G3 | Team/shop/audit/privacy/onboarding | T04,T10,T16 | workspace; R01–R03,R32–R36 | Owner cuối, step-up, legal hold và timezone/base currency guards. |
| T20 | G3 | Toàn bộ acceptance mock và hardening | T06–T19 | tests, budgets, security controls | Mọi route có states; 55 scenarios mapped; NOT_RUN backend không thành PASS. |
| T21 | G4 | Contract integration backend thật | T20 | transport/config + integration tests | Không MSW; API/auth/object/field/concurrency thật pass; xử lý contract diff. |
| T22 | G4 | Provider/Meta staging và recovery | T21 | integration tests + backend owner evidence | Chính sách Meta hiện hành, quotas, webhook/handoff/replay được kiểm chứng. |
| T23 | G5 | UAT, restore/rollback và release approval | T22 | release evidence + operations runbooks | Đủ G5, không critical blocker, owner sign-off; chỉ deploy khi được phép. |

## 2. Đầu ra phiên code đầu tiên

Repo chạy được trong môi trường đã khóa; một slice Product list/create/edit có fixtures hai shop, API contract và ít nhất test happy path + conflict + permission + empty/error; bảng trạng thái bước tiếp theo. Nếu repo cũ chưa build được từ trước, cung cấp baseline failure chính xác và chọn phần sửa giới hạn; không nhận lỗi cũ thành lỗi mới hay tự viết lại dự án.

## 3. Không chấp nhận kiểu giao hàng sau

36 route chỉ có tiêu đề; nút thật ra chỉ toast; số doanh thu từ random; sản phẩm có giá nhưng API request sai; giao diện key lưu localStorage; fake auth role filter; mock silently fallback khi backend lỗi; test file không chạy trong CI; thiếu màn hình conflict/offline; gộp “đã thu tiền” với “đã ghi nhận doanh thu”; code mới bỏ quy tắc repo dùng chung.

## 4. Không thêm việc trùng khi nâng 1.0 → 1.1

Bổ sung governance vào T01/T02 và dark enforcement vào T03; giữ ID, thứ tự và 23
task nghiệp vụ. 24 case QA bổ sung không thay 55 SC nghiệp vụ. T20 phải tổng hợp
cả hai tập theo lớp kiểm phù hợp; T21–T23 vẫn đòi evidence backend/production thật.
