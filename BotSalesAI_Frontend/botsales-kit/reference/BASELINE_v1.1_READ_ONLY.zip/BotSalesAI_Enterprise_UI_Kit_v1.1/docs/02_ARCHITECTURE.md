# 02 — Kiến trúc frontend và quy tắc phụ thuộc

Phiên bản 1.1 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Quyết định kiến trúc

Greenfield dùng **modular frontend một ứng dụng, một deployment**. Tách theo nghiệp vụ, không tách theo mọi loại file trên toàn repo. Backend là ranh giới riêng, có thể modular monolith và worker; UI không đòi microservices. Cơ sở dữ liệu, queue và cloud do backend quyết định sau khi có workload. Không khóa UI vào PostgreSQL, MySQL, Redis hay bất kỳ broker cụ thể nào.

Chọn SPA quản trị vì không có yêu cầu SEO công khai trong phạm vi hiện tại và backend tích hợp độc lập. Đây là quyết định dự án, không phải tuyên bố React khuyến nghị SPA cho mọi trường hợp: hướng dẫn React khuyến nghị cân nhắc framework, đồng thời cho phép tự tổ hợp bằng build tool khi có ràng buộc phù hợp [S01, S02]. Nếu repo đã dùng Next.js/Nuxt/Vue/Angular, giữ nguyên và map các ranh giới dưới đây.

## 2. Một stack greenfield duy nhất

| Mối quan tâm | Baseline | Không thêm đồng thời |
|---|---|---|
| UI/runtime | React + TypeScript strict [S03] | Framework thứ hai |
| Build/package | Vite + pnpm workspace nhẹ | CRA, Nx/Turborepo khi chưa cần |
| Router | React Router với lazy route/error boundary | Router cạnh tranh |
| Server state | TanStack Query [S04] | Redux/Zustand để sao chép server entities |
| Local/form/URL state | React state; React Hook Form + Zod; router search params | Global store cho mọi input |
| Component/styling | MUI Core, một custom dark theme [S05] | AntD, shadcn, Tailwind chạy song song |
| Table | MUI Table + server pagination; composition theo module | Data grid trả phí mặc định hoặc generic table engine |
| I18n | i18next + react-i18next; vi trước | Hardcode text người dùng trong JSX |
| Contracts | OpenAPI 3.1.0 → openapi-typescript → module adapter | Kiểu DTO viết tay thành nguồn song song |
| Testing | Vitest, Testing Library, MSW, Playwright, axe-core | Nhiều E2E framework cạnh tranh |
| Charts | Một thư viện được chốt khi tới task báo cáo, ưu tiên Recharts | Chart engine custom hay 2 thư viện chart |

Chart không là dependency G1; task reports ghi ADR nhỏ và lock version trước khi cài. Chọn Node LTS còn hỗ trợ và phiên bản package tương thích tại G0 từ nguồn chính thức/registry được phép. `STACK_LOCK.md` phải ghi exact versions, peer compatibility, ngày kiểm và commands. Gói tài liệu này không tự bịa một lockfile đã được cài/chạy.

## 3. Cấu trúc dự án tham chiếu

```text
apps/web/
  src/app/                 # bootstrap, router, providers, route composition
  src/modules/
    workspace/ dashboard/ inbox/ customers/ catalog/ inventory/
    orders/ finance/ knowledge/ bot/ integrations/ reports/
      api/                 # query keys, queries, commands, DTO mapping
      model/               # view models, form schema, pure presentation logic
      ui/                  # pages, panels, domain components
      index.ts             # public route entry / supported exports only
  src/shared/
    ui/                    # domain-free wrappers and page patterns
    lib/                   # http, formatting, scope, errors
    config/                # parsed public runtime config
    telemetry/             # event/error scrubbing
  src/mocks/               # DEV/TEST only, HTTP handlers + synthetic fixtures
  tests/                   # cross-module E2E/integration
packages/contracts/        # schema source, generated types; no React/runtime behavior
packages/design-tokens/    # tokens JSON + generated CSS/theme mapping
```

Workspace chỉ có một app và hai package có nhu cầu chia sẻ thật: hợp đồng frontend/backend/test và tokens toàn UI. Không sinh hàng chục package trống. Trong repo cũ, có thể map các thư mục này vào một app hiện hữu, không bắt buộc biến repo thành monorepo.

## 4. Ma trận phụ thuộc được phép

| Từ | Được nhập | Cấm |
|---|---|---|
| app | public module entry; shared; contracts; tokens | module internal để gọi tắt nghiệp vụ |
| module X | nội bộ X; shared; contracts; tokens | module Y, app, DB/AI SDK |
| shared/ui | shared/lib, tokens, MUI | modules, app, API nghiệp vụ |
| shared/lib | contracts khi cần error primitive | modules, app, UI business logic |
| contracts | không phụ thuộc runtime app | React, provider SDK, modules |
| design-tokens | dữ liệu/token generator | app, modules, API |
| mocks/tests | public contracts; handlers; public module APIs | được cô lập khỏi production graph |

Use-case nhiều module được app ghép các public component/callback. Ví dụ inbox có nút tạo đơn: app tạo `CreateOrderFromConversation` composition, đưa customerId và selected product reference vào module orders; inbox không nhập form nội bộ của orders. Orders gọi endpoint orders của mình; backend trả product/stock quote chuẩn, không gọi qua internal catalog hook.

## 5. Hợp đồng public của module

Public API tối thiểu gồm lazy page exports, route metadata, kiểu input/output thật cần để composition và events UI có tên cụ thể. Không export toàn bộ bằng `export *`. Business rules authoritative nằm ở backend; các hàm preview/formatting trong model không được coi là ledger hoặc validation cuối.

```ts
// Ví dụ hình dạng, AI phải nối vào generated types và test trong repo thực.
export type NewOrderSeed = Readonly<{
  customerId: string;
  conversationId?: string;
}>;
export { OrdersPage } from './ui/OrdersPage';
export { CreateOrderPanel } from './ui/CreateOrderPanel';
```

Cấm import từ `modules/orders/ui/...` ở module khác. ESLint restricted imports + dependency graph checker phải xác thực resolved paths, bao gồm alias/relative import, và bắt cycle. Regex đường dẫn đơn giản không đủ làm security/architecture gate. Mỗi rule cần fixture “được phép” và “phải fail”.

## 6. Composition root và vòng đời

Khởi động: CSS/HTML dark từ token trước JavaScript → fixed theme/i18n → error/telemetry boundary → runtime config/session → scoped query client → router. Root fallback trước provider dùng cùng bootstrap CSS; login/lỗi session không phải chờ authentication để có dark theme. Bootstrap đợi session trước khi mount dữ liệu shop. Auth context không chứa entity cache. Scope key gồm userId, shopId, permissionVersion; mount một query client/scope. Sau đổi shop/logout/role revoke: hủy request, đóng stream, reset forms/PII, invalidate session và chỉ sau đó mount scope mới.

Module route lazy load; lỗi module không làm trắng shell toàn app. Unauthorized boot khác route 403. Query/stream phải có AbortSignal và cleanup khi unmount; late response của scope cũ bị loại bỏ ngay cả khi transport không hủy kịp.

## 7. Anti-overengineering và điều kiện mở rộng

Không abstraction “dùng cho mọi màn hình” nếu chưa có nhu cầu hoặc rủi ro đủ căn cứ; áp dụng Complexity/Abstraction Gate Universal 9.1, không đặt số use-case cứng thay cho phân tích. `DataTable` dùng chung chỉ xử lý cơ chế hàng/cột/loading/accessibility; column definitions, filters, permissions, actions thuộc module. Không cấu hình hóa toàn bộ sản phẩm thành JSON UI engine.

Chỉ tách microfrontend khi có ít nhất hai đội cần phát hành độc lập, ranh giới runtime rõ, ngân sách vận hành, mô hình shared dependency và bằng chứng bottleneck phối hợp; ghi ADR so với phương án modular hiện tại. Chỉ tách backend service khi có lý do scale/ownership/isolation đo được. “Dự án sẽ lớn” không tự đủ lý do.

## 8. Khi thêm tính năng

Viết requirement → xác định owner → bổ sung contract/capability/permission → update route manifest nếu cần → module UI → scenarios → integration → release evidence. Feature flag chỉ bật khi backend cho phép và quyền đủ; flag không thay authorization. Không sửa global store, root router và theme tự phát trong cùng PR module.

## 9. Chuẩn code và theme hiệu lực từ 1.1

CODE-001..024 ở docs/18 cụ thể hóa quy ước cho mọi agent. DARK-001..012 ở docs/19
chốt một theme app, không kiến trúc nhiều palette. G0 map vào repo thật, G1 nối
các cổng QG và kiểm cả ca vi phạm. Không auto-adopt stack ở repo cũ hoặc coi file
rules/AGENTS trong docs là cơ chế cưỡng chế toàn repo.
