# 01 — Mục tiêu sản phẩm và phạm vi nghiệm thu

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Sản phẩm cần xây

Một ứng dụng quản lý cho chủ shop và nhân viên. Khách nhắn qua Facebook Messenger; backend nhận webhook, điều phối AI và gửi trả lời. Người quản lý dùng web UI để theo dõi inbox, can thiệp hội thoại, quản lý hàng/đơn và tài chính. UI không chạy bot bằng cách giữ tab trình duyệt mở.

**Đầu ra giai đoạn UI:** có tất cả màn hình trong route manifest, hành vi thật qua network mocks, có thông báo demo, responsive/a11y, tính nhất quán state/permission và tests. **Đầu ra vận hành:** thêm backend thật, policy Meta đã kiểm chứng, secret vault, data integrity, monitoring/restore và phê duyệt.

## 2. Phạm vi 12 module

| Module | Giá trị và trách nhiệm sở hữu | Không sở hữu |
|---|---|---|
| workspace | Phiên, shop, membership, cấu hình, audit/privacy/jobs | Giá, kho, AI reasoning |
| dashboard | Read model tổng quan được server chuẩn hóa | Tự tính lại doanh thu từ các trang dữ liệu |
| inbox | Hội thoại, message status, assignment, bot/human handoff | Gọi Meta trực tiếp |
| customers | Hồ sơ khách, ghi chú, liên kết đơn/hội thoại | Tài khoản nhân viên |
| catalog | Sản phẩm, biến thể, SKU, danh mục, nhập dữ liệu | Available stock hay COGS cuối |
| inventory | Snapshot kho, điều chỉnh có lý do, lịch sử | Sửa lượng bằng form Product |
| orders | Đơn, dòng hàng snapshot, workflow/chuyển trạng thái | Tự ghi sổ quỹ |
| finance | Thu/chi, posting/reversal, payment/refund, P&L | Bot tự ghi chi hoặc nghiệp vụ thuế đầy đủ |
| knowledge | Nguồn tri thức, revision, review, publish/retire | Tự coi hội thoại khách là tri thức chuẩn |
| bot | Config draft/live, playground, eval, rollout/pause | Provider key và adapter protocol |
| integrations | Kênh Messenger, cấu hình provider, trạng thái kết nối | Bảo đảm mọi AI hỗ trợ giống nhau |
| reports | Báo cáo read-only, export jobs theo scope | Dữ liệu ledger nguồn |

## 3. Quy mô thiết kế và giới hạn đề xuất

Các con số dưới là **dataset/budget kiểm thử dự kiến**, không phải lưu lượng đã được người dùng xác nhận hoặc năng lực đã đo: 100.000 SKU/shop, 1.000.000 messages/shop ở backend; trang danh sách 25 mặc định và tối đa 100 bản ghi; đọc messages 50 bản ghi/lần; import ban đầu tối đa 10.000 dòng hoặc 10 MiB, server trả limit thực. Không tải toàn dataset vào browser. Một shop có một warehouse mặc định trong v1; hợp đồng luôn có warehouseId để thêm nhiều kho sau này.

Một shop có một base currency do owner chọn khi onboarding. Giao diện hỗ trợ định dạng vi-VN trước; timezone chọn ở shop, giá trị demo Asia/Vientiane. Không suy đoán mọi shop dùng VND. Multi-currency FX, nhiều công ty pháp nhân và hợp nhất báo cáo chưa thuộc v1.

## 4. Phân loại triển khai

**G0/G1 nền tảng:** repo mapping, stack lock, contracts/tokens, shell, session/shop/permission, Product vertical slice.

**G2 vận hành bán hàng:** customers, inventory, orders, inbox và human handoff đầy đủ qua mocks; nhiều state lỗi và realtime.

**G3 AI và tài chính:** quản lý providers, channels, knowledge review, bot/evals, cashflow/P&L, import/export, team/audit/privacy.

**G4 integration staging:** thay network mocks bằng backend thật theo cùng contracts; chạy tests isolation/concurrency/idempotency/live policy.

**G5 production:** evidence security, monitoring, restore, capacity, privacy/legal scope và rollback. Người chịu trách nhiệm ký duyệt trước mở tự động gửi tin/ghi giao dịch thật.

## 5. Ngoài phạm vi ban đầu

Không social auto-post, spam/bulk messaging, scraping tài khoản cá nhân, đa marketplace, full ERP, tính thuế theo nước, payroll, POS offline write, native mobile, fine-tuning tự động, đa-region active-active, microfrontend, plugin marketplace hay một agent tự quản lý tiền. Khả năng mở rộng phải được dành chỗ tại interface, không dựng sẵn toàn bộ chức năng chưa cần.

## 6. Luồng giá trị bắt buộc

**Luồng A — shop sẵn sàng:** tạo shop → đặt locale/currency/timezone → nhập sản phẩm/biến thể → xác nhận stock đầu → kết nối kênh/provider → kiểm thử bot bằng dữ liệu giả → duyệt config → bật thử trong staging.

**Luồng B — hội thoại thành đơn:** nhận message → xem nguồn thông tin AI → người hỗ trợ tiếp quản khi cần → tạo draft order từ lựa chọn đã xác nhận → backend kiểm giá/tồn → confirm/reserve → fulfill → ghi nhận thanh toán theo quyền. Không có một click “AI đã bán xong” bỏ qua xác nhận.

**Luồng C — sửa AI:** đánh dấu trả lời sai → tạo candidate có redaction → người duyệt sửa → chạy evaluation set → publish revision có người chịu trách nhiệm → đo chất lượng → rollback revision nếu hồi quy.

**Luồng D — chủ shop xem hiệu quả:** date range/timezone → doanh thu đã ghi nhận, tiền thu, chi, COGS và lợi nhuận tách riêng → xem dữ liệu thiếu → drill-down nguồn → export snapshot có asOf và bộ lọc.

## 7. Định nghĩa “hoàn chỉnh” cho một màn hình

Có route thật, permission guard, dữ liệu qua API client, trạng thái phù hợp, validate, phản hồi lỗi có thể hành động, bàn phím/mobile, kiểm thử và hướng dẫn. Không phải một ảnh mockup, không phải một bảng số liệu hardcode, không phải layout có nút bỏ trống. Xem docs/04 và scenario registry để nghiệm thu từng luồng.
