# 20 — Đưa quy tắc vào phiên AI và kiểm tra ngay từ G0/G1

**Kit 1.1 | 29/09/2026 | Áp dụng Universal 3.1 nguyên bản, không sửa theo repo.**

## 1. Nguồn và phạm vi tiếp nhận

AI_RULES.md trong kit là bản sao byte-identical của file người dùng đính kèm.
Hash tại governance/universal-source.json giúp đối chiếu, không là chữ ký hoặc bằng
chứng chức năng. File companion PROJECT_BOOTSTRAP_PROMPT.txt 3.1 không có trong
đầu vào lần cập nhật này; không được nhận đã đọc/kiểm tra đầy đủ cặp Universal.
Nếu repo có companion, đọc bản thật và đối chiếu version; nếu task yêu cầu quy trình
Universal bootstrap đầy đủ, phần thiếu phải được lấy từ chủ dự án/nguồn được phép.
PROJECT_BUILD_PROMPT_VI.txt là prompt triển khai riêng của kit, không sửa hay giả
làm companion. Thiếu companion không buộc bỏ qua AI_RULES đã có hoặc dừng mọi task
độc lập đang được cho phép.

## 2. Một chuỗi nguồn chuẩn, không nhiều bản luật riêng

Tuân thủ thứ tự chỉ dẫn thực sự của môi trường. Giữ nguyên AGENTS/instructions và
nguồn đã có; nội dung trong kit không tự hạ quyền nguồn chuẩn. Universal hướng dẫn
cách quyết định; docs/18/19 cụ thể hóa project; task/contract quy định phần triển
khai. Dark-only là quyết định trực tiếp mới của chủ dự án, không suy ra quyền thay
stack, deploy hoặc sửa code không liên quan.

Không tạo một "AI_RULES cho Claude", một "AI_RULES cho Codex", một "AI_RULES cho
Cursor" với nội dung khác nhau. Mọi loader chỉ tham chiếu cùng bản gốc và profile
cùng revision. Kiểm cơ chế nạp thật của đúng công cụ đang dùng, không tự tạo file
cấu hình cho công cụ chưa sử dụng hoặc thay cấu hình toàn máy.

## 3. Tích hợp vào repo mà không phá quy tắc có sẵn

Mặc định giải nén kit vào docs/botsales-blueprint/. AI tự tìm vị trí thực tế nếu
khác và ghi mapping; người dùng không phải sửa Universal hoặc điền hồ sơ. Khi có
điểm nạp instructions hợp lệ ở root, thêm block tham chiếu ngắn theo
`templates/AGENTS_REPO_SNIPPET.md`; giữ nội dung hiện hữu. Không ghi đè AGENTS.md.
Nếu có AI_RULES.md đúng bản ở root, dùng nguồn root và ghi hash/ref trong hồ sơ;
bản trong kit chỉ là snapshot phân phối, không sửa hai bản thành hai nguồn hiệu lực.
Nếu root khác phiên bản, không tự nâng; ghi xung đột và giới hạn, tiếp tục phần độc lập.

AGENTS.md ở trong docs/botsales-blueprint/ không tự áp dụng tới apps/web/. Cần
loader hợp lệ ở phạm vi code hoặc prompt chỉ rõ nguồn đọc. Không giả định đặt file
cạnh nhau làm mọi AI tự đọc. Nếu công cụ không hỗ trợ auto-load, dùng prompt mở đầu
và báo rõ đã nạp bằng tay qua prompt, không tuyên bố enforcement tự động.

Chạy lại việc tiếp nhận không nhân đôi block. Khi path đổi, cập nhật tham chiếu
đúng phạm vi; kiểm không có nhiều loader trỏ tới các version khác nhau. Không tự
init/commit/push/merge/deploy để "hoàn tất bootstrap".

## 4. G0: xác minh trước khi ghi code

AI ghi vào hồ sơ/task hiện có, không bắt tạo tracker mới: repo revision + diff;
nguồn instruction hiệu lực; rules version/hash; yêu cầu dark-only; tech stack thực;
nguồn API/token; scope và owner; lệnh thật hoặc lệnh ĐỀ XUẤT; kiểm tra V0–V4 liên
quan; xung đột; quyền hành động và trạng thái companion Universal.

Trong task docs_only, dừng sau hồ sơ. Trong task implement được giao, sau G0 làm
G1 nền tảng và một lát cắt đầy đủ. Không tự chuyển task bootstrap docs-only thành
implement vì trong kit có prompt code. Cũng không biến task code đã được giao
thành vòng lặp làm thêm tài liệu vô hạn.

## 5. G1: phải hiện thực cơ chế kiểm tra, không chỉ đọc luật

Tận dụng formatter/lint/TS/graph/codegen/test/CI thật. Lệnh dưới là tên khả năng
đích cần map hoặc tạo trong repo được phép, **không là script có sẵn trong kit**.

| Gate ID | Kiểm tra đích | Cách chứng minh cổng bắt sai |
|---|---|---|
| QG-01 | rules/loader/source refs | sửa hash hoặc làm mất loader phải báo thiếu |
| QG-02 | format/lint/typecheck | kiểu sai hoặc lint violation gây exit khác 0 |
| QG-03 | resolved boundaries/cycles | alias/relative/deep/dynamic import vi phạm bị chặn |
| QG-04 | generated freshness/contracts | sửa source không regenerate làm check fail |
| QG-05 | dark-only AST/CSS/config | app thêm light/system/switch phải fail |
| QG-06 | dark runtime/first paint | OS light hoặc JS chậm không đổi app sang sáng |
| QG-07 | component state tests | lỗi/403/412/unknown không bị hiển thị thành success |
| QG-08 | tenant/permission lifecycle | response scope cũ bị loại; đổi quyền xóa dữ liệu |
| QG-09 | command semantics | timeout/double click không tạo command mới/trừ hai lần |
| QG-10 | secrets/security boundaries | fixture secret/unsafe sink được phát hiện |
| QG-11 | build/dependency/mock isolation | production bundle không import MSW hoặc fixture demo |
| QG-12 | i18n/a11y/responsive | missing label/focus/translation được chỉ ra |
| QG-13 | integration review/evidence | kiểm lại bản đã kết hợp, không dùng log nhánh cũ |
| QG-14 | backend staging correctness | kiểm quyền/giao dịch/races backend thật |
| QG-15 | operation/release gate | restore/rollback/phê duyệt thật đúng revision |
| QG-16 | gate effectiveness | thiếu suite/skip/sai command không được báo pass |

governance/quality-gates.json lưu gate, mức kiểm, trạng thái và liên kết case.
Bản này là đặc tả khởi tạo, tất cả kiểm tra sản phẩm CHƯA XÁC MINH; kết quả thật
đặt ở evidence/tracker của repo theo revision, không sửa snapshot để giả đã chạy.

## 6. Phân biệt bốn cấp triển khai quy tắc

**SPECIFIED:** quy tắc/test expectation đã viết. **CONFIGURED:** đã có config và
lệnh thật bao phủ source đúng. **EXECUTED:** lệnh đã chạy, có report đúng revision.
**ENFORCED:** cổng là điều kiện bắt buộc trong luồng tích hợp và ca vi phạm thật bị
chặn trong phạm vi đã kiểm. Không có quyền cấu hình required checks thì báo thiếu;
không nói đã khóa merge/deploy. Một file CODEOWNERS/CI không tự chứng minh branch
protection hoặc người review đã xác nhận.

## 7. Quy trình CI áp dụng có điều kiện

Clean install frozen lockfile → generated drift check → format/lint/type/boundary
→ dark-only static → unit/component/contract → build → E2E mock/dark/a11y
→ dependency/security/license theo phạm vi → báo cáo. Không `|| true`, không
continue-on-error cho required gate, không passWithNoTests với suite bắt buộc.

Integration và backend/restore chạy ở môi trường phù hợp G4/G5, không nhét bí mật
production vào PR không tin cậy. CI permissions tối thiểu; pin hành động/toolchain
sau xác minh; không ép nền tảng GitHub/GitLab cụ thể khi chưa thấy repo.
Có lỗi từ trước phải báo baseline, không tắt gate để giả không có lỗi.

Dùng lint AST cho source JS/TS, parse CSS cho media/functions/token rules, graph
resolve module, và browser tests cho render. Regex chỉ hỗ trợ tìm kiếm; không được
coi là toàn bộ chứng cứ dark-only hoặc chặn cross-module. Linter không tự chứng
minh không chớp nền sáng; E2E sau load không tự chứng minh CSS bootstrap đúng.

## 8. Negative testing và ngoại lệ

Các case QA-001..024 bao gồm đầu vào đúng/sai, no-tests, thiếu source, alias,
fixture hợp lệ có chữ light, storage cũ và first paint. Thử lỗi trên bản sao/test
workspace, không mutate source thật của đội khác hoặc production. Dọn đúng phần
thử lỗi của mình, rồi kiểm diff. Ngoại lệ cần ID, phạm vi, người có quyền, lý do,
biện pháp bù, test và thời hạn; không sửa trạng thái fail thành pass.

## 9. Nhiều AI, nhiều phiên

Nền tảng G1 và contract hiệu lực trước khi mở các lane phụ thuộc. Shared files một
writer được phân công; agent gửi change request khi cần đổi API/token/router/CI.
Task nhận việc có owner thật và assignment_ref, không lấy tên role trong kit làm
phê duyệt. Khi mất ngữ cảnh, đọc profile/task và source đã đổi, không suy từ nhớ
chat; không khảo sát lại toàn repo nếu chỉ một contract đổi.

Sau merge integration được phép, kiểm bản kết hợp; git không conflict không chứng
minh thống nhất hành vi. Không tạo board riêng trong từng branch để giả khóa việc.
Repo riêng/memory/DB/cache/test account cũng phải cô lập hoặc điều phối tuần tự.

## 10. Các lệnh kiểm riêng bộ tài liệu (đã có trong gói)

Tại thư mục kit, Python 3.10+:

```bash
python scripts/validate_governance.py
python scripts/test_governance_validator.py
python scripts/validate_kit.py
python scripts/validate_schemas.py
```

Hai lệnh đầu dùng Python stdlib, kiểm policy/hash/references và bộ validator này.
validate_schemas cần môi trường Python có dependency ở requirements-validation.txt;
không tự cài vào môi trường production. Không lệnh nào ở đây chạy UI, lint code app
hoặc khóa CI repo. Báo cáo phải giữ rõ ranh giới này.
