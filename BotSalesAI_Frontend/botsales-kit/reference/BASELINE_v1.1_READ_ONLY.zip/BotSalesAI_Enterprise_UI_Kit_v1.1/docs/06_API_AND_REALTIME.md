# 06 — Hợp đồng API, lỗi, đồng thời và realtime

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Phạm vi hợp đồng

`contracts/openapi.yaml` mô tả API quản trị mà UI gọi; base `/api/v1`. Hợp đồng không mô tả toàn bộ API nội bộ worker, Meta webhook hoặc cơ sở dữ liệu. Những ranh giới backend đó có trách nhiệm/acceptance riêng trong docs/07 và docs/12. Phiên bản schema 3.1.0 là lựa chọn compatibility, không phải lời khẳng định mới nhất [S07].

Mọi endpoint shop có `/shops/{shopId}`. Server xác định principal từ session và kiểm membership/permission/object ownership; không tin shopId, role hoặc actor do client gửi. DTO read không được trả secret; thuộc tính redacted trả null và metadata phù hợp, không dùng giá trị giả như 0.

OpenAPI là nguồn cấu trúc; docs/05 là nguồn business invariant. Khi khác nhau, không tự chọn một bên: mở contract change request và sửa đồng bộ trước merge. Generated types chỉ bảo vệ compile-time; API responses phải được validate tại boundary hoặc contract tests. Schema permissive không thay business validation.

## 2. Session và CSRF

Cookie session HttpOnly/Secure/SameSite phù hợp kiến trúc cùng origin, tên dự kiến `__Host-bs_session`, path `/`, không Domain. UI gọi same-origin BFF/API; session không nằm trong JS localStorage. `GET /auth/csrf` tạo anonymous CSRF token trước login; token chỉ trong memory. `POST /auth/login` và mọi thao tác ghi gửi `X-CSRF-Token`, server kiểm origin + token ràng buộc session/pre-session. Login thành công rotate session/token; logout hủy server session và clear scope.

Không tự thiết kế password crypto trong frontend. Production auth backend dùng hệ thống được đánh giá; lockout/rate limits, recovery, MFA cho quản trị đặc quyền là release gates. Login mock không giả bộ là xác thực an toàn. OIDC/SSO là extension; không tự đổi auth flow trong G1.

## 3. Response và lỗi

Success resource `{data, meta:{requestId,asOf}}`; list thêm `page:{nextCursor,hasMore,limit,total?}`. Total chỉ có khi server tính được chính xác/được phép. Job/Command 202 trả resource có id/status; 202 không có nghĩa gửi tin/ghi sổ đã hoàn tất. 204 không parse JSON.

Lỗi dùng `application/problem+json` theo RFC 9457 [S08]: `type`, `title`, `status`, `detail`, `instance`; extension `code`, `requestId`, `errors:[{path,code,message}]`, `retryAfterSeconds?`, `currentVersion?`, `commandId?`. Không trả stack trace, SQL hay provider secret. Client map code → i18n và field error; unknown code hiển thị fallback + requestId.

| HTTP/code | Cách UI xử lý | Không làm |
|---|---|---|
| 401 SESSION_EXPIRED | đóng stream, clear sensitive scope, về login với returnTo an toàn | refresh/retry vô hạn |
| 403 FORBIDDEN | gỡ dữ liệu bị thu quyền; render denied | chỉ ẩn nút nhưng giữ dữ liệu nhạy |
| 404 NOT_FOUND | resource unavailable; có đường quay lại | leak resource tồn tại ở shop khác |
| 409 INSUFFICIENT_STOCK/PRICE_CHANGED | hiển thị dữ liệu server mới và yêu cầu xử lý | âm thầm ghi đè |
| 412 VERSION_CONFLICT | giữ draft local, show server version/diff | tự merge tiền hoặc stock |
| 422 VALIDATION_FAILED | map lỗi field; giữ input | toast chung rồi reset form |
| 429 RATE_LIMITED | tôn trọng Retry-After, disable/retry có giới hạn | loop request |
| 503 PROVIDER_UNAVAILABLE | degraded state/human handoff | tự đổi provider không được phép |
| Timeout / connection lost | tra Command hoặc replay cùng key có bảo đảm | kết luận chắc chắn thất bại |

## 4. Concurrency và idempotency

Detail GET trả ETag từ version. PATCH entity cấu hình dùng `If-Match` exact ETag; thiếu precondition trả 428, mismatch 412. Commands inventory/order có `expectedVersion` trong request; server cũng kiểm transactionally. Không có last-write-wins cho tiền/kho/quyền/publish.

Mọi command tạo side-effect dùng `Idempotency-Key` opaque ≥16 ký tự, do client tạo một lần cho một logical intent. Server scope key theo principal/shop/operation, lưu request hash + status + response/resource reference trong storage bền vững. Cùng key cùng payload replay trả cùng kết quả; cùng key khác payload trả 409 IDEMPOTENCY_MISMATCH. Giới hạn lưu key baseline ít nhất 24 giờ là thiết kế API nội bộ đề xuất, không phải chính sách Meta. Giao dịch quan trọng còn unique sourceRef dài hạn, vì hết TTL không được mở lại khoản thanh toán.

Client giữ key/commandId ở memory cho pending operation và có server list/recovery để reload. Không đặt PII hay key AI vào URL. Sau timeout chưa có commandId, replay cùng key và payload; khi không còn chắc payload/key, yêu cầu backend reconciliation hoặc tìm pending activity trước khi cho tạo intent mới. Disable button chỉ hỗ trợ UX, không bảo vệ idempotency.

## 5. Pagination, search, filter và bulk

Cursor opaque, stable order `(sortField,id)`; không parse cursor trên client. Change filter/sort/shop reset cursor. Server validate max limit 100; query key gồm normalized filters, cursor, sort, scope. Không lọc client để giả tìm toàn dataset.

Bulk operation dùng job, có dry-run/preview, explicit row selection/snapshot token, aggregate counts, row errors, duplicate strategy. Không “select all” chỉ chọn 25 dòng rồi tuyên bố chọn cả shop. Ghi rõ “25 dòng trang này” và “Tất cả N kết quả theo bộ lọc” nếu backend hỗ trợ. Server phải tái kiểm quyền và dữ liệu khi chạy job.

## 6. Realtime

SSE một stream theo shop (`GET /shops/{shopId}/events`) cho message/command/job/inventory/config changes. HTTP commands cho writes; không mở một WebSocket riêng cho từng module. Khi môi trường/SDK SSE không phù hợp, dùng cùng event contract qua transport adapter; không đổi domain model.

Envelope chuẩn trong `contracts/events.schema.json`: eventId, type, schemaVersion, shopId, resourceType/resourceId, resourceVersion, occurredAt, sequence. Event ưu tiên chứa metadata invalidation, không nhồi raw chat/PII. Stream có session/membership check khi mở và định kỳ; revoked permission phải ngắt, không tiếp tục leak events.

Delivery có thể trùng/lệch thứ tự. Dedupe eventId theo cửa sổ bounded; bỏ stale resourceVersion; sequence dùng phát hiện gap trong phạm vi stream, không suy thành thứ tự toàn hệ thống. Khi reconnect gửi Last-Event-ID; cursor hết hạn hoặc gap → `resync.required` → refetch snapshots rồi tiếp tục. Unknown event/schema version không crash: ghi sanitized telemetry và refetch phù hợp. Heartbeat, reconnect backoff+jitter, offline badge; polling bounded chỉ khi stream không hoạt động, dừng khi tab/scope bị hủy.

Cache invalidation: inventory.updated → inventory list/detail và order quote liên quan; order.updated → order detail/list + dashboard invalidation; message.created → conversation messages/list; finance.updated → finance/reports; knowledge.published/config.updated → config/eval views. Không dùng event làm ledger authoritative hoặc tự tính P&L trên browser.

## 7. Versioning và rollout tương thích

API path major `/v1`; additive fields backward-compatible chỉ khi client tolerate unknown fields. Không đổi nghĩa hoặc type trường cũ âm thầm; enum mới cần fallback safe. Breaking change dùng major hoặc transition endpoint và thời gian tồn tại song song được ghi bằng ADR. CI so sánh OpenAPI với base branch, chặn bỏ/đổi required field hoặc thu hẹp enum không có migration.

Deploy backend mở rộng trước → frontend mới → quan sát → chỉ sau compatibility window mới bỏ field cũ. Frontend stale tab vẫn gặp API tương thích. Static chunks content-hash được giữ qua rollback; 404 chunk có bounded reload sau cảnh báo unsaved work. Không xóa assets bản cũ ngay khi deploy.

## 8. Ownership mock→real

Mỗi operation trong route manifest có MSW handler contract-valid; test network failures/conflicts bằng scenario switch. Production build phải loại mocks và demo controls. API client không biết dữ liệu fake hay real; chỉ base URL/runtime mode thay đổi qua bootstrap. Mock không được fallback trả success khi backend thật lỗi.

## 9. Snapshot và realtime không mất invalidation

Client đăng ký stream trước và buffer metadata theo scope, sau đó lấy snapshots. Khi snapshot về, áp dụng các invalidation đã buffer và refetch resource nếu version chưa phủ; không discard event chỉ vì request đang loading. Khi stream báo gap, unsubscribe/reconnect với cursor theo protocol, lấy snapshot mới trong khi tiếp tục buffer; chỉ bỏ buffer sau đối chiếu. Backend cursor phải thuộc stream đã lọc quyền, không suy gap từ global sequence có nhiều event bị lọc. Poll fallback luôn refetch từ nguồn server. Kiểm sự kiện xảy ra giữa subscribe/snapshot và giữa snapshot/reconnect; không chỉ test happy-path streaming.

PATCH bỏ qua trường không gửi, chỉ null những trường nullable. Collection được gửi là replacement cho collection đó; giữ stable IDs, không ngầm xóa lịch sử variant. Finance chỉ sửa draft; published tri thức là immutable và thay đổi tạo draft mới.
