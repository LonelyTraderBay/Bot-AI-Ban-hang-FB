# 16 — Nguồn và phạm vi sử dụng

Ngày đối chiếu: 29/09/2026. Nội dung thiết kế là baseline đề xuất; nguồn tham khảo không chứng nhận ứng dụng đã production-ready.

## Nghiên cứu nội bộ đã đọc

- Tóm tắt điều hành(3), Library file `file_000000005ba481fb98c619a521620fb4`: yêu cầu sản phẩm, dark UI và định hướng kiến trúc.
- Tóm tắt điều hành(1), Library file `file_000000003cd0820993ce47d6e25176a8`: phạm vi bot, kho và tài chính.
- URL share do chủ dự án đưa chỉ đọc được tiêu đề, không đọc được toàn bộ hội thoại. Không khẳng định kit tái hiện mọi quyết định cuối trong share. Các điểm được chuẩn hóa mới nêu ở docs/00.

## Nguồn chính thức

### S01 — React: Creating a React App

https://react.dev/learn/creating-a-react-app

Trạng thái: Đã truy cập. Phạm vi sử dụng: Framework là hướng khuyến nghị chung; chọn SPA có chủ đích, không gán Vite thành lựa chọn enterprise bắt buộc.

### S02 — React: Build a React app from Scratch

https://react.dev/learn/build-a-react-app-from-scratch

Trạng thái: Đã truy cập. Phạm vi sử dụng: Build tool Vite và trách nhiệm routing/data fetching khi tự tổ hợp SPA.

### S03 — TypeScript: strict

https://www.typescriptlang.org/tsconfig/strict.html

Trạng thái: Đã truy cập. Phạm vi sử dụng: Bật họ kiểm tra kiểu strict; không thay thế runtime validation.

### S04 — TanStack Query: Query Keys

https://tanstack.com/query/latest/docs/framework/react/guides/query-keys

Trạng thái: Đã truy cập. Phạm vi sử dụng: Query key chứa các biến ảnh hưởng dữ liệu; tenant scope là thiết kế của kit.

### S05 — Material UI: Dark mode

https://mui.com/material-ui/customization/dark-mode/

Trạng thái: Đã truy cập. Phạm vi sử dụng: Dark-only theme và tùy biến palette.

### S06 — W3C: WCAG 2.2

https://www.w3.org/TR/WCAG22/

Trạng thái: Đã đối chiếu nội dung WCAG 2.2 từ W3C. Phạm vi sử dụng: Contrast, keyboard, focus, target size; cần audit thực tế.

### S07 — OpenAPI Specification 3.1.0

https://spec.openapis.org/oas/v3.1.0.html

Trạng thái: Đã truy cập. Phạm vi sử dụng: Chọn 3.1.0 vì hợp đồng/toolchain, không tuyên bố đây là phiên bản mới nhất.

### S08 — RFC 9457: Problem Details for HTTP APIs

https://www.rfc-editor.org/rfc/rfc9457.html

Trạng thái: Đã truy cập. Phạm vi sử dụng: application/problem+json và extension lỗi nghiệp vụ.

### S09 — OWASP ASVS

https://owasp.org/www-project-application-security-verification-standard/

Trạng thái: Đã truy cập. Phạm vi sử dụng: Tham chiếu kiểm soát bảo mật; không có chứng nhận tuân thủ tự động.

### S10 — OWASP GenAI: LLM01 Prompt Injection

https://genai.owasp.org/llmrisk/llm01-prompt-injection/

Trạng thái: Đã truy cập. Phạm vi sử dụng: Tài liệu/hội thoại truy xuất là dữ liệu không tin cậy, không phải lệnh.

### S11 — Playwright: Best practices

https://playwright.dev/docs/best-practices

Trạng thái: Đã truy cập. Phạm vi sử dụng: Test hành vi người dùng, isolation và locator có ý nghĩa.

### S12 — Mock Service Worker: Documentation

https://mswjs.io/docs/

Trạng thái: Đã truy cập. Phạm vi sử dụng: Mock tại ranh giới network, dùng lại trong môi trường test.

### S13 — Meta Messenger policy overview

https://developers.facebook.com/docs/messenger-platform/policy/policy-overview/

Trạng thái: Truy cập bị HTTP 429; CHƯA xác minh policy hiện hành. Phạm vi sử dụng: Release owner phải xác minh version, quyền, app review, window và loại tin trước kết nối thật.

## Quy tắc cập nhật

Trước khóa dependency và tích hợp thật, kiểm lại tài liệu chính thức/compatibility, ghi ngày và exact version. Không lấy model price, Graph version hoặc quy định pháp lý cũ trong nghiên cứu làm dữ liệu hiện hành. Hạn chế truy cập Meta là blocker được ghi rõ, không phải bằng chứng chính sách không tồn tại.

## Nguồn bổ sung đã đối chiếu trong 1.1 (29/09/2026)

S03 (strict) và S05 (MUI dark-only) được mở lại trong lần này. Các nguồn khác từ
1.0 giữ như provenance của lần bàn giao trước, không nhận đã kiểm lại tất cả.

| ID | Nguồn chính thức | Dùng cho |
|---|---|---|
| S14 | MDN: color-scheme — https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/color-scheme | CSS/native controls, head metadata; không tự theme mọi component. |
| S15 | Playwright: Emulation — https://playwright.dev/docs/emulation | Color-scheme/media emulation; chỉ phương pháp, chưa chạy UI. |
| S16 | TypeScript: noUncheckedIndexedAccess — https://www.typescriptlang.org/tsconfig/noUncheckedIndexedAccess.html | Kiểm truy cập index, riêng với strict. |
| S17 | TypeScript: exactOptionalPropertyTypes — https://www.typescriptlang.org/tsconfig/exactOptionalPropertyTypes.html | Phân biệt optional và undefined theo cấu hình. |
| S18 | MUI: Palette — https://mui.com/material-ui/customization/palette/ | primary.light là sắc độ, không là theme mode. |
| S19 | ESLint: Custom Rules — https://eslint.org/docs/latest/extend/custom-rules | Tham khảo AST-based enforcement; chưa cấu hình linter app trong kit. |

Nguồn nội bộ mới: file AI_RULES.md 3.1 do người dùng đính kèm, giữ nguyên; trực tiếp
yêu cầu dark-only và thống nhất code/AI ngày 29/09/2026. Thông số kỹ thuật/stack
trong quy tắc project là baseline triển khai, không biến thành yêu cầu Universal.
