# 15 — Quyết định còn mở, giả định và release blockers

Phiên bản 1.0 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Quyết định đã chuẩn hóa trong baseline đề xuất

Một modular UI, 12 modules, dark-only, React/TypeScript/Vite cho greenfield, REST OpenAPI, query state có scope, MUI một design system, API key server-only, kiến thức review/eval/publish, no offline writes, quản trị tiền/kho server-authoritative. Đây là đề xuất triển khai cụ thể để AI khỏi tự chọn lại; không gắn nhãn “chủ dự án đã duyệt từng công nghệ”.

## 2. Register

| ID | Nội dung chưa biết/rủi ro | Default dùng để bắt đầu UI mock | Owner cần quyết định | Chặn gate |
|---|---|---|---|---|
| D01 | Repo thực, framework/backend, auth hiện tại | Chưa có repo được kiểm tra trong lần bàn giao; greenfield baseline chỉ khi repo trống | Tech lead | G0 integration mapping |
| D02 | Phiên bản dependency tương thích | G0 lấy stable phù hợp, pin exact + lockfile; không dùng nhãn latest thả nổi | Platform | G1 build |
| D03 | Auth IdP/SSO/MFA, session lifecycle | Same-origin HttpOnly session; login/step-up abstraction; SSO sau ADR | Security/backend | G4 |
| D04 | Meta app mode, permissions, Page token, Graph version, policy | Connection not_ready, sendEligibility unknown, không gửi thật | Integration owner | G4–G5 |
| D05 | Provider đầu tiên, region, retention, quota và fallback | Demo provider metadata, không gọi mạng hoặc phát sinh phí | Business+AI/security | G4 |
| D06 | Quốc gia phục vụ và nghĩa vụ privacy/kế toán/thuế | Chỉ quản trị nội bộ; retention configurable chưa activate; không chứng nhận tuân thủ | Business/legal/accounting | G5 |
| D07 | Currency, timezone, fiscal period, rounding/COGS policy | Fixture VND và Asia/Vientiane; server giữ amount exact, policy có version | Shop owner/accounting | G4 finance |
| D08 | Full/partial returns, damaged stock, payments gateway | V1 full-only; payment/refund là ghi nhận thủ công, không chuyển tiền tự động | Business/backend | G4 orders |
| D09 | Workload, infra và SLA thực tế | Dataset/stress budgets trong docs/01,10 là giả định thử | Operations/business | G4 load/G5 |
| D10 | Brand/logo và UX detail của chủ shop | Tên BotSales AI tạm, dark-only tokens, không copy thương hiệu khác | Product owner | UAT; không chặn G1 |
| D11 | Retention/legal hold/backups/deletion | Request workflow, không tự xóa dữ liệu thực hoặc lưu vô hạn mặc định | Privacy/security | G5 |
| D12 | Nhân sự trực vận hành và quyền production | Chỉ build/mock/staging được cho phép; không tự deploy | Business/operations | G5 |
| D13 | Tài liệu share đầy đủ chưa đọc được | Dùng hai báo cáo Library đã đọc, ghi rõ reconciliation | Product owner | Xác nhận scope; không chặn UI mock |

## 3. Rủi ro kiến trúc và cách giữ kiểm soát

Rò tenant/secret, sai số tiền/kho, bot hành động quá quyền và publish tri thức sai là critical. Contract drift, hai design systems, query cache không scope, merge conflicts shared files và thiếu test lỗi là high. Giới hạn bằng permissions server-side, durable commands, immutable records/revisions, machine-checkable contracts và ownership single-writer; không bằng lời nhắc “hãy cẩn thận” đơn thuần.

Nếu phát hiện khác biệt giữa nghiên cứu cũ và kit này: ghi decision ID, tác động nghiệp vụ/security, lựa chọn thay thế, cách migrate và test; xin approve khi có quyết định không đảo ngược. AI có thể tiếp tục phần mock an toàn nhưng không tự coi điểm UNKNOWN là APPROVED.

## 4. Giới hạn bảo đảm

Không kiến trúc nào miễn bảo trì, nâng dependency hoặc thay API. Sức chịu tải, bảo mật và tính đúng nghiệp vụ chỉ có thể đánh giá từ mã chạy, cấu hình triển khai và test với dữ liệu/tải đại diện. Gói này làm rõ nền tảng, phạm vi và tiêu chí nghiệm thu; không có chứng nhận enterprise/ISO/SOC2, kiểm toán tài chính hoặc kết quả pentest ứng dụng đi kèm.
