# 10 — Chiến lược kiểm thử và định nghĩa hoàn thành

Phiên bản 1.1 • 29/09/2026 • Baseline đề xuất, chưa phải chứng nhận production

## 1. Ba mức bằng chứng, không được đánh tráo

**KIT_VALIDATED** chỉ nghĩa là gói đặc tả được kiểm tra liên kết/schema/fixture/token. **UI_MOCK_VERIFIED** nghĩa là mã UI đã chạy test với MSW và build thành công. **INTEGRATED_VERIFIED** nghĩa là UI và backend thật đã qua contract, authorization, concurrency, recovery và kiểm thử staging. Chỉ mức cuối cộng G5 release controls mới được đề nghị phát hành production.

`fixtures/acceptance-scenarios.json` là đặc tả ca kiểm thử, không phải kết quả chạy. Các ca có `executionStatus=NOT_RUN_PRODUCT_TEST`. Không tự đổi thành PASS sau khi đọc chúng. Screenshots không chứng minh API hoạt động hay dữ liệu kế toán đúng.

## 2. Tháp kiểm thử và ownership

| Lớp | Nội dung bắt buộc | Người chịu trách nhiệm | Bằng chứng |
|---|---|---|---|
| Static | TS strict, no explicit any không giải thích, import boundaries, cycle, format/lint | Platform/UI | CI log; fixture vi phạm phải fail |
| Unit | Money mapper, định dạng ngày, status presentation, validators, query keys | Module owner | Test report + edge inputs |
| Component | Form, table, dialog, permission states, pending/conflict, keyboard | UI owner | RTL/Vitest + accessibility report |
| Contract | Request/response against OpenAPI; unknown fields/enums; breaking diff | Integrator/API | Schema report, generated diff |
| Integration mock | HTTP qua MSW, retry/idempotency UI, stale response, scopes | UI + QA | Report ghi rõ MOCK |
| E2E mock | Vertical flows và browser layout/navigation | QA | Playwright HTML report, trace khi fail |
| Backend integration | IDOR, transaction, races, auth revocation, worker fencing, exports | Backend + Security | Database assertions + request traces |
| Staging E2E | Live login → dữ liệu → nghiệp vụ → reconcile, không fake success | QA + Integrator | Report ghi backend revision/environment |
| Nonfunctional | Accessibility manual, performance, leak, security, recovery | QA + Operations | Artifacts và cấu hình đo có thể tái lập |

MSW dùng cùng semantics request/response như contract, không bỏ qua permission/version để demo luôn xanh [S12]. Playwright ưu tiên hành vi quan sát được bằng role/label và cô lập dữ liệu test [S11]. Test runner không được tự gọi provider có phí hoặc gửi Messenger thật; smoke sandbox có authorization riêng.

## 3. Bộ trạng thái bắt buộc mỗi route

Loading lần đầu; success; empty lần đầu và empty do filter; partial/degraded; error có retry; permission denied; unauthenticated; stale/offline. Với route sửa dữ liệu thêm dirty, validation error, submitting, timeout/unknown, conflict, success, cancel và navigation guard. Với list thêm pagination/sort/filter reset; với detail thêm not found/archived; với job thêm cancelled/partial failure/reload recovery.

Mọi trường hợp phải có hành động tiếp theo rõ ràng. Không một spinner vô hạn. Không dùng skeleton cho lỗi 403. Không xóa input khi server 422. Không dùng toast làm nơi duy nhất hiển thị lỗi quan trọng.

## 4. Acceptance trọng yếu phải chạy trước release

Hai shop có cùng SKU nhưng dữ liệu khác; response shop cũ về muộn; thu hồi quyền khi hai tab đang mở; staff thử xem giá vốn trong response; hai đơn tranh chiếc hàng cuối; quote hết hạn/giá đổi; ghi nhận thanh toán retry sau timeout; post/reversal bị gửi hai lần; takeover lúc bot đang gửi; Meta eligibility unknown; tài liệu tri thức cố prompt injection; provider fallback sang vùng dữ liệu không được phép; export của user vừa bị thu hồi quyền; restore revision nhưng chưa publish.

Các acceptance chi tiết và ID truy nguyên ở docs/17. Mỗi ca severity critical cần ít nhất một test tự động đúng lớp và review chuyên môn khi liên quan dữ liệu/authorization. Không lấy test mock thay cho concurrency test backend.

## 5. Coverage gate đề xuất

Code mới: unit/component line coverage ≥80%, branch ≥75% trong phần có logic. Module quyền, Money và request mapper quan trọng: branch ≥90%. Mọi invariant critical phải có ca positive/negative riêng dù tổng coverage đã đạt. Generated code, icons và type-only files được exclude có lý do; không exclude toàn folder nghiệp vụ. Repo cũ: baseline ghi nhận, không giảm coverage hiện tại; tăng theo phần được sửa thay vì bắt viết lại toàn bộ.

Coverage là tín hiệu chống bỏ sót, không phải chứng minh không có lỗi. CI phải công bố report trước/sau và có owner cho ngoại lệ có hạn chót; không chỉnh thresholds thấp đi để PR xanh.

## 6. Performance và accessibility budgets — mục tiêu cần đo

| Chỉ số | Mục tiêu đề xuất | Phương pháp |
|---|---|---|
| Initial route JS gzip | ≤350 KiB shell + route đầu; library chung tính vào tổng | Production build analyzer, cold cache |
| Route-specific JS gzip | ≤180 KiB mỗi route; charts/import lazy riêng | So sánh baseline CI; ngoại lệ có ADR |
| Lab LCP / CLS / interaction | LCP ≤2.5 s, CLS ≤0.1; tương tác chính p95 ≤200 ms | 5 lần chạy, Chromium cố định, viewport390×844, CPU4× slowdown, down1.6Mbps/up750Kbps/RTT150ms |
| Field UI | Theo dõi p75 LCP/INP/CLS theo route/device khi đủ mẫu | RUM không chứa PII; không dùng số lab như số field |
| Table/inbox | Không tải cả 100k SKU hay 1m messages vào browser | Network assertion, page limit, heap/scroll trace |
| Scope lifecycle | Không tăng retained data theo 50 lần switch sau warm-up | Repeatable heap profiles, subscriptions count; investigate growth >10MiB |
| Accessibility | WCAG 2.2 AA làm mục tiêu; 0 serious/critical axe trên flows chính | Axe + keyboard, focus, NVDA/VoiceOver và zoom/reflow manual |

Các con số là budget dự án, không phải số đo đạt được. Ghi máy chạy, OS/browser versions, commit, fixture volume, API latency profile và median/p95 thật. API mock zero-latency không chứng minh UX trên mạng thật. Không gắn nhãn WCAG compliant chỉ từ token contrast hoặc axe [S06].

## 7. CI contract cần AI hiện thực trong repo

G0 tạo/pin toolchain phù hợp repo. G1 phải cung cấp script tương đương: `lint`, `typecheck`, `test:unit`, `test:integration`, `test:contracts`, `test:boundaries`, `build`, `test:e2e:mock`, `test:a11y`, `check:bundle`. Tên trên là yêu cầu triển khai, chưa phải lệnh có sẵn trong kit. Repo cũ được mapping tên khác trong STACK_LOCK/REPO_ADOPTION.

PR flow: install frozen lockfile → generated freshness → lint/typecheck → boundaries → unit/component → contracts → build → E2E mock/a11y → security/dependency/license → publish reports. Staging flow chạy riêng với backend thật, test accounts và kiểm soát secrets. Không cho production branch skip vì không có test file.

## 8. Definition of Done cho một PR

Có task/FR/route/SC IDs; thay đổi trong phạm vi file được giao; không phá import graph; contract/fixture đồng bộ; mọi state liên quan được test; strings qua i18n; responsive không mất thao tác; keyboard hoạt động; không log secret/PII; generated diff sạch; có test execution log với commit và môi trường. Ghi rõ NOT_RUN và blockers. Nếu PR chưa integrated, label UI_MOCK chứ không “production complete”.

Review độc lập cho quyền, stock, finance, publish hoặc shared contract. CI pass không thay phê duyệt thiết kế; cũng không cho manual approval bỏ qua test critical thất bại.

## 9. Bổ sung gate và kịch bản governance 1.1

Ngoài 55 scenario nghiệp vụ đang giữ nguyên, governance/acceptance-scenarios.json
có 24 case QA về dark-only/code/loader/CI. governance/quality-gates.json có 16
specification gate, chưa nối vào CI repo. Thực thi QG theo phase/rủi ro trong docs/20;
không ép kiểm backend G4 là đã chạy ở G1. Ca sai và ca hợp lệ chứa chữ light đều
cần kiểm để tránh linter vừa bỏ sót vừa báo sai.

Chuẩn trạng thái nghiệm thu: ĐẠT / CHƯA ĐẠT / CHƯA XÁC MINH / KHÔNG ÁP DỤNG có lý do,
theo Universal 19.5. PASS/FAIL/NOT_RUN/SKIP là kết quả kỹ thuật được map, không tự
cấp quyền release. NOT_RUN luôn là chưa xác minh nếu kiểm tra cần thiết. SKIP chỉ
là không áp dụng khi có căn cứ về phạm vi, không vì thiếu source/test/môi trường.
