# 05 — Mô hình dữ liệu và quy tắc không được phá vỡ

Phiên bản 1.0 • 29/09/2026 • Baseline triển khai đề xuất • Phạm vi: UI + hợp đồng tích hợp

## 1. Quy ước chung

ID là chuỗi opaque, không suy diễn quyền từ prefix. Mọi thực thể nghiệp vụ có shopId; quan hệ cross-shop bị từ chối phía server, không chỉ trong UI. User là nhân viên đăng nhập; Customer là khách mua; Membership nối User–Shop với vai trò/permissionVersion. Không trộn khách Messenger vào bảng User của quản trị.

Money = `{amount: "125000.00", currency: "VND"}`. Decimal phải parse bằng thư viện decimal đã chốt hoặc minor-unit integer với scale cấu hình; JavaScript Number không là phép tính tài chính chuẩn. V1 bán đơn vị nguyên, quantity là integer; trọng lượng/phân số là extension cần contract change. Một shop một base currency; UI không cộng các currencies khác nhau. Rounding mode/tax handling phải được backend công bố trong policy.

Datetime API là ISO 8601 UTC, `createdAt` bất biến; báo cáo nhận timezone IANA và khoảng `[from,to)` (đầu bao gồm, cuối không bao gồm). Backend dùng timezone shop để đóng kỳ; query key chứa toàn bộ filter/timezone. Mỗi entity chỉnh sửa có version và ETag trên detail GET. Audit có actor, scope, action, entity, time, trace/command ID, redacted changes.

## 2. Thực thể và quyền sở hữu

| Entity | Thuộc module | Trường/quan hệ thiết yếu |
|---|---|---|
| User, Membership, Shop | workspace | userId, shopId, roles, permissions, permissionVersion; currency/timezone |
| Customer | customers | external identity có channel scope, displayName, contact được che theo quyền |
| Product, Variant, Category | catalog | name/status/category; variant SKU, options, price, version |
| Warehouse, StockSnapshot, StockMovement | inventory | variantId+warehouseId+shopId; onHand/reserved/available; delta/reason/source |
| Order, OrderLine | orders | customer/conversation refs; SKU/name/price/discount snapshots, states/version |
| Payment, Refund | finance | orderId, amount, method, immutable sourceRef, commandId |
| FinanceEntry, ReportSnapshot | finance/reports | classification, status, reversalOf, sourceRef, asOf, warnings |
| ChannelConnection, Conversation, Message | integrations/inbox | page scope, participant ref, assignment, handoff, provider delivery status |
| AIConnection, ModelCapability | integrations | provider/model identity, secret metadata, checks/limits/policy |
| KnowledgeDocument, KnowledgeRevision | knowledge | source, content hash, revision, approval, publishedAt, retention |
| FeedbackCandidate, EvaluationRun, BotConfigRevision | knowledge/bot | input/evidence, review, metrics, dataset version, draft/live version |
| Job, Command, AuditEvent | workspace | async progress, result/resource IDs, idempotency, actor/scope |

## 3. Catalog và kho

Product có nhiều Variant; SKU unique trong shop. Mọi mặt hàng bán được có ít nhất một variant kể cả sản phẩm không có size/color. Product archive không xóa snapshot trong order, message evidence hoặc ledger. Giá bán nằm ở variant; tồn kho không nằm trong product form.

`available = onHand - reserved`, với kiểm không âm trong policy v1. Giá trị số lượng tổng và từng movement được server tính trong transaction. UI không PUT quantity tuyệt đối trực tiếp; yêu cầu điều chỉnh có delta, lý do, warehouse/variant, expectedVersion và idempotency key. Số âm hợp lệ cho delta khi có quyền, nhưng server từ chối làm onHand nhỏ hơn reserved nếu không có workflow giải phóng phù hợp.

Xác nhận đơn reserve hàng một lần; fulfill trừ onHand và giảm reserved cùng transaction. Hủy trước giao giải phóng reservation, không trừ onHand. Reservation timeout có server expiry, không dùng đồng hồ browser làm quyết định. Giữ chỗ phải có nguồn order/line và phiên bản. Test hai người đặt chiếc cuối chỉ một confirm được chấp nhận. Không gọi thêm endpoint adjustment từ UI sau confirm để tự đồng bộ kho.

Inventory receipt/adjustment phải có nguồn/lý do/cost nếu ảnh hưởng giá vốn. Cost chưa có → báo cáo warning và profit=null hoặc provisional; không tự thay bằng 0. Audit movement bất biến; sửa sai bằng movement bù.

## 4. State machine đơn hàng — tách ba chiều

| Trục | Trạng thái v1 | Quy tắc |
|---|---|---|
| orderState | draft, confirmed, completed, cancelled | không nhét cả payment/shipping vào một enum |
| fulfillmentState | unfulfilled, reserved, fulfilled, returned | v1 full fulfillment/full return; partial chưa hỗ trợ |
| paymentState | unpaid, paid, refunded | trạng thái pending nằm ở Command, không giả paid |

Draft không giữ tồn, không tạo doanh thu. Confirm reprice và kiểm tồn server; khi giá khác, trả PRICE_CHANGED với quote mới, người dùng xác nhận lại. Fulfill ghi nhận xuất kho/giá vốn và doanh thu quản trị theo policy baseline. Payment ghi tiền vào, độc lập với thời điểm doanh thu. Completed chỉ khi fulfilled và paid; returned/refunded giữ lịch sử order, không xóa order hoặc quay về draft.

Cancel v1 cho draft/confirmed chưa giao và chưa thanh toán. Đã thu tiền phải có luồng hoàn tiền/hoàn tác được kiểm soát; đã giao dùng return, không cancel. Backend trả `allowedActions` và lý do; client không tự suy toàn bộ action từ enum. Status mới chưa hiểu → read-only với nhãn “Trạng thái chưa được hỗ trợ”, không crash hoặc cho sửa.

V1 chỉ full return và full refund; partial fulfillment/payment/refund là capability tắt. Hoàn hàng xác nhận hàng thực nhận và kiểm tra restock. Hoàn tiền là chuyển động tiền riêng; return không mặc nhiên đồng nghĩa đã hoàn tiền. Refund server chặn vượt số đã thu chưa hoàn. Gửi lặp cùng key không tạo khoản hoàn thứ hai.

## 5. Thu/chi không bằng lợi nhuận

Đây là **tài chính quản trị cửa hàng**, chưa phải hệ thống kế toán/thuế tuân thủ một quốc gia. Baseline đề xuất ghi nhận bán hàng khi fulfill; giá vốn theo bình quân gia quyền liên hoàn, snapshot tại lúc xuất. Backend finance owner phải phê duyệt policy trước integration; UI hiển thị `policyVersion` và tính tạm thời.

- Gross sales: tổng giá niêm yết chưa thuế của hàng đã fulfill.
- Net sales: gross sales trừ giảm giá phân bổ và sales returns đã ghi nhận.
- COGS: giá vốn hàng đã fulfill, trừ phần giá vốn hoàn nhập được xác nhận khi hàng trả lại được restock; hàng hỏng không tự hoàn nhập giá vốn.
- Gross profit = net sales − COGS.
- Operating profit = gross profit + shipping income − shipping expense − platform/payment fees − AI expense − other operating expenses.
- Cash movement = money received − money paid trong kỳ; không phải operating profit.

VAT/tax thu hộ không tự tính là revenue. Vốn chủ, vay, trả nợ gốc, chuyển tiền giữa quỹ và mua tồn kho không tự biến thành doanh thu/chi phí hoạt động. Giá trị nhập hàng đi vào inventory/COGS theo policy, không trừ toàn bộ lần nữa khi tính lợi nhuận bán hàng. Khoản vốn vay ảnh hưởng cash nhưng không tăng lãi. Tiền AI ước lượng từ token là usage estimate, không đồng thời là chi phí đã ghi sổ; đối soát hóa đơn tránh tính đôi.

Entry thủ công có classification rõ và cấm ghi thêm doanh thu cho cùng order sourceRef. Posting immutable; sửa bằng reverse entry có liên kết, reason, actor. Idempotency và unique sourceRef bảo vệ trước replay. Báo cáo chứa `asOf`, period, currency, policyVersion, completeness, warnings và drilldown source. UI không cộng danh sách đã phân trang thành tổng shop.

## 6. Ví dụ nghiệm thu tài chính

Dữ liệu giả, bỏ thuế/phí: nhập 10 áo ×100.000 VND; thanh toán nhập kho 1.000.000. Bán/fulfill 2 áo ×150.000; nhận tiền 300.000. Khi đó onHand=8; gross/net sales=300.000; COGS=200.000; gross profit=100.000; cash movement nếu cùng kỳ gồm nhập hàng =−700.000. Không báo lỗ 700.000 như lợi nhuận vận hành.

Khách trả đủ 2 áo, hàng còn tốt và restock được duyệt: tồn về 10; sales return=300.000; COGS reversal=200.000; gross profit ròng=0. Refund 300.000 giảm cash riêng. Nếu refund đang pending, paymentState chưa refunded và UI hiển thị “Chưa xác nhận hoàn tiền”.

## 7. Các bất biến bắt buộc kiểm thử

Không rò dữ liệu shop; SKU unique scoped; giá/tồn live revalidated; không double-confirm/fulfill/pay/refund; không over-reserve; không gọi lại side-effect sau timeout bằng key mới; decimal/currency đúng; audit append-only; published knowledge immutable revision; không hiển thị cost hoặc contact bị server redacted; order history không mất khi product archive; mọi reference phải thuộc cùng shop.
