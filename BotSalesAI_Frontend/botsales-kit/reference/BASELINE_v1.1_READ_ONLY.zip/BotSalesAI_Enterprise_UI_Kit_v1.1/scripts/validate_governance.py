#!/usr/bin/env python3
"""Validate the v1.1 documentation policy snapshot, not application code or CI.

Python 3.10+, standard library. Read-only. --root accepts a copied kit.
Exit 0 = valid documentation snapshot; 1 = invalid/incomplete; 2 = CLI misuse.
The source/hash checks are integrity checks, not signatures or proof of authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


class PolicyError(ValueError):
    """An invalid or incomplete policy snapshot."""


def safe_file(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative:
        raise PolicyError('File reference must be a non-empty string')
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise PolicyError(f'Missing or out-of-root file: {relative}')
    return path


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PolicyError(f'Duplicate JSON key: {key}')
        result[key] = value
    return result


def load(root: Path, relative: str) -> dict[str, Any]:
    value = json.loads(safe_file(root, relative).read_text(encoding='utf-8'),
                       object_pairs_hook=reject_duplicate_keys)
    if not isinstance(value, dict):
        raise PolicyError(f'Expected an object in {relative}')
    return value


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PolicyError(message)


def validate(root: Path) -> dict[str, Any]:
    root = root.resolve()
    policy = load(root, 'governance/project-policy.json')
    require(policy['kitVersion'] == '1.1', 'Wrong kit version')
    require(policy['decisionId'] == 'ADR-011', 'Unknown dark-only decision')
    theme = policy['theme']
    require(theme['policy'] == 'dark-only', 'Only dark-only policy is authorized')
    require(theme['availableModes'] == ['dark'], 'Multiple or non-dark modes')
    require(theme['defaultMode'] == 'dark', 'Default mode must be dark')
    for key in ('allowThemeToggle', 'useSystemPreference',
                'persistThemePreference', 'allowMultipleAppPalettes'):
        require(theme[key] is False, f'{key} must be false')
    require(theme['allowAccessibilityOverrides'] is True, 'Accessibility cannot be disabled')
    require(theme['forcedColorsPolicy'] == 'preserve-user-accessibility', 'Forced colors policy changed')
    require(theme['printIsSeparateArtifact'] is True, 'Print must not introduce another app theme')
    require(theme['tokenSource'] == 'design/tokens.json', 'Wrong canonical token source')
    require(theme['cssOutput'] == 'design/tokens.css', 'Wrong generated CSS path')
    require(theme['ruleSource'] == 'docs/19_DARK_ONLY_POLICY.md', 'Wrong dark rule source')
    tokens = load(root, theme['tokenSource'])
    require(tokens['theme'] == 'dark-only', 'Token policy drift')
    css = safe_file(root, theme['cssOutput']).read_text(encoding='utf-8')
    for marker in ('color-scheme: dark;', 'background-color: var(--color-canvas);',
                   'color: var(--color-text-primary);'):
        require(marker in css, f'Missing generated bootstrap primitive: {marker}')
    # This checks only generated kit CSS. It is not an AST/CSS application linter.
    require(not re.search(r'prefers-color-scheme|light-dark\(', css), 'Multi-scheme generated CSS')
    code = policy['code']
    require(code['universalSource'] == 'AI_RULES.md', 'Wrong Universal source')
    require(code['universalVersion'] == '3.1', 'Unexpected Universal version')
    for key in ('oneEffectiveStackPerScope', 'preserveBrownfieldArchitecture',
                'publicContractsGenerated', 'resolvedModuleBoundariesRequired',
                'sharedFilesSingleActiveWriter', 'negativeGateTestsRequired'):
        require(code[key] is True, f'Coding invariant disabled: {key}')
    for key in ('projectRulesSource', 'codeStandardSource', 'bootstrapSource', 'universalIntegrityRef'):
        safe_file(root, code[key])
    refs = policy['governanceRefs']
    require(len(refs) == len(set(refs)) and len(refs) >= 3, 'Missing/duplicate governance refs')
    for ref in refs:
        safe_file(root, ref)
    origin = load(root, code['universalIntegrityRef'])
    universal = safe_file(root, origin['sourceFile'])
    require(origin['sourceFile'] == code['universalSource'], 'Universal source references differ')
    require(origin['sourceVersion'] == code['universalVersion'], 'Universal version references differ')
    digest = hashlib.sha256(universal.read_bytes()).hexdigest()
    require(digest == origin['sha256'], 'Universal byte integrity mismatch')
    require(origin['handling'] == 'BYTE_IDENTICAL_COPY_DO_NOT_CUSTOMIZE', 'Universal was customized')
    require(origin['companion']['status'] == 'NOT_PROVIDED_IN_THIS_UPDATE', 'Companion provenance changed')
    require(not (root/'PROJECT_BOOTSTRAP_PROMPT.txt').exists(),
            'New companion requires a provenance/version review; do not silently add it to this snapshot')
    evidence = policy['evidence']
    require(evidence['artifactScope'] == 'DOCUMENTATION_KIT_ONLY', 'Wrong evidence scope')
    for key in ('applicationCodeIncluded', 'repositoryCIConfigured',
                'repositoryMergeProtectionVerified', 'productionApproved'):
        require(evidence[key] is False, f'Unproven application claim: {key}')
    require(evidence['applicationTestExecution'] == 'NOT_RUN', 'False application test claim')
    codetext = safe_file(root, code['codeStandardSource']).read_text(encoding='utf-8')
    darktext = safe_file(root, theme['ruleSource']).read_text(encoding='utf-8')
    codeids = re.findall(r'^CODE-\d{3}(?= —)', codetext, re.MULTILINE)
    darkids = re.findall(r'^\| (DARK-\d{3}) \|', darktext, re.MULTILINE)
    require(len(codeids) == 24 and set(codeids) == {f'CODE-{i:03d}' for i in range(1,25)},
            'Coding rule definitions missing or duplicated')
    require(len(darkids) == 12 and set(darkids) == {f'DARK-{i:03d}' for i in range(1,13)},
            'Dark-only rule definitions missing or duplicated')
    gate_doc = load(root, 'governance/quality-gates.json')
    scenarios = load(root, 'governance/acceptance-scenarios.json')['cases']
    gates = gate_doc['gates']
    require(gate_doc['artifactKind'] == 'GATE_SPECIFICATION_NOT_REPOSITORY_ENFORCEMENT',
            'Gate snapshot misrepresents enforcement')
    gateids = [g['id'] for g in gates]
    caseids = [c['id'] for c in scenarios]
    require(len(gateids) == 16 and set(gateids) == {f'QG-{i:02d}' for i in range(1,17)}, 'Gate catalog incomplete/duplicated')
    require(len(caseids) == 24 and set(caseids) == {f'QA-{i:03d}' for i in range(1,25)}, 'Acceptance catalog incomplete/duplicated')
    for case in scenarios:
        require(case['executionStatus'] == 'NOT_RUN_PRODUCT_TEST', 'Acceptance spec is not a test result')
        require(bool(case['ruleIds']) and set(case['ruleIds']) <= set(codeids+darkids), 'Unknown/missing rule in scenario')
        require(bool(case['gateIds']) and set(case['gateIds']) <= set(gateids), 'Unknown/missing gate in scenario')
        for key in ('given', 'when', 'then', 'layer'):
            require(isinstance(case[key], str) and bool(case[key].strip()), f'Scenario missing {key}')
    for gate in gates:
        require(gate['status'] == 'CHƯA XÁC MINH' and gate['enforcementStage'] == 'SPECIFIED',
                'Snapshot must not claim repository execution/enforcement')
        require(gate['commands'] == [] and gate['evidence'] == [], 'Do not fabricate commands/results in the kit')
        require(gate['requiredWithinApplicableScope'] is True, 'Required gate was weakened')
        require(bool(gate['verificationLevels']) and set(gate['verificationLevels']) <= {f'V{i}' for i in range(5)}, 'Invalid verification level')
        require(bool(gate['appliesFromPhases']) and set(gate['appliesFromPhases']) <= {f'G{i}' for i in range(6)}, 'Invalid gate phase')
        expected = {c['id'] for c in scenarios if gate['id'] in c['gateIds']}
        require(bool(expected) and set(gate['scenarioIds']) == expected, 'Gate/scenario mapping drift')
        require(len(gate['scenarioIds']) == len(expected), 'Duplicate gate scenario')
        safe_file(root, gate['ruleSource'])
    for name in ('AGENTS.md', 'AI_RULES_PROJECT.md', 'PROJECT_BUILD_PROMPT_VI.txt', 'README_START_HERE.md'):
        safe_file(root, name)
    snippet = safe_file(root, 'templates/AGENTS_REPO_SNIPPET.md').read_text(encoding='utf-8')
    require(snippet.count('<!-- BOTSALES_RULES_START -->') == 1 and
            snippet.count('<!-- BOTSALES_RULES_END -->') == 1, 'Loader marker missing/duplicated')
    return {'status':'PASS_GOVERNANCE_DOCUMENTS_ONLY', 'kitVersion':'1.1',
            'universalVersion':'3.1', 'universalSha256':digest, 'codingRules':len(codeids),
            'darkRules':len(darkids), 'qualityGateSpecifications':len(gates),
            'governanceAcceptanceSpecifications':len(scenarios),
            'repositoryEnforcement':'NOT_CONFIGURED', 'applicationTests':'NOT_RUN'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.root), ensure_ascii=False, indent=2))
        return 0
    except (PolicyError, json.JSONDecodeError, KeyError, TypeError, IndexError, OSError, UnicodeError) as exc:
        print(f'FAIL_GOVERNANCE_DOCUMENTS: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
