#!/usr/bin/env python3
"""Validate documentation-kit structure with Python standard library only.
Not an application test, security audit or complete OpenAPI conformance validator.
Run from any directory. --root permits checking a copied/edited kit.
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
from decimal import Decimal

METHODS = {'get','put','post','delete','options','head','patch','trace'}
def load(root: Path, name: str):
    return json.loads((root/name).read_text(encoding='utf-8'))
def pointer(document, value: str):
    if not value.startswith('#/'):
        raise ValueError(f'Only local refs are allowed in this kit: {value}')
    node=document
    for part in value[2:].split('/'):
        part=part.replace('~1','/').replace('~0','~')
        node=node[int(part)] if isinstance(node,list) else node[part]
    return node
def walk_refs(node, document):
    count=0
    if isinstance(node,dict):
        if '$ref' in node:
            pointer(document,node['$ref']); count+=1
        for item in node.values(): count+=walk_refs(item,document)
    elif isinstance(node,list):
        for item in node: count+=walk_refs(item,document)
    return count

def luminance(h: str)->float:
    rgb=[int(h[i:i+2],16)/255 for i in (1,3,5)]
    rgb=[c/12.92 if c<=0.04045 else ((c+0.055)/1.055)**2.4 for c in rgb]
    return sum(c*w for c,w in zip(rgb,[0.2126,0.7152,0.0722]))
def contrast(a: str,b: str)->float:
    x,y=sorted([luminance(a),luminance(b)])
    return (y+0.05)/(x+0.05)
def kebab(s):return re.sub(r'(?<!^)([A-Z])',r'-\1',s).lower()

def validate(root: Path)->dict:
    required=['README_START_HERE.md','AI_RULES_PROJECT.md','PROJECT_BUILD_PROMPT_VI.txt',
      'contracts/openapi.yaml','design/tokens.css','fixtures/shop-seed.json',
      'templates/ADR_TEMPLATE.md','templates/TASK_TEMPLATE.md',
      'templates/CONTRACT_CHANGE_REQUEST.md','templates/HANDOFF_TEMPLATE.md','templates/RELEASE_EVIDENCE_TEMPLATE.md']
    for name in required:
        if not (root/name).is_file():raise ValueError('Missing file: '+name)
    docs=sorted((root/'docs').glob('[0-9][0-9]_*.md'))
    if {p.name[:2] for p in docs}!={f'{i:02d}' for i in range(21)}:raise ValueError('Expected docs/00 through docs/20')
    from validate_governance import validate as validate_governance
    governance_result = validate_governance(root)
    json_files=list(root.rglob('*.json'))
    for f in json_files: json.loads(f.read_text(encoding='utf-8'))
    api=load(root,'contracts/openapi.json'); schemas=api['components']['schemas']
    refs=walk_refs(api,api)
    e=load(root,'contracts/events.schema.json');refs+=walk_refs(e,e)
    event={k:v for k,v in e.items() if k not in ['$schema','$id','$defs']}
    event=json.loads(json.dumps(event).replace('#/$defs/Id','#/components/schemas/Id').replace('#/$defs/DateTime','#/components/schemas/DateTime'))
    if event!=schemas['EventEnvelope']:raise ValueError('Event contract drift')
    catalog=load(root,'contracts/permission-catalog.json')
    permissions={p['id'] for p in catalog['permissions']}
    if len(permissions)!=len(catalog['permissions']):raise ValueError('Duplicate permission')
    for role,perms in catalog['rolePresets'].items():
        if not set(perms)<=permissions:raise ValueError('Unknown permission in role '+role)
    ops={}
    for path,item in api['paths'].items():
        for method,op in item.items():
            if method not in METHODS:continue
            oid=op['operationId']
            if oid in ops:raise ValueError('Duplicate operationId: '+oid)
            ops[oid]={'path':path,'method':method,'operation':op}
            permission=op.get('x-permission')
            if permission and permission not in permissions:raise ValueError('Unknown op permission: '+oid)
            pars=[pointer(api,p['$ref']) if '$ref' in p else p for p in item.get('parameters',[])+op.get('parameters',[])]
            pnames={p['name'] for p in pars if p['in']=='path' and p.get('required')}
            if set(re.findall(r'\{([^}]+)\}',path))!=pnames:raise ValueError('Path parameter mismatch: '+oid)
            if len({(p['name'],p['in']) for p in pars})!=len(pars):raise ValueError('Duplicate parameter: '+oid)
            headers={p['name'] for p in pars if p['in']=='header' and p.get('required')}
            if method not in {'get','head','options'}:
                if 'X-CSRF-Token' not in headers:raise ValueError('Missing CSRF: '+oid)
                if oid not in {'login','logout','stepUp'} and 'Idempotency-Key' not in headers:raise ValueError('Missing idempotency: '+oid)
            if method in {'patch','delete'} and 'If-Match' not in headers:raise ValueError('Missing If-Match: '+oid)
    index=load(root,'contracts/operation-index.json')['operations']
    if {o['operationId'] for o in index}!=set(ops) or len(index)!=len(ops):raise ValueError('Operation index drift')
    for item in index:
        op=ops[item['operationId']]
        if any(op[k]!=item[k] for k in ['path','method']):raise ValueError('Operation index path/method drift')
        if op['operation'].get('x-permission')!=item['permission']:raise ValueError('Operation index permission drift')
        body=op['operation'].get('requestBody',{}).get('content',{})
        schema=next(iter(body.values()))['schema'].get('$ref','').split('/')[-1] if body else None
        if item['request']!=schema:raise ValueError('Operation request schema drift: '+item['operationId'])
    routes=load(root,'contracts/route-manifest.json');scenario_list=load(root,'fixtures/acceptance-scenarios.json')['scenarios']
    sc={s['id']:s for s in scenario_list}
    if len(sc)!=len(scenario_list):raise ValueError('Duplicate scenario')
    routeids=set();paths=set();frs=set();mapped=set(routes['globalOperations'])
    for r in routes['routes']:
        if r['id'] in routeids or r['path'] in paths:raise ValueError('Duplicate route')
        routeids.add(r['id']);paths.add(r['path']);frs.add(r['requirementId'])
        if r['readPermission'] and r['readPermission'] not in permissions:raise ValueError('Unknown route permission')
        ro=set(r['readOperations']);mapped|=ro
        if not ro<=set(ops):raise ValueError('Unknown route operation')
        for action in r['actions']:
            oid=action['operationId'];mapped.add(oid)
            if oid not in ops:raise ValueError('Unknown action operation: '+oid)
            if action['permission']!=ops[oid]['operation'].get('x-permission'):raise ValueError('Action permission mismatch')
        if not r['acceptanceScenarioIds'] or not set(r['acceptanceScenarioIds'])<=set(sc):raise ValueError('Invalid route scenarios')
        if not {'loading','empty','error','forbidden','stale_or_offline','success'}<=set(r['states']):raise ValueError('Missing route states')
    if mapped!=set(ops):raise ValueError('Unmapped or unknown operations: '+str(mapped^set(ops)))
    for s in scenario_list:
        if not set(s['operationIds'])<=set(ops):raise ValueError('Unknown scenario operation')
        if not set(s['requirementIds'])<=frs or not s['requirementIds']:raise ValueError('Invalid scenario requirement mapping')
        if s['executionStatus']!='NOT_RUN_PRODUCT_TEST':raise ValueError('Kit must not claim application tests executed')
    examples=load(root,'fixtures/api-examples.json')['cases']; exids=set()
    for x in examples:
        if x['id'] in exids:raise ValueError('Duplicate fixture ID')
        exids.add(x['id'])
        if x['schema'] not in schemas:raise ValueError('Unknown fixture schema')
        if x['operationId'] and x['operationId'] not in ops:raise ValueError('Unknown fixture operation')
    tokens=load(root,'design/tokens.json');colors=tokens['colors'];css=(root/'design/tokens.css').read_text()
    for k,v in colors.items():
        if f'--color-{kebab(k)}: {v};' not in css:raise ValueError('Token CSS drift: '+k)
    pairs=[]
    for fg in ['textPrimary','textSecondary','accent','success','warning','danger']:
        for bg in ['canvas','surface','raised']:pairs.append((fg,bg,4.5))
    pairs.extend([('onAccent','accent',4.5)])
    pairs.extend(('borderControl',bg,3.0) for bg in ['canvas','surface','raised'])
    ratios=[]
    for fg,bg,minimum in pairs:
        value=contrast(colors[fg],colors[bg]);ratios.append({'foreground':fg,'background':bg,'ratio':round(value,3),'minimum':minimum})
        if value<minimum:raise ValueError(f'Contrast {fg}/{bg}: {value:.2f} < {minimum}')
    seed=load(root,'fixtures/shop-seed.json');stock=seed['stock'][0];pl=seed['managerialReport'];cash=seed['cashflowReport']
    if stock['available']!=stock['onHand']-stock['reserved']:raise ValueError('Seed stock arithmetic')
    amount=lambda d,k:Decimal(d[k]['amount'])
    if amount(pl,'netSales')!=amount(pl,'grossSales')-amount(pl,'discounts')-amount(pl,'salesReturns'):raise ValueError('Seed sales arithmetic')
    if amount(pl,'grossProfit')!=amount(pl,'netSales')-amount(pl,'cogs'):raise ValueError('Seed profit arithmetic')
    if amount(cash,'netCashMovement')!=amount(cash,'receipts')-amount(cash,'disbursements'):raise ValueError('Seed cash arithmetic')
    manifest=root/'MANIFEST.sha256';hash_count=0
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest,name=line.split('  ',1);p=root/name
            if not p.resolve().is_relative_to(root.resolve()):raise ValueError('Unsafe manifest path')
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError('Checksum mismatch: '+name)
            hash_count+=1
    return {'status':'PASS_KIT_STRUCTURE_ONLY','jsonFiles':len(json_files),'documents':len(docs),'paths':len(api['paths']),'operations':len(ops),'schemas':len(schemas),'resolvedReferences':refs,'routes':len(routeids),'modules':len({r['module'] for r in routes['routes']}),'permissions':len(permissions),'rolePresets':len(catalog['rolePresets']),'acceptanceSpecifications':len(sc),'apiExamples':len(examples),'contrastPairs':ratios,'checkedChecksums':hash_count,'governance':governance_result,'applicationTests':'NOT_RUN'}

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);args=parser.parse_args()
    try: result=validate(args.root);print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ValueError,KeyError,IndexError,TypeError,OSError) as exc:
        print('FAIL_KIT: '+str(exc),file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
