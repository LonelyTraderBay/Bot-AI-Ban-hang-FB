#!/usr/bin/env python3
"""Self-tests for the kit validator only. Mutations use temporary copies.

No app tests are run; no source kit file is changed. Python standard library.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from validate_governance import PolicyError, validate

SOURCE = Path(__file__).resolve().parents[1]


class GovernanceValidatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix='botsales-policy-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'kit'
        shutil.copytree(SOURCE, self.root, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

    def mutate(self, file: str, change) -> None:
        path = self.root / file
        value = json.loads(path.read_text(encoding='utf-8'))
        change(value)
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

    def reject(self) -> None:
        with self.assertRaises((PolicyError, KeyError, TypeError)):
            validate(self.root)

    def change_theme(self, key, value) -> None:
        self.mutate('governance/project-policy.json', lambda p: p['theme'].__setitem__(key,value))
        self.reject()

    def test_valid_snapshot(self):
        result = validate(self.root)
        self.assertEqual(result['status'], 'PASS_GOVERNANCE_DOCUMENTS_ONLY')
        self.assertEqual(result['applicationTests'], 'NOT_RUN')

    def test_system_mode_rejected(self): self.change_theme('defaultMode','system')
    def test_multiple_modes_rejected(self): self.change_theme('availableModes',['dark','light'])
    def test_toggle_rejected(self): self.change_theme('allowThemeToggle',True)
    def test_os_preference_rejected(self): self.change_theme('useSystemPreference',True)
    def test_persistence_rejected(self): self.change_theme('persistThemePreference',True)
    def test_accessibility_disabled_rejected(self): self.change_theme('allowAccessibilityOverrides',False)
    def test_duplicate_palettes_rejected(self): self.change_theme('allowMultipleAppPalettes',True)

    def test_missing_required_source_rejected(self):
        (self.root/'docs/18_CODING_STANDARDS.md').unlink()
        self.reject()

    def test_universal_mutation_rejected(self):
        p=self.root/'AI_RULES.md';p.write_bytes(p.read_bytes()+b'\nChanged\n')
        self.reject()

    def test_false_ci_claim_rejected(self):
        self.mutate('governance/project-policy.json',lambda p:p['evidence'].__setitem__('repositoryCIConfigured',True))
        self.reject()

    def test_false_production_claim_rejected(self):
        self.mutate('governance/project-policy.json',lambda p:p['evidence'].__setitem__('productionApproved',True))
        self.reject()

    def test_false_gate_pass_rejected(self):
        self.mutate('governance/quality-gates.json',lambda p:p['gates'][0].__setitem__('status','ĐẠT'))
        self.reject()

    def test_unknown_rule_rejected(self):
        self.mutate('governance/acceptance-scenarios.json',lambda p:p['cases'][0].__setitem__('ruleIds',['CODE-999']))
        self.reject()

    def test_missing_test_case_rejected(self):
        self.mutate('governance/acceptance-scenarios.json',lambda p:p['cases'].pop())
        self.reject()

    def test_zero_cases_rejected(self):
        self.mutate('governance/acceptance-scenarios.json',lambda p:p.__setitem__('cases',[]))
        self.reject()

    def test_mismatched_gate_case_rejected(self):
        self.mutate('governance/quality-gates.json',lambda p:p['gates'][0].__setitem__('scenarioIds',[]))
        self.reject()

    def test_missing_bootstrap_css_rejected(self):
        p=self.root/'design/tokens.css'
        p.write_text(p.read_text().replace('background-color: var(--color-canvas);',''),encoding='utf-8')
        self.reject()

    def test_escaped_source_path_rejected(self):
        self.mutate('governance/project-policy.json',lambda p:p['code'].__setitem__('bootstrapSource','../outside.md'))
        self.reject()

    def test_duplicate_json_key_rejected(self):
        p=self.root/'governance/project-policy.json'
        p.write_text(p.read_text().replace('"kitVersion": "1.1",','"kitVersion": "1.1", "kitVersion": "1.1",',1))
        self.reject()

    def test_valid_color_shade_word_not_blanket_rejected(self):
        p=self.root/'docs/19_DARK_ONLY_POLICY.md'
        p.write_text(p.read_text()+'\nMUI primary.light là sắc độ, không theme mode.\n',encoding='utf-8')
        self.assertEqual(validate(self.root)['status'],'PASS_GOVERNANCE_DOCUMENTS_ONLY')

    def test_cli_nonzero_on_malformed_json(self):
        (self.root/'governance/project-policy.json').write_text('{invalid json',encoding='utf-8')
        result=subprocess.run([sys.executable,str(SOURCE/'scripts/validate_governance.py'),
                               '--root',str(self.root)],capture_output=True,text=True,check=False)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('FAIL_GOVERNANCE_DOCUMENTS',result.stderr)

    def test_cli_nonzero_on_missing_source(self):
        (self.root/'AI_RULES.md').unlink()
        result=subprocess.run([sys.executable,str(SOURCE/'scripts/validate_governance.py'),
                               '--root',str(self.root)],capture_output=True,text=True,check=False)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('FAIL_GOVERNANCE_DOCUMENTS',result.stderr)


if __name__=='__main__':
    unittest.main(verbosity=2)
