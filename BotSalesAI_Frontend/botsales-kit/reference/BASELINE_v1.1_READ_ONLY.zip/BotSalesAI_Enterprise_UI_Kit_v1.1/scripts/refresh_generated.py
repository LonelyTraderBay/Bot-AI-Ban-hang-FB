#!/usr/bin/env python3
"""Regenerate mirrors from canonical OpenAPI YAML and design tokens.
Requires PyYAML. Does not change business requirements or route/scenario mappings.
Run validators after regeneration. --manifest explicitly refreshes integrity hashes.
"""
from __future__ import annotations
import argparse,hashlib,json,re,sys
from pathlib import Path
try:import yaml
except ImportError:
    print('Install optional scripts/requirements-validation.txt first',file=sys.stderr);sys.exit(2)
R=Path(__file__).resolve().parents[1]
def write_json(path,data):(R/path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def kebab(s):return re.sub(r'(?<!^)([A-Z])',r'-\1',s).lower()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',action='store_true');args=p.parse_args()
    a=yaml.safe_load((R/'contracts/openapi.yaml').read_text(encoding='utf-8'))
    write_json('contracts/openapi.json',a)
    ops=[]
    for path,item in a['paths'].items():
        for method,op in item.items():
            if method not in {'get','put','post','delete','options','head','patch','trace'}:continue
            codes=sorted(k for k in op['responses'] if k.startswith('2'))
            code=codes[0] if codes else None
            body=op.get('requestBody',{}).get('content',{})
            req=next(iter(body.values()))['schema'].get('$ref','').split('/')[-1] if body else None
            response=op['responses'][code].get('content',{}).get('application/json',{}).get('schema',{}) if code else {}
            resource=None
            if '$ref' in response:
                wrapper=a['components']['schemas'][response['$ref'].split('/')[-1]]
                data=wrapper['properties']['data'];data=data.get('items',data)
                resource=data.get('$ref','').split('/')[-1] or None
            ops.append({'operationId':op['operationId'],'path':path,'method':method,'permission':op.get('x-permission'),'resource':resource,'request':req,'code':code})
    write_json('contracts/operation-index.json',{'version':'1.0','generatedFrom':'openapi.yaml','operations':ops})
    ev={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:botsales:events:1',**a['components']['schemas']['EventEnvelope'],'$defs':{k:a['components']['schemas'][k] for k in ['Id','DateTime']}}
    ev=json.loads(json.dumps(ev).replace('#/components/schemas/Id','#/$defs/Id').replace('#/components/schemas/DateTime','#/$defs/DateTime'))
    write_json('contracts/events.schema.json',ev)
    t=json.loads((R/'design/tokens.json').read_text(encoding='utf-8'))
    lines=['/* Generated from tokens.json. Do not edit independently. */',':root {','  color-scheme: dark;']
    lines.extend(f'  --color-{kebab(k)}: {v};' for k,v in t['colors'].items())
    lines.append(f"  --font-family: {t['fontFamily']};")
    for group,prefix,unit in [('fontSizes','font-size','px'),('space','space','px'),('radius','radius','px'),('layout','layout','px'),('motion','motion','ms'),('zIndex','z','')]:
        lines.extend(f'  --{prefix}-{kebab(k)}: {v}{unit};' for k,v in t[group].items())
    lines+=['}','html, body, #root {','  min-height: 100%;','  background-color: var(--color-canvas);','  color: var(--color-text-primary);','}','body { margin: 0; }','@media (prefers-reduced-motion: reduce) {','  :root { --motion-fast-ms: 0ms; --motion-standard-ms: 0ms; }','}']
    (R/'design/tokens.css').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    if args.manifest:
        files=sorted(f for f in R.rglob('*') if f.is_file() and f.name!='MANIFEST.sha256' and '__pycache__' not in f.parts and f.suffix!='.pyc')
        lines=[hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(R).as_posix() for f in files]
        (R/'MANIFEST.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('Regenerated JSON/operation/event/CSS mirrors. Run validate_kit.py and validate_schemas.py; product tests remain separate.')
if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,TypeError,OSError,yaml.YAMLError) as e:print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)
