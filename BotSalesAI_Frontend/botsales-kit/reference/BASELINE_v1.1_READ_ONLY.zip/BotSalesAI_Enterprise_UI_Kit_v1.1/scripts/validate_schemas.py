#!/usr/bin/env python3
"""Validate JSON Schema syntax and curated fixtures, plus YAML/JSON equality.
Requires the optional packages in requirements-validation.txt.
This is not a complete OpenAPI specification-validator or an application test.
"""
from pathlib import Path
import json, sys
try:
    import yaml
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError:
    print('Missing optional dependencies: install scripts/requirements-validation.txt',file=sys.stderr)
    sys.exit(2)
R=Path(__file__).resolve().parents[1]
try:
    api=json.loads((R/'contracts/openapi.json').read_text(encoding='utf-8'))
    if yaml.safe_load((R/'contracts/openapi.yaml').read_text(encoding='utf-8'))!=api:raise ValueError('OpenAPI YAML/JSON drift')
    schemas=api['components']['schemas']
    for name,schema in schemas.items():Draft202012Validator.check_schema(schema)
    event=json.loads((R/'contracts/events.schema.json').read_text(encoding='utf-8'))
    Draft202012Validator.check_schema(event)
    cases=json.loads((R/'fixtures/api-examples.json').read_text(encoding='utf-8'))['cases']
    results=[]
    for c in cases:
        root={'$ref':'#/components/schemas/'+c['schema'],'components':api['components']}
        errors=list(Draft202012Validator(root,format_checker=FormatChecker()).iter_errors(c['value']))
        actual_valid=not errors
        if actual_valid!=c['expectedValid']:
            raise ValueError(c['id']+': '+ ('unexpected acceptance' if actual_valid else '; '.join(e.message for e in errors)))
        results.append({'id':c['id'],'status':'PASS','expectedValid':c['expectedValid']})
    print(json.dumps({'status':'PASS_SCHEMA_SYNTAX_AND_FIXTURES','schemaDefinitions':len(schemas),'yamlJsonEqual':True,'validExamples':sum(c['expectedValid'] for c in cases),'negativeExamplesRejected':sum(not c['expectedValid'] for c in cases),'fixtureResults':results,'completeOpenApiConformanceValidation':'NOT_RUN','applicationTests':'NOT_RUN'},indent=2))
except Exception as exc:
    print('FAIL_SCHEMA: '+str(exc),file=sys.stderr);sys.exit(1)
