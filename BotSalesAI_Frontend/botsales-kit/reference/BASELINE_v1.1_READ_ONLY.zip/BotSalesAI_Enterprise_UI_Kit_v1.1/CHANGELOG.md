# Thay đổi 1.0 → 1.1 — 29/09/2026

## Đầu vào
Yêu cầu mới của Jokertrader: khóa dark từ đầu, không code nhiều loại theme, và bổ
sung quy định code/AI thống nhất. AI_RULES.md 3.1 được đính kèm và giữ nguyên byte.

## Bổ sung và cập nhật
Bổ sung AI_RULES.md nguyên bản, AGENTS.md điểm vào phạm vi kit, docs/18–20,
governance policy/hash/16 gate/24 case, root-loader snippet và validator có self-test.
Cập nhật project rules, prompt code, README, provenance, kiến trúc, design system,
kiểm thử, phối hợp, backlog T01–T03, nguồn tham khảo và templates bàn giao.
Token JSON vẫn đúng bảng màu dark cũ; generator thêm nền/color bootstrap từ token.
PDF hướng dẫn và bản Markdown tổng hợp được sinh lại cho 1.1.

## Giữ nguyên
HTTP API, 116 operations, data models, 36 routes, 34 permissions, 55 scenario nghiệp
vụ và mục tiêu 23 task; không thay endpoint nghiệp vụ để thêm theme setting.
Các file không bị ảnh hưởng giữ version nội dung 1.0; kit có version phát hành 1.1.
Không sửa Universal, không dựng bản giả PROJECT_BOOTSTRAP_PROMPT.txt.

## Tình trạng thực tế
Đã chuẩn bị đặc tả và công cụ kiểm bộ tài liệu. Chưa có repo ứng dụng được chỉnh,
chưa cài loader/CI/branch protection, chưa có browser tests hoặc backend staging.
Bằng chứng chính xác của kiểm kit nằm tại evidence/KIT_VALIDATION_REPORT.md.
Kit này không là migration tự động; áp dụng lên repo đã có phải giữ tùy chỉnh và
đối chiếu nguồn trước ghi, không overwrite nguyên docs/AGENTS/AI_RULES đang dùng.
