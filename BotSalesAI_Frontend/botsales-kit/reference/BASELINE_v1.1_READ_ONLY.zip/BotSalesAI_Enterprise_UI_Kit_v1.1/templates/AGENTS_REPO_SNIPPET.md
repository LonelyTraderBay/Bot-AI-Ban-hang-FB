# Block tham chiếu để AI tích hợp vào nguồn instructions của repo

Đây là TEMPLATE, không phải file instructions đã được cài. AI kiểm vị trí kit,
nguồn instructions có hiệu lực và quyền ghi trước khi dùng. Mặc định kit ở
`docs/botsales-blueprint/`; AI tự thay đường dẫn trong block dự án, không sửa Universal.
Giữ mọi chỉ dẫn có sẵn, thêm đúng một block (hoặc sửa block này khi path thay đổi).
Không tạo AGENTS.md mới nếu công cụ đang dùng có điểm vào phù hợp khác.

```markdown
<!-- BOTSALES_RULES_START -->
## BotSales AI: nguồn chuẩn cho công việc thuộc dự án này
Đọc docs/botsales-blueprint/README_START_HERE.md;
hai phần LUÔN ĐỌC của nguồn AI_RULES.md Universal 3.1 đã tiếp nhận;
docs/botsales-blueprint/AI_RULES_PROJECT.md;
docs/botsales-blueprint/docs/18_CODING_STANDARDS.md;
docs/botsales-blueprint/docs/19_DARK_ONLY_POLICY.md;
docs/botsales-blueprint/docs/20_AI_BOOTSTRAP_AND_ENFORCEMENT.md.
Sau đó đọc hồ sơ/task còn hiệu lực và contract của module liên quan.
UI chỉ dark; không thêm light/system/toggle. Không thay Universal theo repo.
Không tự nâng phiên bản quy tắc, đổi stack hoặc tác động production.
<!-- BOTSALES_RULES_END -->
```

Nếu Universal hiệu lực nằm tại root, ghi chính xác ref đó trong hồ sơ; bản trong
kit là snapshot phân phối. Không đặt hai bộ Universal khác nhau cùng hiệu lực.
Kiểm file/path thật, scope áp dụng và cơ chế đọc của đúng công cụ đang dùng.
