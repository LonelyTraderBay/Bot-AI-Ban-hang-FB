# CCR-<ID> — <Thay đổi contract>
Status: PROPOSED. Requested by: <lane>. Integrator: <owner>.

Current source/version/operation: <paths+IDs>. Consumer modules: <list>.
Business reason: <need>. Proposed diff: <exact request/response/enum/permission change>.
Compatibility: ADDITIVE | BREAKING; giải thích unknown fields/enums và N/N-1.
Data/privacy/cost risks: <details>. Migration/rollback: <steps>.
Fixtures/scenarios cần cập nhật: <IDs>. Generated outputs cần sinh lại: <paths>.
Approval/evidence: <owner/date/log>. Không tự sửa cả schema và consumer trước review khi breaking.
