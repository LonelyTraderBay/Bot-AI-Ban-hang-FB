# Release evidence — <release ID>
Commit/build/environment/date: <values>. Requested level: UI_MOCK_VERIFIED | INTEGRATED_VERIFIED | PRODUCTION.
Release owner/reviewer: <roles>. Chưa có evidence: NOT_RUN, không để ngầm hiểu PASS.

| Gate | Required evidence | Status | Evidence path/owner |
|---|---|---|---|
| G0 | Repo inventory, toolchain pin, compatibility decisions | NOT_RUN | |
| G1 | CI, illegal-import tests, product slice, scope isolation | NOT_RUN | |
| G2/G3 | Route state coverage, acceptance, security UI, i18n/a11y/budgets | NOT_RUN | |
| G4 | Real backend contract/auth/transactions/races/recovery | NOT_RUN | |
| G4 channels | Current Meta policy/app review, provider data/cost controls | NOT_RUN | |
| G5 | UAT, restore drill, rollback rehearsal, incident ownership | NOT_RUN | |

Unresolved risks/exceptions and expiry: <details>. Rollback target/runbook: <values>.
Actual approval by authorized human/date: <not pre-approved>. Production deploy permission: <explicit scope>.

## Bổ sung governance 1.1

Rules source/version/hash; loader thực tế và phạm vi: <chưa xác minh>.
CODE/DARK/QG áp dụng: <IDs>. Gate stage: SPECIFIED / CONFIGURED / EXECUTED / ENFORCED.
Test âm đã chạy: <command, revision, exit code, report>. Không có code/test: CHƯA XÁC MINH.

Trạng thái nghiệm thu chuẩn: ĐẠT / CHƯA ĐẠT / CHƯA XÁC MINH / KHÔNG ÁP DỤNG có lý do.
Không dùng NOT_RUN, thiếu suite, check bị skip hoặc thiếu branch protection như PASS.
