# TASK-<ID> — <Một hành vi có thể nghiệm thu>
Status: READY | IN_PROGRESS | BLOCKED | IN_REVIEW | MERGED
Owner/lane: <owner>. Base revision: <commit>. Dependencies: <task/contract versions>.

## Mục tiêu và phạm vi
User outcome; FR/route/SC IDs; file allowlist; files không được sửa; non-goals.

## Inputs tối thiểu
Docs sections, API operation/schema IDs, permissions, tokens và fixtures. Không nạp nghiên cứu không liên quan.

## Acceptance
Happy path, validation/error/permission/conflict/loading/empty; responsive/keyboard; side effect constraints.

## Kiểm chứng và bàn giao
Lệnh dự kiến; evidence paths; migration/rollback nếu có; owner của shared-file change. Khi thiếu contract mở CHANGE_REQUEST thay vì đoán.

## Căn cứ quy tắc 1.1

Universal source/version/hash: <AI tự lấy từ nguồn thực>.
CODE/DARK/QG IDs liên quan: <IDs>.
Mức V0–V4 theo rủi ro; gate cần có ca sai: <details>.
Shared writer/assignment_ref thực; loader scope: <details khi liên quan>.
Không sao chép toàn bộ luật vào mỗi task. Dùng trường tương đương trong tracker hiện hữu.
