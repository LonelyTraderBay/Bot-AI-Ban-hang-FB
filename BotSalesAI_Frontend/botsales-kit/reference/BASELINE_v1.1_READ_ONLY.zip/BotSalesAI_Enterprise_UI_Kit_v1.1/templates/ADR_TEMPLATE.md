# ADR-<ID> — <Quyết định>
Status: PROPOSED | APPROVED | SUPERSEDED. Owner: <role>. Date: <date>. Scope: <modules>.

## Bằng chứng và vấn đề
Nguồn repo/file/commit, constraints, decision liên quan; phân biệt OBSERVED/UNKNOWN.

## Các phương án và lựa chọn
Ít nhất lựa chọn hiện tại và lựa chọn thay thế; trade-offs về complexity, cost, data, operations. Vì sao thay đổi cần thiết?

## Contract, migration và rollout
API/schema/permission/tokens affected; N/N-1 compatibility, data migration, flags, rollback path và negative tests.

## Chấp thuận và evidence
Người duyệt/thời điểm; test IDs, kết quả thật; unresolved risks. Không điền APPROVED thay chủ dự án.
