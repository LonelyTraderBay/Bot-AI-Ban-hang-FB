# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: states/route-role-ready-composition.spec.ts >> ready route content renders for every role granted read access by the canonical contract >> ready route content for accountant
- Location: tests/states/route-role-ready-composition.spec.ts:59:9

# Error details

```
Error: R53 should explain when retained data may be stale for accountant

expect(locator).toBeVisible() failed

Locator: locator('main#main-content').getByText(/có thể đã cũ/i).first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - R53 should explain when retained data may be stale for accountant locator('main#main-content').getByText(/có thể đã cũ/i).first() with timeout 15000ms
  - waiting for locator('main#main-content').getByText(/có thể đã cũ/i).first()

```

```yaml
- link "Đến nội dung chính":
  - /url: "#main-content"
- navigation "Điều hướng chính":
  - heading "BotSales AI" [level=6]
  - text: Đội ngũ vận hành cửa hàng
  - link "Joker Studio · Shop mẫu ⌄":
    - /url: /workspaces
  - text: ĐIỀU HÀNH
  - list:
    - listitem:
      - link "Công việc hôm nay":
        - /url: /s/shop-demo/operations
        - paragraph: Công việc hôm nay
    - listitem:
      - link "Cần phê duyệt":
        - /url: /s/shop-demo/approvals
        - paragraph: Cần phê duyệt
  - text: BÁN HÀNG
  - list:
    - listitem:
      - link "Đơn hàng":
        - /url: /s/shop-demo/orders
        - paragraph: Đơn hàng
    - listitem:
      - link "Đổi trả":
        - /url: /s/shop-demo/returns
        - paragraph: Đổi trả
  - text: KẾ TOÁN
  - list:
    - listitem:
      - link "Thu chi":
        - /url: /s/shop-demo/finance
        - paragraph: Thu chi
    - listitem:
      - link "Sổ thu chi":
        - /url: /s/shop-demo/finance/entries
        - paragraph: Sổ thu chi
    - listitem:
      - link "Lợi nhuận":
        - /url: /s/shop-demo/finance/profit-loss
        - paragraph: Lợi nhuận
    - listitem:
      - link "Chứng từ & sổ kép":
        - /url: /s/shop-demo/finance/journals
        - paragraph: Chứng từ & sổ kép
    - listitem:
      - link "Tài khoản kế toán":
        - /url: /s/shop-demo/finance/accounts
        - paragraph: Tài khoản kế toán
    - listitem:
      - link "Mở sổ kế toán":
        - /url: /s/shop-demo/finance/opening-balances
        - paragraph: Mở sổ kế toán
    - listitem:
      - link "Sổ cái":
        - /url: /s/shop-demo/finance/ledger
        - paragraph: Sổ cái
    - listitem:
      - link "Cân đối phát sinh":
        - /url: /s/shop-demo/finance/trial-balance
        - paragraph: Cân đối phát sinh
    - listitem:
      - link "Cân đối quản trị":
        - /url: /s/shop-demo/finance/balance-sheet
        - paragraph: Cân đối quản trị
    - listitem:
      - link "Đối soát":
        - /url: /s/shop-demo/finance/reconciliation
        - paragraph: Đối soát
    - listitem:
      - link "Công nợ & khóa kỳ":
        - /url: /s/shop-demo/finance/debts-periods
        - paragraph: Công nợ & khóa kỳ
  - text: ĐỘI NGŨ AI
  - list:
    - listitem:
      - link "Bản tin & sức khỏe":
        - /url: /s/shop-demo/operations/digests
        - paragraph: Bản tin & sức khỏe
  - text: THÔNG BÁO & BÁO CÁO
  - list:
    - listitem:
      - link "Xuất báo cáo":
        - /url: /s/shop-demo/reports
        - paragraph: Xuất báo cáo
    - listitem:
      - link "Thông tin marketing":
        - /url: /s/shop-demo/reports/marketing
        - paragraph: Thông tin marketing
  - text: CÀI ĐẶT
  - list:
    - listitem:
      - link "Nhật ký":
        - /url: /s/shop-demo/settings/audit
        - paragraph: Nhật ký
  - separator
  - text: J
  - paragraph: Jokertrader · tài khoản mẫu
  - text: Kế toán
  - button "Đăng xuất"
- banner:
  - navigation "Đường dẫn hiện tại": Không gian làm việc / Thông tin hỗ trợ marketing
  - textbox "Tìm màn hình":
    - /placeholder: Tìm màn hình...
  - text: Dữ liệu mô phỏng
  - link "Thông báo":
    - /url: /s/shop-demo/notifications
  - text: J
- alert:
  - text: "Frontend review: API được mô phỏng trong bộ nhớ, không gửi tin hoặc đặt hàng thật. Tải lại trang sẽ khởi tạo lại dữ liệu."
  - button "Góp ý"
- button "Ẩn công cụ demo" [expanded]
- text: "Thử giao diện: Vai trò mô phỏng"
- combobox "Vai trò mô phỏng Vai trò mô phỏng": accountant
- text: Trạng thái thử
- combobox "Trạng thái thử Trạng thái thử": Lỗi API kéo dài
- text: Dataset mô phỏng
- combobox "Dataset mô phỏng Dataset mô phỏng": Dataset mặc định
- status: Trạng thái thử đã được áp dụng.
- main:
  - heading "Thông tin cho marketing" [level=1]
  - paragraph: Đề xuất chỉ đọc; trang không tự đăng nội dung hoặc thay đổi ngân sách.
  - alert: Số liệu mẫu do API mô phỏng tổng hợp; chưa kết nối tài khoản quảng cáo hoặc nguồn phân bổ thật.
  - heading "Khoảng thời gian báo cáo" [level=2]
  - paragraph: Ngày được tính theo lịch Asia/Vientiane của cửa hàng.
  - text: Từ ngày
  - textbox "Từ ngày": 2026-08-31
  - paragraph: Ngày bắt đầu, tính cả ngày đã chọn.
  - text: Đến ngày
  - textbox "Đến ngày": 2026-09-29
  - paragraph: Tối đa 366 ngày, tính cả hai đầu.
  - text: Gộp theo
  - combobox "Gộp theo Ngày": Ngày
  - paragraph: Chọn ngày, tuần hoặc tháng.
  - button "Áp dụng"
  - alert:
    - text: Không thể hoàn thành yêu cầu API mô phỏng đang lỗi liên tục. Đổi “Trạng thái thử” về bình thường rồi thử lại.
    - button "Thử lại"
- contentinfo:
  - text: BotSales AI · Graphite Gold · Frontend
  - button "Góp ý màn hình"
```

# Test source

```ts
  29  | }
  30  | 
  31  | function canRead(route: Route, role: string) {
  32  |     return route.readPermission === null || permissionCatalog.rolePresets[role].includes(route.readPermission);
  33  | }
  34  | 
  35  | async function chooseRole(page: import('@playwright/test').Page, role: string) {
  36  |     if (role === 'owner') return;
  37  |     await openDemoControls(page);
  38  |     await page.getByRole('combobox', { name: 'Vai trò mô phỏng' }).click();
  39  |     await page.getByRole('option', { name: role, exact: true }).click();
  40  |     await expect(page.getByRole('status').filter({ hasText: 'Vai trò mô phỏng đã được áp dụng.' })).toBeVisible();
  41  |     await expect(page.getByRole('combobox', { name: 'Vai trò mô phỏng' })).toHaveText(role);
  42  | }
  43  | 
  44  | let demoUrl = '';
  45  | let stopDemo: (() => Promise<void>) | undefined;
  46  | 
  47  | test.beforeAll(async () => {
  48  |     const server = await startDemoServer();
  49  |     demoUrl = server.url;
  50  |     stopDemo = server.close;
  51  | });
  52  | 
  53  | test.afterAll(async () => {
  54  |     await stopDemo?.();
  55  | });
  56  | 
  57  | test.describe('ready route content renders for every role granted read access by the canonical contract', () => {
  58  |     for (const role of roles) {
  59  |         test(`ready route content for ${role}`, async ({ page }) => {
  60  |             test.setTimeout(600_000);
  61  |             // A real shop-midnight rollover changes date-based query keys between the two walks.
  62  |             // Keep timers advancing from a stable midday fixture so staleTime still expires.
  63  |             await page.clock.install({ time: new Date('2026-10-23T05:00:00Z') });
  64  |             const browser = test.info().project.name;
  65  |             const browserVersion = page.context().browser()?.version() || 'unknown';
  66  |             console.log(`BROWSER=${browser} VERSION=${browserVersion}`);
  67  |             const pageErrors: string[] = [];
  68  |             page.on('pageerror', error => pageErrors.push(error.message));
  69  |             const operationStatuses = new Map<string, number>();
  70  |             page.on('response', response => {
  71  |                 const pathname = new URL(response.url()).pathname;
  72  |                 const operation = Object.entries(operationPathPatterns).find(([, pattern]) => pattern.test(pathname))?.[0];
  73  |                 if (operation) operationStatuses.set(operation, response.status());
  74  |             });
  75  |             const readableRoutes = privateRoutes.filter(route => canRead(route, role));
  76  |             await page.goto(new URL('/s/shop-demo/notifications', demoUrl).toString());
  77  |             await chooseRole(page, role);
  78  |             await openDemoControls(page);
  79  |             await page.getByRole('combobox', { name: 'Trạng thái thử' }).click();
  80  |             await page.getByRole('option', { name: 'Bình thường', exact: true }).click();
  81  | 
  82  |             for (const route of readableRoutes) {
  83  |                 await page.evaluate(nextPath => {
  84  |                     window.history.pushState({}, '', nextPath);
  85  |                     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }));
  86  |                 }, routePath(route.path));
  87  |                 const main = page.locator('main#main-content');
  88  |                 await expect(main, `${route.id} should render for ${role}`).toBeVisible();
  89  |                 await expect(main.getByRole('heading').first(), `${route.id} should expose route content for ${role}`).toBeVisible();
  90  |                 await expect.poll(() => new URL(page.url()).pathname, { message: `${route.id} should become the active router location for ${role}` }).toBe(routePath(route.path));
  91  |                 await expect.poll(() => page.title(), { message: `${route.id} should update canonical route metadata for ${role}` }).toBe(`${route.title} · BotSales AI`);
  92  |                 const primaryOperation = route.readOperations[0];
  93  |                 await expect.poll(() => operationStatuses.has(primaryOperation), { message: `${route.id} should complete ${primaryOperation} before state changes for ${role}` }).toBe(true);
  94  |                 await expect(main.getByText(/Đang tải/), `${route.id} should settle its visible loading state for ${role}`).toHaveCount(0, { timeout: 10_000 });
  95  |                 await expect(main.getByRole('heading', { name: 'Không thể mở màn hình', exact: true }), `${route.id} should not fall through to the route error boundary for ${role}`).toHaveCount(0);
  96  |                 const primaryStatus = operationStatuses.get(primaryOperation);
  97  |                 if (primaryStatus === 200) {
  98  |                     console.log(`BROWSER=${browser} ROLE_STATE=success ROLE=${role} ROUTE=${route.id} RESULT=PASS`);
  99  |                 }
  100 |                 else if (noSeedJobRoutes.has(route.id) && primaryOperation === 'getJob' && primaryStatus === 404) {
  101 |                     console.log(`BROWSER=${browser} ROLE_STATE_NA=success ROLE=${role} ROUTE=${route.id} REASON=mock-no-resource-404 RESULT=PASS`);
  102 |                 }
  103 |                 else {
  104 |                     throw new Error(`${route.id} expected a successful primary read for ${role}; ${primaryOperation} returned HTTP ${primaryStatus}`);
  105 |                 }
  106 |             }
  107 |             expect(pageErrors).toEqual([]);
  108 |             const readyRoutes = readableRoutes.filter(route => !noSeedJobRoutes.has(route.id));
  109 |             const noSeedRoutes = readableRoutes.filter(route => noSeedJobRoutes.has(route.id));
  110 |             console.log(`ROLE_READY_COMPOSITION=${role}:${readyRoutes.length}/${readyRoutes.length} RESULT=PASS`);
  111 |             if (noSeedRoutes.length)
  112 |                 console.log(`ROLE_READY_NOT_APPLICABLE=${role}:${noSeedRoutes.map(route => route.id).join(',')} REASON=mock-no-resource-404`);
  113 | 
  114 |             const routeOwnedData = readableRoutes.filter(route => route.id !== 'R33' && !noSeedJobRoutes.has(route.id));
  115 |             await openDemoControls(page);
  116 |             await page.getByRole('combobox', { name: 'Trạng thái thử' }).click();
  117 |             await page.getByRole('option', { name: 'Lỗi API kéo dài', exact: true }).click();
  118 |             await expect(page.getByRole('status').filter({ hasText: 'Trạng thái thử đã được áp dụng.' })).toBeVisible();
  119 |             // useApi owns a 5-second staleTime; let every cached route query cross it before remounting.
  120 |             await page.clock.fastForward(5_200);
  121 |             for (const route of routeOwnedData) {
  122 |                 await page.evaluate(nextPath => {
  123 |                     window.history.pushState({}, '', nextPath);
  124 |                     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }));
  125 |                 }, routePath(route.path));
  126 |                 const main = page.locator('main#main-content');
  127 |                 await expect.poll(() => page.title(), { message: `${route.id} should remain the active route while showing stale data for ${role}` }).toBe(`${route.title} · BotSales AI`);
  128 |                 await expect(main.getByRole('heading').first(), `${route.id} should retain its loaded content for ${role}`).toBeVisible();
> 129 |                 await expect(main.getByText(/có thể đã cũ/i).first(), `${route.id} should explain when retained data may be stale for ${role}`).toBeVisible({ timeout: 15_000 });
      |                                                                                                                                                 ^ Error: R53 should explain when retained data may be stale for accountant
  130 |                 console.log(`BROWSER=${browser} ROLE_STATE=stale_or_offline ROLE=${role} ROUTE=${route.id} RESULT=PASS`);
  131 |             }
  132 |             if (role === 'owner' && readableRoutes.some(route => route.id === 'R33'))
  133 |                 console.log(`BROWSER=${browser} ROLE_STATE_NA=stale_or_offline ROLE=owner ROUTE=R33 REASON=shared-shell-snapshot RESULT=PASS`);
  134 |             for (const route of readableRoutes.filter(route => noSeedJobRoutes.has(route.id))) {
  135 |                 const status = operationStatuses.get(route.readOperations[0]);
  136 |                 if (status !== 404) throw new Error(`${route.id} requires a seeded job for stale data; expected fixture HTTP 404, received ${status}`);
  137 |                 console.log(`BROWSER=${browser} ROLE_STATE_NA=stale_or_offline ROLE=${role} ROUTE=${route.id} REASON=mock-no-resource-404 RESULT=PASS`);
  138 |             }
  139 |             expect(pageErrors).toEqual([]);
  140 |         });
  141 |     }
  142 | });
  143 | 
```