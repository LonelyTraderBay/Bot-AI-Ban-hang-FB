# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fe010.spec.ts >> product editor validates positive prices, protects image-only drafts, and saves variant payload through mock HTTP
- Location: tests/fe010.spec.ts:40:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/s\/shop-demo\/products(?:\?.*)?$/
Received string:  "http://127.0.0.1:43705/s/shop-demo/products/product-10006"
Timeout: 30000ms

Call log:
  - Expect "toHaveURL" with timeout 30000ms
    63 × locator resolved to <html lang="vi">…</html>
       - unexpected value "http://127.0.0.1:43705/s/shop-demo/products/product-10006"

```

```yaml
- link "Đến nội dung chính":
  - /url: "#main-content"
- navigation "Điều hướng chính":
  - heading "BotSales AI" [level=6]
  - text: Đội ngũ vận hành cửa hàng
  - link "Joker Studio · Shop mẫu ⌄":
    - /url: /workspaces
  - text: ĐIỀU HÀNH
  - list:
    - listitem:
      - link "Tổng quan":
        - /url: /s/shop-demo/overview
        - paragraph: Tổng quan
    - listitem:
      - link "Công việc hôm nay":
        - /url: /s/shop-demo/operations
        - paragraph: Công việc hôm nay
    - listitem:
      - link "Cần phê duyệt":
        - /url: /s/shop-demo/approvals
        - paragraph: Cần phê duyệt
  - text: BÁN HÀNG
  - list:
    - listitem:
      - link "Hộp thư khách hàng":
        - /url: /s/shop-demo/inbox
        - paragraph: Hộp thư khách hàng
    - listitem:
      - link "Khách hàng":
        - /url: /s/shop-demo/customers
        - paragraph: Khách hàng
    - listitem:
      - link "Đơn hàng":
        - /url: /s/shop-demo/orders
        - paragraph: Đơn hàng
    - listitem:
      - link "Chuẩn bị hàng":
        - /url: /s/shop-demo/fulfillment
        - paragraph: Chuẩn bị hàng
    - listitem:
      - link "Vận đơn & giao hàng":
        - /url: /s/shop-demo/shipments
        - paragraph: Vận đơn & giao hàng
    - listitem:
      - link "Đổi trả":
        - /url: /s/shop-demo/returns
        - paragraph: Đổi trả
    - listitem:
      - link "Chăm sóc sau bán":
        - /url: /s/shop-demo/service-cases
        - paragraph: Chăm sóc sau bán
  - text: HÀNG HÓA
  - list:
    - listitem:
      - link "Sản phẩm":
        - /url: /s/shop-demo/products
        - paragraph: Sản phẩm
    - listitem:
      - link "Danh mục":
        - /url: /s/shop-demo/categories
        - paragraph: Danh mục
    - listitem:
      - link "Nhập dữ liệu":
        - /url: /s/shop-demo/imports
        - paragraph: Nhập dữ liệu
    - listitem:
      - link "Tồn kho":
        - /url: /s/shop-demo/inventory
        - paragraph: Tồn kho
    - listitem:
      - link "Lịch sử kho":
        - /url: /s/shop-demo/inventory/movements
        - paragraph: Lịch sử kho
    - listitem:
      - link "Nhà cung cấp":
        - /url: /s/shop-demo/suppliers
        - paragraph: Nhà cung cấp
    - listitem:
      - link "Đề nghị nhập":
        - /url: /s/shop-demo/replenishment
        - paragraph: Đề nghị nhập
    - listitem:
      - link "Đơn mua hàng":
        - /url: /s/shop-demo/purchases
        - paragraph: Đơn mua hàng
    - listitem:
      - link "Nhận hàng":
        - /url: /s/shop-demo/receipts
        - paragraph: Nhận hàng
  - text: KẾ TOÁN
  - list:
    - listitem:
      - link "Thu chi":
        - /url: /s/shop-demo/finance
        - paragraph: Thu chi
    - listitem:
      - link "Sổ thu chi":
        - /url: /s/shop-demo/finance/entries
        - paragraph: Sổ thu chi
    - listitem:
      - link "Lợi nhuận":
        - /url: /s/shop-demo/finance/profit-loss
        - paragraph: Lợi nhuận
    - listitem:
      - link "Chứng từ & sổ kép":
        - /url: /s/shop-demo/finance/journals
        - paragraph: Chứng từ & sổ kép
    - listitem:
      - link "Tài khoản kế toán":
        - /url: /s/shop-demo/finance/accounts
        - paragraph: Tài khoản kế toán
    - listitem:
      - link "Mở sổ kế toán":
        - /url: /s/shop-demo/finance/opening-balances
        - paragraph: Mở sổ kế toán
    - listitem:
      - link "Sổ cái":
        - /url: /s/shop-demo/finance/ledger
        - paragraph: Sổ cái
    - listitem:
      - link "Cân đối phát sinh":
        - /url: /s/shop-demo/finance/trial-balance
        - paragraph: Cân đối phát sinh
    - listitem:
      - link "Cân đối quản trị":
        - /url: /s/shop-demo/finance/balance-sheet
        - paragraph: Cân đối quản trị
    - listitem:
      - link "Đối soát":
        - /url: /s/shop-demo/finance/reconciliation
        - paragraph: Đối soát
    - listitem:
      - link "Công nợ & khóa kỳ":
        - /url: /s/shop-demo/finance/debts-periods
        - paragraph: Công nợ & khóa kỳ
  - text: ĐỘI NGŨ AI
  - list:
    - listitem:
      - link "Bốn nhân viên AI":
        - /url: /s/shop-demo/bot/team
        - paragraph: Bốn nhân viên AI
    - listitem:
      - link "Cấu hình Admin":
        - /url: /s/shop-demo/bot
        - paragraph: Cấu hình Admin
    - listitem:
      - link "Thử bot":
        - /url: /s/shop-demo/bot/playground
        - paragraph: Thử bot
    - listitem:
      - link "Chất lượng AI":
        - /url: /s/shop-demo/bot/evaluations
        - paragraph: Chất lượng AI
    - listitem:
      - link "Kiến thức cửa hàng":
        - /url: /s/shop-demo/knowledge
        - paragraph: Kiến thức cửa hàng
    - listitem:
      - link "Phản hồi cần duyệt":
        - /url: /s/shop-demo/knowledge/review
        - paragraph: Phản hồi cần duyệt
    - listitem:
      - link "Bản tin & sức khỏe":
        - /url: /s/shop-demo/operations/digests
        - paragraph: Bản tin & sức khỏe
  - text: THÔNG BÁO & BÁO CÁO
  - list:
    - listitem:
      - link "Trung tâm thông báo":
        - /url: /s/shop-demo/notifications
        - paragraph: Trung tâm thông báo
    - listitem:
      - link "Điện thoại & lịch trực":
        - /url: /s/shop-demo/notifications/devices
        - paragraph: Điện thoại & lịch trực
    - listitem:
      - link "Xuất báo cáo":
        - /url: /s/shop-demo/reports
        - paragraph: Xuất báo cáo
    - listitem:
      - link "Thông tin marketing":
        - /url: /s/shop-demo/reports/marketing
        - paragraph: Thông tin marketing
  - text: CÀI ĐẶT
  - list:
    - listitem:
      - link "Kết nối Facebook":
        - /url: /s/shop-demo/integrations/channels
        - paragraph: Kết nối Facebook
    - listitem:
      - link "Nhà cung cấp AI":
        - /url: /s/shop-demo/integrations/ai
        - paragraph: Nhà cung cấp AI
    - listitem:
      - link "Nhân sự & quyền":
        - /url: /s/shop-demo/settings/team
        - paragraph: Nhân sự & quyền
    - listitem:
      - link "Cửa hàng":
        - /url: /s/shop-demo/settings/shop
        - paragraph: Cửa hàng
    - listitem:
      - link "Quản trị kho":
        - /url: /s/shop-demo/settings/warehouses
        - paragraph: Quản trị kho
    - listitem:
      - link "Nhật ký":
        - /url: /s/shop-demo/settings/audit
        - paragraph: Nhật ký
    - listitem:
      - link "Quyền riêng tư":
        - /url: /s/shop-demo/settings/privacy
        - paragraph: Quyền riêng tư
  - separator
  - text: J
  - paragraph: Jokertrader · tài khoản mẫu
  - text: Chủ shop
  - button "Đăng xuất"
- banner:
  - navigation "Đường dẫn hiện tại": Không gian làm việc / Chi tiết sản phẩm
  - textbox "Tìm màn hình":
    - /placeholder: Tìm màn hình...
  - text: Dữ liệu mô phỏng
  - link "Thông báo":
    - /url: /s/shop-demo/notifications
  - text: J
- alert:
  - text: "Frontend review: API được mô phỏng trong bộ nhớ, không gửi tin hoặc đặt hàng thật. Tải lại trang sẽ khởi tạo lại dữ liệu."
  - button "Góp ý"
- button "Công cụ demo"
- text: owner · Bình thường · Dataset mặc định
- main:
  - heading "Thông tin sản phẩm" [level=1]
  - paragraph: Giá theo biến thể. Tồn kho được quản lý ở màn hình riêng.
  - link "Danh sách":
    - /url: /s/shop-demo/products
  - heading "Thông tin bán hàng" [level=2]
  - text: Tên sản phẩm
  - textbox "Tên sản phẩm": Sản phẩm FE010
  - text: Mô tả dùng cho AI tư vấn
  - textbox "Mô tả dùng cho AI tư vấn"
  - text: Tìm danh mục
  - textbox "Tìm danh mục"
  - paragraph: Tìm trên danh sách cửa hàng; có thể tải thêm khi cần.
  - text: Danh mục
  - combobox "Danh mục Áo": Áo
  - text: Đã tải 3 lựa chọn Trạng thái
  - combobox "Trạng thái Bản nháp": Bản nháp
  - heading "Biến thể và giá" [level=2]
  - button "Thêm biến thể"
  - text: SKU
  - textbox "SKU": FE010-PRODUCT-M
  - text: Tên / màu / kích cỡ
  - textbox "Tên / màu / kích cỡ": Mặc định
  - text: Giá bán (VND)
  - textbox "Giá bán (VND)": "249000"
  - checkbox "Đang bán" [checked]
  - text: Đang bán
  - button "Xóa biến thể 1"
  - text: SKU
  - textbox "SKU": FE010-PRODUCT-L
  - text: Tên / màu / kích cỡ
  - textbox "Tên / màu / kích cỡ": Size L
  - text: Giá bán (VND)
  - textbox "Giá bán (VND)": "259000"
  - checkbox "Đang bán" [checked]
  - text: Đang bán
  - button "Xóa biến thể 2"
  - heading "Ảnh sản phẩm" [level=2]
  - paragraph: File được kiểm soát qua API upload; không nhúng secret hoặc URL tùy ý.
  - paragraph: 1 tệp được gắn với sản phẩm
  - button "Chọn ảnh"
  - text: fileobject-10001
  - button "Bỏ liên kết ảnh"
  - button "Ngừng bán"
  - button "Lưu sản phẩm"
- contentinfo:
  - text: BotSales AI · Graphite Gold · Frontend
  - button "Góp ý màn hình"
```

# Test source

```ts
  1   | import { openDemoControls } from './session/demo-controls';
  2   | import {test,expect} from '@playwright/test';
  3   | import {mkdir,readFile,writeFile} from 'node:fs/promises';
  4   | import {resolve} from 'node:path';
  5   | import {startDemoServer} from './session/demo-server.mjs';
  6   | import {evidenceRunId} from './evidence-run-id.mjs';
  7   | 
  8   | let demoUrl='';
  9   | let closeDemo: (()=>Promise<void>)|undefined;
  10  | 
  11  | test.beforeAll(async()=>{
  12  |     const server=await startDemoServer();
  13  |     demoUrl=server.url;
  14  |     closeDemo=server.close;
  15  | });
  16  | 
  17  | test.afterAll(async()=>closeDemo?.());
  18  | 
  19  | async function gotoDemo(page: import('@playwright/test').Page,path: string){
  20  |     await page.goto(new URL(path,demoUrl).toString());
  21  | }
  22  | 
  23  | async function chooseMockOption(page: import('@playwright/test').Page,label: string,value: string){
  24  |     if (['Vai trò mô phỏng', 'Trạng thái thử', 'Dataset mô phỏng'].includes(label)) await openDemoControls(page);
  25  |     await page.getByRole('combobox',{name:label}).click();
  26  |     await page.getByRole('option',{name:value,exact:true}).click();
  27  | }
  28  | 
  29  | type ObservedRequest={method:string;path:string;body:string|null;headers:Record<string,string>};
  30  | function observeShopRequests(page: import('@playwright/test').Page){
  31  |     const requests:ObservedRequest[]=[];
  32  |     page.on('request',request=>{
  33  |         const url=new URL(request.url());
  34  |         if(url.pathname.includes('/shops'))
  35  |             requests.push({method:request.method(),path:url.pathname+url.search,body:request.postData(),headers:request.headers()});
  36  |     });
  37  |     return requests;
  38  | }
  39  | 
  40  | test('product editor validates positive prices, protects image-only drafts, and saves variant payload through mock HTTP',async({page})=>{
  41  |     const calls=observeShopRequests(page);
  42  |     await gotoDemo(page,'/s/shop-demo/products/new');
  43  |     await expect(page.getByRole('heading',{name:'Thêm sản phẩm',exact:true})).toBeVisible();
  44  |     const name=page.getByLabel('Tên sản phẩm');
  45  |     const skus=page.getByLabel('SKU');
  46  |     const prices=page.getByLabel('Giá bán (VND)');
  47  |     await expect(prices.first()).toHaveValue('');
  48  |     await name.fill('Sản phẩm FE010');
  49  |     await skus.nth(0).fill('FE010-PRODUCT-M');
  50  |     await chooseMockOption(page,'Danh mục','Áo');
  51  |     await page.getByRole('button',{name:'Lưu sản phẩm',exact:true}).click();
  52  |     await expect(page.getByText('Nhập giá bán',{exact:true})).toBeVisible();
  53  |     expect(calls.filter(call=>call.method==='POST'&&call.path.endsWith('/shops/shop-demo/products'))).toHaveLength(0);
  54  | 
  55  |     await prices.first().fill('0');
  56  |     await page.getByRole('button',{name:'Lưu sản phẩm',exact:true}).click();
  57  |     await expect(page.getByText('Giá phải lớn hơn 0',{exact:true})).toBeVisible();
  58  |     expect(calls.filter(call=>call.method==='POST'&&call.path.endsWith('/shops/shop-demo/products'))).toHaveLength(0);
  59  | 
  60  |     await prices.first().fill('249000');
  61  |     await page.getByRole('button',{name:'Thêm biến thể'}).click();
  62  |     await skus.nth(1).fill('FE010-PRODUCT-L');
  63  |     await page.getByLabel('Tên / màu / kích cỡ').nth(1).fill('Size L');
  64  |     await prices.nth(1).fill('259000');
  65  |     await page.locator('input[type="file"]').setInputFiles({name:'fe010.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/pWQAAAAASUVORK5CYII=','base64')});
  66  |     await expect(page.getByText('1 tệp được gắn với sản phẩm',{exact:true})).toBeVisible();
  67  | 
  68  |     await page.getByRole('link',{name:'Danh sách',exact:true}).click();
  69  |     const guard=page.getByRole('dialog',{name:'Rời màn hình chưa lưu?'});
  70  |     await expect(guard).toBeVisible();
  71  |     await guard.getByRole('button',{name:'Tiếp tục chỉnh sửa',exact:true}).click();
  72  |     await expect(guard).toBeHidden();
  73  |     await expect(name).toHaveValue('Sản phẩm FE010');
  74  |     await expect(skus.nth(1)).toHaveValue('FE010-PRODUCT-L');
  75  |     await expect(page.getByText('1 tệp được gắn với sản phẩm',{exact:true})).toBeVisible();
  76  | 
  77  |     const savedProductRead = page.waitForResponse(response => response.request().method() === 'GET' && /^\/api\/v2\/shops\/shop-demo\/products\/product-[^/]+$/.test(new URL(response.url()).pathname));
  78  |     await page.getByRole('button',{name:'Lưu sản phẩm',exact:true}).click();
  79  |     await expect(page).toHaveURL(/\/products\/product-/);
  80  |     expect((await savedProductRead).status()).toBe(200);
  81  |     await expect(page.locator('main [role="progressbar"]')).toHaveCount(0);
  82  |     await expect(name).toHaveValue('Sản phẩm FE010');
  83  |     const createCall=calls.find(call=>call.method==='POST'&&call.path.endsWith('/shops/shop-demo/products'));
  84  |     const payload=JSON.parse(createCall?.body||'null');
  85  |     expect(payload).toMatchObject({name:'Sản phẩm FE010',categoryId:'cat-0',status:'draft'});
  86  |     expect(payload.variants.map((v:{sku:string;name:string;price:{amount:string;currency:string}})=>({sku:v.sku,name:v.name,price:v.price}))).toEqual([
  87  |         {sku:'FE010-PRODUCT-M',name:'Mặc định',price:{amount:'249000',currency:'VND'}},
  88  |         {sku:'FE010-PRODUCT-L',name:'Size L',price:{amount:'259000',currency:'VND'}}
  89  |     ]);
  90  |     expect(payload.imageFileIds).toHaveLength(1);
  91  |     expect(payload).not.toHaveProperty('unitCost');
  92  |     expect(payload.variants[0]).not.toHaveProperty('unitCost');
  93  | 
  94  |     await page.getByRole('link',{name:'Danh sách',exact:true}).click();
> 95  |     await expect(page).toHaveURL(/\/s\/shop-demo\/products(?:\?.*)?$/, { timeout: 30_000 });
      |                        ^ Error: expect(page).toHaveURL(expected) failed
  96  |     await expect(page.getByRole('heading',{name:'Sản phẩm',exact:true})).toBeVisible({ timeout: 15_000 });
  97  |     await page.getByLabel('Tìm kiếm').fill('FE010-PRODUCT-L');
  98  |     await page.getByRole('button',{name:'Tìm kiếm',exact:true}).click();
  99  |     await expect(page.getByText('Sản phẩm FE010',{exact:true})).toBeVisible();
  100 |     const clothingProducts=page.waitForRequest(request=>{
  101 |         const url=new URL(request.url());
  102 |         return request.method()==='GET'&&url.pathname.endsWith('/shops/shop-demo/products')&&url.searchParams.get('categoryId')==='cat-1';
  103 |     });
  104 |     await chooseMockOption(page,'Danh mục','Quần');
  105 |     await clothingProducts;
  106 |     await expect(page.getByText('Sản phẩm FE010',{exact:true})).toHaveCount(0);
  107 |     const clothingRestore=page.waitForRequest(request=>{
  108 |         const url=new URL(request.url());
  109 |         return request.method()==='GET'&&url.pathname.endsWith('/shops/shop-demo/products')&&url.searchParams.get('categoryId')==='cat-0';
  110 |     });
  111 |     await chooseMockOption(page,'Danh mục','Áo');
  112 |     await clothingRestore;
  113 |     await expect(page.getByText('Sản phẩm FE010',{exact:true})).toBeVisible();
  114 |     await expect(page.getByRole('button',{name:'Trang tiếp'})).toBeDisabled();
  115 | });
  116 | 
  117 | test('product update sends If-Match and keeps edits visible after a 412 conflict',async({page})=>{
  118 |     const calls=observeShopRequests(page);
  119 |     await gotoDemo(page,'/s/shop-demo/products/p1');
  120 |     await expect(page.getByRole('heading',{name:'Thông tin sản phẩm',exact:true})).toBeVisible();
  121 |     await page.getByLabel('Tên sản phẩm').fill('Áo cập nhật FE010');
  122 |     await page.getByLabel('Giá bán (VND)').first().fill('71000');
  123 |     await chooseMockOption(page,'Trạng thái thử','Xung đột lần ghi tiếp');
  124 |     const staleSave=page.waitForResponse(response=>response.request().method()==='PATCH'&&new URL(response.url()).pathname.endsWith('/shops/shop-demo/products/p1'));
  125 |     await page.getByRole('button',{name:'Lưu sản phẩm',exact:true}).click();
  126 |     expect((await staleSave).status()).toBe(412);
  127 |     const comparison=page.getByRole('dialog',{name:'Đối chiếu thay đổi',exact:true});
  128 |     await expect(comparison).toBeVisible();
  129 |     await expect(comparison.getByText('Áo cập nhật FE010',{exact:true})).toBeVisible();
  130 |     expect(calls.filter(call=>call.method==='PATCH'&&call.path.endsWith('/shops/shop-demo/products/p1'))).toHaveLength(1);
  131 |     await comparison.getByRole('button',{name:'Áp dụng vào bản nháp',exact:true}).click();
  132 |     await expect(page.getByLabel('Tên sản phẩm')).toHaveValue('Áo cập nhật FE010');
  133 |     await expect(page.getByLabel('Giá bán (VND)').first()).toHaveValue('71000');
  134 |     const patch=calls.find(call=>call.method==='PATCH'&&call.path.endsWith('/shops/shop-demo/products/p1'));
  135 |     expect(patch).toBeDefined();
  136 |     expect(patch?.headers['if-match']).toBeTruthy();
  137 |     expect(JSON.parse(patch?.body||'null')).toMatchObject({name:'Áo cập nhật FE010'});
  138 |     expect(JSON.parse(patch?.body||'null')).not.toHaveProperty('unitCost');
  139 |     const latestVersion=await page.evaluate(async()=>(await(await fetch('/api/v2/shops/shop-demo/products/p1')).json()).data.version);
  140 |     const saved=page.waitForResponse(response=>response.request().method()==='PATCH'&&new URL(response.url()).pathname.endsWith('/shops/shop-demo/products/p1'));
  141 |     await page.getByRole('button',{name:'Lưu sản phẩm',exact:true}).click();
  142 |     expect((await saved).status()).toBe(200);
  143 |     const patches=calls.filter(call=>call.method==='PATCH'&&call.path.endsWith('/shops/shop-demo/products/p1'));
  144 |     expect(patches).toHaveLength(2);
  145 |     expect(patches[1].headers['if-match']).toBe(`"${latestVersion}"`);
  146 |     await expect(page.getByLabel('Tên sản phẩm')).toHaveValue('Áo cập nhật FE010');
  147 | });
  148 | 
  149 | test('warehouse role can read catalog products but cannot edit product fields or price cost data',async({page})=>{
  150 |     await gotoDemo(page,'/s/shop-demo/products/p1');
  151 |     await chooseMockOption(page,'Vai trò mô phỏng','warehouse');
  152 |     await expect(page.getByLabel('Tên sản phẩm')).toBeDisabled();
  153 |     await expect(page.getByLabel('Giá bán (VND)').first()).toBeDisabled();
  154 |     await expect(page.getByRole('button',{name:'Lưu sản phẩm',exact:true})).toHaveCount(0);
  155 |     await expect(page.getByText(/giá vốn|unitCost/i)).toHaveCount(0);
  156 | });
  157 | 
  158 | test('categories create, search, update with a version, and render cursor pagination',async({page})=>{
  159 |     const calls=observeShopRequests(page);
  160 |     await gotoDemo(page,'/s/shop-demo/categories');
  161 |     await expect(page.getByRole('heading',{name:'Danh mục',exact:true})).toBeVisible();
  162 |     await expect(page.getByRole('button',{name:'Trang tiếp'})).toBeDisabled();
  163 |     await page.getByRole('button',{name:'Thêm danh mục',exact:true}).click();
  164 |     const dialog=page.getByRole('dialog',{name:'Thêm danh mục'});
  165 |     await dialog.getByLabel('Tên').fill('Danh mục FE010');
  166 |     await dialog.getByRole('button',{name:'Lưu',exact:true}).click();
  167 |     await expect(dialog).toHaveCount(0);
  168 |     const create=calls.find(call=>call.method==='POST'&&call.path.endsWith('/shops/shop-demo/categories'));
  169 |     expect(JSON.parse(create?.body||'null')).toMatchObject({name:'Danh mục FE010',parentId:null});
  170 | 
  171 |     await page.getByLabel('Tìm kiếm').fill('Danh mục FE010');
  172 |     await page.getByRole('button',{name:'Tìm kiếm',exact:true}).click();
  173 |     const row=page.getByRole('row').filter({hasText:'Danh mục FE010'});
  174 |     await expect(row).toBeVisible();
  175 |     await row.getByRole('button',{name:'Sửa',exact:true}).click();
  176 |     const edit=page.getByRole('dialog',{name:'Sửa danh mục'});
  177 |     await edit.getByLabel('Tên').fill('Danh mục FE010 đã sửa');
  178 |     await edit.getByRole('button',{name:'Lưu',exact:true}).click();
  179 |     await expect(edit).toHaveCount(0);
  180 |     const update=calls.find(call=>call.method==='PATCH'&&call.path.match(/\/shops\/shop-demo\/categories\/category-/)&&JSON.parse(call.body||'null')?.name==='Danh mục FE010 đã sửa');
  181 |     expect(update?.headers['if-match']).toBeTruthy();
  182 |     expect(JSON.parse(update?.body||'null')).toMatchObject({name:'Danh mục FE010 đã sửa'});
  183 |     await expect(page.getByText('Danh mục FE010 đã sửa',{exact:true})).toBeVisible();
  184 |     await expect(page.getByRole('button',{name:'Trang tiếp'})).toBeDisabled();
  185 | });
  186 | 
  187 | test('CSV preview reports row-level errors and commits only valid product rows',async({page})=>{
  188 |     const calls=observeShopRequests(page);
  189 |     await gotoDemo(page,'/s/shop-demo/imports');
  190 |     await expect(page.getByRole('heading',{name:'Nhập dữ liệu sản phẩm',exact:true})).toBeVisible();
  191 |     await expect(page.getByRole('alert').filter({hasText:'Trong demo mô phỏng'})).toContainText('5 MB');
  192 |     await expect(page.getByRole('alert').filter({hasText:'Trong demo mô phỏng'})).toContainText('1.000 dòng');
  193 |     const sampleLink=page.getByRole('link',{name:'Tải CSV mẫu',exact:true});
  194 |     await expect(sampleLink).toHaveAttribute('download','botsales-products.csv');
  195 |     const sampleResponse=await page.request.get(new URL(await sampleLink.getAttribute('href')||'',page.url()).toString());
```