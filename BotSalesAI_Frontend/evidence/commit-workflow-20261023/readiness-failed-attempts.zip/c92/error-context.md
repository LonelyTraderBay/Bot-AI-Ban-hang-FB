# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: states/route-role-ready-composition.spec.ts >> ready route content renders for every role granted read access by the canonical contract >> ready route content for owner
- Location: tests/states/route-role-ready-composition.spec.ts:57:9

# Error details

```
Error: R60 should explain when retained data may be stale for owner

expect(locator).toBeVisible() failed

Locator: locator('main#main-content').getByText(/có thể đã cũ/i).first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - R60 should explain when retained data may be stale for owner locator('main#main-content').getByText(/có thể đã cũ/i).first() with timeout 15000ms
  - waiting for locator('main#main-content').getByText(/có thể đã cũ/i).first()

```

```yaml
- link "Đến nội dung chính":
  - /url: "#main-content"
- navigation "Điều hướng chính":
  - heading "BotSales AI" [level=6]
  - text: Đội ngũ vận hành cửa hàng
  - link "Joker Studio · Shop mẫu ⌄":
    - /url: /workspaces
  - text: ĐIỀU HÀNH
  - list:
    - listitem:
      - link "Tổng quan":
        - /url: /s/shop-demo/overview
        - paragraph: Tổng quan
    - listitem:
      - link "Công việc hôm nay":
        - /url: /s/shop-demo/operations
        - paragraph: Công việc hôm nay
    - listitem:
      - link "Cần phê duyệt":
        - /url: /s/shop-demo/approvals
        - paragraph: Cần phê duyệt
  - text: BÁN HÀNG
  - list:
    - listitem:
      - link "Hộp thư khách hàng":
        - /url: /s/shop-demo/inbox
        - paragraph: Hộp thư khách hàng
    - listitem:
      - link "Khách hàng":
        - /url: /s/shop-demo/customers
        - paragraph: Khách hàng
    - listitem:
      - link "Đơn hàng":
        - /url: /s/shop-demo/orders
        - paragraph: Đơn hàng
    - listitem:
      - link "Chuẩn bị hàng":
        - /url: /s/shop-demo/fulfillment
        - paragraph: Chuẩn bị hàng
    - listitem:
      - link "Vận đơn & giao hàng":
        - /url: /s/shop-demo/shipments
        - paragraph: Vận đơn & giao hàng
    - listitem:
      - link "Đổi trả":
        - /url: /s/shop-demo/returns
        - paragraph: Đổi trả
    - listitem:
      - link "Chăm sóc sau bán":
        - /url: /s/shop-demo/service-cases
        - paragraph: Chăm sóc sau bán
  - text: HÀNG HÓA
  - list:
    - listitem:
      - link "Sản phẩm":
        - /url: /s/shop-demo/products
        - paragraph: Sản phẩm
    - listitem:
      - link "Danh mục":
        - /url: /s/shop-demo/categories
        - paragraph: Danh mục
    - listitem:
      - link "Nhập dữ liệu":
        - /url: /s/shop-demo/imports
        - paragraph: Nhập dữ liệu
    - listitem:
      - link "Tồn kho":
        - /url: /s/shop-demo/inventory
        - paragraph: Tồn kho
    - listitem:
      - link "Lịch sử kho":
        - /url: /s/shop-demo/inventory/movements
        - paragraph: Lịch sử kho
    - listitem:
      - link "Nhà cung cấp":
        - /url: /s/shop-demo/suppliers
        - paragraph: Nhà cung cấp
    - listitem:
      - link "Đề nghị nhập":
        - /url: /s/shop-demo/replenishment
        - paragraph: Đề nghị nhập
    - listitem:
      - link "Đơn mua hàng":
        - /url: /s/shop-demo/purchases
        - paragraph: Đơn mua hàng
    - listitem:
      - link "Nhận hàng":
        - /url: /s/shop-demo/receipts
        - paragraph: Nhận hàng
  - text: KẾ TOÁN
  - list:
    - listitem:
      - link "Thu chi":
        - /url: /s/shop-demo/finance
        - paragraph: Thu chi
    - listitem:
      - link "Sổ thu chi":
        - /url: /s/shop-demo/finance/entries
        - paragraph: Sổ thu chi
    - listitem:
      - link "Lợi nhuận":
        - /url: /s/shop-demo/finance/profit-loss
        - paragraph: Lợi nhuận
    - listitem:
      - link "Chứng từ & sổ kép":
        - /url: /s/shop-demo/finance/journals
        - paragraph: Chứng từ & sổ kép
    - listitem:
      - link "Tài khoản kế toán":
        - /url: /s/shop-demo/finance/accounts
        - paragraph: Tài khoản kế toán
    - listitem:
      - link "Mở sổ kế toán":
        - /url: /s/shop-demo/finance/opening-balances
        - paragraph: Mở sổ kế toán
    - listitem:
      - link "Sổ cái":
        - /url: /s/shop-demo/finance/ledger
        - paragraph: Sổ cái
    - listitem:
      - link "Cân đối phát sinh":
        - /url: /s/shop-demo/finance/trial-balance
        - paragraph: Cân đối phát sinh
    - listitem:
      - link "Cân đối quản trị":
        - /url: /s/shop-demo/finance/balance-sheet
        - paragraph: Cân đối quản trị
    - listitem:
      - link "Đối soát":
        - /url: /s/shop-demo/finance/reconciliation
        - paragraph: Đối soát
    - listitem:
      - link "Công nợ & khóa kỳ":
        - /url: /s/shop-demo/finance/debts-periods
        - paragraph: Công nợ & khóa kỳ
  - text: ĐỘI NGŨ AI
  - list:
    - listitem:
      - link "Bốn nhân viên AI":
        - /url: /s/shop-demo/bot/team
        - paragraph: Bốn nhân viên AI
    - listitem:
      - link "Cấu hình Admin":
        - /url: /s/shop-demo/bot
        - paragraph: Cấu hình Admin
    - listitem:
      - link "Thử bot":
        - /url: /s/shop-demo/bot/playground
        - paragraph: Thử bot
    - listitem:
      - link "Chất lượng AI":
        - /url: /s/shop-demo/bot/evaluations
        - paragraph: Chất lượng AI
    - listitem:
      - link "Kiến thức cửa hàng":
        - /url: /s/shop-demo/knowledge
        - paragraph: Kiến thức cửa hàng
    - listitem:
      - link "Phản hồi cần duyệt":
        - /url: /s/shop-demo/knowledge/review
        - paragraph: Phản hồi cần duyệt
    - listitem:
      - link "Bản tin & sức khỏe":
        - /url: /s/shop-demo/operations/digests
        - paragraph: Bản tin & sức khỏe
  - text: THÔNG BÁO & BÁO CÁO
  - list:
    - listitem:
      - link "Trung tâm thông báo":
        - /url: /s/shop-demo/notifications
        - paragraph: Trung tâm thông báo
    - listitem:
      - link "Điện thoại & lịch trực":
        - /url: /s/shop-demo/notifications/devices
        - paragraph: Điện thoại & lịch trực
    - listitem:
      - link "Xuất báo cáo":
        - /url: /s/shop-demo/reports
        - paragraph: Xuất báo cáo
    - listitem:
      - link "Thông tin marketing":
        - /url: /s/shop-demo/reports/marketing
        - paragraph: Thông tin marketing
  - text: CÀI ĐẶT
  - list:
    - listitem:
      - link "Kết nối Facebook":
        - /url: /s/shop-demo/integrations/channels
        - paragraph: Kết nối Facebook
    - listitem:
      - link "Nhà cung cấp AI":
        - /url: /s/shop-demo/integrations/ai
        - paragraph: Nhà cung cấp AI
    - listitem:
      - link "Nhân sự & quyền":
        - /url: /s/shop-demo/settings/team
        - paragraph: Nhân sự & quyền
    - listitem:
      - link "Cửa hàng":
        - /url: /s/shop-demo/settings/shop
        - paragraph: Cửa hàng
    - listitem:
      - link "Quản trị kho":
        - /url: /s/shop-demo/settings/warehouses
        - paragraph: Quản trị kho
    - listitem:
      - link "Nhật ký":
        - /url: /s/shop-demo/settings/audit
        - paragraph: Nhật ký
    - listitem:
      - link "Quyền riêng tư":
        - /url: /s/shop-demo/settings/privacy
        - paragraph: Quyền riêng tư
  - separator
  - text: J
  - paragraph: Jokertrader · tài khoản mẫu
  - text: Chủ shop
  - button "Đăng xuất"
- banner:
  - navigation "Đường dẫn hiện tại": Không gian làm việc / Cân đối quản trị
  - textbox "Tìm màn hình":
    - /placeholder: Tìm màn hình...
  - text: Dữ liệu mô phỏng
  - link "Thông báo":
    - /url: /s/shop-demo/notifications
  - text: J
- alert:
  - text: "Frontend review: API được mô phỏng trong bộ nhớ, không gửi tin hoặc đặt hàng thật. Tải lại trang sẽ khởi tạo lại dữ liệu."
  - button "Góp ý"
- button "Ẩn công cụ demo" [expanded]
- text: "Thử giao diện: Vai trò mô phỏng"
- combobox "Vai trò mô phỏng Vai trò mô phỏng": owner
- text: Trạng thái thử
- combobox "Trạng thái thử Trạng thái thử": Lỗi API kéo dài
- text: Dataset mô phỏng
- combobox "Dataset mô phỏng Dataset mô phỏng": Dataset mặc định
- status: Trạng thái thử đã được áp dụng.
- main:
  - heading "Cân đối quản trị" [level=1]
  - paragraph: Tài sản = nợ phải trả + vốn chủ sở hữu + kết quả lũy kế; đây là báo cáo quản trị theo chính sách của shop.
  - text: Tại ngày
  - textbox "Tại ngày": 2026-10-24
  - alert:
    - text: Không thể hoàn thành yêu cầu API mô phỏng đang lỗi liên tục. Đổi “Trạng thái thử” về bình thường rồi thử lại.
    - button "Thử lại"
- contentinfo:
  - text: BotSales AI · Graphite Gold · Frontend
  - button "Góp ý màn hình"
```

# Test source

```ts
  23  | };
  24  | 
  25  | function routePath(path: string) {
  26  |     return path
  27  |         .replace(':shopId', 'shop-demo')
  28  |         .replace(/:([A-Za-z]+)/g, (_, key: string) => detailIds[key] || 'missing');
  29  | }
  30  | 
  31  | function canRead(route: Route, role: string) {
  32  |     return route.readPermission === null || permissionCatalog.rolePresets[role].includes(route.readPermission);
  33  | }
  34  | 
  35  | async function chooseRole(page: import('@playwright/test').Page, role: string) {
  36  |     if (role === 'owner') return;
  37  |     await openDemoControls(page);
  38  |     await page.getByRole('combobox', { name: 'Vai trò mô phỏng' }).click();
  39  |     await page.getByRole('option', { name: role, exact: true }).click();
  40  | }
  41  | 
  42  | let demoUrl = '';
  43  | let stopDemo: (() => Promise<void>) | undefined;
  44  | 
  45  | test.beforeAll(async () => {
  46  |     const server = await startDemoServer();
  47  |     demoUrl = server.url;
  48  |     stopDemo = server.close;
  49  | });
  50  | 
  51  | test.afterAll(async () => {
  52  |     await stopDemo?.();
  53  | });
  54  | 
  55  | test.describe('ready route content renders for every role granted read access by the canonical contract', () => {
  56  |     for (const role of roles) {
  57  |         test(`ready route content for ${role}`, async ({ page }) => {
  58  |             test.setTimeout(600_000);
  59  |             const browser = test.info().project.name;
  60  |             const browserVersion = page.context().browser()?.version() || 'unknown';
  61  |             console.log(`BROWSER=${browser} VERSION=${browserVersion}`);
  62  |             const pageErrors: string[] = [];
  63  |             page.on('pageerror', error => pageErrors.push(error.message));
  64  |             const operationStatuses = new Map<string, number>();
  65  |             page.on('response', response => {
  66  |                 const pathname = new URL(response.url()).pathname;
  67  |                 const operation = Object.entries(operationPathPatterns).find(([, pattern]) => pattern.test(pathname))?.[0];
  68  |                 if (operation) operationStatuses.set(operation, response.status());
  69  |             });
  70  |             const readableRoutes = privateRoutes.filter(route => canRead(route, role));
  71  |             await page.goto(new URL('/s/shop-demo/notifications', demoUrl).toString());
  72  |             await chooseRole(page, role);
  73  |             await openDemoControls(page);
  74  |             await page.getByRole('combobox', { name: 'Trạng thái thử' }).click();
  75  |             await page.getByRole('option', { name: 'Bình thường', exact: true }).click();
  76  | 
  77  |             for (const route of readableRoutes) {
  78  |                 await page.evaluate(nextPath => {
  79  |                     window.history.pushState({}, '', nextPath);
  80  |                     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }));
  81  |                 }, routePath(route.path));
  82  |                 const main = page.locator('main#main-content');
  83  |                 await expect(main, `${route.id} should render for ${role}`).toBeVisible();
  84  |                 await expect(main.getByRole('heading').first(), `${route.id} should expose route content for ${role}`).toBeVisible();
  85  |                 await expect.poll(() => new URL(page.url()).pathname, { message: `${route.id} should become the active router location for ${role}` }).toBe(routePath(route.path));
  86  |                 await expect.poll(() => page.title(), { message: `${route.id} should update canonical route metadata for ${role}` }).toBe(`${route.title} · BotSales AI`);
  87  |                 const primaryOperation = route.readOperations[0];
  88  |                 await expect.poll(() => operationStatuses.has(primaryOperation), { message: `${route.id} should complete ${primaryOperation} before state changes for ${role}` }).toBe(true);
  89  |                 await expect(main.getByText(/Đang tải/), `${route.id} should settle its visible loading state for ${role}`).toHaveCount(0, { timeout: 10_000 });
  90  |                 await expect(main.getByRole('heading', { name: 'Không thể mở màn hình', exact: true }), `${route.id} should not fall through to the route error boundary for ${role}`).toHaveCount(0);
  91  |                 const primaryStatus = operationStatuses.get(primaryOperation);
  92  |                 if (primaryStatus === 200) {
  93  |                     console.log(`BROWSER=${browser} ROLE_STATE=success ROLE=${role} ROUTE=${route.id} RESULT=PASS`);
  94  |                 }
  95  |                 else if (noSeedJobRoutes.has(route.id) && primaryOperation === 'getJob' && primaryStatus === 404) {
  96  |                     console.log(`BROWSER=${browser} ROLE_STATE_NA=success ROLE=${role} ROUTE=${route.id} REASON=mock-no-resource-404 RESULT=PASS`);
  97  |                 }
  98  |                 else {
  99  |                     throw new Error(`${route.id} expected a successful primary read for ${role}; ${primaryOperation} returned HTTP ${primaryStatus}`);
  100 |                 }
  101 |             }
  102 |             expect(pageErrors).toEqual([]);
  103 |             const readyRoutes = readableRoutes.filter(route => !noSeedJobRoutes.has(route.id));
  104 |             const noSeedRoutes = readableRoutes.filter(route => noSeedJobRoutes.has(route.id));
  105 |             console.log(`ROLE_READY_COMPOSITION=${role}:${readyRoutes.length}/${readyRoutes.length} RESULT=PASS`);
  106 |             if (noSeedRoutes.length)
  107 |                 console.log(`ROLE_READY_NOT_APPLICABLE=${role}:${noSeedRoutes.map(route => route.id).join(',')} REASON=mock-no-resource-404`);
  108 | 
  109 |             const routeOwnedData = readableRoutes.filter(route => route.id !== 'R33' && !noSeedJobRoutes.has(route.id));
  110 |             await openDemoControls(page);
  111 |             await page.getByRole('combobox', { name: 'Trạng thái thử' }).click();
  112 |             await page.getByRole('option', { name: 'Lỗi API kéo dài', exact: true }).click();
  113 |             // useApi owns a 5-second staleTime; let every cached route query cross it before remounting.
  114 |             await page.waitForTimeout(5_200);
  115 |             for (const route of routeOwnedData) {
  116 |                 await page.evaluate(nextPath => {
  117 |                     window.history.pushState({}, '', nextPath);
  118 |                     window.dispatchEvent(new PopStateEvent('popstate', { state: window.history.state }));
  119 |                 }, routePath(route.path));
  120 |                 const main = page.locator('main#main-content');
  121 |                 await expect.poll(() => page.title(), { message: `${route.id} should remain the active route while showing stale data for ${role}` }).toBe(`${route.title} · BotSales AI`);
  122 |                 await expect(main.getByRole('heading').first(), `${route.id} should retain its loaded content for ${role}`).toBeVisible();
> 123 |                 await expect(main.getByText(/có thể đã cũ/i).first(), `${route.id} should explain when retained data may be stale for ${role}`).toBeVisible({ timeout: 15_000 });
      |                                                                                                                                                 ^ Error: R60 should explain when retained data may be stale for owner
  124 |                 console.log(`BROWSER=${browser} ROLE_STATE=stale_or_offline ROLE=${role} ROUTE=${route.id} RESULT=PASS`);
  125 |             }
  126 |             if (role === 'owner' && readableRoutes.some(route => route.id === 'R33'))
  127 |                 console.log(`BROWSER=${browser} ROLE_STATE_NA=stale_or_offline ROLE=owner ROUTE=R33 REASON=shared-shell-snapshot RESULT=PASS`);
  128 |             for (const route of readableRoutes.filter(route => noSeedJobRoutes.has(route.id))) {
  129 |                 const status = operationStatuses.get(route.readOperations[0]);
  130 |                 if (status !== 404) throw new Error(`${route.id} requires a seeded job for stale data; expected fixture HTTP 404, received ${status}`);
  131 |                 console.log(`BROWSER=${browser} ROLE_STATE_NA=stale_or_offline ROLE=${role} ROUTE=${route.id} REASON=mock-no-resource-404 RESULT=PASS`);
  132 |             }
  133 |             expect(pageErrors).toEqual([]);
  134 |         });
  135 |     }
  136 | });
  137 | 
```