import __vite__cjsImport0_react_jsxRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/react_jsx-runtime.js?v=10e18444"; const jsx = __vite__cjsImport0_react_jsxRuntime["jsx"]; const jsxs = __vite__cjsImport0_react_jsxRuntime["jsxs"];
import __vite__cjsImport1_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/react.js?v=10e18444"; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Alert, Box, Button, Chip, Divider, FormControlLabel, Checkbox, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/@mui_material.js?v=10e18444";
import SendRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/@mui_icons-material_SendRounded.js?v=10e18444";
import { colors } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { DetailLine, ErrorNotice, MutationButton, Panel, RouteLink, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
export function ConversationComposer({ conversation }) {
  const { session, online } = useScope();
  const canReply = useCan("conversations.reply");
  const send = useCommand("sendMessage", ["listMessages", "getConversation", "listConversations"]);
  const note = useCommand("addInternalNote", ["listMessages"]);
  const [text, setText] = useState("");
  const [internal, setInternal] = useState(false);
  const revision = useRef(0);
  const currentConversation = useRef(conversation.id);
  currentConversation.current = conversation.id;
  const canSend = canReply && online && (internal || conversation.mode === "human" && conversation.assignedUserId === session.user.id && conversation.sendEligibility.state === "allowed");
  const submit = async () => {
    if (!canSend || !text.trim() || send.pending || note.pending || send.unresolved || note.unresolved) return;
    const submittedRevision = revision.current;
    const submittedConversation = conversation.id;
    try {
      if (internal) {
        await note.execute({ path: { conversationId: conversation.id }, body: { text: text.trim() } });
      } else {
        await send.execute({
          path: { conversationId: conversation.id },
          body: {
            clientMessageId: crypto.randomUUID(),
            text: text.trim(),
            expectedConversationVersion: conversation.version
          }
        });
      }
      if (revision.current === submittedRevision && currentConversation.current === submittedConversation) setText("");
    } catch {
    }
  };
  return /* @__PURE__ */ jsxs(
    Box,
    {
      component: "form",
      "data-draft-clean": text ? void 0 : "true",
      onSubmit: (event) => {
        event.preventDefault();
        void submit();
      },
      sx: [layoutSx.inbox.composerInset, { borderTop: 1, borderColor: "divider" }],
      children: [
        /* @__PURE__ */ jsx(ErrorNotice, { error: send.error || note.error }),
        /* @__PURE__ */ jsx(
          FormControlLabel,
          {
            label: "Ghi chú nội bộ (không gửi khách)",
            control: /* @__PURE__ */ jsx(Checkbox, { checked: internal, onChange: (event) => {
              revision.current += 1;
              setInternal(event.target.checked);
            }, disabled: !canReply })
          }
        ),
        /* @__PURE__ */ jsx(
          TextField,
          {
            fullWidth: true,
            multiline: true,
            minRows: 2,
            maxRows: 7,
            label: internal ? "Ghi chú cho nhóm" : "Nội dung trả lời khách",
            value: text,
            onChange: (event) => {
              revision.current += 1;
              setText(limitCodePoints(event.target.value, internal ? 1e4 : 2e4));
            },
            disabled: !canReply
          }
        ),
        /* @__PURE__ */ jsxs(Stack, { direction: "row", alignItems: "center", justifyContent: "space-between", sx: [layoutSx.inbox.composerControlsBeforeGap, layoutSx.inbox.composerActionGap], children: [
          /* @__PURE__ */ jsx(Typography, { variant: "caption", color: "text.secondary", children: !online ? "Đang ngoại tuyến" : !canSend ? "Cần tiếp quản hoặc quyền gửi hợp lệ" : "Tin gửi qua API, không dùng HTML từ AI" }),
          /* @__PURE__ */ jsx(
            Button,
            {
              type: "submit",
              variant: "contained",
              endIcon: /* @__PURE__ */ jsx(SendRounded, {}),
              disabled: !canSend || !text.trim() || send.pending || note.pending || send.unresolved || note.unresolved,
              children: internal ? "Lưu ghi chú" : "Gửi trả lời"
            }
          )
        ] })
      ]
    }
  );
}
export function ConversationMessageList({ messages, timezone, onRate }) {
  return messages.slice().sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((message) => {
    const senderLabel = message.direction === "internal" ? "Ghi chú nội bộ" : message.senderKind === "customer" ? "Khách" : message.senderKind === "bot" ? "Trợ lý AI" : "Nhân viên";
    const messageText = message.text.replace(/\s+/g, " ").trim();
    const preview = Array.from(messageText).slice(0, 64).join("");
    const messagePreview = preview === messageText ? messageText : `${preview.trimEnd()}…`;
    return /* @__PURE__ */ jsx(Stack, { alignItems: message.direction === "inbound" ? "flex-start" : "flex-end", children: /* @__PURE__ */ jsx(Box, { "data-testid": "inbox-message-bubble", sx: [layoutSx.inbox.bubbleInset, {
      maxWidth: "88%",
      borderRadius: visualSx.radius.bubble,
      bgcolor: message.direction === "internal" ? colors.selected : message.direction === "inbound" ? colors.surface : colors.raised,
      border: message.direction === "internal" ? "1px solid" : "none",
      borderColor: colors.heroBorder
    }], children: /* @__PURE__ */ jsxs(Stack, { "data-testid": "inbox-message-meta-flow", sx: layoutSx.inbox.messageMetaGap, children: [
      /* @__PURE__ */ jsxs(Stack, { "data-testid": "inbox-message-content-flow", sx: layoutSx.inbox.messageContentGap, children: [
        /* @__PURE__ */ jsx(Typography, { variant: "caption", color: "text.secondary", children: senderLabel }),
        /* @__PURE__ */ jsx(Typography, { sx: { whiteSpace: "pre-wrap", overflowWrap: "anywhere" }, children: message.text })
      ] }),
      message.sourceEvidence.length > 0 && /* @__PURE__ */ jsx(Stack, { direction: "row", sx: [layoutSx.surface.compactContentGap, { flexWrap: "wrap" }], "aria-label": "Nguồn tham chiếu", children: message.sourceEvidence.map((reference, index) => /* @__PURE__ */ jsx(Chip, { size: "small", variant: "outlined", label: `${reference.type} · ${reference.id}` }, `${reference.type}:${reference.id}:${index}`)) }),
      /* @__PURE__ */ jsxs(Stack, { direction: "row", alignItems: "center", sx: [layoutSx.inbox.composerActionGap, { flexWrap: "wrap" }], children: [
        /* @__PURE__ */ jsxs(Typography, { variant: "caption", color: "text.secondary", children: [
          dateTime(message.createdAt, timezone),
          " · ",
          message.status
        ] }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            "aria-label": `Đánh giá tin nhắn của ${senderLabel} lúc ${dateTime(message.createdAt, timezone)}: ${messagePreview}`,
            onClick: () => onRate(message),
            children: "Đánh giá"
          }
        )
      ] })
    ] }) }) }, message.id);
  });
}
export function ConversationContextPanel({ conversation, children }) {
  const { shop } = useScope();
  const canReadCustomers = useCan("customers.read");
  const canCreateOrders = useCan("orders.write");
  const metadata = useApi("getInboxMetadata");
  const assign = useCommand("assignConversation", ["getConversation", "listConversations"]);
  const [assignee, setAssignee] = useState("");
  return /* @__PURE__ */ jsx(
    Box,
    {
      "data-testid": "inbox-context-panel",
      component: "aside",
      "aria-label": "Bối cảnh khách hàng",
      tabIndex: 0,
      sx: { minWidth: 0, minHeight: 0, maxHeight: { xl: 650 }, overflowY: { xl: "auto" } },
      children: /* @__PURE__ */ jsx(Panel, { title: "Bối cảnh khách hàng", children: /* @__PURE__ */ jsxs(Box, { "data-testid": "inbox-context-content", sx: layoutSx.inbox.contextInset, children: [
        /* @__PURE__ */ jsx(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsx(Status, { value: conversation.status }) }),
        /* @__PURE__ */ jsx(DetailLine, { label: "Kênh", children: metadata.data?.data.channels.find((channel) => channel.id === conversation.channelId)?.displayName || conversation.channelId }),
        canReadCustomers ? /* @__PURE__ */ jsx(RouteLink, { to: `/s/${shop.id}/customers/${conversation.customerId}`, children: "Hồ sơ khách" }) : /* @__PURE__ */ jsx(Typography, { variant: "caption", color: "text.secondary", children: "Thông tin khách bị ẩn theo quyền hiện tại." }),
        canCreateOrders && /* @__PURE__ */ jsx(RouteLink, { to: `/s/${shop.id}/orders/new?customerId=${conversation.customerId}&conversationId=${conversation.id}`, children: "Tạo đơn từ hội thoại" }),
        /* @__PURE__ */ jsx(Divider, { sx: [layoutSx.surface.sectionBefore, layoutSx.notice.afterGap] }),
        /* @__PURE__ */ jsxs(TextField, { label: "Giao cho nhân viên", select: true, fullWidth: true, size: "small", value: assignee, onChange: (event) => setAssignee(event.target.value), children: [
          /* @__PURE__ */ jsx(MenuItem, { value: "", children: "Chọn nhân viên" }),
          metadata.data?.data.assignees.map((user) => /* @__PURE__ */ jsx(MenuItem, { value: user.userId, children: user.displayName }, user.userId))
        ] }),
        /* @__PURE__ */ jsx(
          MutationButton,
          {
            permission: "conversations.assign",
            disabled: !assignee,
            busy: assign.pending,
            onClick: () => {
              void assign.execute({
                path: { conversationId: conversation.id },
                body: { userId: assignee, expectedVersion: conversation.version }
              }).catch(() => void 0);
            },
            children: "Phân công"
          }
        ),
        /* @__PURE__ */ jsx(ErrorNotice, { error: assign.error }),
        /* @__PURE__ */ jsx(Alert, { severity: "info", sx: layoutSx.surface.sectionBefore, children: "Ảnh/tin thoại chỉ bật khi hợp đồng kênh xác nhận hỗ trợ. Phiên bản API hiện tại của ô soạn chỉ gửi văn bản." }),
        children
      ] }) })
    }
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnZlcnNhdGlvbi1jb21wb25lbnRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIENoaXAsIERpdmlkZXIsIEZvcm1Db250cm9sTGFiZWwsIENoZWNrYm94LCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IFNlbmRSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvU2VuZFJvdW5kZWQnO1xuaW1wb3J0IHR5cGUgeyBDb252ZXJzYXRpb24sIE1lc3NhZ2UgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IGNvbG9ycyB9IGZyb20gJ0Bib3RzYWxlcy90b2tlbnMnO1xuaW1wb3J0IHsgdXNlQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7IHVzZUNhbiwgdXNlU2NvcGUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyBsaW1pdENvZGVQb2ludHMsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcbmltcG9ydCB7IERldGFpbExpbmUsIEVycm9yTm90aWNlLCBNdXRhdGlvbkJ1dHRvbiwgUGFuZWwsIFJvdXRlTGluaywgU3RhdHVzIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL2xheW91dCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBDb252ZXJzYXRpb25Db21wb3Nlcih7IGNvbnZlcnNhdGlvbiB9OiB7XG4gICAgY29udmVyc2F0aW9uOiBDb252ZXJzYXRpb247XG59KSB7XG4gICAgY29uc3QgeyBzZXNzaW9uLCBvbmxpbmUgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgY2FuUmVwbHkgPSB1c2VDYW4oJ2NvbnZlcnNhdGlvbnMucmVwbHknKTtcbiAgICBjb25zdCBzZW5kID0gdXNlQ29tbWFuZCgnc2VuZE1lc3NhZ2UnLCBbJ2xpc3RNZXNzYWdlcycsICdnZXRDb252ZXJzYXRpb24nLCAnbGlzdENvbnZlcnNhdGlvbnMnXSk7XG4gICAgY29uc3Qgbm90ZSA9IHVzZUNvbW1hbmQoJ2FkZEludGVybmFsTm90ZScsIFsnbGlzdE1lc3NhZ2VzJ10pO1xuICAgIGNvbnN0IFt0ZXh0LCBzZXRUZXh0XSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbaW50ZXJuYWwsIHNldEludGVybmFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCByZXZpc2lvbiA9IHVzZVJlZigwKTtcbiAgICBjb25zdCBjdXJyZW50Q29udmVyc2F0aW9uID0gdXNlUmVmKGNvbnZlcnNhdGlvbi5pZCk7XG4gICAgY3VycmVudENvbnZlcnNhdGlvbi5jdXJyZW50ID0gY29udmVyc2F0aW9uLmlkO1xuICAgIGNvbnN0IGNhblNlbmQgPSBjYW5SZXBseSAmJiBvbmxpbmUgJiYgKGludGVybmFsIHx8IChcbiAgICAgICAgY29udmVyc2F0aW9uLm1vZGUgPT09ICdodW1hbicgJiZcbiAgICAgICAgY29udmVyc2F0aW9uLmFzc2lnbmVkVXNlcklkID09PSBzZXNzaW9uLnVzZXIuaWQgJiZcbiAgICAgICAgY29udmVyc2F0aW9uLnNlbmRFbGlnaWJpbGl0eS5zdGF0ZSA9PT0gJ2FsbG93ZWQnXG4gICAgKSk7XG5cbiAgICBjb25zdCBzdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghY2FuU2VuZCB8fCAhdGV4dC50cmltKCkgfHwgc2VuZC5wZW5kaW5nIHx8IG5vdGUucGVuZGluZyB8fCBzZW5kLnVucmVzb2x2ZWQgfHwgbm90ZS51bnJlc29sdmVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZFJldmlzaW9uID0gcmV2aXNpb24uY3VycmVudDtcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkQ29udmVyc2F0aW9uID0gY29udmVyc2F0aW9uLmlkO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKGludGVybmFsKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgbm90ZS5leGVjdXRlKHsgcGF0aDogeyBjb252ZXJzYXRpb25JZDogY29udmVyc2F0aW9uLmlkIH0sIGJvZHk6IHsgdGV4dDogdGV4dC50cmltKCkgfSB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgc2VuZC5leGVjdXRlKHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogeyBjb252ZXJzYXRpb25JZDogY29udmVyc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudE1lc3NhZ2VJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IHRleHQudHJpbSgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWRDb252ZXJzYXRpb25WZXJzaW9uOiBjb252ZXJzYXRpb24udmVyc2lvbixcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXZpc2lvbi5jdXJyZW50ID09PSBzdWJtaXR0ZWRSZXZpc2lvbiAmJiBjdXJyZW50Q29udmVyc2F0aW9uLmN1cnJlbnQgPT09IHN1Ym1pdHRlZENvbnZlcnNhdGlvbikgc2V0VGV4dCgnJyk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLy8gVW5rbm93biBzZW5kcyBwcmVzZXJ2ZSB0ZXh0IGFuZCBkaXNhYmxlIHJldHJpZXMgaW4gdGhlIGNvbW1hbmQgaG9vay5cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8Qm94XG4gICAgICAgICAgICBjb21wb25lbnQ9XCJmb3JtXCJcbiAgICAgICAgICAgIGRhdGEtZHJhZnQtY2xlYW49e3RleHQgPyB1bmRlZmluZWQgOiAndHJ1ZSd9XG4gICAgICAgICAgICBvblN1Ym1pdD17ZXZlbnQgPT4ge1xuICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgdm9pZCBzdWJtaXQoKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBzeD17W2xheW91dFN4LmluYm94LmNvbXBvc2VySW5zZXQsIHsgYm9yZGVyVG9wOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInIH1dfVxuICAgICAgICA+XG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e3NlbmQuZXJyb3IgfHwgbm90ZS5lcnJvcn0gLz5cbiAgICAgICAgICAgIDxGb3JtQ29udHJvbExhYmVsXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJHaGkgY2jDuiBu4buZaSBi4buZIChraMO0bmcgZ+G7rWkga2jDoWNoKVwiXG4gICAgICAgICAgICAgICAgY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e2ludGVybmFsfSBvbkNoYW5nZT17ZXZlbnQgPT4geyByZXZpc2lvbi5jdXJyZW50ICs9IDE7IHNldEludGVybmFsKGV2ZW50LnRhcmdldC5jaGVja2VkKTsgfX0gZGlzYWJsZWQ9eyFjYW5SZXBseX0gLz59XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIG11bHRpbGluZVxuICAgICAgICAgICAgICAgIG1pblJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgbWF4Um93cz17N31cbiAgICAgICAgICAgICAgICBsYWJlbD17aW50ZXJuYWwgPyAnR2hpIGNow7ogY2hvIG5ow7NtJyA6ICdO4buZaSBkdW5nIHRy4bqjIGzhu51pIGtow6FjaCd9XG4gICAgICAgICAgICAgICAgdmFsdWU9e3RleHR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50ID0+IHsgcmV2aXNpb24uY3VycmVudCArPSAxOyBzZXRUZXh0KGxpbWl0Q29kZVBvaW50cyhldmVudC50YXJnZXQudmFsdWUsIGludGVybmFsID8gMTAwMDAgOiAyMDAwMCkpOyB9fVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuUmVwbHl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiBzeD17W2xheW91dFN4LmluYm94LmNvbXBvc2VyQ29udHJvbHNCZWZvcmVHYXAsIGxheW91dFN4LmluYm94LmNvbXBvc2VyQWN0aW9uR2FwXX0+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgIHshb25saW5lID8gJ8SQYW5nIG5nb+G6oWkgdHV54bq/bicgOiAhY2FuU2VuZCA/ICdD4bqnbiB0aeG6v3AgcXXhuqNuIGhv4bq3YyBxdXnhu4FuIGfhu61pIGjhu6NwIGzhu4cnIDogJ1RpbiBn4butaSBxdWEgQVBJLCBraMO0bmcgZMO5bmcgSFRNTCB04burIEFJJ31cbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgICAgICAgICAgIGVuZEljb249ezxTZW5kUm91bmRlZCAvPn1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5TZW5kIHx8ICF0ZXh0LnRyaW0oKSB8fCBzZW5kLnBlbmRpbmcgfHwgbm90ZS5wZW5kaW5nIHx8IHNlbmQudW5yZXNvbHZlZCB8fCBub3RlLnVucmVzb2x2ZWR9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7aW50ZXJuYWwgPyAnTMawdSBnaGkgY2jDuicgOiAnR+G7rWkgdHLhuqMgbOG7nWknfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgPC9Cb3g+XG4gICAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENvbnZlcnNhdGlvbk1lc3NhZ2VMaXN0KHsgbWVzc2FnZXMsIHRpbWV6b25lLCBvblJhdGUgfToge1xuICAgIG1lc3NhZ2VzOiBNZXNzYWdlW107XG4gICAgdGltZXpvbmU6IHN0cmluZztcbiAgICBvblJhdGU6IChtZXNzYWdlOiBNZXNzYWdlKSA9PiB2b2lkO1xufSkge1xuICAgIHJldHVybiBtZXNzYWdlcy5zbGljZSgpLnNvcnQoKGEsIGIpID0+IGEuY3JlYXRlZEF0LmxvY2FsZUNvbXBhcmUoYi5jcmVhdGVkQXQpKS5tYXAobWVzc2FnZSA9PiB7XG4gICAgICAgIGNvbnN0IHNlbmRlckxhYmVsID0gbWVzc2FnZS5kaXJlY3Rpb24gPT09ICdpbnRlcm5hbCcgPyAnR2hpIGNow7ogbuG7mWkgYuG7mScgOiBtZXNzYWdlLnNlbmRlcktpbmQgPT09ICdjdXN0b21lcicgPyAnS2jDoWNoJyA6IG1lc3NhZ2Uuc2VuZGVyS2luZCA9PT0gJ2JvdCcgPyAnVHLhu6MgbMO9IEFJJyA6ICdOaMOibiB2acOqbic7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2VUZXh0ID0gbWVzc2FnZS50ZXh0LnJlcGxhY2UoL1xccysvZywgJyAnKS50cmltKCk7XG4gICAgICAgIGNvbnN0IHByZXZpZXcgPSBBcnJheS5mcm9tKG1lc3NhZ2VUZXh0KS5zbGljZSgwLCA2NCkuam9pbignJyk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2VQcmV2aWV3ID0gcHJldmlldyA9PT0gbWVzc2FnZVRleHQgPyBtZXNzYWdlVGV4dCA6IGAke3ByZXZpZXcudHJpbUVuZCgpfeKApmA7XG5cbiAgICAgICAgcmV0dXJuIDxTdGFjayBrZXk9e21lc3NhZ2UuaWR9IGFsaWduSXRlbXM9e21lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW5ib3VuZCcgPyAnZmxleC1zdGFydCcgOiAnZmxleC1lbmQnfT5cbiAgICAgICAgICAgIDxCb3ggZGF0YS10ZXN0aWQ9XCJpbmJveC1tZXNzYWdlLWJ1YmJsZVwiIHN4PXtbbGF5b3V0U3guaW5ib3guYnViYmxlSW5zZXQsIHtcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzg4JScsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuYnViYmxlLFxuICAgICAgICAgICAgICAgIGJnY29sb3I6IG1lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW50ZXJuYWwnID8gY29sb3JzLnNlbGVjdGVkIDogbWVzc2FnZS5kaXJlY3Rpb24gPT09ICdpbmJvdW5kJyA/IGNvbG9ycy5zdXJmYWNlIDogY29sb3JzLnJhaXNlZCxcbiAgICAgICAgICAgICAgICBib3JkZXI6IG1lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW50ZXJuYWwnID8gJzFweCBzb2xpZCcgOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5oZXJvQm9yZGVyLFxuICAgICAgICAgICAgfV19PlxuICAgICAgICAgICAgICAgIDxTdGFjayBkYXRhLXRlc3RpZD1cImluYm94LW1lc3NhZ2UtbWV0YS1mbG93XCIgc3g9e2xheW91dFN4LmluYm94Lm1lc3NhZ2VNZXRhR2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGRhdGEtdGVzdGlkPVwiaW5ib3gtbWVzc2FnZS1jb250ZW50LWZsb3dcIiBzeD17bGF5b3V0U3guaW5ib3gubWVzc2FnZUNvbnRlbnRHYXB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbmRlckxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgc3g9e3sgd2hpdGVTcGFjZTogJ3ByZS13cmFwJywgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnIH19PnttZXNzYWdlLnRleHR9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZS5zb3VyY2VFdmlkZW5jZS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBzeD17W2xheW91dFN4LnN1cmZhY2UuY29tcGFjdENvbnRlbnRHYXAsIHsgZmxleFdyYXA6ICd3cmFwJyB9XX0gYXJpYS1sYWJlbD1cIk5ndeG7k24gdGhhbSBjaGnhur91XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21lc3NhZ2Uuc291cmNlRXZpZGVuY2UubWFwKChyZWZlcmVuY2UsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGlwIGtleT17YCR7cmVmZXJlbmNlLnR5cGV9OiR7cmVmZXJlbmNlLmlkfToke2luZGV4fWB9IHNpemU9XCJzbWFsbFwiIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGxhYmVsPXtgJHtyZWZlcmVuY2UudHlwZX0gwrcgJHtyZWZlcmVuY2UuaWR9YH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgc3g9e1tsYXlvdXRTeC5pbmJveC5jb21wb3NlckFjdGlvbkdhcCwgeyBmbGV4V3JhcDogJ3dyYXAnIH1dfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPntkYXRlVGltZShtZXNzYWdlLmNyZWF0ZWRBdCwgdGltZXpvbmUpfSDCtyB7bWVzc2FnZS5zdGF0dXN9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YMSQw6FuaCBnacOhIHRpbiBuaOG6r24gY+G7p2EgJHtzZW5kZXJMYWJlbH0gbMO6YyAke2RhdGVUaW1lKG1lc3NhZ2UuY3JlYXRlZEF0LCB0aW1lem9uZSl9OiAke21lc3NhZ2VQcmV2aWV3fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25SYXRlKG1lc3NhZ2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIMSQw6FuaCBnacOhXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvU3RhY2s+O1xuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ29udmVyc2F0aW9uQ29udGV4dFBhbmVsKHsgY29udmVyc2F0aW9uLCBjaGlsZHJlbiB9OiB7XG4gICAgY29udmVyc2F0aW9uOiBDb252ZXJzYXRpb247XG4gICAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59KSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGNhblJlYWRDdXN0b21lcnMgPSB1c2VDYW4oJ2N1c3RvbWVycy5yZWFkJyk7XG4gICAgY29uc3QgY2FuQ3JlYXRlT3JkZXJzID0gdXNlQ2FuKCdvcmRlcnMud3JpdGUnKTtcbiAgICBjb25zdCBtZXRhZGF0YSA9IHVzZUFwaSgnZ2V0SW5ib3hNZXRhZGF0YScpO1xuICAgIGNvbnN0IGFzc2lnbiA9IHVzZUNvbW1hbmQoJ2Fzc2lnbkNvbnZlcnNhdGlvbicsIFsnZ2V0Q29udmVyc2F0aW9uJywgJ2xpc3RDb252ZXJzYXRpb25zJ10pO1xuICAgIGNvbnN0IFthc3NpZ25lZSwgc2V0QXNzaWduZWVdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEJveFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJpbmJveC1jb250ZXh0LXBhbmVsXCJcbiAgICAgICAgICAgIGNvbXBvbmVudD1cImFzaWRlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJC4buRaSBj4bqjbmgga2jDoWNoIGjDoG5nXCJcbiAgICAgICAgICAgIHRhYkluZGV4PXswfVxuICAgICAgICAgICAgc3g9e3sgbWluV2lkdGg6IDAsIG1pbkhlaWdodDogMCwgbWF4SGVpZ2h0OiB7IHhsOiA2NTAgfSwgb3ZlcmZsb3dZOiB7IHhsOiAnYXV0bycgfSB9fVxuICAgICAgICA+XG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJC4buRaSBj4bqjbmgga2jDoWNoIGjDoG5nXCI+XG4gICAgICAgICAgICAgICAgPEJveCBkYXRhLXRlc3RpZD1cImluYm94LWNvbnRleHQtY29udGVudFwiIHN4PXtsYXlvdXRTeC5pbmJveC5jb250ZXh0SW5zZXR9PlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlRy4bqhbmcgdGjDoWlcIj48U3RhdHVzIHZhbHVlPXtjb252ZXJzYXRpb24uc3RhdHVzfSAvPjwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLw6puaFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge21ldGFkYXRhLmRhdGE/LmRhdGEuY2hhbm5lbHMuZmluZChjaGFubmVsID0+IGNoYW5uZWwuaWQgPT09IGNvbnZlcnNhdGlvbi5jaGFubmVsSWQpPy5kaXNwbGF5TmFtZSB8fCBjb252ZXJzYXRpb24uY2hhbm5lbElkfVxuICAgICAgICAgICAgICAgICAgICA8L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgIHtjYW5SZWFkQ3VzdG9tZXJzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2N1c3RvbWVycy8ke2NvbnZlcnNhdGlvbi5jdXN0b21lcklkfWB9Pkjhu5Mgc8ahIGtow6FjaDwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgOiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5UaMO0bmcgdGluIGtow6FjaCBi4buLIOG6qW4gdGhlbyBxdXnhu4FuIGhp4buHbiB04bqhaS48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICB7Y2FuQ3JlYXRlT3JkZXJzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy9uZXc/Y3VzdG9tZXJJZD0ke2NvbnZlcnNhdGlvbi5jdXN0b21lcklkfSZjb252ZXJzYXRpb25JZD0ke2NvbnZlcnNhdGlvbi5pZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBU4bqhbyDEkcahbiB04burIGjhu5lpIHRob+G6oWlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8RGl2aWRlciBzeD17W2xheW91dFN4LnN1cmZhY2Uuc2VjdGlvbkJlZm9yZSwgbGF5b3V0U3gubm90aWNlLmFmdGVyR2FwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkdpYW8gY2hvIG5ow6JuIHZpw6puXCIgc2VsZWN0IGZ1bGxXaWR0aCBzaXplPVwic21hbGxcIiB2YWx1ZT17YXNzaWduZWV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRBc3NpZ25lZShldmVudC50YXJnZXQudmFsdWUpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPkNo4buNbiBuaMOibiB2acOqbjwvTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bWV0YWRhdGEuZGF0YT8uZGF0YS5hc3NpZ25lZXMubWFwKHVzZXIgPT4gPE1lbnVJdGVtIGtleT17dXNlci51c2VySWR9IHZhbHVlPXt1c2VyLnVzZXJJZH0+e3VzZXIuZGlzcGxheU5hbWV9PC9NZW51SXRlbT4pfVxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uPVwiY29udmVyc2F0aW9ucy5hc3NpZ25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFhc3NpZ25lZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1c3k9e2Fzc2lnbi5wZW5kaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvaWQgYXNzaWduLmV4ZWN1dGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiB7IGNvbnZlcnNhdGlvbklkOiBjb252ZXJzYXRpb24uaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogeyB1c2VySWQ6IGFzc2lnbmVlLCBleHBlY3RlZFZlcnNpb246IGNvbnZlcnNhdGlvbi52ZXJzaW9uIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIFBow6JuIGPDtG5nXG4gICAgICAgICAgICAgICAgICAgIDwvTXV0YXRpb25CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17YXNzaWduLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4LnN1cmZhY2Uuc2VjdGlvbkJlZm9yZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICDhuqJuaC90aW4gdGhv4bqhaSBjaOG7iSBi4bqtdCBraGkgaOG7o3AgxJHhu5NuZyBrw6puaCB4w6FjIG5o4bqtbiBo4buXIHRy4bujLiBQaGnDqm4gYuG6o24gQVBJIGhp4buHbiB04bqhaSBj4bunYSDDtCBzb+G6oW4gY2jhu4kgZ+G7rWkgdsSDbiBi4bqjbi5cbiAgICAgICAgICAgICAgICAgICAgPC9BbGVydD5cbiAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgPC9Cb3g+XG4gICAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBZ0VZLGNBZUEsWUFmQTtBQWhFWixTQUFTLFFBQVEsZ0JBQWdCO0FBQ2pDLFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsT0FBTyxLQUFLLFFBQVEsTUFBTSxTQUFTLGtCQUFrQixVQUFVLFVBQVUsT0FBTyxXQUFXLGtCQUFrQjtBQUN0SCxPQUFPLGlCQUFpQjtBQUV4QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxRQUFRLGtCQUFrQjtBQUNuQyxTQUFTLFFBQVEsZ0JBQWdCO0FBQ2pDLFNBQVMsaUJBQWlCLGdCQUFnQjtBQUMxQyxTQUFTLFlBQVksYUFBYSxnQkFBZ0IsT0FBTyxXQUFXLGNBQWM7QUFDbEYsU0FBUyxnQkFBZ0I7QUFFbEIsZ0JBQVMscUJBQXFCLEVBQUUsYUFBYSxHQUVqRDtBQUNDLFFBQU0sRUFBRSxTQUFTLE9BQU8sSUFBSSxTQUFTO0FBQ3JDLFFBQU0sV0FBVyxPQUFPLHFCQUFxQjtBQUM3QyxRQUFNLE9BQU8sV0FBVyxlQUFlLENBQUMsZ0JBQWdCLG1CQUFtQixtQkFBbUIsQ0FBQztBQUMvRixRQUFNLE9BQU8sV0FBVyxtQkFBbUIsQ0FBQyxjQUFjLENBQUM7QUFDM0QsUUFBTSxDQUFDLE1BQU0sT0FBTyxJQUFJLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUMsVUFBVSxXQUFXLElBQUksU0FBUyxLQUFLO0FBQzlDLFFBQU0sV0FBVyxPQUFPLENBQUM7QUFDekIsUUFBTSxzQkFBc0IsT0FBTyxhQUFhLEVBQUU7QUFDbEQsc0JBQW9CLFVBQVUsYUFBYTtBQUMzQyxRQUFNLFVBQVUsWUFBWSxXQUFXLFlBQ25DLGFBQWEsU0FBUyxXQUN0QixhQUFhLG1CQUFtQixRQUFRLEtBQUssTUFDN0MsYUFBYSxnQkFBZ0IsVUFBVTtBQUczQyxRQUFNLFNBQVMsWUFBWTtBQUN2QixRQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLFdBQVcsS0FBSyxjQUFjLEtBQUssV0FBWTtBQUNwRyxVQUFNLG9CQUFvQixTQUFTO0FBQ25DLFVBQU0sd0JBQXdCLGFBQWE7QUFDM0MsUUFBSTtBQUNBLFVBQUksVUFBVTtBQUNWLGNBQU0sS0FBSyxRQUFRLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixhQUFhLEdBQUcsR0FBRyxNQUFNLEVBQUUsTUFBTSxLQUFLLEtBQUssRUFBRSxFQUFFLENBQUM7QUFBQSxNQUNqRyxPQUFPO0FBQ0gsY0FBTSxLQUFLLFFBQVE7QUFBQSxVQUNmLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxHQUFHO0FBQUEsVUFDeEMsTUFBTTtBQUFBLFlBQ0YsaUJBQWlCLE9BQU8sV0FBVztBQUFBLFlBQ25DLE1BQU0sS0FBSyxLQUFLO0FBQUEsWUFDaEIsNkJBQTZCLGFBQWE7QUFBQSxVQUM5QztBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ0w7QUFDQSxVQUFJLFNBQVMsWUFBWSxxQkFBcUIsb0JBQW9CLFlBQVksc0JBQXVCLFNBQVEsRUFBRTtBQUFBLElBQ25ILFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFdBQVU7QUFBQSxNQUNWLG9CQUFrQixPQUFPLFNBQVk7QUFBQSxNQUNyQyxVQUFVLFdBQVM7QUFDZixjQUFNLGVBQWU7QUFDckIsYUFBSyxPQUFPO0FBQUEsTUFDaEI7QUFBQSxNQUNBLElBQUksQ0FBQyxTQUFTLE1BQU0sZUFBZSxFQUFFLFdBQVcsR0FBRyxhQUFhLFVBQVUsQ0FBQztBQUFBLE1BRTNFO0FBQUEsNEJBQUMsZUFBWSxPQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFBQSxRQUM5QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sU0FBUyxvQkFBQyxZQUFTLFNBQVMsVUFBVSxVQUFVLFdBQVM7QUFBRSx1QkFBUyxXQUFXO0FBQUcsMEJBQVksTUFBTSxPQUFPLE9BQU87QUFBQSxZQUFHLEdBQUcsVUFBVSxDQUFDLFVBQVU7QUFBQTtBQUFBLFFBQ2pKO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBUztBQUFBLFlBQ1QsV0FBUztBQUFBLFlBQ1QsU0FBUztBQUFBLFlBQ1QsU0FBUztBQUFBLFlBQ1QsT0FBTyxXQUFXLHFCQUFxQjtBQUFBLFlBQ3ZDLE9BQU87QUFBQSxZQUNQLFVBQVUsV0FBUztBQUFFLHVCQUFTLFdBQVc7QUFBRyxzQkFBUSxnQkFBZ0IsTUFBTSxPQUFPLE9BQU8sV0FBVyxNQUFRLEdBQUssQ0FBQztBQUFBLFlBQUc7QUFBQSxZQUNwSCxVQUFVLENBQUM7QUFBQTtBQUFBLFFBQ2Y7QUFBQSxRQUNBLHFCQUFDLFNBQU0sV0FBVSxPQUFNLFlBQVcsVUFBUyxnQkFBZSxpQkFBZ0IsSUFBSSxDQUFDLFNBQVMsTUFBTSwyQkFBMkIsU0FBUyxNQUFNLGlCQUFpQixHQUNySjtBQUFBLDhCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQy9CLFdBQUMsU0FBUyxxQkFBcUIsQ0FBQyxVQUFVLHdDQUF3QywwQ0FDdkY7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixTQUFTLG9CQUFDLGVBQVk7QUFBQSxjQUN0QixVQUFVLENBQUMsV0FBVyxDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLFdBQVcsS0FBSyxjQUFjLEtBQUs7QUFBQSxjQUU3RixxQkFBVyxnQkFBZ0I7QUFBQTtBQUFBLFVBQ2hDO0FBQUEsV0FDSjtBQUFBO0FBQUE7QUFBQSxFQUNKO0FBRVI7QUFFTyxnQkFBUyx3QkFBd0IsRUFBRSxVQUFVLFVBQVUsT0FBTyxHQUlsRTtBQUNDLFNBQU8sU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFVBQVUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxFQUFFLElBQUksYUFBVztBQUMxRixVQUFNLGNBQWMsUUFBUSxjQUFjLGFBQWEsbUJBQW1CLFFBQVEsZUFBZSxhQUFhLFVBQVUsUUFBUSxlQUFlLFFBQVEsY0FBYztBQUNySyxVQUFNLGNBQWMsUUFBUSxLQUFLLFFBQVEsUUFBUSxHQUFHLEVBQUUsS0FBSztBQUMzRCxVQUFNLFVBQVUsTUFBTSxLQUFLLFdBQVcsRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRTtBQUM1RCxVQUFNLGlCQUFpQixZQUFZLGNBQWMsY0FBYyxHQUFHLFFBQVEsUUFBUSxDQUFDO0FBRW5GLFdBQU8sb0JBQUMsU0FBdUIsWUFBWSxRQUFRLGNBQWMsWUFBWSxlQUFlLFlBQ3hGLDhCQUFDLE9BQUksZUFBWSx3QkFBdUIsSUFBSSxDQUFDLFNBQVMsTUFBTSxhQUFhO0FBQUEsTUFDckUsVUFBVTtBQUFBLE1BQ1YsY0FBYyxTQUFTLE9BQU87QUFBQSxNQUM5QixTQUFTLFFBQVEsY0FBYyxhQUFhLE9BQU8sV0FBVyxRQUFRLGNBQWMsWUFBWSxPQUFPLFVBQVUsT0FBTztBQUFBLE1BQ3hILFFBQVEsUUFBUSxjQUFjLGFBQWEsY0FBYztBQUFBLE1BQ3pELGFBQWEsT0FBTztBQUFBLElBQ3hCLENBQUMsR0FDRywrQkFBQyxTQUFNLGVBQVksMkJBQTBCLElBQUksU0FBUyxNQUFNLGdCQUM1RDtBQUFBLDJCQUFDLFNBQU0sZUFBWSw4QkFBNkIsSUFBSSxTQUFTLE1BQU0sbUJBQy9EO0FBQUEsNEJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFDL0IsdUJBQ0w7QUFBQSxRQUNBLG9CQUFDLGNBQVcsSUFBSSxFQUFFLFlBQVksWUFBWSxjQUFjLFdBQVcsR0FBSSxrQkFBUSxNQUFLO0FBQUEsU0FDeEY7QUFBQSxNQUNDLFFBQVEsZUFBZSxTQUFTLEtBQzdCLG9CQUFDLFNBQU0sV0FBVSxPQUFNLElBQUksQ0FBQyxTQUFTLFFBQVEsbUJBQW1CLEVBQUUsVUFBVSxPQUFPLENBQUMsR0FBRyxjQUFXLG9CQUM3RixrQkFBUSxlQUFlLElBQUksQ0FBQyxXQUFXLFVBQ3BDLG9CQUFDLFFBQXdELE1BQUssU0FBUSxTQUFRLFlBQVcsT0FBTyxHQUFHLFVBQVUsSUFBSSxNQUFNLFVBQVUsRUFBRSxNQUF4SCxHQUFHLFVBQVUsSUFBSSxJQUFJLFVBQVUsRUFBRSxJQUFJLEtBQUssRUFBa0YsQ0FDMUksR0FDTDtBQUFBLE1BRUoscUJBQUMsU0FBTSxXQUFVLE9BQU0sWUFBVyxVQUFTLElBQUksQ0FBQyxTQUFTLE1BQU0sbUJBQW1CLEVBQUUsVUFBVSxPQUFPLENBQUMsR0FDbEc7QUFBQSw2QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFrQjtBQUFBLG1CQUFTLFFBQVEsV0FBVyxRQUFRO0FBQUEsVUFBRTtBQUFBLFVBQUksUUFBUTtBQUFBLFdBQU87QUFBQSxRQUMvRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsY0FBWSx5QkFBeUIsV0FBVyxRQUFRLFNBQVMsUUFBUSxXQUFXLFFBQVEsQ0FBQyxLQUFLLGNBQWM7QUFBQSxZQUNoSCxTQUFTLE1BQU0sT0FBTyxPQUFPO0FBQUEsWUFDaEM7QUFBQTtBQUFBLFFBRUQ7QUFBQSxTQUNKO0FBQUEsT0FDSixHQUNKLEtBakNlLFFBQVEsRUFrQzNCO0FBQUEsRUFDSixDQUFDO0FBQ0w7QUFFTyxnQkFBUyx5QkFBeUIsRUFBRSxjQUFjLFNBQVMsR0FHL0Q7QUFDQyxRQUFNLEVBQUUsS0FBSyxJQUFJLFNBQVM7QUFDMUIsUUFBTSxtQkFBbUIsT0FBTyxnQkFBZ0I7QUFDaEQsUUFBTSxrQkFBa0IsT0FBTyxjQUFjO0FBQzdDLFFBQU0sV0FBVyxPQUFPLGtCQUFrQjtBQUMxQyxRQUFNLFNBQVMsV0FBVyxzQkFBc0IsQ0FBQyxtQkFBbUIsbUJBQW1CLENBQUM7QUFDeEYsUUFBTSxDQUFDLFVBQVUsV0FBVyxJQUFJLFNBQVMsRUFBRTtBQUUzQyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxlQUFZO0FBQUEsTUFDWixXQUFVO0FBQUEsTUFDVixjQUFXO0FBQUEsTUFDWCxVQUFVO0FBQUEsTUFDVixJQUFJLEVBQUUsVUFBVSxHQUFHLFdBQVcsR0FBRyxXQUFXLEVBQUUsSUFBSSxJQUFJLEdBQUcsV0FBVyxFQUFFLElBQUksT0FBTyxFQUFFO0FBQUEsTUFFbkYsOEJBQUMsU0FBTSxPQUFNLHVCQUNULCtCQUFDLE9BQUksZUFBWSx5QkFBd0IsSUFBSSxTQUFTLE1BQU0sY0FDeEQ7QUFBQSw0QkFBQyxjQUFXLE9BQU0sY0FBYSw4QkFBQyxVQUFPLE9BQU8sYUFBYSxRQUFRLEdBQUU7QUFBQSxRQUNyRSxvQkFBQyxjQUFXLE9BQU0sUUFDYixtQkFBUyxNQUFNLEtBQUssU0FBUyxLQUFLLGFBQVcsUUFBUSxPQUFPLGFBQWEsU0FBUyxHQUFHLGVBQWUsYUFBYSxXQUN0SDtBQUFBLFFBQ0MsbUJBQ0ssb0JBQUMsYUFBVSxJQUFJLE1BQU0sS0FBSyxFQUFFLGNBQWMsYUFBYSxVQUFVLElBQUkseUJBQVcsSUFDaEYsb0JBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsd0RBQTBDO0FBQUEsUUFDcEcsbUJBQ0csb0JBQUMsYUFBVSxJQUFJLE1BQU0sS0FBSyxFQUFFLDBCQUEwQixhQUFhLFVBQVUsbUJBQW1CLGFBQWEsRUFBRSxJQUFJLGtDQUVuSDtBQUFBLFFBRUosb0JBQUMsV0FBUSxJQUFJLENBQUMsU0FBUyxRQUFRLGVBQWUsU0FBUyxPQUFPLFFBQVEsR0FBRztBQUFBLFFBQ3pFLHFCQUFDLGFBQVUsT0FBTSxzQkFBcUIsUUFBTSxNQUFDLFdBQVMsTUFBQyxNQUFLLFNBQVEsT0FBTyxVQUFVLFVBQVUsV0FBUyxZQUFZLE1BQU0sT0FBTyxLQUFLLEdBQ2xJO0FBQUEsOEJBQUMsWUFBUyxPQUFNLElBQUcsNEJBQWM7QUFBQSxVQUNoQyxTQUFTLE1BQU0sS0FBSyxVQUFVLElBQUksVUFBUSxvQkFBQyxZQUEyQixPQUFPLEtBQUssUUFBUyxlQUFLLGVBQXZDLEtBQUssTUFBOEMsQ0FBVztBQUFBLFdBQzVIO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csWUFBVztBQUFBLFlBQ1gsVUFBVSxDQUFDO0FBQUEsWUFDWCxNQUFNLE9BQU87QUFBQSxZQUNiLFNBQVMsTUFBTTtBQUNYLG1CQUFLLE9BQU8sUUFBUTtBQUFBLGdCQUNoQixNQUFNLEVBQUUsZ0JBQWdCLGFBQWEsR0FBRztBQUFBLGdCQUN4QyxNQUFNLEVBQUUsUUFBUSxVQUFVLGlCQUFpQixhQUFhLFFBQVE7QUFBQSxjQUNwRSxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQVM7QUFBQSxZQUM1QjtBQUFBLFlBQ0g7QUFBQTtBQUFBLFFBRUQ7QUFBQSxRQUNBLG9CQUFDLGVBQVksT0FBTyxPQUFPLE9BQU87QUFBQSxRQUNsQyxvQkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJLFNBQVMsUUFBUSxlQUFlLHlIQUUzRDtBQUFBLFFBQ0M7QUFBQSxTQUNMLEdBQ0o7QUFBQTtBQUFBLEVBQ0o7QUFFUjsiLCJuYW1lcyI6W119