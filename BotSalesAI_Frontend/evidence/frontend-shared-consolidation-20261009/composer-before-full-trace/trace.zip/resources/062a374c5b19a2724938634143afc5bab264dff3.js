"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-TJQ5SMJY.js?v=10e18444";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-5MCOKOAT.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-TXMVIKFK.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-I5OUBJPO.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-6L6YWZTZ.js?v=10e18444";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-A3OKMDK7.js?v=10e18444";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-PX6F3LHL.js?v=10e18444";

// ../../node_modules/@mui/icons-material/esm/SendRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var SendRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "m3.4 20.4 17.45-7.48c.81-.35.81-1.49 0-1.84L3.4 3.6c-.66-.29-1.39.2-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91"
}), "SendRounded");
export {
  SendRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_SendRounded.js.map
