"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-TJQ5SMJY.js?v=10e18444";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-5MCOKOAT.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-TXMVIKFK.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-I5OUBJPO.js?v=10e18444";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-6L6YWZTZ.js?v=10e18444";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-A3OKMDK7.js?v=10e18444";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-19880-70f70927-8b88-44ec-ad68-90d75b6e4157/deps/chunk-PX6F3LHL.js?v=10e18444";

// ../../node_modules/@mui/icons-material/esm/ArrowBackRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var ArrowBackRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M19 11H7.83l4.88-4.88c.39-.39.39-1.03 0-1.42a.996.996 0 0 0-1.41 0l-6.59 6.59c-.39.39-.39 1.02 0 1.41l6.59 6.59c.39.39 1.02.39 1.41 0s.39-1.02 0-1.41L7.83 13H19c.55 0 1-.45 1-1s-.45-1-1-1"
}), "ArrowBackRounded");
export {
  ArrowBackRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_ArrowBackRounded.js.map
