import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react-router-dom.js?v=a3db78bb";
export function useListQuery(cursorParam = "cursor") {
  const [params] = useSearchParams();
  const query = { limit: 20 };
  for (const key of ["q", "cursor", "status", "state", "orderId", "variantId", "warehouseId", "supplierId", "purchaseOrderId", "kind"])
    if (params.has(key === "cursor" ? cursorParam : key))
      query[key] = params.get(key === "cursor" ? cursorParam : key) || void 0;
  return query;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbHRlcnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5leHBvcnQgZnVuY3Rpb24gdXNlTGlzdFF1ZXJ5KGN1cnNvclBhcmFtID0gJ2N1cnNvcicpIHtcbiAgICBjb25zdCBbcGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IHF1ZXJ5OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBudW1iZXIgfCB1bmRlZmluZWQ+ID0geyBsaW1pdDogMjAgfTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBbJ3EnLCAnY3Vyc29yJywgJ3N0YXR1cycsICdzdGF0ZScsICdvcmRlcklkJywgJ3ZhcmlhbnRJZCcsICd3YXJlaG91c2VJZCcsICdzdXBwbGllcklkJywgJ3B1cmNoYXNlT3JkZXJJZCcsICdraW5kJ10pXG4gICAgICAgIGlmIChwYXJhbXMuaGFzKGtleSA9PT0gJ2N1cnNvcicgPyBjdXJzb3JQYXJhbSA6IGtleSkpXG4gICAgICAgICAgICBxdWVyeVtrZXldID0gcGFyYW1zLmdldChrZXkgPT09ICdjdXJzb3InID8gY3Vyc29yUGFyYW0gOiBrZXkpIHx8IHVuZGVmaW5lZDtcbiAgICByZXR1cm4gcXVlcnk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsdUJBQXVCO0FBQ3pCLGdCQUFTLGFBQWEsY0FBYyxVQUFVO0FBQ2pELFFBQU0sQ0FBQyxNQUFNLElBQUksZ0JBQWdCO0FBQ2pDLFFBQU0sUUFBcUQsRUFBRSxPQUFPLEdBQUc7QUFDdkUsYUFBVyxPQUFPLENBQUMsS0FBSyxVQUFVLFVBQVUsU0FBUyxXQUFXLGFBQWEsZUFBZSxjQUFjLG1CQUFtQixNQUFNO0FBQy9ILFFBQUksT0FBTyxJQUFJLFFBQVEsV0FBVyxjQUFjLEdBQUc7QUFDL0MsWUFBTSxHQUFHLElBQUksT0FBTyxJQUFJLFFBQVEsV0FBVyxjQUFjLEdBQUcsS0FBSztBQUN6RSxTQUFPO0FBQ1g7IiwibmFtZXMiOltdfQ==