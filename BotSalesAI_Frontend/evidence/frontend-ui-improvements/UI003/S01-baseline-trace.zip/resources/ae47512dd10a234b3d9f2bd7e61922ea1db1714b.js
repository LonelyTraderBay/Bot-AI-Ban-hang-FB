import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/workspace/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react_jsx-dev-runtime.js?v=89ec09ef"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react.js?v=89ec09ef"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Link as RouterLink, Navigate, useNavigate, useParams, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react-router-dom.js?v=a3db78bb";
import { useQuery, useQueryClient } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@tanstack_react-query.js?v=d7dea216";
import { Alert, Avatar, Box, Button, Checkbox, FormControlLabel, MenuItem, Paper, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@mui_material.js?v=f046cc3b";
import SmartToyRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@mui_icons-material_SmartToyRounded.js?v=96fa1dcc";
import ArrowForwardRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@mui_icons-material_ArrowForwardRounded.js?v=5d0837a6";
import { permissionCatalog } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/contracts/src/index.ts";
import { colors } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { request, setCsrfToken } from "/src/shared/api/client.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { ApiError } from "/src/shared/api/errors.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { dateTime, safeInternalPath } from "/src/shared/model/format.ts";
import { authorizedDownloadHref } from "/src/shared/model/download.ts";
import { useListQuery } from "/src/shared/model/filters.ts";
import { markDraftClean, setDraftDirty } from "/src/shared/model/dirty-drafts.ts";
import { PageHeader, Panel, QueryState, DataTable, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine } from "/src/shared/ui/components.tsx";
import { useSession } from "/src/shared/model/auth.ts";
function AuthCard({
  children
}) {
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: { minHeight: "100vh", display: "grid", placeItems: "center", p: 3, bgcolor: "background.default", outline: "none" }, children: /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: { width: "100%", maxWidth: 520, p: { xs: 3, sm: 5 }, borderRadius: 4 }, children: [
    /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", gap: 1.5, sx: { mb: 4 }, children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: "primary.main", color: colors.onAccent }, children: /* @__PURE__ */ jsxDEV(SmartToyRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 42,
        columnNumber: 446
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 42,
        columnNumber: 381
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: 800, children: [
        "BotSales ",
        /* @__PURE__ */ jsxDEV(Box, { component: "span", color: "primary.main", children: "AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 42,
          columnNumber: 525
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 42,
        columnNumber: 474
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 42,
      columnNumber: 313
    }, this),
    children
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 42,
    columnNumber: 211
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 42,
    columnNumber: 36
  }, this);
}
_c = AuthCard;
export function LoginPage() {
  _s();
  const { session, loading } = useSession();
  const [params] = useSearchParams();
  const [pending, setPending] = useState(false), [error, setError] = useState(null);
  const login = async () => {
    setPending(true);
    setError(null);
    try {
      const csrf = await request("getCsrfToken");
      setCsrfToken(csrf.data.csrfToken);
      const auth = await request("beginLogin", { body: { returnTo: safeInternalPath(params.get("returnTo") || "/workspaces") } });
      const url = new URL(auth.data.authorizationUrl);
      if (url.protocol !== "https:" && !(__MOCK__ && url.origin === location.origin))
        throw new Error("Địa chỉ đăng nhập không an toàn.");
      window.location.assign(url.href);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không bắt đầu được đăng nhập"));
      setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: { mb: 1 }, children: "Chào mừng trở lại" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: { mb: 4 }, children: "Một không gian cho bán hàng, kho, kế toán và đội ngũ AI của bạn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 105
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 232
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { mb: 3 }, children: "Chế độ xem frontend: tài khoản giả lập, không có mật khẩu thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 274
    }, this),
    session ? /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, component: RouterLink, to: "/workspaces", variant: "contained", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 482
    }, this), children: "Tiếp tục vào cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 395
    }, this) : /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, variant: "contained", size: "large", onClick: () => void login(), disabled: pending || loading, children: pending ? "Đang chuyển đến đăng nhập…" : __MOCK__ ? "Vào tài khoản mô phỏng" : "Đăng nhập bằng tài khoản công ty" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 540
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: { display: "block", mt: 3 }, children: "Phiên đăng nhập được quản lý ở máy chủ. Không lưu access token trong localStorage." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 60,
      columnNumber: 775
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 60,
    columnNumber: 10
  }, this);
}
_s(LoginPage, "tICyXXnoQDGPm2VsFQW+6n6svQk=", false, function() {
  return [useSession, useSearchParams];
});
_c2 = LoginPage;
export function WorkspacesPage() {
  _s2();
  const { session, loading, error: sessionError } = useSession();
  const shops = useQuery({ queryKey: ["shops", session?.user.id], queryFn: ({ signal }) => request("listShops", { signal }), enabled: !!session, retry: false });
  if (!loading && !session && sessionError instanceof ApiError && sessionError.status === 401)
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 66,
      columnNumber: 10
    }, this);
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: { maxWidth: 1100, mx: "auto", p: { xs: 3, md: 6 }, outline: "none" }, children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Chọn cửa hàng", subtitle: "Mỗi cửa hàng là một vùng dữ liệu và quyền độc lập.", actions: /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/onboarding", variant: "contained", children: "Tạo cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 243
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 138
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: sessionError }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 336
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: shops, children: /* @__PURE__ */ jsxDEV(Box, { sx: { display: "grid", gridTemplateColumns: { xs: "1fr", md: "repeat(2,1fr)" }, gap: 3 }, children: shops.data?.data.map((s) => /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: { p: 3, borderRadius: 3 }, children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { mb: 2, bgcolor: colors.selected, color: "primary.main" }, children: s.name[0] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 590
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", children: s.name }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 682
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: { my: 1.5 }, children: [
        s.currency,
        " · ",
        s.timezone
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 728
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
        "Quyền: ",
        session?.memberships.find((m) => m.shopId === s.id)?.roles.join(", ") || "Chưa có quyền"
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 820
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: `/s/${s.id}/overview`, fullWidth: true, variant: "outlined", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 1079
      }, this), sx: { mt: 3 }, children: "Mở cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 67,
        columnNumber: 983
      }, this)
    ] }, s.id, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 522
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 398
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 372
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 67,
    columnNumber: 10
  }, this);
}
_s2(WorkspacesPage, "9VKV6RNilsXVUNYTqRFP3NwfT3I=", false, function() {
  return [useSession, useQuery];
});
_c3 = WorkspacesPage;
export function OnboardingPage() {
  _s3();
  const navigate = useNavigate();
  const { refresh } = useSession();
  const cache = useQueryClient();
  const [name, setName] = useState(""), [currency, setCurrency] = useState("VND"), [timezone, setTimezone] = useState("Asia/Vientiane"), [pending, setPending] = useState(false), [error, setError] = useState(null);
  const save = async () => {
    setPending(true);
    setError(null);
    try {
      new Intl.DateTimeFormat("vi", { timeZone: timezone });
      const r = await request("createShop", { body: { name, currency, timezone, locale: "vi-VN" } });
      await refresh();
      await cache.invalidateQueries({ queryKey: ["shops"] });
      navigate(`/s/${r.data.id}/overview`);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không tạo được cửa hàng"));
    } finally {
      setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: { mb: 1 }, children: "Tạo cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 87,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: { mb: 3 }, children: "Chọn tiền tệ cơ sở trước khi ghi nhận giao dịch." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 87,
      columnNumber: 100
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 87,
      columnNumber: 211
    }, this),
    /* @__PURE__ */ jsxDEV(Stack, { gap: 2.5, children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Tên cửa hàng", value: name, onChange: (e) => setName(e.target.value), inputProps: { maxLength: 160 } }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 257
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Tiền tệ cơ sở", select: true, value: currency, onChange: (e) => setCurrency(e.target.value), children: ["VND", "LAK", "THB", "USD"].map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c, children: c }, c, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 522
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 378
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Múi giờ", value: timezone, onChange: (e) => setTimezone(e.target.value) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 578
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giao diện Graphite Gold dark-only đã chốt. Những chính sách thật và kết nối ngoài chưa tự bật khi tạo shop." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 670
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !name.trim() || !timezone || pending, onClick: () => void save(), children: "Tạo cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 808
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/workspaces", children: "Quay lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 87,
        columnNumber: 933
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 87,
      columnNumber: 240
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 87,
    columnNumber: 10
  }, this);
}
_s3(OnboardingPage, "6aMICNv0qlOf8BbcGl2VjVr0Op8=", false, function() {
  return [useNavigate, useSession, useQueryClient];
});
_c4 = OnboardingPage;
export function ShopSettingsPage() {
  _s4();
  const scope = useScope();
  const { shop } = scope;
  const cache = useQueryClient();
  const canManageShop = useCan("shop.manage");
  const update = useCommand("updateShop", ["getShop"]);
  const [name, setName] = useState(shop.name), [timezone, setTimezone] = useState(shop.timezone), [locale, setLocale] = useState(shop.locale), [error, setError] = useState(null), [saved, setSaved] = useState(false);
  const formRef = useRef(null);
  const baseline = useRef({ shopId: shop.id, name: shop.name, timezone: shop.timezone, locale: shop.locale });
  const draft = useRef(baseline.current);
  useEffect(() => {
    if (baseline.current.shopId === shop.id)
      return;
    const next = { shopId: shop.id, name: shop.name, timezone: shop.timezone, locale: shop.locale };
    baseline.current = next;
    draft.current = next;
    setName(next.name);
    setTimezone(next.timezone);
    setLocale(next.locale);
    setError(null);
    setSaved(false);
    if (formRef.current)
      markDraftClean(formRef.current);
  }, [shop.id, shop.locale, shop.name, shop.timezone]);
  const updateField = (field, value) => {
    const next = { ...draft.current, [field]: value };
    draft.current = next;
    setDraftDirty(formRef.current, next.shopId !== baseline.current.shopId || next.name !== baseline.current.name || next.timezone !== baseline.current.timezone || next.locale !== baseline.current.locale);
    setSaved(false);
  };
  const save = async (form) => {
    setError(null);
    setSaved(false);
    try {
      new Intl.DateTimeFormat(locale, { timeZone: timezone });
      const result = await update.execute({ path: { shopId: shop.id }, version: shop.version, body: { name, timezone, locale } });
      cache.setQueryData(["shop", scope.session.user.id, shop.id, scope.membership.permissionVersion], result);
      const persisted = { shopId: result.data.id, name: result.data.name, timezone: result.data.timezone, locale: result.data.locale };
      baseline.current = persisted;
      draft.current = persisted;
      setName(persisted.name);
      setTimezone(persisted.timezone);
      setLocale(persisted.locale);
      markDraftClean(form);
      setSaved(true);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không lưu được cấu hình"));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thiết lập cửa hàng", subtitle: "Cấu hình riêng của shop không thay đổi quy tắc AI lập trình hoặc màu đã duyệt." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Stack, { gap: 3, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Thông tin cơ sở", children: /* @__PURE__ */ jsxDEV(Stack, { component: "form", ref: formRef, noValidate: true, onSubmit: (event) => {
        event.preventDefault();
        void save(event.currentTarget);
      }, gap: 2.5, sx: { p: 3, maxWidth: 760 }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || update.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 144,
          columnNumber: 21
        }, this),
        saved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã lưu cấu hình cửa hàng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 145,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên cửa hàng", value: name, disabled: !canManageShop, onChange: (event) => {
          setName(event.target.value);
          updateField("name", event.target.value);
        } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 146,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tiền tệ cơ sở", value: shop.currency, disabled: true, helperText: "Không đổi tiền tệ bằng sửa giao diện. Cần kế hoạch chuyển đổi dữ liệu." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 147,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Múi giờ", value: timezone, disabled: !canManageShop, onChange: (event) => {
          setTimezone(event.target.value);
          updateField("timezone", event.target.value);
        } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 148,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Ngôn ngữ", value: locale, disabled: !canManageShop, onChange: (event) => {
          setLocale(event.target.value);
          updateField("locale", event.target.value);
        } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 149,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao diện", value: "Graphite Gold · Dark-only", disabled: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 150,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "shop.manage", type: "submit", variant: "contained", busy: update.pending, disabled: !name.trim() || !timezone, children: "Lưu cấu hình" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 151,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 143,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 142,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Checklist thiết lập vận hành", subtitle: "Các mục không có trường API được giữ ở trạng thái chưa xác minh; không suy diễn đã sẵn sàng.", children: /* @__PURE__ */ jsxDEV(Stack, { gap: 1, sx: { p: 3 }, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          __MOCK__ ? "Bản xem trước mô phỏng. Chỉ tên, tiền tệ, múi giờ và ngôn ngữ được lưu qua API hiện tại." : "API hiện chỉ cho phép sửa thông tin cơ sở được hỗ trợ.",
          " Quốc gia kinh doanh không được suy ra từ múi giờ."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 156,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Quốc gia và giờ kinh doanh", status: "Chưa có trường cấu hình trong contract" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 157,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Địa chỉ, vùng giao và phí vận chuyển", status: __MOCK__ ? "Có preview mô phỏng, chưa lưu cấu hình" : "Chưa có operation cấu hình vùng giao", to: `/s/${shop.id}/shipments`, action: "Xem preview phí giao" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 158,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Người duyệt và thành viên", status: "Quyền lấy từ membership; chưa có API gán chính sách duyệt", to: `/s/${shop.id}/settings/team`, action: "Quản lý thành viên" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 159,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối kênh bán hàng", status: __MOCK__ ? "Kết nối mô phỏng; không có quyền provider thật" : "Kiểm tra trạng thái kết nối", to: `/s/${shop.id}/integrations/channels`, action: "Mở kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 160,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối AI", status: __MOCK__ ? "Catalog nhà cung cấp mô phỏng" : "Kiểm tra catalog nhà cung cấp", to: `/s/${shop.id}/integrations/ai`, action: "Mở nhà cung cấp AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Nội dung sản phẩm và phiên bản kiến thức", status: "Nguồn nội dung, lịch sử phiên bản và duyệt nằm trong khu vực kiến thức.", to: `/s/${shop.id}/knowledge`, action: "Quản lý nội dung" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 162,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Vòng góp ý có duyệt", status: "Góp ý tạo bản nháp; không tự huấn luyện hoặc xuất bản.", to: `/s/${shop.id}/knowledge/feedback`, action: "Duyệt góp ý" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 163,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Consent và ngừng liên hệ marketing", status: "Có preview tương tác; contract chưa có trường consent hoặc thao tác opt-out.", to: `/s/${shop.id}/settings/privacy`, action: "Xem thử consent" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 164,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 155,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 154,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 139,
    columnNumber: 10
  }, this);
}
_s4(ShopSettingsPage, "HNsD87gk2XPKEoVA+jNjsB41ltQ=", false, function() {
  return [useScope, useQueryClient, useCan, useCommand];
});
_c5 = ShopSettingsPage;
function SetupChecklistItem({ title, status, to, action }) {
  return /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", alignItems: { xs: "flex-start", md: "center" }, justifyContent: "space-between", gap: 2, p: 1.5, border: 1, borderColor: "divider", borderRadius: 1, flexWrap: "wrap" }, children: [
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { fontWeight: 650, children: title }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 172,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 172,
        columnNumber: 63
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 172,
      columnNumber: 9
    }, this),
    to && action && /* @__PURE__ */ jsxDEV(RouteLink, { to, children: action }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 173,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 171,
    columnNumber: 10
  }, this);
}
_c6 = SetupChecklistItem;
const roleLabels = {
  owner: "Chủ cửa hàng",
  manager: "Quản lý",
  sales: "Bán hàng",
  warehouse: "Nhân viên kho",
  accountant: "Kế toán",
  bot_admin: "Quản trị AI",
  viewer: "Chỉ xem"
};
export function TeamPage() {
  _s5();
  const { session } = useScope();
  const list = useApi("listMembers", { query: useListQuery() });
  const invite = useCommand("inviteMember", ["listMembers"]);
  const update = useCommand("updateMemberRoles", ["listMembers"]);
  const revoke = useCommand("revokeMembership", ["listMembers"]);
  const [edit, setEdit] = useState(), [email, setEmail] = useState(""), [roles, setRoles] = useState(["viewer"]), [remove, setRemove] = useState(null);
  const open = (m) => {
    setEdit(m);
    setEmail("");
    setRoles(m?.roles || ["viewer"]);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhân sự & phân quyền", subtitle: "Vai trò là bộ quyền mặc định; API quyết định quyền hiệu lực ở từng thao tác.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", variant: "contained", onClick: () => open(null), children: "Mời nhân viên" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 187,
      columnNumber: 150
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 187,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 187,
        columnNumber: 282
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { rows: list.data.data, rowKey: (m) => m.id, columns: [
          { key: "user", label: "Nhân viên", render: (m) => m.userId === session.user.id ? session.user.displayName : m.userId },
          { key: "roles", label: "Vai trò", render: (m) => m.roles.map((r) => roleLabels[r]).join(", ") },
          { key: "status", label: "Trạng thái", render: (m) => /* @__PURE__ */ jsxDEV(Status, { value: m.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 188,
            columnNumber: 281
          }, this) },
          { key: "perms", label: "Quyền hiệu lực", render: (m) => `${m.permissions.length} quyền · v${m.permissionVersion}` },
          {
            key: "actions",
            label: "",
            render: (m) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", children: [
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", onClick: () => open(m), children: "Sửa quyền" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 190,
                columnNumber: 78
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", color: "error", disabled: m.userId === session.user.id || m.status === "revoked", onClick: () => setRemove(m), children: "Thu hồi" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 190,
                columnNumber: 172
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
              lineNumber: 190,
              columnNumber: 55
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 187,
          columnNumber: 334
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 192,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 187,
        columnNumber: 332
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 187,
        columnNumber: 293
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 187,
      columnNumber: 275
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: edit !== void 0, title: edit ? "Cập nhật quyền" : "Mời nhân viên", onClose: () => setEdit(void 0), busy: invite.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !roles.length || !edit && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || invite.pending || update.pending, onClick: async () => {
      try {
        if (edit)
          await update.execute({ path: { memberId: edit.id }, version: edit.permissionVersion, body: { roles } });
        else
          await invite.execute({ body: { email, roles } });
        setEdit(void 0);
      } catch {
      }
    }, children: "Lưu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 193,
      columnNumber: 174
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: invite.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 200,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { gap: 1.5, children: [
        !edit && /* @__PURE__ */ jsxDEV(TextField, { label: "Email nhân viên", type: "email", value: email, onChange: (e) => setEmail(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 200,
          columnNumber: 124
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", children: "Phân vai trò" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 200,
          columnNumber: 232
        }, this),
        Object.keys(roleLabels).map((role) => /* @__PURE__ */ jsxDEV(FormControlLabel, { label: `${roleLabels[role]} · ${permissionCatalog.rolePresets[role]?.length || 0} quyền`, control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: roles.includes(role), onChange: (e) => setRoles(e.target.checked ? [...roles, role] : roles.filter((r) => r !== role)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 200,
          columnNumber: 468
        }, this) }, role, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 200,
          columnNumber: 340
        }, this)),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Quyền mới phải được máy chủ kiểm lại. Thu hồi quyền làm mất hiệu lực cache và phiên truy cập liên quan." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 200,
          columnNumber: 615
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 200,
        columnNumber: 97
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 193,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!remove, title: "Thu hồi quyền nhân viên", description: "Người này không được tiếp tục dùng dữ liệu của shop sau khi quyền được thu hồi.", onClose: () => setRemove(null), busy: revoke.pending, error: revoke.error, onConfirm: async () => {
      if (!remove) return;
      await revoke.execute({ path: { memberId: remove.id }, version: remove.permissionVersion });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 200,
      columnNumber: 773
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 187,
    columnNumber: 10
  }, this);
}
_s5(TeamPage, "xaapWgPxy7wzFwRm/wjt/e4j1BA=", false, function() {
  return [useScope, useApi, useListQuery, useCommand, useCommand, useCommand];
});
_c7 = TeamPage;
export function AuditPage() {
  _s6();
  const { shop } = useScope();
  const list = useApi("listAuditEvents", { query: useListQuery() });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhật ký hoạt động", subtitle: "Ai thực hiện, thao tác nào, dữ liệu nào và mã truy vết. Không lưu API key hoặc suy luận riêng của AI." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 205,
      columnNumber: 139
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { mb: 2 }, children: "API hiện trả về người thực hiện, thao tác, đối tượng, thời gian, mã truy vết và tóm tắt. Loại actor, phiên bản policy/config và snapshot chi tiết chưa có trong DTO nên không được suy đoán." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 205,
      columnNumber: 292
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 205,
        columnNumber: 533
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { rows: list.data.data, rowKey: (a) => a.id, columns: [
          { key: "time", label: "Thời gian", render: (a) => dateTime(a.occurredAt, shop.timezone) },
          { key: "actor", label: "Người thực hiện", render: (a) => a.actorId },
          { key: "action", label: "Thao tác", render: (a) => a.action },
          { key: "source", label: "Đối tượng", render: (a) => `${a.resource.type} · ${a.resource.id}` },
          { key: "summary", label: "Kết quả", render: (a) => a.summary },
          { key: "trace", label: "Mã truy vết", render: (a) => /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: a.requestId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 206,
            columnNumber: 447
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 205,
          columnNumber: 585
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 207,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 205,
        columnNumber: 583
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 205,
        columnNumber: 544
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 205,
      columnNumber: 526
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 205,
    columnNumber: 137
  }, this);
}
_s6(AuditPage, "Jtgiv7AS0Y0EHZdenzTKkK6QaXU=", false, function() {
  return [useScope, useApi, useListQuery];
});
_c8 = AuditPage;
export function PrivacyPage() {
  _s7();
  const policy = useApi("getPrivacyPolicy");
  const requests = useApi("listPrivacyRequests", { query: useListQuery() });
  const save = useCommand("updatePrivacyPolicy", ["getPrivacyPolicy"]);
  const create = useCommand("createPrivacyRequest", ["listPrivacyRequests"]);
  const [days, setDays] = useState(""), [note, setNote] = useState(""), [customerId, setCustomer] = useState(""), [kind, setKind] = useState("export"), [reason, setReason] = useState(""), [open, setOpen] = useState(false);
  const canReadCustomers = useCan("customers.read");
  const customers = useApi("listCustomers", { query: { limit: 100 } }, canReadCustomers);
  useEffect(() => {
    if (policy.data) {
      setDays(policy.data.data.chatRetentionDays?.toString() || "");
      setNote(policy.data.data.jurisdictionNote);
    }
  }, [policy.data]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Quyền riêng tư & vòng đời dữ liệu", subtitle: "Tách cấu hình nháp với chính sách được duyệt; yêu cầu xóa không tự vượt điều kiện lưu chứng từ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 220,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: { display: "grid", gridTemplateColumns: { xs: "1fr", lg: "1fr 1.4fr" }, gap: 3 }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Chính sách lưu trữ", children: /* @__PURE__ */ jsxDEV(QueryState, { query: policy, children: /* @__PURE__ */ jsxDEV(Stack, { gap: 2, sx: { p: 3 }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: save.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 220,
          columnNumber: 356
        }, this),
        policy.data && /* @__PURE__ */ jsxDEV(Status, { value: policy.data.data.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 220,
          columnNumber: 406
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Số ngày lưu hội thoại", value: days, onChange: (e) => setDays(e.target.value), type: "number", inputProps: { min: 1, max: 36500 } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 220,
          columnNumber: 449
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Căn cứ / thị trường áp dụng", multiline: true, minRows: 4, value: note, onChange: (e) => setNote(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 220,
          columnNumber: 597
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", variant: "contained", busy: save.pending, disabled: !policy.data || !days || Number(days) < 1 || note.trim().length < 5, onClick: () => {
          const current = policy.data?.data;
          if (!current) return;
          void save.execute({ version: current.version, body: { chatRetentionDays: Number(days), jurisdictionNote: note } }).catch(() => void 0);
        }, children: "Lưu bản nháp chính sách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 220,
          columnNumber: 723
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Không tự chứng nhận tuân thủ pháp luật. Phê duyệt yêu cầu xóa cần xác thực nâng cao của backend; luồng OIDC step-up chưa được xác minh trong frontend này." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 224,
          columnNumber: 56
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 220,
        columnNumber: 327
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 220,
        columnNumber: 300
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 220,
        columnNumber: 266
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Yêu cầu của khách", action: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", onClick: () => setOpen(true), children: "Tạo yêu cầu" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 224,
        columnNumber: 311
      }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: requests, children: requests.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { rows: requests.data.data, rowKey: (r) => r.id, columns: [
          { key: "customer", label: "Khách", render: (r) => r.customerId },
          { key: "kind", label: "Yêu cầu", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.kind }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 225,
            columnNumber: 127
          }, this) },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 225,
            columnNumber: 208
          }, this) },
          { key: "reason", label: "Lý do", render: (r) => r.reason }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 224,
          columnNumber: 464
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: requests.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 226,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 224,
        columnNumber: 462
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 224,
        columnNumber: 415
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 224,
        columnNumber: 270
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 220,
      columnNumber: 175
    }, this),
    /* @__PURE__ */ jsxDEV(ContactConsentPreview, { customers: customers.data?.data || [], canReadCustomers }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 226,
      columnNumber: 83
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Yêu cầu dữ liệu cá nhân", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !customerId || reason.trim().length < 5 || create.pending, onClick: async () => {
      try {
        await create.execute({ body: { kind, customerId, reason } });
        setOpen(false);
      } catch {
      }
    }, children: "Tạo yêu cầu chờ duyệt" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 227,
      columnNumber: 120
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 231,
        columnNumber: 63
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Khách hàng", select: true, value: customerId, onChange: (e) => setCustomer(e.target.value), children: customers.data?.data.map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: c.displayName }, c.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 231,
          columnNumber: 249
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 231,
          columnNumber: 114
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Loại yêu cầu", select: true, value: kind, onChange: (e) => setKind(e.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "export", children: "Xuất dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 231,
            columnNumber: 432
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "delete", children: "Xóa dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 231,
            columnNumber: 488
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 231,
          columnNumber: 323
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do / xác minh yêu cầu", multiline: true, minRows: 3, value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 231,
          columnNumber: 555
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 231,
        columnNumber: 99
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 227,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 220,
    columnNumber: 10
  }, this);
}
_s7(PrivacyPage, "DklJgP8ocMuy8PDSEiUvlE/AC/s=", false, function() {
  return [useApi, useApi, useListQuery, useCommand, useCommand, useCan, useApi];
});
_c9 = PrivacyPage;
function ContactConsentPreview({ customers, canReadCustomers }) {
  _s8();
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [optOutIds, setOptOutIds] = useState([]);
  const customerId = customers.some((customer2) => customer2.id === selectedCustomerId) ? selectedCustomerId : customers[0]?.id || "";
  const customer = customers.find((candidate) => candidate.id === customerId);
  const optedOut = optOutIds.includes(customerId);
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Xem thử consent marketing", sx: { mt: 3 }, children: /* @__PURE__ */ jsxDEV(Stack, { gap: 2, sx: { p: 3 }, children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Dữ liệu tổng hợp chỉ dùng để xem tương tác UI. Contract Customer chưa có trường consent và API chưa có thao tác opt-out; lựa chọn ở đây không gửi tới backend hoặc chặn chiến dịch thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 242,
      columnNumber: 13
    }, this),
    canReadCustomers ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khách mẫu", value: customerId, onChange: (event) => setSelectedCustomerId(event.target.value), disabled: !customer, children: customers.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.displayName }, item.id, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 245,
        columnNumber: 46
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 244,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Ngừng liên hệ marketing (chỉ bản xem trước)", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: optedOut, disabled: !customer, onChange: (event) => setOptOutIds((current) => event.target.checked ? [.../* @__PURE__ */ new Set([...current, customerId])] : current.filter((id) => id !== customerId)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 247,
        columnNumber: 96
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 247,
        columnNumber: 17
      }, this),
      customer && /* @__PURE__ */ jsxDEV(Box, { role: "status", "data-testid": "consent-preview-status", children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khách mẫu", children: customer.displayName }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 249,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dịch vụ", children: "Chưa có trường consent trong contract" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 250,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Marketing", children: optedOut ? "Opt-out mô phỏng; chưa ghi server" : "Chưa xác minh từ API" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 251,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", sx: { mt: 1 }, children: [
          "Số khách opt-out trong preview: ",
          optOutIds.length,
          ". Không khẳng định đã lọc job đang chờ hoặc dữ liệu khôi phục."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 252,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 248,
        columnNumber: 30
      }, this),
      !customer && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chưa có khách mẫu trong trang API hiện tại." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 254,
        columnNumber: 31
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 243,
      columnNumber: 33
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vai trò hiện tại không có customers.read; khách mẫu và lựa chọn consent được ẩn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 255,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 241,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 240,
    columnNumber: 10
  }, this);
}
_s8(ContactConsentPreview, "xJwIGT0LmzznOjaZ2KRgNs0e6bA=");
_c0 = ContactConsentPreview;
export function JobPage() {
  _s9();
  const { jobId = "" } = useParams();
  const { shop } = useScope();
  const get = useApi("getJob", { path: { jobId } });
  const job = get.data?.data;
  const downloadHref = job?.downloadUrl ? authorizedDownloadHref(job.downloadUrl, location.origin, __MOCK__) : null;
  const jobStatus = job?.status;
  const { refetch } = get;
  useEffect(() => {
    if (!jobStatus || !["queued", "running"].includes(jobStatus))
      return;
    const timer = setInterval(() => void refetch(), 3e3);
    return () => clearInterval(timer);
  }, [jobStatus, refetch]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: `Công việc ${jobId}`, subtitle: "Theo dõi tiến độ từ API. Được tiếp nhận không có nghĩa đã hoàn tất." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: get, children: job && /* @__PURE__ */ jsxDEV(Panel, { title: "Kết quả xử lý", children: /* @__PURE__ */ jsxDEV(Stack, { gap: 2, sx: { p: 3 }, children: [
      /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 224
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Loại", children: job.kind }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 253
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tiến độ", children: [
        job.completed,
        " / ",
        job.total ?? "Chưa biết"
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 301
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lỗi", children: job.errorCount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 386
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cập nhật", children: dateTime(job.updatedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 439
      }, this),
      job.rowErrors.length > 0 && /* @__PURE__ */ jsxDEV(DataTable, { rows: job.rowErrors, rowKey: (e) => `${e.row}-${e.field}-${e.code}`, columns: [{ key: "row", label: "Dòng", render: (e) => e.row }, { key: "field", label: "Trường", render: (e) => e.field }, { key: "message", label: "Lỗi", render: (e) => e.message }] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 550
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => void get.refetch(), variant: "outlined", children: "Kiểm tra lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 816
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && downloadHref && /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => window.open(downloadHref, "_blank", "noopener,noreferrer"), children: "Mở kết quả xuất" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 984
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && !downloadHref && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không an toàn hoặc không hợp lệ nên đã bị chặn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 1198
      }, this),
      job.status === "awaiting_confirmation" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/imports/${job.id}`, children: "Xem và xác nhận nhập" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 1331
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 195
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 166
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 134
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 269,
    columnNumber: 10
  }, this);
}
_s9(JobPage, "l5lsqPeM5OsNbf4sk4jY+IabZuk=", false, function() {
  return [useParams, useScope, useApi];
});
_c1 = JobPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1;
$RefreshReg$(_c, "AuthCard");
$RefreshReg$(_c2, "LoginPage");
$RefreshReg$(_c3, "WorkspacesPage");
$RefreshReg$(_c4, "OnboardingPage");
$RefreshReg$(_c5, "ShopSettingsPage");
$RefreshReg$(_c6, "SetupChecklistItem");
$RefreshReg$(_c7, "TeamPage");
$RefreshReg$(_c8, "AuditPage");
$RefreshReg$(_c9, "PrivacyPage");
$RefreshReg$(_c0, "ContactConsentPreview");
$RefreshReg$(_c1, "JobPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzYSxTQWlHM1osVUFqRzJaOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCdGEsU0FBU0EsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBRTVDLFNBQVNDLFFBQVFDLFlBQVlDLFVBQVVDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUN0RixTQUFTQyxVQUFVQyxzQkFBc0I7QUFDekMsU0FBU0MsT0FBT0MsUUFBUUMsS0FBS0MsUUFBUUMsVUFBVUMsa0JBQWtCQyxVQUFVQyxPQUFPQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFDdEgsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHlCQUF5QjtBQUVoQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxTQUFTQyxvQkFBb0I7QUFDdEMsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDakMsU0FBU0MsVUFBVUMsd0JBQXdCO0FBQzNDLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCQyxxQkFBcUI7QUFDOUMsU0FBU0MsWUFBWUMsT0FBT0MsWUFBWUMsV0FBV0MsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxZQUFZQyxhQUFhQyxlQUFlQyxXQUFXQyxrQkFBa0I7QUFDaEssU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFNBQVM7QUFBQSxFQUFFQztBQUVwQixHQUFHO0FBQUUsU0FBTyx1QkFBQyxPQUFJLFdBQVUsUUFBTyxJQUFHLGdCQUFlLFVBQVUsSUFBSSxJQUFJLEVBQUVDLFdBQVcsU0FBU0MsU0FBUyxRQUFRQyxZQUFZLFVBQVVDLEdBQUcsR0FBR0MsU0FBUyxzQkFBc0JDLFNBQVMsT0FBTyxHQUFHLGlDQUFDLFNBQU0sU0FBUSxZQUFXLElBQUksRUFBRUMsT0FBTyxRQUFRQyxVQUFVLEtBQUtKLEdBQUcsRUFBRUssSUFBSSxHQUFHQyxJQUFJLEVBQUUsR0FBR0MsY0FBYyxFQUFFLEdBQUc7QUFBQSwyQkFBQyxTQUFNLFdBQVUsT0FBTSxZQUFXLFVBQVMsS0FBSyxLQUFLLElBQUksRUFBRUMsSUFBSSxFQUFFLEdBQUc7QUFBQSw2QkFBQyxVQUFPLElBQUksRUFBRVAsU0FBUyxnQkFBZ0JRLE9BQU8xQyxPQUFPMkMsU0FBUyxHQUFHLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLE1BQVMsdUJBQUMsY0FBVyxTQUFRLE1BQUssWUFBWSxLQUFLO0FBQUE7QUFBQSxRQUFTLHVCQUFDLE9BQUksV0FBVSxRQUFPLE9BQU0sZ0JBQWUsa0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNHO0FBQUEsU0FBdlE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvUjtBQUFBLElBQVNkO0FBQUFBLE9BQW5ZO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNFksS0FBM2pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbWtCO0FBQVE7QUFBQ2UsS0FGL2tCaEI7QUFHRixnQkFBU2lCLFlBQVk7QUFBQUMsS0FBQTtBQUN4QixRQUFNLEVBQUVDLFNBQVNDLFFBQVEsSUFBSXJCLFdBQVc7QUFDeEMsUUFBTSxDQUFDc0IsTUFBTSxJQUFJbEUsZ0JBQWdCO0FBQ2pDLFFBQU0sQ0FBQ21FLFNBQVNDLFVBQVUsSUFBSTFFLFNBQVMsS0FBSyxHQUFHLENBQUMyRSxPQUFPQyxRQUFRLElBQUk1RSxTQUF1QixJQUFJO0FBQzlGLFFBQU02RSxRQUFRLFlBQVk7QUFBRUgsZUFBVyxJQUFJO0FBQUdFLGFBQVMsSUFBSTtBQUFHLFFBQUk7QUFDOUQsWUFBTUUsT0FBTyxNQUFNdEQsUUFBUSxjQUFjO0FBQ3pDQyxtQkFBYXFELEtBQUtDLEtBQUtDLFNBQVM7QUFDaEMsWUFBTUMsT0FBTyxNQUFNekQsUUFBUSxjQUFjLEVBQUUwRCxNQUFNLEVBQUVDLFVBQVVuRCxpQkFBaUJ3QyxPQUFPWSxJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxDQUFDO0FBQzFILFlBQU1DLE1BQU0sSUFBSUMsSUFBSUwsS0FBS0YsS0FBS1EsZ0JBQWdCO0FBQzlDLFVBQUlGLElBQUlHLGFBQWEsWUFBWSxFQUFFQyxZQUFZSixJQUFJSyxXQUFXQyxTQUFTRDtBQUNuRSxjQUFNLElBQUlFLE1BQU0sa0NBQWtDO0FBQ3REQyxhQUFPRixTQUFTRyxPQUFPVCxJQUFJVSxJQUFJO0FBQUEsSUFDbkMsU0FDT0MsR0FBRztBQUNOcEIsZUFBU29CLGFBQWFKLFFBQVFJLElBQUksSUFBSUosTUFBTSw4QkFBOEIsQ0FBQztBQUMzRWxCLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQUU7QUFDRixTQUFPLHVCQUFDLFlBQVM7QUFBQSwyQkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssSUFBSSxFQUFFVixJQUFJLEVBQUUsR0FBRyxpQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBQWEsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixJQUFJLEVBQUVBLElBQUksRUFBRSxHQUFHLGdGQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtIO0FBQUEsSUFBYSx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUd5QixZQUFZLHVCQUFDLFNBQU0sVUFBUyxRQUFPLElBQUksRUFBRXpCLElBQUksRUFBRSxHQUFHLCtFQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFHO0FBQUEsSUFBVU0sVUFBVSx1QkFBQyxVQUFPLFdBQVMsTUFBQyxXQUFXcEUsWUFBWSxJQUFHLGVBQWMsU0FBUSxhQUFZLFNBQVMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixHQUFLLHFDQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFJLElBQVksdUJBQUMsVUFBTyxXQUFTLE1BQUMsU0FBUSxhQUFZLE1BQUssU0FBUSxTQUFTLE1BQU0sS0FBSzJFLE1BQU0sR0FBRyxVQUFVSixXQUFXRixTQUFVRSxvQkFBVSwrQkFBK0JnQixXQUFXLDJCQUEyQixzQ0FBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpTztBQUFBLElBQVUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsSUFBSSxFQUFFbkMsU0FBUyxTQUFTMkMsSUFBSSxFQUFFLEdBQUcsa0dBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0s7QUFBQSxPQUFwNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpN0I7QUFDNTdCO0FBQUM1QixHQWxCZUQsV0FBUztBQUFBLFVBQ1FsQixZQUNaNUMsZUFBZTtBQUFBO0FBQUEsTUFGcEI4RDtBQW1CVCxnQkFBUzhCLGlCQUFpQjtBQUFBQyxNQUFBO0FBQzdCLFFBQU0sRUFBRTdCLFNBQVNDLFNBQVNJLE9BQU95QixhQUFhLElBQUlsRCxXQUFXO0FBQzdELFFBQU1tRCxRQUFROUYsU0FBUyxFQUFFK0YsVUFBVSxDQUFDLFNBQVNoQyxTQUFTaUMsS0FBS0MsRUFBRSxHQUFHQyxTQUFTQSxDQUFDLEVBQUVDLE9BQU8sTUFBTWxGLFFBQVEsYUFBYSxFQUFFa0YsT0FBTyxDQUFDLEdBQUdDLFNBQVMsQ0FBQyxDQUFDckMsU0FBU3NDLE9BQU8sTUFBTSxDQUFDO0FBQzdKLE1BQUksQ0FBQ3JDLFdBQVcsQ0FBQ0QsV0FBVzhCLHdCQUF3QnhFLFlBQVl3RSxhQUFhUyxXQUFXO0FBQ3BGLFdBQU8sdUJBQUMsWUFBUyxJQUFHLFVBQVMsU0FBTyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQ3hDLFNBQU8sdUJBQUMsT0FBSSxXQUFVLFFBQU8sSUFBRyxnQkFBZSxVQUFVLElBQUksSUFBSSxFQUFFakQsVUFBVSxNQUFNa0QsSUFBSSxRQUFRdEQsR0FBRyxFQUFFSyxJQUFJLEdBQUdrRCxJQUFJLEVBQUUsR0FBR3JELFNBQVMsT0FBTyxHQUFHO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLHNEQUFxRCxTQUFTLHVCQUFDLFVBQU8sV0FBV3hELFlBQVksSUFBRyxlQUFjLFNBQVEsYUFBWSw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRixLQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1NO0FBQUEsSUFBRSx1QkFBQyxlQUFZLE9BQU9rRyxnQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPQyxPQUFPLGlDQUFDLE9BQUksSUFBSSxFQUFFL0MsU0FBUyxRQUFRMEQscUJBQXFCLEVBQUVuRCxJQUFJLE9BQU9rRCxJQUFJLGdCQUFnQixHQUFHRSxLQUFLLEVBQUUsR0FBSVosZ0JBQU10QixNQUFNQSxLQUFLbUMsSUFBSSxDQUFBQyxNQUFLLHVCQUFDLFNBQU0sU0FBUSxZQUFzQixJQUFJLEVBQUUzRCxHQUFHLEdBQUdPLGNBQWMsRUFBRSxHQUFHO0FBQUEsNkJBQUMsVUFBTyxJQUFJLEVBQUVDLElBQUksR0FBR1AsU0FBU2xDLE9BQU82RixVQUFVbkQsT0FBTyxlQUFlLEdBQUlrRCxZQUFFRSxLQUFLLENBQUMsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQVMsdUJBQUMsY0FBVyxTQUFRLE1BQU1GLFlBQUVFLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSSxFQUFFQyxJQUFJLElBQUksR0FBSUg7QUFBQUEsVUFBRUk7QUFBQUEsUUFBUztBQUFBLFFBQUlKLEVBQUVLO0FBQUFBLFdBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0U7QUFBQSxNQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCO0FBQUE7QUFBQSxRQUFRbEQsU0FBU21ELFlBQVlDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV1QsRUFBRVgsRUFBRSxHQUFHcUIsTUFBTUMsS0FBSyxJQUFJLEtBQUs7QUFBQSxXQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9KO0FBQUEsTUFBYSx1QkFBQyxVQUFPLFdBQVc1SCxZQUFZLElBQUksTUFBTWlILEVBQUVYLEVBQUUsYUFBYSxXQUFTLE1BQUMsU0FBUSxZQUFXLFNBQVMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixHQUFLLElBQUksRUFBRVAsSUFBSSxFQUFFLEdBQUcsMkJBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUo7QUFBQSxTQUEvakJrQixFQUFFWCxJQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVtQixDQUFRLEtBQXp1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJ1QixLQUFyd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyd0I7QUFBQSxPQUFubkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnb0M7QUFDM29DO0FBQUNMLElBTmVELGdCQUFjO0FBQUEsVUFDd0JoRCxZQUNwQzNDLFFBQVE7QUFBQTtBQUFBLE1BRlYyRjtBQU9ULGdCQUFTNkIsaUJBQWlCO0FBQUFDLE1BQUE7QUFDN0IsUUFBTUMsV0FBVzdILFlBQVk7QUFDN0IsUUFBTSxFQUFFOEgsUUFBUSxJQUFJaEYsV0FBVztBQUMvQixRQUFNaUYsUUFBUTNILGVBQWU7QUFDN0IsUUFBTSxDQUFDNkcsTUFBTWUsT0FBTyxJQUFJcEksU0FBUyxFQUFFLEdBQUcsQ0FBQ3VILFVBQVVjLFdBQVcsSUFBSXJJLFNBQVMsS0FBSyxHQUFHLENBQUN3SCxVQUFVYyxXQUFXLElBQUl0SSxTQUFTLGdCQUFnQixHQUFHLENBQUN5RSxTQUFTQyxVQUFVLElBQUkxRSxTQUFTLEtBQUssR0FBRyxDQUFDMkUsT0FBT0MsUUFBUSxJQUFJNUUsU0FBdUIsSUFBSTtBQUMvTixRQUFNdUksT0FBTyxZQUFZO0FBQUU3RCxlQUFXLElBQUk7QUFBR0UsYUFBUyxJQUFJO0FBQUcsUUFBSTtBQUM3RCxVQUFJNEQsS0FBS0MsZUFBZSxNQUFNLEVBQUVDLFVBQVVsQixTQUFTLENBQUM7QUFDcEQsWUFBTW1CLElBQUksTUFBTW5ILFFBQVEsY0FBYyxFQUFFMEQsTUFBTSxFQUFFbUMsTUFBTUUsVUFBVUMsVUFBVW9CLFFBQVEsUUFBUSxFQUFFLENBQUM7QUFDN0YsWUFBTVYsUUFBUTtBQUNkLFlBQU1DLE1BQU1VLGtCQUFrQixFQUFFdkMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ3JEMkIsZUFBUyxNQUFNVSxFQUFFNUQsS0FBS3lCLEVBQUUsV0FBVztBQUFBLElBQ3ZDLFNBQ09SLEdBQUc7QUFDTnBCLGVBQVNvQixhQUFhSixRQUFRSSxJQUFJLElBQUlKLE1BQU0seUJBQXlCLENBQUM7QUFBQSxJQUMxRSxVQUFDO0FBRUdsQixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUFFO0FBQ0YsU0FBTyx1QkFBQyxZQUFTO0FBQUEsMkJBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxNQUFLLElBQUksRUFBRVYsSUFBSSxFQUFFLEdBQUcsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUFhLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSSxFQUFFQSxJQUFJLEVBQUUsR0FBRyxnRUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRztBQUFBLElBQWEsdUJBQUMsZUFBWSxTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxJQUFFLHVCQUFDLFNBQU0sS0FBSyxLQUFLO0FBQUEsNkJBQUMsYUFBVSxPQUFNLGdCQUFlLE9BQU9xRCxNQUFNLFVBQVUsQ0FBQXJCLE1BQUtvQyxRQUFRcEMsRUFBRThDLE9BQU9DLEtBQUssR0FBRyxZQUFZLEVBQUVDLFdBQVcsSUFBSSxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9IO0FBQUEsTUFBRSx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLFFBQU0sTUFBQyxPQUFPekIsVUFBVSxVQUFVLENBQUF2QixNQUFLcUMsWUFBWXJDLEVBQUU4QyxPQUFPQyxLQUFLLEdBQUksV0FBQyxPQUFPLE9BQU8sT0FBTyxLQUFLLEVBQUU3QixJQUFJLENBQUErQixNQUFLLHVCQUFDLFlBQWlCLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixDQUFXLEtBQXRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0w7QUFBQSxNQUFZLHVCQUFDLGFBQVUsT0FBTSxXQUFVLE9BQU96QixVQUFVLFVBQVUsQ0FBQXhCLE1BQUtzQyxZQUFZdEMsRUFBRThDLE9BQU9DLEtBQUssS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLE1BQUUsdUJBQUMsU0FBTSxVQUFTLFFBQU8sMkhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0k7QUFBQSxNQUFRLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQzFCLEtBQUs2QixLQUFLLEtBQUssQ0FBQzFCLFlBQVkvQyxTQUFTLFNBQVMsTUFBTSxLQUFLOEQsS0FBSyxHQUFHLDRCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9IO0FBQUEsTUFBUyx1QkFBQyxVQUFPLFdBQVdySSxZQUFZLElBQUcsZUFBYyx3QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLFNBQW51QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTR1QjtBQUFBLE9BQWo5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXk5QjtBQUNwK0I7QUFBQzhILElBbkJlRCxnQkFBYztBQUFBLFVBQ1QzSCxhQUNHOEMsWUFDTjFDLGNBQWM7QUFBQTtBQUFBLE1BSGhCdUg7QUFvQlQsZ0JBQVNvQixtQkFBbUI7QUFBQUMsTUFBQTtBQUMvQixRQUFNQyxRQUFRdkgsU0FBUztBQUN2QixRQUFNLEVBQUV3SCxLQUFLLElBQUlEO0FBQ2pCLFFBQU1sQixRQUFRM0gsZUFBZTtBQUM3QixRQUFNK0ksZ0JBQWdCMUgsT0FBTyxhQUFhO0FBQzFDLFFBQU0ySCxTQUFTN0gsV0FBVyxjQUFjLENBQUMsU0FBUyxDQUFDO0FBQ25ELFFBQU0sQ0FBQzBGLE1BQU1lLE9BQU8sSUFBSXBJLFNBQVNzSixLQUFLakMsSUFBSSxHQUFHLENBQUNHLFVBQVVjLFdBQVcsSUFBSXRJLFNBQVNzSixLQUFLOUIsUUFBUSxHQUFHLENBQUNvQixRQUFRYSxTQUFTLElBQUl6SixTQUFTc0osS0FBS1YsTUFBTSxHQUFHLENBQUNqRSxPQUFPQyxRQUFRLElBQUk1RSxTQUF1QixJQUFJLEdBQUcsQ0FBQzBKLE9BQU9DLFFBQVEsSUFBSTNKLFNBQVMsS0FBSztBQUNqTyxRQUFNNEosVUFBVTdKLE9BQXdCLElBQUk7QUFDNUMsUUFBTThKLFdBQVc5SixPQUFPLEVBQUU2SCxRQUFRMEIsS0FBSzlDLElBQUlhLE1BQU1pQyxLQUFLakMsTUFBTUcsVUFBVThCLEtBQUs5QixVQUFVb0IsUUFBUVUsS0FBS1YsT0FBTyxDQUFDO0FBQzFHLFFBQU1rQixRQUFRL0osT0FBTzhKLFNBQVNFLE9BQU87QUFDckNqSyxZQUFVLE1BQU07QUFDWixRQUFJK0osU0FBU0UsUUFBUW5DLFdBQVcwQixLQUFLOUM7QUFDakM7QUFDSixVQUFNd0QsT0FBTyxFQUFFcEMsUUFBUTBCLEtBQUs5QyxJQUFJYSxNQUFNaUMsS0FBS2pDLE1BQU1HLFVBQVU4QixLQUFLOUIsVUFBVW9CLFFBQVFVLEtBQUtWLE9BQU87QUFDOUZpQixhQUFTRSxVQUFVQztBQUNuQkYsVUFBTUMsVUFBVUM7QUFDaEI1QixZQUFRNEIsS0FBSzNDLElBQUk7QUFDakJpQixnQkFBWTBCLEtBQUt4QyxRQUFRO0FBQ3pCaUMsY0FBVU8sS0FBS3BCLE1BQU07QUFDckJoRSxhQUFTLElBQUk7QUFDYitFLGFBQVMsS0FBSztBQUNkLFFBQUlDLFFBQVFHO0FBQ1I1SCxxQkFBZXlILFFBQVFHLE9BQU87QUFBQSxFQUN0QyxHQUFHLENBQUNULEtBQUs5QyxJQUFJOEMsS0FBS1YsUUFBUVUsS0FBS2pDLE1BQU1pQyxLQUFLOUIsUUFBUSxDQUFDO0FBQ25ELFFBQU15QyxjQUFjQSxDQUFDQyxPQUF1Q25CLFVBQWtCO0FBQzFFLFVBQU1pQixPQUFPLEVBQUUsR0FBR0YsTUFBTUMsU0FBUyxDQUFDRyxLQUFLLEdBQUduQixNQUFNO0FBQ2hEZSxVQUFNQyxVQUFVQztBQUNoQjVILGtCQUFjd0gsUUFBUUcsU0FBU0MsS0FBS3BDLFdBQVdpQyxTQUFTRSxRQUFRbkMsVUFBVW9DLEtBQUszQyxTQUFTd0MsU0FBU0UsUUFBUTFDLFFBQVEyQyxLQUFLeEMsYUFBYXFDLFNBQVNFLFFBQVF2QyxZQUFZd0MsS0FBS3BCLFdBQVdpQixTQUFTRSxRQUFRbkIsTUFBTTtBQUN2TWUsYUFBUyxLQUFLO0FBQUEsRUFDbEI7QUFDQSxRQUFNcEIsT0FBTyxPQUFPNEIsU0FBMEI7QUFDMUN2RixhQUFTLElBQUk7QUFDYitFLGFBQVMsS0FBSztBQUNkLFFBQUk7QUFDQSxVQUFJbkIsS0FBS0MsZUFBZUcsUUFBUSxFQUFFRixVQUFVbEIsU0FBUyxDQUFDO0FBQ3RELFlBQU00QyxTQUFTLE1BQU1aLE9BQU9hLFFBQVEsRUFBRUMsTUFBTSxFQUFFMUMsUUFBUTBCLEtBQUs5QyxHQUFHLEdBQUcrRCxTQUFTakIsS0FBS2lCLFNBQVNyRixNQUFNLEVBQUVtQyxNQUFNRyxVQUFVb0IsT0FBTyxFQUFFLENBQUM7QUFDMUhULFlBQU1xQyxhQUFhLENBQUMsUUFBUW5CLE1BQU0vRSxRQUFRaUMsS0FBS0MsSUFBSThDLEtBQUs5QyxJQUFJNkMsTUFBTW9CLFdBQVdDLGlCQUFpQixHQUFHTixNQUFNO0FBQ3ZHLFlBQU1PLFlBQVksRUFBRS9DLFFBQVF3QyxPQUFPckYsS0FBS3lCLElBQUlhLE1BQU0rQyxPQUFPckYsS0FBS3NDLE1BQU1HLFVBQVU0QyxPQUFPckYsS0FBS3lDLFVBQVVvQixRQUFRd0IsT0FBT3JGLEtBQUs2RCxPQUFPO0FBQy9IaUIsZUFBU0UsVUFBVVk7QUFDbkJiLFlBQU1DLFVBQVVZO0FBQ2hCdkMsY0FBUXVDLFVBQVV0RCxJQUFJO0FBQ3RCaUIsa0JBQVlxQyxVQUFVbkQsUUFBUTtBQUM5QmlDLGdCQUFVa0IsVUFBVS9CLE1BQU07QUFDMUJ6RyxxQkFBZWdJLElBQUk7QUFDbkJSLGVBQVMsSUFBSTtBQUFBLElBQ2pCLFNBQ08zRCxHQUFHO0FBQ05wQixlQUFTb0IsYUFBYUosUUFBUUksSUFBSSxJQUFJSixNQUFNLHlCQUF5QixDQUFDO0FBQUEsSUFDMUU7QUFBQSxFQUNKO0FBQ0EsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxzQkFBcUIsVUFBUyxvRkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSTtBQUFBLElBQ2hJLHVCQUFDLFNBQU0sS0FBSyxHQUNSO0FBQUEsNkJBQUMsU0FBTSxPQUFNLG1CQUNULGlDQUFDLFNBQU0sV0FBVSxRQUFPLEtBQUtnRSxTQUFTLFlBQVUsTUFBQyxVQUFVLENBQUFnQixVQUFTO0FBQUVBLGNBQU1DLGVBQWU7QUFBRyxhQUFLdEMsS0FBS3FDLE1BQU1FLGFBQWE7QUFBQSxNQUFHLEdBQUcsS0FBSyxLQUFLLElBQUksRUFBRXRILEdBQUcsR0FBR0ksVUFBVSxJQUFJLEdBQ2pLO0FBQUEsK0JBQUMsZUFBWSxPQUFPZSxTQUFTNkUsT0FBTzdFLFNBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUN6QytFLFNBQVMsdUJBQUMsU0FBTSxVQUFTLFdBQVUsTUFBSyxVQUFTLHlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDM0UsdUJBQUMsYUFBVSxPQUFNLGdCQUFlLE9BQU9yQyxNQUFNLFVBQVUsQ0FBQ2tDLGVBQWUsVUFBVSxDQUFBcUIsVUFBUztBQUFFeEMsa0JBQVF3QyxNQUFNOUIsT0FBT0MsS0FBSztBQUFHa0Isc0JBQVksUUFBUVcsTUFBTTlCLE9BQU9DLEtBQUs7QUFBQSxRQUFHLEtBQWxLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0s7QUFBQSxRQUNwSyx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLE9BQU9PLEtBQUsvQixVQUFVLFVBQVEsTUFBQyxZQUFXLDRFQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1KO0FBQUEsUUFDbkosdUJBQUMsYUFBVSxPQUFNLFdBQVUsT0FBT0MsVUFBVSxVQUFVLENBQUMrQixlQUFlLFVBQVUsQ0FBQXFCLFVBQVM7QUFBRXRDLHNCQUFZc0MsTUFBTTlCLE9BQU9DLEtBQUs7QUFBR2tCLHNCQUFZLFlBQVlXLE1BQU05QixPQUFPQyxLQUFLO0FBQUEsUUFBRyxLQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJLO0FBQUEsUUFDM0ssdUJBQUMsYUFBVSxPQUFNLFlBQVcsT0FBT0gsUUFBUSxVQUFVLENBQUNXLGVBQWUsVUFBVSxDQUFBcUIsVUFBUztBQUFFbkIsb0JBQVVtQixNQUFNOUIsT0FBT0MsS0FBSztBQUFHa0Isc0JBQVksVUFBVVcsTUFBTTlCLE9BQU9DLEtBQUs7QUFBQSxRQUFHLEtBQXBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0s7QUFBQSxRQUN0Syx1QkFBQyxhQUFVLE9BQU0sYUFBWSxPQUFNLDZCQUE0QixVQUFRLFFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUN2RSx1QkFBQyxrQkFBZSxZQUFXLGVBQWMsTUFBSyxVQUFTLFNBQVEsYUFBWSxNQUFNUyxPQUFPL0UsU0FBUyxVQUFVLENBQUM0QyxLQUFLNkIsS0FBSyxLQUFLLENBQUMxQixVQUFVLDRCQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtKO0FBQUEsV0FSdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sZ0NBQStCLFVBQVMsZ0dBQ2pELGlDQUFDLFNBQU0sS0FBSyxHQUFHLElBQUksRUFBRWhFLEdBQUcsRUFBRSxHQUN0QjtBQUFBLCtCQUFDLFNBQU0sVUFBUyxRQUFRaUM7QUFBQUEscUJBQVcsNkZBQTZGO0FBQUEsVUFBeUQ7QUFBQSxhQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJPO0FBQUEsUUFDM08sdUJBQUMsc0JBQW1CLE9BQU0sOEJBQTZCLFFBQU8sNENBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0c7QUFBQSxRQUN0Ryx1QkFBQyxzQkFBbUIsT0FBTSx3Q0FBdUMsUUFBUUEsV0FBVywyQ0FBMkMsd0NBQXdDLElBQUksTUFBTTZELEtBQUs5QyxFQUFFLGNBQWMsUUFBTywwQkFBN007QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTztBQUFBLFFBQ25PLHVCQUFDLHNCQUFtQixPQUFNLDZCQUE0QixRQUFPLDZEQUE0RCxJQUFJLE1BQU04QyxLQUFLOUMsRUFBRSxrQkFBa0IsUUFBTyx3QkFBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TDtBQUFBLFFBQ3ZMLHVCQUFDLHNCQUFtQixPQUFNLHlCQUF3QixRQUFRZixXQUFXLG1EQUFtRCwrQkFBK0IsSUFBSSxNQUFNNkQsS0FBSzlDLEVBQUUsMEJBQTBCLFFBQU8sZ0JBQXpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcU47QUFBQSxRQUNyTix1QkFBQyxzQkFBbUIsT0FBTSxjQUFhLFFBQVFmLFdBQVcsa0NBQWtDLGlDQUFpQyxJQUFJLE1BQU02RCxLQUFLOUMsRUFBRSxvQkFBb0IsUUFBTyx3QkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TDtBQUFBLFFBQzdMLHVCQUFDLHNCQUFtQixPQUFNLDRDQUEyQyxRQUFPLDJFQUEwRSxJQUFJLE1BQU04QyxLQUFLOUMsRUFBRSxjQUFjLFFBQU8sc0JBQTVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOE07QUFBQSxRQUM5TSx1QkFBQyxzQkFBbUIsT0FBTSx1QkFBc0IsUUFBTywwREFBeUQsSUFBSSxNQUFNOEMsS0FBSzlDLEVBQUUsdUJBQXVCLFFBQU8saUJBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEs7QUFBQSxRQUM1Syx1QkFBQyxzQkFBbUIsT0FBTSxzQ0FBcUMsUUFBTyxnRkFBK0UsSUFBSSxNQUFNOEMsS0FBSzlDLEVBQUUscUJBQXFCLFFBQU8scUJBQWxNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbU47QUFBQSxXQVR2TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsT0E1Qkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCUDtBQUNKO0FBQUM0QyxJQWhGZUQsa0JBQWdCO0FBQUEsVUFDZHJILFVBRUF0QixnQkFDUXFCLFFBQ1BGLFVBQVU7QUFBQTtBQUFBLE1BTGJ3SDtBQWlGaEIsU0FBUzRCLG1CQUFtQixFQUFFQyxPQUFPbkUsUUFBUW9FLElBQUlDLE9BQXdFLEdBQUc7QUFDeEgsU0FBTyx1QkFBQyxPQUFJLElBQUksRUFBRTVILFNBQVMsUUFBUTZILFlBQVksRUFBRXRILElBQUksY0FBY2tELElBQUksU0FBUyxHQUFHcUUsZ0JBQWdCLGlCQUFpQm5FLEtBQUssR0FBR3pELEdBQUcsS0FBSzZILFFBQVEsR0FBR0MsYUFBYSxXQUFXdkgsY0FBYyxHQUFHd0gsVUFBVSxPQUFPLEdBQ3JNO0FBQUEsMkJBQUMsT0FBSTtBQUFBLDZCQUFDLGNBQVcsWUFBWSxLQUFNUCxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQWEsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBa0JuRSxvQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLFNBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEg7QUFBQSxJQUM3SG9FLE1BQU1DLFVBQVUsdUJBQUMsYUFBVSxJQUFTQSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHUDtBQUNKO0FBQUNNLE1BTFFUO0FBTVQsTUFBTVUsYUFBbUM7QUFBQSxFQUNyQ0MsT0FBTztBQUFBLEVBQWdCQyxTQUFTO0FBQUEsRUFBV0MsT0FBTztBQUFBLEVBQVlDLFdBQVc7QUFBQSxFQUFpQkMsWUFBWTtBQUFBLEVBQVdDLFdBQVc7QUFBQSxFQUFlQyxRQUFRO0FBQ3ZKO0FBQ08sZ0JBQVNDLFdBQVc7QUFBQUMsTUFBQTtBQUN2QixRQUFNLEVBQUU1SCxRQUFRLElBQUl4QyxTQUFTO0FBQzdCLFFBQU1xSyxPQUFPekssT0FBTyxlQUFlLEVBQUUwSyxPQUFPbEssYUFBYSxFQUFFLENBQUM7QUFDNUQsUUFBTW1LLFNBQVMxSyxXQUFXLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztBQUN6RCxRQUFNNkgsU0FBUzdILFdBQVcscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQzlELFFBQU0ySyxTQUFTM0ssV0FBVyxvQkFBb0IsQ0FBQyxhQUFhLENBQUM7QUFDN0QsUUFBTSxDQUFDNEssTUFBTUMsT0FBTyxJQUFJeE0sU0FBd0MsR0FBRyxDQUFDeU0sT0FBT0MsUUFBUSxJQUFJMU0sU0FBUyxFQUFFLEdBQUcsQ0FBQzZILE9BQU84RSxRQUFRLElBQUkzTSxTQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM0TSxRQUFRQyxTQUFTLElBQUk3TSxTQUE0QixJQUFJO0FBQzdNLFFBQU04TSxPQUFPQSxDQUFDbkYsTUFBeUI7QUFBRTZFLFlBQVE3RSxDQUFDO0FBQUcrRSxhQUFTLEVBQUU7QUFBR0MsYUFBU2hGLEdBQUdFLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFBQSxFQUFHO0FBQ3JHLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sd0JBQXVCLFVBQVMsZ0ZBQStFLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxrQkFBaUIsU0FBUSxhQUFZLFNBQVMsTUFBTWlGLEtBQUssSUFBSSxHQUFHLDZCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdHLEtBQWxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb1E7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPWCxNQUFPQSxlQUFLcEgsUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsTUFBTW9ILEtBQUtwSCxLQUFLQSxNQUFNLFFBQVEsQ0FBQTRDLE1BQUtBLEVBQUVuQixJQUFJLFNBQVM7QUFBQSxVQUNuWSxFQUFFdUcsS0FBSyxRQUFRQyxPQUFPLGFBQWFDLFFBQVFBLENBQUF0RixNQUFLQSxFQUFFdUYsV0FBVzVJLFFBQVFpQyxLQUFLQyxLQUFLbEMsUUFBUWlDLEtBQUs0RyxjQUFjeEYsRUFBRXVGLE9BQU87QUFBQSxVQUFHLEVBQUVILEtBQUssU0FBU0MsT0FBTyxXQUFXQyxRQUFRQSxDQUFBdEYsTUFBS0EsRUFBRUUsTUFBTVgsSUFBSSxDQUFBeUIsTUFBSzhDLFdBQVc5QyxDQUFDLENBQUMsRUFBRWIsS0FBSyxJQUFJLEVBQUU7QUFBQSxVQUFHLEVBQUVpRixLQUFLLFVBQVVDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQXRGLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFZCxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QixFQUFHO0FBQUEsVUFBRyxFQUFFa0csS0FBSyxTQUFTQyxPQUFPLGtCQUFrQkMsUUFBUUEsQ0FBQXRGLE1BQUssR0FBR0EsRUFBRXlGLFlBQVlDLE1BQU0sYUFBYTFGLEVBQUUrQyxpQkFBaUIsR0FBRztBQUFBLFVBQ3BaO0FBQUEsWUFDSXFDLEtBQUs7QUFBQSxZQUFXQyxPQUFPO0FBQUEsWUFBSUMsUUFBUUEsQ0FBQXRGLE1BQUssdUJBQUMsU0FBTSxXQUFVLE9BQU07QUFBQSxxQ0FBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFTLE1BQU1tRixLQUFLbkYsQ0FBQyxHQUFHLHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQWlCLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLE9BQU0sU0FBUSxVQUFVQSxFQUFFdUYsV0FBVzVJLFFBQVFpQyxLQUFLQyxNQUFNbUIsRUFBRWQsV0FBVyxXQUFXLFNBQVMsTUFBTWdHLFVBQVVsRixDQUFDLEdBQUcsdUJBQXpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdLO0FBQUEsaUJBQXJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNTO0FBQUEsVUFDbFY7QUFBQSxRQUFDLEtBSnFVO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLeFU7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTXdFLEtBQUtwSCxLQUFLdUksUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBTHdTO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLdFMsS0FMK1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUszUDtBQUFBLFNBTHlPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLNU47QUFBQSxJQUN0RCx1QkFBQyxjQUFXLE1BQU1mLFNBQVNnQixRQUFXLE9BQU9oQixPQUFPLG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNQyxRQUFRZSxNQUFTLEdBQUcsTUFBTWxCLE9BQU81SCxXQUFXK0UsT0FBTy9FLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNvRCxNQUFNd0YsVUFBVyxDQUFDZCxRQUFRLENBQUMsNkJBQTZCaUIsS0FBS2YsS0FBSyxLQUFNSixPQUFPNUgsV0FBVytFLE9BQU8vRSxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDalYsWUFBSThIO0FBQ0EsZ0JBQU0vQyxPQUFPYSxRQUFRLEVBQUVDLE1BQU0sRUFBRW1ELFVBQVVsQixLQUFLL0YsR0FBRyxHQUFHK0QsU0FBU2dDLEtBQUs3QixtQkFBbUJ4RixNQUFNLEVBQUUyQyxNQUFNLEVBQUUsQ0FBQztBQUFBO0FBRXRHLGdCQUFNd0UsT0FBT2hDLFFBQVEsRUFBRW5GLE1BQU0sRUFBRXVILE9BQU81RSxNQUFNLEVBQUUsQ0FBQztBQUNuRDJFLGdCQUFRZSxNQUFTO0FBQUEsTUFDckIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUFnQixHQUFHLG1CQVA4STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTzNJLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9sQixPQUFPMUgsU0FBUzZFLE9BQU83RSxTQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFBRSx1QkFBQyxTQUFNLEtBQUssS0FBTTtBQUFBLFNBQUM0SCxRQUFRLHVCQUFDLGFBQVUsT0FBTSxtQkFBa0IsTUFBSyxTQUFRLE9BQU9FLE9BQU8sVUFBVSxDQUFBekcsTUFBSzBHLFNBQVMxRyxFQUFFOEMsT0FBT0MsS0FBSyxLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsUUFBRyx1QkFBQyxjQUFXLFNBQVEsYUFBWSw0QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQWUyRSxPQUFPQyxLQUFLbEMsVUFBVSxFQUFhdkUsSUFBSSxDQUFBMEcsU0FBUSx1QkFBQyxvQkFBNEIsT0FBTyxHQUFHbkMsV0FBV21DLElBQUksQ0FBQyxNQUFNdE0sa0JBQWtCdU0sWUFBWUQsSUFBSSxHQUFHUCxVQUFVLENBQUMsVUFBVSxTQUFTLHVCQUFDLFlBQVMsU0FBU3hGLE1BQU1pRyxTQUFTRixJQUFJLEdBQUcsVUFBVSxDQUFBNUgsTUFBSzJHLFNBQVMzRyxFQUFFOEMsT0FBT2lGLFVBQVUsQ0FBQyxHQUFHbEcsT0FBTytGLElBQUksSUFBSS9GLE1BQU1tRyxPQUFPLENBQUFyRixNQUFLQSxNQUFNaUYsSUFBSSxDQUFDLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0ksS0FBL09BLE1BQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeVEsQ0FBRTtBQUFBLFFBQUUsdUJBQUMsU0FBTSxVQUFTLFdBQVUsdUhBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUk7QUFBQSxXQUE1bkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvb0I7QUFBQSxTQVBudUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU8ydUI7QUFBQSxJQUFhLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDaEIsUUFBUSxPQUFNLDJCQUEwQixhQUFZLG1GQUFrRixTQUFTLE1BQU1DLFVBQVUsSUFBSSxHQUFHLE1BQU1QLE9BQU83SCxTQUFTLE9BQU82SCxPQUFPM0gsT0FBTyxXQUFXLFlBQVk7QUFDaC9CLFVBQUksQ0FBQ2lJLE9BQVE7QUFDYixZQUFNTixPQUFPakMsUUFBUSxFQUFFQyxNQUFNLEVBQUVtRCxVQUFVYixPQUFPcEcsR0FBRyxHQUFHK0QsU0FBU3FDLE9BQU9sQyxrQkFBa0IsQ0FBQztBQUFBLElBQzdGLEtBSHF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR252QjtBQUFBLE9BaEJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkg7QUFDUjtBQUFDd0IsSUF6QmVELFVBQVE7QUFBQSxVQUNBbkssVUFDUEosUUFBK0JRLGNBQzdCUCxZQUNBQSxZQUNBQSxVQUFVO0FBQUE7QUFBQSxNQUxic0s7QUEwQlQsZ0JBQVNnQyxZQUFZO0FBQUFDLE1BQUE7QUFBRSxRQUFNLEVBQUU1RSxLQUFLLElBQUl4SCxTQUFTO0FBQUcsUUFBTXFLLE9BQU96SyxPQUFPLG1CQUFtQixFQUFFMEssT0FBT2xLLGFBQWEsRUFBRSxDQUFDO0FBQUcsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxxQkFBb0IsVUFBUywyR0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSjtBQUFBLElBQUUsdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSSxFQUFFOEIsSUFBSSxFQUFFLEdBQUcsNE1BQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa087QUFBQSxJQUFRLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPbUksTUFBT0EsZUFBS3BILFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE1BQU1vSCxLQUFLcEgsS0FBS0EsTUFBTSxRQUFRLENBQUFvSixNQUFLQSxFQUFFM0gsSUFBSSxTQUFTO0FBQUEsVUFDN25CLEVBQUV1RyxLQUFLLFFBQVFDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQWtCLE1BQUtwTSxTQUFTb00sRUFBRUMsWUFBWTlFLEtBQUs5QixRQUFRLEVBQUU7QUFBQSxVQUFHLEVBQUV1RixLQUFLLFNBQVNDLE9BQU8sbUJBQW1CQyxRQUFRQSxDQUFBa0IsTUFBS0EsRUFBRUUsUUFBUTtBQUFBLFVBQUcsRUFBRXRCLEtBQUssVUFBVUMsT0FBTyxZQUFZQyxRQUFRQSxDQUFBa0IsTUFBS0EsRUFBRWpELE9BQU87QUFBQSxVQUFHLEVBQUU2QixLQUFLLFVBQVVDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQWtCLE1BQUssR0FBR0EsRUFBRUcsU0FBU0MsSUFBSSxNQUFNSixFQUFFRyxTQUFTOUgsRUFBRSxHQUFHO0FBQUEsVUFBRyxFQUFFdUcsS0FBSyxXQUFXQyxPQUFPLFdBQVdDLFFBQVFBLENBQUFrQixNQUFLQSxFQUFFSyxRQUFRO0FBQUEsVUFBRyxFQUFFekIsS0FBSyxTQUFTQyxPQUFPLGVBQWVDLFFBQVFBLENBQUFrQixNQUFLLHVCQUFDLGNBQVcsU0FBUSxXQUFXQSxZQUFFTSxhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxFQUFjO0FBQUEsUUFBQyxLQUQ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRWxrQjtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNdEMsS0FBS3BILEtBQUt1SSxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGa2lCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFaGlCLEtBRnlmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFcmY7QUFBQSxTQUZtZTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXRkO0FBQUEsT0FGa0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUUxRTtBQUFLO0FBQUNZLElBRmpERCxXQUFTO0FBQUEsVUFBc0JuTSxVQUF5QkosUUFBbUNRLFlBQVk7QUFBQTtBQUFBLE1BQXZHK0w7QUFHVCxnQkFBU1MsY0FBYztBQUFBQyxNQUFBO0FBQzFCLFFBQU1DLFNBQVNsTixPQUFPLGtCQUFrQjtBQUN4QyxRQUFNbU4sV0FBV25OLE9BQU8sdUJBQXVCLEVBQUUwSyxPQUFPbEssYUFBYSxFQUFFLENBQUM7QUFDeEUsUUFBTXFHLE9BQU81RyxXQUFXLHVCQUF1QixDQUFDLGtCQUFrQixDQUFDO0FBQ25FLFFBQU1tTixTQUFTbk4sV0FBVyx3QkFBd0IsQ0FBQyxxQkFBcUIsQ0FBQztBQUN6RSxRQUFNLENBQUNvTixNQUFNQyxPQUFPLElBQUloUCxTQUFTLEVBQUUsR0FBRyxDQUFDaVAsTUFBTUMsT0FBTyxJQUFJbFAsU0FBUyxFQUFFLEdBQUcsQ0FBQ21QLFlBQVlDLFdBQVcsSUFBSXBQLFNBQVMsRUFBRSxHQUFHLENBQUNxUCxNQUFNQyxPQUFPLElBQUl0UCxTQUE4QixRQUFRLEdBQUcsQ0FBQ3VQLFFBQVFDLFNBQVMsSUFBSXhQLFNBQVMsRUFBRSxHQUFHLENBQUM4TSxNQUFNMkMsT0FBTyxJQUFJelAsU0FBUyxLQUFLO0FBQy9PLFFBQU0wUCxtQkFBbUI3TixPQUFPLGdCQUFnQjtBQUNoRCxRQUFNOE4sWUFBWWpPLE9BQU8saUJBQWlCLEVBQUUwSyxPQUFPLEVBQUV3RCxPQUFPLElBQUksRUFBRSxHQUFHRixnQkFBZ0I7QUFDckY1UCxZQUFVLE1BQU07QUFBRSxRQUFJOE8sT0FBTzdKLE1BQU07QUFDL0JpSyxjQUFRSixPQUFPN0osS0FBS0EsS0FBSzhLLG1CQUFtQkMsU0FBUyxLQUFLLEVBQUU7QUFDNURaLGNBQVFOLE9BQU83SixLQUFLQSxLQUFLZ0wsZ0JBQWdCO0FBQUEsSUFDN0M7QUFBQSxFQUFFLEdBQUcsQ0FBQ25CLE9BQU83SixJQUFJLENBQUM7QUFDbEIsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxxQ0FBb0MsVUFBUyxxR0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSztBQUFBLElBQUUsdUJBQUMsT0FBSSxJQUFJLEVBQUV6QixTQUFTLFFBQVEwRCxxQkFBcUIsRUFBRW5ELElBQUksT0FBT21NLElBQUksWUFBWSxHQUFHL0ksS0FBSyxFQUFFLEdBQUc7QUFBQSw2QkFBQyxTQUFNLE9BQU0sc0JBQXFCLGlDQUFDLGNBQVcsT0FBTzJILFFBQVEsaUNBQUMsU0FBTSxLQUFLLEdBQUcsSUFBSSxFQUFFcEwsR0FBRyxFQUFFLEdBQUc7QUFBQSwrQkFBQyxlQUFZLE9BQU8rRSxLQUFLNUQsU0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQUdpSyxPQUFPN0osUUFBUSx1QkFBQyxVQUFPLE9BQU82SixPQUFPN0osS0FBS0EsS0FBSzhCLFVBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUFHLHVCQUFDLGFBQVUsT0FBTSx5QkFBd0IsT0FBT2tJLE1BQU0sVUFBVSxDQUFBL0ksTUFBS2dKLFFBQVFoSixFQUFFOEMsT0FBT0MsS0FBSyxHQUFHLE1BQUssVUFBUyxZQUFZLEVBQUVrSCxLQUFLLEdBQUdDLEtBQUssTUFBTSxLQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStJO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sK0JBQThCLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBT2pCLE1BQU0sVUFBVSxDQUFBakosTUFBS2tKLFFBQVFsSixFQUFFOEMsT0FBT0MsS0FBSyxLQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlIO0FBQUEsUUFBRSx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFRLGFBQVksTUFBTVIsS0FBSzlELFNBQVMsVUFBVSxDQUFDbUssT0FBTzdKLFFBQVEsQ0FBQ2dLLFFBQVFvQixPQUFPcEIsSUFBSSxJQUFJLEtBQUtFLEtBQUsvRixLQUFLLEVBQUVtRSxTQUFTLEdBQUcsU0FBUyxNQUFNO0FBQ3IzQixnQkFBTXRELFVBQVU2RSxPQUFPN0osTUFBTUE7QUFDN0IsY0FBSSxDQUFDZ0YsUUFBUztBQUNkLGVBQUt4QixLQUFLOEIsUUFBUSxFQUFFRSxTQUFTUixRQUFRUSxTQUFTckYsTUFBTSxFQUFFMkssbUJBQW1CTSxPQUFPcEIsSUFBSSxHQUFHZ0Isa0JBQWtCZCxLQUFLLEVBQUUsQ0FBQyxFQUFFbUIsTUFBTSxNQUFNN0MsTUFBUztBQUFBLFFBQzVJLEdBQUcsdUNBSm9zQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSTdxQjtBQUFBLFFBQWlCLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDBLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlMO0FBQUEsV0FKdUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUkvRixLQUpvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSTVELEtBSjBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJYjtBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLHFCQUFvQixRQUFRLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVMsTUFBTWtDLFFBQVEsSUFBSSxHQUFHLDJCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGLEdBQW1CLGlDQUFDLGNBQVcsT0FBT1osVUFBV0EsbUJBQVM5SixRQUFRLG1DQUFFO0FBQUEsK0JBQUMsYUFBVSxNQUFNOEosU0FBUzlKLEtBQUtBLE1BQU0sUUFBUSxDQUFBNEQsTUFBS0EsRUFBRW5DLElBQUksU0FBUztBQUFBLFVBQ2hnQixFQUFFdUcsS0FBSyxZQUFZQyxPQUFPLFNBQVNDLFFBQVFBLENBQUF0RSxNQUFLQSxFQUFFd0csV0FBVztBQUFBLFVBQUcsRUFBRXBDLEtBQUssUUFBUUMsT0FBTyxXQUFXQyxRQUFRQSxDQUFBdEUsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUUwRyxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQixFQUFHO0FBQUEsVUFBRyxFQUFFdEMsS0FBSyxTQUFTQyxPQUFPLGNBQWNDLFFBQVFBLENBQUF0RSxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRTlCLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUFHLEVBQUVrRyxLQUFLLFVBQVVDLE9BQU8sU0FBU0MsUUFBUUEsQ0FBQXRFLE1BQUtBLEVBQUU0RyxPQUFPO0FBQUEsUUFBQyxLQUQ2SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRWpjO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1WLFNBQVM5SixLQUFLdUksUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFdBRjZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFM1osS0FGNFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUV4VyxLQUZ1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTFNO0FBQUEsU0FOb0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU01RztBQUFBLElBQU0sdUJBQUMseUJBQXNCLFdBQVdxQyxVQUFVNUssTUFBTUEsUUFBUSxJQUFJLG9CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlHO0FBQUEsSUFDekssdUJBQUMsY0FBVyxNQUFZLE9BQU0sMkJBQTBCLFNBQVMsTUFBTTBLLFFBQVEsS0FBSyxHQUFHLE1BQU1YLE9BQU9ySyxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDMEssY0FBY0ksT0FBT3JHLEtBQUssRUFBRW1FLFNBQVMsS0FBS3lCLE9BQU9ySyxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDM08sY0FBTXFLLE9BQU96RSxRQUFRLEVBQUVuRixNQUFNLEVBQUVtSyxNQUFNRixZQUFZSSxPQUFPLEVBQUUsQ0FBQztBQUMzREUsZ0JBQVEsS0FBSztBQUFBLE1BQ2pCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyxxQ0FKd0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUluRSxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPWCxPQUFPbkssU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQUUsdUJBQUMsU0FBTSxLQUFLLEdBQUc7QUFBQSwrQkFBQyxhQUFVLE9BQU0sY0FBYSxRQUFNLE1BQUMsT0FBT3dLLFlBQVksVUFBVSxDQUFBbkosTUFBS29KLFlBQVlwSixFQUFFOEMsT0FBT0MsS0FBSyxHQUFJNEcsb0JBQVU1SyxNQUFNQSxLQUFLbUMsSUFBSSxDQUFBK0IsTUFBSyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFekMsSUFBS3lDLFlBQUVrRSxlQUF0QmxFLEVBQUV6QyxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlELENBQVcsS0FBL0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTTtBQUFBLFFBQVksdUJBQUMsYUFBVSxPQUFNLGdCQUFlLFFBQU0sTUFBQyxPQUFPNkksTUFBTSxVQUFVLENBQUFySixNQUFLc0osUUFBUXRKLEVBQUU4QyxPQUFPQyxLQUFvQixHQUFHO0FBQUEsaUNBQUMsWUFBUyxPQUFNLFVBQVMsb0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUyxtQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxhQUEvTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBOO0FBQUEsUUFBWSx1QkFBQyxhQUFVLE9BQU0sNEJBQTJCLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBT3dHLFFBQVEsVUFBVSxDQUFBdkosTUFBS3dKLFVBQVV4SixFQUFFOEMsT0FBT0MsS0FBSyxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsV0FBNWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOGpCO0FBQUEsU0FKL3BCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJdXFCO0FBQUEsT0FYN3BCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXMHFCO0FBQ3JyQjtBQUFDNEYsSUF4QmVELGFBQVc7QUFBQSxVQUNSaE4sUUFDRUEsUUFBdUNRLGNBQzNDUCxZQUNFQSxZQUVVRSxRQUNQSCxNQUFNO0FBQUE7QUFBQSxNQVBaZ047QUEwQmhCLFNBQVMyQixzQkFBc0IsRUFBRVYsV0FBV0QsaUJBQXFGLEdBQUc7QUFBQVksTUFBQTtBQUNoSSxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUl4USxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDeVEsV0FBV0MsWUFBWSxJQUFJMVEsU0FBbUIsRUFBRTtBQUN2RCxRQUFNbVAsYUFBYVEsVUFBVWdCLEtBQUssQ0FBQUMsY0FBWUEsVUFBU3BLLE9BQU8rSixrQkFBa0IsSUFBSUEscUJBQXFCWixVQUFVLENBQUMsR0FBR25KLE1BQU07QUFDN0gsUUFBTW9LLFdBQVdqQixVQUFVakksS0FBSyxDQUFBbUosY0FBYUEsVUFBVXJLLE9BQU8ySSxVQUFVO0FBQ3hFLFFBQU0yQixXQUFXTCxVQUFVM0MsU0FBU3FCLFVBQVU7QUFDOUMsU0FBTyx1QkFBQyxTQUFNLE9BQU0sNkJBQTRCLElBQUksRUFBRWxKLElBQUksRUFBRSxHQUN4RCxpQ0FBQyxTQUFNLEtBQUssR0FBRyxJQUFJLEVBQUV6QyxHQUFHLEVBQUUsR0FDdEI7QUFBQSwyQkFBQyxTQUFNLFVBQVMsUUFBTyx3TUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErTTtBQUFBLElBQzlNa00sbUJBQW1CLG1DQUNoQjtBQUFBLDZCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sYUFBWSxPQUFPUCxZQUFZLFVBQVUsQ0FBQXZFLFVBQVM0RixzQkFBc0I1RixNQUFNOUIsT0FBT0MsS0FBSyxHQUFHLFVBQVUsQ0FBQzZILFVBQzNIakIsb0JBQVV6SSxJQUFJLENBQUE2SixTQUFRLHVCQUFDLFlBQXVCLE9BQU9BLEtBQUt2SyxJQUFLdUssZUFBSzVELGVBQS9CNEQsS0FBS3ZLLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQsQ0FBVyxLQURoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLG9CQUFpQixPQUFNLCtDQUE4QyxTQUFTLHVCQUFDLFlBQVMsU0FBU3NLLFVBQVUsVUFBVSxDQUFDRixVQUFVLFVBQVUsQ0FBQWhHLFVBQVM4RixhQUFhLENBQUEzRyxZQUFXYSxNQUFNOUIsT0FBT2lGLFVBQVUsQ0FBQyxHQUFHLG9CQUFJaUQsSUFBSSxDQUFDLEdBQUdqSCxTQUFTb0YsVUFBVSxDQUFDLENBQUMsSUFBSXBGLFFBQVFpRSxPQUFPLENBQUF4SCxPQUFNQSxPQUFPMkksVUFBVSxDQUFDLEtBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc00sS0FBclI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5UjtBQUFBLE1BQ3hSeUIsWUFBWSx1QkFBQyxPQUFJLE1BQUssVUFBUyxlQUFZLDBCQUN4QztBQUFBLCtCQUFDLGNBQVcsT0FBTSxhQUFhQSxtQkFBU3pELGVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxRQUNwRCx1QkFBQyxjQUFXLE9BQU0sV0FBVSxxREFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFLHVCQUFDLGNBQVcsT0FBTSxhQUFhMkQscUJBQVcsc0NBQXNDLDBCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsUUFDdkcsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBaUIsSUFBSSxFQUFFN0ssSUFBSSxFQUFFLEdBQUc7QUFBQTtBQUFBLFVBQWlDd0ssVUFBVXBEO0FBQUFBLFVBQU87QUFBQSxhQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtMO0FBQUEsV0FKeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtiO0FBQUEsTUFDQyxDQUFDdUQsWUFBWSx1QkFBQyxTQUFNLFVBQVMsUUFBTywyREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLFNBWGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZcEIsSUFBTSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxnR0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRztBQUFBLE9BZHBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQSxLQWhCRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJQO0FBQ0o7QUFBQ04sSUF4QlFELHVCQUFxQjtBQUFBLE1BQXJCQTtBQXlCRixnQkFBU1ksVUFBVTtBQUFBQyxNQUFBO0FBQ3RCLFFBQU0sRUFBRUMsUUFBUSxHQUFHLElBQUk5USxVQUFVO0FBQ2pDLFFBQU0sRUFBRWlKLEtBQUssSUFBSXhILFNBQVM7QUFDMUIsUUFBTXNELE1BQU0xRCxPQUFPLFVBQVUsRUFBRTRJLE1BQU0sRUFBRTZHLE1BQU0sRUFBRSxDQUFDO0FBQ2hELFFBQU1DLE1BQU1oTSxJQUFJTCxNQUFNQTtBQUN0QixRQUFNc00sZUFBZUQsS0FBS0UsY0FBY3JQLHVCQUF1Qm1QLElBQUlFLGFBQWEzTCxTQUFTRCxRQUFRRCxRQUFRLElBQUk7QUFDN0csUUFBTThMLFlBQVlILEtBQUt2SztBQUN2QixRQUFNLEVBQUUySyxRQUFRLElBQUlwTTtBQUNwQnRGLFlBQVUsTUFBTTtBQUFFLFFBQUksQ0FBQ3lSLGFBQWEsQ0FBQyxDQUFDLFVBQVUsU0FBUyxFQUFFekQsU0FBU3lELFNBQVM7QUFDekU7QUFBUSxVQUFNRSxRQUFRQyxZQUFZLE1BQU0sS0FBS0YsUUFBUSxHQUFHLEdBQUk7QUFBRyxXQUFPLE1BQU1HLGNBQWNGLEtBQUs7QUFBQSxFQUFHLEdBQUcsQ0FBQ0YsV0FBV0MsT0FBTyxDQUFDO0FBQzdILFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU8sYUFBYUwsS0FBSyxJQUFJLFVBQVMseUVBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUg7QUFBQSxJQUFFLHVCQUFDLGNBQVcsT0FBTy9MLEtBQU1nTSxpQkFBTyx1QkFBQyxTQUFNLE9BQU0saUJBQWdCLGlDQUFDLFNBQU0sS0FBSyxHQUFHLElBQUksRUFBRTVOLEdBQUcsRUFBRSxHQUFHO0FBQUEsNkJBQUMsVUFBTyxPQUFPNE4sSUFBSXZLLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBTSxRQUFRdUssY0FBSS9CLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxXQUFXK0I7QUFBQUEsWUFBSVE7QUFBQUEsUUFBVTtBQUFBLFFBQUlSLElBQUlTLFNBQVM7QUFBQSxXQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sT0FBT1QsY0FBSVUsY0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFlBQVkvUCxtQkFBU3FQLElBQUlXLFdBQVd6SSxLQUFLOUIsUUFBUSxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFBYzRKLElBQUlZLFVBQVUzRSxTQUFTLEtBQUssdUJBQUMsYUFBVSxNQUFNK0QsSUFBSVksV0FBVyxRQUFRLENBQUFoTSxNQUFLLEdBQUdBLEVBQUVpTSxHQUFHLElBQUlqTSxFQUFFa0UsS0FBSyxJQUFJbEUsRUFBRWtNLElBQUksSUFBSSxTQUFTLENBQUMsRUFBRW5GLEtBQUssT0FBT0MsT0FBTyxRQUFRQyxRQUFRQSxDQUFBakgsTUFBS0EsRUFBRWlNLElBQUksR0FBRyxFQUFFbEYsS0FBSyxTQUFTQyxPQUFPLFVBQVVDLFFBQVFBLENBQUFqSCxNQUFLQSxFQUFFa0UsTUFBTSxHQUFHLEVBQUU2QyxLQUFLLFdBQVdDLE9BQU8sT0FBT0MsUUFBUUEsQ0FBQWpILE1BQUtBLEVBQUVtTSxRQUFRLENBQUMsS0FBNVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4UDtBQUFBLE1BQUcsdUJBQUMsVUFBTyxTQUFTLE1BQU0sS0FBSy9NLElBQUlvTSxRQUFRLEdBQUcsU0FBUSxZQUFXLDRCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFBVUosSUFBSUUsZUFBZSxDQUFDLGFBQWEsU0FBUyxFQUFFeEQsU0FBU3NELElBQUl2SyxNQUFNLEtBQUt3SyxnQkFBZ0IsdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNeEwsT0FBT2lILEtBQUt1RSxjQUFjLFVBQVUscUJBQXFCLEdBQUcsK0JBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxNQUFXRCxJQUFJRSxlQUFlLENBQUMsYUFBYSxTQUFTLEVBQUV4RCxTQUFTc0QsSUFBSXZLLE1BQU0sS0FBSyxDQUFDd0ssZ0JBQWdCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHVFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsTUFBVUQsSUFBSXZLLFdBQVcsMkJBQTJCLHVCQUFDLGFBQVUsSUFBSSxNQUFNeUMsS0FBSzlDLEVBQUUsWUFBWTRLLElBQUk1SyxFQUFFLElBQUksb0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxTQUE1cUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5ckMsS0FBdHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOHRDLEtBQTl2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXV3QztBQUFBLE9BQWw0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQSs0QztBQUMxNUM7QUFBQzBLLElBWGVELFNBQU87QUFBQSxVQUNJNVEsV0FDTnlCLFVBQ0xKLE1BQU07QUFBQTtBQUFBLE1BSE51UDtBQUFPLElBQUE5TSxJQUFBaU8sS0FBQUMsS0FBQUMsS0FBQUMsS0FBQS9HLEtBQUFnSCxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUF6TyxJQUFBO0FBQUEsYUFBQWlPLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBL0csS0FBQTtBQUFBLGFBQUFnSCxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiTGluayIsIlJvdXRlckxpbmsiLCJOYXZpZ2F0ZSIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlU2VhcmNoUGFyYW1zIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsIkFsZXJ0IiwiQXZhdGFyIiwiQm94IiwiQnV0dG9uIiwiQ2hlY2tib3giLCJGb3JtQ29udHJvbExhYmVsIiwiTWVudUl0ZW0iLCJQYXBlciIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsIlNtYXJ0VG95Um91bmRlZCIsIkFycm93Rm9yd2FyZFJvdW5kZWQiLCJwZXJtaXNzaW9uQ2F0YWxvZyIsImNvbG9ycyIsInJlcXVlc3QiLCJzZXRDc3JmVG9rZW4iLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwiQXBpRXJyb3IiLCJ1c2VDYW4iLCJ1c2VTY29wZSIsImRhdGVUaW1lIiwic2FmZUludGVybmFsUGF0aCIsImF1dGhvcml6ZWREb3dubG9hZEhyZWYiLCJ1c2VMaXN0UXVlcnkiLCJtYXJrRHJhZnRDbGVhbiIsInNldERyYWZ0RGlydHkiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJRdWVyeVN0YXRlIiwiRGF0YVRhYmxlIiwiVG9vbGJhciIsIlBhZ2VyIiwiU3RhdHVzIiwiTXV0YXRpb25CdXR0b24iLCJFZGl0RGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJDb25maXJtRGlhbG9nIiwiUm91dGVMaW5rIiwiRGV0YWlsTGluZSIsInVzZVNlc3Npb24iLCJBdXRoQ2FyZCIsImNoaWxkcmVuIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsInBsYWNlSXRlbXMiLCJwIiwiYmdjb2xvciIsIm91dGxpbmUiLCJ3aWR0aCIsIm1heFdpZHRoIiwieHMiLCJzbSIsImJvcmRlclJhZGl1cyIsIm1iIiwiY29sb3IiLCJvbkFjY2VudCIsIl9jIiwiTG9naW5QYWdlIiwiX3MiLCJzZXNzaW9uIiwibG9hZGluZyIsInBhcmFtcyIsInBlbmRpbmciLCJzZXRQZW5kaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvZ2luIiwiY3NyZiIsImRhdGEiLCJjc3JmVG9rZW4iLCJhdXRoIiwiYm9keSIsInJldHVyblRvIiwiZ2V0IiwidXJsIiwiVVJMIiwiYXV0aG9yaXphdGlvblVybCIsInByb3RvY29sIiwiX19NT0NLX18iLCJvcmlnaW4iLCJsb2NhdGlvbiIsIkVycm9yIiwid2luZG93IiwiYXNzaWduIiwiaHJlZiIsImUiLCJtdCIsIldvcmtzcGFjZXNQYWdlIiwiX3MyIiwic2Vzc2lvbkVycm9yIiwic2hvcHMiLCJxdWVyeUtleSIsInVzZXIiLCJpZCIsInF1ZXJ5Rm4iLCJzaWduYWwiLCJlbmFibGVkIiwicmV0cnkiLCJzdGF0dXMiLCJteCIsIm1kIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdhcCIsIm1hcCIsInMiLCJzZWxlY3RlZCIsIm5hbWUiLCJteSIsImN1cnJlbmN5IiwidGltZXpvbmUiLCJtZW1iZXJzaGlwcyIsImZpbmQiLCJtIiwic2hvcElkIiwicm9sZXMiLCJqb2luIiwiT25ib2FyZGluZ1BhZ2UiLCJfczMiLCJuYXZpZ2F0ZSIsInJlZnJlc2giLCJjYWNoZSIsInNldE5hbWUiLCJzZXRDdXJyZW5jeSIsInNldFRpbWV6b25lIiwic2F2ZSIsIkludGwiLCJEYXRlVGltZUZvcm1hdCIsInRpbWVab25lIiwiciIsImxvY2FsZSIsImludmFsaWRhdGVRdWVyaWVzIiwidGFyZ2V0IiwidmFsdWUiLCJtYXhMZW5ndGgiLCJjIiwidHJpbSIsIlNob3BTZXR0aW5nc1BhZ2UiLCJfczQiLCJzY29wZSIsInNob3AiLCJjYW5NYW5hZ2VTaG9wIiwidXBkYXRlIiwic2V0TG9jYWxlIiwic2F2ZWQiLCJzZXRTYXZlZCIsImZvcm1SZWYiLCJiYXNlbGluZSIsImRyYWZ0IiwiY3VycmVudCIsIm5leHQiLCJ1cGRhdGVGaWVsZCIsImZpZWxkIiwiZm9ybSIsInJlc3VsdCIsImV4ZWN1dGUiLCJwYXRoIiwidmVyc2lvbiIsInNldFF1ZXJ5RGF0YSIsIm1lbWJlcnNoaXAiLCJwZXJtaXNzaW9uVmVyc2lvbiIsInBlcnNpc3RlZCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJjdXJyZW50VGFyZ2V0IiwiU2V0dXBDaGVja2xpc3RJdGVtIiwidGl0bGUiLCJ0byIsImFjdGlvbiIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiZmxleFdyYXAiLCJfYzYiLCJyb2xlTGFiZWxzIiwib3duZXIiLCJtYW5hZ2VyIiwic2FsZXMiLCJ3YXJlaG91c2UiLCJhY2NvdW50YW50IiwiYm90X2FkbWluIiwidmlld2VyIiwiVGVhbVBhZ2UiLCJfczUiLCJsaXN0IiwicXVlcnkiLCJpbnZpdGUiLCJyZXZva2UiLCJlZGl0Iiwic2V0RWRpdCIsImVtYWlsIiwic2V0RW1haWwiLCJzZXRSb2xlcyIsInJlbW92ZSIsInNldFJlbW92ZSIsIm9wZW4iLCJrZXkiLCJsYWJlbCIsInJlbmRlciIsInVzZXJJZCIsImRpc3BsYXlOYW1lIiwicGVybWlzc2lvbnMiLCJsZW5ndGgiLCJwYWdlIiwidW5kZWZpbmVkIiwidGVzdCIsIm1lbWJlcklkIiwiT2JqZWN0Iiwia2V5cyIsInJvbGUiLCJyb2xlUHJlc2V0cyIsImluY2x1ZGVzIiwiY2hlY2tlZCIsImZpbHRlciIsIkF1ZGl0UGFnZSIsIl9zNiIsImEiLCJvY2N1cnJlZEF0IiwiYWN0b3JJZCIsInJlc291cmNlIiwidHlwZSIsInN1bW1hcnkiLCJyZXF1ZXN0SWQiLCJQcml2YWN5UGFnZSIsIl9zNyIsInBvbGljeSIsInJlcXVlc3RzIiwiY3JlYXRlIiwiZGF5cyIsInNldERheXMiLCJub3RlIiwic2V0Tm90ZSIsImN1c3RvbWVySWQiLCJzZXRDdXN0b21lciIsImtpbmQiLCJzZXRLaW5kIiwicmVhc29uIiwic2V0UmVhc29uIiwic2V0T3BlbiIsImNhblJlYWRDdXN0b21lcnMiLCJjdXN0b21lcnMiLCJsaW1pdCIsImNoYXRSZXRlbnRpb25EYXlzIiwidG9TdHJpbmciLCJqdXJpc2RpY3Rpb25Ob3RlIiwibGciLCJtaW4iLCJtYXgiLCJOdW1iZXIiLCJjYXRjaCIsIkNvbnRhY3RDb25zZW50UHJldmlldyIsIl9zOCIsInNlbGVjdGVkQ3VzdG9tZXJJZCIsInNldFNlbGVjdGVkQ3VzdG9tZXJJZCIsIm9wdE91dElkcyIsInNldE9wdE91dElkcyIsInNvbWUiLCJjdXN0b21lciIsImNhbmRpZGF0ZSIsIm9wdGVkT3V0IiwiaXRlbSIsIlNldCIsIkpvYlBhZ2UiLCJfczkiLCJqb2JJZCIsImpvYiIsImRvd25sb2FkSHJlZiIsImRvd25sb2FkVXJsIiwiam9iU3RhdHVzIiwicmVmZXRjaCIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwiY29tcGxldGVkIiwidG90YWwiLCJlcnJvckNvdW50IiwidXBkYXRlZEF0Iiwicm93RXJyb3JzIiwicm93IiwiY29kZSIsIm1lc3NhZ2UiLCJfYzIiLCJfYzMiLCJfYzQiLCJfYzUiLCJfYzciLCJfYzgiLCJfYzkiLCJfYzAiLCJfYzEiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayBhcyBSb3V0ZXJMaW5rLCBOYXZpZ2F0ZSwgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcywgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknO1xuaW1wb3J0IHsgQWxlcnQsIEF2YXRhciwgQm94LCBCdXR0b24sIENoZWNrYm94LCBGb3JtQ29udHJvbExhYmVsLCBNZW51SXRlbSwgUGFwZXIsIFN0YWNrLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCBTbWFydFRveVJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9TbWFydFRveVJvdW5kZWQnO1xuaW1wb3J0IEFycm93Rm9yd2FyZFJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd0ZvcndhcmRSb3VuZGVkJztcbmltcG9ydCB0eXBlIHsgTWVtYmVyc2hpcCwgUm9sZSB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgcGVybWlzc2lvbkNhdGFsb2cgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IGNvbG9ycyB9IGZyb20gJ0Bib3RzYWxlcy90b2tlbnMnO1xuaW1wb3J0IHsgcmVxdWVzdCwgc2V0Q3NyZlRva2VuIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2NsaWVudCc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICdAL3NoYXJlZC9hcGkvZXJyb3JzJztcbmltcG9ydCB7IHVzZUNhbiwgdXNlU2NvcGUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyBkYXRlVGltZSwgc2FmZUludGVybmFsUGF0aCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XG5pbXBvcnQgeyBhdXRob3JpemVkRG93bmxvYWRIcmVmIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZG93bmxvYWQnO1xuaW1wb3J0IHsgdXNlTGlzdFF1ZXJ5IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZmlsdGVycyc7XG5pbXBvcnQgeyBtYXJrRHJhZnRDbGVhbiwgc2V0RHJhZnREaXJ0eSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XG5pbXBvcnQgeyBQYWdlSGVhZGVyLCBQYW5lbCwgUXVlcnlTdGF0ZSwgRGF0YVRhYmxlLCBUb29sYmFyLCBQYWdlciwgU3RhdHVzLCBNdXRhdGlvbkJ1dHRvbiwgRWRpdERpYWxvZywgRXJyb3JOb3RpY2UsIENvbmZpcm1EaWFsb2csIFJvdXRlTGluaywgRGV0YWlsTGluZSB9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgdXNlU2Vzc2lvbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2F1dGgnO1xuZnVuY3Rpb24gQXV0aENhcmQoeyBjaGlsZHJlbiB9OiB7XG4gICAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbn0pIHsgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwibWFpblwiIGlkPVwibWFpbi1jb250ZW50XCIgdGFiSW5kZXg9ey0xfSBzeD17eyBtaW5IZWlnaHQ6ICcxMDB2aCcsIGRpc3BsYXk6ICdncmlkJywgcGxhY2VJdGVtczogJ2NlbnRlcicsIHA6IDMsIGJnY29sb3I6ICdiYWNrZ3JvdW5kLmRlZmF1bHQnLCBvdXRsaW5lOiAnbm9uZScgfX0+PFBhcGVyIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIHN4PXt7IHdpZHRoOiAnMTAwJScsIG1heFdpZHRoOiA1MjAsIHA6IHsgeHM6IDMsIHNtOiA1IH0sIGJvcmRlclJhZGl1czogNCB9fT48U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIGdhcD17MS41fSBzeD17eyBtYjogNCB9fT48QXZhdGFyIHN4PXt7IGJnY29sb3I6ICdwcmltYXJ5Lm1haW4nLCBjb2xvcjogY29sb3JzLm9uQWNjZW50IH19PjxTbWFydFRveVJvdW5kZWQgLz48L0F2YXRhcj48VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIiBmb250V2VpZ2h0PXs4MDB9PkJvdFNhbGVzIDxCb3ggY29tcG9uZW50PVwic3BhblwiIGNvbG9yPVwicHJpbWFyeS5tYWluXCI+QUk8L0JveD48L1R5cG9ncmFwaHk+PC9TdGFjaz57Y2hpbGRyZW59PC9QYXBlcj48L0JveD47IH1cbmV4cG9ydCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XG4gICAgY29uc3QgeyBzZXNzaW9uLCBsb2FkaW5nIH0gPSB1c2VTZXNzaW9uKCk7XG4gICAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBbcGVuZGluZywgc2V0UGVuZGluZ10gPSB1c2VTdGF0ZShmYWxzZSksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBsb2dpbiA9IGFzeW5jICgpID0+IHsgc2V0UGVuZGluZyh0cnVlKTsgc2V0RXJyb3IobnVsbCk7IHRyeSB7XG4gICAgICAgIGNvbnN0IGNzcmYgPSBhd2FpdCByZXF1ZXN0KCdnZXRDc3JmVG9rZW4nKTtcbiAgICAgICAgc2V0Q3NyZlRva2VuKGNzcmYuZGF0YS5jc3JmVG9rZW4pO1xuICAgICAgICBjb25zdCBhdXRoID0gYXdhaXQgcmVxdWVzdCgnYmVnaW5Mb2dpbicsIHsgYm9keTogeyByZXR1cm5Ubzogc2FmZUludGVybmFsUGF0aChwYXJhbXMuZ2V0KCdyZXR1cm5UbycpIHx8ICcvd29ya3NwYWNlcycpIH0gfSk7XG4gICAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoYXV0aC5kYXRhLmF1dGhvcml6YXRpb25VcmwpO1xuICAgICAgICBpZiAodXJsLnByb3RvY29sICE9PSAnaHR0cHM6JyAmJiAhKF9fTU9DS19fICYmIHVybC5vcmlnaW4gPT09IGxvY2F0aW9uLm9yaWdpbikpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ8SQ4buLYSBjaOG7iSDEkcSDbmcgbmjhuq1wIGtow7RuZyBhbiB0b8Ogbi4nKTtcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmFzc2lnbih1cmwuaHJlZik7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUgOiBuZXcgRXJyb3IoJ0tow7RuZyBi4bqvdCDEkeG6p3UgxJHGsOG7o2MgxJHEg25nIG5o4bqtcCcpKTtcbiAgICAgICAgc2V0UGVuZGluZyhmYWxzZSk7XG4gICAgfSB9O1xuICAgIHJldHVybiA8QXV0aENhcmQ+PFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDFcIiB2YXJpYW50PVwiaDRcIiBzeD17eyBtYjogMSB9fT5DaMOgbyBt4burbmcgdHLhu58gbOG6oWk8L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXt7IG1iOiA0IH19Pk3hu5l0IGtow7RuZyBnaWFuIGNobyBiw6FuIGjDoG5nLCBraG8sIGvhur8gdG/DoW4gdsOgIMSR4buZaSBuZ8WpIEFJIGPhu6dhIGLhuqFuLjwvVHlwb2dyYXBoeT48RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yfS8+e19fTU9DS19fICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17eyBtYjogMyB9fT5DaOG6vyDEkeG7mSB4ZW0gZnJvbnRlbmQ6IHTDoGkga2hv4bqjbiBnaeG6oyBs4bqtcCwga2jDtG5nIGPDsyBt4bqtdCBraOG6qXUgdGjhuq10LjwvQWxlcnQ+fXtzZXNzaW9uID8gPEJ1dHRvbiBmdWxsV2lkdGggY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz1cIi93b3Jrc3BhY2VzXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGVuZEljb249ezxBcnJvd0ZvcndhcmRSb3VuZGVkIC8+fT5UaeG6v3AgdOG7pWMgdsOgbyBj4butYSBow6BuZzwvQnV0dG9uPiA6IDxCdXR0b24gZnVsbFdpZHRoIHZhcmlhbnQ9XCJjb250YWluZWRcIiBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGxvZ2luKCl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IGxvYWRpbmd9PntwZW5kaW5nID8gJ8SQYW5nIGNodXnhu4NuIMSR4bq/biDEkcSDbmcgbmjhuq1w4oCmJyA6IF9fTU9DS19fID8gJ1bDoG8gdMOgaSBraG/huqNuIG3DtCBwaOG7j25nJyA6ICfEkMSDbmcgbmjhuq1wIGLhurFuZyB0w6BpIGtob+G6o24gY8O0bmcgdHknfTwvQnV0dG9uPn08VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17eyBkaXNwbGF5OiAnYmxvY2snLCBtdDogMyB9fT5QaGnDqm4gxJHEg25nIG5o4bqtcCDEkcaw4bujYyBxdeG6o24gbMO9IOG7nyBtw6F5IGNo4bunLiBLaMO0bmcgbMawdSBhY2Nlc3MgdG9rZW4gdHJvbmcgbG9jYWxTdG9yYWdlLjwvVHlwb2dyYXBoeT48L0F1dGhDYXJkPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBXb3Jrc3BhY2VzUGFnZSgpIHtcbiAgICBjb25zdCB7IHNlc3Npb24sIGxvYWRpbmcsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSA9IHVzZVNlc3Npb24oKTtcbiAgICBjb25zdCBzaG9wcyA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IFsnc2hvcHMnLCBzZXNzaW9uPy51c2VyLmlkXSwgcXVlcnlGbjogKHsgc2lnbmFsIH0pID0+IHJlcXVlc3QoJ2xpc3RTaG9wcycsIHsgc2lnbmFsIH0pLCBlbmFibGVkOiAhIXNlc3Npb24sIHJldHJ5OiBmYWxzZSB9KTtcbiAgICBpZiAoIWxvYWRpbmcgJiYgIXNlc3Npb24gJiYgc2Vzc2lvbkVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgc2Vzc2lvbkVycm9yLnN0YXR1cyA9PT0gNDAxKVxuICAgICAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZS8+O1xuICAgIHJldHVybiA8Qm94IGNvbXBvbmVudD1cIm1haW5cIiBpZD1cIm1haW4tY29udGVudFwiIHRhYkluZGV4PXstMX0gc3g9e3sgbWF4V2lkdGg6IDExMDAsIG14OiAnYXV0bycsIHA6IHsgeHM6IDMsIG1kOiA2IH0sIG91dGxpbmU6ICdub25lJyB9fT48UGFnZUhlYWRlciB0aXRsZT1cIkNo4buNbiBj4butYSBow6BuZ1wiIHN1YnRpdGxlPVwiTeG7l2kgY+G7rWEgaMOgbmcgbMOgIG3hu5l0IHbDuW5nIGThu68gbGnhu4d1IHbDoCBxdXnhu4FuIMSR4buZYyBs4bqtcC5cIiBhY3Rpb25zPXs8QnV0dG9uIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89XCIvb25ib2FyZGluZ1wiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5U4bqhbyBj4butYSBow6BuZzwvQnV0dG9uPn0vPjxFcnJvck5vdGljZSBlcnJvcj17c2Vzc2lvbkVycm9yfS8+PFF1ZXJ5U3RhdGUgcXVlcnk9e3Nob3BzfT48Qm94IHN4PXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogeyB4czogJzFmcicsIG1kOiAncmVwZWF0KDIsMWZyKScgfSwgZ2FwOiAzIH19PntzaG9wcy5kYXRhPy5kYXRhLm1hcChzID0+IDxQYXBlciB2YXJpYW50PVwib3V0bGluZWRcIiBrZXk9e3MuaWR9IHN4PXt7IHA6IDMsIGJvcmRlclJhZGl1czogMyB9fT48QXZhdGFyIHN4PXt7IG1iOiAyLCBiZ2NvbG9yOiBjb2xvcnMuc2VsZWN0ZWQsIGNvbG9yOiAncHJpbWFyeS5tYWluJyB9fT57cy5uYW1lWzBdfTwvQXZhdGFyPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiPntzLm5hbWV9PC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17eyBteTogMS41IH19PntzLmN1cnJlbmN5fSDCtyB7cy50aW1lem9uZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+UXV54buBbjoge3Nlc3Npb24/Lm1lbWJlcnNoaXBzLmZpbmQobSA9PiBtLnNob3BJZCA9PT0gcy5pZCk/LnJvbGVzLmpvaW4oJywgJykgfHwgJ0NoxrBhIGPDsyBxdXnhu4FuJ308L1R5cG9ncmFwaHk+PEJ1dHRvbiBjb21wb25lbnQ9e1JvdXRlckxpbmt9IHRvPXtgL3MvJHtzLmlkfS9vdmVydmlld2B9IGZ1bGxXaWR0aCB2YXJpYW50PVwib3V0bGluZWRcIiBlbmRJY29uPXs8QXJyb3dGb3J3YXJkUm91bmRlZCAvPn0gc3g9e3sgbXQ6IDMgfX0+TeG7nyBj4butYSBow6BuZzwvQnV0dG9uPjwvUGFwZXI+KX08L0JveD48L1F1ZXJ5U3RhdGU+PC9Cb3g+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIE9uYm9hcmRpbmdQYWdlKCkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHJlZnJlc2ggfSA9IHVzZVNlc3Npb24oKTtcbiAgICBjb25zdCBjYWNoZSA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gICAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpLCBbY3VycmVuY3ksIHNldEN1cnJlbmN5XSA9IHVzZVN0YXRlKCdWTkQnKSwgW3RpbWV6b25lLCBzZXRUaW1lem9uZV0gPSB1c2VTdGF0ZSgnQXNpYS9WaWVudGlhbmUnKSwgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpLCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3Qgc2F2ZSA9IGFzeW5jICgpID0+IHsgc2V0UGVuZGluZyh0cnVlKTsgc2V0RXJyb3IobnVsbCk7IHRyeSB7XG4gICAgICAgIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KCd2aScsIHsgdGltZVpvbmU6IHRpbWV6b25lIH0pO1xuICAgICAgICBjb25zdCByID0gYXdhaXQgcmVxdWVzdCgnY3JlYXRlU2hvcCcsIHsgYm9keTogeyBuYW1lLCBjdXJyZW5jeSwgdGltZXpvbmUsIGxvY2FsZTogJ3ZpLVZOJyB9IH0pO1xuICAgICAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgICAgIGF3YWl0IGNhY2hlLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnc2hvcHMnXSB9KTtcbiAgICAgICAgbmF2aWdhdGUoYC9zLyR7ci5kYXRhLmlkfS9vdmVydmlld2ApO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgdOG6oW8gxJHGsOG7o2MgY+G7rWEgaMOgbmcnKSk7XG4gICAgfVxuICAgIGZpbmFsbHkge1xuICAgICAgICBzZXRQZW5kaW5nKGZhbHNlKTtcbiAgICB9IH07XG4gICAgcmV0dXJuIDxBdXRoQ2FyZD48VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoNFwiIHN4PXt7IG1iOiAxIH19PlThuqFvIGPhu61hIGjDoG5nPC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17eyBtYjogMyB9fT5DaOG7jW4gdGnhu4FuIHThu4cgY8ahIHPhu58gdHLGsOG7m2Mga2hpIGdoaSBuaOG6rW4gZ2lhbyBk4buLY2guPC9UeXBvZ3JhcGh5PjxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3J9Lz48U3RhY2sgZ2FwPXsyLjV9PjxUZXh0RmllbGQgbGFiZWw9XCJUw6puIGPhu61hIGjDoG5nXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXtlID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfSBpbnB1dFByb3BzPXt7IG1heExlbmd0aDogMTYwIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiVGnhu4FuIHThu4cgY8ahIHPhu59cIiBzZWxlY3QgdmFsdWU9e2N1cnJlbmN5fSBvbkNoYW5nZT17ZSA9PiBzZXRDdXJyZW5jeShlLnRhcmdldC52YWx1ZSl9PntbJ1ZORCcsICdMQUsnLCAnVEhCJywgJ1VTRCddLm1hcChjID0+IDxNZW51SXRlbSBrZXk9e2N9IHZhbHVlPXtjfT57Y308L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PFRleHRGaWVsZCBsYWJlbD1cIk3DumkgZ2nhu51cIiB2YWx1ZT17dGltZXpvbmV9IG9uQ2hhbmdlPXtlID0+IHNldFRpbWV6b25lKGUudGFyZ2V0LnZhbHVlKX0vPjxBbGVydCBzZXZlcml0eT1cImluZm9cIj5HaWFvIGRp4buHbiBHcmFwaGl0ZSBHb2xkIGRhcmstb25seSDEkcOjIGNo4buRdC4gTmjhu69uZyBjaMOtbmggc8OhY2ggdGjhuq10IHbDoCBr4bq/dCBu4buRaSBuZ2/DoGkgY2jGsGEgdOG7sSBi4bqtdCBraGkgdOG6oW8gc2hvcC48L0FsZXJ0PjxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshbmFtZS50cmltKCkgfHwgIXRpbWV6b25lIHx8IHBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgc2F2ZSgpfT5U4bqhbyBj4butYSBow6BuZzwvQnV0dG9uPjxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz1cIi93b3Jrc3BhY2VzXCI+UXVheSBs4bqhaTwvQnV0dG9uPjwvU3RhY2s+PC9BdXRoQ2FyZD47XG59XG5leHBvcnQgZnVuY3Rpb24gU2hvcFNldHRpbmdzUGFnZSgpIHtcbiAgICBjb25zdCBzY29wZSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgeyBzaG9wIH0gPSBzY29wZTtcbiAgICBjb25zdCBjYWNoZSA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gICAgY29uc3QgY2FuTWFuYWdlU2hvcCA9IHVzZUNhbignc2hvcC5tYW5hZ2UnKTtcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVTaG9wJywgWydnZXRTaG9wJ10pO1xuICAgIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKHNob3AubmFtZSksIFt0aW1lem9uZSwgc2V0VGltZXpvbmVdID0gdXNlU3RhdGUoc2hvcC50aW1lem9uZSksIFtsb2NhbGUsIHNldExvY2FsZV0gPSB1c2VTdGF0ZShzaG9wLmxvY2FsZSksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKSwgW3NhdmVkLCBzZXRTYXZlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgZm9ybVJlZiA9IHVzZVJlZjxIVE1MRm9ybUVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGJhc2VsaW5lID0gdXNlUmVmKHsgc2hvcElkOiBzaG9wLmlkLCBuYW1lOiBzaG9wLm5hbWUsIHRpbWV6b25lOiBzaG9wLnRpbWV6b25lLCBsb2NhbGU6IHNob3AubG9jYWxlIH0pO1xuICAgIGNvbnN0IGRyYWZ0ID0gdXNlUmVmKGJhc2VsaW5lLmN1cnJlbnQpO1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChiYXNlbGluZS5jdXJyZW50LnNob3BJZCA9PT0gc2hvcC5pZClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3QgbmV4dCA9IHsgc2hvcElkOiBzaG9wLmlkLCBuYW1lOiBzaG9wLm5hbWUsIHRpbWV6b25lOiBzaG9wLnRpbWV6b25lLCBsb2NhbGU6IHNob3AubG9jYWxlIH07XG4gICAgICAgIGJhc2VsaW5lLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICBkcmFmdC5jdXJyZW50ID0gbmV4dDtcbiAgICAgICAgc2V0TmFtZShuZXh0Lm5hbWUpO1xuICAgICAgICBzZXRUaW1lem9uZShuZXh0LnRpbWV6b25lKTtcbiAgICAgICAgc2V0TG9jYWxlKG5leHQubG9jYWxlKTtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIHNldFNhdmVkKGZhbHNlKTtcbiAgICAgICAgaWYgKGZvcm1SZWYuY3VycmVudClcbiAgICAgICAgICAgIG1hcmtEcmFmdENsZWFuKGZvcm1SZWYuY3VycmVudCk7XG4gICAgfSwgW3Nob3AuaWQsIHNob3AubG9jYWxlLCBzaG9wLm5hbWUsIHNob3AudGltZXpvbmVdKTtcbiAgICBjb25zdCB1cGRhdGVGaWVsZCA9IChmaWVsZDogJ25hbWUnIHwgJ3RpbWV6b25lJyB8ICdsb2NhbGUnLCB2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSB7IC4uLmRyYWZ0LmN1cnJlbnQsIFtmaWVsZF06IHZhbHVlIH07XG4gICAgICAgIGRyYWZ0LmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICBzZXREcmFmdERpcnR5KGZvcm1SZWYuY3VycmVudCwgbmV4dC5zaG9wSWQgIT09IGJhc2VsaW5lLmN1cnJlbnQuc2hvcElkIHx8IG5leHQubmFtZSAhPT0gYmFzZWxpbmUuY3VycmVudC5uYW1lIHx8IG5leHQudGltZXpvbmUgIT09IGJhc2VsaW5lLmN1cnJlbnQudGltZXpvbmUgfHwgbmV4dC5sb2NhbGUgIT09IGJhc2VsaW5lLmN1cnJlbnQubG9jYWxlKTtcbiAgICAgICAgc2V0U2F2ZWQoZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3Qgc2F2ZSA9IGFzeW5jIChmb3JtOiBIVE1MRm9ybUVsZW1lbnQpID0+IHtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIHNldFNhdmVkKGZhbHNlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KGxvY2FsZSwgeyB0aW1lWm9uZTogdGltZXpvbmUgfSk7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGRhdGUuZXhlY3V0ZSh7IHBhdGg6IHsgc2hvcElkOiBzaG9wLmlkIH0sIHZlcnNpb246IHNob3AudmVyc2lvbiwgYm9keTogeyBuYW1lLCB0aW1lem9uZSwgbG9jYWxlIH0gfSk7XG4gICAgICAgICAgICBjYWNoZS5zZXRRdWVyeURhdGEoWydzaG9wJywgc2NvcGUuc2Vzc2lvbi51c2VyLmlkLCBzaG9wLmlkLCBzY29wZS5tZW1iZXJzaGlwLnBlcm1pc3Npb25WZXJzaW9uXSwgcmVzdWx0KTtcbiAgICAgICAgICAgIGNvbnN0IHBlcnNpc3RlZCA9IHsgc2hvcElkOiByZXN1bHQuZGF0YS5pZCwgbmFtZTogcmVzdWx0LmRhdGEubmFtZSwgdGltZXpvbmU6IHJlc3VsdC5kYXRhLnRpbWV6b25lLCBsb2NhbGU6IHJlc3VsdC5kYXRhLmxvY2FsZSB9O1xuICAgICAgICAgICAgYmFzZWxpbmUuY3VycmVudCA9IHBlcnNpc3RlZDtcbiAgICAgICAgICAgIGRyYWZ0LmN1cnJlbnQgPSBwZXJzaXN0ZWQ7XG4gICAgICAgICAgICBzZXROYW1lKHBlcnNpc3RlZC5uYW1lKTtcbiAgICAgICAgICAgIHNldFRpbWV6b25lKHBlcnNpc3RlZC50aW1lem9uZSk7XG4gICAgICAgICAgICBzZXRMb2NhbGUocGVyc2lzdGVkLmxvY2FsZSk7XG4gICAgICAgICAgICBtYXJrRHJhZnRDbGVhbihmb3JtKTtcbiAgICAgICAgICAgIHNldFNhdmVkKHRydWUpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgbMawdSDEkcaw4bujYyBj4bqldSBow6xuaCcpKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiVGhp4bq/dCBs4bqtcCBj4butYSBow6BuZ1wiIHN1YnRpdGxlPVwiQ+G6pXUgaMOsbmggcmnDqm5nIGPhu6dhIHNob3Aga2jDtG5nIHRoYXkgxJHhu5VpIHF1eSB04bqvYyBBSSBs4bqtcCB0csOsbmggaG/hurdjIG3DoHUgxJHDoyBkdXnhu4d0LlwiIC8+XG4gICAgICAgIDxTdGFjayBnYXA9ezN9PlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiVGjDtG5nIHRpbiBjxqEgc+G7n1wiPlxuICAgICAgICAgICAgICAgIDxTdGFjayBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtmb3JtUmVmfSBub1ZhbGlkYXRlIG9uU3VibWl0PXtldmVudCA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHZvaWQgc2F2ZShldmVudC5jdXJyZW50VGFyZ2V0KTsgfX0gZ2FwPXsyLjV9IHN4PXt7IHA6IDMsIG1heFdpZHRoOiA3NjAgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3IgfHwgdXBkYXRlLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICB7c2F2ZWQgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIj7EkMOjIGzGsHUgY+G6pXUgaMOsbmggY+G7rWEgaMOgbmcuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJUw6puIGPhu61hIGjDoG5nXCIgdmFsdWU9e25hbWV9IGRpc2FibGVkPXshY2FuTWFuYWdlU2hvcH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0TmFtZShldmVudC50YXJnZXQudmFsdWUpOyB1cGRhdGVGaWVsZCgnbmFtZScsIGV2ZW50LnRhcmdldC52YWx1ZSk7IH19IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJUaeG7gW4gdOG7hyBjxqEgc+G7n1wiIHZhbHVlPXtzaG9wLmN1cnJlbmN5fSBkaXNhYmxlZCBoZWxwZXJUZXh0PVwiS2jDtG5nIMSR4buVaSB0aeG7gW4gdOG7hyBi4bqxbmcgc+G7rWEgZ2lhbyBkaeG7h24uIEPhuqduIGvhur8gaG/huqFjaCBjaHV54buDbiDEkeG7lWkgZOG7ryBsaeG7h3UuXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk3DumkgZ2nhu51cIiB2YWx1ZT17dGltZXpvbmV9IGRpc2FibGVkPXshY2FuTWFuYWdlU2hvcH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0VGltZXpvbmUoZXZlbnQudGFyZ2V0LnZhbHVlKTsgdXBkYXRlRmllbGQoJ3RpbWV6b25lJywgZXZlbnQudGFyZ2V0LnZhbHVlKTsgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5nw7RuIG5n4buvXCIgdmFsdWU9e2xvY2FsZX0gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VTaG9wfSBvbkNoYW5nZT17ZXZlbnQgPT4geyBzZXRMb2NhbGUoZXZlbnQudGFyZ2V0LnZhbHVlKTsgdXBkYXRlRmllbGQoJ2xvY2FsZScsIGV2ZW50LnRhcmdldC52YWx1ZSk7IH19IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJHaWFvIGRp4buHblwiIHZhbHVlPVwiR3JhcGhpdGUgR29sZCDCtyBEYXJrLW9ubHlcIiBkaXNhYmxlZCAvPlxuICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInNob3AubWFuYWdlXCIgdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXt1cGRhdGUucGVuZGluZ30gZGlzYWJsZWQ9eyFuYW1lLnRyaW0oKSB8fCAhdGltZXpvbmV9PkzGsHUgY+G6pXUgaMOsbmg8L011dGF0aW9uQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiQ2hlY2tsaXN0IHRoaeG6v3QgbOG6rXAgduG6rW4gaMOgbmhcIiBzdWJ0aXRsZT1cIkPDoWMgbeG7pWMga2jDtG5nIGPDsyB0csaw4budbmcgQVBJIMSRxrDhu6NjIGdp4buvIOG7nyB0cuG6oW5nIHRow6FpIGNoxrBhIHjDoWMgbWluaDsga2jDtG5nIHN1eSBkaeG7hW4gxJHDoyBz4bq1biBzw6BuZy5cIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgZ2FwPXsxfSBzeD17eyBwOiAzIH19PlxuICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e19fTU9DS19fID8gJ0LhuqNuIHhlbSB0csaw4bubYyBtw7QgcGjhu49uZy4gQ2jhu4kgdMOqbiwgdGnhu4FuIHThu4csIG3DumkgZ2nhu50gdsOgIG5nw7RuIG5n4buvIMSRxrDhu6NjIGzGsHUgcXVhIEFQSSBoaeG7h24gdOG6oWkuJyA6ICdBUEkgaGnhu4duIGNo4buJIGNobyBwaMOpcCBz4butYSB0aMO0bmcgdGluIGPGoSBz4bufIMSRxrDhu6NjIGjhu5cgdHLhu6MuJ30gUXXhu5FjIGdpYSBraW5oIGRvYW5oIGtow7RuZyDEkcaw4bujYyBzdXkgcmEgdOG7qyBtw7ppIGdp4budLjwvQWxlcnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJRdeG7kWMgZ2lhIHbDoCBnaeG7nSBraW5oIGRvYW5oXCIgc3RhdHVzPVwiQ2jGsGEgY8OzIHRyxrDhu51uZyBj4bqldSBow6xuaCB0cm9uZyBjb250cmFjdFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCLEkOG7i2EgY2jhu4ksIHbDuW5nIGdpYW8gdsOgIHBow60gduG6rW4gY2h1eeG7g25cIiBzdGF0dXM9e19fTU9DS19fID8gJ0PDsyBwcmV2aWV3IG3DtCBwaOG7j25nLCBjaMawYSBsxrB1IGPhuqV1IGjDrG5oJyA6ICdDaMawYSBjw7Mgb3BlcmF0aW9uIGPhuqV1IGjDrG5oIHbDuW5nIGdpYW8nfSB0bz17YC9zLyR7c2hvcC5pZH0vc2hpcG1lbnRzYH0gYWN0aW9uPVwiWGVtIHByZXZpZXcgcGjDrSBnaWFvXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIk5nxrDhu51pIGR1eeG7h3QgdsOgIHRow6BuaCB2acOqblwiIHN0YXR1cz1cIlF1eeG7gW4gbOG6pXkgdOG7qyBtZW1iZXJzaGlwOyBjaMawYSBjw7MgQVBJIGfDoW4gY2jDrW5oIHPDoWNoIGR1eeG7h3RcIiB0bz17YC9zLyR7c2hvcC5pZH0vc2V0dGluZ3MvdGVhbWB9IGFjdGlvbj1cIlF14bqjbiBsw70gdGjDoG5oIHZpw6puXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIkvhur90IG7hu5FpIGvDqm5oIGLDoW4gaMOgbmdcIiBzdGF0dXM9e19fTU9DS19fID8gJ0vhur90IG7hu5FpIG3DtCBwaOG7j25nOyBraMO0bmcgY8OzIHF1eeG7gW4gcHJvdmlkZXIgdGjhuq10JyA6ICdLaeG7g20gdHJhIHRy4bqhbmcgdGjDoWkga+G6v3QgbuG7kWknfSB0bz17YC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2NoYW5uZWxzYH0gYWN0aW9uPVwiTeG7nyBr4bq/dCBu4buRaVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJL4bq/dCBu4buRaSBBSVwiIHN0YXR1cz17X19NT0NLX18gPyAnQ2F0YWxvZyBuaMOgIGN1bmcgY+G6pXAgbcO0IHBo4buPbmcnIDogJ0tp4buDbSB0cmEgY2F0YWxvZyBuaMOgIGN1bmcgY+G6pXAnfSB0bz17YC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2FpYH0gYWN0aW9uPVwiTeG7nyBuaMOgIGN1bmcgY+G6pXAgQUlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiTuG7mWkgZHVuZyBz4bqjbiBwaOG6qW0gdsOgIHBoacOqbiBi4bqjbiBraeG6v24gdGjhu6ljXCIgc3RhdHVzPVwiTmd14buTbiBu4buZaSBkdW5nLCBs4buLY2ggc+G7rSBwaGnDqm4gYuG6o24gdsOgIGR1eeG7h3QgbuG6sW0gdHJvbmcga2h1IHbhu7FjIGtp4bq/biB0aOG7qWMuXCIgdG89e2Avcy8ke3Nob3AuaWR9L2tub3dsZWRnZWB9IGFjdGlvbj1cIlF14bqjbiBsw70gbuG7mWkgZHVuZ1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJWw7JuZyBnw7NwIMO9IGPDsyBkdXnhu4d0XCIgc3RhdHVzPVwiR8OzcCDDvSB04bqhbyBi4bqjbiBuaMOhcDsga2jDtG5nIHThu7EgaHXhuqVuIGx1eeG7h24gaG/hurdjIHh14bqldCBi4bqjbi5cIiB0bz17YC9zLyR7c2hvcC5pZH0va25vd2xlZGdlL2ZlZWRiYWNrYH0gYWN0aW9uPVwiRHV54buHdCBnw7NwIMO9XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIkNvbnNlbnQgdsOgIG5n4burbmcgbGnDqm4gaOG7hyBtYXJrZXRpbmdcIiBzdGF0dXM9XCJDw7MgcHJldmlldyB0xrDGoW5nIHTDoWM7IGNvbnRyYWN0IGNoxrBhIGPDsyB0csaw4budbmcgY29uc2VudCBob+G6t2MgdGhhbyB0w6FjIG9wdC1vdXQuXCIgdG89e2Avcy8ke3Nob3AuaWR9L3NldHRpbmdzL3ByaXZhY3lgfSBhY3Rpb249XCJYZW0gdGjhu60gY29uc2VudFwiIC8+XG4gICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgIDwvU3RhY2s+XG4gICAgPC8+O1xufVxuZnVuY3Rpb24gU2V0dXBDaGVja2xpc3RJdGVtKHsgdGl0bGUsIHN0YXR1cywgdG8sIGFjdGlvbiB9OiB7IHRpdGxlOiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyB0bz86IHN0cmluZzsgYWN0aW9uPzogc3RyaW5nIH0pIHtcbiAgICByZXR1cm4gPEJveCBzeD17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6IHsgeHM6ICdmbGV4LXN0YXJ0JywgbWQ6ICdjZW50ZXInIH0sIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGdhcDogMiwgcDogMS41LCBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogMSwgZmxleFdyYXA6ICd3cmFwJyB9fT5cbiAgICAgICAgPEJveD48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXs2NTB9Pnt0aXRsZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPntzdGF0dXN9PC9UeXBvZ3JhcGh5PjwvQm94PlxuICAgICAgICB7dG8gJiYgYWN0aW9uICYmIDxSb3V0ZUxpbmsgdG89e3RvfT57YWN0aW9ufTwvUm91dGVMaW5rPn1cbiAgICA8L0JveD47XG59XG5jb25zdCByb2xlTGFiZWxzOiBSZWNvcmQ8Um9sZSwgc3RyaW5nPiA9IHtcbiAgICBvd25lcjogJ0No4bunIGPhu61hIGjDoG5nJywgbWFuYWdlcjogJ1F14bqjbiBsw70nLCBzYWxlczogJ0LDoW4gaMOgbmcnLCB3YXJlaG91c2U6ICdOaMOibiB2acOqbiBraG8nLCBhY2NvdW50YW50OiAnS+G6vyB0b8OhbicsIGJvdF9hZG1pbjogJ1F14bqjbiB0cuG7iyBBSScsIHZpZXdlcjogJ0No4buJIHhlbSdcbn07XG5leHBvcnQgZnVuY3Rpb24gVGVhbVBhZ2UoKSB7XG4gICAgY29uc3QgeyBzZXNzaW9uIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RNZW1iZXJzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCkgfSk7XG4gICAgY29uc3QgaW52aXRlID0gdXNlQ29tbWFuZCgnaW52aXRlTWVtYmVyJywgWydsaXN0TWVtYmVycyddKTtcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVNZW1iZXJSb2xlcycsIFsnbGlzdE1lbWJlcnMnXSk7XG4gICAgY29uc3QgcmV2b2tlID0gdXNlQ29tbWFuZCgncmV2b2tlTWVtYmVyc2hpcCcsIFsnbGlzdE1lbWJlcnMnXSk7XG4gICAgY29uc3QgW2VkaXQsIHNldEVkaXRdID0gdXNlU3RhdGU8TWVtYmVyc2hpcCB8IG51bGwgfCB1bmRlZmluZWQ+KCksIFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpLCBbcm9sZXMsIHNldFJvbGVzXSA9IHVzZVN0YXRlPFJvbGVbXT4oWyd2aWV3ZXInXSksIFtyZW1vdmUsIHNldFJlbW92ZV0gPSB1c2VTdGF0ZTxNZW1iZXJzaGlwIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3Qgb3BlbiA9IChtOiBNZW1iZXJzaGlwIHwgbnVsbCkgPT4geyBzZXRFZGl0KG0pOyBzZXRFbWFpbCgnJyk7IHNldFJvbGVzKG0/LnJvbGVzIHx8IFsndmlld2VyJ10pOyB9O1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiTmjDom4gc+G7sSAmIHBow6JuIHF1eeG7gW5cIiBzdWJ0aXRsZT1cIlZhaSB0csOyIGzDoCBi4buZIHF1eeG7gW4gbeG6t2MgxJHhu4tuaDsgQVBJIHF1eeG6v3QgxJHhu4tuaCBxdXnhu4FuIGhp4buHdSBs4buxYyDhu58gdOG7q25nIHRoYW8gdMOhYy5cIiBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm1lbWJlcnMubWFuYWdlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IG9wZW4obnVsbCl9Pk3hu51pIG5ow6JuIHZpw6puPC9NdXRhdGlvbkJ1dHRvbj59Lz48UGFuZWw+PFRvb2xiYXIgLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17bSA9PiBtLmlkfSBjb2x1bW5zPXtbXG4gICAgICAgIHsga2V5OiAndXNlcicsIGxhYmVsOiAnTmjDom4gdmnDqm4nLCByZW5kZXI6IG0gPT4gbS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/IHNlc3Npb24udXNlci5kaXNwbGF5TmFtZSA6IG0udXNlcklkIH0sIHsga2V5OiAncm9sZXMnLCBsYWJlbDogJ1ZhaSB0csOyJywgcmVuZGVyOiBtID0+IG0ucm9sZXMubWFwKHIgPT4gcm9sZUxhYmVsc1tyXSkuam9pbignLCAnKSB9LCB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogbSA9PiA8U3RhdHVzIHZhbHVlPXttLnN0YXR1c30vPiB9LCB7IGtleTogJ3Blcm1zJywgbGFiZWw6ICdRdXnhu4FuIGhp4buHdSBs4buxYycsIHJlbmRlcjogbSA9PiBgJHttLnBlcm1pc3Npb25zLmxlbmd0aH0gcXV54buBbiDCtyB2JHttLnBlcm1pc3Npb25WZXJzaW9ufWAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAga2V5OiAnYWN0aW9ucycsIGxhYmVsOiAnJywgcmVuZGVyOiBtID0+IDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm1lbWJlcnMubWFuYWdlXCIgb25DbGljaz17KCkgPT4gb3BlbihtKX0+U+G7rWEgcXV54buBbjwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJtZW1iZXJzLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBkaXNhYmxlZD17bS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCB8fCBtLnN0YXR1cyA9PT0gJ3Jldm9rZWQnfSBvbkNsaWNrPXsoKSA9PiBzZXRSZW1vdmUobSl9PlRodSBo4buTaTwvTXV0YXRpb25CdXR0b24+PC9TdGFjaz5cbiAgICAgICAgfVxuICAgIF19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+XG4gPEVkaXREaWFsb2cgb3Blbj17ZWRpdCAhPT0gdW5kZWZpbmVkfSB0aXRsZT17ZWRpdCA/ICdD4bqtcCBuaOG6rXQgcXV54buBbicgOiAnTeG7nWkgbmjDom4gdmnDqm4nfSBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0KHVuZGVmaW5lZCl9IGJ1c3k9e2ludml0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IXJvbGVzLmxlbmd0aCB8fCAoIWVkaXQgJiYgIS9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QoZW1haWwpKSB8fCBpbnZpdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBpZiAoZWRpdClcbiAgICAgICAgICAgIGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyBtZW1iZXJJZDogZWRpdC5pZCB9LCB2ZXJzaW9uOiBlZGl0LnBlcm1pc3Npb25WZXJzaW9uLCBib2R5OiB7IHJvbGVzIH0gfSk7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIGF3YWl0IGludml0ZS5leGVjdXRlKHsgYm9keTogeyBlbWFpbCwgcm9sZXMgfSB9KTtcbiAgICAgICAgc2V0RWRpdCh1bmRlZmluZWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5MxrB1PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2ludml0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz48U3RhY2sgZ2FwPXsxLjV9PnshZWRpdCAmJiA8VGV4dEZpZWxkIGxhYmVsPVwiRW1haWwgbmjDom4gdmnDqm5cIiB0eXBlPVwiZW1haWxcIiB2YWx1ZT17ZW1haWx9IG9uQ2hhbmdlPXtlID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX0vPn08VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUyXCI+UGjDom4gdmFpIHRyw7I8L1R5cG9ncmFwaHk+eyhPYmplY3Qua2V5cyhyb2xlTGFiZWxzKSBhcyBSb2xlW10pLm1hcChyb2xlID0+IDxGb3JtQ29udHJvbExhYmVsIGtleT17cm9sZX0gbGFiZWw9e2Ake3JvbGVMYWJlbHNbcm9sZV19IMK3ICR7cGVybWlzc2lvbkNhdGFsb2cucm9sZVByZXNldHNbcm9sZV0/Lmxlbmd0aCB8fCAwfSBxdXnhu4FuYH0gY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e3JvbGVzLmluY2x1ZGVzKHJvbGUpfSBvbkNoYW5nZT17ZSA9PiBzZXRSb2xlcyhlLnRhcmdldC5jaGVja2VkID8gWy4uLnJvbGVzLCByb2xlXSA6IHJvbGVzLmZpbHRlcihyID0+IHIgIT09IHJvbGUpKX0vPn0vPil9PEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlF1eeG7gW4gbeG7m2kgcGjhuqNpIMSRxrDhu6NjIG3DoXkgY2jhu6cga2nhu4NtIGzhuqFpLiBUaHUgaOG7k2kgcXV54buBbiBsw6BtIG3huqV0IGhp4buHdSBs4buxYyBjYWNoZSB2w6AgcGhpw6puIHRydXkgY+G6rXAgbGnDqm4gcXVhbi48L0FsZXJ0PjwvU3RhY2s+PC9FZGl0RGlhbG9nPjxDb25maXJtRGlhbG9nIG9wZW49eyEhcmVtb3ZlfSB0aXRsZT1cIlRodSBo4buTaSBxdXnhu4FuIG5ow6JuIHZpw6puXCIgZGVzY3JpcHRpb249XCJOZ8aw4budaSBuw6B5IGtow7RuZyDEkcaw4bujYyB0aeG6v3AgdOG7pWMgZMO5bmcgZOG7ryBsaeG7h3UgY+G7p2Egc2hvcCBzYXUga2hpIHF1eeG7gW4gxJHGsOG7o2MgdGh1IGjhu5NpLlwiIG9uQ2xvc2U9eygpID0+IHNldFJlbW92ZShudWxsKX0gYnVzeT17cmV2b2tlLnBlbmRpbmd9IGVycm9yPXtyZXZva2UuZXJyb3J9IG9uQ29uZmlybT17YXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXJlbW92ZSkgcmV0dXJuO1xuICAgICAgICBhd2FpdCByZXZva2UuZXhlY3V0ZSh7IHBhdGg6IHsgbWVtYmVySWQ6IHJlbW92ZS5pZCB9LCB2ZXJzaW9uOiByZW1vdmUucGVybWlzc2lvblZlcnNpb24gfSk7XG4gICAgfX0vPjwvPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBBdWRpdFBhZ2UoKSB7IGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTsgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdEF1ZGl0RXZlbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCkgfSk7IHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiTmjhuq10IGvDvSBob+G6oXQgxJHhu5luZ1wiIHN1YnRpdGxlPVwiQWkgdGjhu7FjIGhp4buHbiwgdGhhbyB0w6FjIG7DoG8sIGThu68gbGnhu4d1IG7DoG8gdsOgIG3DoyB0cnV5IHbhur90LiBLaMO0bmcgbMawdSBBUEkga2V5IGhv4bq3YyBzdXkgbHXhuq1uIHJpw6puZyBj4bunYSBBSS5cIi8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHN4PXt7IG1iOiAyIH19PkFQSSBoaeG7h24gdHLhuqMgduG7gSBuZ8aw4budaSB0aOG7sWMgaGnhu4duLCB0aGFvIHTDoWMsIMSR4buRaSB0xrDhu6NuZywgdGjhu51pIGdpYW4sIG3DoyB0cnV5IHbhur90IHbDoCB0w7NtIHThuq90LiBMb+G6oWkgYWN0b3IsIHBoacOqbiBi4bqjbiBwb2xpY3kvY29uZmlnIHbDoCBzbmFwc2hvdCBjaGkgdGnhur90IGNoxrBhIGPDsyB0cm9uZyBEVE8gbsOqbiBraMO0bmcgxJHGsOG7o2Mgc3V5IMSRb8Ohbi48L0FsZXJ0PjxQYW5lbD48VG9vbGJhciAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fT57bGlzdC5kYXRhICYmIDw+PERhdGFUYWJsZSByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXthID0+IGEuaWR9IGNvbHVtbnM9e1tcbiAgICB7IGtleTogJ3RpbWUnLCBsYWJlbDogJ1Ro4budaSBnaWFuJywgcmVuZGVyOiBhID0+IGRhdGVUaW1lKGEub2NjdXJyZWRBdCwgc2hvcC50aW1lem9uZSkgfSwgeyBrZXk6ICdhY3RvcicsIGxhYmVsOiAnTmfGsOG7nWkgdGjhu7FjIGhp4buHbicsIHJlbmRlcjogYSA9PiBhLmFjdG9ySWQgfSwgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJ1RoYW8gdMOhYycsIHJlbmRlcjogYSA9PiBhLmFjdGlvbiB9LCB7IGtleTogJ3NvdXJjZScsIGxhYmVsOiAnxJDhu5FpIHTGsOG7o25nJywgcmVuZGVyOiBhID0+IGAke2EucmVzb3VyY2UudHlwZX0gwrcgJHthLnJlc291cmNlLmlkfWAgfSwgeyBrZXk6ICdzdW1tYXJ5JywgbGFiZWw6ICdL4bq/dCBxdeG6oycsIHJlbmRlcjogYSA9PiBhLnN1bW1hcnkgfSwgeyBrZXk6ICd0cmFjZScsIGxhYmVsOiAnTcOjIHRydXkgduG6v3QnLCByZW5kZXI6IGEgPT4gPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57YS5yZXF1ZXN0SWR9PC9UeXBvZ3JhcGh5PiB9XG5dfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPjwvPjsgfVxuZXhwb3J0IGZ1bmN0aW9uIFByaXZhY3lQYWdlKCkge1xuICAgIGNvbnN0IHBvbGljeSA9IHVzZUFwaSgnZ2V0UHJpdmFjeVBvbGljeScpO1xuICAgIGNvbnN0IHJlcXVlc3RzID0gdXNlQXBpKCdsaXN0UHJpdmFjeVJlcXVlc3RzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCkgfSk7XG4gICAgY29uc3Qgc2F2ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZVByaXZhY3lQb2xpY3knLCBbJ2dldFByaXZhY3lQb2xpY3knXSk7XG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUHJpdmFjeVJlcXVlc3QnLCBbJ2xpc3RQcml2YWN5UmVxdWVzdHMnXSk7XG4gICAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoJycpLCBbbm90ZSwgc2V0Tm90ZV0gPSB1c2VTdGF0ZSgnJyksIFtjdXN0b21lcklkLCBzZXRDdXN0b21lcl0gPSB1c2VTdGF0ZSgnJyksIFtraW5kLCBzZXRLaW5kXSA9IHVzZVN0YXRlPCdleHBvcnQnIHwgJ2RlbGV0ZSc+KCdleHBvcnQnKSwgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKCcnKSwgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGNhblJlYWRDdXN0b21lcnMgPSB1c2VDYW4oJ2N1c3RvbWVycy5yZWFkJyk7XG4gICAgY29uc3QgY3VzdG9tZXJzID0gdXNlQXBpKCdsaXN0Q3VzdG9tZXJzJywgeyBxdWVyeTogeyBsaW1pdDogMTAwIH0gfSwgY2FuUmVhZEN1c3RvbWVycyk7XG4gICAgdXNlRWZmZWN0KCgpID0+IHsgaWYgKHBvbGljeS5kYXRhKSB7XG4gICAgICAgIHNldERheXMocG9saWN5LmRhdGEuZGF0YS5jaGF0UmV0ZW50aW9uRGF5cz8udG9TdHJpbmcoKSB8fCAnJyk7XG4gICAgICAgIHNldE5vdGUocG9saWN5LmRhdGEuZGF0YS5qdXJpc2RpY3Rpb25Ob3RlKTtcbiAgICB9IH0sIFtwb2xpY3kuZGF0YV0pO1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiUXV54buBbiByacOqbmcgdMawICYgdsOybmcgxJHhu51pIGThu68gbGnhu4d1XCIgc3VidGl0bGU9XCJUw6FjaCBj4bqldSBow6xuaCBuaMOhcCB24bubaSBjaMOtbmggc8OhY2ggxJHGsOG7o2MgZHV54buHdDsgecOqdSBj4bqndSB4w7NhIGtow7RuZyB04buxIHbGsOG7o3QgxJFp4buBdSBraeG7h24gbMawdSBjaOG7qW5nIHThu6suXCIvPjxCb3ggc3g9e3sgZGlzcGxheTogJ2dyaWQnLCBncmlkVGVtcGxhdGVDb2x1bW5zOiB7IHhzOiAnMWZyJywgbGc6ICcxZnIgMS40ZnInIH0sIGdhcDogMyB9fT48UGFuZWwgdGl0bGU9XCJDaMOtbmggc8OhY2ggbMawdSB0cuG7r1wiPjxRdWVyeVN0YXRlIHF1ZXJ5PXtwb2xpY3l9PjxTdGFjayBnYXA9ezJ9IHN4PXt7IHA6IDMgfX0+PEVycm9yTm90aWNlIGVycm9yPXtzYXZlLmVycm9yfS8+e3BvbGljeS5kYXRhICYmIDxTdGF0dXMgdmFsdWU9e3BvbGljeS5kYXRhLmRhdGEuc3RhdHVzfS8+fTxUZXh0RmllbGQgbGFiZWw9XCJT4buRIG5nw6B5IGzGsHUgaOG7mWkgdGhv4bqhaVwiIHZhbHVlPXtkYXlzfSBvbkNoYW5nZT17ZSA9PiBzZXREYXlzKGUudGFyZ2V0LnZhbHVlKX0gdHlwZT1cIm51bWJlclwiIGlucHV0UHJvcHM9e3sgbWluOiAxLCBtYXg6IDM2NTAwIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiQ8SDbiBj4bupIC8gdGjhu4sgdHLGsOG7nW5nIMOhcCBk4bulbmdcIiBtdWx0aWxpbmUgbWluUm93cz17NH0gdmFsdWU9e25vdGV9IG9uQ2hhbmdlPXtlID0+IHNldE5vdGUoZS50YXJnZXQudmFsdWUpfS8+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcml2YWN5Lm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtzYXZlLnBlbmRpbmd9IGRpc2FibGVkPXshcG9saWN5LmRhdGEgfHwgIWRheXMgfHwgTnVtYmVyKGRheXMpIDwgMSB8fCBub3RlLnRyaW0oKS5sZW5ndGggPCA1fSBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSBwb2xpY3kuZGF0YT8uZGF0YTtcbiAgICAgICAgaWYgKCFjdXJyZW50KSByZXR1cm47XG4gICAgICAgIHZvaWQgc2F2ZS5leGVjdXRlKHsgdmVyc2lvbjogY3VycmVudC52ZXJzaW9uLCBib2R5OiB7IGNoYXRSZXRlbnRpb25EYXlzOiBOdW1iZXIoZGF5cyksIGp1cmlzZGljdGlvbk5vdGU6IG5vdGUgfSB9KS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgIH19PkzGsHUgYuG6o24gbmjDoXAgY2jDrW5oIHPDoWNoPC9NdXRhdGlvbkJ1dHRvbj48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+S2jDtG5nIHThu7EgY2jhu6luZyBuaOG6rW4gdHXDom4gdGjhu6cgcGjDoXAgbHXhuq10LiBQaMOqIGR1eeG7h3QgecOqdSBj4bqndSB4w7NhIGPhuqduIHjDoWMgdGjhu7FjIG7Dom5nIGNhbyBj4bunYSBiYWNrZW5kOyBsdeG7k25nIE9JREMgc3RlcC11cCBjaMawYSDEkcaw4bujYyB4w6FjIG1pbmggdHJvbmcgZnJvbnRlbmQgbsOgeS48L0FsZXJ0PjwvU3RhY2s+PC9RdWVyeVN0YXRlPjwvUGFuZWw+PFBhbmVsIHRpdGxlPVwiWcOqdSBj4bqndSBj4bunYSBraMOhY2hcIiBhY3Rpb249ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJpdmFjeS5tYW5hZ2VcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5U4bqhbyB5w6p1IGPhuqd1PC9NdXRhdGlvbkJ1dHRvbj59PjxRdWVyeVN0YXRlIHF1ZXJ5PXtyZXF1ZXN0c30+e3JlcXVlc3RzLmRhdGEgJiYgPD48RGF0YVRhYmxlIHJvd3M9e3JlcXVlc3RzLmRhdGEuZGF0YX0gcm93S2V5PXtyID0+IHIuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiByID0+IHIuY3VzdG9tZXJJZCB9LCB7IGtleTogJ2tpbmQnLCBsYWJlbDogJ1nDqnUgY+G6p3UnLCByZW5kZXI6IHIgPT4gPFN0YXR1cyB2YWx1ZT17ci5raW5kfS8+IH0sIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IHIgPT4gPFN0YXR1cyB2YWx1ZT17ci5zdGF0dXN9Lz4gfSwgeyBrZXk6ICdyZWFzb24nLCBsYWJlbDogJ0zDvSBkbycsIHJlbmRlcjogciA9PiByLnJlYXNvbiB9XG4gICAgXX0vPjxQYWdlciBwYWdlPXtyZXF1ZXN0cy5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PC9Cb3g+PENvbnRhY3RDb25zZW50UHJldmlldyBjdXN0b21lcnM9e2N1c3RvbWVycy5kYXRhPy5kYXRhIHx8IFtdfSBjYW5SZWFkQ3VzdG9tZXJzPXtjYW5SZWFkQ3VzdG9tZXJzfSAvPlxuIDxFZGl0RGlhbG9nIG9wZW49e29wZW59IHRpdGxlPVwiWcOqdSBj4bqndSBk4buvIGxp4buHdSBjw6EgbmjDom5cIiBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gYnVzeT17Y3JlYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshY3VzdG9tZXJJZCB8fCByZWFzb24udHJpbSgpLmxlbmd0aCA8IDUgfHwgY3JlYXRlLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IGtpbmQsIGN1c3RvbWVySWQsIHJlYXNvbiB9IH0pO1xuICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICB9XG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+VOG6oW8gecOqdSBj4bqndSBjaOG7nSBkdXnhu4d0PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0vPjxTdGFjayBnYXA9ezJ9PjxUZXh0RmllbGQgbGFiZWw9XCJLaMOhY2ggaMOgbmdcIiBzZWxlY3QgdmFsdWU9e2N1c3RvbWVySWR9IG9uQ2hhbmdlPXtlID0+IHNldEN1c3RvbWVyKGUudGFyZ2V0LnZhbHVlKX0+e2N1c3RvbWVycy5kYXRhPy5kYXRhLm1hcChjID0+IDxNZW51SXRlbSBrZXk9e2MuaWR9IHZhbHVlPXtjLmlkfT57Yy5kaXNwbGF5TmFtZX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PFRleHRGaWVsZCBsYWJlbD1cIkxv4bqhaSB5w6p1IGPhuqd1XCIgc2VsZWN0IHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZSA9PiBzZXRLaW5kKGUudGFyZ2V0LnZhbHVlIGFzIHR5cGVvZiBraW5kKX0+PE1lbnVJdGVtIHZhbHVlPVwiZXhwb3J0XCI+WHXhuqV0IGThu68gbGnhu4d1IGPDoSBuaMOibjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiZGVsZXRlXCI+WMOzYSBk4buvIGxp4buHdSBjw6EgbmjDom48L01lbnVJdGVtPjwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gLyB4w6FjIG1pbmggecOqdSBj4bqndVwiIG11bHRpbGluZSBtaW5Sb3dzPXszfSB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfS8+PC9TdGFjaz48L0VkaXREaWFsb2c+PC8+O1xufVxudHlwZSBDb25zZW50UHJldmlld0N1c3RvbWVyID0geyBpZDogc3RyaW5nOyBkaXNwbGF5TmFtZTogc3RyaW5nIH07XG5mdW5jdGlvbiBDb250YWN0Q29uc2VudFByZXZpZXcoeyBjdXN0b21lcnMsIGNhblJlYWRDdXN0b21lcnMgfTogeyBjdXN0b21lcnM6IENvbnNlbnRQcmV2aWV3Q3VzdG9tZXJbXTsgY2FuUmVhZEN1c3RvbWVyczogYm9vbGVhbiB9KSB7XG4gICAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJJZCwgc2V0U2VsZWN0ZWRDdXN0b21lcklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbb3B0T3V0SWRzLCBzZXRPcHRPdXRJZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgICBjb25zdCBjdXN0b21lcklkID0gY3VzdG9tZXJzLnNvbWUoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IHNlbGVjdGVkQ3VzdG9tZXJJZCkgPyBzZWxlY3RlZEN1c3RvbWVySWQgOiBjdXN0b21lcnNbMF0/LmlkIHx8ICcnO1xuICAgIGNvbnN0IGN1c3RvbWVyID0gY3VzdG9tZXJzLmZpbmQoY2FuZGlkYXRlID0+IGNhbmRpZGF0ZS5pZCA9PT0gY3VzdG9tZXJJZCk7XG4gICAgY29uc3Qgb3B0ZWRPdXQgPSBvcHRPdXRJZHMuaW5jbHVkZXMoY3VzdG9tZXJJZCk7XG4gICAgcmV0dXJuIDxQYW5lbCB0aXRsZT1cIlhlbSB0aOG7rSBjb25zZW50IG1hcmtldGluZ1wiIHN4PXt7IG10OiAzIH19PlxuICAgICAgICA8U3RhY2sgZ2FwPXsyfSBzeD17eyBwOiAzIH19PlxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkThu68gbGnhu4d1IHThu5VuZyBo4bujcCBjaOG7iSBkw7luZyDEkeG7gyB4ZW0gdMawxqFuZyB0w6FjIFVJLiBDb250cmFjdCBDdXN0b21lciBjaMawYSBjw7MgdHLGsOG7nW5nIGNvbnNlbnQgdsOgIEFQSSBjaMawYSBjw7MgdGhhbyB0w6FjIG9wdC1vdXQ7IGzhu7FhIGNo4buNbiDhu58gxJHDonkga2jDtG5nIGfhu61pIHThu5tpIGJhY2tlbmQgaG/hurdjIGNo4bq3biBjaGnhur9uIGThu4tjaCB0aOG6rXQuPC9BbGVydD5cbiAgICAgICAgICAgIHtjYW5SZWFkQ3VzdG9tZXJzID8gPD5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIktow6FjaCBt4bqrdVwiIHZhbHVlPXtjdXN0b21lcklkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcklkKGV2ZW50LnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY3VzdG9tZXJ9PlxuICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcChpdGVtID0+IDxNZW51SXRlbSBrZXk9e2l0ZW0uaWR9IHZhbHVlPXtpdGVtLmlkfT57aXRlbS5kaXNwbGF5TmFtZX08L01lbnVJdGVtPil9XG4gICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgPEZvcm1Db250cm9sTGFiZWwgbGFiZWw9XCJOZ+G7q25nIGxpw6puIGjhu4cgbWFya2V0aW5nIChjaOG7iSBi4bqjbiB4ZW0gdHLGsOG7m2MpXCIgY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e29wdGVkT3V0fSBkaXNhYmxlZD17IWN1c3RvbWVyfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0T3B0T3V0SWRzKGN1cnJlbnQgPT4gZXZlbnQudGFyZ2V0LmNoZWNrZWQgPyBbLi4ubmV3IFNldChbLi4uY3VycmVudCwgY3VzdG9tZXJJZF0pXSA6IGN1cnJlbnQuZmlsdGVyKGlkID0+IGlkICE9PSBjdXN0b21lcklkKSl9IC8+fSAvPlxuICAgICAgICAgICAgICAgIHtjdXN0b21lciAmJiA8Qm94IHJvbGU9XCJzdGF0dXNcIiBkYXRhLXRlc3RpZD1cImNvbnNlbnQtcHJldmlldy1zdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLaMOhY2ggbeG6q3VcIj57Y3VzdG9tZXIuZGlzcGxheU5hbWV9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkThu4tjaCB24bulXCI+Q2jGsGEgY8OzIHRyxrDhu51uZyBjb25zZW50IHRyb25nIGNvbnRyYWN0PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk1hcmtldGluZ1wiPntvcHRlZE91dCA/ICdPcHQtb3V0IG3DtCBwaOG7j25nOyBjaMawYSBnaGkgc2VydmVyJyA6ICdDaMawYSB4w6FjIG1pbmggdOG7qyBBUEknfTwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXt7IG10OiAxIH19PlPhu5Ega2jDoWNoIG9wdC1vdXQgdHJvbmcgcHJldmlldzoge29wdE91dElkcy5sZW5ndGh9LiBLaMO0bmcga2jhurNuZyDEkeG7i25oIMSRw6MgbOG7jWMgam9iIMSRYW5nIGNo4budIGhv4bq3YyBk4buvIGxp4buHdSBraMO0aSBwaOG7pWMuPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIDwvQm94Pn1cbiAgICAgICAgICAgICAgICB7IWN1c3RvbWVyICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5DaMawYSBjw7Mga2jDoWNoIG3huqt1IHRyb25nIHRyYW5nIEFQSSBoaeG7h24gdOG6oWkuPC9BbGVydD59XG4gICAgICAgICAgICA8Lz4gOiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VmFpIHRyw7IgaGnhu4duIHThuqFpIGtow7RuZyBjw7MgY3VzdG9tZXJzLnJlYWQ7IGtow6FjaCBt4bqrdSB2w6AgbOG7sWEgY2jhu41uIGNvbnNlbnQgxJHGsOG7o2Mg4bqpbi48L0FsZXJ0Pn1cbiAgICAgICAgPC9TdGFjaz5cbiAgICA8L1BhbmVsPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBKb2JQYWdlKCkge1xuICAgIGNvbnN0IHsgam9iSWQgPSAnJyB9ID0gdXNlUGFyYW1zKCk7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGdldCA9IHVzZUFwaSgnZ2V0Sm9iJywgeyBwYXRoOiB7IGpvYklkIH0gfSk7XG4gICAgY29uc3Qgam9iID0gZ2V0LmRhdGE/LmRhdGE7XG4gICAgY29uc3QgZG93bmxvYWRIcmVmID0gam9iPy5kb3dubG9hZFVybCA/IGF1dGhvcml6ZWREb3dubG9hZEhyZWYoam9iLmRvd25sb2FkVXJsLCBsb2NhdGlvbi5vcmlnaW4sIF9fTU9DS19fKSA6IG51bGw7XG4gICAgY29uc3Qgam9iU3RhdHVzID0gam9iPy5zdGF0dXM7XG4gICAgY29uc3QgeyByZWZldGNoIH0gPSBnZXQ7XG4gICAgdXNlRWZmZWN0KCgpID0+IHsgaWYgKCFqb2JTdGF0dXMgfHwgIVsncXVldWVkJywgJ3J1bm5pbmcnXS5pbmNsdWRlcyhqb2JTdGF0dXMpKVxuICAgICAgICByZXR1cm47IGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4gdm9pZCByZWZldGNoKCksIDMwMDApOyByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbCh0aW1lcik7IH0sIFtqb2JTdGF0dXMsIHJlZmV0Y2hdKTtcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT17YEPDtG5nIHZp4buHYyAke2pvYklkfWB9IHN1YnRpdGxlPVwiVGhlbyBkw7VpIHRp4bq/biDEkeG7mSB04burIEFQSS4gxJDGsOG7o2MgdGnhur9wIG5o4bqtbiBraMO0bmcgY8OzIG5naMSpYSDEkcOjIGhvw6BuIHThuqV0LlwiLz48UXVlcnlTdGF0ZSBxdWVyeT17Z2V0fT57am9iICYmIDxQYW5lbCB0aXRsZT1cIkvhur90IHF14bqjIHjhu60gbMO9XCI+PFN0YWNrIGdhcD17Mn0gc3g9e3sgcDogMyB9fT48U3RhdHVzIHZhbHVlPXtqb2Iuc3RhdHVzfS8+PERldGFpbExpbmUgbGFiZWw9XCJMb+G6oWlcIj57am9iLmtpbmR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiVGnhur9uIMSR4buZXCI+e2pvYi5jb21wbGV0ZWR9IC8ge2pvYi50b3RhbCA/PyAnQ2jGsGEgYmnhur90J308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJM4buXaVwiPntqb2IuZXJyb3JDb3VudH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJD4bqtcCBuaOG6rXRcIj57ZGF0ZVRpbWUoam9iLnVwZGF0ZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPntqb2Iucm93RXJyb3JzLmxlbmd0aCA+IDAgJiYgPERhdGFUYWJsZSByb3dzPXtqb2Iucm93RXJyb3JzfSByb3dLZXk9e2UgPT4gYCR7ZS5yb3d9LSR7ZS5maWVsZH0tJHtlLmNvZGV9YH0gY29sdW1ucz17W3sga2V5OiAncm93JywgbGFiZWw6ICdEw7JuZycsIHJlbmRlcjogZSA9PiBlLnJvdyB9LCB7IGtleTogJ2ZpZWxkJywgbGFiZWw6ICdUcsaw4budbmcnLCByZW5kZXI6IGUgPT4gZS5maWVsZCB9LCB7IGtleTogJ21lc3NhZ2UnLCBsYWJlbDogJ0zhu5dpJywgcmVuZGVyOiBlID0+IGUubWVzc2FnZSB9XX0vPn08QnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgZ2V0LnJlZmV0Y2goKX0gdmFyaWFudD1cIm91dGxpbmVkXCI+S2nhu4NtIHRyYSBs4bqhaTwvQnV0dG9uPntqb2IuZG93bmxvYWRVcmwgJiYgWydzdWNjZWVkZWQnLCAncGFydGlhbCddLmluY2x1ZGVzKGpvYi5zdGF0dXMpICYmIGRvd25sb2FkSHJlZiAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cub3Blbihkb3dubG9hZEhyZWYsICdfYmxhbmsnLCAnbm9vcGVuZXIsbm9yZWZlcnJlcicpfT5N4bufIGvhur90IHF14bqjIHh14bqldDwvQnV0dG9uPn17am9iLmRvd25sb2FkVXJsICYmIFsnc3VjY2VlZGVkJywgJ3BhcnRpYWwnXS5pbmNsdWRlcyhqb2Iuc3RhdHVzKSAmJiAhZG93bmxvYWRIcmVmICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5VUkwgdOG6o2kga2jDtG5nIGFuIHRvw6BuIGhv4bq3YyBraMO0bmcgaOG7o3AgbOG7hyBuw6puIMSRw6MgYuG7iyBjaOG6t24uPC9BbGVydD59e2pvYi5zdGF0dXMgPT09ICdhd2FpdGluZ19jb25maXJtYXRpb24nICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ltcG9ydHMvJHtqb2IuaWR9YH0+WGVtIHbDoCB4w6FjIG5o4bqtbiBuaOG6rXA8L1JvdXRlTGluaz59PC9TdGFjaz48L1BhbmVsPn08L1F1ZXJ5U3RhdGU+PC8+O1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvd29ya3NwYWNlL2luZGV4LnRzeCJ9