import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react_jsx-dev-runtime.js?v=89ec09ef"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react.js?v=89ec09ef"; const useState = __vite__cjsImport3_react["useState"];
import { Alert, Box, Button, MenuItem, Stack, Tab, Tabs, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@mui_material.js?v=f046cc3b";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { dateTime, formatMoney } from "/src/shared/model/format.ts";
import { Amount, ConfirmDialog, DataTable, DetailLine, EditDialog, ErrorNotice, LookupLoadMore, MutationButton, PageHeader, Pager, Panel, QueryState, RouteLink, Stat, Stats, Status, Toolbar } from "/src/shared/ui/components.tsx";
import { explainProfitLoss, profitLossQuestions } from "/src/modules/finance/report-explanations.ts";
import { demoJournalAccounts } from "/src/modules/finance/demo-account-preview.ts";
function previousMonthRange() {
  const today = /* @__PURE__ */ new Date();
  const end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
  const start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - 1, 1));
  const dateOnly = (value) => value.toISOString().slice(0, 10);
  return { from: dateOnly(start), to: dateOnly(end) };
}
function localMidnight(date, timezone) {
  const dateParts = date.split("-");
  const [yearText, monthText, dayText] = dateParts;
  if (dateParts.length !== 3 || !yearText || !monthText || !dayText) throw new RangeError("Ngày phải theo định dạng YYYY-MM-DD.");
  const year = Number(yearText), month = Number(monthText), day = Number(dayText);
  if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day) || month < 1 || month > 12 || day < 1 || day > 31) throw new RangeError("Ngày báo cáo không hợp lệ.");
  const target = Date.UTC(year, month - 1, day);
  const targetDate = new Date(target);
  if (targetDate.getUTCFullYear() !== year || targetDate.getUTCMonth() !== month - 1 || targetDate.getUTCDate() !== day) throw new RangeError("Ngày báo cáo không hợp lệ.");
  let instant = target;
  for (let attempt = 0; attempt < 3; attempt++) {
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(new Date(instant));
    const part = (name) => {
      const value = parts.find((item) => item.type === name)?.value;
      if (value === void 0) throw new RangeError(`Thiếu thành phần thời gian ${name}.`);
      return Number(value);
    };
    const localAsUtc = Date.UTC(part("year"), part("month") - 1, part("day"), part("hour"), part("minute"), part("second"));
    instant += target - localAsUtc;
  }
  return new Date(instant).toISOString();
}
function useReportRange(timezone) {
  _s();
  const [range, setRange] = useState(previousMonthRange);
  const valid = Boolean(range.from && range.to && range.from < range.to);
  return {
    range,
    setFrom: (from) => setRange((current) => ({ ...current, from })),
    setTo: (to) => setRange((current) => ({ ...current, to })),
    valid,
    query: {
      from: valid ? localMidnight(range.from, timezone) : "",
      to: valid ? localMidnight(range.to, timezone) : "",
      timezone
    }
  };
}
_s(useReportRange, "Mxfl57wMbnjisVHWqoMqHOusdxI=");
function ReportRangeFields({ range, timezone, setFrom, setTo }) {
  return /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", sm: "row" }, gap: 2, sx: { mb: 2 }, children: [
    /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Từ ngày", value: range.from, onChange: (event) => setFrom(event.target.value), slotProps: { inputLabel: { shrink: true } } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Đến trước ngày", value: range.to, onChange: (event) => setTo(event.target.value), slotProps: { inputLabel: { shrink: true } } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 78,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { alignItems: "center" }, children: [
      "Khoảng [Từ, Đến); múi giờ ",
      timezone,
      "."
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 79,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 76,
    columnNumber: 10
  }, this);
}
_c = ReportRangeFields;
function decimalUnits(value) {
  if (!/^\d+(\.\d{1,4})?$/.test(value)) return null;
  const [whole = "", fraction = ""] = value.split(".");
  if (!whole) return null;
  return BigInt(whole) * 10000n + BigInt(fraction.padEnd(4, "0"));
}
function hasOutstandingBalance(value) {
  const amount = decimalUnits(value);
  return amount !== null && amount > 0n;
}
function decimalText(value) {
  const fraction = (value % 10000n).toString().padStart(4, "0").replace(/0+$/, "");
  return `${value / 10000n}${fraction ? `.${fraction}` : ""}`;
}
function journalLineError(line) {
  const debit = decimalUnits(line.debit.amount), credit = decimalUnits(line.credit.amount);
  if (!line.accountId.trim()) return "Nhập mã tài khoản được cấp trong hệ thống.";
  if (debit === null || credit === null) return "Số tiền dùng tối đa 4 chữ số thập phân.";
  if (debit === 0n && credit === 0n) return "Mỗi dòng phải có số Nợ hoặc Có lớn hơn 0.";
  if (debit > 0n && credit > 0n) return "Một dòng chỉ được có Nợ hoặc Có.";
  if (!line.description.trim()) return "Nhập diễn giải cho dòng.";
  return "";
}
export function CashflowPage() {
  _s2();
  const { shop } = useScope();
  const report = useReportRange(shop.timezone);
  const data = useApi("getCashflow", { query: report.query }, report.valid);
  const c = data.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Dòng tiền", subtitle: "Tiền thực thu và thực chi, tách biệt doanh thu và lợi nhuận.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/entries`, children: "Sổ thu chi" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 123
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: report.range, timezone: shop.timezone, setFrom: report.setFrom, setTo: report.setTo }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 197
    }, this),
    report.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query: data, children: c && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tiền đã thu", value: /* @__PURE__ */ jsxDEV(Amount, { value: c.receipts }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 399
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 366
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tiền đã chi", value: /* @__PURE__ */ jsxDEV(Amount, { value: c.disbursements }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 465
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 432
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Biến động tiền thuần", value: /* @__PURE__ */ jsxDEV(Amount, { value: c.netCashMovement }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 545
        }, this), accent: true, note: "Không phải số dư tài khoản" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 503
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Múi giờ báo cáo", value: c.timezone }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 626
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 110,
        columnNumber: 359
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Kỳ báo cáo", children: /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Từ", children: dateTime(c.from) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 730
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đến (không gồm)", children: dateTime(c.to) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 784
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dữ liệu tại", children: dateTime(c.asOf) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 849
        }, this),
        c.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { mt: 2 }, children: w }, w, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 110,
          columnNumber: 935
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 110,
        columnNumber: 711
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 110,
        columnNumber: 685
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 357
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 326
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 110,
      columnNumber: 1028
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 110,
    columnNumber: 10
  }, this);
}
_s2(CashflowPage, "kMF4bss271epB6ChkSLKbVGqlGE=", false, function() {
  return [useScope, useReportRange, useApi];
});
_c2 = CashflowPage;
export function EntriesPage() {
  _s3();
  const { shop } = useScope();
  const list = useApi("listFinanceEntries", { query: useListQuery() });
  const create = useCommand("createFinanceEntry", ["listFinanceEntries"]);
  const update = useCommand("updateFinanceEntry", ["listFinanceEntries"]);
  const post = useCommand("postFinanceEntry", ["listFinanceEntries", "getCashflow", "getProfitLoss", "listJournals"]);
  const reverse = useCommand("reverseFinanceEntry", ["listFinanceEntries", "getCashflow", "getProfitLoss", "listJournals"]);
  const [entryId, setEntryId] = useState(null);
  const detail = useApi("getFinanceEntry", { path: { entryId: entryId || "" } }, Boolean(entryId));
  const selectedEntry = detail.data?.data;
  const [editing, setEditing] = useState(null), [open, setOpen] = useState(false), [selected, setSelected] = useState(null);
  const [kind, setKind] = useState("disbursement"), [classification, setClassification] = useState("operating_expense"), [amount, setAmount] = useState(""), [occurredAt, setOccurredAt] = useState("2026-09-29T14:00:00Z"), [description, setDescription] = useState("");
  const begin = (entry) => {
    setEditing(entry);
    setKind(entry?.kind || "disbursement");
    setClassification(entry?.classification || "operating_expense");
    setAmount(entry?.amount.amount || "");
    setOccurredAt(entry?.occurredAt || (/* @__PURE__ */ new Date()).toISOString());
    setDescription(entry?.description || "");
    setOpen(true);
  };
  const classes = {
    sales_receipt: "Thu bán hàng",
    inventory_purchase: "Mua tồn kho",
    shipping: "Vận chuyển",
    platform_fee: "Phí nền tảng",
    payment_fee: "Phí thanh toán",
    ai_expense: "Chi phí AI",
    operating_expense: "Chi phí vận hành",
    capital: "Góp vốn",
    loan_principal: "Gốc vay",
    transfer: "Chuyển nội bộ",
    other: "Khác"
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Sổ thu chi", subtitle: "Phiếu nháp → kiểm tra → ghi sổ. Phiếu đã ghi chỉ điều chỉnh có lịch sử.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", variant: "contained", onClick: () => begin(null), children: "Tạo phiếu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 131,
      columnNumber: 135
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 131,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 131,
        columnNumber: 262
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { rows: list.data.data, rowKey: (r) => r.id, columns: [
          { key: "id", label: "Chứng từ", render: (r) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(r.id), children: r.id }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 132,
            columnNumber: 58
          }, this) },
          { key: "date", label: "Ngày", render: (r) => dateTime(r.occurredAt) },
          { key: "type", label: "Phân loại", render: (r) => classes[r.classification] },
          { key: "amount", label: "Số tiền", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.amount }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 132,
            columnNumber: 318
          }, this) },
          { key: "note", label: "Diễn giải", render: (r) => r.description },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 132,
            columnNumber: 468
          }, this) },
          {
            key: "action",
            label: "Thao tác",
            render: (r) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(r.id), children: "Chi tiết" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 134,
              columnNumber: 62
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 131,
          columnNumber: 314
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 136,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 131,
        columnNumber: 312
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 131,
        columnNumber: 273
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 131,
      columnNumber: 255
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: Boolean(entryId), title: selectedEntry ? `Chứng từ ${selectedEntry.id}` : "Đang tải chứng từ", onClose: () => setEntryId(null), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(null), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 137,
      columnNumber: 157
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: selectedEntry && /* @__PURE__ */ jsxDEV(Stack, { gap: 1, children: [
      /* @__PURE__ */ jsxDEV(Status, { value: selectedEntry.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 273
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Loại", children: selectedEntry.kind === "receipt" ? "Thu tiền" : "Chi tiền" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 312
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phân loại", children: classes[selectedEntry.classification] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 410
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Số tiền", children: /* @__PURE__ */ jsxDEV(Amount, { value: selectedEntry.amount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 520
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 492
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Ngày ghi nhận", children: dateTime(selectedEntry.occurredAt) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 572
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nguồn", children: selectedEntry.sourceRef ? `${selectedEntry.sourceRef.type} / ${selectedEntry.sourceRef.id}` : "Không có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 655
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Diễn giải", children: selectedEntry.description }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 800
      }, this),
      selectedEntry.status === "draft" && /* @__PURE__ */ jsxDEV(Stack, { direction: "row", gap: 1, children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => begin(selectedEntry), children: "Sửa nháp" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 137,
          columnNumber: 938
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ entry: selectedEntry, action: "post" }), children: "Ghi sổ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 137,
          columnNumber: 1042
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 907
      }, this),
      selectedEntry.status === "posted" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ entry: selectedEntry, action: "reverse" }), children: "Đảo phiếu" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 137,
        columnNumber: 1224
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 137,
      columnNumber: 258
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 137,
      columnNumber: 213
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 137,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: editing ? "Sửa phiếu nháp" : "Phiếu thu chi mới", onClose: () => setOpen(false), busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: create.pending || update.pending || !/^\d+(\.\d{1,4})?$/.test(amount) || description.trim().length < 5, onClick: async () => {
      const body = { kind, classification, amount: { amount, currency: shop.currency }, occurredAt, description, sourceRef: editing?.sourceRef || null };
      try {
        if (editing)
          await update.execute({ path: { entryId: editing.id }, version: editing.version, body });
        else
          await create.execute({ body });
        setOpen(false);
      } catch {
      }
    }, children: "Lưu nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 138,
      columnNumber: 163
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 145,
        columnNumber: 62
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Loại phiếu", value: kind, onChange: (e) => setKind(e.target.value === "receipt" ? "receipt" : "disbursement"), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "receipt", children: "Thu tiền" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 145,
            columnNumber: 264
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "disbursement", children: "Chi tiền" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 145,
            columnNumber: 309
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 145,
          columnNumber: 129
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Phân loại", value: classification, onChange: (e) => {
          const v = e.target.value;
          if (v in classes)
            setClassification(v);
        }, children: Object.entries(classes).map(([v, t]) => /* @__PURE__ */ jsxDEV(MenuItem, { value: v, children: t }, v, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 146,
          columnNumber: 115
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 145,
          columnNumber: 371
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Số tiền (${shop.currency})`, value: amount, onChange: (e) => setAmount(e.target.value), inputProps: { inputMode: "decimal" } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 146,
          columnNumber: 171
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Thời điểm ISO 8601", value: occurredAt, onChange: (e) => setOccurredAt(e.target.value), helperText: "Ví dụ 2026-09-29T14:00:00Z; không tự suy múi giờ từ máy." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 146,
          columnNumber: 318
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Diễn giải", multiline: true, minRows: 2, value: description, onChange: (e) => setDescription(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 146,
          columnNumber: 495
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Tiền mua hàng tồn kho không tự trở thành toàn bộ chi phí trong lợi nhuận." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 146,
          columnNumber: 617
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 145,
        columnNumber: 114
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 138,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: selected?.action === "post" ? "Ghi sổ phiếu đã kiểm" : "Đảo phiếu đã ghi", description: `${selected?.entry.id || ""} · ${formatMoney(selected?.entry.amount)}. Không chuyển tiền thực tế qua chức năng này.`, requireReason: true, onClose: () => setSelected(null), busy: post.pending || reverse.pending, error: post.error || reverse.error, onConfirm: (reason) => selected?.action === "post" ? post.execute({ path: { entryId: selected.entry.id }, body: { expectedVersion: selected.entry.version, reason } }) : reverse.execute({ path: { entryId: selected?.entry.id || "" }, body: { expectedVersion: selected?.entry.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 147,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 131,
    columnNumber: 10
  }, this);
}
_s3(EntriesPage, "GbUliAQnpdyxxwhiGU4YZbnjjS8=", false, function() {
  return [useScope, useApi, useListQuery, useCommand, useCommand, useCommand, useCommand, useApi];
});
_c3 = EntriesPage;
export function ProfitLossPage() {
  _s4();
  const { shop } = useScope();
  const report = useReportRange(shop.timezone);
  const data = useApi("getProfitLoss", { query: report.query }, report.valid);
  const p = data.data?.data;
  const [question, setQuestion] = useState("summary");
  const [generatedKey, setGeneratedKey] = useState("");
  const currentKey = p ? `${report.range.from}|${report.range.to}|${p.asOf}|${question}` : "";
  const explanation = p && generatedKey === currentKey ? explainProfitLoss(p, question) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Lợi nhuận quản trị", subtitle: "Số liệu do API tổng hợp từ nguồn giao dịch, không tính từ trang danh sách đang mở." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 158,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: report.range, timezone: shop.timezone, setFrom: (value) => {
      setGeneratedKey("");
      report.setFrom(value);
    }, setTo: (value) => {
      setGeneratedKey("");
      report.setTo(value);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 158,
      columnNumber: 147
    }, this),
    report.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query: data, children: p && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Doanh thu thuần", value: /* @__PURE__ */ jsxDEV(Amount, { value: p.netSales }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 435
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 398
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Giá vốn", value: /* @__PURE__ */ jsxDEV(Amount, { value: p.cogs }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 497
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 468
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Lãi gộp", value: /* @__PURE__ */ jsxDEV(Amount, { value: p.grossProfit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 555
        }, this), accent: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 526
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Lợi nhuận vận hành", value: /* @__PURE__ */ jsxDEV(Amount, { value: p.operatingProfit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 638
        }, this), note: "Chưa có chứng nhận kế toán pháp định" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 598
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 158,
        columnNumber: 391
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Chi tiết kết quả kinh doanh", action: /* @__PURE__ */ jsxDEV(Status, { value: p.completeness }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 158,
        columnNumber: 781
      }, this), children: /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
        [
          ["Doanh thu gộp", p.grossSales],
          ["Giảm giá", p.discounts],
          ["Hàng bán trả lại", p.salesReturns],
          ["Doanh thu thuần", p.netSales],
          ["Giá vốn", p.cogs],
          ["Thu phí giao", p.shippingIncome],
          ["Chi phí giao", p.shippingExpense],
          ["Phí nền tảng", p.platformFees],
          ["Phí thanh toán", p.paymentFees],
          ["Chi phí AI", p.aiExpense],
          ["Chi phí khác", p.otherOperatingExpenses]
        ].map(([t, v]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: String(t), children: /* @__PURE__ */ jsxDEV(Amount, { value: typeof v === "object" ? v : null }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 160,
          columnNumber: 75
        }, this) }, String(t), false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 160,
          columnNumber: 29
        }, this)),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: p.policyVersion }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 160,
          columnNumber: 141
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dữ liệu tại", children: dateTime(p.asOf) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 160,
          columnNumber: 202
        }, this),
        p.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: { mt: 2 }, children: w }, w, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 160,
          columnNumber: 288
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 158,
        columnNumber: 816
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 158,
        columnNumber: 730
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Hỏi đáp có nguồn", subtitle: "Giải thích giới hạn theo đúng snapshot đang hiển thị.", children: __MOCK__ ? /* @__PURE__ */ jsxDEV(Stack, { gap: 2, sx: { p: 3 }, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chế độ mô phỏng: câu trả lời theo mẫu cố định, chỉ đọc dữ liệu P&L API tổng hợp này; không gọi AI và không ghi sổ." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 162,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Câu hỏi về báo cáo", value: question, onChange: (event) => {
          setQuestion(event.target.value);
          setGeneratedKey("");
        }, children: profitLossQuestions.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.label }, item.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 164,
          columnNumber: 52
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 163,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => setGeneratedKey(currentKey), disabled: !currentKey, children: "Tạo giải thích mô phỏng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 166,
          columnNumber: 13
        }, this),
        explanation && /* @__PURE__ */ jsxDEV(Box, { role: "region", "aria-label": "Giải thích báo cáo mô phỏng", "data-testid": "profit-loss-explanation", sx: { p: 2, border: 1, borderColor: "divider", borderRadius: 1 }, children: [
          /* @__PURE__ */ jsxDEV(Typography, { sx: { mb: 2 }, children: explanation.answer }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 168,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { mb: 1 }, children: "Dữ liệu nguồn trong snapshot" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 169,
            columnNumber: 17
          }, this),
          explanation.sources.map((source) => /* @__PURE__ */ jsxDEV(DetailLine, { label: source.label, children: source.value }, source.label, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 170,
            columnNumber: 54
          }, this)),
          explanation.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: { mt: 1 }, children: warning }, `${index}-${warning}`, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 171,
            columnNumber: 63
          }, this)),
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { mt: 2 }, children: "Hợp đồng getProfitLoss chưa trả về journal ID để drill-down; giao diện không tạo liên kết nguồn giả." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 172,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 167,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 161,
        columnNumber: 21
      }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { m: 3 }, children: "Chức năng giải thích chỉ có bản xem trước mô phỏng. API hiện chưa có operation hỏi đáp báo cáo." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 174,
        columnNumber: 20
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 364
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 158,
      columnNumber: 389
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 158,
      columnNumber: 358
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 175,
      columnNumber: 33
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 158,
    columnNumber: 10
  }, this);
}
_s4(ProfitLossPage, "LtOWyWl6PdqtCVPevzPfpZnn42o=", false, function() {
  return [useScope, useReportRange, useApi];
});
_c4 = ProfitLossPage;
function JournalAccountField({ index, value, onChange }) {
  if (__MOCK__) return /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Tài khoản dòng ${index}`, fullWidth: true, value, error: !value.trim(), helperText: value ? "Tài khoản tổng hợp chỉ dùng nghiệm thu UI; không xác thực với sơ đồ kế toán thật." : "Chọn tài khoản mẫu để hoàn tất luồng demo.", onChange: (event) => onChange(event.target.value), children: [
    /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn tài khoản mẫu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 179,
      columnNumber: 9
    }, this),
    demoJournalAccounts.map((account) => /* @__PURE__ */ jsxDEV(MenuItem, { value: account.id, children: account.label }, account.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 180,
      columnNumber: 47
    }, this))
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 178,
    columnNumber: 24
  }, this);
  return /* @__PURE__ */ jsxDEV(TextField, { label: `Tài khoản dòng ${index}`, fullWidth: true, value, error: !value.trim(), helperText: !value.trim() ? "Nhập ID do hệ thống cấp; UI không tự tạo danh mục tài khoản." : "", onChange: (event) => onChange(event.target.value) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 182,
    columnNumber: 10
  }, this);
}
_c5 = JournalAccountField;
export function JournalsPage() {
  _s5();
  const { shop } = useScope();
  const list = useApi("listJournals", { query: useListQuery() });
  const [viewId, setViewId] = useState(null);
  const detail = useApi("getJournal", { path: { resourceId: viewId || "" } }, Boolean(viewId));
  const viewedJournal = detail.data?.data;
  const periods = useApi("listAccountingPeriods");
  const create = useCommand("createJournal", ["listJournals"]);
  const post = useCommand("postJournal", ["listJournals"]);
  const reverse = useCommand("reverseJournal", ["listJournals"]);
  const [open, setOpen] = useState(false), [selected, setSelected] = useState(null), [sourceType, setSourceType] = useState("manual"), [sourceId, setSourceId] = useState(""), [date, setDate] = useState("2026-09-29"), [reason, setReason] = useState("");
  const newLine = () => ({ accountId: "", debit: { amount: "0", currency: shop.currency }, credit: { amount: "0", currency: shop.currency }, description: "" });
  const [lines, setLines] = useState([newLine(), newLine()]);
  const lineErrors = lines.map(journalLineError);
  const debitTotal = lines.reduce((total, line) => total + (decimalUnits(line.debit.amount) ?? 0n), 0n);
  const creditTotal = lines.reduce((total, line) => total + (decimalUnits(line.credit.amount) ?? 0n), 0n);
  const period = periods.data?.data.find((item) => date >= item.startDate && date <= item.endDate);
  const periodOpen = period?.state === "open";
  const balanced = lines.length >= 2 && lineErrors.every((error) => !error) && debitTotal === creditTotal && debitTotal > 0n;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Bút toán", subtitle: "Sổ kép có chứng từ nguồn, kiểm cân bằng tại API và không sửa bút toán đã ghi.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", variant: "contained", onClick: () => setOpen(true), children: "Tạo bút toán nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 204,
      columnNumber: 139
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 204,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 204,
        columnNumber: 276
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { rows: list.data.data, rowKey: (journal) => journal.id, columns: [
          { key: "id", label: "Bút toán", render: (journal) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(journal.id), children: journal.id }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 205,
            columnNumber: 64
          }, this) },
          { key: "date", label: "Ngày hiệu lực", render: (journal) => journal.effectiveDate },
          { key: "source", label: "Nguồn", render: (journal) => `${journal.sourceType} / ${journal.sourceId}` },
          { key: "state", label: "Trạng thái", render: (journal) => /* @__PURE__ */ jsxDEV(Status, { value: journal.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 208,
            columnNumber: 69
          }, this) },
          { key: "actions", label: "", render: (journal) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(journal.id), children: "Chi tiết" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 209,
            columnNumber: 61
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 204,
          columnNumber: 328
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 210,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 204,
        columnNumber: 326
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 204,
        columnNumber: 287
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 204,
      columnNumber: 269
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: Boolean(viewId), title: viewedJournal ? `Bút toán ${viewedJournal.id}` : "Đang tải bút toán", onClose: () => setViewId(null), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(null), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 211,
      columnNumber: 158
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: viewedJournal && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Status, { value: viewedJournal.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 211,
        columnNumber: 260
      }, this),
      /* @__PURE__ */ jsxDEV(DataTable, { rows: viewedJournal.lines.map((line, index) => ({ ...line, key: String(index) })), rowKey: (line) => line.key, columns: [
        { key: "account", label: "Tài khoản", render: (line) => line.accountId },
        { key: "debit", label: "Nợ", render: (line) => /* @__PURE__ */ jsxDEV(Amount, { value: line.debit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 58
        }, this) },
        { key: "credit", label: "Có", render: (line) => /* @__PURE__ */ jsxDEV(Amount, { value: line.credit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 214,
          columnNumber: 59
        }, this) },
        { key: "note", label: "Diễn giải", render: (line) => line.description }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 211,
        columnNumber: 299
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: viewedJournal.policyVersion }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 216,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bút toán gốc", children: viewedJournal.reversalOf || "—" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 216,
        columnNumber: 88
      }, this),
      viewedJournal.status === "draft" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ journal: viewedJournal, action: "post" }), children: "Ghi sổ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 216,
        columnNumber: 204
      }, this),
      viewedJournal.status === "posted" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ journal: viewedJournal, action: "reverse" }), children: "Đảo bút toán" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 216,
        columnNumber: 380
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 211,
      columnNumber: 258
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 211,
      columnNumber: 213
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 211,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Bút toán nháp", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !sourceId.trim() || reason.trim().length < 5 || create.pending || !balanced || !periodOpen, onClick: async () => {
      try {
        await create.execute({ body: { sourceType, sourceId, effectiveDate: date, lines, reason } });
        setOpen(false);
      } catch {
      }
    }, children: "Lưu nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 217,
      columnNumber: 113
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 217,
        columnNumber: 423
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: __MOCK__ ? "Danh mục dưới đây là dữ liệu tổng hợp để nghiệm thu giao diện, không phải sơ đồ kế toán đã xác minh." : "Contract hiện chưa có API danh mục tài khoản; chỉ dùng mã tài khoản do hệ thống cấp." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 474
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Loại chứng từ nguồn", value: sourceType, onChange: (event) => setSourceType(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 709
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã chứng từ nguồn", value: sourceId, onChange: (event) => setSourceId(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 825
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Ngày hiệu lực", value: date, onChange: (event) => setDate(event.target.value), slotProps: { inputLabel: { shrink: true } } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 935
        }, this),
        periods.isPending ? /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Đang tải trạng thái kỳ kế toán…" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 1111
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: periodOpen ? "success" : "warning", children: period ? periodOpen ? `Kỳ ${period.startDate} – ${period.endDate} đang mở.` : `Kỳ ${period.startDate} – ${period.endDate} đã khóa; không thể tạo bút toán cho ngày này.` : "Chưa có kỳ kế toán cấu hình cho ngày hiệu lực." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 1176
        }, this),
        lines.map((line, index) => /* @__PURE__ */ jsxDEV(Box, { sx: { p: 2, border: 1, borderColor: lineErrors[index] ? "error.main" : "divider", borderRadius: 2 }, children: [
          /* @__PURE__ */ jsxDEV(JournalAccountField, { index: index + 1, value: line.accountId, onChange: (accountId) => setLines((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, accountId } : item)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 1605
          }, this),
          /* @__PURE__ */ jsxDEV(Stack, { direction: "row", gap: 1, sx: { my: 1.5 }, children: ["debit", "credit"].map((side) => /* @__PURE__ */ jsxDEV(TextField, { label: side === "debit" ? "Nợ" : "Có", value: line[side].amount, error: decimalUnits(line[side].amount) === null || (side === "debit" ? decimalUnits(line.credit.amount) : decimalUnits(line.debit.amount)) === null, helperText: decimalUnits(line[side].amount) === null ? "Dùng số thập phân tối đa 4 chữ số." : "", inputProps: { inputMode: "decimal" }, onChange: (event) => setLines((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, [side]: { amount: event.target.value, currency: shop.currency } } : item)) }, side, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 1898
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 1804
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Diễn giải dòng", fullWidth: true, value: line.description, error: !line.description.trim(), helperText: !line.description.trim() ? "Bắt buộc nhập diễn giải." : "", onChange: (event) => setLines((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, description: event.target.value } : item)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 2467
          }, this),
          lineErrors[index] && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: { mt: 1 }, children: lineErrors[index] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 2818
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: lines.length <= 2, onClick: () => setLines((current) => current.filter((_, itemIndex) => itemIndex !== index)), children: "Bỏ dòng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 217,
            columnNumber: 2887
          }, this)
        ] }, index, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 1487
        }, this)),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => setLines((current) => [...current, newLine()]), children: "Thêm dòng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 3041
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: balanced ? "success" : "warning", children: [
          "Tổng Nợ ",
          decimalText(debitTotal),
          " ",
          shop.currency,
          " · Tổng Có ",
          decimalText(creditTotal),
          " ",
          shop.currency,
          balanced ? " · Đã cân bằng" : " · Cần cân bằng và mỗi dòng chỉ có một bên"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 3130
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (event) => setReason(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 217,
          columnNumber: 3367
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 217,
        columnNumber: 459
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 217,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: selected?.action === "post" ? "Ghi sổ bút toán" : "Đảo bút toán", description: "Backend kiểm kỳ, cân bằng, quyền và chứng từ trùng trước khi ghi.", requireReason: selected?.action === "reverse", onClose: () => setSelected(null), error: post.error || reverse.error, busy: post.pending || reverse.pending, onConfirm: (confirmReason) => selected?.action === "post" ? post.execute({ path: { resourceId: selected.journal.id }, body: { expectedVersion: selected.journal.version } }) : reverse.execute({ path: { resourceId: selected?.journal.id || "" }, body: { expectedVersion: selected?.journal.version || 1, reason: confirmReason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 218,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 204,
    columnNumber: 10
  }, this);
}
_s5(JournalsPage, "8pzxJCA0erXKo2vAalPCLgEIkx0=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useApi, useCommand, useCommand, useCommand];
});
_c6 = JournalsPage;
export function ReconciliationPage() {
  _s6();
  const { shop } = useScope();
  const [tab, setTab] = useState(0);
  const banks = useApi("listBankTransactions", { query: useListQuery("bankCursor") });
  const cod = useApi("listCODSettlements", { query: useListQuery("codCursor") });
  const cases = useApi("listReconciliationCases", { query: useListQuery("caseCursor") });
  const match = useCommand("matchCODSettlement", ["listCODSettlements", "listBankTransactions", "listDebtItems", "getCashflow"]);
  const matchBank = useCommand("matchSettlement", ["listReconciliationCases", "listBankTransactions", "listDebtItems"]);
  const [selected, setSelected] = useState(null), [caseItem, setCase] = useState(null), [transaction, setTransaction] = useState(""), [fees, setFees] = useState("0"), [evidence, setEvidence] = useState(""), [resourceId, setResource] = useState(""), [allocation, setAllocation] = useState(""), [reason, setReason] = useState(""), [importOpen, setImport] = useState(false);
  const bankChoices = usePagedApi("listBankTransactions", {}, Boolean(selected));
  const caseBank = useApi("getBankTransaction", { path: { resourceId: caseItem?.transactionId || "" } }, Boolean(caseItem));
  const debtChoices = usePagedApi("listDebtItems", {}, Boolean(caseItem));
  const selectedBank = caseItem ? caseBank.data?.data : bankChoices.data?.data.find((item) => item.id === transaction);
  const selectedDebt = debtChoices.data?.data.find((item) => item.id === resourceId);
  const feeUnits = decimalUnits(fees), allocationUnits = decimalUnits(allocation);
  const codMatchValid = Boolean(selected && selectedBank && feeUnits !== null && feeUnits >= 0n && feeUnits <= (decimalUnits(selected.grossDue.amount) ?? -1n) && (decimalUnits(selected.grossDue.amount) ?? -1n) - feeUnits === decimalUnits(selectedBank.amount.amount) && evidence.trim());
  const bankMatchValid = Boolean(caseItem && selectedBank && selectedDebt && !selectedDebt.disputed && allocationUnits !== null && allocationUnits > 0n && allocationUnits <= (decimalUnits(caseItem.difference.amount) ?? -1n) && allocationUnits <= (decimalUnits(selectedDebt.outstandingAmount.amount) ?? -1n) && selectedDebt.outstandingAmount.currency === selectedBank.amount.currency && selectedBank.direction === "credit" === (selectedDebt.direction === "receivable") && reason.trim().length >= 5);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đối soát ngân hàng & COD", subtitle: "Khách trả tiền cho đơn vị giao hàng chưa đồng nghĩa tiền đã về shop.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", variant: "contained", onClick: () => setImport(true), children: "Nhập bảng đối soát" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 146
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Tabs, { value: tab, onChange: (_, value) => setTab(value), sx: { mb: 2 }, variant: "scrollable", children: [
      /* @__PURE__ */ jsxDEV(Tab, { label: "Ngân hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 238,
        columnNumber: 385
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { label: "COD" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 238,
        columnNumber: 410
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { label: "Chênh lệch cần xử lý" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 238,
        columnNumber: 429
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 284
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: tab === 0 ? /* @__PURE__ */ jsxDEV(QueryState, { query: banks, children: banks.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { rows: banks.data.data, rowKey: (row) => row.id, columns: [
        { key: "id", label: "Mã ngoài hệ thống", render: (row) => row.externalTransactionId },
        { key: "account", label: "Tài khoản", render: (row) => row.accountId },
        { key: "money", label: "Số tiền", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.amount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 241,
          columnNumber: 62
        }, this) },
        { key: "direction", label: "Chiều", render: (row) => row.direction === "credit" ? "Tiền vào" : "Tiền ra" },
        { key: "note", label: "Nội dung", render: (row) => row.referenceText },
        { key: "state", label: "Khớp", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.matchState }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 244,
          columnNumber: 59
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 238,
        columnNumber: 535
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: banks.data.page, cursorParam: "bankCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 245,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 533
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 492
    }, this) : tab === 1 ? /* @__PURE__ */ jsxDEV(QueryState, { query: cod, children: cod.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { rows: cod.data.data, rowKey: (row) => row.id, columns: [
        { key: "id", label: "Đợt COD", render: (row) => row.externalBatchId },
        { key: "carrier", label: "Đơn vị giao", render: (row) => row.carrierId },
        { key: "gross", label: "Phải thu", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.grossDue }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 248,
          columnNumber: 63
        }, this) },
        { key: "fee", label: "Phí thực tế", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.actualFees }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 249,
          columnNumber: 64
        }, this) },
        { key: "cash", label: "Đã về ngân hàng", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.bankReceived }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 250,
          columnNumber: 69
        }, this) },
        { key: "state", label: "Trạng thái", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 251,
          columnNumber: 65
        }, this) },
        { key: "action", label: "", render: (row) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", disabled: row.status === "matched", onClick: () => {
          setSelected(row);
          setTransaction("");
          setFees(row.actualFees.amount);
          setEvidence("");
        }, children: "Đối chiếu" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 252,
          columnNumber: 56
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 245,
        columnNumber: 143
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: cod.data.page, cursorParam: "codCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 253,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 245,
      columnNumber: 141
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 245,
      columnNumber: 104
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: cases, children: cases.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { rows: cases.data.data, rowKey: (row) => row.id, columns: [
        { key: "id", label: "Mã", render: (row) => row.id },
        { key: "transaction", label: "Giao dịch", render: (row) => banks.data?.data.find((transaction2) => transaction2.id === row.transactionId)?.externalTransactionId || row.transactionId },
        { key: "state", label: "Trạng thái", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.state }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 256,
          columnNumber: 65
        }, this) },
        { key: "reason", label: "Cần xử lý", render: (row) => row.reason },
        { key: "action", label: "", render: (row) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", disabled: row.state === "matched", onClick: () => {
          setCase(row);
          setTransaction(row.transactionId);
          setResource("");
          setAllocation("");
          setReason("");
        }, children: "Ghép giao dịch" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 258,
          columnNumber: 56
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 253,
        columnNumber: 132
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: cases.data.page, cursorParam: "caseCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 259,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 253,
      columnNumber: 130
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 253,
      columnNumber: 89
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 238,
      columnNumber: 472
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!selected, title: "Ghép tiền COD", onClose: () => setSelected(null), busy: match.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !codMatchValid || match.pending, onClick: async () => {
      try {
        await match.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, bankTransactionId: transaction, actualFees: { amount: fees, currency: shop.currency }, feeEvidenceRef: evidence, reason: "Đối chiếu bảng COD và giao dịch ngân hàng" } });
        setSelected(null);
      } catch {
      }
    }, children: "Xác nhận khớp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 260,
      columnNumber: 121
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: match.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 260,
        columnNumber: 570
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: bankChoices, children: bankChoices.data && /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Mã giao dịch ngân hàng", value: transaction, onChange: (event) => setTransaction(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn giao dịch chưa ghép" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 260,
            columnNumber: 799
          }, this),
          bankChoices.data.data.filter((item) => item.direction === "credit" && item.matchState === "unmatched" && item.amount.currency === selected?.grossDue.currency).map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: [
            item.externalTransactionId,
            " · ",
            formatMoney(item.amount)
          ] }, item.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 260,
            columnNumber: 1027
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 260,
          columnNumber: 673
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "giao dịch ngân hàng", loadedCount: bankChoices.loadedCount, hasMore: bankChoices.hasMore, busy: bankChoices.isLoadingMore, onLoadMore: bankChoices.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 260,
          columnNumber: 1149
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Phí thực tế (${shop.currency})`, value: fees, error: feeUnits === null, helperText: selectedBank && feeUnits !== null && !codMatchValid ? "Tiền về + phí phải bằng khoản COD và cần chứng từ phí." : "Nhập phí theo chứng từ; khoản fee đã khấu trừ không phải chi tiền thêm.", onChange: (event) => setFees(event.target.value), inputProps: { inputMode: "decimal" } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 260,
          columnNumber: 1330
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã chứng từ phí", value: evidence, onChange: (event) => setEvidence(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 260,
          columnNumber: 1711
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không xác nhận thanh toán bằng ảnh chuyển khoản. Tổng tiền về và phí phải khớp khoản COD." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 260,
          columnNumber: 1819
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 260,
        columnNumber: 658
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 260,
        columnNumber: 605
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 260,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!caseItem, title: "Ghép giao dịch với công nợ", onClose: () => setCase(null), busy: matchBank.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !bankMatchValid || matchBank.pending, onClick: async () => {
      try {
        await matchBank.execute({ path: { resourceId: caseItem?.id || "" }, body: { expectedVersion: caseItem?.version || 1, transactionId: transaction, allocations: [{ resource: { type: "debt", id: resourceId }, amount: { amount: allocation, currency: shop.currency } }], reason } });
        setCase(null);
      } catch {
      }
    }, children: "Ghi kết quả đối soát" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 261,
      columnNumber: 134
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: matchBank.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 261,
        columnNumber: 597
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: caseBank, children: caseBank.data && /* @__PURE__ */ jsxDEV(QueryState, { query: debtChoices, children: debtChoices.data && /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao dịch ngoài hệ thống", value: caseBank.data.data.externalTransactionId, InputProps: { readOnly: true } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 261,
          columnNumber: 751
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khoản công nợ", value: resourceId, onChange: (event) => setResource(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn khoản nợ chưa tranh chấp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 261,
            columnNumber: 991
          }, this),
          debtChoices.data.data.filter((item) => !item.disputed && hasOutstandingBalance(item.outstandingAmount.amount) && item.outstandingAmount.currency === selectedBank?.amount.currency && selectedBank?.direction === "credit" === (item.direction === "receivable")).map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: [
            item.id,
            " · ",
            item.direction === "receivable" ? "Phải thu" : "Phải trả",
            " · ",
            formatMoney(item.outstandingAmount)
          ] }, item.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 261,
            columnNumber: 1323
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 261,
          columnNumber: 878
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "công nợ", loadedCount: debtChoices.loadedCount, hasMore: debtChoices.hasMore, busy: debtChoices.isLoadingMore, onLoadMore: debtChoices.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 261,
          columnNumber: 1499
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Số tiền phân bổ (${shop.currency})`, value: allocation, error: allocation !== "" && allocationUnits === null, helperText: allocationUnits !== null && allocationUnits > 0n && !bankMatchValid ? "Số tiền vượt chênh lệch/khoản nợ, khác tiền tệ hoặc thiếu lý do." : "", onChange: (event) => setAllocation(event.target.value), inputProps: { inputMode: "decimal" } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 261,
          columnNumber: 1668
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (event) => setReason(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 261,
          columnNumber: 2048
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 261,
        columnNumber: 736
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 261,
        columnNumber: 683
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 261,
        columnNumber: 636
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 261,
      columnNumber: 5
    }, this),
    importOpen && /* @__PURE__ */ jsxDEV(StatementDialog, { onClose: () => setImport(false) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 262,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 238,
    columnNumber: 10
  }, this);
}
_s6(ReconciliationPage, "nYHbk3LPGK4jyHFe8yiSRd9+IpQ=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useListQuery, useApi, useListQuery, useCommand, useCommand, usePagedApi, useApi, usePagedApi];
});
_c7 = ReconciliationPage;
function StatementDialog({
  onClose
}) {
  _s7();
  const { shop } = useScope();
  const upload = useCommand("uploadFile", []), bank = useCommand("importBankStatement", ["listBankTransactions", "listReconciliationCases"]), cod = useCommand("importCODStatement", ["listCODSettlements"]);
  const [kind, setKind] = useState("bank"), [file, setFile] = useState(null), [account, setAccount] = useState(""), [batch, setBatch] = useState(""), [format, setFormat] = useState("botsales-csv-v1"), [jobId, setJob] = useState(""), [draftCommit, setDraftCommit] = useState();
  return /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: "Nhập bảng đối soát", onClose, busy: upload.pending || bank.pending || cod.pending, draftCommit, actions: jobId ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Xem kết quả nhập" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 270,
    columnNumber: 168
  }, this) : /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !__MOCK__ || !file || !account || !batch || upload.pending || bank.pending || cod.pending, onClick: async () => {
    if (!file || !__MOCK__)
      return;
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("purpose", kind === "bank" ? "bank_statement" : "cod_statement");
      const f = await upload.execute({ form: fd });
      const body = { fileId: f.data.id, accountOrCarrierId: account, formatId: format, sourceBatchId: batch };
      const result = kind === "bank" ? await bank.execute({ body }) : await cod.execute({ body });
      setJob(result.data.id);
      setDraftCommit((previous) => ({ scope: null, sequence: (previous?.sequence || 0) + 1 }));
    } catch {
    }
  }, children: "Kiểm tra và nhập" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 270,
    columnNumber: 245
  }, this), children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: upload.error || bank.error || cod.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 281,
      columnNumber: 56
    }, this),
    /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
      !__MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Hợp đồng upload hiện chưa có mục đích cho tệp đối soát. Luồng này chỉ chạy trong MSW demo." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 148
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Loại bảng", value: kind, onChange: (e) => setKind(e.target.value), children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "bank", children: "Ngân hàng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 281,
          columnNumber: 364
        }, this),
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "cod", children: "COD" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 281,
          columnNumber: 407
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 273
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: "label", variant: "outlined", children: [
        file ? file.name : "Chọn CSV",
        /* @__PURE__ */ jsxDEV("input", { hidden: true, type: "file", accept: ".csv,text/csv", onChange: (e) => setFile(e.target.files?.[0] || null) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 281,
          columnNumber: 531
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 455
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Mã tài khoản / đơn vị vận chuyển", value: account, onChange: (e) => setAccount(e.target.value) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 646
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Mã đợt nhập duy nhất", value: batch, onChange: (e) => setBatch(e.target.value) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 761
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Mã định dạng được backend hỗ trợ", value: format, onChange: (e) => setFormat(e.target.value) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 860
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Mẫu CSV và định dạng mô phỏng nằm trong samples/. Định dạng ngân hàng thật phải được backend xác nhận; nhập không đồng nghĩa đối soát xong." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 281,
        columnNumber: 973
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 281,
      columnNumber: 119
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 270,
    columnNumber: 10
  }, this);
}
_s7(StatementDialog, "s3p1cogEvvA4WCceQSIEBYepfQs=", false, function() {
  return [useScope, useCommand, useCommand, useCommand];
});
_c8 = StatementDialog;
export function DebtsPage() {
  _s8();
  const debts = useApi("listDebtItems", { query: useListQuery() }), periods = useApi("listAccountingPeriods");
  const close = useCommand("closeAccountingPeriod", ["listAccountingPeriods"]);
  const reopen = useCommand("reopenAccountingPeriod", ["listAccountingPeriods"]);
  const [selected, setSelected] = useState(null), [approval, setApproval] = useState(""), [reason, setReason] = useState("");
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Công nợ & khóa kỳ", subtitle: "Theo dõi khoản còn phải thu/trả; khóa kỳ chỉ khi các điều kiện được kiểm chứng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 288,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Công nợ", children: /* @__PURE__ */ jsxDEV(QueryState, { query: debts, children: debts.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { rows: debts.data.data, rowKey: (r) => r.id, columns: [
        { key: "id", label: "Khoản nợ", render: (r) => r.id },
        { key: "who", label: "Đối tượng", render: (r) => `${r.counterpartyType} / ${r.counterpartyId}` },
        { key: "direction", label: "Loại", render: (r) => r.direction === "receivable" ? "Phải thu" : "Phải trả" },
        { key: "original", label: "Ban đầu", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.originalAmount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 289,
          columnNumber: 324
        }, this) },
        { key: "current", label: "Còn lại", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.outstandingAmount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 289,
          columnNumber: 414
        }, this) },
        { key: "due", label: "Đến hạn", render: (r) => dateTime(r.dueAt) },
        { key: "dispute", label: "Tranh chấp", render: (r) => r.disputed ? "Đang giữ xử lý" : "Không" }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 288,
        columnNumber: 209
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: debts.data.page }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 290,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 288,
      columnNumber: 207
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 288,
      columnNumber: 166
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 288,
      columnNumber: 143
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Kỳ kế toán", sx: { mt: 3 }, children: /* @__PURE__ */ jsxDEV(QueryState, { query: periods, children: /* @__PURE__ */ jsxDEV(DataTable, { rows: periods.data?.data || [], rowKey: (r) => r.id, columns: [
      { key: "period", label: "Kỳ", render: (r) => `${r.startDate} → ${r.endDate}` },
      { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.state }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 291,
        columnNumber: 141
      }, this) },
      { key: "issues", label: "Điều kiện còn thiếu", render: (r) => r.blockingIssues.join("; ") || "Xác minh lại tại lúc ghi" },
      {
        key: "action",
        label: "",
        render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.close", onClick: () => {
          setSelected(r);
          setApproval("");
          setReason("");
        }, children: r.state === "closed" ? "Mở lại có phê duyệt" : "Kiểm & khóa kỳ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 293,
          columnNumber: 52
        }, this)
      }
    ] }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 290,
      columnNumber: 141
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 290,
      columnNumber: 113
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 290,
      columnNumber: 72
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected && selected.state !== "closed", title: "Khóa kỳ kế toán", description: "Backend kiểm lại chứng từ nháp, sai lệch, COD và quyền trước khi khóa; không xóa sai lệch để vượt kiểm tra.", onClose: () => setSelected(null), busy: close.pending, error: close.error, onConfirm: () => close.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 295,
      columnNumber: 34
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: selected?.state === "closed", title: "Mở lại kỳ đã khóa", onClose: () => setSelected(null), busy: reopen.pending, actions: /* @__PURE__ */ jsxDEV(Button, { disabled: !approval || reason.length < 5 || reopen.pending, onClick: async () => {
      try {
        await reopen.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, approvalId: approval, reason } });
        setSelected(null);
      } catch {
      }
    }, children: "Mở lại kỳ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 295,
      columnNumber: 589
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: reopen.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 299,
        columnNumber: 51
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { gap: 2, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã phê duyệt đúng kỳ", value: approval, onChange: (e) => setApproval(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 299,
          columnNumber: 102
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 299,
          columnNumber: 207
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 299,
        columnNumber: 87
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 295,
      columnNumber: 450
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 288,
    columnNumber: 10
  }, this);
}
_s8(DebtsPage, "F9BMEk5t45ggKtYEGR75PoWa2m0=", false, function() {
  return [useApi, useListQuery, useApi, useCommand, useCommand];
});
_c9 = DebtsPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "ReportRangeFields");
$RefreshReg$(_c2, "CashflowPage");
$RefreshReg$(_c3, "EntriesPage");
$RefreshReg$(_c4, "ProfitLossPage");
$RefreshReg$(_c5, "JournalAccountField");
$RefreshReg$(_c6, "JournalsPage");
$RefreshReg$(_c7, "ReconciliationPage");
$RefreshReg$(_c8, "StatementDialog");
$RefreshReg$(_c9, "DebtsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURRLFNBaUM0VixVQWpDNVY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBekRSLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxVQUFVQyxPQUFPQyxLQUFLQyxNQUFNQyxXQUFXQyxrQkFBa0I7QUFFdEYsU0FBU0MsUUFBUUMsWUFBWUMsbUJBQW1CO0FBQ2hELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsVUFBVUMsbUJBQW1CO0FBQ3RDLFNBQVNDLFFBQVFDLGVBQWVDLFdBQVdDLFlBQVlDLFlBQVlDLGFBQWFDLGdCQUFnQkMsZ0JBQWdCQyxZQUFZQyxPQUFPQyxPQUFPQyxZQUFZQyxXQUFXQyxNQUFNQyxPQUFPQyxRQUFRQyxlQUFlO0FBQ3JNLFNBQVNDLG1CQUFtQkMsMkJBQXNEO0FBQ2xGLFNBQVNDLDJCQUEyQjtBQUVwQyxTQUFTQyxxQkFBcUI7QUFDMUIsUUFBTUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxNQUFNLElBQUlELEtBQUtBLEtBQUtFLElBQUlILE1BQU1JLGVBQWUsR0FBR0osTUFBTUssWUFBWSxHQUFHLENBQUMsQ0FBQztBQUM3RSxRQUFNQyxRQUFRLElBQUlMLEtBQUtBLEtBQUtFLElBQUlILE1BQU1JLGVBQWUsR0FBR0osTUFBTUssWUFBWSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ25GLFFBQU1FLFdBQVdBLENBQUNDLFVBQWdCQSxNQUFNQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFO0FBQ2pFLFNBQU8sRUFBRUMsTUFBTUosU0FBU0QsS0FBSyxHQUFHTSxJQUFJTCxTQUFTTCxHQUFHLEVBQUU7QUFDdEQ7QUFDQSxTQUFTVyxjQUFjQyxNQUFjQyxVQUFrQjtBQUNuRCxRQUFNQyxZQUFZRixLQUFLRyxNQUFNLEdBQUc7QUFDaEMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXQyxPQUFPLElBQUlKO0FBQ3ZDLE1BQUlBLFVBQVVLLFdBQVcsS0FBSyxDQUFDSCxZQUFZLENBQUNDLGFBQWEsQ0FBQ0MsUUFBUyxPQUFNLElBQUlFLFdBQVcsc0NBQXNDO0FBQzlILFFBQU1DLE9BQU9DLE9BQU9OLFFBQVEsR0FBR08sUUFBUUQsT0FBT0wsU0FBUyxHQUFHTyxNQUFNRixPQUFPSixPQUFPO0FBQzlFLE1BQUksQ0FBQ0ksT0FBT0csVUFBVUosSUFBSSxLQUFLLENBQUNDLE9BQU9HLFVBQVVGLEtBQUssS0FBSyxDQUFDRCxPQUFPRyxVQUFVRCxHQUFHLEtBQUtELFFBQVEsS0FBS0EsUUFBUSxNQUFNQyxNQUFNLEtBQUtBLE1BQU0sR0FBSSxPQUFNLElBQUlKLFdBQVcsNEJBQTRCO0FBQ3RMLFFBQU1NLFNBQVMzQixLQUFLRSxJQUFJb0IsTUFBTUUsUUFBUSxHQUFHQyxHQUFHO0FBQzVDLFFBQU1HLGFBQWEsSUFBSTVCLEtBQUsyQixNQUFNO0FBQ2xDLE1BQUlDLFdBQVd6QixlQUFlLE1BQU1tQixRQUFRTSxXQUFXeEIsWUFBWSxNQUFNb0IsUUFBUSxLQUFLSSxXQUFXQyxXQUFXLE1BQU1KLElBQUssT0FBTSxJQUFJSixXQUFXLDRCQUE0QjtBQUN4SyxNQUFJUyxVQUFVSDtBQUNkLFdBQVNJLFVBQVUsR0FBR0EsVUFBVSxHQUFHQSxXQUFXO0FBQzFDLFVBQU1DLFFBQVEsSUFBSUMsS0FBS0MsZUFBZSxTQUFTLEVBQUVDLFVBQVVyQixVQUFVUSxNQUFNLFdBQVdFLE9BQU8sV0FBV0MsS0FBSyxXQUFXVyxNQUFNLFdBQVdDLFFBQVEsV0FBV0MsUUFBUSxXQUFXQyxXQUFXLE1BQU0sQ0FBQyxFQUFFQyxjQUFjLElBQUl4QyxLQUFLOEIsT0FBTyxDQUFDO0FBQ2xPLFVBQU1XLE9BQU9BLENBQUNDLFNBQWlCO0FBQzNCLFlBQU1uQyxRQUFReUIsTUFBTVcsS0FBSyxDQUFBQyxTQUFRQSxLQUFLQyxTQUFTSCxJQUFJLEdBQUduQztBQUN0RCxVQUFJQSxVQUFVdUMsT0FBVyxPQUFNLElBQUl6QixXQUFXLDhCQUE4QnFCLElBQUksR0FBRztBQUNuRixhQUFPbkIsT0FBT2hCLEtBQUs7QUFBQSxJQUN2QjtBQUNBLFVBQU13QyxhQUFhL0MsS0FBS0UsSUFBSXVDLEtBQUssTUFBTSxHQUFHQSxLQUFLLE9BQU8sSUFBSSxHQUFHQSxLQUFLLEtBQUssR0FBR0EsS0FBSyxNQUFNLEdBQUdBLEtBQUssUUFBUSxHQUFHQSxLQUFLLFFBQVEsQ0FBQztBQUN0SFgsZUFBV0gsU0FBU29CO0FBQUFBLEVBQ3hCO0FBQ0EsU0FBTyxJQUFJL0MsS0FBSzhCLE9BQU8sRUFBRXRCLFlBQVk7QUFDekM7QUFDQSxTQUFTd0MsZUFBZWxDLFVBQWtCO0FBQUFtQyxLQUFBO0FBQ3RDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJMUYsU0FBU3FDLGtCQUFrQjtBQUNyRCxRQUFNc0QsUUFBUUMsUUFBUUgsTUFBTXhDLFFBQVF3QyxNQUFNdkMsTUFBTXVDLE1BQU14QyxPQUFPd0MsTUFBTXZDLEVBQUU7QUFDckUsU0FBTztBQUFBLElBQ0h1QztBQUFBQSxJQUNBSSxTQUFTQSxDQUFDNUMsU0FBaUJ5QyxTQUFTLENBQUFJLGFBQVksRUFBRSxHQUFHQSxTQUFTN0MsS0FBSyxFQUFFO0FBQUEsSUFDckU4QyxPQUFPQSxDQUFDN0MsT0FBZXdDLFNBQVMsQ0FBQUksYUFBWSxFQUFFLEdBQUdBLFNBQVM1QyxHQUFHLEVBQUU7QUFBQSxJQUMvRHlDO0FBQUFBLElBQ0FLLE9BQU87QUFBQSxNQUNIL0MsTUFBTTBDLFFBQVF4QyxjQUFjc0MsTUFBTXhDLE1BQU1JLFFBQVEsSUFBSTtBQUFBLE1BQ3BESCxJQUFJeUMsUUFBUXhDLGNBQWNzQyxNQUFNdkMsSUFBSUcsUUFBUSxJQUFJO0FBQUEsTUFDaERBO0FBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0o7QUFBQ21DLEdBZFFELGdCQUFjO0FBZXZCLFNBQVNVLGtCQUFrQixFQUFFUixPQUFPcEMsVUFBVXdDLFNBQVNFLE1BQW1JLEdBQUc7QUFDekwsU0FBTyx1QkFBQyxTQUFNLFdBQVcsRUFBRUcsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxLQUFLLEdBQUcsSUFBSSxFQUFFQyxJQUFJLEVBQUUsR0FDdEU7QUFBQSwyQkFBQyxhQUFVLE1BQUssUUFBTyxPQUFNLFdBQVUsT0FBT1gsTUFBTXhDLE1BQU0sVUFBVSxDQUFBb0QsVUFBU1IsUUFBUVEsTUFBTW5DLE9BQU9wQixLQUFLLEdBQUcsV0FBVyxFQUFFd0QsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxLQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNKO0FBQUEsSUFDdEosdUJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxrQkFBaUIsT0FBT2QsTUFBTXZDLElBQUksVUFBVSxDQUFBbUQsVUFBU04sTUFBTU0sTUFBTW5DLE9BQU9wQixLQUFLLEdBQUcsV0FBVyxFQUFFd0QsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlKO0FBQUEsSUFDekosdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSSxFQUFFQyxZQUFZLFNBQVMsR0FBRztBQUFBO0FBQUEsTUFBMkJuRDtBQUFBQSxNQUFTO0FBQUEsU0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRjtBQUFBLE9BSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJUDtBQUNKO0FBQUNvRCxLQU5RUjtBQU9ULFNBQVNTLGFBQWE1RCxPQUE4QjtBQUNoRCxNQUFJLENBQUMsb0JBQW9CNkQsS0FBSzdELEtBQUssRUFBRyxRQUFPO0FBQzdDLFFBQU0sQ0FBQzhELFFBQVEsSUFBSUMsV0FBVyxFQUFFLElBQUkvRCxNQUFNUyxNQUFNLEdBQUc7QUFDbkQsTUFBSSxDQUFDcUQsTUFBTyxRQUFPO0FBQ25CLFNBQU9FLE9BQU9GLEtBQUssSUFBSSxTQUFTRSxPQUFPRCxTQUFTRSxPQUFPLEdBQUcsR0FBRyxDQUFDO0FBQ2xFO0FBQ0EsU0FBU0Msc0JBQXNCbEUsT0FBZTtBQUMxQyxRQUFNbUUsU0FBU1AsYUFBYTVELEtBQUs7QUFDakMsU0FBT21FLFdBQVcsUUFBUUEsU0FBUztBQUN2QztBQUNBLFNBQVNDLFlBQVlwRSxPQUFlO0FBQ2hDLFFBQU0rRCxZQUFZL0QsUUFBUSxRQUFRcUUsU0FBUyxFQUFFQyxTQUFTLEdBQUcsR0FBRyxFQUFFQyxRQUFRLE9BQU8sRUFBRTtBQUMvRSxTQUFPLEdBQUd2RSxRQUFRLE1BQU0sR0FBRytELFdBQVcsSUFBSUEsUUFBUSxLQUFLLEVBQUU7QUFDN0Q7QUFDQSxTQUFTUyxpQkFBaUJDLE1BQW1CO0FBQ3pDLFFBQU1DLFFBQVFkLGFBQWFhLEtBQUtDLE1BQU1QLE1BQU0sR0FBR1EsU0FBU2YsYUFBYWEsS0FBS0UsT0FBT1IsTUFBTTtBQUN2RixNQUFJLENBQUNNLEtBQUtHLFVBQVVDLEtBQUssRUFBRyxRQUFPO0FBQ25DLE1BQUlILFVBQVUsUUFBUUMsV0FBVyxLQUFNLFFBQU87QUFDOUMsTUFBSUQsVUFBVSxNQUFNQyxXQUFXLEdBQUksUUFBTztBQUMxQyxNQUFJRCxRQUFRLE1BQU1DLFNBQVMsR0FBSSxRQUFPO0FBQ3RDLE1BQUksQ0FBQ0YsS0FBS0ssWUFBWUQsS0FBSyxFQUFHLFFBQU87QUFDckMsU0FBTztBQUNYO0FBQ08sZ0JBQVNFLGVBQWU7QUFBQUMsTUFBQTtBQUMzQixRQUFNLEVBQUVDLEtBQUssSUFBSWxILFNBQVM7QUFDMUIsUUFBTW1ILFNBQVN6QyxlQUFld0MsS0FBSzFFLFFBQVE7QUFDM0MsUUFBTTRFLE9BQU92SCxPQUFPLGVBQWUsRUFBRXNGLE9BQU9nQyxPQUFPaEMsTUFBTSxHQUFHZ0MsT0FBT3JDLEtBQUs7QUFDeEUsUUFBTXVDLElBQUlELEtBQUtBLE1BQU1BO0FBQ3JCLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sYUFBWSxVQUFTLGdFQUErRCxTQUFTLHVCQUFDLGFBQVUsSUFBSSxNQUFNRixLQUFLSSxFQUFFLG9CQUFvQiwwQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRCxLQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNMO0FBQUEsSUFBRSx1QkFBQyxxQkFBa0IsT0FBT0gsT0FBT3ZDLE9BQU8sVUFBVXNDLEtBQUsxRSxVQUFVLFNBQVMyRSxPQUFPbkMsU0FBUyxPQUFPbUMsT0FBT2pDLFNBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEc7QUFBQSxJQUFHaUMsT0FBT3JDLFFBQVEsdUJBQUMsY0FBVyxPQUFPc0MsTUFBT0MsZUFBSyxtQ0FBRTtBQUFBLDZCQUFDLFNBQU07QUFBQSwrQkFBQyxRQUFLLE9BQU0sZUFBYyxPQUFPLHVCQUFDLFVBQU8sT0FBT0EsRUFBRUUsWUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sZUFBYyxPQUFPLHVCQUFDLFVBQU8sT0FBT0YsRUFBRUcsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0IsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLHdCQUF1QixPQUFPLHVCQUFDLFVBQU8sT0FBT0gsRUFBRUksbUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUMsR0FBSSxRQUFNLE1BQUMsTUFBSyxnQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SDtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPSixFQUFFN0UsWUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBQXJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdVQ7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxjQUFhLGlDQUFDLE9BQUksSUFBSSxFQUFFa0YsR0FBRyxFQUFFLEdBQUc7QUFBQSwrQkFBQyxjQUFXLE9BQU0sTUFBTXhILG1CQUFTbUgsRUFBRWpGLElBQUksS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLG1CQUFtQmxDLG1CQUFTbUgsRUFBRWhGLEVBQUUsS0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLGVBQWVuQyxtQkFBU21ILEVBQUVNLElBQUksS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQWNOLEVBQUVPLFNBQVNDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFjLFVBQVMsUUFBTyxJQUFJLEVBQUVDLElBQUksRUFBRSxHQUFJRCxlQUFuQ0EsR0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlELENBQVE7QUFBQSxXQUF2UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlSLEtBQW5UO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeVQ7QUFBQSxTQUExbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrb0IsS0FBanFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcXFCLElBQWdCLHVCQUFDLFNBQU0sVUFBUyxTQUFRLHNEQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThEO0FBQUEsT0FBN2lDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc2pDO0FBQ2prQztBQUFDYixJQU5lRCxjQUFZO0FBQUEsVUFDUGhILFVBQ0YwRSxnQkFDRjdFLE1BQU07QUFBQTtBQUFBLE1BSFBtSDtBQU9ULGdCQUFTZ0IsY0FBYztBQUFBQyxNQUFBO0FBQzFCLFFBQU0sRUFBRWYsS0FBSyxJQUFJbEgsU0FBUztBQUMxQixRQUFNa0ksT0FBT3JJLE9BQU8sc0JBQXNCLEVBQUVzRixPQUFPbEYsYUFBYSxFQUFFLENBQUM7QUFDbkUsUUFBTWtJLFNBQVNySSxXQUFXLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDO0FBQ3RFLFFBQU1zSSxTQUFTdEksV0FBVyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQztBQUN0RSxRQUFNdUksT0FBT3ZJLFdBQVcsb0JBQW9CLENBQUMsc0JBQXNCLGVBQWUsaUJBQWlCLGNBQWMsQ0FBQztBQUNsSCxRQUFNd0ksVUFBVXhJLFdBQVcsdUJBQXVCLENBQUMsc0JBQXNCLGVBQWUsaUJBQWlCLGNBQWMsQ0FBQztBQUN4SCxRQUFNLENBQUN5SSxTQUFTQyxVQUFVLElBQUlySixTQUF3QixJQUFJO0FBQzFELFFBQU1zSixTQUFTNUksT0FBTyxtQkFBbUIsRUFBRTZJLE1BQU0sRUFBRUgsU0FBU0EsV0FBVyxHQUFHLEVBQUUsR0FBR3hELFFBQVF3RCxPQUFPLENBQUM7QUFDL0YsUUFBTUksZ0JBQWdCRixPQUFPckIsTUFBTUE7QUFDbkMsUUFBTSxDQUFDd0IsU0FBU0MsVUFBVSxJQUFJMUosU0FBOEIsSUFBSSxHQUFHLENBQUMySixNQUFNQyxPQUFPLElBQUk1SixTQUFTLEtBQUssR0FBRyxDQUFDNkosVUFBVUMsV0FBVyxJQUFJOUosU0FHdEgsSUFBSTtBQUNkLFFBQU0sQ0FBQytKLE1BQU1DLE9BQU8sSUFBSWhLLFNBQW9DLGNBQWMsR0FBRyxDQUFDaUssZ0JBQWdCQyxpQkFBaUIsSUFBSWxLLFNBQThDLG1CQUFtQixHQUFHLENBQUNpSCxRQUFRa0QsU0FBUyxJQUFJbkssU0FBUyxFQUFFLEdBQUcsQ0FBQ29LLFlBQVlDLGFBQWEsSUFBSXJLLFNBQVMsc0JBQXNCLEdBQUcsQ0FBQzRILGFBQWEwQyxjQUFjLElBQUl0SyxTQUFTLEVBQUU7QUFDdFUsUUFBTXVLLFFBQVFBLENBQUNDLFVBQStCO0FBQUVkLGVBQVdjLEtBQUs7QUFBR1IsWUFBUVEsT0FBT1QsUUFBUSxjQUFjO0FBQUdHLHNCQUFrQk0sT0FBT1Asa0JBQWtCLG1CQUFtQjtBQUFHRSxjQUFVSyxPQUFPdkQsT0FBT0EsVUFBVSxFQUFFO0FBQUdvRCxrQkFBY0csT0FBT0osZUFBYyxvQkFBSTdILEtBQUssR0FBRVEsWUFBWSxDQUFDO0FBQUd1SCxtQkFBZUUsT0FBTzVDLGVBQWUsRUFBRTtBQUFHZ0MsWUFBUSxJQUFJO0FBQUEsRUFBRztBQUMxVSxRQUFNYSxVQUErRDtBQUFBLElBQ2pFQyxlQUFlO0FBQUEsSUFBZ0JDLG9CQUFvQjtBQUFBLElBQWVDLFVBQVU7QUFBQSxJQUFjQyxjQUFjO0FBQUEsSUFBZ0JDLGFBQWE7QUFBQSxJQUFrQkMsWUFBWTtBQUFBLElBQWNDLG1CQUFtQjtBQUFBLElBQW9CQyxTQUFTO0FBQUEsSUFBV0MsZ0JBQWdCO0FBQUEsSUFBV0MsVUFBVTtBQUFBLElBQWlCQyxPQUFPO0FBQUEsRUFDN1M7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGNBQWEsVUFBUywyRUFBMEUsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVEsYUFBWSxTQUFTLE1BQU1iLE1BQU0sSUFBSSxHQUFHLHlCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HLEtBQTlOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ1A7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPeEIsTUFBT0EsZUFBS2QsUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsTUFBTWMsS0FBS2QsS0FBS0EsTUFBTSxRQUFRLENBQUFvRCxNQUFLQSxFQUFFbEQsSUFBSSxTQUFTO0FBQUEsVUFDL1csRUFBRW1ELEtBQUssTUFBTUMsT0FBTyxZQUFZQyxRQUFRQSxDQUFBSCxNQUFLLHVCQUFDLFVBQU8sU0FBUyxNQUFNaEMsV0FBV2dDLEVBQUVsRCxFQUFFLEdBQUlrRCxZQUFFbEQsTUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsRUFBVTtBQUFBLFVBQUcsRUFBRW1ELEtBQUssUUFBUUMsT0FBTyxRQUFRQyxRQUFRQSxDQUFBSCxNQUFLdEssU0FBU3NLLEVBQUVqQixVQUFVLEVBQUU7QUFBQSxVQUFHLEVBQUVrQixLQUFLLFFBQVFDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQUgsTUFBS1osUUFBUVksRUFBRXBCLGNBQWMsRUFBRTtBQUFBLFVBQUcsRUFBRXFCLEtBQUssVUFBVUMsT0FBTyxXQUFXQyxRQUFRQSxDQUFBSCxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRXBFLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUFHLEVBQUVxRSxLQUFLLFFBQVFDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRXpELFlBQVk7QUFBQSxVQUFHLEVBQUUwRCxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVJLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUN2ZDtBQUFBLFlBQ0lILEtBQUs7QUFBQSxZQUFVQyxPQUFPO0FBQUEsWUFBWUMsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLFNBQVMsTUFBTWhDLFdBQVdnQyxFQUFFbEQsRUFBRSxHQUFHLHdCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFVBQ3BHO0FBQUEsUUFBQyxLQUppVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3BUO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1ZLEtBQUtkLEtBQUt5RCxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FMb1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtsUixLQUwyTztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS3ZPO0FBQUEsU0FMcU47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUt4TTtBQUFBLElBQ3RELHVCQUFDLGNBQVcsTUFBTTlGLFFBQVF3RCxPQUFPLEdBQUcsT0FBT0ksZ0JBQWdCLFlBQVlBLGNBQWNyQixFQUFFLEtBQUsscUJBQXFCLFNBQVMsTUFBTWtCLFdBQVcsSUFBSSxHQUFHLFNBQVMsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLFdBQVcsSUFBSSxHQUFHLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQVcsaUNBQUMsY0FBVyxPQUFPQyxRQUFTRSwyQkFBaUIsdUJBQUMsU0FBTSxLQUFLLEdBQUc7QUFBQSw2QkFBQyxVQUFPLE9BQU9BLGNBQWNpQyxVQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU0sUUFBUWpDLHdCQUFjTyxTQUFTLFlBQVksYUFBYSxjQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sYUFBYVUsa0JBQVFqQixjQUFjUyxjQUFjLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxXQUFVLGlDQUFDLFVBQU8sT0FBT1QsY0FBY3ZDLFVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0MsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQmxHLG1CQUFTeUksY0FBY1ksVUFBVSxLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sU0FBU1osd0JBQWNtQyxZQUFZLEdBQUduQyxjQUFjbUMsVUFBVXZHLElBQUksTUFBTW9FLGNBQWNtQyxVQUFVeEQsRUFBRSxLQUFLLGNBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0k7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxhQUFhcUIsd0JBQWM1QixlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsTUFBYzRCLGNBQWNpQyxXQUFXLFdBQVcsdUJBQUMsU0FBTSxXQUFVLE9BQU0sS0FBSyxHQUFHO0FBQUEsK0JBQUMsa0JBQWUsWUFBVyxnQkFBZSxTQUFTLE1BQU1sQixNQUFNZixhQUFhLEdBQUcsd0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVMsTUFBTU0sWUFBWSxFQUFFVSxPQUFPaEIsZUFBZW9DLFFBQVEsT0FBTyxDQUFDLEdBQUcsc0JBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0g7QUFBQSxXQUE3UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThRO0FBQUEsTUFBVXBDLGNBQWNpQyxXQUFXLFlBQVksdUJBQUMsa0JBQWUsWUFBVyxnQkFBZSxTQUFTLE1BQU0zQixZQUFZLEVBQUVVLE9BQU9oQixlQUFlb0MsUUFBUSxVQUFVLENBQUMsR0FBRyx5QkFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SDtBQUFBLFNBQWhrQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtsQyxLQUEvbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3b0MsS0FBMzFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdzJDO0FBQUEsSUFDeDJDLHVCQUFDLGNBQVcsTUFBWSxPQUFPbkMsVUFBVSxtQkFBbUIscUJBQXFCLFNBQVMsTUFBTUcsUUFBUSxLQUFLLEdBQUcsTUFBTVosT0FBTzZDLFdBQVc1QyxPQUFPNEMsU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVU3QyxPQUFPNkMsV0FBVzVDLE9BQU80QyxXQUFXLENBQUMsb0JBQW9CbEYsS0FBS00sTUFBTSxLQUFLVyxZQUFZRCxLQUFLLEVBQUVoRSxTQUFTLEdBQUcsU0FBUyxZQUFZO0FBQUUsWUFBTW1JLE9BQTBCLEVBQUUvQixNQUFNRSxnQkFBZ0JoRCxRQUFRLEVBQUVBLFFBQVE4RSxVQUFVaEUsS0FBS2dFLFNBQVMsR0FBRzNCLFlBQVl4QyxhQUFhK0QsV0FBV2xDLFNBQVNrQyxhQUFhLEtBQUs7QUFBRyxVQUFJO0FBQzFlLFlBQUlsQztBQUNBLGdCQUFNUixPQUFPK0MsUUFBUSxFQUFFekMsTUFBTSxFQUFFSCxTQUFTSyxRQUFRdEIsR0FBRyxHQUFHOEQsU0FBU3hDLFFBQVF3QyxTQUFTSCxLQUFLLENBQUM7QUFBQTtBQUV0RixnQkFBTTlDLE9BQU9nRCxRQUFRLEVBQUVGLEtBQUssQ0FBQztBQUNqQ2xDLGdCQUFRLEtBQUs7QUFBQSxNQUNqQixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQTRCLEdBQUcsd0JBUHVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPL0csR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT1osT0FBT2tELFNBQVNqRCxPQUFPaUQsU0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQUUsdUJBQUMsU0FBTSxLQUFLLEdBQUc7QUFBQSwrQkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGNBQWEsT0FBT25DLE1BQU0sVUFBVSxDQUFBb0MsTUFBS25DLFFBQVFtQyxFQUFFakksT0FBT3BCLFVBQVUsWUFBWSxZQUFZLGNBQWMsR0FBRztBQUFBLGlDQUFDLFlBQVMsT0FBTSxXQUFVLHdCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQVcsdUJBQUMsWUFBUyxPQUFNLGdCQUFlLHdCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBQXpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb087QUFBQSxRQUFZLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sYUFBWSxPQUFPbUgsZ0JBQWdCLFVBQVUsQ0FBQWtDLE1BQUs7QUFBRSxnQkFBTUMsSUFBSUQsRUFBRWpJLE9BQU9wQjtBQUFPLGNBQUlzSixLQUFLM0I7QUFDdmRQLDhCQUFrQmtDLENBQXdDO0FBQUEsUUFBRyxHQUFJQyxpQkFBT0MsUUFBUTdCLE9BQU8sRUFBRS9CLElBQUksQ0FBQyxDQUFDMEQsR0FBR0csQ0FBQyxNQUFNLHVCQUFDLFlBQWlCLE9BQU9ILEdBQUlHLGVBQWRILEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQixDQUFXLEtBRHFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFDbk47QUFBQSxRQUFZLHVCQUFDLGFBQVUsT0FBTyxZQUFZckUsS0FBS2dFLFFBQVEsS0FBSyxPQUFPOUUsUUFBUSxVQUFVLENBQUFrRixNQUFLaEMsVUFBVWdDLEVBQUVqSSxPQUFPcEIsS0FBSyxHQUFHLFlBQVksRUFBRTBKLFdBQVcsVUFBVSxLQUE1STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThJO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sc0JBQXFCLE9BQU9wQyxZQUFZLFVBQVUsQ0FBQStCLE1BQUs5QixjQUFjOEIsRUFBRWpJLE9BQU9wQixLQUFLLEdBQUcsWUFBVyw4REFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0SztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLGFBQVksV0FBUyxNQUFDLFNBQVMsR0FBRyxPQUFPOEUsYUFBYSxVQUFVLENBQUF1RSxNQUFLN0IsZUFBZTZCLEVBQUVqSSxPQUFPcEIsS0FBSyxLQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFIO0FBQUEsUUFBRSx1QkFBQyxTQUFNLFVBQVMsUUFBTyx5RkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRztBQUFBLFdBRDdrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQ3FsQjtBQUFBLFNBUnJzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUTZzQjtBQUFBLElBQzdzQix1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQytHLFVBQVUsT0FBT0EsVUFBVStCLFdBQVcsU0FBUyx5QkFBeUIsb0JBQW9CLGFBQWEsR0FBRy9CLFVBQVVXLE1BQU1yQyxNQUFNLEVBQUUsTUFBTW5ILFlBQVk2SSxVQUFVVyxNQUFNdkQsTUFBTSxDQUFDLGtEQUFrRCxlQUFhLE1BQUMsU0FBUyxNQUFNNkMsWUFBWSxJQUFJLEdBQUcsTUFBTVosS0FBSzJDLFdBQVcxQyxRQUFRMEMsU0FBUyxPQUFPM0MsS0FBS2dELFNBQVMvQyxRQUFRK0MsT0FBTyxXQUFXLENBQUFPLFdBQVU1QyxVQUFVK0IsV0FBVyxTQUFTMUMsS0FBSzhDLFFBQVEsRUFBRXpDLE1BQU0sRUFBRUgsU0FBU1MsU0FBU1csTUFBTXJDLEdBQUcsR0FBRzJELE1BQU0sRUFBRVksaUJBQWlCN0MsU0FBU1csTUFBTXlCLFNBQVNRLE9BQU8sRUFBRSxDQUFDLElBQUl0RCxRQUFRNkMsUUFBUSxFQUFFekMsTUFBTSxFQUFFSCxTQUFTUyxVQUFVVyxNQUFNckMsTUFBTSxHQUFHLEdBQUcyRCxNQUFNLEVBQUVZLGlCQUFpQjdDLFVBQVVXLE1BQU15QixXQUFXLEdBQUdRLE9BQU8sRUFBRSxDQUFDLEtBQXhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBwQjtBQUFBLE9BaEJocEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCa3BCO0FBQzdwQjtBQUFDM0QsSUFwQ2VELGFBQVc7QUFBQSxVQUNOaEksVUFDSkgsUUFBc0NJLGNBQ3BDSCxZQUNBQSxZQUNGQSxZQUNHQSxZQUVERCxNQUFNO0FBQUE7QUFBQSxNQVJUbUk7QUFxQ1QsZ0JBQVM4RCxpQkFBaUI7QUFBQUMsTUFBQTtBQUM3QixRQUFNLEVBQUU3RSxLQUFLLElBQUlsSCxTQUFTO0FBQzFCLFFBQU1tSCxTQUFTekMsZUFBZXdDLEtBQUsxRSxRQUFRO0FBQzNDLFFBQU00RSxPQUFPdkgsT0FBTyxpQkFBaUIsRUFBRXNGLE9BQU9nQyxPQUFPaEMsTUFBTSxHQUFHZ0MsT0FBT3JDLEtBQUs7QUFDMUUsUUFBTTRDLElBQUlOLEtBQUtBLE1BQU1BO0FBQ3JCLFFBQU0sQ0FBQzRFLFVBQVVDLFdBQVcsSUFBSTlNLFNBQStCLFNBQVM7QUFDeEUsUUFBTSxDQUFDK00sY0FBY0MsZUFBZSxJQUFJaE4sU0FBUyxFQUFFO0FBQ25ELFFBQU1pTixhQUFhMUUsSUFBSSxHQUFHUCxPQUFPdkMsTUFBTXhDLElBQUksSUFBSStFLE9BQU92QyxNQUFNdkMsRUFBRSxJQUFJcUYsRUFBRUMsSUFBSSxJQUFJcUUsUUFBUSxLQUFLO0FBQ3pGLFFBQU1LLGNBQWMzRSxLQUFLd0UsaUJBQWlCRSxhQUFhL0ssa0JBQWtCcUcsR0FBR3NFLFFBQVEsSUFBSTtBQUN4RixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHNCQUFxQixVQUFTLHdGQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9JO0FBQUEsSUFBRSx1QkFBQyxxQkFBa0IsT0FBTzdFLE9BQU92QyxPQUFPLFVBQVVzQyxLQUFLMUUsVUFBVSxTQUFTLENBQUFQLFVBQVM7QUFBRWtLLHNCQUFnQixFQUFFO0FBQUdoRixhQUFPbkMsUUFBUS9DLEtBQUs7QUFBQSxJQUFHLEdBQUcsT0FBTyxDQUFBQSxVQUFTO0FBQUVrSyxzQkFBZ0IsRUFBRTtBQUFHaEYsYUFBT2pDLE1BQU1qRCxLQUFLO0FBQUEsSUFBRyxLQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtNO0FBQUEsSUFBR2tGLE9BQU9yQyxRQUFRLHVCQUFDLGNBQVcsT0FBT3NDLE1BQU9NLGVBQUssbUNBQUU7QUFBQSw2QkFBQyxTQUFNO0FBQUEsK0JBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPLHVCQUFDLFVBQU8sT0FBT0EsRUFBRTRFLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEIsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLFdBQVUsT0FBTyx1QkFBQyxVQUFPLE9BQU81RSxFQUFFNkUsUUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQixLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNEO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sV0FBVSxPQUFPLHVCQUFDLFVBQU8sT0FBTzdFLEVBQUU4RSxlQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCLEdBQUksUUFBTSxRQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sc0JBQXFCLE9BQU8sdUJBQUMsVUFBTyxPQUFPOUUsRUFBRStFLG1CQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDLEdBQUksTUFBSywwQ0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3SDtBQUFBLFdBQWpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbVU7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSwrQkFBOEIsUUFBUSx1QkFBQyxVQUFPLE9BQU8vRSxFQUFFZ0YsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEIsR0FBSSxpQ0FBQyxPQUFJLElBQUksRUFBRWhGLEdBQUcsRUFBRSxHQUFJO0FBQUE7QUFBQSxVQUNwekIsQ0FBQyxpQkFBaUJBLEVBQUVpRixVQUFVO0FBQUEsVUFBRyxDQUFDLFlBQVlqRixFQUFFa0YsU0FBUztBQUFBLFVBQUcsQ0FBQyxvQkFBb0JsRixFQUFFbUYsWUFBWTtBQUFBLFVBQUcsQ0FBQyxtQkFBbUJuRixFQUFFNEUsUUFBUTtBQUFBLFVBQUcsQ0FBQyxXQUFXNUUsRUFBRTZFLElBQUk7QUFBQSxVQUFHLENBQUMsZ0JBQWdCN0UsRUFBRW9GLGNBQWM7QUFBQSxVQUFHLENBQUMsZ0JBQWdCcEYsRUFBRXFGLGVBQWU7QUFBQSxVQUFHLENBQUMsZ0JBQWdCckYsRUFBRXNGLFlBQVk7QUFBQSxVQUFHLENBQUMsa0JBQWtCdEYsRUFBRXVGLFdBQVc7QUFBQSxVQUFHLENBQUMsY0FBY3ZGLEVBQUV3RixTQUFTO0FBQUEsVUFBRyxDQUFDLGdCQUFnQnhGLEVBQUV5RixzQkFBc0I7QUFBQSxRQUFDLEVBQy9XdEYsSUFBSSxDQUFDLENBQUM2RCxHQUFHSCxDQUFDLE1BQU0sdUJBQUMsY0FBMkIsT0FBTzZCLE9BQU8xQixDQUFDLEdBQUcsaUNBQUMsVUFBTyxPQUFPLE9BQU9ILE1BQU0sV0FBV0EsSUFBSSxRQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdELEtBQTdFNkIsT0FBTzFCLENBQUMsR0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRyxDQUFhO0FBQUEsUUFBRSx1QkFBQyxjQUFXLE9BQU0sY0FBY2hFLFlBQUUyRixpQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLGVBQWVuTixtQkFBU3dILEVBQUVDLElBQUksS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQWNELEVBQUVFLFNBQVNDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFjLFVBQVMsV0FBVSxJQUFJLEVBQUVDLElBQUksRUFBRSxHQUFJRCxlQUF0Q0EsR0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9ELENBQVE7QUFBQSxXQUZzZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXBkLEtBRitYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFelg7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxvQkFBbUIsVUFBUyx5REFDbFl3RixxQkFBVyx1QkFBQyxTQUFNLEtBQUssR0FBRyxJQUFJLEVBQUU1RixHQUFHLEVBQUUsR0FDbEM7QUFBQSwrQkFBQyxTQUFNLFVBQVMsUUFBTyxrSUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5STtBQUFBLFFBQ3pJLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sc0JBQXFCLE9BQU9zRSxVQUFVLFVBQVUsQ0FBQXhHLFVBQVM7QUFBRXlHLHNCQUFZekcsTUFBTW5DLE9BQU9wQixLQUE2QjtBQUFHa0ssMEJBQWdCLEVBQUU7QUFBQSxRQUFHLEdBQzVKN0ssOEJBQW9CdUcsSUFBSSxDQUFBdkQsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLZ0QsSUFBS2hELGVBQUtvRyxTQUEvQnBHLEtBQUtnRCxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9ELENBQVcsS0FEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTLE1BQU02RSxnQkFBZ0JDLFVBQVUsR0FBRyxVQUFVLENBQUNBLFlBQVksdUNBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0g7QUFBQSxRQUNySEMsZUFBZSx1QkFBQyxPQUFJLE1BQUssVUFBUyxjQUFXLCtCQUE4QixlQUFZLDJCQUEwQixJQUFJLEVBQUUzRSxHQUFHLEdBQUc2RixRQUFRLEdBQUdDLGFBQWEsV0FBV0MsY0FBYyxFQUFFLEdBQzdLO0FBQUEsaUNBQUMsY0FBVyxJQUFJLEVBQUVsSSxJQUFJLEVBQUUsR0FBSThHLHNCQUFZcUIsVUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUMvQyx1QkFBQyxjQUFXLFNBQVEsYUFBWSxJQUFJLEVBQUVuSSxJQUFJLEVBQUUsR0FBRyw0Q0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkU7QUFBQSxVQUMxRThHLFlBQVlzQixRQUFROUYsSUFBSSxDQUFBK0YsV0FBVSx1QkFBQyxjQUE4QixPQUFPQSxPQUFPbEQsT0FBUWtELGlCQUFPM0wsU0FBM0MyTCxPQUFPbEQsT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0UsQ0FBYTtBQUFBLFVBQ2pIMkIsWUFBWXpFLFNBQVNDLElBQUksQ0FBQ2dHLFNBQVNDLFVBQVUsdUJBQUMsU0FBa0MsVUFBUyxXQUFVLElBQUksRUFBRS9GLElBQUksRUFBRSxHQUFJOEYscUJBQTFELEdBQUdDLEtBQUssSUFBSUQsT0FBTyxJQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RSxDQUFRO0FBQUEsVUFDcEksdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSSxFQUFFOUYsSUFBSSxFQUFFLEdBQUcsb0hBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBJO0FBQUEsYUFMOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1oQjtBQUFBLFdBWlE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFaLElBQVcsdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSSxFQUFFZ0csR0FBRyxFQUFFLEdBQUcsK0dBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0ksS0FkMk07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWU5VjtBQUFBLFNBakJrWTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUIxWCxLQWpCMlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCdlYsSUFBZ0IsdUJBQUMsU0FBTSxVQUFTLFNBQVEsc0RBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxPQWpCbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCNEY7QUFDdkc7QUFBQ2hDLElBM0JlRCxnQkFBYztBQUFBLFVBQ1Q5TCxVQUNGMEUsZ0JBQ0Y3RSxNQUFNO0FBQUE7QUFBQSxNQUhQaU07QUE0QmhCLFNBQVNrQyxvQkFBb0IsRUFBRUYsT0FBTzdMLE9BQU9nTSxTQUFrRixHQUFHO0FBQzlILE1BQUlYLFNBQVUsUUFBTyx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFPLGtCQUFrQlEsS0FBSyxJQUFJLFdBQVMsTUFBQyxPQUFjLE9BQU8sQ0FBQzdMLE1BQU02RSxLQUFLLEdBQUcsWUFBWTdFLFFBQVEsc0ZBQXNGLDhDQUE4QyxVQUFVLENBQUF1RCxVQUFTeUksU0FBU3pJLE1BQU1uQyxPQUFPcEIsS0FBSyxHQUN6VDtBQUFBLDJCQUFDLFlBQVMsT0FBTSxJQUFHLGtDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFDcENWLG9CQUFvQnNHLElBQUksQ0FBQXFHLFlBQVcsdUJBQUMsWUFBMEIsT0FBT0EsUUFBUTVHLElBQUs0RyxrQkFBUXhELFNBQXhDd0QsUUFBUTVHLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkQsQ0FBVztBQUFBLE9BRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHckI7QUFDQSxTQUFPLHVCQUFDLGFBQVUsT0FBTyxrQkFBa0J3RyxLQUFLLElBQUksV0FBUyxNQUFDLE9BQWMsT0FBTyxDQUFDN0wsTUFBTTZFLEtBQUssR0FBRyxZQUFZLENBQUM3RSxNQUFNNkUsS0FBSyxJQUFJLGlFQUFpRSxJQUFJLFVBQVUsQ0FBQXRCLFVBQVN5SSxTQUFTekksTUFBTW5DLE9BQU9wQixLQUFLLEtBQTFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNE87QUFDdlA7QUFBQ2tNLE1BTlFIO0FBUUYsZ0JBQVNJLGVBQWU7QUFBQUMsTUFBQTtBQUMzQixRQUFNLEVBQUVuSCxLQUFLLElBQUlsSCxTQUFTO0FBQzFCLFFBQU1rSSxPQUFPckksT0FBTyxnQkFBZ0IsRUFBRXNGLE9BQU9sRixhQUFhLEVBQUUsQ0FBQztBQUM3RCxRQUFNLENBQUNxTyxRQUFRQyxTQUFTLElBQUlwUCxTQUF3QixJQUFJO0FBQ3hELFFBQU1zSixTQUFTNUksT0FBTyxjQUFjLEVBQUU2SSxNQUFNLEVBQUU4RixZQUFZRixVQUFVLEdBQUcsRUFBRSxHQUFHdkosUUFBUXVKLE1BQU0sQ0FBQztBQUMzRixRQUFNRyxnQkFBZ0JoRyxPQUFPckIsTUFBTUE7QUFDbkMsUUFBTXNILFVBQVU3TyxPQUFPLHVCQUF1QjtBQUM5QyxRQUFNc0ksU0FBU3JJLFdBQVcsaUJBQWlCLENBQUMsY0FBYyxDQUFDO0FBQzNELFFBQU11SSxPQUFPdkksV0FBVyxlQUFlLENBQUMsY0FBYyxDQUFDO0FBQ3ZELFFBQU13SSxVQUFVeEksV0FBVyxrQkFBa0IsQ0FBQyxjQUFjLENBQUM7QUFDN0QsUUFBTSxDQUFDZ0osTUFBTUMsT0FBTyxJQUFJNUosU0FBUyxLQUFLLEdBQUcsQ0FBQzZKLFVBQVVDLFdBQVcsSUFBSTlKLFNBQWtFLElBQUksR0FBRyxDQUFDd1AsWUFBWUMsYUFBYSxJQUFJelAsU0FBUyxRQUFRLEdBQUcsQ0FBQzBQLFVBQVVDLFdBQVcsSUFBSTNQLFNBQVMsRUFBRSxHQUFHLENBQUNvRCxNQUFNd00sT0FBTyxJQUFJNVAsU0FBUyxZQUFZLEdBQUcsQ0FBQ3lNLFFBQVFvRCxTQUFTLElBQUk3UCxTQUFTLEVBQUU7QUFDalQsUUFBTThQLFVBQVVBLE9BQW9CLEVBQUVwSSxXQUFXLElBQUlGLE9BQU8sRUFBRVAsUUFBUSxLQUFLOEUsVUFBVWhFLEtBQUtnRSxTQUFTLEdBQUd0RSxRQUFRLEVBQUVSLFFBQVEsS0FBSzhFLFVBQVVoRSxLQUFLZ0UsU0FBUyxHQUFHbkUsYUFBYSxHQUFHO0FBQ3hLLFFBQU0sQ0FBQ21JLE9BQU9DLFFBQVEsSUFBSWhRLFNBQXdCLENBQUM4UCxRQUFRLEdBQUdBLFFBQVEsQ0FBQyxDQUFDO0FBQ3hFLFFBQU1HLGFBQWFGLE1BQU1ySCxJQUFJcEIsZ0JBQWdCO0FBQzdDLFFBQU00SSxhQUFhSCxNQUFNSSxPQUFPLENBQUNDLE9BQU83SSxTQUFTNkksU0FBUzFKLGFBQWFhLEtBQUtDLE1BQU1QLE1BQU0sS0FBSyxLQUFLLEVBQUU7QUFDcEcsUUFBTW9KLGNBQWNOLE1BQU1JLE9BQU8sQ0FBQ0MsT0FBTzdJLFNBQVM2SSxTQUFTMUosYUFBYWEsS0FBS0UsT0FBT1IsTUFBTSxLQUFLLEtBQUssRUFBRTtBQUN0RyxRQUFNcUosU0FBU2YsUUFBUXRILE1BQU1BLEtBQUsvQyxLQUFLLENBQUFDLFNBQVEvQixRQUFRK0IsS0FBS29MLGFBQWFuTixRQUFRK0IsS0FBS3FMLE9BQU87QUFDN0YsUUFBTUMsYUFBYUgsUUFBUUksVUFBVTtBQUNyQyxRQUFNQyxXQUFXWixNQUFNcE0sVUFBVSxLQUFLc00sV0FBV1csTUFBTSxDQUFBMUUsVUFBUyxDQUFDQSxLQUFLLEtBQUtnRSxlQUFlRyxlQUFlSCxhQUFhO0FBQ3RILFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sWUFBVyxVQUFTLGlGQUFnRixTQUFTLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUSxhQUFZLFNBQVMsTUFBTXRHLFFBQVEsSUFBSSxHQUFHLGlDQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZHLEtBQTVPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOFA7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPYixNQUFPQSxlQUFLZCxRQUFRLG1DQUFFO0FBQUEsK0JBQUMsYUFBVSxNQUFNYyxLQUFLZCxLQUFLQSxNQUFNLFFBQVEsQ0FBQTRJLFlBQVdBLFFBQVExSSxJQUFJLFNBQVM7QUFBQSxVQUN4WSxFQUFFbUQsS0FBSyxNQUFNQyxPQUFPLFlBQVlDLFFBQVFBLENBQUFxRixZQUFXLHVCQUFDLFVBQU8sU0FBUyxNQUFNekIsVUFBVXlCLFFBQVExSSxFQUFFLEdBQUkwSSxrQkFBUTFJLE1BQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBELEVBQVU7QUFBQSxVQUN2SCxFQUFFbUQsS0FBSyxRQUFRQyxPQUFPLGlCQUFpQkMsUUFBUUEsQ0FBQXFGLFlBQVdBLFFBQVFDLGNBQWM7QUFBQSxVQUNoRixFQUFFeEYsS0FBSyxVQUFVQyxPQUFPLFNBQVNDLFFBQVFBLENBQUFxRixZQUFXLEdBQUdBLFFBQVFyQixVQUFVLE1BQU1xQixRQUFRbkIsUUFBUSxHQUFHO0FBQUEsVUFDbEcsRUFBRXBFLEtBQUssU0FBU0MsT0FBTyxjQUFjQyxRQUFRQSxDQUFBcUYsWUFBVyx1QkFBQyxVQUFPLE9BQU9BLFFBQVFwRixVQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QixFQUFHO0FBQUEsVUFDekYsRUFBRUgsS0FBSyxXQUFXQyxPQUFPLElBQUlDLFFBQVFBLENBQUFxRixZQUFXLHVCQUFDLFVBQU8sU0FBUyxNQUFNekIsVUFBVXlCLFFBQVExSSxFQUFFLEdBQUcsd0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNELEVBQVU7QUFBQSxRQUFDLEtBTDhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNalU7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTVksS0FBS2QsS0FBS3lELFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQU5pUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTS9SLEtBTndQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNcFA7QUFBQSxTQU5tTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTXROO0FBQUEsSUFDbkQsdUJBQUMsY0FBVyxNQUFNOUYsUUFBUXVKLE1BQU0sR0FBRyxPQUFPRyxnQkFBZ0IsWUFBWUEsY0FBY25ILEVBQUUsS0FBSyxxQkFBcUIsU0FBUyxNQUFNaUgsVUFBVSxJQUFJLEdBQUcsU0FBUyx1QkFBQyxVQUFPLFNBQVMsTUFBTUEsVUFBVSxJQUFJLEdBQUcsb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEMsR0FBVyxpQ0FBQyxjQUFXLE9BQU85RixRQUFTZ0csMkJBQWlCLG1DQUFFO0FBQUEsNkJBQUMsVUFBTyxPQUFPQSxjQUFjN0QsVUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQUUsdUJBQUMsYUFBVSxNQUFNNkQsY0FBY1MsTUFBTXJILElBQUksQ0FBQ25CLE1BQU1vSCxXQUFXLEVBQUUsR0FBR3BILE1BQU0rRCxLQUFLMkMsT0FBT1UsS0FBSyxFQUFFLEVBQUUsR0FBRyxRQUFRLENBQUFwSCxTQUFRQSxLQUFLK0QsS0FBSyxTQUFTO0FBQUEsUUFDbGEsRUFBRUEsS0FBSyxXQUFXQyxPQUFPLGFBQWFDLFFBQVFBLENBQUFqRSxTQUFRQSxLQUFLRyxVQUFVO0FBQUEsUUFDckUsRUFBRTRELEtBQUssU0FBU0MsT0FBTyxNQUFNQyxRQUFRQSxDQUFBakUsU0FBUSx1QkFBQyxVQUFPLE9BQU9BLEtBQUtDLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEIsRUFBRztBQUFBLFFBQzFFLEVBQUU4RCxLQUFLLFVBQVVDLE9BQU8sTUFBTUMsUUFBUUEsQ0FBQWpFLFNBQVEsdUJBQUMsVUFBTyxPQUFPQSxLQUFLRSxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCLEVBQUc7QUFBQSxRQUM1RSxFQUFFNkQsS0FBSyxRQUFRQyxPQUFPLGFBQWFDLFFBQVFBLENBQUFqRSxTQUFRQSxLQUFLSyxZQUFZO0FBQUEsTUFBQyxLQUo0TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS25TO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU0sY0FBYzBILHdCQUFjcEIsaUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxnQkFBZ0JvQix3QkFBY3lCLGNBQWMsT0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BQWN6QixjQUFjN0QsV0FBVyxXQUFXLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUyxNQUFNM0IsWUFBWSxFQUFFK0csU0FBU3ZCLGVBQWUxRCxRQUFRLE9BQU8sQ0FBQyxHQUFHLHNCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdIO0FBQUEsTUFBbUIwRCxjQUFjN0QsV0FBVyxZQUFZLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUyxNQUFNM0IsWUFBWSxFQUFFK0csU0FBU3ZCLGVBQWUxRCxRQUFRLFVBQVUsQ0FBQyxHQUFHLDRCQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlJO0FBQUEsU0FMclA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUt1USxLQUxwVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3dULEtBTHhnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3FoQjtBQUFBLElBQ3JoQix1QkFBQyxjQUFXLE1BQVksT0FBTSxpQkFBZ0IsU0FBUyxNQUFNaEMsUUFBUSxLQUFLLEdBQUcsTUFBTVosT0FBTzZDLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUM2RCxTQUFTL0gsS0FBSyxLQUFLOEUsT0FBTzlFLEtBQUssRUFBRWhFLFNBQVMsS0FBS3FGLE9BQU82QyxXQUFXLENBQUM4RSxZQUFZLENBQUNGLFlBQVksU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUFFLGNBQU16SCxPQUFPZ0QsUUFBUSxFQUFFRixNQUFNLEVBQUUwRCxZQUFZRSxVQUFVb0IsZUFBZTFOLE1BQU0yTSxPQUFPdEQsT0FBTyxFQUFFLENBQUM7QUFBRzdDLGdCQUFRLEtBQUs7QUFBQSxNQUFHLFFBQVE7QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyx3QkFBMVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrVCxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPWixPQUFPa0QsU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQUUsdUJBQUMsU0FBTSxLQUFLLEdBQUc7QUFBQSwrQkFBQyxTQUFNLFVBQVMsUUFBUWlDLHFCQUFXLHlHQUF5RywwRkFBNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTztBQUFBLFFBQVEsdUJBQUMsYUFBVSxPQUFNLHVCQUFzQixPQUFPcUIsWUFBWSxVQUFVLENBQUFuSixVQUFTb0osY0FBY3BKLE1BQU1uQyxPQUFPcEIsS0FBSyxLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0scUJBQW9CLE9BQU80TSxVQUFVLFVBQVUsQ0FBQXJKLFVBQVNzSixZQUFZdEosTUFBTW5DLE9BQU9wQixLQUFLLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUFFLHVCQUFDLGFBQVUsTUFBSyxRQUFPLE9BQU0saUJBQWdCLE9BQU9NLE1BQU0sVUFBVSxDQUFBaUQsVUFBU3VKLFFBQVF2SixNQUFNbkMsT0FBT3BCLEtBQUssR0FBRyxXQUFXLEVBQUV3RCxZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFDLEtBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUo7QUFBQSxRQUFHZ0osUUFBUXlCLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sK0NBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0QsSUFBVyx1QkFBQyxTQUFNLFVBQVVQLGFBQWEsWUFBWSxXQUFZSCxtQkFBU0csYUFBYSxNQUFNSCxPQUFPQyxTQUFTLE1BQU1ELE9BQU9FLE9BQU8sY0FBYyxNQUFNRixPQUFPQyxTQUFTLE1BQU1ELE9BQU9FLE9BQU8sbURBQW1ELG9EQUFqTztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtSO0FBQUEsUUFBVVQsTUFBTXJILElBQUksQ0FBQ25CLE1BQU1vSCxVQUFVLHVCQUFDLE9BQWdCLElBQUksRUFBRXBHLEdBQUcsR0FBRzZGLFFBQVEsR0FBR0MsYUFBYTRCLFdBQVd0QixLQUFLLElBQUksZUFBZSxXQUFXTCxjQUFjLEVBQUUsR0FBRztBQUFBLGlDQUFDLHVCQUFvQixPQUFPSyxRQUFRLEdBQUcsT0FBT3BILEtBQUtHLFdBQVcsVUFBVSxDQUFBQSxjQUFhc0ksU0FBUyxDQUFBbEssWUFBV0EsUUFBUTRDLElBQUksQ0FBQ3ZELE1BQU04TCxjQUFjQSxjQUFjdEMsUUFBUSxFQUFFLEdBQUd4SixNQUFNdUMsVUFBVSxJQUFJdkMsSUFBSSxDQUFDLEtBQTlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdNO0FBQUEsVUFBRSx1QkFBQyxTQUFNLFdBQVUsT0FBTSxLQUFLLEdBQUcsSUFBSSxFQUFFK0wsSUFBSSxJQUFJLEdBQUssV0FBQyxTQUFTLFFBQVEsRUFBWXhJLElBQUksQ0FBQXlJLFNBQVEsdUJBQUMsYUFBcUIsT0FBT0EsU0FBUyxVQUFVLE9BQU8sTUFBTSxPQUFPNUosS0FBSzRKLElBQUksRUFBRWxLLFFBQVEsT0FBT1AsYUFBYWEsS0FBSzRKLElBQUksRUFBRWxLLE1BQU0sTUFBTSxTQUFTa0ssU0FBUyxVQUFVekssYUFBYWEsS0FBS0UsT0FBT1IsTUFBTSxJQUFJUCxhQUFhYSxLQUFLQyxNQUFNUCxNQUFNLE9BQU8sTUFBTSxZQUFZUCxhQUFhYSxLQUFLNEosSUFBSSxFQUFFbEssTUFBTSxNQUFNLE9BQU8sdUNBQXVDLElBQUksWUFBWSxFQUFFdUYsV0FBVyxVQUFVLEdBQUcsVUFBVSxDQUFBbkcsVUFBUzJKLFNBQVMsQ0FBQWxLLFlBQVdBLFFBQVE0QyxJQUFJLENBQUN2RCxNQUFNOEwsY0FBY0EsY0FBY3RDLFFBQVEsRUFBRSxHQUFHeEosTUFBTSxDQUFDZ00sSUFBSSxHQUFHLEVBQUVsSyxRQUFRWixNQUFNbkMsT0FBT3BCLE9BQU9pSixVQUFVaEUsS0FBS2dFLFNBQVMsRUFBRSxJQUFJNUcsSUFBSSxDQUFDLEtBQXRoQmdNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdpQixDQUFFLEtBQXRvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3b0I7QUFBQSxVQUFRLHVCQUFDLGFBQVUsT0FBTSxrQkFBaUIsV0FBUyxNQUFDLE9BQU81SixLQUFLSyxhQUFhLE9BQU8sQ0FBQ0wsS0FBS0ssWUFBWUQsS0FBSyxHQUFHLFlBQVksQ0FBQ0osS0FBS0ssWUFBWUQsS0FBSyxJQUFJLDZCQUE2QixJQUFJLFVBQVUsQ0FBQXRCLFVBQVMySixTQUFTLENBQUFsSyxZQUFXQSxRQUFRNEMsSUFBSSxDQUFDdkQsTUFBTThMLGNBQWNBLGNBQWN0QyxRQUFRLEVBQUUsR0FBR3hKLE1BQU15QyxhQUFhdkIsTUFBTW5DLE9BQU9wQixNQUFNLElBQUlxQyxJQUFJLENBQUMsS0FBaFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa1U7QUFBQSxVQUFHOEssV0FBV3RCLEtBQUssS0FBSyx1QkFBQyxTQUFNLFVBQVMsV0FBVSxJQUFJLEVBQUUvRixJQUFJLEVBQUUsR0FBSXFILHFCQUFXdEIsS0FBSyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQVMsdUJBQUMsVUFBTyxVQUFVb0IsTUFBTXBNLFVBQVUsR0FBRyxTQUFTLE1BQU1xTSxTQUFTLENBQUFsSyxZQUFXQSxRQUFRc0wsT0FBTyxDQUFDQyxHQUFHSixjQUFjQSxjQUFjdEMsS0FBSyxDQUFDLEdBQUcsdUJBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVJO0FBQUEsYUFBcCtDQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdS9DLENBQU07QUFBQSxRQUFFLHVCQUFDLFVBQU8sU0FBUyxNQUFNcUIsU0FBUyxDQUFBbEssWUFBVyxDQUFDLEdBQUdBLFNBQVNnSyxRQUFRLENBQUMsQ0FBQyxHQUFHLHlCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFBUyx1QkFBQyxTQUFNLFVBQVVhLFdBQVcsWUFBWSxXQUFXO0FBQUE7QUFBQSxVQUFTekosWUFBWWdKLFVBQVU7QUFBQSxVQUFFO0FBQUEsVUFBRW5JLEtBQUtnRTtBQUFBQSxVQUFTO0FBQUEsVUFBWTdFLFlBQVltSixXQUFXO0FBQUEsVUFBRTtBQUFBLFVBQUV0SSxLQUFLZ0U7QUFBQUEsVUFBVTRFLFdBQVcsbUJBQW1CO0FBQUEsYUFBeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxTztBQUFBLFFBQVEsdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBT2xFLFFBQVEsVUFBVSxDQUFBcEcsVUFBU3dKLFVBQVV4SixNQUFNbkMsT0FBT3BCLEtBQUssS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBQXQ1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXc1RjtBQUFBLFNBQXAyRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTQyRztBQUFBLElBQzUyRyx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQytHLFVBQVUsT0FBT0EsVUFBVStCLFdBQVcsU0FBUyxvQkFBb0IsZ0JBQWdCLGFBQVkscUVBQW9FLGVBQWUvQixVQUFVK0IsV0FBVyxXQUFXLFNBQVMsTUFBTTlCLFlBQVksSUFBSSxHQUFHLE9BQU9aLEtBQUtnRCxTQUFTL0MsUUFBUStDLE9BQU8sTUFBTWhELEtBQUsyQyxXQUFXMUMsUUFBUTBDLFNBQVMsV0FBVyxDQUFBeUYsa0JBQWlCekgsVUFBVStCLFdBQVcsU0FBUzFDLEtBQUs4QyxRQUFRLEVBQUV6QyxNQUFNLEVBQUU4RixZQUFZeEYsU0FBU2dILFFBQVExSSxHQUFHLEdBQUcyRCxNQUFNLEVBQUVZLGlCQUFpQjdDLFNBQVNnSCxRQUFRNUUsUUFBUSxFQUFFLENBQUMsSUFBSTlDLFFBQVE2QyxRQUFRLEVBQUV6QyxNQUFNLEVBQUU4RixZQUFZeEYsVUFBVWdILFFBQVExSSxNQUFNLEdBQUcsR0FBRzJELE1BQU0sRUFBRVksaUJBQWlCN0MsVUFBVWdILFFBQVE1RSxXQUFXLEdBQUdRLFFBQVE2RSxjQUFjLEVBQUUsQ0FBQyxLQUF6cEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEycEI7QUFBQSxPQWRwcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNzcEI7QUFDanFCO0FBQUNwQyxJQWxDZUQsY0FBWTtBQUFBLFVBQ1BwTyxVQUNKSCxRQUFnQ0ksY0FFOUJKLFFBRUNBLFFBQ0RDLFlBQ0ZBLFlBQ0dBLFVBQVU7QUFBQTtBQUFBLE1BVGRzTztBQW9DVCxnQkFBU3NDLHFCQUFxQjtBQUFBQyxNQUFBO0FBQ2pDLFFBQU0sRUFBRXpKLEtBQUssSUFBSWxILFNBQVM7QUFDMUIsUUFBTSxDQUFDNFEsS0FBS0MsTUFBTSxJQUFJMVIsU0FBUyxDQUFDO0FBQ2hDLFFBQU0yUixRQUFRalIsT0FBTyx3QkFBd0IsRUFBRXNGLE9BQU9sRixhQUFhLFlBQVksRUFBRSxDQUFDO0FBQ2xGLFFBQU04USxNQUFNbFIsT0FBTyxzQkFBc0IsRUFBRXNGLE9BQU9sRixhQUFhLFdBQVcsRUFBRSxDQUFDO0FBQzdFLFFBQU0rUSxRQUFRblIsT0FBTywyQkFBMkIsRUFBRXNGLE9BQU9sRixhQUFhLFlBQVksRUFBRSxDQUFDO0FBQ3JGLFFBQU1nUixRQUFRblIsV0FBVyxzQkFBc0IsQ0FBQyxzQkFBc0Isd0JBQXdCLGlCQUFpQixhQUFhLENBQUM7QUFDN0gsUUFBTW9SLFlBQVlwUixXQUFXLG1CQUFtQixDQUFDLDJCQUEyQix3QkFBd0IsZUFBZSxDQUFDO0FBQ3BILFFBQU0sQ0FBQ2tKLFVBQVVDLFdBQVcsSUFBSTlKLFNBQStCLElBQUksR0FBRyxDQUFDZ1MsVUFBVUMsT0FBTyxJQUFJalMsU0FBb0MsSUFBSSxHQUFHLENBQUNrUyxhQUFhQyxjQUFjLElBQUluUyxTQUFTLEVBQUUsR0FBRyxDQUFDb1MsTUFBTUMsT0FBTyxJQUFJclMsU0FBUyxHQUFHLEdBQUcsQ0FBQ3NTLFVBQVVDLFdBQVcsSUFBSXZTLFNBQVMsRUFBRSxHQUFHLENBQUNxUCxZQUFZbUQsV0FBVyxJQUFJeFMsU0FBUyxFQUFFLEdBQUcsQ0FBQ3lTLFlBQVlDLGFBQWEsSUFBSTFTLFNBQVMsRUFBRSxHQUFHLENBQUN5TSxRQUFRb0QsU0FBUyxJQUFJN1AsU0FBUyxFQUFFLEdBQUcsQ0FBQzJTLFlBQVlDLFNBQVMsSUFBSTVTLFNBQVMsS0FBSztBQUNoYSxRQUFNNlMsY0FBY2pTLFlBQVksd0JBQXdCLENBQUMsR0FBR2dGLFFBQVFpRSxRQUFRLENBQUM7QUFDN0UsUUFBTWlKLFdBQVdwUyxPQUFPLHNCQUFzQixFQUFFNkksTUFBTSxFQUFFOEYsWUFBWTJDLFVBQVVlLGlCQUFpQixHQUFHLEVBQUUsR0FBR25OLFFBQVFvTSxRQUFRLENBQUM7QUFDeEgsUUFBTWdCLGNBQWNwUyxZQUFZLGlCQUFpQixDQUFDLEdBQUdnRixRQUFRb00sUUFBUSxDQUFDO0FBQ3RFLFFBQU1pQixlQUFlakIsV0FBV2MsU0FBUzdLLE1BQU1BLE9BQU80SyxZQUFZNUssTUFBTUEsS0FBSy9DLEtBQUssQ0FBQUMsU0FBUUEsS0FBS2dELE9BQU8rSixXQUFXO0FBQ2pILFFBQU1nQixlQUFlRixZQUFZL0ssTUFBTUEsS0FBSy9DLEtBQUssQ0FBQUMsU0FBUUEsS0FBS2dELE9BQU9rSCxVQUFVO0FBQy9FLFFBQU04RCxXQUFXek0sYUFBYTBMLElBQUksR0FBR2dCLGtCQUFrQjFNLGFBQWErTCxVQUFVO0FBQzlFLFFBQU1ZLGdCQUFnQnpOLFFBQVFpRSxZQUFZb0osZ0JBQWdCRSxhQUFhLFFBQVFBLFlBQVksTUFBTUEsYUFBYXpNLGFBQWFtRCxTQUFTeUosU0FBU3JNLE1BQU0sS0FBSyxDQUFDLFFBQVFQLGFBQWFtRCxTQUFTeUosU0FBU3JNLE1BQU0sS0FBSyxDQUFDLE1BQU1rTSxhQUFhek0sYUFBYXVNLGFBQWFoTSxPQUFPQSxNQUFNLEtBQUtxTCxTQUFTM0ssS0FBSyxDQUFDO0FBQzFSLFFBQU00TCxpQkFBaUIzTixRQUFRb00sWUFBWWlCLGdCQUFnQkMsZ0JBQWdCLENBQUNBLGFBQWFNLFlBQVlKLG9CQUFvQixRQUFRQSxrQkFBa0IsTUFBTUEsb0JBQW9CMU0sYUFBYXNMLFNBQVN5QixXQUFXeE0sTUFBTSxLQUFLLENBQUMsT0FBT21NLG9CQUFvQjFNLGFBQWF3TSxhQUFhUSxrQkFBa0J6TSxNQUFNLEtBQUssQ0FBQyxPQUFPaU0sYUFBYVEsa0JBQWtCM0gsYUFBYWtILGFBQWFoTSxPQUFPOEUsWUFBY2tILGFBQWFVLGNBQWMsY0FBZVQsYUFBYVMsY0FBYyxpQkFBa0JsSCxPQUFPOUUsS0FBSyxFQUFFaEUsVUFBVSxDQUFDO0FBQ2xmLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sNEJBQTJCLFVBQVMsd0VBQXVFLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUSxhQUFZLFNBQVMsTUFBTWlQLFVBQVUsSUFBSSxHQUFHLGtDQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFILEtBQTNQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNlE7QUFBQSxJQUFFLHVCQUFDLFFBQUssT0FBT25CLEtBQUssVUFBVSxDQUFDSixHQUFHdk8sVUFBa0I0TyxPQUFPNU8sS0FBSyxHQUFHLElBQUksRUFBRXNELElBQUksRUFBRSxHQUFHLFNBQVEsY0FBYTtBQUFBLDZCQUFDLE9BQUksT0FBTSxlQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUFFLHVCQUFDLE9BQUksT0FBTSxTQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0I7QUFBQSxNQUFFLHVCQUFDLE9BQUksT0FBTSwwQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsU0FBaEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrTDtBQUFBLElBQU8sdUJBQUMsU0FBT3FMLGtCQUFRLElBQUksdUJBQUMsY0FBVyxPQUFPRSxPQUFRQSxnQkFBTTFKLFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE1BQU0wSixNQUFNMUosS0FBS0EsTUFBTSxRQUFRLENBQUEyTCxRQUFPQSxJQUFJekwsSUFBSSxTQUFTO0FBQUEsUUFDOWtCLEVBQUVtRCxLQUFLLE1BQU1DLE9BQU8scUJBQXFCQyxRQUFRQSxDQUFBb0ksUUFBT0EsSUFBSUMsc0JBQXNCO0FBQUEsUUFDbEYsRUFBRXZJLEtBQUssV0FBV0MsT0FBTyxhQUFhQyxRQUFRQSxDQUFBb0ksUUFBT0EsSUFBSWxNLFVBQVU7QUFBQSxRQUNuRSxFQUFFNEQsS0FBSyxTQUFTQyxPQUFPLFdBQVdDLFFBQVFBLENBQUFvSSxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSTNNLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEIsRUFBRztBQUFBLFFBQzlFLEVBQUVxRSxLQUFLLGFBQWFDLE9BQU8sU0FBU0MsUUFBUUEsQ0FBQW9JLFFBQU9BLElBQUlELGNBQWMsV0FBVyxhQUFhLFVBQVU7QUFBQSxRQUN2RyxFQUFFckksS0FBSyxRQUFRQyxPQUFPLFlBQVlDLFFBQVFBLENBQUFvSSxRQUFPQSxJQUFJRSxjQUFjO0FBQUEsUUFDbkUsRUFBRXhJLEtBQUssU0FBU0MsT0FBTyxRQUFRQyxRQUFRQSxDQUFBb0ksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUlHLGNBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsRUFBRztBQUFBLE1BQUMsS0FONGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU85Z0I7QUFBQSxNQUFFLHVCQUFDLFNBQU0sTUFBTXBDLE1BQU0xSixLQUFLeUQsTUFBTSxhQUFZLGdCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNEO0FBQUEsU0FQb2Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9sZCxLQVB5YTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT3JhLElBQWdCK0YsUUFBUSxJQUFJLHVCQUFDLGNBQVcsT0FBT0csS0FBTUEsY0FBSTNKLFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE1BQU0ySixJQUFJM0osS0FBS0EsTUFBTSxRQUFRLENBQUEyTCxRQUFPQSxJQUFJekwsSUFBSSxTQUFTO0FBQUEsUUFDL0wsRUFBRW1ELEtBQUssTUFBTUMsT0FBTyxXQUFXQyxRQUFRQSxDQUFBb0ksUUFBT0EsSUFBSUksZ0JBQWdCO0FBQUEsUUFDbEUsRUFBRTFJLEtBQUssV0FBV0MsT0FBTyxlQUFlQyxRQUFRQSxDQUFBb0ksUUFBT0EsSUFBSUssVUFBVTtBQUFBLFFBQ3JFLEVBQUUzSSxLQUFLLFNBQVNDLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQW9JLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJTixZQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLEVBQUc7QUFBQSxRQUNqRixFQUFFaEksS0FBSyxPQUFPQyxPQUFPLGVBQWVDLFFBQVFBLENBQUFvSSxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSU0sY0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QixFQUFHO0FBQUEsUUFDcEYsRUFBRTVJLEtBQUssUUFBUUMsT0FBTyxtQkFBbUJDLFFBQVFBLENBQUFvSSxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSU8sZ0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsRUFBRztBQUFBLFFBQzNGLEVBQUU3SSxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQW9JLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJbkksVUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQixFQUFHO0FBQUEsUUFDakYsRUFBRUgsS0FBSyxVQUFVQyxPQUFPLElBQUlDLFFBQVFBLENBQUFvSSxRQUFPLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFVBQVVBLElBQUluSSxXQUFXLFdBQVcsU0FBUyxNQUFNO0FBQUUzQixzQkFBWThKLEdBQUc7QUFBR3pCLHlCQUFlLEVBQUU7QUFBR0Usa0JBQVF1QixJQUFJTSxXQUFXak4sTUFBTTtBQUFHc0wsc0JBQVksRUFBRTtBQUFBLFFBQUcsR0FBRyx5QkFBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TSxFQUFrQjtBQUFBLE1BQUMsS0FQdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFqSTtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNWCxJQUFJM0osS0FBS3lELE1BQU0sYUFBWSxlQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FSMEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVF4RSxLQVJtQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUS9CLElBQWdCLHVCQUFDLGNBQVcsT0FBT21HLE9BQVFBLGdCQUFNNUosUUFBUSxtQ0FBRTtBQUFBLDZCQUFDLGFBQVUsTUFBTTRKLE1BQU01SixLQUFLQSxNQUFNLFFBQVEsQ0FBQTJMLFFBQU9BLElBQUl6TCxJQUFJLFNBQVM7QUFBQSxRQUN0TCxFQUFFbUQsS0FBSyxNQUFNQyxPQUFPLE1BQU1DLFFBQVFBLENBQUFvSSxRQUFPQSxJQUFJekwsR0FBRztBQUFBLFFBQ2hELEVBQUVtRCxLQUFLLGVBQWVDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQW9JLFFBQU9qQyxNQUFNMUosTUFBTUEsS0FBSy9DLEtBQUssQ0FBQWdOLGlCQUFlQSxhQUFZL0osT0FBT3lMLElBQUliLGFBQWEsR0FBR2MseUJBQXlCRCxJQUFJYixjQUFjO0FBQUEsUUFDaEwsRUFBRXpILEtBQUssU0FBU0MsT0FBTyxjQUFjQyxRQUFRQSxDQUFBb0ksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUlsRCxTQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCLEVBQUc7QUFBQSxRQUNoRixFQUFFcEYsS0FBSyxVQUFVQyxPQUFPLGFBQWFDLFFBQVFBLENBQUFvSSxRQUFPQSxJQUFJbkgsT0FBTztBQUFBLFFBQy9ELEVBQUVuQixLQUFLLFVBQVVDLE9BQU8sSUFBSUMsUUFBUUEsQ0FBQW9JLFFBQU8sdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsVUFBVUEsSUFBSWxELFVBQVUsV0FBVyxTQUFTLE1BQU07QUFBRXVCLGtCQUFRMkIsR0FBRztBQUFHekIseUJBQWV5QixJQUFJYixhQUFhO0FBQUdQLHNCQUFZLEVBQUU7QUFBR0Usd0JBQWMsRUFBRTtBQUFHN0Msb0JBQVUsRUFBRTtBQUFBLFFBQUcsR0FBRyw4QkFBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TixFQUFrQjtBQUFBLE1BQUMsS0FMbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU10SDtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNZ0MsTUFBTTVKLEtBQUt5RCxNQUFNLGFBQVksZ0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxTQU40RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTTFELEtBTmlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNYixLQXJCaVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCblk7QUFBQSxJQUM5RSx1QkFBQyxjQUFXLE1BQU0sQ0FBQyxDQUFDN0IsVUFBVSxPQUFNLGlCQUFnQixTQUFTLE1BQU1DLFlBQVksSUFBSSxHQUFHLE1BQU1nSSxNQUFNakcsU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQ3dILGlCQUFpQnZCLE1BQU1qRyxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFBRSxjQUFNaUcsTUFBTTlGLFFBQVEsRUFBRXpDLE1BQU0sRUFBRThGLFlBQVl4RixVQUFVMUIsTUFBTSxHQUFHLEdBQUcyRCxNQUFNLEVBQUVZLGlCQUFpQjdDLFVBQVVvQyxXQUFXLEdBQUdtSSxtQkFBbUJsQyxhQUFhZ0MsWUFBWSxFQUFFak4sUUFBUW1MLE1BQU1yRyxVQUFVaEUsS0FBS2dFLFNBQVMsR0FBR3NJLGdCQUFnQi9CLFVBQVU3RixRQUFRLDRDQUE0QyxFQUFFLENBQUM7QUFBRzNDLG9CQUFZLElBQUk7QUFBQSxNQUFHLFFBQVE7QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyw2QkFBaGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2YixHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPZ0ksTUFBTTVGLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBTzJHLGFBQWNBLHNCQUFZNUssUUFBUSx1QkFBQyxTQUFNLEtBQUssR0FBRztBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sMEJBQXlCLE9BQU9pSyxhQUFhLFVBQVUsQ0FBQTdMLFVBQVM4TCxlQUFlOUwsTUFBTW5DLE9BQU9wQixLQUFLLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sSUFBRyx3Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUFZK1AsWUFBWTVLLEtBQUtBLEtBQUttSixPQUFPLENBQUFqTSxTQUFRQSxLQUFLd08sY0FBYyxZQUFZeE8sS0FBSzRPLGVBQWUsZUFBZTVPLEtBQUs4QixPQUFPOEUsYUFBYWxDLFVBQVV5SixTQUFTdkgsUUFBUSxFQUFFckQsSUFBSSxDQUFBdkQsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLZ0QsSUFBS2hEO0FBQUFBLGlCQUFLME87QUFBQUEsWUFBc0I7QUFBQSxZQUFJN1MsWUFBWW1FLEtBQUs4QixNQUFNO0FBQUEsZUFBaEY5QixLQUFLZ0QsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUcsQ0FBVztBQUFBLGFBQXhjO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMGM7QUFBQSxRQUFZLHVCQUFDLGtCQUFlLE9BQU0sdUJBQXNCLGFBQWEwSyxZQUFZeUIsYUFBYSxTQUFTekIsWUFBWTBCLFNBQVMsTUFBTTFCLFlBQVkyQixlQUFlLFlBQVkzQixZQUFZNEIsWUFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrTDtBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFPLGdCQUFnQjFNLEtBQUtnRSxRQUFRLEtBQUssT0FBT3FHLE1BQU0sT0FBT2UsYUFBYSxNQUFNLFlBQVlGLGdCQUFnQkUsYUFBYSxRQUFRLENBQUNFLGdCQUFnQiwyREFBMkQsMkVBQTJFLFVBQVUsQ0FBQWhOLFVBQVNnTSxRQUFRaE0sTUFBTW5DLE9BQU9wQixLQUFLLEdBQUcsWUFBWSxFQUFFMEosV0FBVyxVQUFVLEtBQXRYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd1g7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxtQkFBa0IsT0FBTzhGLFVBQVUsVUFBVSxDQUFBak0sVUFBU2tNLFlBQVlsTSxNQUFNbkMsT0FBT3BCLEtBQUssS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFFBQUUsdUJBQUMsU0FBTSxVQUFTLFdBQVUseUdBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQUEvdUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1dkMsS0FBNXlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcXpDO0FBQUEsU0FBbjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZzZEO0FBQUEsSUFDaDZELHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUNrUCxVQUFVLE9BQU0sOEJBQTZCLFNBQVMsTUFBTUMsUUFBUSxJQUFJLEdBQUcsTUFBTUYsVUFBVWxHLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUMwSCxrQkFBa0J4QixVQUFVbEcsU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJO0FBQUUsY0FBTWtHLFVBQVUvRixRQUFRLEVBQUV6QyxNQUFNLEVBQUU4RixZQUFZMkMsVUFBVTdKLE1BQU0sR0FBRyxHQUFHMkQsTUFBTSxFQUFFWSxpQkFBaUJzRixVQUFVL0YsV0FBVyxHQUFHOEcsZUFBZWIsYUFBYXdDLGFBQWEsQ0FBQyxFQUFFQyxVQUFVLEVBQUV2UCxNQUFNLFFBQVErQyxJQUFJa0gsV0FBVyxHQUFHcEksUUFBUSxFQUFFQSxRQUFRd0wsWUFBWTFHLFVBQVVoRSxLQUFLZ0UsU0FBUyxFQUFFLENBQUMsR0FBR1UsT0FBTyxFQUFFLENBQUM7QUFBR3dGLGdCQUFRLElBQUk7QUFBQSxNQUFHLFFBQVE7QUFBQSxNQUFFO0FBQUEsSUFBNEIsR0FBRyxvQ0FBdmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyYyxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPRixVQUFVN0YsU0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPNEcsVUFBV0EsbUJBQVM3SyxRQUFRLHVCQUFDLGNBQVcsT0FBTytLLGFBQWNBLHNCQUFZL0ssUUFBUSx1QkFBQyxTQUFNLEtBQUssR0FBRztBQUFBLCtCQUFDLGFBQVUsT0FBTSw0QkFBMkIsT0FBTzZLLFNBQVM3SyxLQUFLQSxLQUFLNEwsdUJBQXVCLFlBQVksRUFBRWUsVUFBVSxLQUFLLEtBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEg7QUFBQSxRQUFFLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0saUJBQWdCLE9BQU92RixZQUFZLFVBQVUsQ0FBQWhKLFVBQVNtTSxZQUFZbk0sTUFBTW5DLE9BQU9wQixLQUFLLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sSUFBRyw2Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUFZa1EsWUFBWS9LLEtBQUtBLEtBQUttSixPQUFPLENBQUFqTSxTQUFRLENBQUNBLEtBQUtxTyxZQUFZeE0sc0JBQXNCN0IsS0FBS3VPLGtCQUFrQnpNLE1BQU0sS0FBSzlCLEtBQUt1TyxrQkFBa0IzSCxhQUFha0gsY0FBY2hNLE9BQU84RSxZQUFja0gsY0FBY1UsY0FBYyxjQUFleE8sS0FBS3dPLGNBQWMsYUFBYyxFQUFFakwsSUFBSSxDQUFBdkQsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLZ0QsSUFBS2hEO0FBQUFBLGlCQUFLZ0Q7QUFBQUEsWUFBRztBQUFBLFlBQUloRCxLQUFLd08sY0FBYyxlQUFlLGFBQWE7QUFBQSxZQUFXO0FBQUEsWUFBSTNTLFlBQVltRSxLQUFLdU8saUJBQWlCO0FBQUEsZUFBdEl2TyxLQUFLZ0QsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUosQ0FBVztBQUFBLGFBQTdsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStsQjtBQUFBLFFBQVksdUJBQUMsa0JBQWUsT0FBTSxXQUFVLGFBQWE2SyxZQUFZc0IsYUFBYSxTQUFTdEIsWUFBWXVCLFNBQVMsTUFBTXZCLFlBQVl3QixlQUFlLFlBQVl4QixZQUFZeUIsWUFBN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFPLG9CQUFvQjFNLEtBQUtnRSxRQUFRLEtBQUssT0FBTzBHLFlBQVksT0FBT0EsZUFBZSxNQUFNVyxvQkFBb0IsTUFBTSxZQUFZQSxvQkFBb0IsUUFBUUEsa0JBQWtCLE1BQU0sQ0FBQ0csaUJBQWlCLHFFQUFxRSxJQUFJLFVBQVUsQ0FBQWxOLFVBQVNxTSxjQUFjck0sTUFBTW5DLE9BQU9wQixLQUFLLEdBQUcsWUFBWSxFQUFFMEosV0FBVyxVQUFVLEtBQXJYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdVg7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxTQUFRLE9BQU9DLFFBQVEsVUFBVSxDQUFBcEcsVUFBU3dKLFVBQVV4SixNQUFNbkMsT0FBT3BCLEtBQUssS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBQWwzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW8zQyxLQUF6NkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrN0MsS0FBaitDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBKytDO0FBQUEsU0FBNW1FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeW5FO0FBQUEsSUFDeG5FNlAsY0FBYyx1QkFBQyxtQkFBZ0IsU0FBUyxNQUFNQyxVQUFVLEtBQUssS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLE9BeEJ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0I0RDtBQUN2RTtBQUFDcEIsSUExQ2VELG9CQUFrQjtBQUFBLFVBQ2IxUSxVQUVISCxRQUF3Q0ksY0FDMUNKLFFBQXNDSSxjQUNwQ0osUUFBMkNJLGNBQzNDSCxZQUNJQSxZQUVFQyxhQUNIRixRQUNHRSxXQUFXO0FBQUE7QUFBQSxNQVhuQjJRO0FBMkNoQixTQUFTc0QsZ0JBQWdCO0FBQUEsRUFBRUM7QUFFM0IsR0FBRztBQUFBQyxNQUFBO0FBQ0MsUUFBTSxFQUFFaE4sS0FBSyxJQUFJbEgsU0FBUztBQUMxQixRQUFNbVUsU0FBU3JVLFdBQVcsY0FBYyxFQUFFLEdBQUdzVSxPQUFPdFUsV0FBVyx1QkFBdUIsQ0FBQyx3QkFBd0IseUJBQXlCLENBQUMsR0FBR2lSLE1BQU1qUixXQUFXLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDO0FBQ3pNLFFBQU0sQ0FBQ29KLE1BQU1DLE9BQU8sSUFBSWhLLFNBQVMsTUFBTSxHQUFHLENBQUNrVixNQUFNQyxPQUFPLElBQUluVixTQUFzQixJQUFJLEdBQUcsQ0FBQytPLFNBQVNxRyxVQUFVLElBQUlwVixTQUFTLEVBQUUsR0FBRyxDQUFDcVYsT0FBT0MsUUFBUSxJQUFJdFYsU0FBUyxFQUFFLEdBQUcsQ0FBQ3VWLFFBQVFDLFNBQVMsSUFBSXhWLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQ3lWLE9BQU9DLE1BQU0sSUFBSTFWLFNBQVMsRUFBRSxHQUFHLENBQUMyVixhQUFhQyxjQUFjLElBQUk1VixTQUFxRDtBQUN6VSxTQUFPLHVCQUFDLGNBQVcsTUFBSSxNQUFDLE9BQU0sc0JBQXFCLFNBQWtCLE1BQU1nVixPQUFPbkosV0FBV29KLEtBQUtwSixXQUFXK0YsSUFBSS9GLFNBQVMsYUFBMEIsU0FBUzRKLFFBQVEsdUJBQUMsYUFBVSxJQUFJLE1BQU0xTixLQUFLSSxFQUFFLFNBQVNzTixLQUFLLElBQUksZ0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEQsSUFBZSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUN0SCxZQUFZLENBQUMrRyxRQUFRLENBQUNuRyxXQUFXLENBQUNzRyxTQUFTTCxPQUFPbkosV0FBV29KLEtBQUtwSixXQUFXK0YsSUFBSS9GLFNBQVMsU0FBUyxZQUFZO0FBQUUsUUFBSSxDQUFDcUosUUFBUSxDQUFDL0c7QUFDcFo7QUFBUSxRQUFJO0FBQ1osWUFBTTBILEtBQUssSUFBSUMsU0FBUztBQUN4QkQsU0FBR0UsT0FBTyxRQUFRYixJQUFJO0FBQ3RCVyxTQUFHRSxPQUFPLFdBQVdoTSxTQUFTLFNBQVMsbUJBQW1CLGVBQWU7QUFDekUsWUFBTWlNLElBQUksTUFBTWhCLE9BQU9oSixRQUFRLEVBQUVpSyxNQUFNSixHQUFHLENBQUM7QUFDM0MsWUFBTS9KLE9BQU8sRUFBRW9LLFFBQVFGLEVBQUUvTixLQUFLRSxJQUFJZ08sb0JBQW9CcEgsU0FBU3FILFVBQVViLFFBQVFjLGVBQWVoQixNQUFNO0FBQ3RHLFlBQU1pQixTQUFTdk0sU0FBUyxTQUFTLE1BQU1rTCxLQUFLakosUUFBUSxFQUFFRixLQUFLLENBQUMsSUFBSSxNQUFNOEYsSUFBSTVGLFFBQVEsRUFBRUYsS0FBSyxDQUFDO0FBQzFGNEosYUFBT1ksT0FBT3JPLEtBQUtFLEVBQUU7QUFDckJ5TixxQkFBZSxDQUFBVyxjQUFhLEVBQUVDLE9BQU8sTUFBTUMsV0FBV0YsVUFBVUUsWUFBWSxLQUFLLEVBQUUsRUFBRTtBQUFBLElBQ3pGLFFBQ007QUFBQSxJQUFFO0FBQUEsRUFBZ0IsR0FBRyxnQ0FYdU47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVd2TSxHQUFXO0FBQUEsMkJBQUMsZUFBWSxPQUFPekIsT0FBTzlJLFNBQVMrSSxLQUFLL0ksU0FBUzBGLElBQUkxRixTQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsSUFBRSx1QkFBQyxTQUFNLEtBQUssR0FBSTtBQUFBLE9BQUNpQyxZQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLDBHQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9IO0FBQUEsTUFBUyx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGFBQVksT0FBT3BFLE1BQU0sVUFBVSxDQUFBb0MsTUFBS25DLFFBQVFtQyxFQUFFakksT0FBT3BCLEtBQUssR0FBRztBQUFBLCtCQUFDLFlBQVMsT0FBTSxRQUFPLHlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBVyx1QkFBQyxZQUFTLE9BQU0sT0FBTSxtQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFdBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0s7QUFBQSxNQUFZLHVCQUFDLFVBQU8sV0FBVSxTQUFRLFNBQVEsWUFBWW9TO0FBQUFBLGVBQU9BLEtBQUtqUSxPQUFPO0FBQUEsUUFBVyx1QkFBQyxXQUFNLFFBQU0sTUFBQyxNQUFLLFFBQU8sUUFBTyxpQkFBZ0IsVUFBVSxDQUFBa0gsTUFBS2dKLFFBQVFoSixFQUFFakksT0FBT3dTLFFBQVEsQ0FBQyxLQUFLLElBQUksS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFdBQWpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUw7QUFBQSxNQUFTLHVCQUFDLGFBQVUsT0FBTSxvQ0FBbUMsT0FBTzNILFNBQVMsVUFBVSxDQUFBNUMsTUFBS2lKLFdBQVdqSixFQUFFakksT0FBT3BCLEtBQUssS0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RztBQUFBLE1BQUUsdUJBQUMsYUFBVSxPQUFNLHdCQUF1QixPQUFPdVMsT0FBTyxVQUFVLENBQUFsSixNQUFLbUosU0FBU25KLEVBQUVqSSxPQUFPcEIsS0FBSyxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThGO0FBQUEsTUFBRSx1QkFBQyxhQUFVLE9BQU0sb0NBQW1DLE9BQU95UyxRQUFRLFVBQVUsQ0FBQXBKLE1BQUtxSixVQUFVckosRUFBRWpJLE9BQU9wQixLQUFLLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEc7QUFBQSxNQUFFLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJKQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtLO0FBQUEsU0FBMStCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBay9CO0FBQUEsT0FYL2xDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXdW1DO0FBQ2xuQztBQUFDaVMsSUFsQlFGLGlCQUFlO0FBQUEsVUFHSGhVLFVBQ0ZGLFlBQXFDQSxZQUE4RkEsVUFBVTtBQUFBO0FBQUEsTUFKdkprVTtBQW1CRixnQkFBUzhCLFlBQVk7QUFBQUMsTUFBQTtBQUN4QixRQUFNQyxRQUFRblcsT0FBTyxpQkFBaUIsRUFBRXNGLE9BQU9sRixhQUFhLEVBQUUsQ0FBQyxHQUFHeU8sVUFBVTdPLE9BQU8sdUJBQXVCO0FBQzFHLFFBQU1vVyxRQUFRblcsV0FBVyx5QkFBeUIsQ0FBQyx1QkFBdUIsQ0FBQztBQUMzRSxRQUFNb1csU0FBU3BXLFdBQVcsMEJBQTBCLENBQUMsdUJBQXVCLENBQUM7QUFDN0UsUUFBTSxDQUFDa0osVUFBVUMsV0FBVyxJQUFJOUosU0FBa0MsSUFBSSxHQUFHLENBQUNnWCxVQUFVQyxXQUFXLElBQUlqWCxTQUFTLEVBQUUsR0FBRyxDQUFDeU0sUUFBUW9ELFNBQVMsSUFBSTdQLFNBQVMsRUFBRTtBQUNsSixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHFCQUFvQixVQUFTLHFGQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdJO0FBQUEsSUFBRSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxpQ0FBQyxjQUFXLE9BQU82VyxPQUFRQSxnQkFBTTVPLFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE1BQU00TyxNQUFNNU8sS0FBS0EsTUFBTSxRQUFRLENBQUFvRCxNQUFLQSxFQUFFbEQsSUFBSSxTQUFTO0FBQUEsUUFDdlEsRUFBRW1ELEtBQUssTUFBTUMsT0FBTyxZQUFZQyxRQUFRQSxDQUFBSCxNQUFLQSxFQUFFbEQsR0FBRztBQUFBLFFBQUcsRUFBRW1ELEtBQUssT0FBT0MsT0FBTyxhQUFhQyxRQUFRQSxDQUFBSCxNQUFLLEdBQUdBLEVBQUU2TCxnQkFBZ0IsTUFBTTdMLEVBQUU4TCxjQUFjLEdBQUc7QUFBQSxRQUFHLEVBQUU3TCxLQUFLLGFBQWFDLE9BQU8sUUFBUUMsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRXNJLGNBQWMsZUFBZSxhQUFhLFdBQVc7QUFBQSxRQUFHLEVBQUVySSxLQUFLLFlBQVlDLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUUrTCxrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxFQUFHO0FBQUEsUUFBRyxFQUFFOUwsS0FBSyxXQUFXQyxPQUFPLFdBQVdDLFFBQVFBLENBQUFILE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFcUkscUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUMsRUFBRztBQUFBLFFBQUcsRUFBRXBJLEtBQUssT0FBT0MsT0FBTyxXQUFXQyxRQUFRQSxDQUFBSCxNQUFLdEssU0FBU3NLLEVBQUVnTSxLQUFLLEVBQUU7QUFBQSxRQUFHLEVBQUUvTCxLQUFLLFdBQVdDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRW1JLFdBQVcsbUJBQW1CLFFBQVE7QUFBQSxNQUFDLEtBRHZZO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFM007QUFBQSxNQUFFLHVCQUFDLFNBQU0sTUFBTXFELE1BQU01TyxLQUFLeUQsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLFNBRjBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFeEssS0FGK0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUUzSCxLQUZvRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXZGO0FBQUEsSUFBUSx1QkFBQyxTQUFNLE9BQU0sY0FBYSxJQUFJLEVBQUU5QyxJQUFJLEVBQUUsR0FBRyxpQ0FBQyxjQUFXLE9BQU8yRyxTQUFTLGlDQUFDLGFBQVUsTUFBTUEsUUFBUXRILE1BQU1BLFFBQVEsSUFBSSxRQUFRLENBQUFvRCxNQUFLQSxFQUFFbEQsSUFBSSxTQUFTO0FBQUEsTUFDcE0sRUFBRW1ELEtBQUssVUFBVUMsT0FBTyxNQUFNQyxRQUFRQSxDQUFBSCxNQUFLLEdBQUdBLEVBQUVrRixTQUFTLE1BQU1sRixFQUFFbUYsT0FBTyxHQUFHO0FBQUEsTUFBRyxFQUFFbEYsS0FBSyxTQUFTQyxPQUFPLGNBQWNDLFFBQVFBLENBQUFILE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFcUYsU0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QixFQUFHO0FBQUEsTUFBRyxFQUFFcEYsS0FBSyxVQUFVQyxPQUFPLHVCQUF1QkMsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRWlNLGVBQWVDLEtBQUssSUFBSSxLQUFLLDJCQUEyQjtBQUFBLE1BQ25SO0FBQUEsUUFDSWpNLEtBQUs7QUFBQSxRQUFVQyxPQUFPO0FBQUEsUUFBSUMsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxrQkFBZSxZQUFXLGlCQUFnQixTQUFTLE1BQU07QUFBRXZCLHNCQUFZdUIsQ0FBQztBQUFHNEwsc0JBQVksRUFBRTtBQUFHcEgsb0JBQVUsRUFBRTtBQUFBLFFBQUcsR0FBSXhFLFlBQUVxRixVQUFVLFdBQVcsd0JBQXdCLG9CQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdMO0FBQUEsTUFDM047QUFBQSxJQUFDLEtBSjRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLL0gsS0FMbUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtqRyxLQUx3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzNDO0FBQUEsSUFBUSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQzdHLFlBQVlBLFNBQVM2RyxVQUFVLFVBQVUsT0FBTSxtQkFBa0IsYUFBWSwrR0FBOEcsU0FBUyxNQUFNNUcsWUFBWSxJQUFJLEdBQUcsTUFBTWdOLE1BQU1qTCxTQUFTLE9BQU9pTCxNQUFNNUssT0FBTyxXQUFXLE1BQU00SyxNQUFNOUssUUFBUSxFQUFFekMsTUFBTSxFQUFFOEYsWUFBWXhGLFVBQVUxQixNQUFNLEdBQUcsR0FBRzJELE1BQU0sRUFBRVksaUJBQWlCN0MsVUFBVW9DLFdBQVcsRUFBRSxFQUFFLENBQUMsS0FBM1o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2WjtBQUFBLElBQUUsdUJBQUMsY0FBVyxNQUFNcEMsVUFBVTZHLFVBQVUsVUFBVSxPQUFNLHFCQUFvQixTQUFTLE1BQU01RyxZQUFZLElBQUksR0FBRyxNQUFNaU4sT0FBT2xMLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFVBQVUsQ0FBQ21MLFlBQVl2SyxPQUFPOUksU0FBUyxLQUFLb1QsT0FBT2xMLFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUM5cEIsY0FBTWtMLE9BQU8vSyxRQUFRLEVBQUV6QyxNQUFNLEVBQUU4RixZQUFZeEYsVUFBVTFCLE1BQU0sR0FBRyxHQUFHMkQsTUFBTSxFQUFFWSxpQkFBaUI3QyxVQUFVb0MsV0FBVyxHQUFHdUwsWUFBWVIsVUFBVXZLLE9BQU8sRUFBRSxDQUFDO0FBQ2xKM0Msb0JBQVksSUFBSTtBQUFBLE1BQ3BCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyx5QkFKd2lCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJL2hCLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9pTixPQUFPN0ssU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQUUsdUJBQUMsU0FBTSxLQUFLLEdBQUc7QUFBQSwrQkFBQyxhQUFVLE9BQU0sd0JBQXVCLE9BQU84SyxVQUFVLFVBQVUsQ0FBQTdLLE1BQUs4SyxZQUFZOUssRUFBRWpJLE9BQU9wQixLQUFLLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxTQUFRLE9BQU8ySixRQUFRLFVBQVUsQ0FBQU4sTUFBSzBELFVBQVUxRCxFQUFFakksT0FBT3BCLEtBQUssS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBQXRNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd007QUFBQSxTQUo4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXRKO0FBQUEsT0FYM1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVd3UztBQUNuVDtBQUFDOFQsSUFqQmVELFdBQVM7QUFBQSxVQUNQalcsUUFBaUNJLGNBQTZCSixRQUM5REMsWUFDQ0EsVUFBVTtBQUFBO0FBQUEsTUFIYmdXO0FBQVMsSUFBQWxRLElBQUFnUixLQUFBQyxLQUFBQyxLQUFBM0ksS0FBQTRJLEtBQUFDLEtBQUFDLEtBQUFDO0FBQUEsYUFBQXRSLElBQUE7QUFBQSxhQUFBZ1IsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQTNJLEtBQUE7QUFBQSxhQUFBNEksS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQWxlcnQiLCJCb3giLCJCdXR0b24iLCJNZW51SXRlbSIsIlN0YWNrIiwiVGFiIiwiVGFicyIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwidXNlUGFnZWRBcGkiLCJ1c2VTY29wZSIsInVzZUxpc3RRdWVyeSIsImRhdGVUaW1lIiwiZm9ybWF0TW9uZXkiLCJBbW91bnQiLCJDb25maXJtRGlhbG9nIiwiRGF0YVRhYmxlIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkxvb2t1cExvYWRNb3JlIiwiTXV0YXRpb25CdXR0b24iLCJQYWdlSGVhZGVyIiwiUGFnZXIiLCJQYW5lbCIsIlF1ZXJ5U3RhdGUiLCJSb3V0ZUxpbmsiLCJTdGF0IiwiU3RhdHMiLCJTdGF0dXMiLCJUb29sYmFyIiwiZXhwbGFpblByb2ZpdExvc3MiLCJwcm9maXRMb3NzUXVlc3Rpb25zIiwiZGVtb0pvdXJuYWxBY2NvdW50cyIsInByZXZpb3VzTW9udGhSYW5nZSIsInRvZGF5IiwiRGF0ZSIsImVuZCIsIlVUQyIsImdldFVUQ0Z1bGxZZWFyIiwiZ2V0VVRDTW9udGgiLCJzdGFydCIsImRhdGVPbmx5IiwidmFsdWUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiZnJvbSIsInRvIiwibG9jYWxNaWRuaWdodCIsImRhdGUiLCJ0aW1lem9uZSIsImRhdGVQYXJ0cyIsInNwbGl0IiwieWVhclRleHQiLCJtb250aFRleHQiLCJkYXlUZXh0IiwibGVuZ3RoIiwiUmFuZ2VFcnJvciIsInllYXIiLCJOdW1iZXIiLCJtb250aCIsImRheSIsImlzSW50ZWdlciIsInRhcmdldCIsInRhcmdldERhdGUiLCJnZXRVVENEYXRlIiwiaW5zdGFudCIsImF0dGVtcHQiLCJwYXJ0cyIsIkludGwiLCJEYXRlVGltZUZvcm1hdCIsInRpbWVab25lIiwiaG91ciIsIm1pbnV0ZSIsInNlY29uZCIsImhvdXJDeWNsZSIsImZvcm1hdFRvUGFydHMiLCJwYXJ0IiwibmFtZSIsImZpbmQiLCJpdGVtIiwidHlwZSIsInVuZGVmaW5lZCIsImxvY2FsQXNVdGMiLCJ1c2VSZXBvcnRSYW5nZSIsIl9zIiwicmFuZ2UiLCJzZXRSYW5nZSIsInZhbGlkIiwiQm9vbGVhbiIsInNldEZyb20iLCJjdXJyZW50Iiwic2V0VG8iLCJxdWVyeSIsIlJlcG9ydFJhbmdlRmllbGRzIiwieHMiLCJzbSIsIm1iIiwiZXZlbnQiLCJpbnB1dExhYmVsIiwic2hyaW5rIiwiYWxpZ25JdGVtcyIsIl9jIiwiZGVjaW1hbFVuaXRzIiwidGVzdCIsIndob2xlIiwiZnJhY3Rpb24iLCJCaWdJbnQiLCJwYWRFbmQiLCJoYXNPdXRzdGFuZGluZ0JhbGFuY2UiLCJhbW91bnQiLCJkZWNpbWFsVGV4dCIsInRvU3RyaW5nIiwicGFkU3RhcnQiLCJyZXBsYWNlIiwiam91cm5hbExpbmVFcnJvciIsImxpbmUiLCJkZWJpdCIsImNyZWRpdCIsImFjY291bnRJZCIsInRyaW0iLCJkZXNjcmlwdGlvbiIsIkNhc2hmbG93UGFnZSIsIl9zMiIsInNob3AiLCJyZXBvcnQiLCJkYXRhIiwiYyIsImlkIiwicmVjZWlwdHMiLCJkaXNidXJzZW1lbnRzIiwibmV0Q2FzaE1vdmVtZW50IiwicCIsImFzT2YiLCJ3YXJuaW5ncyIsIm1hcCIsInciLCJtdCIsIkVudHJpZXNQYWdlIiwiX3MzIiwibGlzdCIsImNyZWF0ZSIsInVwZGF0ZSIsInBvc3QiLCJyZXZlcnNlIiwiZW50cnlJZCIsInNldEVudHJ5SWQiLCJkZXRhaWwiLCJwYXRoIiwic2VsZWN0ZWRFbnRyeSIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwib3BlbiIsInNldE9wZW4iLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwia2luZCIsInNldEtpbmQiLCJjbGFzc2lmaWNhdGlvbiIsInNldENsYXNzaWZpY2F0aW9uIiwic2V0QW1vdW50Iiwib2NjdXJyZWRBdCIsInNldE9jY3VycmVkQXQiLCJzZXREZXNjcmlwdGlvbiIsImJlZ2luIiwiZW50cnkiLCJjbGFzc2VzIiwic2FsZXNfcmVjZWlwdCIsImludmVudG9yeV9wdXJjaGFzZSIsInNoaXBwaW5nIiwicGxhdGZvcm1fZmVlIiwicGF5bWVudF9mZWUiLCJhaV9leHBlbnNlIiwib3BlcmF0aW5nX2V4cGVuc2UiLCJjYXBpdGFsIiwibG9hbl9wcmluY2lwYWwiLCJ0cmFuc2ZlciIsIm90aGVyIiwiciIsImtleSIsImxhYmVsIiwicmVuZGVyIiwic3RhdHVzIiwicGFnZSIsInNvdXJjZVJlZiIsImFjdGlvbiIsInBlbmRpbmciLCJib2R5IiwiY3VycmVuY3kiLCJleGVjdXRlIiwidmVyc2lvbiIsImVycm9yIiwiZSIsInYiLCJPYmplY3QiLCJlbnRyaWVzIiwidCIsImlucHV0TW9kZSIsInJlYXNvbiIsImV4cGVjdGVkVmVyc2lvbiIsIlByb2ZpdExvc3NQYWdlIiwiX3M0IiwicXVlc3Rpb24iLCJzZXRRdWVzdGlvbiIsImdlbmVyYXRlZEtleSIsInNldEdlbmVyYXRlZEtleSIsImN1cnJlbnRLZXkiLCJleHBsYW5hdGlvbiIsIm5ldFNhbGVzIiwiY29ncyIsImdyb3NzUHJvZml0Iiwib3BlcmF0aW5nUHJvZml0IiwiY29tcGxldGVuZXNzIiwiZ3Jvc3NTYWxlcyIsImRpc2NvdW50cyIsInNhbGVzUmV0dXJucyIsInNoaXBwaW5nSW5jb21lIiwic2hpcHBpbmdFeHBlbnNlIiwicGxhdGZvcm1GZWVzIiwicGF5bWVudEZlZXMiLCJhaUV4cGVuc2UiLCJvdGhlck9wZXJhdGluZ0V4cGVuc2VzIiwiU3RyaW5nIiwicG9saWN5VmVyc2lvbiIsIl9fTU9DS19fIiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJhbnN3ZXIiLCJzb3VyY2VzIiwic291cmNlIiwid2FybmluZyIsImluZGV4IiwibSIsIkpvdXJuYWxBY2NvdW50RmllbGQiLCJvbkNoYW5nZSIsImFjY291bnQiLCJfYzUiLCJKb3VybmFsc1BhZ2UiLCJfczUiLCJ2aWV3SWQiLCJzZXRWaWV3SWQiLCJyZXNvdXJjZUlkIiwidmlld2VkSm91cm5hbCIsInBlcmlvZHMiLCJzb3VyY2VUeXBlIiwic2V0U291cmNlVHlwZSIsInNvdXJjZUlkIiwic2V0U291cmNlSWQiLCJzZXREYXRlIiwic2V0UmVhc29uIiwibmV3TGluZSIsImxpbmVzIiwic2V0TGluZXMiLCJsaW5lRXJyb3JzIiwiZGViaXRUb3RhbCIsInJlZHVjZSIsInRvdGFsIiwiY3JlZGl0VG90YWwiLCJwZXJpb2QiLCJzdGFydERhdGUiLCJlbmREYXRlIiwicGVyaW9kT3BlbiIsInN0YXRlIiwiYmFsYW5jZWQiLCJldmVyeSIsImpvdXJuYWwiLCJlZmZlY3RpdmVEYXRlIiwicmV2ZXJzYWxPZiIsImlzUGVuZGluZyIsIml0ZW1JbmRleCIsIm15Iiwic2lkZSIsImZpbHRlciIsIl8iLCJjb25maXJtUmVhc29uIiwiUmVjb25jaWxpYXRpb25QYWdlIiwiX3M2IiwidGFiIiwic2V0VGFiIiwiYmFua3MiLCJjb2QiLCJjYXNlcyIsIm1hdGNoIiwibWF0Y2hCYW5rIiwiY2FzZUl0ZW0iLCJzZXRDYXNlIiwidHJhbnNhY3Rpb24iLCJzZXRUcmFuc2FjdGlvbiIsImZlZXMiLCJzZXRGZWVzIiwiZXZpZGVuY2UiLCJzZXRFdmlkZW5jZSIsInNldFJlc291cmNlIiwiYWxsb2NhdGlvbiIsInNldEFsbG9jYXRpb24iLCJpbXBvcnRPcGVuIiwic2V0SW1wb3J0IiwiYmFua0Nob2ljZXMiLCJjYXNlQmFuayIsInRyYW5zYWN0aW9uSWQiLCJkZWJ0Q2hvaWNlcyIsInNlbGVjdGVkQmFuayIsInNlbGVjdGVkRGVidCIsImZlZVVuaXRzIiwiYWxsb2NhdGlvblVuaXRzIiwiY29kTWF0Y2hWYWxpZCIsImdyb3NzRHVlIiwiYmFua01hdGNoVmFsaWQiLCJkaXNwdXRlZCIsImRpZmZlcmVuY2UiLCJvdXRzdGFuZGluZ0Ftb3VudCIsImRpcmVjdGlvbiIsInJvdyIsImV4dGVybmFsVHJhbnNhY3Rpb25JZCIsInJlZmVyZW5jZVRleHQiLCJtYXRjaFN0YXRlIiwiZXh0ZXJuYWxCYXRjaElkIiwiY2FycmllcklkIiwiYWN0dWFsRmVlcyIsImJhbmtSZWNlaXZlZCIsImJhbmtUcmFuc2FjdGlvbklkIiwiZmVlRXZpZGVuY2VSZWYiLCJsb2FkZWRDb3VudCIsImhhc01vcmUiLCJpc0xvYWRpbmdNb3JlIiwibG9hZE1vcmUiLCJhbGxvY2F0aW9ucyIsInJlc291cmNlIiwicmVhZE9ubHkiLCJTdGF0ZW1lbnREaWFsb2ciLCJvbkNsb3NlIiwiX3M3IiwidXBsb2FkIiwiYmFuayIsImZpbGUiLCJzZXRGaWxlIiwic2V0QWNjb3VudCIsImJhdGNoIiwic2V0QmF0Y2giLCJmb3JtYXQiLCJzZXRGb3JtYXQiLCJqb2JJZCIsInNldEpvYiIsImRyYWZ0Q29tbWl0Iiwic2V0RHJhZnRDb21taXQiLCJmZCIsIkZvcm1EYXRhIiwiYXBwZW5kIiwiZiIsImZvcm0iLCJmaWxlSWQiLCJhY2NvdW50T3JDYXJyaWVySWQiLCJmb3JtYXRJZCIsInNvdXJjZUJhdGNoSWQiLCJyZXN1bHQiLCJwcmV2aW91cyIsInNjb3BlIiwic2VxdWVuY2UiLCJmaWxlcyIsIkRlYnRzUGFnZSIsIl9zOCIsImRlYnRzIiwiY2xvc2UiLCJyZW9wZW4iLCJhcHByb3ZhbCIsInNldEFwcHJvdmFsIiwiY291bnRlcnBhcnR5VHlwZSIsImNvdW50ZXJwYXJ0eUlkIiwib3JpZ2luYWxBbW91bnQiLCJkdWVBdCIsImJsb2NraW5nSXNzdWVzIiwiam9pbiIsImFwcHJvdmFsSWQiLCJfYzIiLCJfYzMiLCJfYzQiLCJfYzYiLCJfYzciLCJfYzgiLCJfYzkiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBNZW51SXRlbSwgU3RhY2ssIFRhYiwgVGFicywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgdHlwZSB7IEFjY291bnRpbmdQZXJpb2QsIENPRFNldHRsZW1lbnQsIEZpbmFuY2VFbnRyeSwgRmluYW5jZUVudHJ5V3JpdGUsIEpvdXJuYWwsIEpvdXJuYWxMaW5lLCBSZWNvbmNpbGlhdGlvbkNhc2UgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCwgdXNlUGFnZWRBcGkgfSBmcm9tICcuLi8uLi9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7IHVzZVNjb3BlIH0gZnJvbSAnLi4vLi4vc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcbmltcG9ydCB7IGRhdGVUaW1lLCBmb3JtYXRNb25leSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgQW1vdW50LCBDb25maXJtRGlhbG9nLCBEYXRhVGFibGUsIERldGFpbExpbmUsIEVkaXREaWFsb2csIEVycm9yTm90aWNlLCBMb29rdXBMb2FkTW9yZSwgTXV0YXRpb25CdXR0b24sIFBhZ2VIZWFkZXIsIFBhZ2VyLCBQYW5lbCwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0LCBTdGF0cywgU3RhdHVzLCBUb29sYmFyIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgZXhwbGFpblByb2ZpdExvc3MsIHByb2ZpdExvc3NRdWVzdGlvbnMsIHR5cGUgUHJvZml0TG9zc1F1ZXN0aW9uSWQgfSBmcm9tICcuL3JlcG9ydC1leHBsYW5hdGlvbnMnO1xuaW1wb3J0IHsgZGVtb0pvdXJuYWxBY2NvdW50cyB9IGZyb20gJy4vZGVtby1hY2NvdW50LXByZXZpZXcnO1xuXG5mdW5jdGlvbiBwcmV2aW91c01vbnRoUmFuZ2UoKSB7XG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xuICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKERhdGUuVVRDKHRvZGF5LmdldFVUQ0Z1bGxZZWFyKCksIHRvZGF5LmdldFVUQ01vbnRoKCksIDEpKTtcbiAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKERhdGUuVVRDKHRvZGF5LmdldFVUQ0Z1bGxZZWFyKCksIHRvZGF5LmdldFVUQ01vbnRoKCkgLSAxLCAxKSk7XG4gICAgY29uc3QgZGF0ZU9ubHkgPSAodmFsdWU6IERhdGUpID0+IHZhbHVlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgIHJldHVybiB7IGZyb206IGRhdGVPbmx5KHN0YXJ0KSwgdG86IGRhdGVPbmx5KGVuZCkgfTtcbn1cbmZ1bmN0aW9uIGxvY2FsTWlkbmlnaHQoZGF0ZTogc3RyaW5nLCB0aW1lem9uZTogc3RyaW5nKSB7XG4gICAgY29uc3QgZGF0ZVBhcnRzID0gZGF0ZS5zcGxpdCgnLScpO1xuICAgIGNvbnN0IFt5ZWFyVGV4dCwgbW9udGhUZXh0LCBkYXlUZXh0XSA9IGRhdGVQYXJ0cztcbiAgICBpZiAoZGF0ZVBhcnRzLmxlbmd0aCAhPT0gMyB8fCAheWVhclRleHQgfHwgIW1vbnRoVGV4dCB8fCAhZGF5VGV4dCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ05nw6B5IHBo4bqjaSB0aGVvIMSR4buLbmggZOG6oW5nIFlZWVktTU0tREQuJyk7XG4gICAgY29uc3QgeWVhciA9IE51bWJlcih5ZWFyVGV4dCksIG1vbnRoID0gTnVtYmVyKG1vbnRoVGV4dCksIGRheSA9IE51bWJlcihkYXlUZXh0KTtcbiAgICBpZiAoIU51bWJlci5pc0ludGVnZXIoeWVhcikgfHwgIU51bWJlci5pc0ludGVnZXIobW9udGgpIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKGRheSkgfHwgbW9udGggPCAxIHx8IG1vbnRoID4gMTIgfHwgZGF5IDwgMSB8fCBkYXkgPiAzMSkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ05nw6B5IGLDoW8gY8OhbyBraMO0bmcgaOG7o3AgbOG7hy4nKTtcbiAgICBjb25zdCB0YXJnZXQgPSBEYXRlLlVUQyh5ZWFyLCBtb250aCAtIDEsIGRheSk7XG4gICAgY29uc3QgdGFyZ2V0RGF0ZSA9IG5ldyBEYXRlKHRhcmdldCk7XG4gICAgaWYgKHRhcmdldERhdGUuZ2V0VVRDRnVsbFllYXIoKSAhPT0geWVhciB8fCB0YXJnZXREYXRlLmdldFVUQ01vbnRoKCkgIT09IG1vbnRoIC0gMSB8fCB0YXJnZXREYXRlLmdldFVUQ0RhdGUoKSAhPT0gZGF5KSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignTmfDoHkgYsOhbyBjw6FvIGtow7RuZyBo4bujcCBs4buHLicpO1xuICAgIGxldCBpbnN0YW50ID0gdGFyZ2V0O1xuICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgMzsgYXR0ZW1wdCsrKSB7XG4gICAgICAgIGNvbnN0IHBhcnRzID0gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ2VuLVVTJywgeyB0aW1lWm9uZTogdGltZXpvbmUsIHllYXI6ICdudW1lcmljJywgbW9udGg6ICcyLWRpZ2l0JywgZGF5OiAnMi1kaWdpdCcsIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcsIHNlY29uZDogJzItZGlnaXQnLCBob3VyQ3ljbGU6ICdoMjMnIH0pLmZvcm1hdFRvUGFydHMobmV3IERhdGUoaW5zdGFudCkpO1xuICAgICAgICBjb25zdCBwYXJ0ID0gKG5hbWU6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBwYXJ0cy5maW5kKGl0ZW0gPT4gaXRlbS50eXBlID09PSBuYW1lKT8udmFsdWU7XG4gICAgICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFRoaeG6v3UgdGjDoG5oIHBo4bqnbiB0aOG7nWkgZ2lhbiAke25hbWV9LmApO1xuICAgICAgICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGxvY2FsQXNVdGMgPSBEYXRlLlVUQyhwYXJ0KCd5ZWFyJyksIHBhcnQoJ21vbnRoJykgLSAxLCBwYXJ0KCdkYXknKSwgcGFydCgnaG91cicpLCBwYXJ0KCdtaW51dGUnKSwgcGFydCgnc2Vjb25kJykpO1xuICAgICAgICBpbnN0YW50ICs9IHRhcmdldCAtIGxvY2FsQXNVdGM7XG4gICAgfVxuICAgIHJldHVybiBuZXcgRGF0ZShpbnN0YW50KS50b0lTT1N0cmluZygpO1xufVxuZnVuY3Rpb24gdXNlUmVwb3J0UmFuZ2UodGltZXpvbmU6IHN0cmluZykge1xuICAgIGNvbnN0IFtyYW5nZSwgc2V0UmFuZ2VdID0gdXNlU3RhdGUocHJldmlvdXNNb250aFJhbmdlKTtcbiAgICBjb25zdCB2YWxpZCA9IEJvb2xlYW4ocmFuZ2UuZnJvbSAmJiByYW5nZS50byAmJiByYW5nZS5mcm9tIDwgcmFuZ2UudG8pO1xuICAgIHJldHVybiB7XG4gICAgICAgIHJhbmdlLFxuICAgICAgICBzZXRGcm9tOiAoZnJvbTogc3RyaW5nKSA9PiBzZXRSYW5nZShjdXJyZW50ID0+ICh7IC4uLmN1cnJlbnQsIGZyb20gfSkpLFxuICAgICAgICBzZXRUbzogKHRvOiBzdHJpbmcpID0+IHNldFJhbmdlKGN1cnJlbnQgPT4gKHsgLi4uY3VycmVudCwgdG8gfSkpLFxuICAgICAgICB2YWxpZCxcbiAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgIGZyb206IHZhbGlkID8gbG9jYWxNaWRuaWdodChyYW5nZS5mcm9tLCB0aW1lem9uZSkgOiAnJyxcbiAgICAgICAgICAgIHRvOiB2YWxpZCA/IGxvY2FsTWlkbmlnaHQocmFuZ2UudG8sIHRpbWV6b25lKSA6ICcnLFxuICAgICAgICAgICAgdGltZXpvbmUsXG4gICAgICAgIH0sXG4gICAgfTtcbn1cbmZ1bmN0aW9uIFJlcG9ydFJhbmdlRmllbGRzKHsgcmFuZ2UsIHRpbWV6b25lLCBzZXRGcm9tLCBzZXRUbyB9OiB7IHJhbmdlOiB7IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9OyB0aW1lem9uZTogc3RyaW5nOyBzZXRGcm9tOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDsgc2V0VG86ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkIH0pIHtcbiAgICByZXR1cm4gPFN0YWNrIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBnYXA9ezJ9IHN4PXt7IG1iOiAyIH19PlxuICAgICAgICA8VGV4dEZpZWxkIHR5cGU9XCJkYXRlXCIgbGFiZWw9XCJU4burIG5nw6B5XCIgdmFsdWU9e3JhbmdlLmZyb219IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRGcm9tKGV2ZW50LnRhcmdldC52YWx1ZSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19Lz5cbiAgICAgICAgPFRleHRGaWVsZCB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwixJDhur9uIHRyxrDhu5tjIG5nw6B5XCIgdmFsdWU9e3JhbmdlLnRvfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0VG8oZXZlbnQudGFyZ2V0LnZhbHVlKX0gc2xvdFByb3BzPXt7IGlucHV0TGFiZWw6IHsgc2hyaW5rOiB0cnVlIH0gfX0vPlxuICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e3sgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+S2hv4bqjbmcgW1Thu6ssIMSQ4bq/bik7IG3DumkgZ2nhu50ge3RpbWV6b25lfS48L0FsZXJ0PlxuICAgIDwvU3RhY2s+O1xufVxuZnVuY3Rpb24gZGVjaW1hbFVuaXRzKHZhbHVlOiBzdHJpbmcpOiBiaWdpbnQgfCBudWxsIHtcbiAgICBpZiAoIS9eXFxkKyhcXC5cXGR7MSw0fSk/JC8udGVzdCh2YWx1ZSkpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IFt3aG9sZSA9ICcnLCBmcmFjdGlvbiA9ICcnXSA9IHZhbHVlLnNwbGl0KCcuJyk7XG4gICAgaWYgKCF3aG9sZSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIEJpZ0ludCh3aG9sZSkgKiAxMDAwMG4gKyBCaWdJbnQoZnJhY3Rpb24ucGFkRW5kKDQsICcwJykpO1xufVxuZnVuY3Rpb24gaGFzT3V0c3RhbmRpbmdCYWxhbmNlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhbW91bnQgPSBkZWNpbWFsVW5pdHModmFsdWUpO1xuICAgIHJldHVybiBhbW91bnQgIT09IG51bGwgJiYgYW1vdW50ID4gMG47XG59XG5mdW5jdGlvbiBkZWNpbWFsVGV4dCh2YWx1ZTogYmlnaW50KSB7XG4gICAgY29uc3QgZnJhY3Rpb24gPSAodmFsdWUgJSAxMDAwMG4pLnRvU3RyaW5nKCkucGFkU3RhcnQoNCwgJzAnKS5yZXBsYWNlKC8wKyQvLCAnJyk7XG4gICAgcmV0dXJuIGAke3ZhbHVlIC8gMTAwMDBufSR7ZnJhY3Rpb24gPyBgLiR7ZnJhY3Rpb259YCA6ICcnfWA7XG59XG5mdW5jdGlvbiBqb3VybmFsTGluZUVycm9yKGxpbmU6IEpvdXJuYWxMaW5lKSB7XG4gICAgY29uc3QgZGViaXQgPSBkZWNpbWFsVW5pdHMobGluZS5kZWJpdC5hbW91bnQpLCBjcmVkaXQgPSBkZWNpbWFsVW5pdHMobGluZS5jcmVkaXQuYW1vdW50KTtcbiAgICBpZiAoIWxpbmUuYWNjb3VudElkLnRyaW0oKSkgcmV0dXJuICdOaOG6rXAgbcOjIHTDoGkga2hv4bqjbiDEkcaw4bujYyBj4bqlcCB0cm9uZyBo4buHIHRo4buRbmcuJztcbiAgICBpZiAoZGViaXQgPT09IG51bGwgfHwgY3JlZGl0ID09PSBudWxsKSByZXR1cm4gJ1Phu5EgdGnhu4FuIGTDuW5nIHThu5FpIMSRYSA0IGNo4buvIHPhu5EgdGjhuq1wIHBow6JuLic7XG4gICAgaWYgKGRlYml0ID09PSAwbiAmJiBjcmVkaXQgPT09IDBuKSByZXR1cm4gJ03hu5dpIGTDsm5nIHBo4bqjaSBjw7Mgc+G7kSBO4bujIGhv4bq3YyBDw7MgbOG7m24gaMahbiAwLic7XG4gICAgaWYgKGRlYml0ID4gMG4gJiYgY3JlZGl0ID4gMG4pIHJldHVybiAnTeG7mXQgZMOybmcgY2jhu4kgxJHGsOG7o2MgY8OzIE7hu6MgaG/hurdjIEPDsy4nO1xuICAgIGlmICghbGluZS5kZXNjcmlwdGlvbi50cmltKCkpIHJldHVybiAnTmjhuq1wIGRp4buFbiBnaeG6o2kgY2hvIGTDsm5nLic7XG4gICAgcmV0dXJuICcnO1xufVxuZXhwb3J0IGZ1bmN0aW9uIENhc2hmbG93UGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgcmVwb3J0ID0gdXNlUmVwb3J0UmFuZ2Uoc2hvcC50aW1lem9uZSk7XG4gICAgY29uc3QgZGF0YSA9IHVzZUFwaSgnZ2V0Q2FzaGZsb3cnLCB7IHF1ZXJ5OiByZXBvcnQucXVlcnkgfSwgcmVwb3J0LnZhbGlkKTtcbiAgICBjb25zdCBjID0gZGF0YS5kYXRhPy5kYXRhO1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiRMOybmcgdGnhu4FuXCIgc3VidGl0bGU9XCJUaeG7gW4gdGjhu7FjIHRodSB2w6AgdGjhu7FjIGNoaSwgdMOhY2ggYmnhu4d0IGRvYW5oIHRodSB2w6AgbOG7o2kgbmh14bqtbi5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL2VudHJpZXNgfT5T4buVIHRodSBjaGk8L1JvdXRlTGluaz59Lz48UmVwb3J0UmFuZ2VGaWVsZHMgcmFuZ2U9e3JlcG9ydC5yYW5nZX0gdGltZXpvbmU9e3Nob3AudGltZXpvbmV9IHNldEZyb209e3JlcG9ydC5zZXRGcm9tfSBzZXRUbz17cmVwb3J0LnNldFRvfS8+e3JlcG9ydC52YWxpZCA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtkYXRhfT57YyAmJiA8PjxTdGF0cz48U3RhdCB0aXRsZT1cIlRp4buBbiDEkcOjIHRodVwiIHZhbHVlPXs8QW1vdW50IHZhbHVlPXtjLnJlY2VpcHRzfS8+fS8+PFN0YXQgdGl0bGU9XCJUaeG7gW4gxJHDoyBjaGlcIiB2YWx1ZT17PEFtb3VudCB2YWx1ZT17Yy5kaXNidXJzZW1lbnRzfS8+fS8+PFN0YXQgdGl0bGU9XCJCaeG6v24gxJHhu5luZyB0aeG7gW4gdGh14bqnblwiIHZhbHVlPXs8QW1vdW50IHZhbHVlPXtjLm5ldENhc2hNb3ZlbWVudH0vPn0gYWNjZW50IG5vdGU9XCJLaMO0bmcgcGjhuqNpIHPhu5EgZMawIHTDoGkga2hv4bqjblwiLz48U3RhdCB0aXRsZT1cIk3DumkgZ2nhu50gYsOhbyBjw6FvXCIgdmFsdWU9e2MudGltZXpvbmV9Lz48L1N0YXRzPjxQYW5lbCB0aXRsZT1cIkvhu7MgYsOhbyBjw6FvXCI+PEJveCBzeD17eyBwOiAzIH19PjxEZXRhaWxMaW5lIGxhYmVsPVwiVOG7q1wiPntkYXRlVGltZShjLmZyb20pfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIsSQ4bq/biAoa2jDtG5nIGfhu5NtKVwiPntkYXRlVGltZShjLnRvKX08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJE4buvIGxp4buHdSB04bqhaVwiPntkYXRlVGltZShjLmFzT2YpfTwvRGV0YWlsTGluZT57Yy53YXJuaW5ncy5tYXAodyA9PiA8QWxlcnQga2V5PXt3fSBzZXZlcml0eT1cImluZm9cIiBzeD17eyBtdDogMiB9fT57d308L0FsZXJ0Pil9PC9Cb3g+PC9QYW5lbD48Lz59PC9RdWVyeVN0YXRlPiA6IDxBbGVydCBzZXZlcml0eT1cImVycm9yXCI+TmfDoHkgYuG6r3QgxJHhuqd1IHBo4bqjaSB0csaw4bubYyBuZ8OgeSBr4bq/dCB0aMO6Yy48L0FsZXJ0Pn08Lz47XG59XG5leHBvcnQgZnVuY3Rpb24gRW50cmllc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RGaW5hbmNlRW50cmllcycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgpIH0pO1xuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUZpbmFuY2VFbnRyeScsIFsnbGlzdEZpbmFuY2VFbnRyaWVzJ10pO1xuICAgIGNvbnN0IHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZUZpbmFuY2VFbnRyeScsIFsnbGlzdEZpbmFuY2VFbnRyaWVzJ10pO1xuICAgIGNvbnN0IHBvc3QgPSB1c2VDb21tYW5kKCdwb3N0RmluYW5jZUVudHJ5JywgWydsaXN0RmluYW5jZUVudHJpZXMnLCAnZ2V0Q2FzaGZsb3cnLCAnZ2V0UHJvZml0TG9zcycsICdsaXN0Sm91cm5hbHMnXSk7XG4gICAgY29uc3QgcmV2ZXJzZSA9IHVzZUNvbW1hbmQoJ3JldmVyc2VGaW5hbmNlRW50cnknLCBbJ2xpc3RGaW5hbmNlRW50cmllcycsICdnZXRDYXNoZmxvdycsICdnZXRQcm9maXRMb3NzJywgJ2xpc3RKb3VybmFscyddKTtcbiAgICBjb25zdCBbZW50cnlJZCwgc2V0RW50cnlJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldEZpbmFuY2VFbnRyeScsIHsgcGF0aDogeyBlbnRyeUlkOiBlbnRyeUlkIHx8ICcnIH0gfSwgQm9vbGVhbihlbnRyeUlkKSk7XG4gICAgY29uc3Qgc2VsZWN0ZWRFbnRyeSA9IGRldGFpbC5kYXRhPy5kYXRhO1xuICAgIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPEZpbmFuY2VFbnRyeSB8IG51bGw+KG51bGwpLCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSksIFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8e1xuICAgICAgICBlbnRyeTogRmluYW5jZUVudHJ5O1xuICAgICAgICBhY3Rpb246ICdwb3N0JyB8ICdyZXZlcnNlJztcbiAgICB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2tpbmQsIHNldEtpbmRdID0gdXNlU3RhdGU8RmluYW5jZUVudHJ5V3JpdGVbJ2tpbmQnXT4oJ2Rpc2J1cnNlbWVudCcpLCBbY2xhc3NpZmljYXRpb24sIHNldENsYXNzaWZpY2F0aW9uXSA9IHVzZVN0YXRlPEZpbmFuY2VFbnRyeVdyaXRlWydjbGFzc2lmaWNhdGlvbiddPignb3BlcmF0aW5nX2V4cGVuc2UnKSwgW2Ftb3VudCwgc2V0QW1vdW50XSA9IHVzZVN0YXRlKCcnKSwgW29jY3VycmVkQXQsIHNldE9jY3VycmVkQXRdID0gdXNlU3RhdGUoJzIwMjYtMDktMjlUMTQ6MDA6MDBaJyksIFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGJlZ2luID0gKGVudHJ5OiBGaW5hbmNlRW50cnkgfCBudWxsKSA9PiB7IHNldEVkaXRpbmcoZW50cnkpOyBzZXRLaW5kKGVudHJ5Py5raW5kIHx8ICdkaXNidXJzZW1lbnQnKTsgc2V0Q2xhc3NpZmljYXRpb24oZW50cnk/LmNsYXNzaWZpY2F0aW9uIHx8ICdvcGVyYXRpbmdfZXhwZW5zZScpOyBzZXRBbW91bnQoZW50cnk/LmFtb3VudC5hbW91bnQgfHwgJycpOyBzZXRPY2N1cnJlZEF0KGVudHJ5Py5vY2N1cnJlZEF0IHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7IHNldERlc2NyaXB0aW9uKGVudHJ5Py5kZXNjcmlwdGlvbiB8fCAnJyk7IHNldE9wZW4odHJ1ZSk7IH07XG4gICAgY29uc3QgY2xhc3NlczogUmVjb3JkPEZpbmFuY2VFbnRyeVdyaXRlWydjbGFzc2lmaWNhdGlvbiddLCBzdHJpbmc+ID0ge1xuICAgICAgICBzYWxlc19yZWNlaXB0OiAnVGh1IGLDoW4gaMOgbmcnLCBpbnZlbnRvcnlfcHVyY2hhc2U6ICdNdWEgdOG7k24ga2hvJywgc2hpcHBpbmc6ICdW4bqtbiBjaHV54buDbicsIHBsYXRmb3JtX2ZlZTogJ1Bow60gbuG7gW4gdOG6o25nJywgcGF5bWVudF9mZWU6ICdQaMOtIHRoYW5oIHRvw6FuJywgYWlfZXhwZW5zZTogJ0NoaSBwaMOtIEFJJywgb3BlcmF0aW5nX2V4cGVuc2U6ICdDaGkgcGjDrSB24bqtbiBow6BuaCcsIGNhcGl0YWw6ICdHw7NwIHbhu5FuJywgbG9hbl9wcmluY2lwYWw6ICdH4buRYyB2YXknLCB0cmFuc2ZlcjogJ0NodXnhu4NuIG7hu5lpIGLhu5knLCBvdGhlcjogJ0tow6FjJ1xuICAgIH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJT4buVIHRodSBjaGlcIiBzdWJ0aXRsZT1cIlBoaeG6v3UgbmjDoXAg4oaSIGtp4buDbSB0cmEg4oaSIGdoaSBz4buVLiBQaGnhur91IMSRw6MgZ2hpIGNo4buJIMSRaeG7gXUgY2jhu4luaCBjw7MgbOG7i2NoIHPhu60uXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gYmVnaW4obnVsbCl9PlThuqFvIHBoaeG6v3U8L011dGF0aW9uQnV0dG9uPn0vPjxQYW5lbD48VG9vbGJhciAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fT57bGlzdC5kYXRhICYmIDw+PERhdGFUYWJsZSByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtyID0+IHIuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnQ2jhu6luZyB04burJywgcmVuZGVyOiByID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RW50cnlJZChyLmlkKX0+e3IuaWR9PC9CdXR0b24+IH0sIHsga2V5OiAnZGF0ZScsIGxhYmVsOiAnTmfDoHknLCByZW5kZXI6IHIgPT4gZGF0ZVRpbWUoci5vY2N1cnJlZEF0KSB9LCB7IGtleTogJ3R5cGUnLCBsYWJlbDogJ1Bow6JuIGxv4bqhaScsIHJlbmRlcjogciA9PiBjbGFzc2VzW3IuY2xhc3NpZmljYXRpb25dIH0sIHsga2V5OiAnYW1vdW50JywgbGFiZWw6ICdT4buRIHRp4buBbicsIHJlbmRlcjogciA9PiA8QW1vdW50IHZhbHVlPXtyLmFtb3VudH0vPiB9LCB7IGtleTogJ25vdGUnLCBsYWJlbDogJ0Rp4buFbiBnaeG6o2knLCByZW5kZXI6IHIgPT4gci5kZXNjcmlwdGlvbiB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiByID0+IDxTdGF0dXMgdmFsdWU9e3Iuc3RhdHVzfS8+IH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIGtleTogJ2FjdGlvbicsIGxhYmVsOiAnVGhhbyB0w6FjJywgcmVuZGVyOiByID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RW50cnlJZChyLmlkKX0+Q2hpIHRp4bq/dDwvQnV0dG9uPlxuICAgICAgICB9XG4gICAgXX0vPjxQYWdlciBwYWdlPXtsaXN0LmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cbiA8RWRpdERpYWxvZyBvcGVuPXtCb29sZWFuKGVudHJ5SWQpfSB0aXRsZT17c2VsZWN0ZWRFbnRyeSA/IGBDaOG7qW5nIHThu6sgJHtzZWxlY3RlZEVudHJ5LmlkfWAgOiAnxJBhbmcgdOG6o2kgY2jhu6luZyB04burJ30gb25DbG9zZT17KCkgPT4gc2V0RW50cnlJZChudWxsKX0gYWN0aW9ucz17PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRFbnRyeUlkKG51bGwpfT7EkMOzbmc8L0J1dHRvbj59PjxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9PntzZWxlY3RlZEVudHJ5ICYmIDxTdGFjayBnYXA9ezF9PjxTdGF0dXMgdmFsdWU9e3NlbGVjdGVkRW50cnkuc3RhdHVzfS8+PERldGFpbExpbmUgbGFiZWw9XCJMb+G6oWlcIj57c2VsZWN0ZWRFbnRyeS5raW5kID09PSAncmVjZWlwdCcgPyAnVGh1IHRp4buBbicgOiAnQ2hpIHRp4buBbid9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiUGjDom4gbG/huqFpXCI+e2NsYXNzZXNbc2VsZWN0ZWRFbnRyeS5jbGFzc2lmaWNhdGlvbl19PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiU+G7kSB0aeG7gW5cIj48QW1vdW50IHZhbHVlPXtzZWxlY3RlZEVudHJ5LmFtb3VudH0vPjwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIk5nw6B5IGdoaSBuaOG6rW5cIj57ZGF0ZVRpbWUoc2VsZWN0ZWRFbnRyeS5vY2N1cnJlZEF0KX08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJOZ3Xhu5NuXCI+e3NlbGVjdGVkRW50cnkuc291cmNlUmVmID8gYCR7c2VsZWN0ZWRFbnRyeS5zb3VyY2VSZWYudHlwZX0gLyAke3NlbGVjdGVkRW50cnkuc291cmNlUmVmLmlkfWAgOiAnS2jDtG5nIGPDsyd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiRGnhu4VuIGdp4bqjaVwiPntzZWxlY3RlZEVudHJ5LmRlc2NyaXB0aW9ufTwvRGV0YWlsTGluZT57c2VsZWN0ZWRFbnRyeS5zdGF0dXMgPT09ICdkcmFmdCcgJiYgPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGdhcD17MX0+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBvbkNsaWNrPXsoKSA9PiBiZWdpbihzZWxlY3RlZEVudHJ5KX0+U+G7rWEgbmjDoXA8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5wb3N0XCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoeyBlbnRyeTogc2VsZWN0ZWRFbnRyeSwgYWN0aW9uOiAncG9zdCcgfSl9PkdoaSBz4buVPC9NdXRhdGlvbkJ1dHRvbj48L1N0YWNrPn17c2VsZWN0ZWRFbnRyeS5zdGF0dXMgPT09ICdwb3N0ZWQnICYmIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5wb3N0XCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoeyBlbnRyeTogc2VsZWN0ZWRFbnRyeSwgYWN0aW9uOiAncmV2ZXJzZScgfSl9PsSQ4bqjbyBwaGnhur91PC9NdXRhdGlvbkJ1dHRvbj59PC9TdGFjaz59PC9RdWVyeVN0YXRlPjwvRWRpdERpYWxvZz5cbiA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT17ZWRpdGluZyA/ICdT4butYSBwaGnhur91IG5ow6FwJyA6ICdQaGnhur91IHRodSBjaGkgbeG7m2knfSBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gYnVzeT17Y3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZyB8fCAhL15cXGQrKFxcLlxcZHsxLDR9KT8kLy50ZXN0KGFtb3VudCkgfHwgZGVzY3JpcHRpb24udHJpbSgpLmxlbmd0aCA8IDV9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgY29uc3QgYm9keTogRmluYW5jZUVudHJ5V3JpdGUgPSB7IGtpbmQsIGNsYXNzaWZpY2F0aW9uLCBhbW91bnQ6IHsgYW1vdW50LCBjdXJyZW5jeTogc2hvcC5jdXJyZW5jeSB9LCBvY2N1cnJlZEF0LCBkZXNjcmlwdGlvbiwgc291cmNlUmVmOiBlZGl0aW5nPy5zb3VyY2VSZWYgfHwgbnVsbCB9OyB0cnkge1xuICAgICAgICBpZiAoZWRpdGluZylcbiAgICAgICAgICAgIGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyBlbnRyeUlkOiBlZGl0aW5nLmlkIH0sIHZlcnNpb246IGVkaXRpbmcudmVyc2lvbiwgYm9keSB9KTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5IH0pO1xuICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICB9XG4gICAgY2F0Y2ggeyAvKiBrZWVwIGZvcm0gYW5kIGVycm9yICovIH0gfX0+TMawdSBuaMOhcDwvQnV0dG9uPn0+PEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3IgfHwgdXBkYXRlLmVycm9yfS8+PFN0YWNrIGdhcD17Mn0+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJMb+G6oWkgcGhp4bq/dVwiIHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZSA9PiBzZXRLaW5kKGUudGFyZ2V0LnZhbHVlID09PSAncmVjZWlwdCcgPyAncmVjZWlwdCcgOiAnZGlzYnVyc2VtZW50Jyl9PjxNZW51SXRlbSB2YWx1ZT1cInJlY2VpcHRcIj5UaHUgdGnhu4FuPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJkaXNidXJzZW1lbnRcIj5DaGkgdGnhu4FuPC9NZW51SXRlbT48L1RleHRGaWVsZD48VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIlBow6JuIGxv4bqhaVwiIHZhbHVlPXtjbGFzc2lmaWNhdGlvbn0gb25DaGFuZ2U9e2UgPT4geyBjb25zdCB2ID0gZS50YXJnZXQudmFsdWU7IGlmICh2IGluIGNsYXNzZXMpXG4gICAgICAgIHNldENsYXNzaWZpY2F0aW9uKHYgYXMgRmluYW5jZUVudHJ5V3JpdGVbJ2NsYXNzaWZpY2F0aW9uJ10pOyB9fT57T2JqZWN0LmVudHJpZXMoY2xhc3NlcykubWFwKChbdiwgdF0pID0+IDxNZW51SXRlbSBrZXk9e3Z9IHZhbHVlPXt2fT57dH08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PFRleHRGaWVsZCBsYWJlbD17YFPhu5EgdGnhu4FuICgke3Nob3AuY3VycmVuY3l9KWB9IHZhbHVlPXthbW91bnR9IG9uQ2hhbmdlPXtlID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgaW5wdXRNb2RlOiAnZGVjaW1hbCcgfX0vPjxUZXh0RmllbGQgbGFiZWw9XCJUaOG7nWkgxJFp4buDbSBJU08gODYwMVwiIHZhbHVlPXtvY2N1cnJlZEF0fSBvbkNoYW5nZT17ZSA9PiBzZXRPY2N1cnJlZEF0KGUudGFyZ2V0LnZhbHVlKX0gaGVscGVyVGV4dD1cIlbDrSBk4bulIDIwMjYtMDktMjlUMTQ6MDA6MDBaOyBraMO0bmcgdOG7sSBzdXkgbcO6aSBnaeG7nSB04burIG3DoXkuXCIvPjxUZXh0RmllbGQgbGFiZWw9XCJEaeG7hW4gZ2nhuqNpXCIgbXVsdGlsaW5lIG1pblJvd3M9ezJ9IHZhbHVlPXtkZXNjcmlwdGlvbn0gb25DaGFuZ2U9e2UgPT4gc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfS8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlRp4buBbiBtdWEgaMOgbmcgdOG7k24ga2hvIGtow7RuZyB04buxIHRy4bufIHRow6BuaCB0b8OgbiBi4buZIGNoaSBwaMOtIHRyb25nIGzhu6NpIG5odeG6rW4uPC9BbGVydD48L1N0YWNrPjwvRWRpdERpYWxvZz5cbiA8Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT17c2VsZWN0ZWQ/LmFjdGlvbiA9PT0gJ3Bvc3QnID8gJ0doaSBz4buVIHBoaeG6v3UgxJHDoyBraeG7g20nIDogJ8SQ4bqjbyBwaGnhur91IMSRw6MgZ2hpJ30gZGVzY3JpcHRpb249e2Ake3NlbGVjdGVkPy5lbnRyeS5pZCB8fCAnJ30gwrcgJHtmb3JtYXRNb25leShzZWxlY3RlZD8uZW50cnkuYW1vdW50KX0uIEtow7RuZyBjaHV54buDbiB0aeG7gW4gdGjhu7FjIHThur8gcXVhIGNo4bupYyBuxINuZyBuw6B5LmB9IHJlcXVpcmVSZWFzb24gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGJ1c3k9e3Bvc3QucGVuZGluZyB8fCByZXZlcnNlLnBlbmRpbmd9IGVycm9yPXtwb3N0LmVycm9yIHx8IHJldmVyc2UuZXJyb3J9IG9uQ29uZmlybT17cmVhc29uID0+IHNlbGVjdGVkPy5hY3Rpb24gPT09ICdwb3N0JyA/IHBvc3QuZXhlY3V0ZSh7IHBhdGg6IHsgZW50cnlJZDogc2VsZWN0ZWQuZW50cnkuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkLmVudHJ5LnZlcnNpb24sIHJlYXNvbiB9IH0pIDogcmV2ZXJzZS5leGVjdXRlKHsgcGF0aDogeyBlbnRyeUlkOiBzZWxlY3RlZD8uZW50cnkuaWQgfHwgJycgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkPy5lbnRyeS52ZXJzaW9uIHx8IDEsIHJlYXNvbiB9IH0pfS8+PC8+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIFByb2ZpdExvc3NQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCByZXBvcnQgPSB1c2VSZXBvcnRSYW5nZShzaG9wLnRpbWV6b25lKTtcbiAgICBjb25zdCBkYXRhID0gdXNlQXBpKCdnZXRQcm9maXRMb3NzJywgeyBxdWVyeTogcmVwb3J0LnF1ZXJ5IH0sIHJlcG9ydC52YWxpZCk7XG4gICAgY29uc3QgcCA9IGRhdGEuZGF0YT8uZGF0YTtcbiAgICBjb25zdCBbcXVlc3Rpb24sIHNldFF1ZXN0aW9uXSA9IHVzZVN0YXRlPFByb2ZpdExvc3NRdWVzdGlvbklkPignc3VtbWFyeScpO1xuICAgIGNvbnN0IFtnZW5lcmF0ZWRLZXksIHNldEdlbmVyYXRlZEtleV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgY3VycmVudEtleSA9IHAgPyBgJHtyZXBvcnQucmFuZ2UuZnJvbX18JHtyZXBvcnQucmFuZ2UudG99fCR7cC5hc09mfXwke3F1ZXN0aW9ufWAgOiAnJztcbiAgICBjb25zdCBleHBsYW5hdGlvbiA9IHAgJiYgZ2VuZXJhdGVkS2V5ID09PSBjdXJyZW50S2V5ID8gZXhwbGFpblByb2ZpdExvc3MocCwgcXVlc3Rpb24pIDogbnVsbDtcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIkzhu6NpIG5odeG6rW4gcXXhuqNuIHRy4buLXCIgc3VidGl0bGU9XCJT4buRIGxp4buHdSBkbyBBUEkgdOG7lW5nIGjhu6NwIHThu6sgbmd14buTbiBnaWFvIGThu4tjaCwga2jDtG5nIHTDrW5oIHThu6sgdHJhbmcgZGFuaCBzw6FjaCDEkWFuZyBt4bufLlwiLz48UmVwb3J0UmFuZ2VGaWVsZHMgcmFuZ2U9e3JlcG9ydC5yYW5nZX0gdGltZXpvbmU9e3Nob3AudGltZXpvbmV9IHNldEZyb209e3ZhbHVlID0+IHsgc2V0R2VuZXJhdGVkS2V5KCcnKTsgcmVwb3J0LnNldEZyb20odmFsdWUpOyB9fSBzZXRUbz17dmFsdWUgPT4geyBzZXRHZW5lcmF0ZWRLZXkoJycpOyByZXBvcnQuc2V0VG8odmFsdWUpOyB9fS8+e3JlcG9ydC52YWxpZCA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtkYXRhfT57cCAmJiA8PjxTdGF0cz48U3RhdCB0aXRsZT1cIkRvYW5oIHRodSB0aHXhuqduXCIgdmFsdWU9ezxBbW91bnQgdmFsdWU9e3AubmV0U2FsZXN9Lz59Lz48U3RhdCB0aXRsZT1cIkdpw6EgduG7kW5cIiB2YWx1ZT17PEFtb3VudCB2YWx1ZT17cC5jb2dzfS8+fS8+PFN0YXQgdGl0bGU9XCJMw6NpIGfhu5lwXCIgdmFsdWU9ezxBbW91bnQgdmFsdWU9e3AuZ3Jvc3NQcm9maXR9Lz59IGFjY2VudC8+PFN0YXQgdGl0bGU9XCJM4bujaSBuaHXhuq1uIHbhuq1uIGjDoG5oXCIgdmFsdWU9ezxBbW91bnQgdmFsdWU9e3Aub3BlcmF0aW5nUHJvZml0fS8+fSBub3RlPVwiQ2jGsGEgY8OzIGNo4bupbmcgbmjhuq1uIGvhur8gdG/DoW4gcGjDoXAgxJHhu4tuaFwiLz48L1N0YXRzPjxQYW5lbCB0aXRsZT1cIkNoaSB0aeG6v3Qga+G6v3QgcXXhuqMga2luaCBkb2FuaFwiIGFjdGlvbj17PFN0YXR1cyB2YWx1ZT17cC5jb21wbGV0ZW5lc3N9Lz59PjxCb3ggc3g9e3sgcDogMyB9fT57W1xuICAgICAgICBbJ0RvYW5oIHRodSBn4buZcCcsIHAuZ3Jvc3NTYWxlc10sIFsnR2nhuqNtIGdpw6EnLCBwLmRpc2NvdW50c10sIFsnSMOgbmcgYsOhbiB0cuG6oyBs4bqhaScsIHAuc2FsZXNSZXR1cm5zXSwgWydEb2FuaCB0aHUgdGh14bqnbicsIHAubmV0U2FsZXNdLCBbJ0dpw6EgduG7kW4nLCBwLmNvZ3NdLCBbJ1RodSBwaMOtIGdpYW8nLCBwLnNoaXBwaW5nSW5jb21lXSwgWydDaGkgcGjDrSBnaWFvJywgcC5zaGlwcGluZ0V4cGVuc2VdLCBbJ1Bow60gbuG7gW4gdOG6o25nJywgcC5wbGF0Zm9ybUZlZXNdLCBbJ1Bow60gdGhhbmggdG/DoW4nLCBwLnBheW1lbnRGZWVzXSwgWydDaGkgcGjDrSBBSScsIHAuYWlFeHBlbnNlXSwgWydDaGkgcGjDrSBraMOhYycsIHAub3RoZXJPcGVyYXRpbmdFeHBlbnNlc11cbiAgICBdLm1hcCgoW3QsIHZdKSA9PiA8RGV0YWlsTGluZSBrZXk9e1N0cmluZyh0KX0gbGFiZWw9e1N0cmluZyh0KX0+PEFtb3VudCB2YWx1ZT17dHlwZW9mIHYgPT09ICdvYmplY3QnID8gdiA6IG51bGx9Lz48L0RldGFpbExpbmU+KX08RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPntwLnBvbGljeVZlcnNpb259PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiROG7ryBsaeG7h3UgdOG6oWlcIj57ZGF0ZVRpbWUocC5hc09mKX08L0RldGFpbExpbmU+e3Aud2FybmluZ3MubWFwKHcgPT4gPEFsZXJ0IGtleT17d30gc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e3sgbXQ6IDIgfX0+e3d9PC9BbGVydD4pfTwvQm94PjwvUGFuZWw+PFBhbmVsIHRpdGxlPVwiSOG7j2kgxJHDoXAgY8OzIG5ndeG7k25cIiBzdWJ0aXRsZT1cIkdp4bqjaSB0aMOtY2ggZ2nhu5tpIGjhuqFuIHRoZW8gxJHDum5nIHNuYXBzaG90IMSRYW5nIGhp4buDbiB0aOG7iy5cIj5cbiAgICAgICAge19fTU9DS19fID8gPFN0YWNrIGdhcD17Mn0gc3g9e3sgcDogMyB9fT5cbiAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5DaOG6vyDEkeG7mSBtw7QgcGjhu49uZzogY8OidSB0cuG6oyBs4budaSB0aGVvIG3huqt1IGPhu5EgxJHhu4tuaCwgY2jhu4kgxJHhu41jIGThu68gbGnhu4d1IFAmTCBBUEkgdOG7lW5nIGjhu6NwIG7DoHk7IGtow7RuZyBn4buNaSBBSSB2w6Aga2jDtG5nIGdoaSBz4buVLjwvQWxlcnQ+XG4gICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkPDonUgaOG7j2kgduG7gSBiw6FvIGPDoW9cIiB2YWx1ZT17cXVlc3Rpb259IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldFF1ZXN0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSBhcyBQcm9maXRMb3NzUXVlc3Rpb25JZCk7IHNldEdlbmVyYXRlZEtleSgnJyk7IH19PlxuICAgICAgICAgICAgICAgIHtwcm9maXRMb3NzUXVlc3Rpb25zLm1hcChpdGVtID0+IDxNZW51SXRlbSBrZXk9e2l0ZW0uaWR9IHZhbHVlPXtpdGVtLmlkfT57aXRlbS5sYWJlbH08L01lbnVJdGVtPil9XG4gICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHNldEdlbmVyYXRlZEtleShjdXJyZW50S2V5KX0gZGlzYWJsZWQ9eyFjdXJyZW50S2V5fT5U4bqhbyBnaeG6o2kgdGjDrWNoIG3DtCBwaOG7j25nPC9CdXR0b24+XG4gICAgICAgICAgICB7ZXhwbGFuYXRpb24gJiYgPEJveCByb2xlPVwicmVnaW9uXCIgYXJpYS1sYWJlbD1cIkdp4bqjaSB0aMOtY2ggYsOhbyBjw6FvIG3DtCBwaOG7j25nXCIgZGF0YS10ZXN0aWQ9XCJwcm9maXQtbG9zcy1leHBsYW5hdGlvblwiIHN4PXt7IHA6IDIsIGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6ICdkaXZpZGVyJywgYm9yZGVyUmFkaXVzOiAxIH19PlxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHN4PXt7IG1iOiAyIH19PntleHBsYW5hdGlvbi5hbnN3ZXJ9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIiBzeD17eyBtYjogMSB9fT5E4buvIGxp4buHdSBuZ3Xhu5NuIHRyb25nIHNuYXBzaG90PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIHtleHBsYW5hdGlvbi5zb3VyY2VzLm1hcChzb3VyY2UgPT4gPERldGFpbExpbmUga2V5PXtzb3VyY2UubGFiZWx9IGxhYmVsPXtzb3VyY2UubGFiZWx9Pntzb3VyY2UudmFsdWV9PC9EZXRhaWxMaW5lPil9XG4gICAgICAgICAgICAgICAge2V4cGxhbmF0aW9uLndhcm5pbmdzLm1hcCgod2FybmluZywgaW5kZXgpID0+IDxBbGVydCBrZXk9e2Ake2luZGV4fS0ke3dhcm5pbmd9YH0gc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e3sgbXQ6IDEgfX0+e3dhcm5pbmd9PC9BbGVydD4pfVxuICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17eyBtdDogMiB9fT5I4bujcCDEkeG7k25nIGdldFByb2ZpdExvc3MgY2jGsGEgdHLhuqMgduG7gSBqb3VybmFsIElEIMSR4buDIGRyaWxsLWRvd247IGdpYW8gZGnhu4duIGtow7RuZyB04bqhbyBsacOqbiBr4bq/dCBuZ3Xhu5NuIGdp4bqjLjwvQWxlcnQ+XG4gICAgICAgICAgICA8L0JveD59XG4gICAgICAgIDwvU3RhY2s+IDogPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHN4PXt7IG06IDMgfX0+Q2jhu6ljIG7Eg25nIGdp4bqjaSB0aMOtY2ggY2jhu4kgY8OzIGLhuqNuIHhlbSB0csaw4bubYyBtw7QgcGjhu49uZy4gQVBJIGhp4buHbiBjaMawYSBjw7Mgb3BlcmF0aW9uIGjhu49pIMSRw6FwIGLDoW8gY8Ohby48L0FsZXJ0Pn1cbiAgICA8L1BhbmVsPjwvPn08L1F1ZXJ5U3RhdGU+IDogPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIj5OZ8OgeSBi4bqvdCDEkeG6p3UgcGjhuqNpIHRyxrDhu5tjIG5nw6B5IGvhur90IHRow7pjLjwvQWxlcnQ+fTwvPjtcbn1cbmZ1bmN0aW9uIEpvdXJuYWxBY2NvdW50RmllbGQoeyBpbmRleCwgdmFsdWUsIG9uQ2hhbmdlIH06IHsgaW5kZXg6IG51bWJlcjsgdmFsdWU6IHN0cmluZzsgb25DaGFuZ2U6IChhY2NvdW50SWQ6IHN0cmluZykgPT4gdm9pZCB9KSB7XG4gICAgaWYgKF9fTU9DS19fKSByZXR1cm4gPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9e2BUw6BpIGtob+G6o24gZMOybmcgJHtpbmRleH1gfSBmdWxsV2lkdGggdmFsdWU9e3ZhbHVlfSBlcnJvcj17IXZhbHVlLnRyaW0oKX0gaGVscGVyVGV4dD17dmFsdWUgPyAnVMOgaSBraG/huqNuIHThu5VuZyBo4bujcCBjaOG7iSBkw7luZyBuZ2hp4buHbSB0aHUgVUk7IGtow7RuZyB4w6FjIHRo4buxYyB24bubaSBzxqEgxJHhu5Mga+G6vyB0b8OhbiB0aOG6rXQuJyA6ICdDaOG7jW4gdMOgaSBraG/huqNuIG3huqt1IMSR4buDIGhvw6BuIHThuqV0IGx14buTbmcgZGVtby4nfSBvbkNoYW5nZT17ZXZlbnQgPT4gb25DaGFuZ2UoZXZlbnQudGFyZ2V0LnZhbHVlKX0+XG4gICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPkNo4buNbiB0w6BpIGtob+G6o24gbeG6q3U8L01lbnVJdGVtPlxuICAgICAgICB7ZGVtb0pvdXJuYWxBY2NvdW50cy5tYXAoYWNjb3VudCA9PiA8TWVudUl0ZW0ga2V5PXthY2NvdW50LmlkfSB2YWx1ZT17YWNjb3VudC5pZH0+e2FjY291bnQubGFiZWx9PC9NZW51SXRlbT4pfVxuICAgIDwvVGV4dEZpZWxkPjtcbiAgICByZXR1cm4gPFRleHRGaWVsZCBsYWJlbD17YFTDoGkga2hv4bqjbiBkw7JuZyAke2luZGV4fWB9IGZ1bGxXaWR0aCB2YWx1ZT17dmFsdWV9IGVycm9yPXshdmFsdWUudHJpbSgpfSBoZWxwZXJUZXh0PXshdmFsdWUudHJpbSgpID8gJ05o4bqtcCBJRCBkbyBo4buHIHRo4buRbmcgY+G6pXA7IFVJIGtow7RuZyB04buxIHThuqFvIGRhbmggbeG7pWMgdMOgaSBraG/huqNuLicgOiAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBKb3VybmFsc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RKb3VybmFscycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgpIH0pO1xuICAgIGNvbnN0IFt2aWV3SWQsIHNldFZpZXdJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldEpvdXJuYWwnLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogdmlld0lkIHx8ICcnIH0gfSwgQm9vbGVhbih2aWV3SWQpKTtcbiAgICBjb25zdCB2aWV3ZWRKb3VybmFsID0gZGV0YWlsLmRhdGE/LmRhdGE7XG4gICAgY29uc3QgcGVyaW9kcyA9IHVzZUFwaSgnbGlzdEFjY291bnRpbmdQZXJpb2RzJyk7XG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlSm91cm5hbCcsIFsnbGlzdEpvdXJuYWxzJ10pO1xuICAgIGNvbnN0IHBvc3QgPSB1c2VDb21tYW5kKCdwb3N0Sm91cm5hbCcsIFsnbGlzdEpvdXJuYWxzJ10pO1xuICAgIGNvbnN0IHJldmVyc2UgPSB1c2VDb21tYW5kKCdyZXZlcnNlSm91cm5hbCcsIFsnbGlzdEpvdXJuYWxzJ10pO1xuICAgIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKSwgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTx7IGpvdXJuYWw6IEpvdXJuYWw7IGFjdGlvbjogJ3Bvc3QnIHwgJ3JldmVyc2UnIH0gfCBudWxsPihudWxsKSwgW3NvdXJjZVR5cGUsIHNldFNvdXJjZVR5cGVdID0gdXNlU3RhdGUoJ21hbnVhbCcpLCBbc291cmNlSWQsIHNldFNvdXJjZUlkXSA9IHVzZVN0YXRlKCcnKSwgW2RhdGUsIHNldERhdGVdID0gdXNlU3RhdGUoJzIwMjYtMDktMjknKSwgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBuZXdMaW5lID0gKCk6IEpvdXJuYWxMaW5lID0+ICh7IGFjY291bnRJZDogJycsIGRlYml0OiB7IGFtb3VudDogJzAnLCBjdXJyZW5jeTogc2hvcC5jdXJyZW5jeSB9LCBjcmVkaXQ6IHsgYW1vdW50OiAnMCcsIGN1cnJlbmN5OiBzaG9wLmN1cnJlbmN5IH0sIGRlc2NyaXB0aW9uOiAnJyB9KTtcbiAgICBjb25zdCBbbGluZXMsIHNldExpbmVzXSA9IHVzZVN0YXRlPEpvdXJuYWxMaW5lW10+KFtuZXdMaW5lKCksIG5ld0xpbmUoKV0pO1xuICAgIGNvbnN0IGxpbmVFcnJvcnMgPSBsaW5lcy5tYXAoam91cm5hbExpbmVFcnJvcik7XG4gICAgY29uc3QgZGViaXRUb3RhbCA9IGxpbmVzLnJlZHVjZSgodG90YWwsIGxpbmUpID0+IHRvdGFsICsgKGRlY2ltYWxVbml0cyhsaW5lLmRlYml0LmFtb3VudCkgPz8gMG4pLCAwbik7XG4gICAgY29uc3QgY3JlZGl0VG90YWwgPSBsaW5lcy5yZWR1Y2UoKHRvdGFsLCBsaW5lKSA9PiB0b3RhbCArIChkZWNpbWFsVW5pdHMobGluZS5jcmVkaXQuYW1vdW50KSA/PyAwbiksIDBuKTtcbiAgICBjb25zdCBwZXJpb2QgPSBwZXJpb2RzLmRhdGE/LmRhdGEuZmluZChpdGVtID0+IGRhdGUgPj0gaXRlbS5zdGFydERhdGUgJiYgZGF0ZSA8PSBpdGVtLmVuZERhdGUpO1xuICAgIGNvbnN0IHBlcmlvZE9wZW4gPSBwZXJpb2Q/LnN0YXRlID09PSAnb3Blbic7XG4gICAgY29uc3QgYmFsYW5jZWQgPSBsaW5lcy5sZW5ndGggPj0gMiAmJiBsaW5lRXJyb3JzLmV2ZXJ5KGVycm9yID0+ICFlcnJvcikgJiYgZGViaXRUb3RhbCA9PT0gY3JlZGl0VG90YWwgJiYgZGViaXRUb3RhbCA+IDBuO1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiQsO6dCB0b8OhblwiIHN1YnRpdGxlPVwiU+G7lSBrw6lwIGPDsyBjaOG7qW5nIHThu6sgbmd14buTbiwga2nhu4NtIGPDom4gYuG6sW5nIHThuqFpIEFQSSB2w6Aga2jDtG5nIHPhu61hIGLDunQgdG/DoW4gxJHDoyBnaGkuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0+VOG6oW8gYsO6dCB0b8OhbiBuaMOhcDwvTXV0YXRpb25CdXR0b24+fS8+PFBhbmVsPjxUb29sYmFyLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17am91cm5hbCA9PiBqb3VybmFsLmlkfSBjb2x1bW5zPXtbXG4gICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ0LDunQgdG/DoW4nLCByZW5kZXI6IGpvdXJuYWwgPT4gPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3SWQoam91cm5hbC5pZCl9Pntqb3VybmFsLmlkfTwvQnV0dG9uPiB9LFxuICAgICAgICB7IGtleTogJ2RhdGUnLCBsYWJlbDogJ05nw6B5IGhp4buHdSBs4buxYycsIHJlbmRlcjogam91cm5hbCA9PiBqb3VybmFsLmVmZmVjdGl2ZURhdGUgfSxcbiAgICAgICAgeyBrZXk6ICdzb3VyY2UnLCBsYWJlbDogJ05ndeG7k24nLCByZW5kZXI6IGpvdXJuYWwgPT4gYCR7am91cm5hbC5zb3VyY2VUeXBlfSAvICR7am91cm5hbC5zb3VyY2VJZH1gIH0sXG4gICAgICAgIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGpvdXJuYWwgPT4gPFN0YXR1cyB2YWx1ZT17am91cm5hbC5zdGF0dXN9Lz4gfSxcbiAgICAgICAgeyBrZXk6ICdhY3Rpb25zJywgbGFiZWw6ICcnLCByZW5kZXI6IGpvdXJuYWwgPT4gPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3SWQoam91cm5hbC5pZCl9PkNoaSB0aeG6v3Q8L0J1dHRvbj4gfSxcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxuICAgIDxFZGl0RGlhbG9nIG9wZW49e0Jvb2xlYW4odmlld0lkKX0gdGl0bGU9e3ZpZXdlZEpvdXJuYWwgPyBgQsO6dCB0b8OhbiAke3ZpZXdlZEpvdXJuYWwuaWR9YCA6ICfEkGFuZyB04bqjaSBiw7p0IHRvw6FuJ30gb25DbG9zZT17KCkgPT4gc2V0Vmlld0lkKG51bGwpfSBhY3Rpb25zPXs8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFZpZXdJZChudWxsKX0+xJDDs25nPC9CdXR0b24+fT48UXVlcnlTdGF0ZSBxdWVyeT17ZGV0YWlsfT57dmlld2VkSm91cm5hbCAmJiA8PjxTdGF0dXMgdmFsdWU9e3ZpZXdlZEpvdXJuYWwuc3RhdHVzfS8+PERhdGFUYWJsZSByb3dzPXt2aWV3ZWRKb3VybmFsLmxpbmVzLm1hcCgobGluZSwgaW5kZXgpID0+ICh7IC4uLmxpbmUsIGtleTogU3RyaW5nKGluZGV4KSB9KSl9IHJvd0tleT17bGluZSA9PiBsaW5lLmtleX0gY29sdW1ucz17W1xuICAgICAgICB7IGtleTogJ2FjY291bnQnLCBsYWJlbDogJ1TDoGkga2hv4bqjbicsIHJlbmRlcjogbGluZSA9PiBsaW5lLmFjY291bnRJZCB9LFxuICAgICAgICB7IGtleTogJ2RlYml0JywgbGFiZWw6ICdO4bujJywgcmVuZGVyOiBsaW5lID0+IDxBbW91bnQgdmFsdWU9e2xpbmUuZGViaXR9Lz4gfSxcbiAgICAgICAgeyBrZXk6ICdjcmVkaXQnLCBsYWJlbDogJ0PDsycsIHJlbmRlcjogbGluZSA9PiA8QW1vdW50IHZhbHVlPXtsaW5lLmNyZWRpdH0vPiB9LFxuICAgICAgICB7IGtleTogJ25vdGUnLCBsYWJlbDogJ0Rp4buFbiBnaeG6o2knLCByZW5kZXI6IGxpbmUgPT4gbGluZS5kZXNjcmlwdGlvbiB9LFxuICAgIF19Lz48RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPnt2aWV3ZWRKb3VybmFsLnBvbGljeVZlcnNpb259PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQsO6dCB0b8OhbiBn4buRY1wiPnt2aWV3ZWRKb3VybmFsLnJldmVyc2FsT2YgfHwgJ+KAlCd9PC9EZXRhaWxMaW5lPnt2aWV3ZWRKb3VybmFsLnN0YXR1cyA9PT0gJ2RyYWZ0JyAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZpbmFuY2UucG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHsgam91cm5hbDogdmlld2VkSm91cm5hbCwgYWN0aW9uOiAncG9zdCcgfSl9PkdoaSBz4buVPC9NdXRhdGlvbkJ1dHRvbj59e3ZpZXdlZEpvdXJuYWwuc3RhdHVzID09PSAncG9zdGVkJyAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZpbmFuY2UucG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHsgam91cm5hbDogdmlld2VkSm91cm5hbCwgYWN0aW9uOiAncmV2ZXJzZScgfSl9PsSQ4bqjbyBiw7p0IHRvw6FuPC9NdXRhdGlvbkJ1dHRvbj59PC8+fTwvUXVlcnlTdGF0ZT48L0VkaXREaWFsb2c+XG4gICAgPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9XCJCw7p0IHRvw6FuIG5ow6FwXCIgb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IXNvdXJjZUlkLnRyaW0oKSB8fCByZWFzb24udHJpbSgpLmxlbmd0aCA8IDUgfHwgY3JlYXRlLnBlbmRpbmcgfHwgIWJhbGFuY2VkIHx8ICFwZXJpb2RPcGVufSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IGNyZWF0ZS5leGVjdXRlKHsgYm9keTogeyBzb3VyY2VUeXBlLCBzb3VyY2VJZCwgZWZmZWN0aXZlRGF0ZTogZGF0ZSwgbGluZXMsIHJlYXNvbiB9IH0pOyBzZXRPcGVuKGZhbHNlKTsgfSBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5MxrB1IG5ow6FwPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0vPjxTdGFjayBnYXA9ezJ9PjxBbGVydCBzZXZlcml0eT1cImluZm9cIj57X19NT0NLX18gPyAnRGFuaCBt4bulYyBkxrDhu5tpIMSRw6J5IGzDoCBk4buvIGxp4buHdSB04buVbmcgaOG7o3AgxJHhu4MgbmdoaeG7h20gdGh1IGdpYW8gZGnhu4duLCBraMO0bmcgcGjhuqNpIHPGoSDEkeG7kyBr4bq/IHRvw6FuIMSRw6MgeMOhYyBtaW5oLicgOiAnQ29udHJhY3QgaGnhu4duIGNoxrBhIGPDsyBBUEkgZGFuaCBt4bulYyB0w6BpIGtob+G6o247IGNo4buJIGTDuW5nIG3DoyB0w6BpIGtob+G6o24gZG8gaOG7hyB0aOG7kW5nIGPhuqVwLid9PC9BbGVydD48VGV4dEZpZWxkIGxhYmVsPVwiTG/huqFpIGNo4bupbmcgdOG7qyBuZ3Xhu5NuXCIgdmFsdWU9e3NvdXJjZVR5cGV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRTb3VyY2VUeXBlKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIGNo4bupbmcgdOG7qyBuZ3Xhu5NuXCIgdmFsdWU9e3NvdXJjZUlkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0U291cmNlSWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgdHlwZT1cImRhdGVcIiBsYWJlbD1cIk5nw6B5IGhp4buHdSBs4buxY1wiIHZhbHVlPXtkYXRlfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0RGF0ZShldmVudC50YXJnZXQudmFsdWUpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfX19Lz57cGVyaW9kcy5pc1BlbmRpbmcgPyA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+xJBhbmcgdOG6o2kgdHLhuqFuZyB0aMOhaSBr4buzIGvhur8gdG/DoW7igKY8L0FsZXJ0PiA6IDxBbGVydCBzZXZlcml0eT17cGVyaW9kT3BlbiA/ICdzdWNjZXNzJyA6ICd3YXJuaW5nJ30+e3BlcmlvZCA/IHBlcmlvZE9wZW4gPyBgS+G7syAke3BlcmlvZC5zdGFydERhdGV9IOKAkyAke3BlcmlvZC5lbmREYXRlfSDEkWFuZyBt4bufLmAgOiBgS+G7syAke3BlcmlvZC5zdGFydERhdGV9IOKAkyAke3BlcmlvZC5lbmREYXRlfSDEkcOjIGtow7NhOyBraMO0bmcgdGjhu4MgdOG6oW8gYsO6dCB0b8OhbiBjaG8gbmfDoHkgbsOgeS5gIDogJ0NoxrBhIGPDsyBr4buzIGvhur8gdG/DoW4gY+G6pXUgaMOsbmggY2hvIG5nw6B5IGhp4buHdSBs4buxYy4nfTwvQWxlcnQ+fXtsaW5lcy5tYXAoKGxpbmUsIGluZGV4KSA9PiA8Qm94IGtleT17aW5kZXh9IHN4PXt7IHA6IDIsIGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6IGxpbmVFcnJvcnNbaW5kZXhdID8gJ2Vycm9yLm1haW4nIDogJ2RpdmlkZXInLCBib3JkZXJSYWRpdXM6IDIgfX0+PEpvdXJuYWxBY2NvdW50RmllbGQgaW5kZXg9e2luZGV4ICsgMX0gdmFsdWU9e2xpbmUuYWNjb3VudElkfSBvbkNoYW5nZT17YWNjb3VudElkID0+IHNldExpbmVzKGN1cnJlbnQgPT4gY3VycmVudC5tYXAoKGl0ZW0sIGl0ZW1JbmRleCkgPT4gaXRlbUluZGV4ID09PSBpbmRleCA/IHsgLi4uaXRlbSwgYWNjb3VudElkIH0gOiBpdGVtKSl9Lz48U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgZ2FwPXsxfSBzeD17eyBteTogMS41IH19PnsoWydkZWJpdCcsICdjcmVkaXQnXSBhcyBjb25zdCkubWFwKHNpZGUgPT4gPFRleHRGaWVsZCBrZXk9e3NpZGV9IGxhYmVsPXtzaWRlID09PSAnZGViaXQnID8gJ07hu6MnIDogJ0PDsyd9IHZhbHVlPXtsaW5lW3NpZGVdLmFtb3VudH0gZXJyb3I9e2RlY2ltYWxVbml0cyhsaW5lW3NpZGVdLmFtb3VudCkgPT09IG51bGwgfHwgKHNpZGUgPT09ICdkZWJpdCcgPyBkZWNpbWFsVW5pdHMobGluZS5jcmVkaXQuYW1vdW50KSA6IGRlY2ltYWxVbml0cyhsaW5lLmRlYml0LmFtb3VudCkpID09PSBudWxsfSBoZWxwZXJUZXh0PXtkZWNpbWFsVW5pdHMobGluZVtzaWRlXS5hbW91bnQpID09PSBudWxsID8gJ0TDuW5nIHPhu5EgdGjhuq1wIHBow6JuIHThu5FpIMSRYSA0IGNo4buvIHPhu5EuJyA6ICcnfSBpbnB1dFByb3BzPXt7IGlucHV0TW9kZTogJ2RlY2ltYWwnIH19IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRMaW5lcyhjdXJyZW50ID0+IGN1cnJlbnQubWFwKChpdGVtLCBpdGVtSW5kZXgpID0+IGl0ZW1JbmRleCA9PT0gaW5kZXggPyB7IC4uLml0ZW0sIFtzaWRlXTogeyBhbW91bnQ6IGV2ZW50LnRhcmdldC52YWx1ZSwgY3VycmVuY3k6IHNob3AuY3VycmVuY3kgfSB9IDogaXRlbSkpfS8+KX08L1N0YWNrPjxUZXh0RmllbGQgbGFiZWw9XCJEaeG7hW4gZ2nhuqNpIGTDsm5nXCIgZnVsbFdpZHRoIHZhbHVlPXtsaW5lLmRlc2NyaXB0aW9ufSBlcnJvcj17IWxpbmUuZGVzY3JpcHRpb24udHJpbSgpfSBoZWxwZXJUZXh0PXshbGluZS5kZXNjcmlwdGlvbi50cmltKCkgPyAnQuG6r3QgYnXhu5ljIG5o4bqtcCBkaeG7hW4gZ2nhuqNpLicgOiAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldExpbmVzKGN1cnJlbnQgPT4gY3VycmVudC5tYXAoKGl0ZW0sIGl0ZW1JbmRleCkgPT4gaXRlbUluZGV4ID09PSBpbmRleCA/IHsgLi4uaXRlbSwgZGVzY3JpcHRpb246IGV2ZW50LnRhcmdldC52YWx1ZSB9IDogaXRlbSkpfS8+e2xpbmVFcnJvcnNbaW5kZXhdICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIiBzeD17eyBtdDogMSB9fT57bGluZUVycm9yc1tpbmRleF19PC9BbGVydD59PEJ1dHRvbiBkaXNhYmxlZD17bGluZXMubGVuZ3RoIDw9IDJ9IG9uQ2xpY2s9eygpID0+IHNldExpbmVzKGN1cnJlbnQgPT4gY3VycmVudC5maWx0ZXIoKF8sIGl0ZW1JbmRleCkgPT4gaXRlbUluZGV4ICE9PSBpbmRleCkpfT5C4buPIGTDsm5nPC9CdXR0b24+PC9Cb3g+KX08QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldExpbmVzKGN1cnJlbnQgPT4gWy4uLmN1cnJlbnQsIG5ld0xpbmUoKV0pfT5UaMOqbSBkw7JuZzwvQnV0dG9uPjxBbGVydCBzZXZlcml0eT17YmFsYW5jZWQgPyAnc3VjY2VzcycgOiAnd2FybmluZyd9PlThu5VuZyBO4bujIHtkZWNpbWFsVGV4dChkZWJpdFRvdGFsKX0ge3Nob3AuY3VycmVuY3l9IMK3IFThu5VuZyBDw7Mge2RlY2ltYWxUZXh0KGNyZWRpdFRvdGFsKX0ge3Nob3AuY3VycmVuY3l9e2JhbGFuY2VkID8gJyDCtyDEkMOjIGPDom4gYuG6sW5nJyA6ICcgwrcgQ+G6p24gY8OibiBi4bqxbmcgdsOgIG3hu5dpIGTDsm5nIGNo4buJIGPDsyBt4buZdCBiw6puJ308L0FsZXJ0PjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG9cIiB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz48L1N0YWNrPjwvRWRpdERpYWxvZz5cbiAgICA8Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT17c2VsZWN0ZWQ/LmFjdGlvbiA9PT0gJ3Bvc3QnID8gJ0doaSBz4buVIGLDunQgdG/DoW4nIDogJ8SQ4bqjbyBiw7p0IHRvw6FuJ30gZGVzY3JpcHRpb249XCJCYWNrZW5kIGtp4buDbSBr4buzLCBjw6JuIGLhurFuZywgcXV54buBbiB2w6AgY2jhu6luZyB04burIHRyw7luZyB0csaw4bubYyBraGkgZ2hpLlwiIHJlcXVpcmVSZWFzb249e3NlbGVjdGVkPy5hY3Rpb24gPT09ICdyZXZlcnNlJ30gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGVycm9yPXtwb3N0LmVycm9yIHx8IHJldmVyc2UuZXJyb3J9IGJ1c3k9e3Bvc3QucGVuZGluZyB8fCByZXZlcnNlLnBlbmRpbmd9IG9uQ29uZmlybT17Y29uZmlybVJlYXNvbiA9PiBzZWxlY3RlZD8uYWN0aW9uID09PSAncG9zdCcgPyBwb3N0LmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IHNlbGVjdGVkLmpvdXJuYWwuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkLmpvdXJuYWwudmVyc2lvbiB9IH0pIDogcmV2ZXJzZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZD8uam91cm5hbC5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LmpvdXJuYWwudmVyc2lvbiB8fCAxLCByZWFzb246IGNvbmZpcm1SZWFzb24gfSB9KX0vPjwvPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlY29uY2lsaWF0aW9uUGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IGJhbmtzID0gdXNlQXBpKCdsaXN0QmFua1RyYW5zYWN0aW9ucycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnYmFua0N1cnNvcicpIH0pO1xuICAgIGNvbnN0IGNvZCA9IHVzZUFwaSgnbGlzdENPRFNldHRsZW1lbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdjb2RDdXJzb3InKSB9KTtcbiAgICBjb25zdCBjYXNlcyA9IHVzZUFwaSgnbGlzdFJlY29uY2lsaWF0aW9uQ2FzZXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2Nhc2VDdXJzb3InKSB9KTtcbiAgICBjb25zdCBtYXRjaCA9IHVzZUNvbW1hbmQoJ21hdGNoQ09EU2V0dGxlbWVudCcsIFsnbGlzdENPRFNldHRsZW1lbnRzJywgJ2xpc3RCYW5rVHJhbnNhY3Rpb25zJywgJ2xpc3REZWJ0SXRlbXMnLCAnZ2V0Q2FzaGZsb3cnXSk7XG4gICAgY29uc3QgbWF0Y2hCYW5rID0gdXNlQ29tbWFuZCgnbWF0Y2hTZXR0bGVtZW50JywgWydsaXN0UmVjb25jaWxpYXRpb25DYXNlcycsICdsaXN0QmFua1RyYW5zYWN0aW9ucycsICdsaXN0RGVidEl0ZW1zJ10pO1xuICAgIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8Q09EU2V0dGxlbWVudCB8IG51bGw+KG51bGwpLCBbY2FzZUl0ZW0sIHNldENhc2VdID0gdXNlU3RhdGU8UmVjb25jaWxpYXRpb25DYXNlIHwgbnVsbD4obnVsbCksIFt0cmFuc2FjdGlvbiwgc2V0VHJhbnNhY3Rpb25dID0gdXNlU3RhdGUoJycpLCBbZmVlcywgc2V0RmVlc10gPSB1c2VTdGF0ZSgnMCcpLCBbZXZpZGVuY2UsIHNldEV2aWRlbmNlXSA9IHVzZVN0YXRlKCcnKSwgW3Jlc291cmNlSWQsIHNldFJlc291cmNlXSA9IHVzZVN0YXRlKCcnKSwgW2FsbG9jYXRpb24sIHNldEFsbG9jYXRpb25dID0gdXNlU3RhdGUoJycpLCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpLCBbaW1wb3J0T3Blbiwgc2V0SW1wb3J0XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBiYW5rQ2hvaWNlcyA9IHVzZVBhZ2VkQXBpKCdsaXN0QmFua1RyYW5zYWN0aW9ucycsIHt9LCBCb29sZWFuKHNlbGVjdGVkKSk7XG4gICAgY29uc3QgY2FzZUJhbmsgPSB1c2VBcGkoJ2dldEJhbmtUcmFuc2FjdGlvbicsIHsgcGF0aDogeyByZXNvdXJjZUlkOiBjYXNlSXRlbT8udHJhbnNhY3Rpb25JZCB8fCAnJyB9IH0sIEJvb2xlYW4oY2FzZUl0ZW0pKTtcbiAgICBjb25zdCBkZWJ0Q2hvaWNlcyA9IHVzZVBhZ2VkQXBpKCdsaXN0RGVidEl0ZW1zJywge30sIEJvb2xlYW4oY2FzZUl0ZW0pKTtcbiAgICBjb25zdCBzZWxlY3RlZEJhbmsgPSBjYXNlSXRlbSA/IGNhc2VCYW5rLmRhdGE/LmRhdGEgOiBiYW5rQ2hvaWNlcy5kYXRhPy5kYXRhLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSB0cmFuc2FjdGlvbik7XG4gICAgY29uc3Qgc2VsZWN0ZWREZWJ0ID0gZGVidENob2ljZXMuZGF0YT8uZGF0YS5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gcmVzb3VyY2VJZCk7XG4gICAgY29uc3QgZmVlVW5pdHMgPSBkZWNpbWFsVW5pdHMoZmVlcyksIGFsbG9jYXRpb25Vbml0cyA9IGRlY2ltYWxVbml0cyhhbGxvY2F0aW9uKTtcbiAgICBjb25zdCBjb2RNYXRjaFZhbGlkID0gQm9vbGVhbihzZWxlY3RlZCAmJiBzZWxlY3RlZEJhbmsgJiYgZmVlVW5pdHMgIT09IG51bGwgJiYgZmVlVW5pdHMgPj0gMG4gJiYgZmVlVW5pdHMgPD0gKGRlY2ltYWxVbml0cyhzZWxlY3RlZC5ncm9zc0R1ZS5hbW91bnQpID8/IC0xbikgJiYgKGRlY2ltYWxVbml0cyhzZWxlY3RlZC5ncm9zc0R1ZS5hbW91bnQpID8/IC0xbikgLSBmZWVVbml0cyA9PT0gZGVjaW1hbFVuaXRzKHNlbGVjdGVkQmFuay5hbW91bnQuYW1vdW50KSAmJiBldmlkZW5jZS50cmltKCkpO1xuICAgIGNvbnN0IGJhbmtNYXRjaFZhbGlkID0gQm9vbGVhbihjYXNlSXRlbSAmJiBzZWxlY3RlZEJhbmsgJiYgc2VsZWN0ZWREZWJ0ICYmICFzZWxlY3RlZERlYnQuZGlzcHV0ZWQgJiYgYWxsb2NhdGlvblVuaXRzICE9PSBudWxsICYmIGFsbG9jYXRpb25Vbml0cyA+IDBuICYmIGFsbG9jYXRpb25Vbml0cyA8PSAoZGVjaW1hbFVuaXRzKGNhc2VJdGVtLmRpZmZlcmVuY2UuYW1vdW50KSA/PyAtMW4pICYmIGFsbG9jYXRpb25Vbml0cyA8PSAoZGVjaW1hbFVuaXRzKHNlbGVjdGVkRGVidC5vdXRzdGFuZGluZ0Ftb3VudC5hbW91bnQpID8/IC0xbikgJiYgc2VsZWN0ZWREZWJ0Lm91dHN0YW5kaW5nQW1vdW50LmN1cnJlbmN5ID09PSBzZWxlY3RlZEJhbmsuYW1vdW50LmN1cnJlbmN5ICYmICgoc2VsZWN0ZWRCYW5rLmRpcmVjdGlvbiA9PT0gJ2NyZWRpdCcpID09PSAoc2VsZWN0ZWREZWJ0LmRpcmVjdGlvbiA9PT0gJ3JlY2VpdmFibGUnKSkgJiYgcmVhc29uLnRyaW0oKS5sZW5ndGggPj0gNSk7XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCLEkOG7kWkgc2/DoXQgbmfDom4gaMOgbmcgJiBDT0RcIiBzdWJ0aXRsZT1cIktow6FjaCB0cuG6oyB0aeG7gW4gY2hvIMSRxqFuIHbhu4sgZ2lhbyBow6BuZyBjaMawYSDEkeG7k25nIG5naMSpYSB0aeG7gW4gxJHDoyB24buBIHNob3AuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRJbXBvcnQodHJ1ZSl9Pk5o4bqtcCBi4bqjbmcgxJHhu5FpIHNvw6F0PC9NdXRhdGlvbkJ1dHRvbj59Lz48VGFicyB2YWx1ZT17dGFifSBvbkNoYW5nZT17KF8sIHZhbHVlOiBudW1iZXIpID0+IHNldFRhYih2YWx1ZSl9IHN4PXt7IG1iOiAyIH19IHZhcmlhbnQ9XCJzY3JvbGxhYmxlXCI+PFRhYiBsYWJlbD1cIk5nw6JuIGjDoG5nXCIvPjxUYWIgbGFiZWw9XCJDT0RcIi8+PFRhYiBsYWJlbD1cIkNow6puaCBs4buHY2ggY+G6p24geOG7rSBsw71cIi8+PC9UYWJzPjxQYW5lbD57dGFiID09PSAwID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e2JhbmtzfT57YmFua3MuZGF0YSAmJiA8PjxEYXRhVGFibGUgcm93cz17YmFua3MuZGF0YS5kYXRhfSByb3dLZXk9e3JvdyA9PiByb3cuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnTcOjIG5nb8OgaSBo4buHIHRo4buRbmcnLCByZW5kZXI6IHJvdyA9PiByb3cuZXh0ZXJuYWxUcmFuc2FjdGlvbklkIH0sXG4gICAgICAgIHsga2V5OiAnYWNjb3VudCcsIGxhYmVsOiAnVMOgaSBraG/huqNuJywgcmVuZGVyOiByb3cgPT4gcm93LmFjY291bnRJZCB9LFxuICAgICAgICB7IGtleTogJ21vbmV5JywgbGFiZWw6ICdT4buRIHRp4buBbicsIHJlbmRlcjogcm93ID0+IDxBbW91bnQgdmFsdWU9e3Jvdy5hbW91bnR9Lz4gfSxcbiAgICAgICAgeyBrZXk6ICdkaXJlY3Rpb24nLCBsYWJlbDogJ0NoaeG7gXUnLCByZW5kZXI6IHJvdyA9PiByb3cuZGlyZWN0aW9uID09PSAnY3JlZGl0JyA/ICdUaeG7gW4gdsOgbycgOiAnVGnhu4FuIHJhJyB9LFxuICAgICAgICB7IGtleTogJ25vdGUnLCBsYWJlbDogJ07hu5lpIGR1bmcnLCByZW5kZXI6IHJvdyA9PiByb3cucmVmZXJlbmNlVGV4dCB9LFxuICAgICAgICB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdLaOG7m3AnLCByZW5kZXI6IHJvdyA9PiA8U3RhdHVzIHZhbHVlPXtyb3cubWF0Y2hTdGF0ZX0vPiB9LFxuICAgIF19Lz48UGFnZXIgcGFnZT17YmFua3MuZGF0YS5wYWdlfSBjdXJzb3JQYXJhbT1cImJhbmtDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT4gOiB0YWIgPT09IDEgPyA8UXVlcnlTdGF0ZSBxdWVyeT17Y29kfT57Y29kLmRhdGEgJiYgPD48RGF0YVRhYmxlIHJvd3M9e2NvZC5kYXRhLmRhdGF9IHJvd0tleT17cm93ID0+IHJvdy5pZH0gY29sdW1ucz17W1xuICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICfEkOG7o3QgQ09EJywgcmVuZGVyOiByb3cgPT4gcm93LmV4dGVybmFsQmF0Y2hJZCB9LFxuICAgICAgICB7IGtleTogJ2NhcnJpZXInLCBsYWJlbDogJ8SQxqFuIHbhu4sgZ2lhbycsIHJlbmRlcjogcm93ID0+IHJvdy5jYXJyaWVySWQgfSxcbiAgICAgICAgeyBrZXk6ICdncm9zcycsIGxhYmVsOiAnUGjhuqNpIHRodScsIHJlbmRlcjogcm93ID0+IDxBbW91bnQgdmFsdWU9e3Jvdy5ncm9zc0R1ZX0vPiB9LFxuICAgICAgICB7IGtleTogJ2ZlZScsIGxhYmVsOiAnUGjDrSB0aOG7sWMgdOG6vycsIHJlbmRlcjogcm93ID0+IDxBbW91bnQgdmFsdWU9e3Jvdy5hY3R1YWxGZWVzfS8+IH0sXG4gICAgICAgIHsga2V5OiAnY2FzaCcsIGxhYmVsOiAnxJDDoyB24buBIG5nw6JuIGjDoG5nJywgcmVuZGVyOiByb3cgPT4gPEFtb3VudCB2YWx1ZT17cm93LmJhbmtSZWNlaXZlZH0vPiB9LFxuICAgICAgICB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiByb3cgPT4gPFN0YXR1cyB2YWx1ZT17cm93LnN0YXR1c30vPiB9LFxuICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiByb3cgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIGRpc2FibGVkPXtyb3cuc3RhdHVzID09PSAnbWF0Y2hlZCd9IG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWQocm93KTsgc2V0VHJhbnNhY3Rpb24oJycpOyBzZXRGZWVzKHJvdy5hY3R1YWxGZWVzLmFtb3VudCk7IHNldEV2aWRlbmNlKCcnKTsgfX0+xJDhu5FpIGNoaeG6v3U8L011dGF0aW9uQnV0dG9uPiB9LFxuICAgIF19Lz48UGFnZXIgcGFnZT17Y29kLmRhdGEucGFnZX0gY3Vyc29yUGFyYW09XCJjb2RDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT4gOiA8UXVlcnlTdGF0ZSBxdWVyeT17Y2FzZXN9PntjYXNlcy5kYXRhICYmIDw+PERhdGFUYWJsZSByb3dzPXtjYXNlcy5kYXRhLmRhdGF9IHJvd0tleT17cm93ID0+IHJvdy5pZH0gY29sdW1ucz17W1xuICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICdNw6MnLCByZW5kZXI6IHJvdyA9PiByb3cuaWQgfSxcbiAgICAgICAgeyBrZXk6ICd0cmFuc2FjdGlvbicsIGxhYmVsOiAnR2lhbyBk4buLY2gnLCByZW5kZXI6IHJvdyA9PiBiYW5rcy5kYXRhPy5kYXRhLmZpbmQodHJhbnNhY3Rpb24gPT4gdHJhbnNhY3Rpb24uaWQgPT09IHJvdy50cmFuc2FjdGlvbklkKT8uZXh0ZXJuYWxUcmFuc2FjdGlvbklkIHx8IHJvdy50cmFuc2FjdGlvbklkIH0sXG4gICAgICAgIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IHJvdyA9PiA8U3RhdHVzIHZhbHVlPXtyb3cuc3RhdGV9Lz4gfSxcbiAgICAgICAgeyBrZXk6ICdyZWFzb24nLCBsYWJlbDogJ0PhuqduIHjhu60gbMO9JywgcmVuZGVyOiByb3cgPT4gcm93LnJlYXNvbiB9LFxuICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiByb3cgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIGRpc2FibGVkPXtyb3cuc3RhdGUgPT09ICdtYXRjaGVkJ30gb25DbGljaz17KCkgPT4geyBzZXRDYXNlKHJvdyk7IHNldFRyYW5zYWN0aW9uKHJvdy50cmFuc2FjdGlvbklkKTsgc2V0UmVzb3VyY2UoJycpOyBzZXRBbGxvY2F0aW9uKCcnKTsgc2V0UmVhc29uKCcnKTsgfX0+R2jDqXAgZ2lhbyBk4buLY2g8L011dGF0aW9uQnV0dG9uPiB9LFxuICAgIF19Lz48UGFnZXIgcGFnZT17Y2FzZXMuZGF0YS5wYWdlfSBjdXJzb3JQYXJhbT1cImNhc2VDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT59PC9QYW5lbD5cbiAgICA8RWRpdERpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT1cIkdow6lwIHRp4buBbiBDT0RcIiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17bWF0Y2gucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjb2RNYXRjaFZhbGlkIHx8IG1hdGNoLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHsgYXdhaXQgbWF0Y2guZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2VsZWN0ZWQ/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzZWxlY3RlZD8udmVyc2lvbiB8fCAxLCBiYW5rVHJhbnNhY3Rpb25JZDogdHJhbnNhY3Rpb24sIGFjdHVhbEZlZXM6IHsgYW1vdW50OiBmZWVzLCBjdXJyZW5jeTogc2hvcC5jdXJyZW5jeSB9LCBmZWVFdmlkZW5jZVJlZjogZXZpZGVuY2UsIHJlYXNvbjogJ8SQ4buRaSBjaGnhur91IGLhuqNuZyBDT0QgdsOgIGdpYW8gZOG7i2NoIG5nw6JuIGjDoG5nJyB9IH0pOyBzZXRTZWxlY3RlZChudWxsKTsgfSBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5Yw6FjIG5o4bqtbiBraOG7m3A8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17bWF0Y2guZXJyb3J9Lz48UXVlcnlTdGF0ZSBxdWVyeT17YmFua0Nob2ljZXN9PntiYW5rQ2hvaWNlcy5kYXRhICYmIDxTdGFjayBnYXA9ezJ9PjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTcOjIGdpYW8gZOG7i2NoIG5nw6JuIGjDoG5nXCIgdmFsdWU9e3RyYW5zYWN0aW9ufSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0VHJhbnNhY3Rpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIGdpYW8gZOG7i2NoIGNoxrBhIGdow6lwPC9NZW51SXRlbT57YmFua0Nob2ljZXMuZGF0YS5kYXRhLmZpbHRlcihpdGVtID0+IGl0ZW0uZGlyZWN0aW9uID09PSAnY3JlZGl0JyAmJiBpdGVtLm1hdGNoU3RhdGUgPT09ICd1bm1hdGNoZWQnICYmIGl0ZW0uYW1vdW50LmN1cnJlbmN5ID09PSBzZWxlY3RlZD8uZ3Jvc3NEdWUuY3VycmVuY3kpLm1hcChpdGVtID0+IDxNZW51SXRlbSBrZXk9e2l0ZW0uaWR9IHZhbHVlPXtpdGVtLmlkfT57aXRlbS5leHRlcm5hbFRyYW5zYWN0aW9uSWR9IMK3IHtmb3JtYXRNb25leShpdGVtLmFtb3VudCl9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImdpYW8gZOG7i2NoIG5nw6JuIGjDoG5nXCIgbG9hZGVkQ291bnQ9e2JhbmtDaG9pY2VzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtiYW5rQ2hvaWNlcy5oYXNNb3JlfSBidXN5PXtiYW5rQ2hvaWNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtiYW5rQ2hvaWNlcy5sb2FkTW9yZX0vPjxUZXh0RmllbGQgbGFiZWw9e2BQaMOtIHRo4buxYyB04bq/ICgke3Nob3AuY3VycmVuY3l9KWB9IHZhbHVlPXtmZWVzfSBlcnJvcj17ZmVlVW5pdHMgPT09IG51bGx9IGhlbHBlclRleHQ9e3NlbGVjdGVkQmFuayAmJiBmZWVVbml0cyAhPT0gbnVsbCAmJiAhY29kTWF0Y2hWYWxpZCA/ICdUaeG7gW4gduG7gSArIHBow60gcGjhuqNpIGLhurFuZyBraG/huqNuIENPRCB2w6AgY+G6p24gY2jhu6luZyB04burIHBow60uJyA6ICdOaOG6rXAgcGjDrSB0aGVvIGNo4bupbmcgdOG7qzsga2hv4bqjbiBmZWUgxJHDoyBraOG6pXUgdHLhu6sga2jDtG5nIHBo4bqjaSBjaGkgdGnhu4FuIHRow6ptLid9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRGZWVzKGV2ZW50LnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgaW5wdXRNb2RlOiAnZGVjaW1hbCcgfX0vPjxUZXh0RmllbGQgbGFiZWw9XCJNw6MgY2jhu6luZyB04burIHBow61cIiB2YWx1ZT17ZXZpZGVuY2V9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRFdmlkZW5jZShldmVudC50YXJnZXQudmFsdWUpfS8+PEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPktow7RuZyB4w6FjIG5o4bqtbiB0aGFuaCB0b8OhbiBi4bqxbmcg4bqjbmggY2h1eeG7g24ga2hv4bqjbi4gVOG7lW5nIHRp4buBbiB24buBIHbDoCBwaMOtIHBo4bqjaSBraOG7m3Aga2hv4bqjbiBDT0QuPC9BbGVydD48L1N0YWNrPn08L1F1ZXJ5U3RhdGU+PC9FZGl0RGlhbG9nPlxuICAgIDxFZGl0RGlhbG9nIG9wZW49eyEhY2FzZUl0ZW19IHRpdGxlPVwiR2jDqXAgZ2lhbyBk4buLY2ggduG7m2kgY8O0bmcgbuG7o1wiIG9uQ2xvc2U9eygpID0+IHNldENhc2UobnVsbCl9IGJ1c3k9e21hdGNoQmFuay5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IWJhbmtNYXRjaFZhbGlkIHx8IG1hdGNoQmFuay5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IG1hdGNoQmFuay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBjYXNlSXRlbT8uaWQgfHwgJycgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGNhc2VJdGVtPy52ZXJzaW9uIHx8IDEsIHRyYW5zYWN0aW9uSWQ6IHRyYW5zYWN0aW9uLCBhbGxvY2F0aW9uczogW3sgcmVzb3VyY2U6IHsgdHlwZTogJ2RlYnQnLCBpZDogcmVzb3VyY2VJZCB9LCBhbW91bnQ6IHsgYW1vdW50OiBhbGxvY2F0aW9uLCBjdXJyZW5jeTogc2hvcC5jdXJyZW5jeSB9IH1dLCByZWFzb24gfSB9KTsgc2V0Q2FzZShudWxsKTsgfSBjYXRjaCB7IC8qIGtlZXAgZm9ybSBhbmQgZXJyb3IgKi8gfSB9fT5HaGkga+G6v3QgcXXhuqMgxJHhu5FpIHNvw6F0PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e21hdGNoQmFuay5lcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtjYXNlQmFua30+e2Nhc2VCYW5rLmRhdGEgJiYgPFF1ZXJ5U3RhdGUgcXVlcnk9e2RlYnRDaG9pY2VzfT57ZGVidENob2ljZXMuZGF0YSAmJiA8U3RhY2sgZ2FwPXsyfT48VGV4dEZpZWxkIGxhYmVsPVwiR2lhbyBk4buLY2ggbmdvw6BpIGjhu4cgdGjhu5FuZ1wiIHZhbHVlPXtjYXNlQmFuay5kYXRhLmRhdGEuZXh0ZXJuYWxUcmFuc2FjdGlvbklkfSBJbnB1dFByb3BzPXt7IHJlYWRPbmx5OiB0cnVlIH19Lz48VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIktob+G6o24gY8O0bmcgbuG7o1wiIHZhbHVlPXtyZXNvdXJjZUlkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVzb3VyY2UoZXZlbnQudGFyZ2V0LnZhbHVlKX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIGtob+G6o24gbuG7oyBjaMawYSB0cmFuaCBjaOG6pXA8L01lbnVJdGVtPntkZWJ0Q2hvaWNlcy5kYXRhLmRhdGEuZmlsdGVyKGl0ZW0gPT4gIWl0ZW0uZGlzcHV0ZWQgJiYgaGFzT3V0c3RhbmRpbmdCYWxhbmNlKGl0ZW0ub3V0c3RhbmRpbmdBbW91bnQuYW1vdW50KSAmJiBpdGVtLm91dHN0YW5kaW5nQW1vdW50LmN1cnJlbmN5ID09PSBzZWxlY3RlZEJhbms/LmFtb3VudC5jdXJyZW5jeSAmJiAoKHNlbGVjdGVkQmFuaz8uZGlyZWN0aW9uID09PSAnY3JlZGl0JykgPT09IChpdGVtLmRpcmVjdGlvbiA9PT0gJ3JlY2VpdmFibGUnKSkpLm1hcChpdGVtID0+IDxNZW51SXRlbSBrZXk9e2l0ZW0uaWR9IHZhbHVlPXtpdGVtLmlkfT57aXRlbS5pZH0gwrcge2l0ZW0uZGlyZWN0aW9uID09PSAncmVjZWl2YWJsZScgPyAnUGjhuqNpIHRodScgOiAnUGjhuqNpIHRy4bqjJ30gwrcge2Zvcm1hdE1vbmV5KGl0ZW0ub3V0c3RhbmRpbmdBbW91bnQpfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJjw7RuZyBu4bujXCIgbG9hZGVkQ291bnQ9e2RlYnRDaG9pY2VzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtkZWJ0Q2hvaWNlcy5oYXNNb3JlfSBidXN5PXtkZWJ0Q2hvaWNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtkZWJ0Q2hvaWNlcy5sb2FkTW9yZX0vPjxUZXh0RmllbGQgbGFiZWw9e2BT4buRIHRp4buBbiBwaMOibiBi4buVICgke3Nob3AuY3VycmVuY3l9KWB9IHZhbHVlPXthbGxvY2F0aW9ufSBlcnJvcj17YWxsb2NhdGlvbiAhPT0gJycgJiYgYWxsb2NhdGlvblVuaXRzID09PSBudWxsfSBoZWxwZXJUZXh0PXthbGxvY2F0aW9uVW5pdHMgIT09IG51bGwgJiYgYWxsb2NhdGlvblVuaXRzID4gMG4gJiYgIWJhbmtNYXRjaFZhbGlkID8gJ1Phu5EgdGnhu4FuIHbGsOG7o3QgY2jDqm5oIGzhu4djaC9raG/huqNuIG7hu6MsIGtow6FjIHRp4buBbiB04buHIGhv4bq3YyB0aGnhur91IGzDvSBkby4nIDogJyd9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRBbGxvY2F0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgaW5wdXRNb2RlOiAnZGVjaW1hbCcgfX0vPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG9cIiB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz48L1N0YWNrPn08L1F1ZXJ5U3RhdGU+fTwvUXVlcnlTdGF0ZT48L0VkaXREaWFsb2c+XG4gICAge2ltcG9ydE9wZW4gJiYgPFN0YXRlbWVudERpYWxvZyBvbkNsb3NlPXsoKSA9PiBzZXRJbXBvcnQoZmFsc2UpfS8+fTwvPjtcbn1cbmZ1bmN0aW9uIFN0YXRlbWVudERpYWxvZyh7IG9uQ2xvc2UgfToge1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59KSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IHVwbG9hZCA9IHVzZUNvbW1hbmQoJ3VwbG9hZEZpbGUnLCBbXSksIGJhbmsgPSB1c2VDb21tYW5kKCdpbXBvcnRCYW5rU3RhdGVtZW50JywgWydsaXN0QmFua1RyYW5zYWN0aW9ucycsICdsaXN0UmVjb25jaWxpYXRpb25DYXNlcyddKSwgY29kID0gdXNlQ29tbWFuZCgnaW1wb3J0Q09EU3RhdGVtZW50JywgWydsaXN0Q09EU2V0dGxlbWVudHMnXSk7XG4gICAgY29uc3QgW2tpbmQsIHNldEtpbmRdID0gdXNlU3RhdGUoJ2JhbmsnKSwgW2ZpbGUsIHNldEZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpLCBbYWNjb3VudCwgc2V0QWNjb3VudF0gPSB1c2VTdGF0ZSgnJyksIFtiYXRjaCwgc2V0QmF0Y2hdID0gdXNlU3RhdGUoJycpLCBbZm9ybWF0LCBzZXRGb3JtYXRdID0gdXNlU3RhdGUoJ2JvdHNhbGVzLWNzdi12MScpLCBbam9iSWQsIHNldEpvYl0gPSB1c2VTdGF0ZSgnJyksIFtkcmFmdENvbW1pdCwgc2V0RHJhZnRDb21taXRdID0gdXNlU3RhdGU8eyBzY29wZTogc3RyaW5nIHwgbnVsbDsgc2VxdWVuY2U6IG51bWJlciB9PigpO1xuICAgIHJldHVybiA8RWRpdERpYWxvZyBvcGVuIHRpdGxlPVwiTmjhuq1wIGLhuqNuZyDEkeG7kWkgc2/DoXRcIiBvbkNsb3NlPXtvbkNsb3NlfSBidXN5PXt1cGxvYWQucGVuZGluZyB8fCBiYW5rLnBlbmRpbmcgfHwgY29kLnBlbmRpbmd9IGRyYWZ0Q29tbWl0PXtkcmFmdENvbW1pdH0gYWN0aW9ucz17am9iSWQgPyA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7am9iSWR9YH0+WGVtIGvhur90IHF14bqjIG5o4bqtcDwvUm91dGVMaW5rPiA6IDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshX19NT0NLX18gfHwgIWZpbGUgfHwgIWFjY291bnQgfHwgIWJhdGNoIHx8IHVwbG9hZC5wZW5kaW5nIHx8IGJhbmsucGVuZGluZyB8fCBjb2QucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyBpZiAoIWZpbGUgfHwgIV9fTU9DS19fKVxuICAgICAgICByZXR1cm47IHRyeSB7XG4gICAgICAgIGNvbnN0IGZkID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAgIGZkLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xuICAgICAgICBmZC5hcHBlbmQoJ3B1cnBvc2UnLCBraW5kID09PSAnYmFuaycgPyAnYmFua19zdGF0ZW1lbnQnIDogJ2NvZF9zdGF0ZW1lbnQnKTtcbiAgICAgICAgY29uc3QgZiA9IGF3YWl0IHVwbG9hZC5leGVjdXRlKHsgZm9ybTogZmQgfSk7XG4gICAgICAgIGNvbnN0IGJvZHkgPSB7IGZpbGVJZDogZi5kYXRhLmlkLCBhY2NvdW50T3JDYXJyaWVySWQ6IGFjY291bnQsIGZvcm1hdElkOiBmb3JtYXQsIHNvdXJjZUJhdGNoSWQ6IGJhdGNoIH07XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGtpbmQgPT09ICdiYW5rJyA/IGF3YWl0IGJhbmsuZXhlY3V0ZSh7IGJvZHkgfSkgOiBhd2FpdCBjb2QuZXhlY3V0ZSh7IGJvZHkgfSk7XG4gICAgICAgIHNldEpvYihyZXN1bHQuZGF0YS5pZCk7XG4gICAgICAgIHNldERyYWZ0Q29tbWl0KHByZXZpb3VzID0+ICh7IHNjb3BlOiBudWxsLCBzZXF1ZW5jZTogKHByZXZpb3VzPy5zZXF1ZW5jZSB8fCAwKSArIDEgfSkpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5LaeG7g20gdHJhIHbDoCBuaOG6rXA8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17dXBsb2FkLmVycm9yIHx8IGJhbmsuZXJyb3IgfHwgY29kLmVycm9yfS8+PFN0YWNrIGdhcD17Mn0+eyFfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+SOG7o3AgxJHhu5NuZyB1cGxvYWQgaGnhu4duIGNoxrBhIGPDsyBt4bulYyDEkcOtY2ggY2hvIHThu4dwIMSR4buRaSBzb8OhdC4gTHXhu5NuZyBuw6B5IGNo4buJIGNo4bqheSB0cm9uZyBNU1cgZGVtby48L0FsZXJ0Pn08VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkxv4bqhaSBi4bqjbmdcIiB2YWx1ZT17a2luZH0gb25DaGFuZ2U9e2UgPT4gc2V0S2luZChlLnRhcmdldC52YWx1ZSl9PjxNZW51SXRlbSB2YWx1ZT1cImJhbmtcIj5OZ8OibiBow6BuZzwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiY29kXCI+Q09EPC9NZW51SXRlbT48L1RleHRGaWVsZD48QnV0dG9uIGNvbXBvbmVudD1cImxhYmVsXCIgdmFyaWFudD1cIm91dGxpbmVkXCI+e2ZpbGUgPyBmaWxlLm5hbWUgOiAnQ2jhu41uIENTVid9PGlucHV0IGhpZGRlbiB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5jc3YsdGV4dC9jc3ZcIiBvbkNoYW5nZT17ZSA9PiBzZXRGaWxlKGUudGFyZ2V0LmZpbGVzPy5bMF0gfHwgbnVsbCl9Lz48L0J1dHRvbj48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHTDoGkga2hv4bqjbiAvIMSRxqFuIHbhu4sgduG6rW4gY2h1eeG7g25cIiB2YWx1ZT17YWNjb3VudH0gb25DaGFuZ2U9e2UgPT4gc2V0QWNjb3VudChlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIMSR4bujdCBuaOG6rXAgZHV5IG5o4bqldFwiIHZhbHVlPXtiYXRjaH0gb25DaGFuZ2U9e2UgPT4gc2V0QmF0Y2goZS50YXJnZXQudmFsdWUpfS8+PFRleHRGaWVsZCBsYWJlbD1cIk3DoyDEkeG7i25oIGThuqFuZyDEkcaw4bujYyBiYWNrZW5kIGjhu5cgdHLhu6NcIiB2YWx1ZT17Zm9ybWF0fSBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtYXQoZS50YXJnZXQudmFsdWUpfS8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPk3huqt1IENTViB2w6AgxJHhu4tuaCBk4bqhbmcgbcO0IHBo4buPbmcgbuG6sW0gdHJvbmcgc2FtcGxlcy8uIMSQ4buLbmggZOG6oW5nIG5nw6JuIGjDoG5nIHRo4bqtdCBwaOG6o2kgxJHGsOG7o2MgYmFja2VuZCB4w6FjIG5o4bqtbjsgbmjhuq1wIGtow7RuZyDEkeG7k25nIG5naMSpYSDEkeG7kWkgc2/DoXQgeG9uZy48L0FsZXJ0PjwvU3RhY2s+PC9FZGl0RGlhbG9nPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBEZWJ0c1BhZ2UoKSB7XG4gICAgY29uc3QgZGVidHMgPSB1c2VBcGkoJ2xpc3REZWJ0SXRlbXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoKSB9KSwgcGVyaW9kcyA9IHVzZUFwaSgnbGlzdEFjY291bnRpbmdQZXJpb2RzJyk7XG4gICAgY29uc3QgY2xvc2UgPSB1c2VDb21tYW5kKCdjbG9zZUFjY291bnRpbmdQZXJpb2QnLCBbJ2xpc3RBY2NvdW50aW5nUGVyaW9kcyddKTtcbiAgICBjb25zdCByZW9wZW4gPSB1c2VDb21tYW5kKCdyZW9wZW5BY2NvdW50aW5nUGVyaW9kJywgWydsaXN0QWNjb3VudGluZ1BlcmlvZHMnXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxBY2NvdW50aW5nUGVyaW9kIHwgbnVsbD4obnVsbCksIFthcHByb3ZhbCwgc2V0QXBwcm92YWxdID0gdXNlU3RhdGUoJycpLCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpO1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiQ8O0bmcgbuG7oyAmIGtow7NhIGvhu7NcIiBzdWJ0aXRsZT1cIlRoZW8gZMO1aSBraG/huqNuIGPDsm4gcGjhuqNpIHRodS90cuG6ozsga2jDs2Ega+G7syBjaOG7iSBraGkgY8OhYyDEkWnhu4F1IGtp4buHbiDEkcaw4bujYyBraeG7g20gY2jhu6luZy5cIi8+PFBhbmVsIHRpdGxlPVwiQ8O0bmcgbuG7o1wiPjxRdWVyeVN0YXRlIHF1ZXJ5PXtkZWJ0c30+e2RlYnRzLmRhdGEgJiYgPD48RGF0YVRhYmxlIHJvd3M9e2RlYnRzLmRhdGEuZGF0YX0gcm93S2V5PXtyID0+IHIuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnS2hv4bqjbiBu4bujJywgcmVuZGVyOiByID0+IHIuaWQgfSwgeyBrZXk6ICd3aG8nLCBsYWJlbDogJ8SQ4buRaSB0xrDhu6NuZycsIHJlbmRlcjogciA9PiBgJHtyLmNvdW50ZXJwYXJ0eVR5cGV9IC8gJHtyLmNvdW50ZXJwYXJ0eUlkfWAgfSwgeyBrZXk6ICdkaXJlY3Rpb24nLCBsYWJlbDogJ0xv4bqhaScsIHJlbmRlcjogciA9PiByLmRpcmVjdGlvbiA9PT0gJ3JlY2VpdmFibGUnID8gJ1Bo4bqjaSB0aHUnIDogJ1Bo4bqjaSB0cuG6oycgfSwgeyBrZXk6ICdvcmlnaW5hbCcsIGxhYmVsOiAnQmFuIMSR4bqndScsIHJlbmRlcjogciA9PiA8QW1vdW50IHZhbHVlPXtyLm9yaWdpbmFsQW1vdW50fS8+IH0sIHsga2V5OiAnY3VycmVudCcsIGxhYmVsOiAnQ8OybiBs4bqhaScsIHJlbmRlcjogciA9PiA8QW1vdW50IHZhbHVlPXtyLm91dHN0YW5kaW5nQW1vdW50fS8+IH0sIHsga2V5OiAnZHVlJywgbGFiZWw6ICfEkOG6v24gaOG6oW4nLCByZW5kZXI6IHIgPT4gZGF0ZVRpbWUoci5kdWVBdCkgfSwgeyBrZXk6ICdkaXNwdXRlJywgbGFiZWw6ICdUcmFuaCBjaOG6pXAnLCByZW5kZXI6IHIgPT4gci5kaXNwdXRlZCA/ICfEkGFuZyBnaeG7ryB44butIGzDvScgOiAnS2jDtG5nJyB9XG4gICAgXX0vPjxQYWdlciBwYWdlPXtkZWJ0cy5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PFBhbmVsIHRpdGxlPVwiS+G7syBr4bq/IHRvw6FuXCIgc3g9e3sgbXQ6IDMgfX0+PFF1ZXJ5U3RhdGUgcXVlcnk9e3BlcmlvZHN9PjxEYXRhVGFibGUgcm93cz17cGVyaW9kcy5kYXRhPy5kYXRhIHx8IFtdfSByb3dLZXk9e3IgPT4gci5pZH0gY29sdW1ucz17W1xuICAgICAgICB7IGtleTogJ3BlcmlvZCcsIGxhYmVsOiAnS+G7sycsIHJlbmRlcjogciA9PiBgJHtyLnN0YXJ0RGF0ZX0g4oaSICR7ci5lbmREYXRlfWAgfSwgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLnN0YXRlfS8+IH0sIHsga2V5OiAnaXNzdWVzJywgbGFiZWw6ICfEkGnhu4F1IGtp4buHbiBjw7JuIHRoaeG6v3UnLCByZW5kZXI6IHIgPT4gci5ibG9ja2luZ0lzc3Vlcy5qb2luKCc7ICcpIHx8ICdYw6FjIG1pbmggbOG6oWkgdOG6oWkgbMO6YyBnaGknIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiByID0+IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5jbG9zZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWQocik7IHNldEFwcHJvdmFsKCcnKTsgc2V0UmVhc29uKCcnKTsgfX0+e3Iuc3RhdGUgPT09ICdjbG9zZWQnID8gJ03hu58gbOG6oWkgY8OzIHBow6ogZHV54buHdCcgOiAnS2nhu4NtICYga2jDs2Ega+G7syd9PC9NdXRhdGlvbkJ1dHRvbj5cbiAgICAgICAgfVxuICAgIF19Lz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD48Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkICYmIHNlbGVjdGVkLnN0YXRlICE9PSAnY2xvc2VkJ30gdGl0bGU9XCJLaMOzYSBr4buzIGvhur8gdG/DoW5cIiBkZXNjcmlwdGlvbj1cIkJhY2tlbmQga2nhu4NtIGzhuqFpIGNo4bupbmcgdOG7qyBuaMOhcCwgc2FpIGzhu4djaCwgQ09EIHbDoCBxdXnhu4FuIHRyxrDhu5tjIGtoaSBraMOzYTsga2jDtG5nIHjDs2Egc2FpIGzhu4djaCDEkeG7gyB2xrDhu6N0IGtp4buDbSB0cmEuXCIgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGJ1c3k9e2Nsb3NlLnBlbmRpbmd9IGVycm9yPXtjbG9zZS5lcnJvcn0gb25Db25maXJtPXsoKSA9PiBjbG9zZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZD8uaWQgfHwgJycgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkPy52ZXJzaW9uIHx8IDEgfSB9KX0vPjxFZGl0RGlhbG9nIG9wZW49e3NlbGVjdGVkPy5zdGF0ZSA9PT0gJ2Nsb3NlZCd9IHRpdGxlPVwiTeG7nyBs4bqhaSBr4buzIMSRw6Mga2jDs2FcIiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17cmVvcGVuLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gZGlzYWJsZWQ9eyFhcHByb3ZhbCB8fCByZWFzb24ubGVuZ3RoIDwgNSB8fCByZW9wZW4ucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBhd2FpdCByZW9wZW4uZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2VsZWN0ZWQ/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzZWxlY3RlZD8udmVyc2lvbiB8fCAxLCBhcHByb3ZhbElkOiBhcHByb3ZhbCwgcmVhc29uIH0gfSk7XG4gICAgICAgIHNldFNlbGVjdGVkKG51bGwpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5N4bufIGzhuqFpIGvhu7M8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17cmVvcGVuLmVycm9yfS8+PFN0YWNrIGdhcD17Mn0+PFRleHRGaWVsZCBsYWJlbD1cIk3DoyBwaMOqIGR1eeG7h3QgxJHDum5nIGvhu7NcIiB2YWx1ZT17YXBwcm92YWx9IG9uQ2hhbmdlPXtlID0+IHNldEFwcHJvdmFsKGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG9cIiB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfS8+PC9TdGFjaz48L0VkaXREaWFsb2c+PC8+O1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvZmluYW5jZS9pbmRleC50c3gifQ==