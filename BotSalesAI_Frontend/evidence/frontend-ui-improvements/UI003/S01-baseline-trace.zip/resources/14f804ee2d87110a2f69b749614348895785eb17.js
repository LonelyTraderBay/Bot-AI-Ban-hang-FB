import __vite__cjsImport0_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/react.js?v=89ec09ef"; const useCallback = __vite__cjsImport0_react["useCallback"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];
import { useInfiniteQuery, useQuery, useQueryClient } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27480-492ce36b-6a60-4f46-8ba2-f4f3f86273cd-fe015-ui003-timezone/deps/@tanstack_react-query.js?v=d7dea216";
import { operations } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/contracts/src/index.ts";
import { request } from "/src/shared/api/client.ts";
import { ApiError, UnknownResultError } from "/src/shared/api/errors.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { rememberUnknown, hasUnknownIntent } from "/src/shared/api/intents.ts";
export function useApi(op, options = {}, enabled = true) {
  const scope = useScope();
  const { user } = scope.session;
  const path = { shopId: scope.shop.id, ...options.path };
  const query = options.query || {};
  return useQuery({
    queryKey: ["scope", user.id, scope.shop.id, scope.membership.permissionVersion, op, path, query],
    queryFn: ({ signal }) => request(op, { ...options, path, signal }),
    enabled,
    staleTime: 5e3,
    retry: (count, error) => count < 1 && (!(error instanceof ApiError) || error.status >= 500)
  });
}
export function usePagedApi(op, options = {}, enabled = true) {
  const scope = useScope();
  const { user } = scope.session;
  const path = { shopId: scope.shop.id, ...options.path };
  const { cursor: _cursor, limit: requestedLimit, ...filters } = options.query || {};
  const limit = typeof requestedLimit === "number" && requestedLimit > 0 ? Math.min(requestedLimit, 100) : 20;
  const query = useInfiniteQuery({
    queryKey: ["scope", user.id, scope.shop.id, scope.membership.permissionVersion, op, path, { ...filters, limit, paged: true }],
    initialPageParam: void 0,
    queryFn: ({ signal, pageParam }) => request(op, { ...options, path, query: { ...filters, limit, cursor: pageParam }, signal }),
    getNextPageParam: (lastPage2) => {
      const page = lastPage2.page;
      return page?.hasMore && page.nextCursor ? page.nextCursor : void 0;
    },
    enabled,
    staleTime: 5e3,
    retry: (count, error) => count < 1 && (!(error instanceof ApiError) || error.status >= 500)
  });
  const pages = query.data?.pages || [];
  const lastPage = pages.at(-1);
  const data = lastPage ? {
    ...lastPage,
    data: pages.flatMap((page) => page.data)
  } : void 0;
  return {
    ...query,
    data,
    loadedCount: data ? data.data.length : 0,
    loadMore: () => query.hasNextPage ? query.fetchNextPage() : Promise.resolve(void 0),
    hasMore: Boolean(query.hasNextPage),
    isLoadingMore: query.isFetchingNextPage
  };
}
export function useCommand(op, invalidate) {
  const scope = useScope();
  const cache = useQueryClient();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState(null);
  const inFlight = useRef(false);
  const unresolved = useRef(false);
  if (!hasUnknownIntent(scope.shop.id, op))
    unresolved.current = false;
  const execute = useCallback(async (...args) => {
    const options = args[0] ?? {};
    if (inFlight.current || unresolved.current || hasUnknownIntent(scope.shop.id, op))
      throw new ApiError(409, "IN_FLIGHT", "Thao tác đang xử lý hoặc chưa xác minh kết quả.");
    if (!scope.online)
      throw new ApiError(0, "OFFLINE", "Đang ngoại tuyến. Không gửi thay đổi.");
    inFlight.current = true;
    setPending(true);
    setError(null);
    try {
      const result = await request(op, { ...options, path: { shopId: scope.shop.id, ...options.path }, idempotencyKey: options.idempotencyKey || crypto.randomUUID() });
      let settledResult = result;
      if (operations[op].responseSchema === "CommandResponse" && result && typeof result === "object" && "data" in result) {
        const command = result.data;
        if (command && typeof command === "object" && "id" in command && typeof command.id === "string" && "status" in command) {
          let observed = command.status;
          if (observed === "failed")
            throw new ApiError(409, "COMMAND_FAILED", "Lệnh bị từ chối; xem kết quả kiểm tra của backend.");
          for (let attempt = 0; ["accepted", "running"].includes(String(observed)) && attempt < 8; attempt++) {
            await new Promise((resolve) => setTimeout(resolve, 400 + attempt * 150));
            let current;
            try {
              current = await request("getCommand", { path: { shopId: scope.shop.id, commandId: command.id } });
            } catch {
              throw new UnknownResultError(options.idempotencyKey || command.id, command.id);
            }
            observed = current.data.status;
            settledResult = current;
            if (observed === "failed")
              throw new ApiError(409, current.data.problem?.code || "COMMAND_FAILED", current.data.problem?.detail || "Lệnh bị từ chối.");
          }
          if (["unknown", "accepted", "running"].includes(String(observed)))
            throw new UnknownResultError(options.idempotencyKey || command.id, command.id);
        }
      }
      await Promise.all(invalidate.map((id) => cache.invalidateQueries({ queryKey: ["scope", scope.session.user.id, scope.shop.id, scope.membership.permissionVersion, id] })));
      return settledResult;
    } catch (e) {
      const error2 = e instanceof Error ? e : new Error("Yêu cầu thất bại");
      setError(error2);
      if (error2 instanceof UnknownResultError) {
        unresolved.current = true;
        rememberUnknown({ intentId: error2.intentId, commandId: error2.commandId || null, shopId: scope.shop.id, operation: op });
      }
      throw error2;
    } finally {
      inFlight.current = false;
      setPending(false);
    }
  }, [cache, invalidate, op, scope]);
  return {
    execute,
    pending,
    error,
    clearError: () => setError(null),
    resetAfterReconcile: () => {
      unresolved.current = false;
      setError(null);
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvb2tzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSW5maW5pdGVRdWVyeSwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5JztcbmltcG9ydCB0eXBlIHsgSW5maW5pdGVEYXRhIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5JztcbmltcG9ydCB0eXBlIHsgQ29tbWFuZFJlc3BvbnNlLCBPcGVyYXRpb25JZCwgUmVzcG9uc2VPZiB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgb3BlcmF0aW9ucyB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgcmVxdWVzdCB9IGZyb20gJy4vY2xpZW50JztcbmltcG9ydCB0eXBlIHsgQXBpQXJndW1lbnRzLCBBcGlPcHRpb25zLCBNdXRhdGlvbk9wZXJhdGlvbklkLCBRdWVyeUFwaU9wdGlvbnMsIFF1ZXJ5T3BlcmF0aW9uSWQgfSBmcm9tICcuL2NsaWVudCc7XG5pbXBvcnQgeyBBcGlFcnJvciwgVW5rbm93blJlc3VsdEVycm9yIH0gZnJvbSAnLi9lcnJvcnMnO1xuaW1wb3J0IHsgdXNlU2NvcGUgfSBmcm9tICcuLi9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyByZW1lbWJlclVua25vd24sIGhhc1Vua25vd25JbnRlbnQgfSBmcm9tICcuL2ludGVudHMnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUFwaTxLIGV4dGVuZHMgUXVlcnlPcGVyYXRpb25JZD4ob3A6IEssIG9wdGlvbnM6IE9taXQ8UXVlcnlBcGlPcHRpb25zPEs+LCAnc2lnbmFsJz4gPSB7fSwgZW5hYmxlZCA9IHRydWUpIHtcbiAgICBjb25zdCBzY29wZSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBzY29wZS5zZXNzaW9uO1xuICAgIGNvbnN0IHBhdGggPSB7IHNob3BJZDogc2NvcGUuc2hvcC5pZCwgLi4ub3B0aW9ucy5wYXRoIH07XG4gICAgY29uc3QgcXVlcnkgPSBvcHRpb25zLnF1ZXJ5IHx8IHt9O1xuICAgIHJldHVybiB1c2VRdWVyeTxSZXNwb25zZU9mPEs+LCBFcnJvcj4oe1xuICAgICAgICBxdWVyeUtleTogWydzY29wZScsIHVzZXIuaWQsIHNjb3BlLnNob3AuaWQsIHNjb3BlLm1lbWJlcnNoaXAucGVybWlzc2lvblZlcnNpb24sIG9wLCBwYXRoLCBxdWVyeV0sXG4gICAgICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiByZXF1ZXN0KG9wLCB7IC4uLm9wdGlvbnMsIHBhdGgsIHNpZ25hbCB9KSxcbiAgICAgICAgZW5hYmxlZCwgc3RhbGVUaW1lOiA1MDAwLFxuICAgICAgICByZXRyeTogKGNvdW50LCBlcnJvcikgPT4gY291bnQgPCAxICYmICghKGVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IpIHx8IGVycm9yLnN0YXR1cyA+PSA1MDApLFxuICAgIH0pO1xufVxuXG4vKiogTG9hZHMgbG9va3VwIGNob2ljZXMgaW4gYm91bmRlZCBjdXJzb3IgcGFnZXMgYW5kIHJldGFpbnMgcHJpb3IgcGFnZXMgZm9yIHNlbGVjdGVkIHZhbHVlcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VQYWdlZEFwaTxLIGV4dGVuZHMgUXVlcnlPcGVyYXRpb25JZD4ob3A6IEssIG9wdGlvbnM6IE9taXQ8UXVlcnlBcGlPcHRpb25zPEs+LCAnc2lnbmFsJz4gPSB7fSwgZW5hYmxlZCA9IHRydWUpIHtcbiAgICBjb25zdCBzY29wZSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBzY29wZS5zZXNzaW9uO1xuICAgIGNvbnN0IHBhdGggPSB7IHNob3BJZDogc2NvcGUuc2hvcC5pZCwgLi4ub3B0aW9ucy5wYXRoIH07XG4gICAgY29uc3QgeyBjdXJzb3I6IF9jdXJzb3IsIGxpbWl0OiByZXF1ZXN0ZWRMaW1pdCwgLi4uZmlsdGVycyB9ID0gKG9wdGlvbnMucXVlcnkgfHwge30pIGFzIFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCB1bmRlZmluZWQ+O1xuICAgIGNvbnN0IGxpbWl0ID0gdHlwZW9mIHJlcXVlc3RlZExpbWl0ID09PSAnbnVtYmVyJyAmJiByZXF1ZXN0ZWRMaW1pdCA+IDAgPyBNYXRoLm1pbihyZXF1ZXN0ZWRMaW1pdCwgMTAwKSA6IDIwO1xuICAgIGNvbnN0IHF1ZXJ5ID0gdXNlSW5maW5pdGVRdWVyeTxSZXNwb25zZU9mPEs+LCBFcnJvciwgSW5maW5pdGVEYXRhPFJlc3BvbnNlT2Y8Sz4sIHN0cmluZyB8IHVuZGVmaW5lZD4sIHJlYWRvbmx5IHVua25vd25bXSwgc3RyaW5nIHwgdW5kZWZpbmVkPih7XG4gICAgICAgIHF1ZXJ5S2V5OiBbJ3Njb3BlJywgdXNlci5pZCwgc2NvcGUuc2hvcC5pZCwgc2NvcGUubWVtYmVyc2hpcC5wZXJtaXNzaW9uVmVyc2lvbiwgb3AsIHBhdGgsIHsgLi4uZmlsdGVycywgbGltaXQsIHBhZ2VkOiB0cnVlIH1dLFxuICAgICAgICBpbml0aWFsUGFnZVBhcmFtOiB1bmRlZmluZWQsXG4gICAgICAgIHF1ZXJ5Rm46ICh7IHNpZ25hbCwgcGFnZVBhcmFtIH0pID0+IHJlcXVlc3Qob3AsIHsgLi4ub3B0aW9ucywgcGF0aCwgcXVlcnk6IHsgLi4uZmlsdGVycywgbGltaXQsIGN1cnNvcjogcGFnZVBhcmFtIH0gYXMgUXVlcnlBcGlPcHRpb25zPEs+WydxdWVyeSddLCBzaWduYWwgfSksXG4gICAgICAgIGdldE5leHRQYWdlUGFyYW06IGxhc3RQYWdlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBhZ2UgPSAobGFzdFBhZ2UgYXMgdW5rbm93biBhcyB7IHBhZ2U/OiB7IGhhc01vcmU6IGJvb2xlYW47IG5leHRDdXJzb3I6IHN0cmluZyB8IG51bGwgfSB9KS5wYWdlO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2U/Lmhhc01vcmUgJiYgcGFnZS5uZXh0Q3Vyc29yID8gcGFnZS5uZXh0Q3Vyc29yIDogdW5kZWZpbmVkO1xuICAgICAgICB9LFxuICAgICAgICBlbmFibGVkLFxuICAgICAgICBzdGFsZVRpbWU6IDUwMDAsXG4gICAgICAgIHJldHJ5OiAoY291bnQsIGVycm9yKSA9PiBjb3VudCA8IDEgJiYgKCEoZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvcikgfHwgZXJyb3Iuc3RhdHVzID49IDUwMCksXG4gICAgfSk7XG4gICAgY29uc3QgcGFnZXMgPSBxdWVyeS5kYXRhPy5wYWdlcyB8fCBbXTtcbiAgICBjb25zdCBsYXN0UGFnZSA9IHBhZ2VzLmF0KC0xKTtcbiAgICBjb25zdCBkYXRhID0gbGFzdFBhZ2UgPyB7XG4gICAgICAgIC4uLihsYXN0UGFnZSBhcyBvYmplY3QpLFxuICAgICAgICBkYXRhOiBwYWdlcy5mbGF0TWFwKHBhZ2UgPT4gKHBhZ2UgYXMgdW5rbm93biBhcyB7IGRhdGE6IHVua25vd25bXSB9KS5kYXRhKSxcbiAgICB9IGFzIFJlc3BvbnNlT2Y8Sz4gOiB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgLi4ucXVlcnksXG4gICAgICAgIGRhdGEsXG4gICAgICAgIGxvYWRlZENvdW50OiBkYXRhID8gKChkYXRhIGFzIHVua25vd24gYXMgeyBkYXRhOiB1bmtub3duW10gfSkuZGF0YS5sZW5ndGgpIDogMCxcbiAgICAgICAgbG9hZE1vcmU6ICgpID0+IHF1ZXJ5Lmhhc05leHRQYWdlID8gcXVlcnkuZmV0Y2hOZXh0UGFnZSgpIDogUHJvbWlzZS5yZXNvbHZlKHVuZGVmaW5lZCksXG4gICAgICAgIGhhc01vcmU6IEJvb2xlYW4ocXVlcnkuaGFzTmV4dFBhZ2UpLFxuICAgICAgICBpc0xvYWRpbmdNb3JlOiBxdWVyeS5pc0ZldGNoaW5nTmV4dFBhZ2UsXG4gICAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNvbW1hbmQ8SyBleHRlbmRzIE11dGF0aW9uT3BlcmF0aW9uSWQ+KG9wOiBLLCBpbnZhbGlkYXRlOiByZWFkb25seSBPcGVyYXRpb25JZFtdKSB7XG4gICAgY29uc3Qgc2NvcGUgPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGNhY2hlID0gdXNlUXVlcnlDbGllbnQoKTtcbiAgICBjb25zdCBbcGVuZGluZywgc2V0UGVuZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGluRmxpZ2h0ID0gdXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCB1bnJlc29sdmVkID0gdXNlUmVmKGZhbHNlKTtcbiAgICBpZiAoIWhhc1Vua25vd25JbnRlbnQoc2NvcGUuc2hvcC5pZCwgb3ApKVxuICAgICAgICB1bnJlc29sdmVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICBjb25zdCBleGVjdXRlID0gdXNlQ2FsbGJhY2soYXN5bmMgKC4uLmFyZ3M6IEFwaUFyZ3VtZW50czxLPik6IFByb21pc2U8UmVzcG9uc2VPZjxLPj4gPT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gKGFyZ3NbMF0gPz8ge30pIGFzIEFwaU9wdGlvbnM8Sz47XG4gICAgICAgIGlmIChpbkZsaWdodC5jdXJyZW50IHx8IHVucmVzb2x2ZWQuY3VycmVudCB8fCBoYXNVbmtub3duSW50ZW50KHNjb3BlLnNob3AuaWQsIG9wKSlcbiAgICAgICAgICAgIHRocm93IG5ldyBBcGlFcnJvcig0MDksICdJTl9GTElHSFQnLCAnVGhhbyB0w6FjIMSRYW5nIHjhu60gbMO9IGhv4bq3YyBjaMawYSB4w6FjIG1pbmgga+G6v3QgcXXhuqMuJyk7XG4gICAgICAgIGlmICghc2NvcGUub25saW5lKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEFwaUVycm9yKDAsICdPRkZMSU5FJywgJ8SQYW5nIG5nb+G6oWkgdHV54bq/bi4gS2jDtG5nIGfhu61pIHRoYXkgxJHhu5VpLicpO1xuICAgICAgICBpbkZsaWdodC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgc2V0UGVuZGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXF1ZXN0KG9wLCB7IC4uLm9wdGlvbnMsIHBhdGg6IHsgc2hvcElkOiBzY29wZS5zaG9wLmlkLCAuLi5vcHRpb25zLnBhdGggfSwgaWRlbXBvdGVuY3lLZXk6IG9wdGlvbnMuaWRlbXBvdGVuY3lLZXkgfHwgY3J5cHRvLnJhbmRvbVVVSUQoKSB9KTtcbiAgICAgICAgICAgIGxldCBzZXR0bGVkUmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICAgICAgaWYgKG9wZXJhdGlvbnNbb3BdLnJlc3BvbnNlU2NoZW1hID09PSAnQ29tbWFuZFJlc3BvbnNlJyAmJiByZXN1bHQgJiYgdHlwZW9mIHJlc3VsdCA9PT0gJ29iamVjdCcgJiYgJ2RhdGEnIGluIHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbW1hbmQgPSByZXN1bHQuZGF0YTtcbiAgICAgICAgICAgICAgICBpZiAoY29tbWFuZCAmJiB0eXBlb2YgY29tbWFuZCA9PT0gJ29iamVjdCcgJiYgJ2lkJyBpbiBjb21tYW5kICYmIHR5cGVvZiBjb21tYW5kLmlkID09PSAnc3RyaW5nJyAmJiAnc3RhdHVzJyBpbiBjb21tYW5kKSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBvYnNlcnZlZCA9IGNvbW1hbmQuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JzZXJ2ZWQgPT09ICdmYWlsZWQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwaUVycm9yKDQwOSwgJ0NPTU1BTkRfRkFJTEVEJywgJ0zhu4duaCBi4buLIHThu6sgY2jhu5FpOyB4ZW0ga+G6v3QgcXXhuqMga2nhu4NtIHRyYSBj4bunYSBiYWNrZW5kLicpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBhdHRlbXB0ID0gMDsgWydhY2NlcHRlZCcsICdydW5uaW5nJ10uaW5jbHVkZXMoU3RyaW5nKG9ic2VydmVkKSkgJiYgYXR0ZW1wdCA8IDg7IGF0dGVtcHQrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDQwMCArIGF0dGVtcHQgKiAxNTApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjdXJyZW50OiBDb21tYW5kUmVzcG9uc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnQgPSBhd2FpdCByZXF1ZXN0KCdnZXRDb21tYW5kJywgeyBwYXRoOiB7IHNob3BJZDogc2NvcGUuc2hvcC5pZCwgY29tbWFuZElkOiBjb21tYW5kLmlkIH0gfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFVua25vd25SZXN1bHRFcnJvcihvcHRpb25zLmlkZW1wb3RlbmN5S2V5IHx8IGNvbW1hbmQuaWQsIGNvbW1hbmQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZWQgPSBjdXJyZW50LmRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0dGxlZFJlc3VsdCA9IGN1cnJlbnQgYXMgUmVzcG9uc2VPZjxLPjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvYnNlcnZlZCA9PT0gJ2ZhaWxlZCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwaUVycm9yKDQwOSwgY3VycmVudC5kYXRhLnByb2JsZW0/LmNvZGUgfHwgJ0NPTU1BTkRfRkFJTEVEJywgY3VycmVudC5kYXRhLnByb2JsZW0/LmRldGFpbCB8fCAnTOG7h25oIGLhu4sgdOG7qyBjaOG7kWkuJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKFsndW5rbm93bicsICdhY2NlcHRlZCcsICdydW5uaW5nJ10uaW5jbHVkZXMoU3RyaW5nKG9ic2VydmVkKSkpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVW5rbm93blJlc3VsdEVycm9yKG9wdGlvbnMuaWRlbXBvdGVuY3lLZXkgfHwgY29tbWFuZC5pZCwgY29tbWFuZC5pZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoaW52YWxpZGF0ZS5tYXAoaWQgPT4gY2FjaGUuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydzY29wZScsIHNjb3BlLnNlc3Npb24udXNlci5pZCwgc2NvcGUuc2hvcC5pZCwgc2NvcGUubWVtYmVyc2hpcC5wZXJtaXNzaW9uVmVyc2lvbiwgaWRdIH0pKSk7XG4gICAgICAgICAgICByZXR1cm4gc2V0dGxlZFJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdZw6p1IGPhuqd1IHRo4bqldCBi4bqhaScpO1xuICAgICAgICAgICAgc2V0RXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVW5rbm93blJlc3VsdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgdW5yZXNvbHZlZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICByZW1lbWJlclVua25vd24oeyBpbnRlbnRJZDogZXJyb3IuaW50ZW50SWQsIGNvbW1hbmRJZDogZXJyb3IuY29tbWFuZElkIHx8IG51bGwsIHNob3BJZDogc2NvcGUuc2hvcC5pZCwgb3BlcmF0aW9uOiBvcCB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgaW5GbGlnaHQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgICAgc2V0UGVuZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbY2FjaGUsIGludmFsaWRhdGUsIG9wLCBzY29wZV0pO1xuICAgIHJldHVybiB7XG4gICAgICAgIGV4ZWN1dGUsIHBlbmRpbmcsIGVycm9yLCBjbGVhckVycm9yOiAoKSA9PiBzZXRFcnJvcihudWxsKSwgcmVzZXRBZnRlclJlY29uY2lsZTogKCkgPT4geyB1bnJlc29sdmVkLmN1cnJlbnQgPSBmYWxzZTsgc2V0RXJyb3IobnVsbCk7IH1cbiAgICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsUUFBUSxnQkFBZ0I7QUFDOUMsU0FBUyxrQkFBa0IsVUFBVSxzQkFBc0I7QUFHM0QsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxlQUFlO0FBRXhCLFNBQVMsVUFBVSwwQkFBMEI7QUFDN0MsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxpQkFBaUIsd0JBQXdCO0FBQzNDLGdCQUFTLE9BQW1DLElBQU8sVUFBOEMsQ0FBQyxHQUFHLFVBQVUsTUFBTTtBQUN4SCxRQUFNLFFBQVEsU0FBUztBQUN2QixRQUFNLEVBQUUsS0FBSyxJQUFJLE1BQU07QUFDdkIsUUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLEtBQUssSUFBSSxHQUFHLFFBQVEsS0FBSztBQUN0RCxRQUFNLFFBQVEsUUFBUSxTQUFTLENBQUM7QUFDaEMsU0FBTyxTQUErQjtBQUFBLElBQ2xDLFVBQVUsQ0FBQyxTQUFTLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLFdBQVcsbUJBQW1CLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDL0YsU0FBUyxDQUFDLEVBQUUsT0FBTyxNQUFNLFFBQVEsSUFBSSxFQUFFLEdBQUcsU0FBUyxNQUFNLE9BQU8sQ0FBQztBQUFBLElBQ2pFO0FBQUEsSUFBUyxXQUFXO0FBQUEsSUFDcEIsT0FBTyxDQUFDLE9BQU8sVUFBVSxRQUFRLE1BQU0sRUFBRSxpQkFBaUIsYUFBYSxNQUFNLFVBQVU7QUFBQSxFQUMzRixDQUFDO0FBQ0w7QUFHTyxnQkFBUyxZQUF3QyxJQUFPLFVBQThDLENBQUMsR0FBRyxVQUFVLE1BQU07QUFDN0gsUUFBTSxRQUFRLFNBQVM7QUFDdkIsUUFBTSxFQUFFLEtBQUssSUFBSSxNQUFNO0FBQ3ZCLFFBQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxLQUFLLElBQUksR0FBRyxRQUFRLEtBQUs7QUFDdEQsUUFBTSxFQUFFLFFBQVEsU0FBUyxPQUFPLGdCQUFnQixHQUFHLFFBQVEsSUFBSyxRQUFRLFNBQVMsQ0FBQztBQUNsRixRQUFNLFFBQVEsT0FBTyxtQkFBbUIsWUFBWSxpQkFBaUIsSUFBSSxLQUFLLElBQUksZ0JBQWdCLEdBQUcsSUFBSTtBQUN6RyxRQUFNLFFBQVEsaUJBQWdJO0FBQUEsSUFDMUksVUFBVSxDQUFDLFNBQVMsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sV0FBVyxtQkFBbUIsSUFBSSxNQUFNLEVBQUUsR0FBRyxTQUFTLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFBQSxJQUM1SCxrQkFBa0I7QUFBQSxJQUNsQixTQUFTLENBQUMsRUFBRSxRQUFRLFVBQVUsTUFBTSxRQUFRLElBQUksRUFBRSxHQUFHLFNBQVMsTUFBTSxPQUFPLEVBQUUsR0FBRyxTQUFTLE9BQU8sUUFBUSxVQUFVLEdBQWtDLE9BQU8sQ0FBQztBQUFBLElBQzVKLGtCQUFrQixDQUFBQSxjQUFZO0FBQzFCLFlBQU0sT0FBUUEsVUFBbUY7QUFDakcsYUFBTyxNQUFNLFdBQVcsS0FBSyxhQUFhLEtBQUssYUFBYTtBQUFBLElBQ2hFO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLElBQ1gsT0FBTyxDQUFDLE9BQU8sVUFBVSxRQUFRLE1BQU0sRUFBRSxpQkFBaUIsYUFBYSxNQUFNLFVBQVU7QUFBQSxFQUMzRixDQUFDO0FBQ0QsUUFBTSxRQUFRLE1BQU0sTUFBTSxTQUFTLENBQUM7QUFDcEMsUUFBTSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQzVCLFFBQU0sT0FBTyxXQUFXO0FBQUEsSUFDcEIsR0FBSTtBQUFBLElBQ0osTUFBTSxNQUFNLFFBQVEsVUFBUyxLQUF3QyxJQUFJO0FBQUEsRUFDN0UsSUFBcUI7QUFDckIsU0FBTztBQUFBLElBQ0gsR0FBRztBQUFBLElBQ0g7QUFBQSxJQUNBLGFBQWEsT0FBUyxLQUF3QyxLQUFLLFNBQVU7QUFBQSxJQUM3RSxVQUFVLE1BQU0sTUFBTSxjQUFjLE1BQU0sY0FBYyxJQUFJLFFBQVEsUUFBUSxNQUFTO0FBQUEsSUFDckYsU0FBUyxRQUFRLE1BQU0sV0FBVztBQUFBLElBQ2xDLGVBQWUsTUFBTTtBQUFBLEVBQ3pCO0FBQ0o7QUFFTyxnQkFBUyxXQUEwQyxJQUFPLFlBQW9DO0FBQ2pHLFFBQU0sUUFBUSxTQUFTO0FBQ3ZCLFFBQU0sUUFBUSxlQUFlO0FBQzdCLFFBQU0sQ0FBQyxTQUFTLFVBQVUsSUFBSSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDLE9BQU8sUUFBUSxJQUFJLFNBQXVCLElBQUk7QUFDckQsUUFBTSxXQUFXLE9BQU8sS0FBSztBQUM3QixRQUFNLGFBQWEsT0FBTyxLQUFLO0FBQy9CLE1BQUksQ0FBQyxpQkFBaUIsTUFBTSxLQUFLLElBQUksRUFBRTtBQUNuQyxlQUFXLFVBQVU7QUFDekIsUUFBTSxVQUFVLFlBQVksVUFBVSxTQUFrRDtBQUNwRixVQUFNLFVBQVcsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUM3QixRQUFJLFNBQVMsV0FBVyxXQUFXLFdBQVcsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEVBQUU7QUFDNUUsWUFBTSxJQUFJLFNBQVMsS0FBSyxhQUFhLGlEQUFpRDtBQUMxRixRQUFJLENBQUMsTUFBTTtBQUNQLFlBQU0sSUFBSSxTQUFTLEdBQUcsV0FBVyx1Q0FBdUM7QUFDNUUsYUFBUyxVQUFVO0FBQ25CLGVBQVcsSUFBSTtBQUNmLGFBQVMsSUFBSTtBQUNiLFFBQUk7QUFDQSxZQUFNLFNBQVMsTUFBTSxRQUFRLElBQUksRUFBRSxHQUFHLFNBQVMsTUFBTSxFQUFFLFFBQVEsTUFBTSxLQUFLLElBQUksR0FBRyxRQUFRLEtBQUssR0FBRyxnQkFBZ0IsUUFBUSxrQkFBa0IsT0FBTyxXQUFXLEVBQUUsQ0FBQztBQUNoSyxVQUFJLGdCQUFnQjtBQUNwQixVQUFJLFdBQVcsRUFBRSxFQUFFLG1CQUFtQixxQkFBcUIsVUFBVSxPQUFPLFdBQVcsWUFBWSxVQUFVLFFBQVE7QUFDakgsY0FBTSxVQUFVLE9BQU87QUFDdkIsWUFBSSxXQUFXLE9BQU8sWUFBWSxZQUFZLFFBQVEsV0FBVyxPQUFPLFFBQVEsT0FBTyxZQUFZLFlBQVksU0FBUztBQUNwSCxjQUFJLFdBQVcsUUFBUTtBQUN2QixjQUFJLGFBQWE7QUFDYixrQkFBTSxJQUFJLFNBQVMsS0FBSyxrQkFBa0Isb0RBQW9EO0FBQ2xHLG1CQUFTLFVBQVUsR0FBRyxDQUFDLFlBQVksU0FBUyxFQUFFLFNBQVMsT0FBTyxRQUFRLENBQUMsS0FBSyxVQUFVLEdBQUcsV0FBVztBQUNoRyxrQkFBTSxJQUFJLFFBQVEsYUFBVyxXQUFXLFNBQVMsTUFBTSxVQUFVLEdBQUcsQ0FBQztBQUNyRSxnQkFBSTtBQUNKLGdCQUFJO0FBQ0Esd0JBQVUsTUFBTSxRQUFRLGNBQWMsRUFBRSxNQUFNLEVBQUUsUUFBUSxNQUFNLEtBQUssSUFBSSxXQUFXLFFBQVEsR0FBRyxFQUFFLENBQUM7QUFBQSxZQUNwRyxRQUNNO0FBQ0Ysb0JBQU0sSUFBSSxtQkFBbUIsUUFBUSxrQkFBa0IsUUFBUSxJQUFJLFFBQVEsRUFBRTtBQUFBLFlBQ2pGO0FBQ0EsdUJBQVcsUUFBUSxLQUFLO0FBQ3hCLDRCQUFnQjtBQUNoQixnQkFBSSxhQUFhO0FBQ2Isb0JBQU0sSUFBSSxTQUFTLEtBQUssUUFBUSxLQUFLLFNBQVMsUUFBUSxrQkFBa0IsUUFBUSxLQUFLLFNBQVMsVUFBVSxrQkFBa0I7QUFBQSxVQUNsSTtBQUNBLGNBQUksQ0FBQyxXQUFXLFlBQVksU0FBUyxFQUFFLFNBQVMsT0FBTyxRQUFRLENBQUM7QUFDNUQsa0JBQU0sSUFBSSxtQkFBbUIsUUFBUSxrQkFBa0IsUUFBUSxJQUFJLFFBQVEsRUFBRTtBQUFBLFFBQ3JGO0FBQUEsTUFDSjtBQUNBLFlBQU0sUUFBUSxJQUFJLFdBQVcsSUFBSSxRQUFNLE1BQU0sa0JBQWtCLEVBQUUsVUFBVSxDQUFDLFNBQVMsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLFdBQVcsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN0SyxhQUFPO0FBQUEsSUFDWCxTQUNPLEdBQUc7QUFDTixZQUFNQyxTQUFRLGFBQWEsUUFBUSxJQUFJLElBQUksTUFBTSxrQkFBa0I7QUFDbkUsZUFBU0EsTUFBSztBQUNkLFVBQUlBLGtCQUFpQixvQkFBb0I7QUFDckMsbUJBQVcsVUFBVTtBQUNyQix3QkFBZ0IsRUFBRSxVQUFVQSxPQUFNLFVBQVUsV0FBV0EsT0FBTSxhQUFhLE1BQU0sUUFBUSxNQUFNLEtBQUssSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUFBLE1BQzFIO0FBQ0EsWUFBTUE7QUFBQSxJQUNWLFVBQ0E7QUFDSSxlQUFTLFVBQVU7QUFDbkIsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSixHQUFHLENBQUMsT0FBTyxZQUFZLElBQUksS0FBSyxDQUFDO0FBQ2pDLFNBQU87QUFBQSxJQUNIO0FBQUEsSUFBUztBQUFBLElBQVM7QUFBQSxJQUFPLFlBQVksTUFBTSxTQUFTLElBQUk7QUFBQSxJQUFHLHFCQUFxQixNQUFNO0FBQUUsaUJBQVcsVUFBVTtBQUFPLGVBQVMsSUFBSTtBQUFBLElBQUc7QUFBQSxFQUN4STtBQUNKOyIsIm5hbWVzIjpbImxhc3RQYWdlIiwiZXJyb3IiXX0=