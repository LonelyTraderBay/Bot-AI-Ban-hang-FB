import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/bot/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-9523869a-ed79-40c6-9aa8-4eaa2b0e33d7/deps/react_jsx-dev-runtime.js?v=7c580bf5"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { ActionGroup, FormFields, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-9523869a-ed79-40c6-9aa8-4eaa2b0e33d7/deps/react.js?v=7c580bf5"; const useState = __vite__cjsImport4_react["useState"];
import { Alert, Box, Button, Chip, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-9523869a-ed79-40c6-9aa8-4eaa2b0e33d7/deps/@mui_material.js?v=17ff158c";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { codePointLength, dateTime } from "/src/shared/model/format.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { Amount, ConfirmDialog, DataTable, DetailLine, EditDialog, ErrorNotice, MutationButton, PageHeader, Pager, Panel, QueryState, RouteLink, Status, Toolbar } from "/src/shared/ui/components.tsx";
export function BotConfigPage() {
  _s();
  const { shop } = useScope();
  const get = useApi("getBotConfig");
  const connections = useApi("listAIConnections", {}, true);
  const versions = useApi("listBotRevisions");
  const update = useCommand("updateBotDraft", ["getBotConfig", "listBotRevisions", "getBotRevision"]);
  const publish = useCommand("publishBotConfig", ["getBotConfig", "listBotRevisions", "getBotRevision"]);
  const pause = useCommand("pauseBot", ["getBotConfig"]);
  const restore = useCommand("restoreBotRevision", ["getBotConfig", "listBotRevisions", "getBotRevision"]);
  const [revisionId, setRevisionId] = useState("");
  const revision = useApi("getBotRevision", { path: { revisionId } }, Boolean(revisionId));
  const b = get.data?.data;
  const [editing, setEdit] = useState(null), [instructions, setInstructions] = useState(""), [connection, setConnection] = useState(""), [budget, setBudget] = useState(""), [steps, setSteps] = useState("4"), [knowledge, setKnowledge] = useState(""), [action, setAction] = useState(null), [evalId, setEval] = useState(""), [reason, setReason] = useState(""), [restoreVersion, setRestore] = useState(null);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Điều khiển Admin AI", subtitle: "Tách cấu hình đang chạy và cấu hình đang soạn. Không bật tự động chỉ vì lưu prompt.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/bot/playground`, children: "Thử bot" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 156
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: get, pendingProfile: "section", children: b && /* @__PURE__ */ jsxDEV(Panel, { title: "Cấu hình hiện hành", action: /* @__PURE__ */ jsxDEV(Status, { value: b.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 323
    }, this), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bản nháp", children: b.draftRevision }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 374
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bản đang chạy", children: b.liveRevision || "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 433
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã kết nối AI", children: b.connectionId || "Chưa chọn" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 509
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giới hạn chi phí mỗi ngày", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: b.dailyBudget }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 633
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 587
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giới hạn bước công cụ", children: b.maxToolSteps }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 683
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Xuất bản lúc", children: dateTime(b.publishedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 754
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { sx: [layoutSx.page.sectionBefore, layoutSx.page.sectionAfter, { whiteSpace: "pre-wrap" }], children: b.instructions || "Chưa có chỉ dẫn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 840
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Đơn do AI đề xuất vẫn cần người có quyền kiểm tra và xác nhận. Lưu bản nháp không thay đổi cấu hình đang chạy hoặc tự chốt đơn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 994
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "form", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.configure", onClick: () => {
          setEdit(b);
          setInstructions(b.instructions);
          setConnection(b.connectionId || "");
          setBudget(b.dailyBudget?.amount || "");
          setSteps(String(b.maxToolSteps));
          setKnowledge(b.knowledgeRevisionIds.join("\n"));
        }, children: "Sửa bản nháp" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 43,
          columnNumber: 1198
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.publish", variant: "contained", onClick: () => setAction("publish"), children: "Duyệt & xuất bản" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 43,
          columnNumber: 1488
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.publish", color: "error", onClick: () => setAction("pause"), children: "Tạm dừng bot" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 43,
          columnNumber: 1619
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 43,
        columnNumber: 1152
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 369
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 281
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 226
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Các phiên bản", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: versions, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử cấu hình AI", rows: versions.data?.data || [], rowKey: (r) => `${r.id}-${r.revision}`, columns: [
      { key: "revision", label: "Phiên bản", render: (r) => `#${r.revision}` },
      { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 44,
        columnNumber: 135
      }, this) },
      { key: "updated", label: "Cập nhật", render: (r) => dateTime(r.updatedAt, shop.timezone) },
      {
        key: "action",
        label: "",
        render: (r) => /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setRevisionId(r.id), children: "Xem phiên bản" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
            lineNumber: 46,
            columnNumber: 81
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.configure", onClick: () => setRestore(r), children: "Khôi phục vào nháp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
            lineNumber: 46,
            columnNumber: 147
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 46,
          columnNumber: 52
        }, this)
      }
    ] }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 1885
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 1831
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 43,
      columnNumber: 1780
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!revisionId, title: "Chi tiết phiên bản AI", onClose: () => setRevisionId(""), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setRevisionId(""), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 49,
      columnNumber: 107
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: revision, pendingProfile: "section", children: revision.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản", children: [
        "#",
        revision.data.data.revision
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: revision.data.data.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 52,
        columnNumber: 40
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cập nhật", children: dateTime(revision.data.data.updatedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã kết nối AI", children: revision.data.data.connectionId || "Chưa chọn" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản kiến thức", children: revision.data.data.knowledgeRevisionIds.join(", ") || "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giới hạn chi phí mỗi ngày", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: revision.data.data.dailyBudget }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 56,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giới hạn bước công cụ", children: revision.data.data.maxToolSteps }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Người xác nhận đơn", children: revision.data.data.requireHumanOrderConfirmation ? "Bắt buộc" : "Theo chính sách máy chủ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { sx: { whiteSpace: "pre-wrap", overflowWrap: "anywhere" }, children: revision.data.data.instructions || "Chưa có chỉ dẫn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 50,
      columnNumber: 77
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 50,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 49,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!editing, title: "Cấu hình bản nháp", onClose: () => setEdit(null), busy: update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !editing || !instructions || !connection || !budget || update.pending, onClick: async () => {
      if (!editing)
        return;
      try {
        await update.execute({ version: editing.version, body: {
          connectionId: connection,
          instructions,
          knowledgeRevisionIds: knowledge.split(/\s+/).filter(Boolean),
          maxToolSteps: Number(steps),
          dailyBudget: { amount: budget, currency: shop.currency },
          requireHumanOrderConfirmation: true
        } });
        setEdit(null);
      } catch {
      }
    }, children: "Lưu nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 62,
      columnNumber: 118
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 69,
        columnNumber: 50
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Kết nối AI", select: true, value: connection, onChange: (e) => setConnection(e.target.value), children: connections.data?.data.map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: [
          c.name,
          " · ",
          c.status
        ] }, c.id, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 237
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 98
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Chỉ dẫn tư vấn đã duyệt", multiline: true, minRows: 8, value: instructions, onChange: (e) => setInstructions(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 317
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã phiên bản kiến thức (mỗi dòng một mã)", multiline: true, minRows: 3, value: knowledge, onChange: (e) => setKnowledge(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 455
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Ngân sách ngày (${shop.currency})`, value: budget, onChange: (e) => setBudget(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 604
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { type: "number", label: "Số bước công cụ tối đa", value: steps, inputProps: { min: 0, max: 20 }, onChange: (e) => setSteps(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 69,
          columnNumber: 720
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 69,
        columnNumber: 86
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 62,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: action === "publish", title: "Xuất bản cấu hình đã đánh giá", onClose: () => setAction(null), busy: publish.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !evalId || codePointLength(reason) < 5 || publish.pending, onClick: async () => {
      try {
        await publish.execute({ body: { expectedVersion: b?.version || 1, draftRevision: b?.draftRevision || 1, evaluationRunId: evalId, reason } });
        setAction(null);
      } catch {
      }
    }, children: "Xuất bản" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 70,
      columnNumber: 144
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: publish.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 74,
        columnNumber: 50
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã lần đánh giá đúng bản nháp", value: evalId, onChange: (e) => setEval(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 74,
          columnNumber: 99
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 74,
          columnNumber: 207
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/bot/evaluations`, children: "Xem kết quả kiểm thử" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 74,
          columnNumber: 293
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 74,
        columnNumber: 87
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 70,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: action === "pause", title: "Tạm dừng Admin AI", confirmLabel: "Tạm dừng Admin AI", description: `Admin AI ${b?.id || ""} trong ${shop.name}: dừng các tác động chưa gửi. Tin nhắn đã được nhà cung cấp nhận không thể thu hồi bằng nút này.`, requireReason: true, onClose: () => setAction(null), busy: pause.pending, error: pause.error, onConfirm: (reason2) => pause.execute({ body: { expectedVersion: b?.version || 1, reason: reason2 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 75,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!restoreVersion, title: "Khôi phục bản cũ vào nháp", confirmLabel: "Khôi phục vào nháp", description: `Cấu hình ${b?.id || ""}, phiên bản ${restoreVersion?.revision || ""}: khôi phục vào bản nháp. Bản đang chạy được giữ; phải kiểm thử và duyệt lại trước xuất bản.`, requireReason: true, onClose: () => setRestore(null), busy: restore.pending, error: restore.error, onConfirm: (reason2) => restore.execute({ path: { revisionId: String(restoreVersion?.revision || 1) }, body: { expectedVersion: b?.version || 1, reason: reason2 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 75,
      columnNumber: 440
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
}
_s(BotConfigPage, "RhvzO3WrS3CG/OF1owKD8neX4hA=", false, function() {
  return [useScope, useApi, useApi, useApi, useCommand, useCommand, useCommand, useCommand, useApi];
});
_c = BotConfigPage;
export function PlaygroundPage() {
  _s2();
  const config = useApi("getBotConfig");
  const run = useCommand("runPlayground", []);
  const [text, setText] = useState(""), [customer, setCustomer] = useState(""), [result, setResult] = useState(null);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Phòng thử bot", subtitle: "Thử cấu hình hiện tại mà không gửi tin cho khách hàng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 81,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1fr 1fr" }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Câu hỏi thử", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { component: "form", onSubmit: async (e) => {
        e.preventDefault();
        try {
          const r = await run.execute({ body: { configRevision: config.data?.data.draftRevision || 1, text, customerContextId: customer || null } });
          setResult(r.data);
        } catch {
        }
      }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: run.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 35
        }, this),
        /* @__PURE__ */ jsxDEV(QueryState, { query: config, children: config.data?.data && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          "Phòng thử dùng bản nháp #",
          config.data.data.draftRevision,
          " · ",
          config.data.data.status === "active" ? `đang chạy bản #${config.data.data.liveRevision || "chưa có"}` : "cấu hình bot đang tạm dừng",
          ". Nội dung thử không gửi ra ngoài."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 117
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 68
        }, this),
        /* @__PURE__ */ jsxDEV(FormFields, { beforeGap: "surface", children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Nội dung khách hỏi", multiline: true, minRows: 9, value: text, onChange: (e) => setText(e.target.value) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
            lineNumber: 85,
            columnNumber: 422
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Mã khách để thử ngữ cảnh (tùy chọn)", value: customer, onChange: (e) => setCustomer(e.target.value) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
            lineNumber: 85,
            columnNumber: 539
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.configure", type: "submit", variant: "contained", busy: run.pending, disabled: !text.trim() || !config.data, children: "Chạy thử" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
            lineNumber: 85,
            columnNumber: 659
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 390
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 81,
        columnNumber: 210
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 81,
        columnNumber: 166
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Kết quả có nguồn", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { children: result ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { sx: { whiteSpace: "pre-wrap" }, children: result.text }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 913
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản cấu hình", children: result.configRevision }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 983
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Độ trễ", children: [
          result.latencyMs,
          " ms"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1058
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chi phí ước tính", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: result.estimatedCost }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1156
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1119
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Token vào / ra", children: [
          result.inputTokens ?? "Chưa rõ",
          " / ",
          result.outputTokens ?? "Chưa rõ"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1213
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Gửi ra ngoài", children: "Không" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1331
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: layoutSx.surface.sectionBefore, children: "Nguồn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1382
        }, this),
        result.sources.length > 0 && /* @__PURE__ */ jsxDEV(Stack, { direction: "row", sx: [layoutSx.code.inlineGap, { flexWrap: "wrap" }], children: result.sources.map((s) => /* @__PURE__ */ jsxDEV(Chip, { label: `${s.type} / ${s.id}` }, s.type + s.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1601
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1498
        }, this),
        result.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.surface.sectionBefore, children: w }, w, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 85,
          columnNumber: 1698
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 85,
        columnNumber: 911
      }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Chạy câu hỏi để xem câu trả lời, nguồn và cảnh báo. Không có điểm chất lượng tự tạo." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 85,
        columnNumber: 1787
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 85,
        columnNumber: 896
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 85,
        columnNumber: 847
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 81,
      columnNumber: 114
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
    lineNumber: 81,
    columnNumber: 10
  }, this);
}
_s2(PlaygroundPage, "jFyUXcAXovXyo5Wpf7D8XbbEQcw=", false, function() {
  return [useApi, useCommand];
});
_c2 = PlaygroundPage;
export function EvaluationsPage() {
  _s3();
  const { shop } = useScope();
  const list = useApi("listEvaluations", { query: useListQuery("listEvaluations") });
  const bot = useApi("getBotConfig");
  const create = useCommand("createEvaluation", ["listEvaluations"]);
  const [open, setOpen] = useState(false), [dataset, setDataset] = useState(""), [knowledge, setKnowledge] = useState(""), [selected, setSelected] = useState(null);
  const detail = useApi("getEvaluation", { path: { evaluationId: selected?.id || "" } }, Boolean(selected));
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đánh giá AI", subtitle: "Kết quả gắn cấu hình, dữ liệu kiểm thử và phiên bản kiến thức.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.configure", variant: "contained", onClick: () => setOpen(true), children: "Chạy đánh giá" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 94,
      columnNumber: 127
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 94,
      columnNumber: 12
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Chế độ mô phỏng chỉ kiểm quy trình, không đánh giá chất lượng mô hình AI thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 94,
      columnNumber: 267
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listEvaluations" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 94,
        columnNumber: 417
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử đánh giá AI", rows: list.data?.data || [], rowKey: (r) => r.id, empty: "Chưa có lần đánh giá nào. Có thể chạy đánh giá cấu hình nháp từ nút phía trên.", columns: [
        { key: "id", label: "Lần đánh giá", render: (r) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setSelected(r), children: r.id }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 95,
          columnNumber: 60
        }, this) },
        { key: "config", label: "Bản cấu hình", render: (r) => r.configRevision },
        { key: "dataset", label: "Bộ kiểm thử", render: (r) => r.datasetVersion },
        { key: "count", label: "Đạt / tổng", render: (r) => `${r.passedCases} / ${r.totalCases}` },
        { key: "critical", label: "Lỗi trọng yếu", render: (r) => r.criticalFailures },
        { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 95,
          columnNumber: 492
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 94,
        columnNumber: 506
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 94,
        columnNumber: 456
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: list.data?.page }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 96,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 94,
      columnNumber: 410
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Đánh giá cấu hình nháp", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !dataset || !bot.data || create.pending, onClick: async () => {
      try {
        const r = await create.execute({ body: { configRevision: bot.data?.data.draftRevision || 1, datasetVersion: dataset, knowledgeRevisionId: knowledge || null } });
        setSelected(r.data);
        setOpen(false);
      } catch {
      }
    }, children: "Bắt đầu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 97,
      columnNumber: 119
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 49
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Phiên bản bộ kiểm thử đã đăng ký", value: dataset, onChange: (e) => setDataset(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 102,
          columnNumber: 97
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã bản kiến thức (tùy chọn)", value: knowledge, onChange: (e) => setKnowledge(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 102,
          columnNumber: 212
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Mã bộ kiểm thử phải do backend xác minh. Không tự gọi tỷ lệ 100% là chứng nhận chất lượng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 102,
          columnNumber: 326
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 85
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 97,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!selected, title: "Chi tiết đánh giá", onClose: () => setSelected(null), actions: /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
      /* @__PURE__ */ jsxDEV(Button, { disabled: detail.isFetching, onClick: () => void detail.refetch(), children: "Cập nhật kết quả" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 601
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => setSelected(null), children: "Đóng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 701
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 102,
      columnNumber: 572
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, pendingProfile: "section", children: detail.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã", children: detail.data.data.id }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 856
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bộ dữ liệu", children: detail.data.data.datasetVersion }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 913
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bản cấu hình", children: detail.data.data.configRevision }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 990
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kết quả", children: /* @__PURE__ */ jsxDEV(Status, { value: detail.data.data.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 1097
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 1069
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Số ca", children: [
        detail.data.data.passedCases,
        " / ",
        detail.data.data.totalCases
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 1152
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lỗi trọng yếu", children: detail.data.data.criticalFailures }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 1253
      }, this),
      detail.data.data.reportJobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${detail.data.data.reportJobId}`, children: "Báo cáo chi tiết" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 102,
        columnNumber: 1368
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 102,
      columnNumber: 840
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 102,
      columnNumber: 772
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 102,
      columnNumber: 473
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
    lineNumber: 94,
    columnNumber: 10
  }, this);
}
_s3(EvaluationsPage, "iOAiavewoe40WXU4nHA+X0OxlNo=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand, useApi];
});
_c3 = EvaluationsPage;
const roleNames = { sales_admin: "Admin bán hàng", accountant: "Kế toán", warehouse_buyer: "Kho & mua hàng", supervisor: "Trưởng nhóm" };
export function AgentTeamPage() {
  _s4();
  const { shop } = useScope();
  const roles = useApi("listAgentRoles");
  const budgets = useApi("listBudgetPolicies");
  const update = useCommand("updateAgentRole", ["listAgentRoles", "getOperationsSummary"]);
  const control = useCommand("controlAutomation", ["listAgentRoles", "getBotConfig", "getOperationsSummary"]);
  const budgetUpdate = useCommand("updateBudgetPolicy", ["listBudgetPolicies"]);
  const [editing, setEditing] = useState(null), [owner, setOwner] = useState(""), [connection, setConnection] = useState(""), [policy, setPolicy] = useState(""), [stop, setStop] = useState(null), [budget, setBudget] = useState(null), [amount, setAmount] = useState(""), [approval, setApproval] = useState("");
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đội ngũ AI", subtitle: "Bốn vai trò trên cùng nền điều phối, quyền và người chịu trách nhiệm rõ ràng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: roles, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", md: "repeat(2,1fr)" }, children: roles.data?.data.map((r) => /* @__PURE__ */ jsxDEV(Panel, { title: roleNames[r.kind], action: /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 324
    }, this), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Người chịu trách nhiệm", children: r.humanOwnerId ? `Mã nhân sự: ${r.humanOwnerId}` : "Chưa giao" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 375
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: r.policyVersion }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 495
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Thế hệ tác vụ", children: r.generation }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 556
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { direction: "row", sx: [layoutSx.code.inlineGap, layoutSx.surface.sectionBefore, layoutSx.notice.afterGap, { flexWrap: "wrap" }], children: r.allowedToolIds.map((tool) => /* @__PURE__ */ jsxDEV(Chip, { label: tool }, tool, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 783
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 617
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.configure", onClick: () => {
          setEditing(r);
          setOwner(r.humanOwnerId || "");
          setConnection(r.modelConnectionId || "");
          setPolicy(r.policyVersion);
        }, children: "Phân công" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 116,
          columnNumber: 854
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.pause", color: r.status === "paused" ? "primary" : "error", onClick: () => setStop({ role: r, action: r.status === "paused" ? "resume" : "pause" }), children: r.status === "paused" ? "Đề nghị tiếp tục" : "Tạm dừng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 116,
          columnNumber: 1055
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 116,
        columnNumber: 825
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 370
    }, this) }, r.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 272
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 185
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 134
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Ngân sách được giao", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: budgets, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Hạn mức của đội ngũ AI", rows: budgets.data?.data || [], rowKey: (b) => b.id, columns: [
      { key: "kind", label: "Loại", render: (b) => b.kind },
      { key: "limit", label: "Giới hạn", render: (b) => /* @__PURE__ */ jsxDEV(Amount, { value: b.limitAmount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 117,
        columnNumber: 114
      }, this) },
      { key: "used", label: "Đã dùng", render: (b) => /* @__PURE__ */ jsxDEV(Amount, { value: b.consumed }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 117,
        columnNumber: 198
      }, this) },
      { key: "reserved", label: "Đã cam kết", render: (b) => /* @__PURE__ */ jsxDEV(Amount, { value: b.reserved }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 117,
        columnNumber: 286
      }, this) },
      { key: "state", label: "Áp dụng", render: (b) => b.enabled ? "Đã bật" : "Chưa bật" },
      {
        key: "action",
        label: "",
        render: (b) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "operations.manage", onClick: () => {
          setBudget(b);
          setAmount(b.limitAmount?.amount || "");
          setApproval("");
        }, children: "Đổi có phê duyệt" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 119,
          columnNumber: 52
        }, this)
      }
    ] }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 1476
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 1423
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 116,
      columnNumber: 1366
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Chi phí AI & dự phòng nhà cung cấp", beforeGap: "section", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(SurfaceContent, { "data-testid": "provider-failover-preview", children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chi phí trong phòng thử là ước tính mô phỏng. Chỉ dùng provider dự phòng đã được phê duyệt; demo không chuyển dữ liệu khách sang provider khác." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Ngân sách token / kênh", children: "Theo chính sách và hạn mức do hệ thống trả về; không dùng chung với ngân sách mua hàng." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 125,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Provider dự phòng", children: "Chưa có trạng thái failover được xác minh trong dữ liệu frontend." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khi hết hạn mức", children: "Dừng câu trả lời tự động và chuyển nhân viên xử lý; không âm thầm đổi provider." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 123,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 122,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!editing, title: "Giao trách nhiệm và cấu hình vai trò", onClose: () => setEditing(null), busy: update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !owner || !connection || !policy || update.pending, onClick: async () => {
      try {
        await update.execute({ path: { resourceId: editing?.id || "" }, body: { expectedVersion: editing?.version || 1, humanOwnerId: owner, modelConnectionId: connection, policyVersion: policy } });
        setEditing(null);
      } catch {
      }
    }, children: "Lưu phân công" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 130,
      columnNumber: 140
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 134,
        columnNumber: 55
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã nhân sự chịu trách nhiệm", value: owner, onChange: (e) => setOwner(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 134,
          columnNumber: 103
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã kết nối AI", value: connection, onChange: (e) => setConnection(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 134,
          columnNumber: 209
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Phiên bản chính sách đã duyệt", value: policy, onChange: (e) => setPolicy(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 134,
          columnNumber: 311
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Công cụ được phép do backend trả về; không sửa quyền qua prompt." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 134,
          columnNumber: 421
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 134,
        columnNumber: 91
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 130,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!stop, title: stop?.action === "pause" ? "Tạm dừng vai trò" : "Kiểm điều kiện để tiếp tục", confirmLabel: stop?.action === "pause" ? "Tạm dừng vai trò" : "Kiểm tra để tiếp tục", description: `${stop ? roleNames[stop.role.kind] : ""} (${stop?.role.id || ""}) trong ${shop.name}: ${stop?.action === "pause" ? "tạm dừng tác động chưa được tiếp nhận." : "kiểm thế hệ tác vụ và chính sách trước tác động mới."} Không thu hồi được tác động đã được dịch vụ ngoài nhận.`, requireReason: true, onClose: () => setStop(null), error: control.error, busy: control.pending, onConfirm: (reason) => control.execute({ body: { expectedVersion: stop?.role.version || 1, scope: "role", resourceId: stop?.role.id || null, action: stop?.action || "pause", reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 135,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!budget, title: "Đổi giới hạn được duyệt", onClose: () => setBudget(null), busy: budgetUpdate.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !amount || !approval || budgetUpdate.pending, onClick: async () => {
      try {
        await budgetUpdate.execute({ path: { resourceId: budget?.id || "" }, body: {
          expectedVersion: budget?.version || 1,
          limitAmount: { amount, currency: shop.currency },
          period: budget?.period || "daily",
          approvalId: approval
        } });
        setBudget(null);
      } catch {
      }
    }, children: "Áp dụng giới hạn" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 136,
      columnNumber: 131
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: budgetUpdate.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 142,
        columnNumber: 58
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: `Giới hạn (${shop.currency})`, value: amount, onChange: (e) => setAmount(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 142,
          columnNumber: 112
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã phê duyệt đúng nội dung", value: approval, onChange: (e) => setApproval(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
          lineNumber: 142,
          columnNumber: 222
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
        lineNumber: 142,
        columnNumber: 100
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
      lineNumber: 136,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx",
    lineNumber: 116,
    columnNumber: 10
  }, this);
}
_s4(AgentTeamPage, "Fkld0XricZj6rqtSPSKcu2A6Ea4=", false, function() {
  return [useScope, useApi, useApi, useCommand, useCommand, useCommand];
});
_c4 = AgentTeamPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "BotConfigPage");
$RefreshReg$(_c2, "PlaygroundPage");
$RefreshReg$(_c3, "EvaluationsPage");
$RefreshReg$(_c4, "AgentTeamPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/bot/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJXLG1CQUFrSixjQUFsSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2QlgsU0FBU0EsYUFBYUMsWUFBWUMsYUFBYUMsc0JBQXNCO0FBQ3JFLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxNQUFNQyxVQUFVQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFFakYsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFFBQVFDLGVBQWVDLFdBQVdDLFlBQVlDLFlBQVlDLGFBQWFDLGdCQUFnQkMsWUFBWUMsT0FBT0MsT0FBT0MsWUFBWUMsV0FBV0MsUUFBUUMsZUFBZTtBQUNqSyxnQkFBU0MsZ0JBQWdCO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxFQUFFQyxLQUFLLElBQUlyQixTQUFTO0FBQzFCLFFBQU1zQixNQUFNeEIsT0FBTyxjQUFjO0FBQ2pDLFFBQU15QixjQUFjekIsT0FBTyxxQkFBcUIsQ0FBQyxHQUFHLElBQUk7QUFDeEQsUUFBTTBCLFdBQVcxQixPQUFPLGtCQUFrQjtBQUMxQyxRQUFNMkIsU0FBUzFCLFdBQVcsa0JBQWtCLENBQUMsZ0JBQWdCLG9CQUFvQixnQkFBZ0IsQ0FBQztBQUNsRyxRQUFNMkIsVUFBVTNCLFdBQVcsb0JBQW9CLENBQUMsZ0JBQWdCLG9CQUFvQixnQkFBZ0IsQ0FBQztBQUNyRyxRQUFNNEIsUUFBUTVCLFdBQVcsWUFBWSxDQUFDLGNBQWMsQ0FBQztBQUNyRCxRQUFNNkIsVUFBVTdCLFdBQVcsc0JBQXNCLENBQUMsZ0JBQWdCLG9CQUFvQixnQkFBZ0IsQ0FBQztBQUN2RyxRQUFNLENBQUM4QixZQUFZQyxhQUFhLElBQUl6QyxTQUFTLEVBQUU7QUFDL0MsUUFBTTBDLFdBQVdqQyxPQUFPLGtCQUFrQixFQUFFa0MsTUFBTSxFQUFFSCxXQUFXLEVBQUUsR0FBR0ksUUFBUUosVUFBVSxDQUFDO0FBQ3ZGLFFBQU1LLElBQUlaLElBQUlhLE1BQU1BO0FBQ3BCLFFBQU0sQ0FBQ0MsU0FBU0MsT0FBTyxJQUFJaEQsU0FBMkIsSUFBSSxHQUFHLENBQUNpRCxjQUFjQyxlQUFlLElBQUlsRCxTQUFTLEVBQUUsR0FBRyxDQUFDbUQsWUFBWUMsYUFBYSxJQUFJcEQsU0FBUyxFQUFFLEdBQUcsQ0FBQ3FELFFBQVFDLFNBQVMsSUFBSXRELFNBQVMsRUFBRSxHQUFHLENBQUN1RCxPQUFPQyxRQUFRLElBQUl4RCxTQUFTLEdBQUcsR0FBRyxDQUFDeUQsV0FBV0MsWUFBWSxJQUFJMUQsU0FBUyxFQUFFLEdBQUcsQ0FBQzJELFFBQVFDLFNBQVMsSUFBSTVELFNBQXFDLElBQUksR0FBRyxDQUFDNkQsUUFBUUMsT0FBTyxJQUFJOUQsU0FBUyxFQUFFLEdBQUcsQ0FBQytELFFBQVFDLFNBQVMsSUFBSWhFLFNBQVMsRUFBRSxHQUFHLENBQUNpRSxnQkFBZ0JDLFVBQVUsSUFBSWxFLFNBQTZCLElBQUk7QUFDbGQsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSx1QkFBc0IsVUFBUyx1RkFBc0YsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTWdDLEtBQUttQyxFQUFFLG1CQUFtQix1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRCxLQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1OO0FBQUEsSUFBRSx1QkFBQyxjQUFXLE9BQU9sQyxLQUFLLGdCQUFlLFdBQVdZLGVBQUssdUJBQUMsU0FBTSxPQUFNLHNCQUFxQixRQUFRLHVCQUFDLFVBQU8sT0FBT0EsRUFBRXVCLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsR0FBSSxVQUFTLFNBQVEsaUNBQUMsT0FBSTtBQUFBLDZCQUFDLGNBQVcsT0FBTSxZQUFZdkIsWUFBRXdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0saUJBQWlCeEIsWUFBRXlCLGdCQUFnQixhQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0saUJBQWlCekIsWUFBRTBCLGdCQUFnQixlQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sNkJBQTRCLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU8xQixFQUFFMkIsZUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQyxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0seUJBQXlCM0IsWUFBRTRCLGdCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sZ0JBQWdCM0QsbUJBQVMrQixFQUFFNkIsYUFBYTFDLEtBQUsyQyxRQUFRLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUFhLHVCQUFDLGNBQVcsSUFBSSxDQUFDNUQsU0FBUzZELEtBQUtDLGVBQWU5RCxTQUFTNkQsS0FBS0UsY0FBYyxFQUFFQyxZQUFZLFdBQVcsQ0FBQyxHQUFJbEMsWUFBRUksZ0JBQWdCLHNCQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZJO0FBQUEsTUFBYSx1QkFBQyxTQUFNLFVBQVMsUUFBTywrSUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzSjtBQUFBLE1BQVEsdUJBQUMsZUFBWSxXQUFVLE9BQU0sV0FBVSxRQUFPO0FBQUEsK0JBQUMsa0JBQWUsWUFBVyxpQkFBZ0IsU0FBUyxNQUFNO0FBQUVELGtCQUFRSCxDQUFDO0FBQUdLLDBCQUFnQkwsRUFBRUksWUFBWTtBQUFHRyx3QkFBY1AsRUFBRTBCLGdCQUFnQixFQUFFO0FBQUdqQixvQkFBVVQsRUFBRTJCLGFBQWFRLFVBQVUsRUFBRTtBQUFHeEIsbUJBQVN5QixPQUFPcEMsRUFBRTRCLFlBQVksQ0FBQztBQUFHZix1QkFBYWIsRUFBRXFDLHFCQUFxQkMsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUFHLEdBQUcsNEJBQTVRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd1I7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLGVBQWMsU0FBUSxhQUFZLFNBQVMsTUFBTXZCLFVBQVUsU0FBUyxHQUFHLGdDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtIO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxlQUFjLE9BQU0sU0FBUSxTQUFTLE1BQU1BLFVBQVUsT0FBTyxHQUFHLDRCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsV0FBaGtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaWxCO0FBQUEsU0FBLzFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNjJDLEtBQXA4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTA4QyxLQUFqZ0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwZ0Q7QUFBQSxJQUFhLHVCQUFDLFNBQU0sT0FBTSxpQkFBZ0IsV0FBVyxXQUFXLGlDQUFDLGNBQVcsT0FBT3pCLFVBQVUsZ0JBQWUsV0FBVSxpQ0FBQyxhQUFVLE9BQU0sdUJBQXNCLE1BQU1BLFNBQVNXLE1BQU1BLFFBQVEsSUFBSSxRQUFRLENBQUFzQyxNQUFLLEdBQUdBLEVBQUVqQixFQUFFLElBQUlpQixFQUFFMUMsUUFBUSxJQUFJLFNBQVM7QUFBQSxNQUNqOUQsRUFBRTJDLEtBQUssWUFBWUMsT0FBTyxhQUFhQyxRQUFRQSxDQUFBSCxNQUFLLElBQUlBLEVBQUUxQyxRQUFRLEdBQUc7QUFBQSxNQUFHLEVBQUUyQyxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVoQixVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCLEVBQUc7QUFBQSxNQUFHLEVBQUVpQixLQUFLLFdBQVdDLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQUgsTUFBS3RFLFNBQVNzRSxFQUFFSSxXQUFXeEQsS0FBSzJDLFFBQVEsRUFBRTtBQUFBLE1BQy9PO0FBQUEsUUFDSVUsS0FBSztBQUFBLFFBQVVDLE9BQU87QUFBQSxRQUFJQyxRQUFRQSxDQUFBSCxNQUFLLHVCQUFDLGVBQVksV0FBVSxPQUFNO0FBQUEsaUNBQUMsVUFBTyxTQUFTLE1BQU0zQyxjQUFjMkMsRUFBRWpCLEVBQUUsR0FBRyw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUFTLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVMsTUFBTUQsV0FBV2tCLENBQUMsR0FBRyxrQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxhQUExTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJNO0FBQUEsTUFDdFA7QUFBQSxJQUFDLEtBSnkxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzUxRCxLQUxzeUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtweUQsS0FMaXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLcHVEO0FBQUEsSUFDcEIsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQzVDLFlBQVksT0FBTSx5QkFBd0IsU0FBUyxNQUFNQyxjQUFjLEVBQUUsR0FBRyxTQUFTLHVCQUFDLFVBQU8sU0FBUyxNQUFNQSxjQUFjLEVBQUUsR0FBRyxvQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QyxHQUNwSixpQ0FBQyxjQUFXLE9BQU9DLFVBQVUsZ0JBQWUsV0FBV0EsbUJBQVNJLFFBQVEsdUJBQUMsa0JBQ3JFO0FBQUEsNkJBQUMsY0FBVyxPQUFNLGFBQVk7QUFBQTtBQUFBLFFBQUVKLFNBQVNJLEtBQUtBLEtBQUtKO0FBQUFBLFdBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxjQUFXLE9BQU0sY0FBYSxpQ0FBQyxVQUFPLE9BQU9BLFNBQVNJLEtBQUtBLEtBQUtzQixVQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEU7QUFBQSxNQUMxRSx1QkFBQyxjQUFXLE9BQU0sWUFBWXRELG1CQUFTNEIsU0FBU0ksS0FBS0EsS0FBSzBDLFdBQVd4RCxLQUFLMkMsUUFBUSxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GO0FBQUEsTUFDcEYsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQmpDLG1CQUFTSSxLQUFLQSxLQUFLeUIsZ0JBQWdCLGVBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUNsRix1QkFBQyxjQUFXLE9BQU0sdUJBQXVCN0IsbUJBQVNJLEtBQUtBLEtBQUtvQyxxQkFBcUJDLEtBQUssSUFBSSxLQUFLLGFBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUc7QUFBQSxNQUN6Ryx1QkFBQyxjQUFXLE9BQU0sNkJBQTRCLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU96QyxTQUFTSSxLQUFLQSxLQUFLMEIsZUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRCxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1HO0FBQUEsTUFDbkcsdUJBQUMsY0FBVyxPQUFNLHlCQUF5QjlCLG1CQUFTSSxLQUFLQSxLQUFLMkIsZ0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUMzRSx1QkFBQyxjQUFXLE9BQU0sc0JBQXNCL0IsbUJBQVNJLEtBQUtBLEtBQUsyQyxnQ0FBZ0MsYUFBYSw2QkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrSTtBQUFBLE1BQ2xJLHVCQUFDLGNBQVcsSUFBSSxFQUFFVixZQUFZLFlBQVlXLGNBQWMsV0FBVyxHQUFJaEQsbUJBQVNJLEtBQUtBLEtBQUtHLGdCQUFnQixzQkFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2SDtBQUFBLFNBVHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVeEUsS0FWQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVWtCLEtBWHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQ0YsU0FBUyxPQUFNLHFCQUFvQixTQUFTLE1BQU1DLFFBQVEsSUFBSSxHQUFHLE1BQU1aLE9BQU91RCxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDNUMsV0FBVyxDQUFDRSxnQkFBZ0IsQ0FBQ0UsY0FBYyxDQUFDRSxVQUFVakIsT0FBT3VELFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSSxDQUFDNUM7QUFDdFA7QUFBUSxVQUFJO0FBQ1osY0FBTVgsT0FBT3dELFFBQVEsRUFBRUMsU0FBUzlDLFFBQVE4QyxTQUFTQyxNQUFNO0FBQUEsVUFDL0N2QixjQUFjcEI7QUFBQUEsVUFBWUY7QUFBQUEsVUFBY2lDLHNCQUFzQnpCLFVBQVVzQyxNQUFNLEtBQUssRUFBRUMsT0FBT3BELE9BQU87QUFBQSxVQUFHNkIsY0FBY3dCLE9BQU8xQyxLQUFLO0FBQUEsVUFBR2lCLGFBQWEsRUFBRVEsUUFBUTNCLFFBQVE2QyxVQUFVbEUsS0FBS2tFLFNBQVM7QUFBQSxVQUFHVCwrQkFBK0I7QUFBQSxRQUNoTyxFQUFFLENBQUM7QUFDUHpDLGdCQUFRLElBQUk7QUFBQSxNQUNoQixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsd0JBUHNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPOUUsR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT1osT0FBTytELFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU0sY0FBYSxRQUFNLE1BQUMsT0FBT2hELFlBQVksVUFBVSxDQUFBaUQsTUFBS2hELGNBQWNnRCxFQUFFQyxPQUFPQyxLQUFLLEdBQUlwRSxzQkFBWVksTUFBTUEsS0FBS3lELElBQUksQ0FBQUMsTUFBSyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFckMsSUFBS3FDO0FBQUFBLFlBQUVDO0FBQUFBLFVBQUs7QUFBQSxVQUFJRCxFQUFFcEM7QUFBQUEsYUFBakNvQyxFQUFFckMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RCxDQUFXLEtBQXpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMk07QUFBQSxRQUFZLHVCQUFDLGFBQVUsT0FBTSwyQkFBMEIsV0FBUyxNQUFDLFNBQVMsR0FBRyxPQUFPbEIsY0FBYyxVQUFVLENBQUFtRCxNQUFLbEQsZ0JBQWdCa0QsRUFBRUMsT0FBT0MsS0FBSyxLQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFJO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sNENBQTJDLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBTzdDLFdBQVcsVUFBVSxDQUFBMkMsTUFBSzFDLGFBQWEwQyxFQUFFQyxPQUFPQyxLQUFLLEtBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0o7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTyxtQkFBbUJ0RSxLQUFLa0UsUUFBUSxLQUFLLE9BQU83QyxRQUFRLFVBQVUsQ0FBQStDLE1BQUs5QyxVQUFVOEMsRUFBRUMsT0FBT0MsS0FBSyxLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE1BQUssVUFBUyxPQUFNLDBCQUF5QixPQUFPL0MsT0FBTyxZQUFZLEVBQUVtRCxLQUFLLEdBQUdDLEtBQUssR0FBRyxHQUFHLFVBQVUsQ0FBQVAsTUFBSzVDLFNBQVM0QyxFQUFFQyxPQUFPQyxLQUFLLEtBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0k7QUFBQSxXQUE3dkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErdkI7QUFBQSxTQVBuMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9nMkI7QUFBQSxJQUNoMkIsdUJBQUMsY0FBVyxNQUFNM0MsV0FBVyxXQUFXLE9BQU0saUNBQWdDLFNBQVMsTUFBTUMsVUFBVSxJQUFJLEdBQUcsTUFBTXZCLFFBQVFzRCxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDOUIsVUFBVWhELGdCQUFnQmtELE1BQU0sSUFBSSxLQUFLMUIsUUFBUXNELFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUNuUSxjQUFNdEQsUUFBUXVELFFBQVEsRUFBRUUsTUFBTSxFQUFFYyxpQkFBaUIvRCxHQUFHZ0QsV0FBVyxHQUFHeEIsZUFBZXhCLEdBQUd3QixpQkFBaUIsR0FBR3dDLGlCQUFpQmhELFFBQVFFLE9BQU8sRUFBRSxDQUFDO0FBQzNJSCxrQkFBVSxJQUFJO0FBQUEsTUFDbEIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUFnQixHQUFHLHdCQUpnSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXhHLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU92QixRQUFROEQsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQUUsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxpQ0FBZ0MsT0FBT3RDLFFBQVEsVUFBVSxDQUFBdUMsTUFBS3RDLFFBQVFzQyxFQUFFQyxPQUFPQyxLQUFLLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxTQUFRLE9BQU92QyxRQUFRLFVBQVUsQ0FBQXFDLE1BQUtwQyxVQUFVb0MsRUFBRUMsT0FBT0MsS0FBSyxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFBRSx1QkFBQyxhQUFVLElBQUksTUFBTXRFLEtBQUttQyxFQUFFLG9CQUFvQixvQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBQTdRO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeVI7QUFBQSxTQUo5VztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSTJYO0FBQUEsSUFDM1gsdUJBQUMsaUJBQWMsTUFBTVIsV0FBVyxTQUFTLE9BQU0scUJBQW9CLGNBQWEscUJBQW9CLGFBQWEsWUFBWWQsR0FBR3NCLE1BQU0sRUFBRSxVQUFVbkMsS0FBS3lFLElBQUksb0dBQW9HLGVBQWEsTUFBQyxTQUFTLE1BQU03QyxVQUFVLElBQUksR0FBRyxNQUFNdEIsTUFBTXFELFNBQVMsT0FBT3JELE1BQU02RCxPQUFPLFdBQVcsQ0FBQXBDLFlBQVV6QixNQUFNc0QsUUFBUSxFQUFFRSxNQUFNLEVBQUVjLGlCQUFpQi9ELEdBQUdnRCxXQUFXLEdBQUc5QixnQkFBTyxFQUFFLENBQUMsS0FBL2E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpYjtBQUFBLElBQUUsdUJBQUMsaUJBQWMsTUFBTSxDQUFDLENBQUNFLGdCQUFnQixPQUFNLDZCQUE0QixjQUFhLHNCQUFxQixhQUFhLFlBQVlwQixHQUFHc0IsTUFBTSxFQUFFLGVBQWVGLGdCQUFnQnZCLFlBQVksRUFBRSxnR0FBZ0csZUFBYSxNQUFDLFNBQVMsTUFBTXdCLFdBQVcsSUFBSSxHQUFHLE1BQU0zQixRQUFRb0QsU0FBUyxPQUFPcEQsUUFBUTRELE9BQU8sV0FBVyxDQUFBcEMsWUFBVXhCLFFBQVFxRCxRQUFRLEVBQUVqRCxNQUFNLEVBQUVILFlBQVl5QyxPQUFPaEIsZ0JBQWdCdkIsWUFBWSxDQUFDLEVBQUUsR0FBR29ELE1BQU0sRUFBRWMsaUJBQWlCL0QsR0FBR2dELFdBQVcsR0FBRzlCLGdCQUFPLEVBQUUsQ0FBQyxLQUFoaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFraEI7QUFBQSxPQWhDMzdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQzY3QjtBQUN4OEI7QUFBQ2hDLEdBOUNlRCxlQUFhO0FBQUEsVUFDUm5CLFVBQ0xGLFFBQ1FBLFFBQ0hBLFFBQ0ZDLFlBQ0NBLFlBQ0ZBLFlBQ0VBLFlBRUNELE1BQU07QUFBQTtBQUFBLEtBVlhxQjtBQStDVCxnQkFBU2dGLGlCQUFpQjtBQUFBQyxNQUFBO0FBQzdCLFFBQU1DLFNBQVN2RyxPQUFPLGNBQWM7QUFDcEMsUUFBTXdHLE1BQU12RyxXQUFXLGlCQUFpQixFQUFFO0FBQzFDLFFBQU0sQ0FBQ3dHLE1BQU1DLE9BQU8sSUFBSW5ILFNBQVMsRUFBRSxHQUFHLENBQUNvSCxVQUFVQyxXQUFXLElBQUlySCxTQUFTLEVBQUUsR0FBRyxDQUFDc0gsUUFBUUMsU0FBUyxJQUFJdkgsU0FBa0MsSUFBSTtBQUMxSSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLDREQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HO0FBQUEsSUFBRSx1QkFBQyxlQUFZLFNBQVMsRUFBRXdILElBQUksT0FBT0MsSUFBSSxVQUFVLEdBQUc7QUFBQSw2QkFBQyxTQUFNLE9BQU0sZUFBYyxVQUFTLFNBQVEsaUNBQUMsT0FBSSxXQUFVLFFBQU8sVUFBVSxPQUFPckIsTUFBTTtBQUFFQSxVQUFFc0IsZUFBZTtBQUFHLFlBQUk7QUFDalIsZ0JBQU10QyxJQUFJLE1BQU02QixJQUFJckIsUUFBUSxFQUFFRSxNQUFNLEVBQUU2QixnQkFBZ0JYLE9BQU9sRSxNQUFNQSxLQUFLdUIsaUJBQWlCLEdBQUc2QyxNQUFNVSxtQkFBbUJSLFlBQVksS0FBSyxFQUFFLENBQUM7QUFDeklHLG9CQUFVbkMsRUFBRXRDLElBQUk7QUFBQSxRQUNwQixRQUNNO0FBQUEsUUFBRTtBQUFBLE1BQWdCLEdBQUc7QUFBQSwrQkFBQyxlQUFZLE9BQU9tRSxJQUFJZCxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsUUFBRSx1QkFBQyxjQUFXLE9BQU9hLFFBQVNBLGlCQUFPbEUsTUFBTUEsUUFBUSx1QkFBQyxTQUFNLFVBQVMsUUFBTztBQUFBO0FBQUEsVUFBMEJrRSxPQUFPbEUsS0FBS0EsS0FBS3VCO0FBQUFBLFVBQWM7QUFBQSxVQUFJMkMsT0FBT2xFLEtBQUtBLEtBQUtzQixXQUFXLFdBQVcsa0JBQWtCNEMsT0FBT2xFLEtBQUtBLEtBQUt3QixnQkFBZ0IsU0FBUyxLQUFLO0FBQUEsVUFBNkI7QUFBQSxhQUF6TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJQLEtBQTVTO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcVQ7QUFBQSxRQUFhLHVCQUFDLGNBQVcsV0FBVSxXQUFVO0FBQUEsaUNBQUMsYUFBVSxPQUFNLHNCQUFxQixXQUFTLE1BQUMsU0FBUyxHQUFHLE9BQU80QyxNQUFNLFVBQVUsQ0FBQWQsTUFBS2UsUUFBUWYsRUFBRUMsT0FBT0MsS0FBSyxLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSDtBQUFBLFVBQUUsdUJBQUMsYUFBVSxPQUFNLHVDQUFzQyxPQUFPYyxVQUFVLFVBQVUsQ0FBQWhCLE1BQUtpQixZQUFZakIsRUFBRUMsT0FBT0MsS0FBSyxLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLFVBQUUsdUJBQUMsa0JBQWUsWUFBVyxpQkFBZ0IsTUFBSyxVQUFTLFNBQVEsYUFBWSxNQUFNVyxJQUFJdEIsU0FBUyxVQUFVLENBQUN1QixLQUFLVyxLQUFLLEtBQUssQ0FBQ2IsT0FBT2xFLE1BQU0sd0JBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdKO0FBQUEsYUFBdlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3YTtBQUFBLFdBSnZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSW9tQixLQUpocEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlzcEI7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxvQkFBbUIsVUFBUyxTQUFRLGlDQUFDLE9BQUt3RSxtQkFBUyxtQ0FBRTtBQUFBLCtCQUFDLGNBQVcsSUFBSSxFQUFFdkMsWUFBWSxXQUFXLEdBQUl1QyxpQkFBT0osUUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLHNCQUFzQkksaUJBQU9LLGtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsUUFBYSx1QkFBQyxjQUFXLE9BQU0sVUFBVUw7QUFBQUEsaUJBQU9RO0FBQUFBLFVBQVU7QUFBQSxhQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsUUFBYSx1QkFBQyxjQUFXLE9BQU0sb0JBQW1CLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9SLE9BQU9TLGlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUFhLHVCQUFDLGNBQVcsT0FBTSxrQkFBa0JUO0FBQUFBLGlCQUFPVSxlQUFlO0FBQUEsVUFBVTtBQUFBLFVBQUlWLE9BQU9XLGdCQUFnQjtBQUFBLGFBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUFhLHVCQUFDLGNBQVcsT0FBTSxnQkFBZSxxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQWEsdUJBQUMsY0FBVyxTQUFRLGFBQVksSUFBSWxILFNBQVNtSCxRQUFRckQsZUFBZSxxQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFFBQWN5QyxPQUFPYSxRQUFRQyxTQUFTLEtBQUssdUJBQUMsU0FBTSxXQUFVLE9BQU0sSUFBSSxDQUFDckgsU0FBU3NILEtBQUtDLFdBQVcsRUFBRUMsVUFBVSxPQUFPLENBQUMsR0FBSWpCLGlCQUFPYSxRQUFRNUIsSUFBSSxDQUFBaUMsTUFBSyx1QkFBQyxRQUF5QixPQUFPLEdBQUdBLEVBQUVDLElBQUksTUFBTUQsRUFBRXJFLEVBQUUsTUFBekNxRSxFQUFFQyxPQUFPRCxFQUFFckUsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RCxDQUFHLEtBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUs7QUFBQSxRQUFVbUQsT0FBT29CLFNBQVNuQyxJQUFJLENBQUFvQyxNQUFLLHVCQUFDLFNBQWMsVUFBUyxXQUFVLElBQUk1SCxTQUFTbUgsUUFBUXJELGVBQWdCOEQsZUFBM0RBLEdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RSxDQUFRO0FBQUEsV0FBLzFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaTJCLElBQU0sdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixvR0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1SCxLQUE3K0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyL0IsS0FBNWlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa2pDO0FBQUEsU0FKcHdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJNHdEO0FBQUEsT0FKbjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJaTREO0FBQzU0RDtBQUFDNUIsSUFUZUQsZ0JBQWM7QUFBQSxVQUNYckcsUUFDSEMsVUFBVTtBQUFBO0FBQUEsTUFGVm9HO0FBVVQsZ0JBQVM4QixrQkFBa0I7QUFBQUMsTUFBQTtBQUM5QixRQUFNLEVBQUU3RyxLQUFLLElBQUlyQixTQUFTO0FBQzFCLFFBQU1tSSxPQUFPckksT0FBTyxtQkFBbUIsRUFBRXNJLE9BQU9uSSxhQUFhLGlCQUFpQixFQUFFLENBQUM7QUFDakYsUUFBTW9JLE1BQU12SSxPQUFPLGNBQWM7QUFDakMsUUFBTXdJLFNBQVN2SSxXQUFXLG9CQUFvQixDQUFDLGlCQUFpQixDQUFDO0FBQ2pFLFFBQU0sQ0FBQ3dJLE1BQU1DLE9BQU8sSUFBSW5KLFNBQVMsS0FBSyxHQUFHLENBQUNvSixTQUFTQyxVQUFVLElBQUlySixTQUFTLEVBQUUsR0FBRyxDQUFDeUQsV0FBV0MsWUFBWSxJQUFJMUQsU0FBUyxFQUFFLEdBQUcsQ0FBQ3NKLFVBQVVDLFdBQVcsSUFBSXZKLFNBQTRCLElBQUk7QUFDbkwsUUFBTXdKLFNBQVMvSSxPQUFPLGlCQUFpQixFQUFFa0MsTUFBTSxFQUFFOEcsY0FBY0gsVUFBVW5GLE1BQU0sR0FBRyxFQUFFLEdBQUd2QixRQUFRMEcsUUFBUSxDQUFDO0FBQ3hHLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sZUFBYyxVQUFTLGtFQUFpRSxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVEsYUFBWSxTQUFTLE1BQU1ILFFBQVEsSUFBSSxHQUFHLDZCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBHLEtBQTdOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK087QUFBQSxJQUFHTyxZQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLElBQUkzSSxTQUFTNEksT0FBT0MsVUFBVSw4RkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSTtBQUFBLElBQVMsdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxxQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPZCxNQUFNLGdCQUFlLFdBQVUsaUNBQUMsYUFBVSxPQUFNLHVCQUFzQixNQUFNQSxLQUFLaEcsTUFBTUEsUUFBUSxJQUFJLFFBQVEsQ0FBQXNDLE1BQUtBLEVBQUVqQixJQUFJLE9BQU0sa0ZBQWlGLFNBQVM7QUFBQSxRQUN6cUIsRUFBRWtCLEtBQUssTUFBTUMsT0FBTyxnQkFBZ0JDLFFBQVFBLENBQUFILE1BQUssdUJBQUMsVUFBTyxTQUFTLE1BQU1tRSxZQUFZbkUsQ0FBQyxHQUFJQSxZQUFFakIsTUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QyxFQUFVO0FBQUEsUUFBRyxFQUFFa0IsS0FBSyxVQUFVQyxPQUFPLGdCQUFnQkMsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRXVDLGVBQWU7QUFBQSxRQUFHLEVBQUV0QyxLQUFLLFdBQVdDLE9BQU8sZUFBZUMsUUFBUUEsQ0FBQUgsTUFBS0EsRUFBRXlFLGVBQWU7QUFBQSxRQUFHLEVBQUV4RSxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQUgsTUFBSyxHQUFHQSxFQUFFMEUsV0FBVyxNQUFNMUUsRUFBRTJFLFVBQVUsR0FBRztBQUFBLFFBQUcsRUFBRTFFLEtBQUssWUFBWUMsT0FBTyxpQkFBaUJDLFFBQVFBLENBQUFILE1BQUtBLEVBQUU0RSxpQkFBaUI7QUFBQSxRQUFHLEVBQUUzRSxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVoQixVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCLEVBQUc7QUFBQSxNQUFDLEtBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVwZixLQUZrYztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWhjO0FBQUEsTUFBYSx1QkFBQyxTQUFNLE1BQU0wRSxLQUFLaEcsTUFBTThCLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxTQUZ3VztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXRXO0FBQUEsSUFDbkQsdUJBQUMsY0FBVyxNQUFZLE9BQU0sMEJBQXlCLFNBQVMsTUFBTXVFLFFBQVEsS0FBSyxHQUFHLE1BQU1GLE9BQU90RCxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDeUQsV0FBVyxDQUFDSixJQUFJbEcsUUFBUW1HLE9BQU90RCxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDeE4sY0FBTVAsSUFBSSxNQUFNNkQsT0FBT3JELFFBQVEsRUFBRUUsTUFBTSxFQUFFNkIsZ0JBQWdCcUIsSUFBSWxHLE1BQU1BLEtBQUt1QixpQkFBaUIsR0FBR3dGLGdCQUFnQlQsU0FBU2EscUJBQXFCeEcsYUFBYSxLQUFLLEVBQUUsQ0FBQztBQUMvSjhGLG9CQUFZbkUsRUFBRXRDLElBQUk7QUFDbEJxRyxnQkFBUSxLQUFLO0FBQUEsTUFDakIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUFnQixHQUFHLHVCQUx1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2hGLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9GLE9BQU85QyxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFBRSx1QkFBQyxjQUFZO0FBQUEsK0JBQUMsYUFBVSxPQUFNLG9DQUFtQyxPQUFPaUQsU0FBUyxVQUFVLENBQUFoRCxNQUFLaUQsV0FBV2pELEVBQUVDLE9BQU9DLEtBQUssS0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLCtCQUE4QixPQUFPN0MsV0FBVyxVQUFVLENBQUEyQyxNQUFLMUMsYUFBYTBDLEVBQUVDLE9BQU9DLEtBQUssS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RztBQUFBLFFBQUUsdUJBQUMsU0FBTSxVQUFTLFFBQU8sMEdBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUg7QUFBQSxXQUE3VjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFXO0FBQUEsU0FMeGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtxYztBQUFBLElBQWEsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQ2dELFVBQVUsT0FBTSxxQkFBb0IsU0FBUyxNQUFNQyxZQUFZLElBQUksR0FBRyxTQUFTLHVCQUFDLGVBQVksV0FBVSxPQUFNO0FBQUEsNkJBQUMsVUFBTyxVQUFVQyxPQUFPVSxZQUFZLFNBQVMsTUFBTSxLQUFLVixPQUFPVyxRQUFRLEdBQUcsZ0NBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxNQUFTLHVCQUFDLFVBQU8sU0FBUyxNQUFNWixZQUFZLElBQUksR0FBRyxvQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLFNBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0wsR0FBZ0IsaUNBQUMsY0FBVyxPQUFPQyxRQUFRLGdCQUFlLFdBQVdBLGlCQUFPMUcsUUFBUSx1QkFBQyxrQkFBZTtBQUFBLDZCQUFDLGNBQVcsT0FBTSxNQUFNMEcsaUJBQU8xRyxLQUFLQSxLQUFLcUIsTUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGNBQWNxRixpQkFBTzFHLEtBQUtBLEtBQUsrRyxrQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGdCQUFnQkwsaUJBQU8xRyxLQUFLQSxLQUFLNkUsa0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxXQUFVLGlDQUFDLFVBQU8sT0FBTzZCLE9BQU8xRyxLQUFLQSxLQUFLc0IsVUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QyxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sU0FBU29GO0FBQUFBLGVBQU8xRyxLQUFLQSxLQUFLZ0g7QUFBQUEsUUFBWTtBQUFBLFFBQUlOLE9BQU8xRyxLQUFLQSxLQUFLaUg7QUFBQUEsV0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQlAsaUJBQU8xRyxLQUFLQSxLQUFLa0gsb0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUFjUixPQUFPMUcsS0FBS0EsS0FBS3NILGVBQWUsdUJBQUMsYUFBVSxJQUFJLE1BQU1wSSxLQUFLbUMsRUFBRSxTQUFTcUYsT0FBTzFHLEtBQUtBLEtBQUtzSCxXQUFXLElBQUksZ0NBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxTQUFwbUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpbkIsS0FBcnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdXNCLEtBQWwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQSsvQjtBQUFBLE9BUnY4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUW85QztBQUMvOUM7QUFBQ3ZCLElBaEJlRCxpQkFBZTtBQUFBLFVBQ1ZqSSxVQUNKRixRQUFtQ0csY0FDcENILFFBQ0dDLFlBRUFELE1BQU07QUFBQTtBQUFBLE1BTlRtSTtBQWlCaEIsTUFBTXlCLFlBQVksRUFBRUMsYUFBYSxrQkFBa0JDLFlBQVksV0FBV0MsaUJBQWlCLGtCQUFrQkMsWUFBWSxjQUFjO0FBQ2hJLGdCQUFTQyxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUUzSSxLQUFLLElBQUlyQixTQUFTO0FBQzFCLFFBQU1pSyxRQUFRbkssT0FBTyxnQkFBZ0I7QUFDckMsUUFBTW9LLFVBQVVwSyxPQUFPLG9CQUFvQjtBQUMzQyxRQUFNMkIsU0FBUzFCLFdBQVcsbUJBQW1CLENBQUMsa0JBQWtCLHNCQUFzQixDQUFDO0FBQ3ZGLFFBQU1vSyxVQUFVcEssV0FBVyxxQkFBcUIsQ0FBQyxrQkFBa0IsZ0JBQWdCLHNCQUFzQixDQUFDO0FBQzFHLFFBQU1xSyxlQUFlckssV0FBVyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQztBQUM1RSxRQUFNLENBQUNxQyxTQUFTaUksVUFBVSxJQUFJaEwsU0FBMkIsSUFBSSxHQUFHLENBQUNpTCxPQUFPQyxRQUFRLElBQUlsTCxTQUFTLEVBQUUsR0FBRyxDQUFDbUQsWUFBWUMsYUFBYSxJQUFJcEQsU0FBUyxFQUFFLEdBQUcsQ0FBQ21MLFFBQVFDLFNBQVMsSUFBSXBMLFNBQVMsRUFBRSxHQUFHLENBQUNxTCxNQUFNQyxPQUFPLElBQUl0TCxTQUcxTCxJQUFJLEdBQUcsQ0FBQ3FELFFBQVFDLFNBQVMsSUFBSXRELFNBQThCLElBQUksR0FBRyxDQUFDZ0YsUUFBUXVHLFNBQVMsSUFBSXZMLFNBQVMsRUFBRSxHQUFHLENBQUN3TCxVQUFVQyxXQUFXLElBQUl6TCxTQUFTLEVBQUU7QUFDckosU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxjQUFhLFVBQVMsbUZBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUg7QUFBQSxJQUFFLHVCQUFDLGNBQVcsT0FBTzRLLE9BQU8sZ0JBQWUsV0FBVSxpQ0FBQyxlQUFZLFNBQVMsRUFBRXBELElBQUksT0FBT2tFLElBQUksZ0JBQWdCLEdBQUlkLGdCQUFNOUgsTUFBTUEsS0FBS3lELElBQUksQ0FBQW5CLE1BQUssdUJBQUMsU0FBaUIsT0FBT2lGLFVBQVVqRixFQUFFdUcsSUFBSSxHQUFHLFFBQVEsdUJBQUMsVUFBTyxPQUFPdkcsRUFBRWhCLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsR0FBSSxVQUFTLFNBQVEsaUNBQUMsT0FBSTtBQUFBLDZCQUFDLGNBQVcsT0FBTSwwQkFBMEJnQixZQUFFd0csZUFBZSxlQUFleEcsRUFBRXdHLFlBQVksS0FBSyxlQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJHO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sY0FBY3hHLFlBQUV5RyxpQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQnpHLFlBQUUwRyxjQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFBYSx1QkFBQyxTQUFNLFdBQVUsT0FBTSxJQUFJLENBQUMvSyxTQUFTc0gsS0FBS0MsV0FBV3ZILFNBQVNtSCxRQUFRckQsZUFBZTlELFNBQVM0SSxPQUFPQyxVQUFVLEVBQUVyQixVQUFVLE9BQU8sQ0FBQyxHQUFJbkQsWUFBRTJHLGVBQWV4RixJQUFJLENBQUF5RixTQUFRLHVCQUFDLFFBQWdCLE9BQU9BLFFBQWJBLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QixDQUFFLEtBQW5NO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcU07QUFBQSxNQUFRLHVCQUFDLGVBQVksV0FBVSxPQUFPO0FBQUEsK0JBQUMsa0JBQWUsWUFBVyxpQkFBZ0IsU0FBUyxNQUFNO0FBQUVoQixxQkFBVzVGLENBQUM7QUFBRzhGLG1CQUFTOUYsRUFBRXdHLGdCQUFnQixFQUFFO0FBQUd4SSx3QkFBY2dDLEVBQUU2RyxxQkFBcUIsRUFBRTtBQUFHYixvQkFBVWhHLEVBQUV5RyxhQUFhO0FBQUEsUUFBRyxHQUFHLHlCQUFwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZMO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxhQUFZLE9BQU96RyxFQUFFaEIsV0FBVyxXQUFXLFlBQVksU0FBUyxTQUFTLE1BQU1rSCxRQUFRLEVBQUVZLE1BQU05RyxHQUFHekIsUUFBUXlCLEVBQUVoQixXQUFXLFdBQVcsV0FBVyxRQUFRLENBQUMsR0FBSWdCLFlBQUVoQixXQUFXLFdBQVcscUJBQXFCLGNBQWxPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNk87QUFBQSxXQUF6ZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBlO0FBQUEsU0FBOTZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNDdCLEtBQWpoQ2dCLEVBQUVqQixJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbWlDLENBQVEsS0FBaG9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa29DLEtBQXJyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1zQztBQUFBLElBQWEsdUJBQUMsU0FBTSxPQUFNLHVCQUFzQixXQUFXLFdBQVcsaUNBQUMsY0FBVyxPQUFPMEcsU0FBUyxnQkFBZSxXQUFVLGlDQUFDLGFBQVUsT0FBTSwwQkFBeUIsTUFBTUEsUUFBUS9ILE1BQU1BLFFBQVEsSUFBSSxRQUFRLENBQUFELE1BQUtBLEVBQUVzQixJQUFJLFNBQVM7QUFBQSxNQUNsaUQsRUFBRWtCLEtBQUssUUFBUUMsT0FBTyxRQUFRQyxRQUFRQSxDQUFBMUMsTUFBS0EsRUFBRThJLEtBQUs7QUFBQSxNQUFHLEVBQUV0RyxLQUFLLFNBQVNDLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQTFDLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFc0osZUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QixFQUFHO0FBQUEsTUFBRyxFQUFFOUcsS0FBSyxRQUFRQyxPQUFPLFdBQVdDLFFBQVFBLENBQUExQyxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRXVKLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEIsRUFBRztBQUFBLE1BQUcsRUFBRS9HLEtBQUssWUFBWUMsT0FBTyxjQUFjQyxRQUFRQSxDQUFBMUMsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUV3SixZQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLEVBQUc7QUFBQSxNQUFHLEVBQUVoSCxLQUFLLFNBQVNDLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQTFDLE1BQUtBLEVBQUV5SixVQUFVLFdBQVcsV0FBVztBQUFBLE1BQzVYO0FBQUEsUUFDSWpILEtBQUs7QUFBQSxRQUFVQyxPQUFPO0FBQUEsUUFBSUMsUUFBUUEsQ0FBQTFDLE1BQUssdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUyxNQUFNO0FBQUVTLG9CQUFVVCxDQUFDO0FBQUcwSSxvQkFBVTFJLEVBQUVzSixhQUFhbkgsVUFBVSxFQUFFO0FBQUd5RyxzQkFBWSxFQUFFO0FBQUEsUUFBRyxHQUFHLGdDQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBKO0FBQUEsTUFDck07QUFBQSxJQUFDLEtBSjI3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzk3QyxLQUx5NEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUt2NEMsS0FMODBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLajBDO0FBQUEsSUFDcEIsdUJBQUMsU0FBTSxPQUFNLHNDQUFxQyxXQUFXLFdBQVcsVUFBUyxTQUM5RSxpQ0FBQyxrQkFBZ0IsZUFBWSw2QkFDekI7QUFBQSw2QkFBQyxTQUFNLFVBQVMsUUFBTywrSkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzSztBQUFBLE1BQ3RLLHVCQUFDLGNBQVcsT0FBTSwwQkFBeUIsdUdBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0k7QUFBQSxNQUNsSSx1QkFBQyxjQUFXLE9BQU0scUJBQW9CLGlGQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVHO0FBQUEsTUFDdkcsdUJBQUMsY0FBVyxPQUFNLG1CQUFrQiwrRkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSDtBQUFBLFNBSnZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQzFJLFNBQVMsT0FBTSx3Q0FBdUMsU0FBUyxNQUFNaUksV0FBVyxJQUFJLEdBQUcsTUFBTTVJLE9BQU91RCxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDc0YsU0FBUyxDQUFDOUgsY0FBYyxDQUFDZ0ksVUFBVS9JLE9BQU91RCxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDeFAsY0FBTXZELE9BQU93RCxRQUFRLEVBQUVqRCxNQUFNLEVBQUU0SixZQUFZeEosU0FBU29CLE1BQU0sR0FBRyxHQUFHMkIsTUFBTSxFQUFFYyxpQkFBaUI3RCxTQUFTOEMsV0FBVyxHQUFHK0YsY0FBY1gsT0FBT2dCLG1CQUFtQjlJLFlBQVkwSSxlQUFlVixPQUFPLEVBQUUsQ0FBQztBQUM3TEgsbUJBQVcsSUFBSTtBQUFBLE1BQ25CLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyw2QkFKNEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUkvRixHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPNUksT0FBTytELFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU0sK0JBQThCLE9BQU84RSxPQUFPLFVBQVUsQ0FBQTdFLE1BQUs4RSxTQUFTOUUsRUFBRUMsT0FBT0MsS0FBSyxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLE9BQU9uRCxZQUFZLFVBQVUsQ0FBQWlELE1BQUtoRCxjQUFjZ0QsRUFBRUMsT0FBT0MsS0FBSyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0saUNBQWdDLE9BQU82RSxRQUFRLFVBQVUsQ0FBQS9FLE1BQUtnRixVQUFVaEYsRUFBRUMsT0FBT0MsS0FBSyxLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlHO0FBQUEsUUFBRSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxnRkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFdBQXpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaWE7QUFBQSxTQUoxZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXVnQjtBQUFBLElBQ3ZnQix1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQytFLE1BQU0sT0FBT0EsTUFBTTFILFdBQVcsVUFBVSxxQkFBcUIsOEJBQThCLGNBQWMwSCxNQUFNMUgsV0FBVyxVQUFVLHFCQUFxQix3QkFBd0IsYUFBYSxHQUFHMEgsT0FBT2hCLFVBQVVnQixLQUFLYSxLQUFLUCxJQUFJLElBQUksRUFBRSxLQUFLTixNQUFNYSxLQUFLL0gsTUFBTSxFQUFFLFdBQVduQyxLQUFLeUUsSUFBSSxLQUFLNEUsTUFBTTFILFdBQVcsVUFBVSwyQ0FBMkMsc0RBQXNELDREQUE0RCxlQUFhLE1BQUMsU0FBUyxNQUFNMkgsUUFBUSxJQUFJLEdBQUcsT0FBT1IsUUFBUTNFLE9BQU8sTUFBTTJFLFFBQVFuRixTQUFTLFdBQVcsQ0FBQTVCLFdBQVUrRyxRQUFRbEYsUUFBUSxFQUFFRSxNQUFNLEVBQUVjLGlCQUFpQnlFLE1BQU1hLEtBQUtyRyxXQUFXLEdBQUcyRyxPQUFPLFFBQVFELFlBQVlsQixNQUFNYSxLQUFLL0gsTUFBTSxNQUFNUixRQUFRMEgsTUFBTTFILFVBQVUsU0FBU0ksT0FBTyxFQUFFLENBQUMsS0FBcnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdXZCO0FBQUEsSUFDdnZCLHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUNWLFFBQVEsT0FBTSwyQkFBMEIsU0FBUyxNQUFNQyxVQUFVLElBQUksR0FBRyxNQUFNeUgsYUFBYXBGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNYLFVBQVUsQ0FBQ3dHLFlBQVlULGFBQWFwRixTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDek8sY0FBTW9GLGFBQWFuRixRQUFRLEVBQUVqRCxNQUFNLEVBQUU0SixZQUFZbEosUUFBUWMsTUFBTSxHQUFHLEdBQUcyQixNQUFNO0FBQUEsVUFDbkVjLGlCQUFpQnZELFFBQVF3QyxXQUFXO0FBQUEsVUFBR3NHLGFBQWEsRUFBRW5ILFFBQVFrQixVQUFVbEUsS0FBS2tFLFNBQVM7QUFBQSxVQUFHdUcsUUFBUXBKLFFBQVFvSixVQUFVO0FBQUEsVUFBU0MsWUFBWWxCO0FBQUFBLFFBQzVJLEVBQUUsQ0FBQztBQUNQbEksa0JBQVUsSUFBSTtBQUFBLE1BQ2xCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyxnQ0FObUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1uRixHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPeUgsYUFBYTVFLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU8sYUFBYW5FLEtBQUtrRSxRQUFRLEtBQUssT0FBT2xCLFFBQVEsVUFBVSxDQUFBb0IsTUFBS21GLFVBQVVuRixFQUFFQyxPQUFPQyxLQUFLLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSw4QkFBNkIsT0FBT2tGLFVBQVUsVUFBVSxDQUFBcEYsTUFBS3FGLFlBQVlyRixFQUFFQyxPQUFPQyxLQUFLLEtBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEc7QUFBQSxXQUFsTztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9PO0FBQUEsU0FOdFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1tVjtBQUFBLE9BMUJ6VTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJzVjtBQUNqVztBQUFDcUUsSUF0Q2VELGVBQWE7QUFBQSxVQUNSL0osVUFDSEYsUUFDRUEsUUFDREMsWUFDQ0EsWUFDS0EsVUFBVTtBQUFBO0FBQUEsTUFObkJnSztBQUFhLElBQUFpQyxJQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFILElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJBY3Rpb25Hcm91cCIsIkZvcm1GaWVsZHMiLCJTZWN0aW9uR3JpZCIsIlN1cmZhY2VDb250ZW50IiwidXNlU3RhdGUiLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIkNoaXAiLCJNZW51SXRlbSIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsInVzZUxpc3RRdWVyeSIsImNvZGVQb2ludExlbmd0aCIsImRhdGVUaW1lIiwibGF5b3V0U3giLCJBbW91bnQiLCJDb25maXJtRGlhbG9nIiwiRGF0YVRhYmxlIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIk11dGF0aW9uQnV0dG9uIiwiUGFnZUhlYWRlciIsIlBhZ2VyIiwiUGFuZWwiLCJRdWVyeVN0YXRlIiwiUm91dGVMaW5rIiwiU3RhdHVzIiwiVG9vbGJhciIsIkJvdENvbmZpZ1BhZ2UiLCJfcyIsInNob3AiLCJnZXQiLCJjb25uZWN0aW9ucyIsInZlcnNpb25zIiwidXBkYXRlIiwicHVibGlzaCIsInBhdXNlIiwicmVzdG9yZSIsInJldmlzaW9uSWQiLCJzZXRSZXZpc2lvbklkIiwicmV2aXNpb24iLCJwYXRoIiwiQm9vbGVhbiIsImIiLCJkYXRhIiwiZWRpdGluZyIsInNldEVkaXQiLCJpbnN0cnVjdGlvbnMiLCJzZXRJbnN0cnVjdGlvbnMiLCJjb25uZWN0aW9uIiwic2V0Q29ubmVjdGlvbiIsImJ1ZGdldCIsInNldEJ1ZGdldCIsInN0ZXBzIiwic2V0U3RlcHMiLCJrbm93bGVkZ2UiLCJzZXRLbm93bGVkZ2UiLCJhY3Rpb24iLCJzZXRBY3Rpb24iLCJldmFsSWQiLCJzZXRFdmFsIiwicmVhc29uIiwic2V0UmVhc29uIiwicmVzdG9yZVZlcnNpb24iLCJzZXRSZXN0b3JlIiwiaWQiLCJzdGF0dXMiLCJkcmFmdFJldmlzaW9uIiwibGl2ZVJldmlzaW9uIiwiY29ubmVjdGlvbklkIiwiZGFpbHlCdWRnZXQiLCJtYXhUb29sU3RlcHMiLCJwdWJsaXNoZWRBdCIsInRpbWV6b25lIiwicGFnZSIsInNlY3Rpb25CZWZvcmUiLCJzZWN0aW9uQWZ0ZXIiLCJ3aGl0ZVNwYWNlIiwiYW1vdW50IiwiU3RyaW5nIiwia25vd2xlZGdlUmV2aXNpb25JZHMiLCJqb2luIiwiciIsImtleSIsImxhYmVsIiwicmVuZGVyIiwidXBkYXRlZEF0IiwicmVxdWlyZUh1bWFuT3JkZXJDb25maXJtYXRpb24iLCJvdmVyZmxvd1dyYXAiLCJwZW5kaW5nIiwiZXhlY3V0ZSIsInZlcnNpb24iLCJib2R5Iiwic3BsaXQiLCJmaWx0ZXIiLCJOdW1iZXIiLCJjdXJyZW5jeSIsImVycm9yIiwiZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiYyIsIm5hbWUiLCJtaW4iLCJtYXgiLCJleHBlY3RlZFZlcnNpb24iLCJldmFsdWF0aW9uUnVuSWQiLCJQbGF5Z3JvdW5kUGFnZSIsIl9zMiIsImNvbmZpZyIsInJ1biIsInRleHQiLCJzZXRUZXh0IiwiY3VzdG9tZXIiLCJzZXRDdXN0b21lciIsInJlc3VsdCIsInNldFJlc3VsdCIsInhzIiwibGciLCJwcmV2ZW50RGVmYXVsdCIsImNvbmZpZ1JldmlzaW9uIiwiY3VzdG9tZXJDb250ZXh0SWQiLCJ0cmltIiwibGF0ZW5jeU1zIiwiZXN0aW1hdGVkQ29zdCIsImlucHV0VG9rZW5zIiwib3V0cHV0VG9rZW5zIiwic3VyZmFjZSIsInNvdXJjZXMiLCJsZW5ndGgiLCJjb2RlIiwiaW5saW5lR2FwIiwiZmxleFdyYXAiLCJzIiwidHlwZSIsIndhcm5pbmdzIiwidyIsIkV2YWx1YXRpb25zUGFnZSIsIl9zMyIsImxpc3QiLCJxdWVyeSIsImJvdCIsImNyZWF0ZSIsIm9wZW4iLCJzZXRPcGVuIiwiZGF0YXNldCIsInNldERhdGFzZXQiLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiZGV0YWlsIiwiZXZhbHVhdGlvbklkIiwiX19NT0NLX18iLCJub3RpY2UiLCJhZnRlckdhcCIsImRhdGFzZXRWZXJzaW9uIiwicGFzc2VkQ2FzZXMiLCJ0b3RhbENhc2VzIiwiY3JpdGljYWxGYWlsdXJlcyIsImtub3dsZWRnZVJldmlzaW9uSWQiLCJpc0ZldGNoaW5nIiwicmVmZXRjaCIsInJlcG9ydEpvYklkIiwicm9sZU5hbWVzIiwic2FsZXNfYWRtaW4iLCJhY2NvdW50YW50Iiwid2FyZWhvdXNlX2J1eWVyIiwic3VwZXJ2aXNvciIsIkFnZW50VGVhbVBhZ2UiLCJfczQiLCJyb2xlcyIsImJ1ZGdldHMiLCJjb250cm9sIiwiYnVkZ2V0VXBkYXRlIiwic2V0RWRpdGluZyIsIm93bmVyIiwic2V0T3duZXIiLCJwb2xpY3kiLCJzZXRQb2xpY3kiLCJzdG9wIiwic2V0U3RvcCIsInNldEFtb3VudCIsImFwcHJvdmFsIiwic2V0QXBwcm92YWwiLCJtZCIsImtpbmQiLCJodW1hbk93bmVySWQiLCJwb2xpY3lWZXJzaW9uIiwiZ2VuZXJhdGlvbiIsImFsbG93ZWRUb29sSWRzIiwidG9vbCIsIm1vZGVsQ29ubmVjdGlvbklkIiwicm9sZSIsImxpbWl0QW1vdW50IiwiY29uc3VtZWQiLCJyZXNlcnZlZCIsImVuYWJsZWQiLCJyZXNvdXJjZUlkIiwic2NvcGUiLCJwZXJpb2QiLCJhcHByb3ZhbElkIiwiX2MiLCJfYzIiLCJfYzMiLCJfYzQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFjdGlvbkdyb3VwLCBGb3JtRmllbGRzLCBTZWN0aW9uR3JpZCwgU3VyZmFjZUNvbnRlbnQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBDaGlwLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgdHlwZSB7IEFnZW50Um9sZSwgQm90Q29uZmlnLCBCb3RSZXZpc2lvbiwgQnVkZ2V0UG9saWN5LCBFdmFsdWF0aW9uLCBQbGF5Z3JvdW5kUmVzdWx0IH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJy4uLy4uL3NoYXJlZC9hcGkvaG9va3MnO1xyXG5pbXBvcnQgeyB1c2VTY29wZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcclxuaW1wb3J0IHsgY29kZVBvaW50TGVuZ3RoLCBkYXRlVGltZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XHJcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2xheW91dCc7XHJcbmltcG9ydCB7IEFtb3VudCwgQ29uZmlybURpYWxvZywgRGF0YVRhYmxlLCBEZXRhaWxMaW5lLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgTXV0YXRpb25CdXR0b24sIFBhZ2VIZWFkZXIsIFBhZ2VyLCBQYW5lbCwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0dXMsIFRvb2xiYXIgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmV4cG9ydCBmdW5jdGlvbiBCb3RDb25maWdQYWdlKCkge1xyXG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgZ2V0ID0gdXNlQXBpKCdnZXRCb3RDb25maWcnKTtcclxuICAgIGNvbnN0IGNvbm5lY3Rpb25zID0gdXNlQXBpKCdsaXN0QUlDb25uZWN0aW9ucycsIHt9LCB0cnVlKTtcclxuICAgIGNvbnN0IHZlcnNpb25zID0gdXNlQXBpKCdsaXN0Qm90UmV2aXNpb25zJyk7XHJcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVCb3REcmFmdCcsIFsnZ2V0Qm90Q29uZmlnJywgJ2xpc3RCb3RSZXZpc2lvbnMnLCAnZ2V0Qm90UmV2aXNpb24nXSk7XHJcbiAgICBjb25zdCBwdWJsaXNoID0gdXNlQ29tbWFuZCgncHVibGlzaEJvdENvbmZpZycsIFsnZ2V0Qm90Q29uZmlnJywgJ2xpc3RCb3RSZXZpc2lvbnMnLCAnZ2V0Qm90UmV2aXNpb24nXSk7XHJcbiAgICBjb25zdCBwYXVzZSA9IHVzZUNvbW1hbmQoJ3BhdXNlQm90JywgWydnZXRCb3RDb25maWcnXSk7XHJcbiAgICBjb25zdCByZXN0b3JlID0gdXNlQ29tbWFuZCgncmVzdG9yZUJvdFJldmlzaW9uJywgWydnZXRCb3RDb25maWcnLCAnbGlzdEJvdFJldmlzaW9ucycsICdnZXRCb3RSZXZpc2lvbiddKTtcclxuICAgIGNvbnN0IFtyZXZpc2lvbklkLCBzZXRSZXZpc2lvbklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCByZXZpc2lvbiA9IHVzZUFwaSgnZ2V0Qm90UmV2aXNpb24nLCB7IHBhdGg6IHsgcmV2aXNpb25JZCB9IH0sIEJvb2xlYW4ocmV2aXNpb25JZCkpO1xuICAgIGNvbnN0IGIgPSBnZXQuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0XSA9IHVzZVN0YXRlPEJvdENvbmZpZyB8IG51bGw+KG51bGwpLCBbaW5zdHJ1Y3Rpb25zLCBzZXRJbnN0cnVjdGlvbnNdID0gdXNlU3RhdGUoJycpLCBbY29ubmVjdGlvbiwgc2V0Q29ubmVjdGlvbl0gPSB1c2VTdGF0ZSgnJyksIFtidWRnZXQsIHNldEJ1ZGdldF0gPSB1c2VTdGF0ZSgnJyksIFtzdGVwcywgc2V0U3RlcHNdID0gdXNlU3RhdGUoJzQnKSwgW2tub3dsZWRnZSwgc2V0S25vd2xlZGdlXSA9IHVzZVN0YXRlKCcnKSwgW2FjdGlvbiwgc2V0QWN0aW9uXSA9IHVzZVN0YXRlPCdwdWJsaXNoJyB8ICdwYXVzZScgfCBudWxsPihudWxsKSwgW2V2YWxJZCwgc2V0RXZhbF0gPSB1c2VTdGF0ZSgnJyksIFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnJyksIFtyZXN0b3JlVmVyc2lvbiwgc2V0UmVzdG9yZV0gPSB1c2VTdGF0ZTxCb3RSZXZpc2lvbiB8IG51bGw+KG51bGwpO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCLEkGnhu4F1IGtoaeG7g24gQWRtaW4gQUlcIiBzdWJ0aXRsZT1cIlTDoWNoIGPhuqV1IGjDrG5oIMSRYW5nIGNo4bqheSB2w6AgY+G6pXUgaMOsbmggxJFhbmcgc2/huqFuLiBLaMO0bmcgYuG6rXQgdOG7sSDEkeG7mW5nIGNo4buJIHbDrCBsxrB1IHByb21wdC5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9ib3QvcGxheWdyb3VuZGB9PlRo4butIGJvdDwvUm91dGVMaW5rPn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtnZXR9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntiICYmIDxQYW5lbCB0aXRsZT1cIkPhuqV1IGjDrG5oIGhp4buHbiBow6BuaFwiIGFjdGlvbj17PFN0YXR1cyB2YWx1ZT17Yi5zdGF0dXN9Lz59IGJvZHlNb2RlPVwiaW5zZXRcIj48Qm94PjxEZXRhaWxMaW5lIGxhYmVsPVwiQuG6o24gbmjDoXBcIj57Yi5kcmFmdFJldmlzaW9ufTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkLhuqNuIMSRYW5nIGNo4bqheVwiPntiLmxpdmVSZXZpc2lvbiB8fCAnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJNw6Mga+G6v3QgbuG7kWkgQUlcIj57Yi5jb25uZWN0aW9uSWQgfHwgJ0NoxrBhIGNo4buNbid9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiR2nhu5tpIGjhuqFuIGNoaSBwaMOtIG3hu5dpIG5nw6B5XCI+PEFtb3VudCB3cmFwIHZhbHVlPXtiLmRhaWx5QnVkZ2V0fS8+PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiR2nhu5tpIGjhuqFuIGLGsOG7m2MgY8O0bmcgY+G7pVwiPntiLm1heFRvb2xTdGVwc308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJYdeG6pXQgYuG6o24gbMO6Y1wiPntkYXRlVGltZShiLnB1Ymxpc2hlZEF0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+PFR5cG9ncmFwaHkgc3g9e1tsYXlvdXRTeC5wYWdlLnNlY3Rpb25CZWZvcmUsIGxheW91dFN4LnBhZ2Uuc2VjdGlvbkFmdGVyLCB7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcgfV19PntiLmluc3RydWN0aW9ucyB8fCAnQ2jGsGEgY8OzIGNo4buJIGThuqtuLid9PC9UeXBvZ3JhcGh5PjxBbGVydCBzZXZlcml0eT1cImluZm9cIj7EkMahbiBkbyBBSSDEkeG7gSB4deG6pXQgduG6q24gY+G6p24gbmfGsOG7nWkgY8OzIHF1eeG7gW4ga2nhu4NtIHRyYSB2w6AgeMOhYyBuaOG6rW4uIEzGsHUgYuG6o24gbmjDoXAga2jDtG5nIHRoYXkgxJHhu5VpIGPhuqV1IGjDrG5oIMSRYW5nIGNo4bqheSBob+G6t2MgdOG7sSBjaOG7kXQgxJHGoW4uPC9BbGVydD48QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgYmVmb3JlR2FwPVwiZm9ybVwiPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiYm90LmNvbmZpZ3VyZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RWRpdChiKTsgc2V0SW5zdHJ1Y3Rpb25zKGIuaW5zdHJ1Y3Rpb25zKTsgc2V0Q29ubmVjdGlvbihiLmNvbm5lY3Rpb25JZCB8fCAnJyk7IHNldEJ1ZGdldChiLmRhaWx5QnVkZ2V0Py5hbW91bnQgfHwgJycpOyBzZXRTdGVwcyhTdHJpbmcoYi5tYXhUb29sU3RlcHMpKTsgc2V0S25vd2xlZGdlKGIua25vd2xlZGdlUmV2aXNpb25JZHMuam9pbignXFxuJykpOyB9fT5T4butYSBi4bqjbiBuaMOhcDwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJib3QucHVibGlzaFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ3B1Ymxpc2gnKX0+RHV54buHdCAmIHh14bqldCBi4bqjbjwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJib3QucHVibGlzaFwiIGNvbG9yPVwiZXJyb3JcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ3BhdXNlJyl9PlThuqFtIGThu6tuZyBib3Q8L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+PC9Cb3g+PC9QYW5lbD59PC9RdWVyeVN0YXRlPjxQYW5lbCB0aXRsZT1cIkPDoWMgcGhpw6puIGLhuqNuXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e3ZlcnNpb25zfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj48RGF0YVRhYmxlIGxhYmVsPVwiTOG7i2NoIHPhu60gY+G6pXUgaMOsbmggQUlcIiByb3dzPXt2ZXJzaW9ucy5kYXRhPy5kYXRhIHx8IFtdfSByb3dLZXk9e3IgPT4gYCR7ci5pZH0tJHtyLnJldmlzaW9ufWB9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ3JldmlzaW9uJywgbGFiZWw6ICdQaGnDqm4gYuG6o24nLCByZW5kZXI6IHIgPT4gYCMke3IucmV2aXNpb259YCB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiByID0+IDxTdGF0dXMgdmFsdWU9e3Iuc3RhdHVzfS8+IH0sIHsga2V5OiAndXBkYXRlZCcsIGxhYmVsOiAnQ+G6rXAgbmjhuq10JywgcmVuZGVyOiByID0+IGRhdGVUaW1lKHIudXBkYXRlZEF0LCBzaG9wLnRpbWV6b25lKSB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHIgPT4gPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiPjxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0UmV2aXNpb25JZChyLmlkKX0+WGVtIHBoacOqbiBi4bqjbjwvQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiYm90LmNvbmZpZ3VyZVwiIG9uQ2xpY2s9eygpID0+IHNldFJlc3RvcmUocil9Pktow7RpIHBo4bulYyB2w6BvIG5ow6FwPC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPlxyXG4gICAgICAgIH1cclxuICAgIF19Lz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cclxuIDxFZGl0RGlhbG9nIG9wZW49eyEhcmV2aXNpb25JZH0gdGl0bGU9XCJDaGkgdGnhur90IHBoacOqbiBi4bqjbiBBSVwiIG9uQ2xvc2U9eygpID0+IHNldFJldmlzaW9uSWQoJycpfSBhY3Rpb25zPXs8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFJldmlzaW9uSWQoJycpfT7EkMOzbmc8L0J1dHRvbj59PlxuICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtyZXZpc2lvbn0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e3JldmlzaW9uLmRhdGEgJiYgPFN1cmZhY2VDb250ZW50PlxuICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlBoacOqbiBi4bqjblwiPiN7cmV2aXNpb24uZGF0YS5kYXRhLnJldmlzaW9ufTwvRGV0YWlsTGluZT5cbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJUcuG6oW5nIHRow6FpXCI+PFN0YXR1cyB2YWx1ZT17cmV2aXNpb24uZGF0YS5kYXRhLnN0YXR1c30vPjwvRGV0YWlsTGluZT5cbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJD4bqtcCBuaOG6rXRcIj57ZGF0ZVRpbWUocmV2aXNpb24uZGF0YS5kYXRhLnVwZGF0ZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxuICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk3DoyBr4bq/dCBu4buRaSBBSVwiPntyZXZpc2lvbi5kYXRhLmRhdGEuY29ubmVjdGlvbklkIHx8ICdDaMawYSBjaOG7jW4nfTwvRGV0YWlsTGluZT5cbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJQaGnDqm4gYuG6o24ga2nhur9uIHRo4bupY1wiPntyZXZpc2lvbi5kYXRhLmRhdGEua25vd2xlZGdlUmV2aXNpb25JZHMuam9pbignLCAnKSB8fCAnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiR2nhu5tpIGjhuqFuIGNoaSBwaMOtIG3hu5dpIG5nw6B5XCI+PEFtb3VudCB3cmFwIHZhbHVlPXtyZXZpc2lvbi5kYXRhLmRhdGEuZGFpbHlCdWRnZXR9Lz48L0RldGFpbExpbmU+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiR2nhu5tpIGjhuqFuIGLGsOG7m2MgY8O0bmcgY+G7pVwiPntyZXZpc2lvbi5kYXRhLmRhdGEubWF4VG9vbFN0ZXBzfTwvRGV0YWlsTGluZT5cbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJOZ8aw4budaSB4w6FjIG5o4bqtbiDEkcahblwiPntyZXZpc2lvbi5kYXRhLmRhdGEucmVxdWlyZUh1bWFuT3JkZXJDb25maXJtYXRpb24gPyAnQuG6r3QgYnXhu5ljJyA6ICdUaGVvIGNow61uaCBzw6FjaCBtw6F5IGNo4bunJ308L0RldGFpbExpbmU+XG4gICAgICAgIDxUeXBvZ3JhcGh5IHN4PXt7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcsIG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9fT57cmV2aXNpb24uZGF0YS5kYXRhLmluc3RydWN0aW9ucyB8fCAnQ2jGsGEgY8OzIGNo4buJIGThuqtuLid9PC9UeXBvZ3JhcGh5PlxuICAgIDwvU3VyZmFjZUNvbnRlbnQ+fTwvUXVlcnlTdGF0ZT5cbiA8L0VkaXREaWFsb2c+XG4gPEVkaXREaWFsb2cgb3Blbj17ISFlZGl0aW5nfSB0aXRsZT1cIkPhuqV1IGjDrG5oIGLhuqNuIG5ow6FwXCIgb25DbG9zZT17KCkgPT4gc2V0RWRpdChudWxsKX0gYnVzeT17dXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshZWRpdGluZyB8fCAhaW5zdHJ1Y3Rpb25zIHx8ICFjb25uZWN0aW9uIHx8ICFidWRnZXQgfHwgdXBkYXRlLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgaWYgKCFlZGl0aW5nKVxyXG4gICAgICAgIHJldHVybjsgdHJ5IHtcclxuICAgICAgICBhd2FpdCB1cGRhdGUuZXhlY3V0ZSh7IHZlcnNpb246IGVkaXRpbmcudmVyc2lvbiwgYm9keToge1xyXG4gICAgICAgICAgICAgICAgY29ubmVjdGlvbklkOiBjb25uZWN0aW9uLCBpbnN0cnVjdGlvbnMsIGtub3dsZWRnZVJldmlzaW9uSWRzOiBrbm93bGVkZ2Uuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbiksIG1heFRvb2xTdGVwczogTnVtYmVyKHN0ZXBzKSwgZGFpbHlCdWRnZXQ6IHsgYW1vdW50OiBidWRnZXQsIGN1cnJlbmN5OiBzaG9wLmN1cnJlbmN5IH0sIHJlcXVpcmVIdW1hbk9yZGVyQ29uZmlybWF0aW9uOiB0cnVlXHJcbiAgICAgICAgICAgIH0gfSk7XHJcbiAgICAgICAgc2V0RWRpdChudWxsKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PkzGsHUgbmjDoXA8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17dXBkYXRlLmVycm9yfS8+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgbGFiZWw9XCJL4bq/dCBu4buRaSBBSVwiIHNlbGVjdCB2YWx1ZT17Y29ubmVjdGlvbn0gb25DaGFuZ2U9e2UgPT4gc2V0Q29ubmVjdGlvbihlLnRhcmdldC52YWx1ZSl9Pntjb25uZWN0aW9ucy5kYXRhPy5kYXRhLm1hcChjID0+IDxNZW51SXRlbSBrZXk9e2MuaWR9IHZhbHVlPXtjLmlkfT57Yy5uYW1lfSDCtyB7Yy5zdGF0dXN9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJDaOG7iSBk4bqrbiB0xrAgduG6pW4gxJHDoyBkdXnhu4d0XCIgbXVsdGlsaW5lIG1pblJvd3M9ezh9IHZhbHVlPXtpbnN0cnVjdGlvbnN9IG9uQ2hhbmdlPXtlID0+IHNldEluc3RydWN0aW9ucyhlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHBoacOqbiBi4bqjbiBraeG6v24gdGjhu6ljICht4buXaSBkw7JuZyBt4buZdCBtw6MpXCIgbXVsdGlsaW5lIG1pblJvd3M9ezN9IHZhbHVlPXtrbm93bGVkZ2V9IG9uQ2hhbmdlPXtlID0+IHNldEtub3dsZWRnZShlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPXtgTmfDom4gc8OhY2ggbmfDoHkgKCR7c2hvcC5jdXJyZW5jeX0pYH0gdmFsdWU9e2J1ZGdldH0gb25DaGFuZ2U9e2UgPT4gc2V0QnVkZ2V0KGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgdHlwZT1cIm51bWJlclwiIGxhYmVsPVwiU+G7kSBixrDhu5tjIGPDtG5nIGPhu6UgdOG7kWkgxJFhXCIgdmFsdWU9e3N0ZXBzfSBpbnB1dFByb3BzPXt7IG1pbjogMCwgbWF4OiAyMCB9fSBvbkNoYW5nZT17ZSA9PiBzZXRTdGVwcyhlLnRhcmdldC52YWx1ZSl9Lz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPlxyXG4gPEVkaXREaWFsb2cgb3Blbj17YWN0aW9uID09PSAncHVibGlzaCd9IHRpdGxlPVwiWHXhuqV0IGLhuqNuIGPhuqV1IGjDrG5oIMSRw6MgxJHDoW5oIGdpw6FcIiBvbkNsb3NlPXsoKSA9PiBzZXRBY3Rpb24obnVsbCl9IGJ1c3k9e3B1Ymxpc2gucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFldmFsSWQgfHwgY29kZVBvaW50TGVuZ3RoKHJlYXNvbikgPCA1IHx8IHB1Ymxpc2gucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xyXG4gICAgICAgIGF3YWl0IHB1Ymxpc2guZXhlY3V0ZSh7IGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBiPy52ZXJzaW9uIHx8IDEsIGRyYWZ0UmV2aXNpb246IGI/LmRyYWZ0UmV2aXNpb24gfHwgMSwgZXZhbHVhdGlvblJ1bklkOiBldmFsSWQsIHJlYXNvbiB9IH0pO1xyXG4gICAgICAgIHNldEFjdGlvbihudWxsKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19Plh14bqldCBi4bqjbjwvQnV0dG9uPn0+PEVycm9yTm90aWNlIGVycm9yPXtwdWJsaXNoLmVycm9yfS8+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgbGFiZWw9XCJNw6MgbOG6p24gxJHDoW5oIGdpw6EgxJHDum5nIGLhuqNuIG5ow6FwXCIgdmFsdWU9e2V2YWxJZH0gb25DaGFuZ2U9e2UgPT4gc2V0RXZhbChlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTMO9IGRvXCIgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9e2UgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX0vPjxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2JvdC9ldmFsdWF0aW9uc2B9PlhlbSBr4bq/dCBxdeG6oyBraeG7g20gdGjhu608L1JvdXRlTGluaz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPlxyXG4gPENvbmZpcm1EaWFsb2cgb3Blbj17YWN0aW9uID09PSAncGF1c2UnfSB0aXRsZT1cIlThuqFtIGThu6tuZyBBZG1pbiBBSVwiIGNvbmZpcm1MYWJlbD1cIlThuqFtIGThu6tuZyBBZG1pbiBBSVwiIGRlc2NyaXB0aW9uPXtgQWRtaW4gQUkgJHtiPy5pZCB8fCBcIlwifSB0cm9uZyAke3Nob3AubmFtZX06IGThu6tuZyBjw6FjIHTDoWMgxJHhu5luZyBjaMawYSBn4butaS4gVGluIG5o4bqvbiDEkcOjIMSRxrDhu6NjIG5ow6AgY3VuZyBj4bqlcCBuaOG6rW4ga2jDtG5nIHRo4buDIHRodSBo4buTaSBi4bqxbmcgbsO6dCBuw6B5LmB9IHJlcXVpcmVSZWFzb24gb25DbG9zZT17KCkgPT4gc2V0QWN0aW9uKG51bGwpfSBidXN5PXtwYXVzZS5wZW5kaW5nfSBlcnJvcj17cGF1c2UuZXJyb3J9IG9uQ29uZmlybT17cmVhc29uID0+IHBhdXNlLmV4ZWN1dGUoeyBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogYj8udmVyc2lvbiB8fCAxLCByZWFzb24gfSB9KX0vPjxDb25maXJtRGlhbG9nIG9wZW49eyEhcmVzdG9yZVZlcnNpb259IHRpdGxlPVwiS2jDtGkgcGjhu6VjIGLhuqNuIGPFqSB2w6BvIG5ow6FwXCIgY29uZmlybUxhYmVsPVwiS2jDtGkgcGjhu6VjIHbDoG8gbmjDoXBcIiBkZXNjcmlwdGlvbj17YEPhuqV1IGjDrG5oICR7Yj8uaWQgfHwgXCJcIn0sIHBoacOqbiBi4bqjbiAke3Jlc3RvcmVWZXJzaW9uPy5yZXZpc2lvbiB8fCBcIlwifToga2jDtGkgcGjhu6VjIHbDoG8gYuG6o24gbmjDoXAuIELhuqNuIMSRYW5nIGNo4bqheSDEkcaw4bujYyBnaeG7rzsgcGjhuqNpIGtp4buDbSB0aOG7rSB2w6AgZHV54buHdCBs4bqhaSB0csaw4bubYyB4deG6pXQgYuG6o24uYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRSZXN0b3JlKG51bGwpfSBidXN5PXtyZXN0b3JlLnBlbmRpbmd9IGVycm9yPXtyZXN0b3JlLmVycm9yfSBvbkNvbmZpcm09e3JlYXNvbiA9PiByZXN0b3JlLmV4ZWN1dGUoeyBwYXRoOiB7IHJldmlzaW9uSWQ6IFN0cmluZyhyZXN0b3JlVmVyc2lvbj8ucmV2aXNpb24gfHwgMSkgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGI/LnZlcnNpb24gfHwgMSwgcmVhc29uIH0gfSl9Lz48Lz47XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFBsYXlncm91bmRQYWdlKCkge1xyXG4gICAgY29uc3QgY29uZmlnID0gdXNlQXBpKCdnZXRCb3RDb25maWcnKTtcclxuICAgIGNvbnN0IHJ1biA9IHVzZUNvbW1hbmQoJ3J1blBsYXlncm91bmQnLCBbXSk7XHJcbiAgICBjb25zdCBbdGV4dCwgc2V0VGV4dF0gPSB1c2VTdGF0ZSgnJyksIFtjdXN0b21lciwgc2V0Q3VzdG9tZXJdID0gdXNlU3RhdGUoJycpLCBbcmVzdWx0LCBzZXRSZXN1bHRdID0gdXNlU3RhdGU8UGxheWdyb3VuZFJlc3VsdCB8IG51bGw+KG51bGwpO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJQaMOybmcgdGjhu60gYm90XCIgc3VidGl0bGU9XCJUaOG7rSBj4bqldSBow6xuaCBoaeG7h24gdOG6oWkgbcOgIGtow7RuZyBn4butaSB0aW4gY2hvIGtow6FjaCBow6BuZy5cIi8+PFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICcxZnInLCBsZzogJzFmciAxZnInIH19PjxQYW5lbCB0aXRsZT1cIkPDonUgaOG7j2kgdGjhu61cIiBib2R5TW9kZT1cImluc2V0XCI+PEJveCBjb21wb25lbnQ9XCJmb3JtXCIgb25TdWJtaXQ9e2FzeW5jIChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgdHJ5IHtcclxuICAgICAgICBjb25zdCByID0gYXdhaXQgcnVuLmV4ZWN1dGUoeyBib2R5OiB7IGNvbmZpZ1JldmlzaW9uOiBjb25maWcuZGF0YT8uZGF0YS5kcmFmdFJldmlzaW9uIHx8IDEsIHRleHQsIGN1c3RvbWVyQ29udGV4dElkOiBjdXN0b21lciB8fCBudWxsIH0gfSk7XHJcbiAgICAgICAgc2V0UmVzdWx0KHIuZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT48RXJyb3JOb3RpY2UgZXJyb3I9e3J1bi5lcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtjb25maWd9Pntjb25maWcuZGF0YT8uZGF0YSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+UGjDsm5nIHRo4butIGTDuW5nIGLhuqNuIG5ow6FwICN7Y29uZmlnLmRhdGEuZGF0YS5kcmFmdFJldmlzaW9ufSDCtyB7Y29uZmlnLmRhdGEuZGF0YS5zdGF0dXMgPT09ICdhY3RpdmUnID8gYMSRYW5nIGNo4bqheSBi4bqjbiAjJHtjb25maWcuZGF0YS5kYXRhLmxpdmVSZXZpc2lvbiB8fCAnY2jGsGEgY8OzJ31gIDogJ2PhuqV1IGjDrG5oIGJvdCDEkWFuZyB04bqhbSBk4burbmcnfS4gTuG7mWkgZHVuZyB0aOG7rSBraMO0bmcgZ+G7rWkgcmEgbmdvw6BpLjwvQWxlcnQ+fTwvUXVlcnlTdGF0ZT48Rm9ybUZpZWxkcyBiZWZvcmVHYXA9XCJzdXJmYWNlXCI+PFRleHRGaWVsZCBsYWJlbD1cIk7hu5lpIGR1bmcga2jDoWNoIGjhu49pXCIgbXVsdGlsaW5lIG1pblJvd3M9ezl9IHZhbHVlPXt0ZXh0fSBvbkNoYW5nZT17ZSA9PiBzZXRUZXh0KGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJNw6Mga2jDoWNoIMSR4buDIHRo4butIG5n4buvIGPhuqNuaCAodMO5eSBjaOG7jW4pXCIgdmFsdWU9e2N1c3RvbWVyfSBvbkNoYW5nZT17ZSA9PiBzZXRDdXN0b21lcihlLnRhcmdldC52YWx1ZSl9Lz48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImJvdC5jb25maWd1cmVcIiB0eXBlPVwic3VibWl0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e3J1bi5wZW5kaW5nfSBkaXNhYmxlZD17IXRleHQudHJpbSgpIHx8ICFjb25maWcuZGF0YX0+Q2jhuqF5IHRo4butPC9NdXRhdGlvbkJ1dHRvbj48L0Zvcm1GaWVsZHM+PC9Cb3g+PC9QYW5lbD48UGFuZWwgdGl0bGU9XCJL4bq/dCBxdeG6oyBjw7Mgbmd14buTblwiIGJvZHlNb2RlPVwiaW5zZXRcIj48Qm94PntyZXN1bHQgPyA8PjxUeXBvZ3JhcGh5IHN4PXt7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcgfX0+e3Jlc3VsdC50ZXh0fTwvVHlwb2dyYXBoeT48RGV0YWlsTGluZSBsYWJlbD1cIlBoacOqbiBi4bqjbiBj4bqldSBow6xuaFwiPntyZXN1bHQuY29uZmlnUmV2aXNpb259PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwixJDhu5kgdHLhu4VcIj57cmVzdWx0LmxhdGVuY3lNc30gbXM8L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJDaGkgcGjDrSDGsOG7m2MgdMOtbmhcIj48QW1vdW50IHdyYXAgdmFsdWU9e3Jlc3VsdC5lc3RpbWF0ZWRDb3N0fS8+PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiVG9rZW4gdsOgbyAvIHJhXCI+e3Jlc3VsdC5pbnB1dFRva2VucyA/PyAnQ2jGsGEgcsO1J30gLyB7cmVzdWx0Lm91dHB1dFRva2VucyA/PyAnQ2jGsGEgcsO1J308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJH4butaSByYSBuZ2/DoGlcIj5LaMO0bmc8L0RldGFpbExpbmU+PFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMlwiIHN4PXtsYXlvdXRTeC5zdXJmYWNlLnNlY3Rpb25CZWZvcmV9Pk5ndeG7k248L1R5cG9ncmFwaHk+e3Jlc3VsdC5zb3VyY2VzLmxlbmd0aCA+IDAgJiYgPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIHN4PXtbbGF5b3V0U3guY29kZS5pbmxpbmVHYXAsIHsgZmxleFdyYXA6ICd3cmFwJyB9XX0+e3Jlc3VsdC5zb3VyY2VzLm1hcChzID0+IDxDaGlwIGtleT17cy50eXBlICsgcy5pZH0gbGFiZWw9e2Ake3MudHlwZX0gLyAke3MuaWR9YH0gLz4pfTwvU3RhY2s+fXtyZXN1bHQud2FybmluZ3MubWFwKHcgPT4gPEFsZXJ0IGtleT17d30gc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e2xheW91dFN4LnN1cmZhY2Uuc2VjdGlvbkJlZm9yZX0+e3d9PC9BbGVydD4pfTwvPiA6IDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5DaOG6oXkgY8OidSBo4buPaSDEkeG7gyB4ZW0gY8OidSB0cuG6oyBs4budaSwgbmd14buTbiB2w6AgY+G6o25oIGLDoW8uIEtow7RuZyBjw7MgxJFp4buDbSBjaOG6pXQgbMaw4bujbmcgdOG7sSB04bqhby48L1R5cG9ncmFwaHk+fTwvQm94PjwvUGFuZWw+PC9TZWN0aW9uR3JpZD48Lz47XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIEV2YWx1YXRpb25zUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RFdmFsdWF0aW9ucycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdEV2YWx1YXRpb25zJykgfSk7XHJcbiAgICBjb25zdCBib3QgPSB1c2VBcGkoJ2dldEJvdENvbmZpZycpO1xyXG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlRXZhbHVhdGlvbicsIFsnbGlzdEV2YWx1YXRpb25zJ10pO1xyXG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbZGF0YXNldCwgc2V0RGF0YXNldF0gPSB1c2VTdGF0ZSgnJyksIFtrbm93bGVkZ2UsIHNldEtub3dsZWRnZV0gPSB1c2VTdGF0ZSgnJyksIFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8RXZhbHVhdGlvbiB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGRldGFpbCA9IHVzZUFwaSgnZ2V0RXZhbHVhdGlvbicsIHsgcGF0aDogeyBldmFsdWF0aW9uSWQ6IHNlbGVjdGVkPy5pZCB8fCAnJyB9IH0sIEJvb2xlYW4oc2VsZWN0ZWQpKTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwixJDDoW5oIGdpw6EgQUlcIiBzdWJ0aXRsZT1cIkvhur90IHF14bqjIGfhuq9uIGPhuqV1IGjDrG5oLCBk4buvIGxp4buHdSBraeG7g20gdGjhu60gdsOgIHBoacOqbiBi4bqjbiBraeG6v24gdGjhu6ljLlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiYm90LmNvbmZpZ3VyZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5DaOG6oXkgxJHDoW5oIGdpw6E8L011dGF0aW9uQnV0dG9uPn0vPntfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+Q2jhur8gxJHhu5kgbcO0IHBo4buPbmcgY2jhu4kga2nhu4NtIHF1eSB0csOsbmgsIGtow7RuZyDEkcOhbmggZ2nDoSBjaOG6pXQgbMaw4bujbmcgbcO0IGjDrG5oIEFJIHRo4bqtdC48L0FsZXJ0Pn08UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdEV2YWx1YXRpb25zXCIgLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+PERhdGFUYWJsZSBsYWJlbD1cIkzhu4tjaCBz4butIMSRw6FuaCBnacOhIEFJXCIgcm93cz17bGlzdC5kYXRhPy5kYXRhIHx8IFtdfSByb3dLZXk9e3IgPT4gci5pZH0gZW1wdHk9XCJDaMawYSBjw7MgbOG6p24gxJHDoW5oIGdpw6EgbsOgby4gQ8OzIHRo4buDIGNo4bqheSDEkcOhbmggZ2nDoSBj4bqldSBow6xuaCBuaMOhcCB04burIG7DunQgcGjDrWEgdHLDqm4uXCIgY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ0zhuqduIMSRw6FuaCBnacOhJywgcmVuZGVyOiByID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQocil9PntyLmlkfTwvQnV0dG9uPiB9LCB7IGtleTogJ2NvbmZpZycsIGxhYmVsOiAnQuG6o24gY+G6pXUgaMOsbmgnLCByZW5kZXI6IHIgPT4gci5jb25maWdSZXZpc2lvbiB9LCB7IGtleTogJ2RhdGFzZXQnLCBsYWJlbDogJ0Lhu5kga2nhu4NtIHRo4butJywgcmVuZGVyOiByID0+IHIuZGF0YXNldFZlcnNpb24gfSwgeyBrZXk6ICdjb3VudCcsIGxhYmVsOiAnxJDhuqF0IC8gdOG7lW5nJywgcmVuZGVyOiByID0+IGAke3IucGFzc2VkQ2FzZXN9IC8gJHtyLnRvdGFsQ2FzZXN9YCB9LCB7IGtleTogJ2NyaXRpY2FsJywgbGFiZWw6ICdM4buXaSB0cuG7jW5nIHnhur91JywgcmVuZGVyOiByID0+IHIuY3JpdGljYWxGYWlsdXJlcyB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiByID0+IDxTdGF0dXMgdmFsdWU9e3Iuc3RhdHVzfS8+IH1cclxuICAgIF19Lz48L1F1ZXJ5U3RhdGU+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YT8ucGFnZX0vPjwvUGFuZWw+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT1cIsSQw6FuaCBnacOhIGPhuqV1IGjDrG5oIG5ow6FwXCIgb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IWRhdGFzZXQgfHwgIWJvdC5kYXRhIHx8IGNyZWF0ZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgY29uc3QgciA9IGF3YWl0IGNyZWF0ZS5leGVjdXRlKHsgYm9keTogeyBjb25maWdSZXZpc2lvbjogYm90LmRhdGE/LmRhdGEuZHJhZnRSZXZpc2lvbiB8fCAxLCBkYXRhc2V0VmVyc2lvbjogZGF0YXNldCwga25vd2xlZGdlUmV2aXNpb25JZDoga25vd2xlZGdlIHx8IG51bGwgfSB9KTtcclxuICAgICAgICBzZXRTZWxlY3RlZChyLmRhdGEpO1xyXG4gICAgICAgIHNldE9wZW4oZmFsc2UpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+QuG6r3QgxJHhuqd1PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0vPjxGb3JtRmllbGRzID48VGV4dEZpZWxkIGxhYmVsPVwiUGhpw6puIGLhuqNuIGLhu5kga2nhu4NtIHRo4butIMSRw6MgxJHEg25nIGvDvVwiIHZhbHVlPXtkYXRhc2V0fSBvbkNoYW5nZT17ZSA9PiBzZXREYXRhc2V0KGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJNw6MgYuG6o24ga2nhur9uIHRo4bupYyAodMO5eSBjaOG7jW4pXCIgdmFsdWU9e2tub3dsZWRnZX0gb25DaGFuZ2U9e2UgPT4gc2V0S25vd2xlZGdlKGUudGFyZ2V0LnZhbHVlKX0vPjxBbGVydCBzZXZlcml0eT1cImluZm9cIj5Nw6MgYuG7mSBraeG7g20gdGjhu60gcGjhuqNpIGRvIGJhY2tlbmQgeMOhYyBtaW5oLiBLaMO0bmcgdOG7sSBn4buNaSB04bu3IGzhu4cgMTAwJSBsw6AgY2jhu6luZyBuaOG6rW4gY2jhuqV0IGzGsOG7o25nLjwvQWxlcnQ+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48RWRpdERpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT1cIkNoaSB0aeG6v3QgxJHDoW5oIGdpw6FcIiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYWN0aW9ucz17PEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiPjxCdXR0b24gZGlzYWJsZWQ9e2RldGFpbC5pc0ZldGNoaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIGRldGFpbC5yZWZldGNoKCl9PkPhuq1wIG5o4bqtdCBr4bq/dCBxdeG6ozwvQnV0dG9uPjxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9PsSQw7NuZzwvQnV0dG9uPjwvQWN0aW9uR3JvdXA+fT48UXVlcnlTdGF0ZSBxdWVyeT17ZGV0YWlsfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57ZGV0YWlsLmRhdGEgJiYgPFN1cmZhY2VDb250ZW50PjxEZXRhaWxMaW5lIGxhYmVsPVwiTcOjXCI+e2RldGFpbC5kYXRhLmRhdGEuaWR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQuG7mSBk4buvIGxp4buHdVwiPntkZXRhaWwuZGF0YS5kYXRhLmRhdGFzZXRWZXJzaW9ufTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkLhuqNuIGPhuqV1IGjDrG5oXCI+e2RldGFpbC5kYXRhLmRhdGEuY29uZmlnUmV2aXNpb259PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiS+G6v3QgcXXhuqNcIj48U3RhdHVzIHZhbHVlPXtkZXRhaWwuZGF0YS5kYXRhLnN0YXR1c30vPjwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlPhu5EgY2FcIj57ZGV0YWlsLmRhdGEuZGF0YS5wYXNzZWRDYXNlc30gLyB7ZGV0YWlsLmRhdGEuZGF0YS50b3RhbENhc2VzfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkzhu5dpIHRy4buNbmcgeeG6v3VcIj57ZGV0YWlsLmRhdGEuZGF0YS5jcml0aWNhbEZhaWx1cmVzfTwvRGV0YWlsTGluZT57ZGV0YWlsLmRhdGEuZGF0YS5yZXBvcnRKb2JJZCAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7ZGV0YWlsLmRhdGEuZGF0YS5yZXBvcnRKb2JJZH1gfT5Cw6FvIGPDoW8gY2hpIHRp4bq/dDwvUm91dGVMaW5rPn08L1N1cmZhY2VDb250ZW50Pn08L1F1ZXJ5U3RhdGU+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG5jb25zdCByb2xlTmFtZXMgPSB7IHNhbGVzX2FkbWluOiAnQWRtaW4gYsOhbiBow6BuZycsIGFjY291bnRhbnQ6ICdL4bq/IHRvw6FuJywgd2FyZWhvdXNlX2J1eWVyOiAnS2hvICYgbXVhIGjDoG5nJywgc3VwZXJ2aXNvcjogJ1RyxrDhu59uZyBuaMOzbScgfTtcclxuZXhwb3J0IGZ1bmN0aW9uIEFnZW50VGVhbVBhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCByb2xlcyA9IHVzZUFwaSgnbGlzdEFnZW50Um9sZXMnKTtcclxuICAgIGNvbnN0IGJ1ZGdldHMgPSB1c2VBcGkoJ2xpc3RCdWRnZXRQb2xpY2llcycpO1xyXG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlQWdlbnRSb2xlJywgWydsaXN0QWdlbnRSb2xlcycsICdnZXRPcGVyYXRpb25zU3VtbWFyeSddKTtcclxuICAgIGNvbnN0IGNvbnRyb2wgPSB1c2VDb21tYW5kKCdjb250cm9sQXV0b21hdGlvbicsIFsnbGlzdEFnZW50Um9sZXMnLCAnZ2V0Qm90Q29uZmlnJywgJ2dldE9wZXJhdGlvbnNTdW1tYXJ5J10pO1xyXG4gICAgY29uc3QgYnVkZ2V0VXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlQnVkZ2V0UG9saWN5JywgWydsaXN0QnVkZ2V0UG9saWNpZXMnXSk7XHJcbiAgICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxBZ2VudFJvbGUgfCBudWxsPihudWxsKSwgW293bmVyLCBzZXRPd25lcl0gPSB1c2VTdGF0ZSgnJyksIFtjb25uZWN0aW9uLCBzZXRDb25uZWN0aW9uXSA9IHVzZVN0YXRlKCcnKSwgW3BvbGljeSwgc2V0UG9saWN5XSA9IHVzZVN0YXRlKCcnKSwgW3N0b3AsIHNldFN0b3BdID0gdXNlU3RhdGU8e1xyXG4gICAgICAgIHJvbGU6IEFnZW50Um9sZTtcclxuICAgICAgICBhY3Rpb246ICdwYXVzZScgfCAncmVzdW1lJztcclxuICAgIH0gfCBudWxsPihudWxsKSwgW2J1ZGdldCwgc2V0QnVkZ2V0XSA9IHVzZVN0YXRlPEJ1ZGdldFBvbGljeSB8IG51bGw+KG51bGwpLCBbYW1vdW50LCBzZXRBbW91bnRdID0gdXNlU3RhdGUoJycpLCBbYXBwcm92YWwsIHNldEFwcHJvdmFsXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwixJDhu5lpIG5nxakgQUlcIiBzdWJ0aXRsZT1cIkLhu5FuIHZhaSB0csOyIHRyw6puIGPDuW5nIG7hu4FuIMSRaeG7gXUgcGjhu5FpLCBxdXnhu4FuIHbDoCBuZ8aw4budaSBjaOG7i3UgdHLDoWNoIG5oaeG7h20gcsO1IHLDoG5nLlwiLz48UXVlcnlTdGF0ZSBxdWVyeT17cm9sZXN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPjxTZWN0aW9uR3JpZCBjb2x1bW5zPXt7IHhzOiAnMWZyJywgbWQ6ICdyZXBlYXQoMiwxZnIpJyB9fT57cm9sZXMuZGF0YT8uZGF0YS5tYXAociA9PiA8UGFuZWwga2V5PXtyLmlkfSB0aXRsZT17cm9sZU5hbWVzW3Iua2luZF19IGFjdGlvbj17PFN0YXR1cyB2YWx1ZT17ci5zdGF0dXN9Lz59IGJvZHlNb2RlPVwiaW5zZXRcIj48Qm94PjxEZXRhaWxMaW5lIGxhYmVsPVwiTmfGsOG7nWkgY2jhu4t1IHRyw6FjaCBuaGnhu4dtXCI+e3IuaHVtYW5Pd25lcklkID8gYE3DoyBuaMOibiBz4buxOiAke3IuaHVtYW5Pd25lcklkfWAgOiAnQ2jGsGEgZ2lhbyd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQ2jDrW5oIHPDoWNoXCI+e3IucG9saWN5VmVyc2lvbn08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJUaOG6vyBo4buHIHTDoWMgduG7pVwiPntyLmdlbmVyYXRpb259PC9EZXRhaWxMaW5lPjxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBzeD17W2xheW91dFN4LmNvZGUuaW5saW5lR2FwLCBsYXlvdXRTeC5zdXJmYWNlLnNlY3Rpb25CZWZvcmUsIGxheW91dFN4Lm5vdGljZS5hZnRlckdhcCwgeyBmbGV4V3JhcDogJ3dyYXAnIH1dfT57ci5hbGxvd2VkVG9vbElkcy5tYXAodG9vbCA9PiA8Q2hpcCBrZXk9e3Rvb2x9IGxhYmVsPXt0b29sfS8+KX08L1N0YWNrPjxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiA+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJib3QuY29uZmlndXJlXCIgb25DbGljaz17KCkgPT4geyBzZXRFZGl0aW5nKHIpOyBzZXRPd25lcihyLmh1bWFuT3duZXJJZCB8fCAnJyk7IHNldENvbm5lY3Rpb24oci5tb2RlbENvbm5lY3Rpb25JZCB8fCAnJyk7IHNldFBvbGljeShyLnBvbGljeVZlcnNpb24pOyB9fT5QaMOibiBjw7RuZzwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJib3QucGF1c2VcIiBjb2xvcj17ci5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ3ByaW1hcnknIDogJ2Vycm9yJ30gb25DbGljaz17KCkgPT4gc2V0U3RvcCh7IHJvbGU6IHIsIGFjdGlvbjogci5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ3Jlc3VtZScgOiAncGF1c2UnIH0pfT57ci5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ8SQ4buBIG5naOG7iyB0aeG6v3AgdOG7pWMnIDogJ1ThuqFtIGThu6tuZyd9PC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPjwvQm94PjwvUGFuZWw+KX08L1NlY3Rpb25HcmlkPjwvUXVlcnlTdGF0ZT48UGFuZWwgdGl0bGU9XCJOZ8OibiBzw6FjaCDEkcaw4bujYyBnaWFvXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e2J1ZGdldHN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPjxEYXRhVGFibGUgbGFiZWw9XCJI4bqhbiBt4bupYyBj4bunYSDEkeG7mWkgbmfFqSBBSVwiIHJvd3M9e2J1ZGdldHMuZGF0YT8uZGF0YSB8fCBbXX0gcm93S2V5PXtiID0+IGIuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ2tpbmQnLCBsYWJlbDogJ0xv4bqhaScsIHJlbmRlcjogYiA9PiBiLmtpbmQgfSwgeyBrZXk6ICdsaW1pdCcsIGxhYmVsOiAnR2nhu5tpIGjhuqFuJywgcmVuZGVyOiBiID0+IDxBbW91bnQgdmFsdWU9e2IubGltaXRBbW91bnR9Lz4gfSwgeyBrZXk6ICd1c2VkJywgbGFiZWw6ICfEkMOjIGTDuW5nJywgcmVuZGVyOiBiID0+IDxBbW91bnQgdmFsdWU9e2IuY29uc3VtZWR9Lz4gfSwgeyBrZXk6ICdyZXNlcnZlZCcsIGxhYmVsOiAnxJDDoyBjYW0ga+G6v3QnLCByZW5kZXI6IGIgPT4gPEFtb3VudCB2YWx1ZT17Yi5yZXNlcnZlZH0vPiB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICfDgXAgZOG7pW5nJywgcmVuZGVyOiBiID0+IGIuZW5hYmxlZCA/ICfEkMOjIGLhuq10JyA6ICdDaMawYSBi4bqtdCcgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiBiID0+IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwib3BlcmF0aW9ucy5tYW5hZ2VcIiBvbkNsaWNrPXsoKSA9PiB7IHNldEJ1ZGdldChiKTsgc2V0QW1vdW50KGIubGltaXRBbW91bnQ/LmFtb3VudCB8fCAnJyk7IHNldEFwcHJvdmFsKCcnKTsgfX0+xJDhu5VpIGPDsyBwaMOqIGR1eeG7h3Q8L011dGF0aW9uQnV0dG9uPlxyXG4gICAgICAgIH1cclxuICAgIF19Lz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cclxuIDxQYW5lbCB0aXRsZT1cIkNoaSBwaMOtIEFJICYgZOG7sSBwaMOybmcgbmjDoCBjdW5nIGPhuqVwXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0gYm9keU1vZGU9XCJpbnNldFwiPlxyXG4gICAgPFN1cmZhY2VDb250ZW50ICBkYXRhLXRlc3RpZD1cInByb3ZpZGVyLWZhaWxvdmVyLXByZXZpZXdcIj5cclxuICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+Q2hpIHBow60gdHJvbmcgcGjDsm5nIHRo4butIGzDoCDGsOG7m2MgdMOtbmggbcO0IHBo4buPbmcuIENo4buJIGTDuW5nIHByb3ZpZGVyIGThu7EgcGjDsm5nIMSRw6MgxJHGsOG7o2MgcGjDqiBkdXnhu4d0OyBkZW1vIGtow7RuZyBjaHV54buDbiBk4buvIGxp4buHdSBraMOhY2ggc2FuZyBwcm92aWRlciBraMOhYy48L0FsZXJ0PlxyXG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiTmfDom4gc8OhY2ggdG9rZW4gLyBrw6puaFwiPlRoZW8gY2jDrW5oIHPDoWNoIHbDoCBo4bqhbiBt4bupYyBkbyBo4buHIHRo4buRbmcgdHLhuqMgduG7gTsga2jDtG5nIGTDuW5nIGNodW5nIHbhu5tpIG5nw6JuIHPDoWNoIG11YSBow6BuZy48L0RldGFpbExpbmU+XHJcbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJQcm92aWRlciBk4buxIHBow7JuZ1wiPkNoxrBhIGPDsyB0cuG6oW5nIHRow6FpIGZhaWxvdmVyIMSRxrDhu6NjIHjDoWMgbWluaCB0cm9uZyBk4buvIGxp4buHdSBmcm9udGVuZC48L0RldGFpbExpbmU+XHJcbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLaGkgaOG6v3QgaOG6oW4gbeG7qWNcIj5E4burbmcgY8OidSB0cuG6oyBs4budaSB04buxIMSR4buZbmcgdsOgIGNodXnhu4NuIG5ow6JuIHZpw6puIHjhu60gbMO9OyBraMO0bmcgw6JtIHRo4bqnbSDEkeG7lWkgcHJvdmlkZXIuPC9EZXRhaWxMaW5lPlxyXG4gICAgPC9TdXJmYWNlQ29udGVudD5cclxuIDwvUGFuZWw+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXshIWVkaXRpbmd9IHRpdGxlPVwiR2lhbyB0csOhY2ggbmhp4buHbSB2w6AgY+G6pXUgaMOsbmggdmFpIHRyw7JcIiBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nKG51bGwpfSBidXN5PXt1cGRhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFvd25lciB8fCAhY29ubmVjdGlvbiB8fCAhcG9saWN5IHx8IHVwZGF0ZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IGVkaXRpbmc/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBlZGl0aW5nPy52ZXJzaW9uIHx8IDEsIGh1bWFuT3duZXJJZDogb3duZXIsIG1vZGVsQ29ubmVjdGlvbklkOiBjb25uZWN0aW9uLCBwb2xpY3lWZXJzaW9uOiBwb2xpY3kgfSB9KTtcclxuICAgICAgICBzZXRFZGl0aW5nKG51bGwpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+TMawdSBwaMOibiBjw7RuZzwvQnV0dG9uPn0+PEVycm9yTm90aWNlIGVycm9yPXt1cGRhdGUuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+PFRleHRGaWVsZCBsYWJlbD1cIk3DoyBuaMOibiBz4buxIGNo4buLdSB0csOhY2ggbmhp4buHbVwiIHZhbHVlPXtvd25lcn0gb25DaGFuZ2U9e2UgPT4gc2V0T3duZXIoZS50YXJnZXQudmFsdWUpfS8+PFRleHRGaWVsZCBsYWJlbD1cIk3DoyBr4bq/dCBu4buRaSBBSVwiIHZhbHVlPXtjb25uZWN0aW9ufSBvbkNoYW5nZT17ZSA9PiBzZXRDb25uZWN0aW9uKGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJQaGnDqm4gYuG6o24gY2jDrW5oIHPDoWNoIMSRw6MgZHV54buHdFwiIHZhbHVlPXtwb2xpY3l9IG9uQ2hhbmdlPXtlID0+IHNldFBvbGljeShlLnRhcmdldC52YWx1ZSl9Lz48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+Q8O0bmcgY+G7pSDEkcaw4bujYyBwaMOpcCBkbyBiYWNrZW5kIHRy4bqjIHbhu4E7IGtow7RuZyBz4butYSBxdXnhu4FuIHF1YSBwcm9tcHQuPC9BbGVydD48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPlxyXG4gPENvbmZpcm1EaWFsb2cgb3Blbj17ISFzdG9wfSB0aXRsZT17c3RvcD8uYWN0aW9uID09PSAncGF1c2UnID8gJ1ThuqFtIGThu6tuZyB2YWkgdHLDsicgOiAnS2nhu4NtIMSRaeG7gXUga2nhu4duIMSR4buDIHRp4bq/cCB04bulYyd9IGNvbmZpcm1MYWJlbD17c3RvcD8uYWN0aW9uID09PSBcInBhdXNlXCIgPyBcIlThuqFtIGThu6tuZyB2YWkgdHLDslwiIDogXCJLaeG7g20gdHJhIMSR4buDIHRp4bq/cCB04bulY1wifSBkZXNjcmlwdGlvbj17YCR7c3RvcCA/IHJvbGVOYW1lc1tzdG9wLnJvbGUua2luZF0gOiBcIlwifSAoJHtzdG9wPy5yb2xlLmlkIHx8IFwiXCJ9KSB0cm9uZyAke3Nob3AubmFtZX06ICR7c3RvcD8uYWN0aW9uID09PSBcInBhdXNlXCIgPyBcInThuqFtIGThu6tuZyB0w6FjIMSR4buZbmcgY2jGsGEgxJHGsOG7o2MgdGnhur9wIG5o4bqtbi5cIiA6IFwia2nhu4NtIHRo4bq/IGjhu4cgdMOhYyB24bulIHbDoCBjaMOtbmggc8OhY2ggdHLGsOG7m2MgdMOhYyDEkeG7mW5nIG3hu5tpLlwifSBLaMO0bmcgdGh1IGjhu5NpIMSRxrDhu6NjIHTDoWMgxJHhu5luZyDEkcOjIMSRxrDhu6NjIGThu4tjaCB24bulIG5nb8OgaSBuaOG6rW4uYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRTdG9wKG51bGwpfSBlcnJvcj17Y29udHJvbC5lcnJvcn0gYnVzeT17Y29udHJvbC5wZW5kaW5nfSBvbkNvbmZpcm09e3JlYXNvbiA9PiBjb250cm9sLmV4ZWN1dGUoeyBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc3RvcD8ucm9sZS52ZXJzaW9uIHx8IDEsIHNjb3BlOiAncm9sZScsIHJlc291cmNlSWQ6IHN0b3A/LnJvbGUuaWQgfHwgbnVsbCwgYWN0aW9uOiBzdG9wPy5hY3Rpb24gfHwgJ3BhdXNlJywgcmVhc29uIH0gfSl9Lz5cclxuIDxFZGl0RGlhbG9nIG9wZW49eyEhYnVkZ2V0fSB0aXRsZT1cIsSQ4buVaSBnaeG7m2kgaOG6oW4gxJHGsOG7o2MgZHV54buHdFwiIG9uQ2xvc2U9eygpID0+IHNldEJ1ZGdldChudWxsKX0gYnVzeT17YnVkZ2V0VXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshYW1vdW50IHx8ICFhcHByb3ZhbCB8fCBidWRnZXRVcGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xyXG4gICAgICAgIGF3YWl0IGJ1ZGdldFVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBidWRnZXQ/LmlkIHx8ICcnIH0sIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgIGV4cGVjdGVkVmVyc2lvbjogYnVkZ2V0Py52ZXJzaW9uIHx8IDEsIGxpbWl0QW1vdW50OiB7IGFtb3VudCwgY3VycmVuY3k6IHNob3AuY3VycmVuY3kgfSwgcGVyaW9kOiBidWRnZXQ/LnBlcmlvZCB8fCAnZGFpbHknLCBhcHByb3ZhbElkOiBhcHByb3ZhbFxyXG4gICAgICAgICAgICB9IH0pO1xyXG4gICAgICAgIHNldEJ1ZGdldChudWxsKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PsOBcCBk4bulbmcgZ2nhu5tpIGjhuqFuPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2J1ZGdldFVwZGF0ZS5lcnJvcn0vPjxGb3JtRmllbGRzID48VGV4dEZpZWxkIGxhYmVsPXtgR2nhu5tpIGjhuqFuICgke3Nob3AuY3VycmVuY3l9KWB9IHZhbHVlPXthbW91bnR9IG9uQ2hhbmdlPXtlID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHBow6ogZHV54buHdCDEkcO6bmcgbuG7mWkgZHVuZ1wiIHZhbHVlPXthcHByb3ZhbH0gb25DaGFuZ2U9e2UgPT4gc2V0QXBwcm92YWwoZS50YXJnZXQudmFsdWUpfS8+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48Lz47XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvZXZpZGVuY2UvZnJvbnRlbmQtY29tcGxldGVuZXNzLTIwMjYxMDEzLWFhZjc0YjcvY2xlYW4taW5zdGFsbC1yMi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2JvdC9pbmRleC50c3gifQ==