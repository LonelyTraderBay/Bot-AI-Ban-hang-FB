import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/workspace/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/react_jsx-dev-runtime.js?v=38e1174f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s0 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import { ActionGroup, FieldGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport5_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/react.js?v=38e1174f"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useRef = __vite__cjsImport5_react["useRef"]; const useState = __vite__cjsImport5_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Link as RouterLink, Navigate, useLocation, useNavigate, useParams, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/react-router-dom.js?v=e14569da";
import { useQuery, useQueryClient } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/@tanstack_react-query.js?v=aef6dd1e";
import { Alert, Avatar, Box, Button, Checkbox, FormControlLabel, MenuItem, Paper, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/@mui_material.js?v=e6a33dc3";
import SmartToyRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/@mui_icons-material_SmartToyRounded.js?v=60b54a62";
import ArrowForwardRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-140b3938-c0f9-4144-8a40-dcc50973b16f/deps/@mui_icons-material_ArrowForwardRounded.js?v=f0a82d94";
import { permissionCatalog } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/packages/contracts/src/index.ts";
import { colors } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { request, setCsrfToken } from "/src/shared/api/client.ts";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { ApiError } from "/src/shared/api/errors.ts";
import { assertSchema } from "/src/shared/api/validation.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { codePointLength, limitCodePoints, dateTime, safeInternalPath, isValidTimeZone } from "/src/shared/model/format.ts";
import { authorizedDownloadHref } from "/src/shared/model/download.ts";
import { useListQuery } from "/src/shared/model/filters.ts";
import { markDraftClean, useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { PageHeader, Panel, QueryState, DataTable, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine, LookupLoadMore, Empty } from "/src/shared/ui/components.tsx";
import { useSession } from "/src/shared/model/auth.ts";
function AuthCard({
  children
}) {
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.centeredFallback, { bgcolor: "background.default", outline: "none" }], children: /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: [layoutSx.auth.surfaceInset, { width: "100%", maxWidth: 520, borderRadius: visualSx.radius.hero }], children: [
    /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: layoutSx.auth.brandMarkGap, children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: "primary.main", color: colors.onAccent }, children: /* @__PURE__ */ jsxDEV(SmartToyRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 451
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 386
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: visualSx.typography.fontWeight.extraBold, children: [
        "BotSales ",
        /* @__PURE__ */ jsxDEV(Box, { component: "span", color: "primary.main", children: "AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 49,
          columnNumber: 567
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 479
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 49,
      columnNumber: 311
    }, this),
    children
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 49,
    columnNumber: 181
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 49,
    columnNumber: 36
  }, this);
}
_c = AuthCard;
export function LoginPage() {
  _s();
  const { session, loading } = useSession();
  const [params] = useSearchParams();
  const [pending, setPending] = useState(false), [error, setError] = useState(null);
  const login = async () => {
    setPending(true);
    setError(null);
    try {
      const csrf = await request("getCsrfToken");
      setCsrfToken(csrf.data.csrfToken);
      const auth = await request("beginLogin", { body: { returnTo: safeInternalPath(params.get("returnTo") || "/workspaces") } });
      const url = new URL(auth.data.authorizationUrl);
      if (url.protocol !== "https:" && !(__MOCK__ && url.origin === location.origin))
        throw new Error("Địa chỉ đăng nhập không an toàn.");
      window.location.assign(url.href);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không bắt đầu được đăng nhập"));
      setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: layoutSx.auth.brandTitleGap, children: "Chào mừng trở lại" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: [layoutSx.pageHeader.titleDescriptionGap, layoutSx.pageHeader.afterGap], children: "Một không gian cho bán hàng, kho, kế toán và đội ngũ AI của bạn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 123
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 312
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.pageHeader.afterGap, children: "Chế độ xem frontend: tài khoản giả lập, không có mật khẩu thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 354
    }, this),
    session ? /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, component: RouterLink, to: "/workspaces", variant: "contained", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 581
    }, this), children: "Tiếp tục vào cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 494
    }, this) : /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, variant: "contained", size: "large", onClick: () => void login(), disabled: pending || loading, children: pending ? "Đang chuyển đến đăng nhập…" : __MOCK__ ? "Vào tài khoản mô phỏng" : "Đăng nhập bằng tài khoản công ty" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 639
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: [layoutSx.page.sectionBefore, { display: "block" }], children: "Phiên đăng nhập được quản lý ở máy chủ. Không lưu access token trong localStorage." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 874
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 67,
    columnNumber: 10
  }, this);
}
_s(LoginPage, "tICyXXnoQDGPm2VsFQW+6n6svQk=", false, function() {
  return [useSession, useSearchParams];
});
_c2 = LoginPage;
export function WorkspacesPage() {
  _s2();
  const { session, loading, error: sessionError } = useSession();
  const shops = useQuery({ queryKey: ["shops", session?.user.id], queryFn: ({ signal }) => request("listShops", { signal }), enabled: !!session, retry: false });
  const isEmpty = !shops.isError && shops.data?.data.length === 0;
  const createShopButton = /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/onboarding", variant: "contained", children: "Tạo cửa hàng" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 73,
    columnNumber: 28
  }, this);
  if (!loading && !session && sessionError instanceof ApiError && sessionError.status === 401)
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 75,
      columnNumber: 10
    }, this);
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.pageFallbackInset, { maxWidth: 1100, mx: "auto", outline: "none" }], children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Chọn cửa hàng", subtitle: "Mỗi cửa hàng là một vùng dữ liệu và quyền độc lập.", actions: !isEmpty && createShopButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 153
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: sessionError }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 290
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: shops, pendingProfile: "section", children: isEmpty ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có cửa hàng.", action: createShopButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 388
    }, this) : /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "minmax(0, 1fr)", md: shops.data?.data.length === 1 ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))" }, children: shops.data?.data.map((s) => /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: [layoutSx.surface.inset, { borderRadius: visualSx.radius.large }], children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: colors.selected, color: "primary.main" }, children: s.name[0] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 720
      }, this),
      /* @__PURE__ */ jsxDEV(SurfaceContent, { beforeGap: "surface", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", children: s.name }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 841
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: [
          s.currency,
          " · ",
          s.timezone
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 887
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Quyền: ",
          session?.memberships.find((m) => m.shopId === s.id)?.roles.map((role) => businessLabel(role)).join(", ") || "Chưa có quyền"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 962
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 805
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: `/s/${s.id}/overview`, fullWidth: true, variant: "outlined", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 1273
      }, this), sx: layoutSx.page.sectionBefore, children: "Mở cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 1177
      }, this)
    ] }, s.id, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 612
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 451
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 326
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 76,
    columnNumber: 10
  }, this);
}
_s2(WorkspacesPage, "9VKV6RNilsXVUNYTqRFP3NwfT3I=", false, function() {
  return [useSession, useQuery];
});
_c3 = WorkspacesPage;
export function OnboardingPage() {
  _s3();
  const navigate = useNavigate();
  const { refresh } = useSession();
  const cache = useQueryClient();
  const [name, setName] = useState(""), [currency, setCurrency] = useState("VND"), [timezone, setTimezone] = useState("Asia/Vientiane"), [pending, setPending] = useState(false), [error, setError] = useState(null), [timezoneTouched, setTimezoneTouched] = useState(false), [submitted, setSubmitted] = useState(false);
  const formElement = useRef(null);
  const baseline = useRef({ name: "", currency: "VND", timezone: "Asia/Vientiane" });
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const bindDraft = useDraftForm(name !== baseline.current.name || currency !== baseline.current.currency || timezone !== baseline.current.timezone);
  const timezoneError = !isValidTimeZone(timezone) ? "Nhập múi giờ hợp lệ, ví dụ Asia/Vientiane." : "";
  const save = async () => {
    setSubmitted(true);
    if (pending || !name.trim() || timezoneError) return;
    setPending(true);
    setError(null);
    try {
      const r = await request("createShop", { body: { name, currency, timezone, locale: "vi-VN" } });
      await refresh();
      await cache.invalidateQueries({ queryKey: ["shops"] });
      if (!mounted.current) return;
      baseline.current = { name, currency, timezone };
      if (formElement.current) markDraftClean(formElement.current);
      navigate(`/s/${r.data.id}/overview`);
    } catch (e) {
      if (mounted.current) setError(e instanceof Error ? e : new Error("Không tạo được cửa hàng"));
    } finally {
      if (mounted.current) setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: layoutSx.auth.brandTitleGap, children: "Tạo cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: [layoutSx.pageHeader.titleDescriptionGap, layoutSx.pageHeader.afterGap], children: "Chọn tiền tệ cơ sở trước khi ghi nhận giao dịch." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 118
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 291
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { component: "form", noValidate: true, ref: (element) => {
      formElement.current = element;
      bindDraft(element);
    }, onSubmit: (event) => {
      event.preventDefault();
      void save();
    }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Tên cửa hàng", value: name, onChange: (e) => setName(limitCodePoints(e.target.value, 160)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 491
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Tiền tệ cơ sở", select: true, value: currency, onChange: (e) => setCurrency(e.target.value), children: ["VND", "LAK", "THB", "USD"].map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c, children: c }, c, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 784
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 621
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Múi giờ", value: timezone, onBlur: () => setTimezoneTouched(true), onChange: (e) => setTimezone(e.target.value), error: (timezoneTouched || submitted) && !!timezoneError, helperText: (timezoneTouched || submitted) && timezoneError ? timezoneError : "Ví dụ: Asia/Vientiane" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 840
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giao diện Graphite Gold dark-only đã chốt. Những chính sách thật và kết nối ngoài chưa tự bật khi tạo shop." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1152
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", disabled: !name.trim() || pending, children: "Tạo cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1290
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/workspaces", children: "Quay lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1388
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 320
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 104,
    columnNumber: 10
  }, this);
}
_s3(OnboardingPage, "+O2BjTy3yRtrAgt9iSgKUSEAFUI=", false, function() {
  return [useNavigate, useSession, useQueryClient, useDraftForm];
});
_c4 = OnboardingPage;
export function ShopSettingsPage() {
  _s4();
  const scope = useScope();
  const { shop } = scope;
  const cache = useQueryClient();
  const canManageShop = useCan("shop.manage");
  const update = useCommand("updateShop", ["getShop"]);
  const [name, setName] = useState(shop.name), [timezone, setTimezone] = useState(shop.timezone), [locale, setLocale] = useState(shop.locale), [error, setError] = useState(null), [saved, setSaved] = useState(false), [timezoneTouched, setTimezoneTouched] = useState(false), [settingsSubmitted, setSettingsSubmitted] = useState(false);
  const latestShop = useApi("getShop");
  const currentShop = latestShop.data && latestShop.data.data.version >= shop.version ? latestShop.data.data : shop;
  const editor = useVersionedDraft({
    identity: `${shop.id}:settings`,
    source: { version: currentShop.version, values: { name: currentShop.name, timezone: currentShop.timezone, locale: currentShop.locale } },
    draft: { name, timezone, locale },
    apply: (values) => {
      setName(values.name);
      setTimezone(values.timezone);
      setLocale(values.locale);
    },
    refresh: () => latestShop.refetch({ throwOnError: true })
  });
  const formRef = useDraftForm(editor.dirty);
  const timezoneError = !isValidTimeZone(timezone) ? "Nhập múi giờ hợp lệ, ví dụ Asia/Vientiane." : "";
  const save = async () => {
    setSettingsSubmitted(true);
    if (!name.trim() || timezoneError) return;
    setError(null);
    setSaved(false);
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { name, timezone, locale };
    try {
      const result = await update.execute({ path: { shopId: shop.id }, version: prepared.version, body: prepared.patch });
      cache.setQueryData(["shop", scope.session.user.id, shop.id, scope.membership.permissionVersion], result);
      editor.committed({ version: result.data.version, values: { name: result.data.name, timezone: result.data.timezone, locale: result.data.locale } }, submitted);
      setSaved(true);
    } catch (error2) {
      editor.failed(error2);
      setError(error2 instanceof Error ? error2 : new Error("Không lưu được cấu hình"));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thiết lập cửa hàng", subtitle: "Cấu hình riêng của shop không thay đổi quy tắc AI lập trình hoặc màu đã duyệt." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Thông tin cơ sở", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: formRef, noValidate: true, onSubmit: (event) => {
        event.preventDefault();
        void save();
      }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || update.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 144,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { name: "Tên cửa hàng", timezone: "Múi giờ", locale: "Ngôn ngữ" }, busy: update.pending }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 145,
          columnNumber: 21
        }, this),
        saved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã lưu cấu hình cửa hàng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 146,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tên cửa hàng", value: name, disabled: !canManageShop, onChange: (event) => {
            setName(event.target.value);
            setSaved(false);
          }, sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 148,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tiền tệ cơ sở", value: shop.currency, disabled: true, helperText: "Không đổi tiền tệ bằng sửa giao diện. Cần kế hoạch chuyển đổi dữ liệu.", sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 149,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 147,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Múi giờ", value: timezone, disabled: !canManageShop, onBlur: () => setTimezoneTouched(true), onChange: (event) => {
            setTimezone(event.target.value);
            setSaved(false);
          }, error: (timezoneTouched || settingsSubmitted) && !!timezoneError, helperText: (timezoneTouched || settingsSubmitted) && timezoneError ? timezoneError : "Áp dụng cho ngày giờ theo cửa hàng.", sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 152,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Ngôn ngữ giao diện", value: "Tiếng Việt", disabled: true, helperText: `Giao diện hiện chỉ hỗ trợ tiếng Việt. Locale lưu trong API: ${locale}.`, sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 153,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 151,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao diện", value: "Graphite Gold · Dark-only", disabled: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 155,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "shop.manage", type: "submit", variant: "contained", busy: update.pending, disabled: !canManageShop || !editor.dirty || update.pending, children: "Lưu cấu hình" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 156,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 143,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 142,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Checklist thiết lập vận hành", subtitle: "Các mục không có trường API được giữ ở trạng thái chưa xác minh; không suy diễn đã sẵn sàng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.surface.compactContentGap, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          __MOCK__ ? "Bản xem trước mô phỏng. Chỉ tên, tiền tệ, múi giờ và ngôn ngữ được lưu qua API hiện tại." : "API hiện chỉ cho phép sửa thông tin cơ sở được hỗ trợ.",
          " Quốc gia kinh doanh không được suy ra từ múi giờ."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Quốc gia và giờ kinh doanh", status: "Chưa có trường cấu hình trong contract" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 162,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Địa chỉ, vùng giao và phí vận chuyển", status: __MOCK__ ? "Có preview mô phỏng, chưa lưu cấu hình" : "Chưa có operation cấu hình vùng giao", to: `/s/${shop.id}/shipments`, action: "Xem preview phí giao" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 163,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Người duyệt và thành viên", status: "Quyền lấy từ membership; chưa có API gán chính sách duyệt", to: `/s/${shop.id}/settings/team`, action: "Quản lý thành viên" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 164,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối kênh bán hàng", status: __MOCK__ ? "Kết nối mô phỏng; không có quyền provider thật" : "Kiểm tra trạng thái kết nối", to: `/s/${shop.id}/integrations/channels`, action: "Mở kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 165,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối AI", status: __MOCK__ ? "Catalog nhà cung cấp mô phỏng" : "Kiểm tra catalog nhà cung cấp", to: `/s/${shop.id}/integrations/ai`, action: "Mở nhà cung cấp AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 166,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Nội dung sản phẩm và phiên bản kiến thức", status: "Nguồn nội dung, lịch sử phiên bản và duyệt nằm trong khu vực kiến thức.", to: `/s/${shop.id}/knowledge`, action: "Quản lý nội dung" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 167,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Vòng góp ý có duyệt", status: "Góp ý tạo bản nháp; không tự huấn luyện hoặc xuất bản.", to: `/s/${shop.id}/knowledge/review`, action: "Duyệt góp ý" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 168,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Consent và ngừng liên hệ marketing", status: "Có bản ghi consent, lịch sử và luồng xác nhận challenge; gửi qua nhà cung cấp chưa kết nối.", to: `/s/${shop.id}/settings/privacy`, action: "Quản lý consent" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 169,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 160,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 159,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 139,
    columnNumber: 10
  }, this);
}
_s4(ShopSettingsPage, "pjSWA3i3YfXp4xheEW2BgOwAgnQ=", false, function() {
  return [useScope, useQueryClient, useCan, useCommand, useApi, useVersionedDraft, useDraftForm];
});
_c5 = ShopSettingsPage;
function SetupChecklistItem({ title, status, to, action }) {
  return /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactControlOutlined", direction: "row", alignItems: { xs: "flex-start", md: "center" }, justifyContent: "space-between", flexWrap: "wrap", children: [
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: title }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 177,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 177,
        columnNumber: 97
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 177,
      columnNumber: 9
    }, this),
    to && action && /* @__PURE__ */ jsxDEV(RouteLink, { to, children: action }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 178,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 176,
    columnNumber: 10
  }, this);
}
_c6 = SetupChecklistItem;
const roleLabels = {
  owner: "Chủ cửa hàng",
  manager: "Quản lý",
  sales: "Bán hàng",
  warehouse: "Nhân viên kho",
  accountant: "Kế toán",
  bot_admin: "Quản trị AI",
  viewer: "Chỉ xem"
};
export function TeamPage() {
  _s5();
  const { session, shop } = useScope();
  const list = useApi("listMembers", { query: useListQuery("listMembers") });
  const [memberId, setMemberId] = useState("");
  const detail = useApi("getMember", { path: { memberId } }, Boolean(memberId));
  const invite = useCommand("inviteMember", ["listMembers"]);
  const update = useCommand("updateMemberRoles", ["listMembers", "getMember"]);
  const revoke = useCommand("revokeMembership", ["listMembers", "getMember"]);
  const [edit, setEdit] = useState(), [email, setEmail] = useState(""), [roles, setRoles] = useState(["viewer"]), [remove, setRemove] = useState(null), [savedMessage, setSavedMessage] = useState("");
  const open = (m) => {
    setSavedMessage("");
    setEdit(m);
    setEmail("");
    setRoles(m?.roles || ["viewer"]);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhân sự & phân quyền", subtitle: "Vai trò là bộ quyền mặc định; API quyết định quyền hiệu lực ở từng thao tác.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", variant: "contained", onClick: () => open(null), children: "Mời nhân viên" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 194,
      columnNumber: 150
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 194,
      columnNumber: 12
    }, this),
    savedMessage && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", sx: layoutSx.notice.afterGap, children: savedMessage }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 194,
      columnNumber: 292
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listMembers" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 194,
        columnNumber: 392
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Nhân sự và quyền truy cập", rows: list.data.data, rowKey: (m) => m.id, columns: [
          { key: "user", label: "Nhân viên", render: (m) => m.userId === session.user.id ? session.user.displayName : `Mã nhân sự: ${m.userId}` },
          { key: "roles", label: "Vai trò", render: (m) => m.roles.map((r) => roleLabels[r]).join(", ") },
          { key: "status", label: "Trạng thái", render: (m) => /* @__PURE__ */ jsxDEV(Status, { value: m.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 195,
            columnNumber: 298
          }, this) },
          { key: "perms", label: "Quyền hiệu lực", render: (m) => `${m.permissions.length} quyền · v${m.permissionVersion}` },
          {
            key: "actions",
            label: "",
            render: (m) => /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
              /* @__PURE__ */ jsxDEV(Button, { onClick: () => setMemberId(m.id), children: "Chi tiết nhân sự" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 197,
                columnNumber: 84
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", onClick: () => open(m), children: "Sửa quyền" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 197,
                columnNumber: 151
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", color: "error", disabled: m.userId === session.user.id || m.status === "revoked", onClick: () => setRemove(m), children: "Thu hồi" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 197,
                columnNumber: 245
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
              lineNumber: 197,
              columnNumber: 55
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 194,
          columnNumber: 493
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 199,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 194,
        columnNumber: 491
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 194,
        columnNumber: 427
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 194,
      columnNumber: 385
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!memberId, title: "Chi tiết nhân sự", onClose: () => setMemberId(""), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setMemberId(""), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 200,
      columnNumber: 98
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, pendingProfile: "section", children: detail.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nhân viên", children: detail.data.data.userId === session.user.id ? session.user.displayName : "Mã nhân sự: " + detail.data.data.userId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 202,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã thành viên", children: detail.data.data.id }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 203,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: detail.data.data.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 203,
        columnNumber: 108
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 203,
        columnNumber: 77
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Vai trò", children: detail.data.data.roles.map((role) => roleLabels[role]).join(", ") }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 204,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản quyền", children: detail.data.data.permissionVersion }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 205,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Quyền hiệu lực", children: detail.data.data.permissions.join(", ") || "Không có quyền" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 205,
        columnNumber: 94
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 201,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 201,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 200,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: edit !== void 0, title: edit ? "Cập nhật quyền" : "Mời nhân viên", onClose: () => setEdit(void 0), busy: invite.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !roles.length || !edit && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || invite.pending || update.pending, onClick: async () => {
      try {
        if (edit) {
          await update.execute({ path: { memberId: edit.id }, version: edit.permissionVersion, body: { roles } });
          setSavedMessage(`Đã cập nhật quyền truy cập của ${edit.userId}.`);
        } else {
          await invite.execute({ body: { email, roles } });
          setSavedMessage(`Đã gửi lời mời đến ${email.trim()}.`);
        }
        setEdit(void 0);
      } catch {
      }
    }, children: "Lưu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 208,
      columnNumber: 174
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: invite.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 218,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        !edit && /* @__PURE__ */ jsxDEV(TextField, { label: "Email nhân viên", type: "email", value: email, onChange: (e) => setEmail(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 218,
          columnNumber: 119
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", children: "Phân vai trò" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 218,
          columnNumber: 227
        }, this),
        Object.keys(roleLabels).map((role) => /* @__PURE__ */ jsxDEV(FormControlLabel, { label: `${roleLabels[role]} · ${permissionCatalog.rolePresets[role]?.length || 0} quyền`, control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: roles.includes(role), onChange: (e) => setRoles(e.target.checked ? [...roles, role] : roles.filter((r) => r !== role)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 218,
          columnNumber: 463
        }, this) }, role, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 218,
          columnNumber: 335
        }, this)),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Quyền mới phải được máy chủ kiểm lại. Thu hồi quyền làm mất hiệu lực cache và phiên truy cập liên quan." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 218,
          columnNumber: 610
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 218,
        columnNumber: 97
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 208,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!remove, title: "Thu hồi quyền nhân viên", confirmLabel: "Thu hồi quyền", description: `Nhân viên ${remove?.userId || ""} trong ${shop.name}: người này không được tiếp tục truy cập dữ liệu cửa hàng sau khi thu hồi. Lịch sử hoạt động được giữ.`, onClose: () => setRemove(null), busy: revoke.pending, error: revoke.error, onConfirm: async () => {
      if (!remove) return;
      await revoke.execute({ path: { memberId: remove.id }, version: remove.permissionVersion });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 218,
      columnNumber: 773
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 194,
    columnNumber: 10
  }, this);
}
_s5(TeamPage, "rHMpo0MAIlCliVWGHjL0PAxlbnk=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand, useCommand, useCommand];
});
_c7 = TeamPage;
export function AuditPage() {
  _s6();
  const { shop } = useScope();
  const list = useApi("listAuditEvents", { query: useListQuery("listAuditEvents") });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhật ký hoạt động", subtitle: "Ai thực hiện, thao tác nào, dữ liệu nào và mã truy vết. Không lưu API key hoặc suy luận riêng của AI." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 223,
      columnNumber: 156
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "API hiện trả về người thực hiện, thao tác, đối tượng, thời gian, mã truy vết và tóm tắt. Loại actor, phiên bản policy/config và snapshot chi tiết chưa có trong DTO nên không được suy đoán." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 223,
      columnNumber: 309
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listAuditEvents" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 223,
        columnNumber: 565
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Nhật ký hoạt động", rows: list.data.data, rowKey: (a) => a.id, columns: [
          { key: "time", label: "Thời gian", render: (a) => dateTime(a.occurredAt, shop.timezone) },
          { key: "actor", label: "Người thực hiện", render: (a) => `Mã nhân sự: ${a.actorId}` },
          { key: "action", label: "Thao tác", render: (a) => a.action },
          { key: "source", label: "Đối tượng", render: (a) => `${a.resource.type} · Mã đối tượng: ${a.resource.id}` },
          { key: "summary", label: "Kết quả", render: (a) => a.summary },
          { key: "trace", label: "Mã truy vết", render: (a) => /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: a.requestId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 224,
            columnNumber: 478
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 223,
          columnNumber: 670
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 225,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 223,
        columnNumber: 668
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 223,
        columnNumber: 604
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 223,
      columnNumber: 558
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 223,
    columnNumber: 154
  }, this);
}
_s6(AuditPage, "Jtgiv7AS0Y0EHZdenzTKkK6QaXU=", false, function() {
  return [useScope, useApi, useListQuery];
});
_c8 = AuditPage;
export function PrivacyPage() {
  _s7();
  const { shop } = useScope();
  const policy = useApi("getPrivacyPolicy");
  const requests = useApi("listPrivacyRequests", { query: useListQuery("listPrivacyRequests") });
  const save = useCommand("updatePrivacyPolicy", ["getPrivacyPolicy"]);
  const create = useCommand("createPrivacyRequest", ["listPrivacyRequests"]);
  const [days, setDays] = useState(""), [note, setNote] = useState(""), [customerId, setCustomer] = useState(""), [kind, setKind] = useState("export"), [reason, setReason] = useState(""), [open, setOpen] = useState(false), [daysTouched, setDaysTouched] = useState(false), [noteTouched, setNoteTouched] = useState(false), [policySubmitted, setPolicySubmitted] = useState(false), [policySaved, setPolicySaved] = useState("");
  const canReadCustomers = useCan("customers.read");
  const [customerSearchInput, setCustomerSearchInput] = useState(""), [customerSearch, setCustomerSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setCustomerSearch(customerSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [customerSearchInput]);
  const customers = usePagedApi("listCustomers", { query: { q: customerSearch || void 0 } }, canReadCustomers);
  const selectedCustomerDetail = useApi("getCustomer", { path: { customerId } }, canReadCustomers && !!customerId);
  const selectedCustomer = customers.data?.data.find((customer) => customer.id === customerId) || selectedCustomerDetail.data?.data;
  const editor = useVersionedDraft({
    identity: `${shop.id}:privacy`,
    source: policy.data ? { version: policy.data.data.version, values: { days: policy.data.data.chatRetentionDays?.toString() || "", note: policy.data.data.jurisdictionNote } } : void 0,
    draft: { days, note },
    apply: (values) => {
      setDays(values.days);
      setNote(values.note);
    },
    refresh: () => policy.refetch({ throwOnError: true })
  });
  const policyForm = useDraftForm(editor.dirty);
  const daysError = !/^\d+$/.test(days) || Number(days) < 1 || Number(days) > 36500 ? "Nhập số nguyên từ 1 đến 36.500 ngày." : "";
  const noteError = codePointLength(note.trim()) < 5 || codePointLength(note) > 2e3 ? "Nhập căn cứ từ 5 đến 2.000 ký tự." : "";
  const showDaysError = (daysTouched || policySubmitted) && !!daysError;
  const showNoteError = (noteTouched || policySubmitted) && !!noteError;
  const savePolicy = async () => {
    setPolicySubmitted(true);
    if (daysError || noteError || !editor.dirty) return;
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { days, note };
    setPolicySaved("");
    try {
      const result = await save.execute({ version: prepared.version, body: {
        ...prepared.patch.days !== void 0 ? { chatRetentionDays: Number(prepared.patch.days) } : {},
        ...prepared.patch.note !== void 0 ? { jurisdictionNote: prepared.patch.note } : {}
      } });
      const clean = editor.committed({ version: result.data.version, values: { days: result.data.chatRetentionDays?.toString() || "", note: result.data.jurisdictionNote } }, submitted);
      setPolicySaved(clean ? "Đã lưu bản nháp chính sách lưu trữ." : "Đã lưu phần thay đổi đã gửi; chỉnh sửa mới vẫn chưa được lưu.");
    } catch (error) {
      editor.failed(error);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Quyền riêng tư & vòng đời dữ liệu", subtitle: "Tách cấu hình nháp với chính sách được duyệt; yêu cầu xóa không tự vượt điều kiện lưu chứng từ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1fr 1.4fr" }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Chính sách lưu trữ", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: policy, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: policyForm, onSubmit: (event) => {
        event.preventDefault();
        void savePolicy();
      }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: save.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 444
        }, this),
        /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { days: "Số ngày lưu hội thoại", note: "Căn cứ / thị trường áp dụng" }, busy: save.pending }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 478
        }, this),
        policySaved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: policySaved }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 627
        }, this),
        policy.data && /* @__PURE__ */ jsxDEV(Status, { value: policy.data.data.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 705
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Số ngày lưu hội thoại", value: days, onBlur: () => setDaysTouched(true), onChange: (e) => {
          setDays(e.target.value);
          setDaysTouched(true);
          setPolicySaved("");
        }, type: "number", inputProps: { min: 1, max: 36500, step: 1 }, error: showDaysError, helperText: showDaysError ? daysError : "Nhập số nguyên từ 1 đến 36.500 ngày." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 748
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Căn cứ / thị trường áp dụng", multiline: true, minRows: 4, value: note, onBlur: () => setNoteTouched(true), onChange: (e) => {
          setNote(e.target.value);
          setNoteTouched(true);
          setPolicySaved("");
        }, error: showNoteError, helperText: showNoteError ? noteError : "Tối thiểu 5 và tối đa 2.000 ký tự." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 1086
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", type: "submit", variant: "contained", busy: save.pending, disabled: !policy.data || !editor.dirty || save.pending || !!daysError || !!noteError, children: "Lưu bản nháp chính sách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 1391
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Không tự chứng nhận tuân thủ pháp luật. Phê duyệt yêu cầu xóa cần xác thực nâng cao của backend; luồng OIDC step-up chưa được xác minh trong frontend này." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 1616
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 332
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 280
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 229
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Yêu cầu của khách", action: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", onClick: () => setOpen(true), children: "Tạo yêu cầu" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 1876
      }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: requests, pendingProfile: "section", children: requests.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu quyền riêng tư", rows: requests.data.data, rowKey: (r) => r.id, columns: [
          { key: "customer", label: "Khách", render: (r) => `Mã khách hàng: ${r.customerId}` },
          { key: "kind", label: "Yêu cầu", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.kind }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 270,
            columnNumber: 147
          }, this) },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 270,
            columnNumber: 228
          }, this) },
          { key: "reason", label: "Lý do", render: (r) => r.reason }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 269,
          columnNumber: 2054
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: requests.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 271,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 2052
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 1980
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 269,
        columnNumber: 1835
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 269,
      columnNumber: 175
    }, this),
    /* @__PURE__ */ jsxDEV(ConsentManagement, { customers: customers.data?.data || [], canReadCustomers, shopId: shop.id }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 271,
      columnNumber: 91
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Yêu cầu dữ liệu cá nhân", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !customerId || codePointLength(reason.trim()) < 5 || create.pending, onClick: async () => {
      try {
        await create.execute({ body: { kind, customerId, reason } });
        setOpen(false);
      } catch {
      }
    }, children: "Tạo yêu cầu chờ duyệt" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 272,
      columnNumber: 120
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || customers.error || selectedCustomerDetail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 276,
        columnNumber: 63
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm khách hàng", value: customerSearchInput, onChange: (e) => setCustomerSearchInput(e.target.value), disabled: !canReadCustomers, helperText: "Tìm theo mã hoặc tên khách; API hỗ trợ tìm kiếm và cursor." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 162
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Khách hàng", select: true, value: customerId, onChange: (e) => setCustomer(e.target.value), disabled: !canReadCustomers || customers.isPending && !customers.data, children: [
          customerId && !customers.data?.data.some((customer) => customer.id === customerId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: customerId, children: selectedCustomer?.displayName || (selectedCustomerDetail.isPending ? "Đang tải khách đã chọn…" : customerId) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 276,
            columnNumber: 644
          }, this),
          customers.data?.data.map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: c.displayName }, c.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 276,
            columnNumber: 828
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 384
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "khách hàng", loadedCount: customers.loadedCount, hasMore: customers.hasMore, busy: customers.isLoadingMore, onLoadMore: customers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 902
        }, this),
        customers.isError && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void (customers.isFetchNextPageError ? customers.loadMore() : customers.refetch());
        }, children: "Thử lại danh sách khách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 1088
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Loại yêu cầu", select: true, value: kind, onChange: (e) => setKind(e.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "export", children: "Xuất dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 276,
            columnNumber: 1353
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "delete", children: "Xóa dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 276,
            columnNumber: 1409
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 1244
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do / xác minh yêu cầu", multiline: true, minRows: 3, value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 276,
          columnNumber: 1476
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 276,
        columnNumber: 150
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 272,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 269,
    columnNumber: 10
  }, this);
}
_s7(PrivacyPage, "TGmX92/FKzju/bSKHvgcch3C6G0=", false, function() {
  return [useScope, useApi, useApi, useListQuery, useCommand, useCommand, useCan, usePagedApi, useApi, useVersionedDraft, useDraftForm];
});
_c9 = PrivacyPage;
const consentCopyVersion = 1;
const consentReconfirmCopy = "Bạn có đồng ý nhận nội dung tiếp thị từ cửa hàng qua kênh đã chọn không? Bạn có thể rút lại đồng ý bất cứ lúc nào. Tin nhắn phục vụ đơn hàng không thay đổi.";
function ConsentManagement({ customers, canReadCustomers, shopId }) {
  _s8();
  const consentList = usePagedApi("listCustomerConsents", { query: useListQuery("listCustomerConsents") });
  const challengeList = usePagedApi("listCustomerConsentChallenges", { query: useListQuery("listCustomerConsentChallenges") });
  const createChallenge = useCommand("createCustomerConsentChallenge", ["listCustomerConsentChallenges"]);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [channel, setChannel] = useState("messenger");
  const [created, setCreated] = useState(false);
  const customerId = customers.some((customer2) => customer2.id === selectedCustomerId) ? selectedCustomerId : customers[0]?.id || "";
  const customer = customers.find((candidate) => candidate.id === customerId);
  const redacted = customer?.redactedFields || [];
  const availableChannels = [
    { value: "messenger", label: "Messenger", available: Boolean(customer?.externalIdentity) },
    { value: "sms", label: "SMS", available: Boolean(customer?.phone && !redacted.includes("phone")) },
    { value: "email", label: "Email", available: Boolean(customer?.email && !redacted.includes("email")) }
  ].filter((item) => item.available);
  const selectedChannel = availableChannels.find((item) => item.value === channel)?.value || availableChannels[0]?.value || channel;
  const channelIsAvailable = availableChannels.some((item) => item.value === selectedChannel);
  const requestReconfirmation = async () => {
    if (!customerId || !canReadCustomers || !channelIsAvailable) return;
    try {
      await createChallenge.execute({ path: { customerId }, body: { purpose: "marketing", channel: selectedChannel, message: consentReconfirmCopy, contentVersion: consentCopyVersion } });
      setCreated(true);
      await Promise.all([challengeList.refetch(), consentList.refetch()]);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Consent marketing và xác nhận lại", beforeGap: "section", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Consent được lưu theo khách, mục đích, kênh, phiên bản và lịch sử. Tạo yêu cầu chỉ tạo challenge đang chờ; không bật consent. Môi trường local không có nhà cung cấp gửi email/SMS/Meta nên không khẳng định đã gửi link thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 309,
      columnNumber: 13
    }, this),
    canReadCustomers ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khách hàng", value: customerId, onChange: (event) => {
        setSelectedCustomerId(event.target.value);
        setCreated(false);
      }, disabled: !customer, children: customers.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.displayName }, item.id, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 312,
        columnNumber: 46
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 311,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kênh cần xác nhận", value: selectedChannel, onChange: (event) => {
        setChannel(event.target.value);
        setCreated(false);
      }, disabled: !availableChannels.length, children: availableChannels.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.value, children: item.label }, item.value, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 315,
        columnNumber: 54
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 314,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: `Nội dung v${consentCopyVersion}`, children: consentReconfirmCopy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 317,
        columnNumber: 17
      }, this),
      !availableChannels.length && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không có kênh liên hệ còn quyền xem cho khách đã chọn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 318,
        columnNumber: 47
      }, this),
      /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", variant: "contained", busy: createChallenge.pending, disabled: !customerId || !channelIsAvailable || !canReadCustomers, onClick: () => void requestReconfirmation(), children: "Tạo yêu cầu xác nhận lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 319,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: createChallenge.error || consentList.error || challengeList.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 320,
        columnNumber: 17
      }, this),
      created && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã tạo challenge chờ khách xác nhận. Trạng thái này chưa phải consent được cấp." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 321,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 310,
      columnNumber: 33
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Cần quyền customers.read để chọn khách. Danh sách và thông tin nhận dạng được ẩn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 322,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Bản ghi consent hiện tại", children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", children: "Bản ghi consent hiện tại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 324,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: consentList, pendingProfile: "section", children: consentList.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử consent khách hàng", rows: consentList.data.data, rowKey: (record) => record.id, columns: [
          { key: "customer", label: "Khách", render: (record) => `Mã khách hàng: ${record.customerId}` },
          { key: "purpose", label: "Mục đích", render: (record) => businessLabel(record.purpose) },
          { key: "channel", label: "Kênh", render: (record) => businessLabel(record.channel) },
          { key: "status", label: "Trạng thái", render: (record) => /* @__PURE__ */ jsxDEV(Status, { value: record.status, domain: "consent" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 330,
            columnNumber: 71
          }, this) },
          { key: "version", label: "Phiên bản", render: (record) => record.version },
          { key: "evidence", label: "Bằng chứng gần nhất", render: (record) => {
            const latest = record.history.at(-1);
            return latest ? `${businessLabel(latest.action, "consent")} · ${latest.evidenceType} · ${latest.evidenceReference || "—"}` : "Chưa có";
          } }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 326,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: consentList.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 334,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 325,
        columnNumber: 95
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 325,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 323,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Yêu cầu xác nhận đang chờ", children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", children: "Yêu cầu xác nhận đang chờ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 338,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: challengeList, pendingProfile: "section", children: challengeList.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu xác nhận đang chờ", rows: challengeList.data.data, rowKey: (challenge) => challenge.id, columns: [
          { key: "customer", label: "Khách", render: (challenge) => `Mã khách hàng: ${challenge.customerId}` },
          { key: "purpose", label: "Mục đích", render: (challenge) => businessLabel(challenge.purpose) },
          { key: "channel", label: "Kênh", render: (challenge) => businessLabel(challenge.channel) },
          { key: "action", label: "Yêu cầu", render: (challenge) => challenge.action === "withdraw" ? "Ngừng marketing" : "Xác nhận marketing" },
          { key: "status", label: "Trạng thái", render: (challenge) => /* @__PURE__ */ jsxDEV(Status, { value: challenge.status, domain: "consent" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 345,
            columnNumber: 74
          }, this) },
          { key: "expires", label: "Hết hạn", render: (challenge) => dateTime(challenge.expiresAt, "Asia/Ho_Chi_Minh") }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 340,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: challengeList.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 348,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 339,
        columnNumber: 99
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 339,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 337,
      columnNumber: 13
    }, this),
    canReadCustomers && /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: `/s/${shopId}/customers`, size: "small", sx: { alignSelf: "flex-start" }, children: "Mở danh sách khách" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 351,
      columnNumber: 34
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 308,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 307,
    columnNumber: 10
  }, this);
}
_s8(ConsentManagement, "dM1/KXSS4/1TbEyxTpM5R96mHrQ=", false, function() {
  return [usePagedApi, useListQuery, usePagedApi, useListQuery, useCommand];
});
_c0 = ConsentManagement;
function savedConsentChallenge(value) {
  try {
    assertSchema("PublicConsentChallengeView", value);
    return value;
  } catch {
    return null;
  }
}
export function ConsentConfirmationPage() {
  _s9();
  const [params] = useSearchParams();
  const location2 = useLocation();
  const navigate = useNavigate();
  const token = params.get("token") || "";
  const [challenge, setChallenge] = useState(() => savedConsentChallenge(location2.state?.consentChallenge));
  const [confirmation, setConfirmation] = useState(null);
  const [error, setError] = useState(null);
  const [pending, setPending] = useState(false);
  const [submittedDecision, setSubmittedDecision] = useState(null);
  const exchangeId = useRef(crypto.randomUUID());
  const confirmationId = useRef(null);
  const exchange = async () => {
    if (!token || pending) return;
    setPending(true);
    setError(null);
    try {
      const csrf = await request("getCsrfToken");
      setCsrfToken(csrf.data.csrfToken);
      const result = await request("exchangeConsentChallenge", { body: { token }, idempotencyKey: exchangeId.current });
      setChallenge(result.data);
      navigate("/consent/confirm", { replace: true, state: { consentChallenge: result.data } });
    } catch (reason) {
      setError(reason instanceof Error ? reason : new Error("Không xác minh được liên kết."));
    } finally {
      setPending(false);
    }
  };
  const confirm = async (decision) => {
    if (!challenge || pending || confirmation || submittedDecision && submittedDecision !== decision) return;
    const intent = confirmationId.current?.decision === decision ? confirmationId.current : { decision, key: crypto.randomUUID() };
    confirmationId.current = intent;
    setSubmittedDecision(decision);
    setPending(true);
    setError(null);
    try {
      const result = await request("confirmConsentChallenge", { body: { challengeSessionId: challenge.challengeSessionId, decision, contentVersion: challenge.contentVersion }, idempotencyKey: intent.key });
      setConfirmation(result.data);
    } catch (reason) {
      setError(reason instanceof Error ? reason : new Error("Chưa xác minh được kết quả. Hãy thử lại cùng lựa chọn."));
    } finally {
      setPending(false);
    }
  };
  const withdrawal = challenge?.action === "withdraw";
  const confirmationMessage = confirmation ? confirmation.consentStatus === "withdrawn" ? "Đã ghi nhận không nhận tin marketing qua kênh này. Tin nhắn phục vụ đơn hàng không bị ảnh hưởng." : confirmation.status === "declined" ? "Lựa chọn hiện tại được giữ nguyên; không có quyền marketing mới nào được cấp." : "Đã ghi nhận lựa chọn của bạn." : "";
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.pageFallbackInset, { maxWidth: 900, mx: "auto", outline: "none" }], children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Xác nhận lựa chọn marketing", subtitle: "Liên kết ngắn hạn gắn với đúng khách, kênh và nội dung đã gửi." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 405,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: challenge ? withdrawal ? "Ngừng nhận tin marketing" : "Xác nhận nhận tin marketing" : "Kiểm tra liên kết", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Lựa chọn này chỉ áp dụng cho nội dung marketing. Trao đổi phục vụ đơn hàng vẫn được xử lý riêng." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 408,
        columnNumber: 17
      }, this),
      error && /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 409,
        columnNumber: 27
      }, this),
      !challenge && token && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Liên kết không chứa thông tin cá nhân. Tiếp tục để kiểm tra mục đích, kênh và nội dung trước khi gửi lựa chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 411,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => void exchange(), disabled: pending, children: pending ? "Đang kiểm tra…" : error ? "Thử xác minh lại" : "Xem nội dung yêu cầu" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 412,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 410,
        columnNumber: 41
      }, this),
      !challenge && !token && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Thiếu liên kết challenge. Hãy mở liên kết đầy đủ do cửa hàng gửi cho bạn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 414,
        columnNumber: 42
      }, this),
      challenge && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mục đích", children: "Marketing" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 416,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kênh", children: businessLabel(challenge.channel) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 417,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nội dung đã xem", children: challenge.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 418,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản nội dung", children: [
          "v",
          challenge.contentVersion
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 419,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Hết hạn", children: dateTime(challenge.expiresAt, "Asia/Ho_Chi_Minh") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 420,
          columnNumber: 21
        }, this),
        confirmation ? /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: confirmationMessage }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 421,
          columnNumber: 37
        }, this) : /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => void confirm("accept"), disabled: pending || submittedDecision === "decline", children: pending && submittedDecision === "accept" ? "Đang ghi nhận…" : submittedDecision === "accept" ? "Thử lại cùng lựa chọn" : withdrawal ? "Xác nhận ngừng marketing" : "Đồng ý nhận marketing" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 422,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", onClick: () => void confirm("decline"), disabled: pending || submittedDecision === "accept", children: pending && submittedDecision === "decline" ? "Đang ghi nhận…" : submittedDecision === "decline" ? "Thử lại cùng lựa chọn" : withdrawal ? "Giữ nguyên lựa chọn" : "Không đồng ý marketing" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 423,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 421,
          columnNumber: 109
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 415,
        columnNumber: 31
      }, this),
      __MOCK__ && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Môi trường local chỉ mô phỏng hợp đồng và dữ liệu; không gửi email/SMS/Meta và không chứng nhận Backend hoặc nhà cung cấp thật." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 426,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 407,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 406,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 404,
    columnNumber: 10
  }, this);
}
_s9(ConsentConfirmationPage, "DaywKdEVtETRwsgWsiOsX589mWw=", false, function() {
  return [useSearchParams, useLocation, useNavigate];
});
_c1 = ConsentConfirmationPage;
export function JobPage() {
  _s0();
  const { jobId = "" } = useParams();
  const { shop } = useScope();
  const get = useApi("getJob", { path: { jobId } });
  const job = get.data?.data;
  const downloadHref = job?.downloadUrl ? authorizedDownloadHref(job.downloadUrl, location.origin, __MOCK__) : null;
  const jobStatus = job?.status;
  const { refetch } = get;
  useEffect(() => {
    if (!jobStatus || !["queued", "running"].includes(jobStatus))
      return;
    const timer = setInterval(() => void refetch(), 3e3);
    return () => clearInterval(timer);
  }, [jobStatus, refetch]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: `Công việc ${jobId}`, subtitle: "Theo dõi tiến độ từ API. Được tiếp nhận không có nghĩa đã hoàn tất." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 441,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: get, pendingProfile: "section", children: job && /* @__PURE__ */ jsxDEV(Panel, { title: "Kết quả xử lý", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 249
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Loại", children: businessLabel(job.kind) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 278
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tiến độ", children: [
        job.completed,
        " / ",
        job.total ?? "Chưa biết"
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 341
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lỗi", children: job.errorCount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 426
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cập nhật", children: dateTime(job.updatedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 479
      }, this),
      job.rowErrors.length > 0 && /* @__PURE__ */ jsxDEV(DataTable, { label: "Lỗi công việc nền", rows: job.rowErrors, rowKey: (e) => `${e.row}-${e.field}-${e.code}`, columns: [{ key: "row", label: "Dòng", render: (e) => e.row }, { key: "field", label: "Trường", render: (e) => e.field }, { key: "message", label: "Lỗi", render: (e) => e.message }] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 590
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => void get.refetch(), variant: "outlined", children: "Kiểm tra lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 882
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && downloadHref && /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => window.open(downloadHref, "_blank", "noopener,noreferrer"), children: "Mở kết quả xuất" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 1050
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && !downloadHref && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không an toàn hoặc không hợp lệ nên đã bị chặn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 1264
      }, this),
      job.status === "awaiting_confirmation" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/imports/${job.id}`, children: "Xem và xác nhận nhập" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 441,
        columnNumber: 1397
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 441,
      columnNumber: 237
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 441,
      columnNumber: 191
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 441,
      columnNumber: 134
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 441,
    columnNumber: 10
  }, this);
}
_s0(JobPage, "l5lsqPeM5OsNbf4sk4jY+IabZuk=", false, function() {
  return [useParams, useScope, useApi];
});
_c10 = JobPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10;
$RefreshReg$(_c, "AuthCard");
$RefreshReg$(_c2, "LoginPage");
$RefreshReg$(_c3, "WorkspacesPage");
$RefreshReg$(_c4, "OnboardingPage");
$RefreshReg$(_c5, "ShopSettingsPage");
$RefreshReg$(_c6, "SetupChecklistItem");
$RefreshReg$(_c7, "TeamPage");
$RefreshReg$(_c8, "AuditPage");
$RefreshReg$(_c9, "PrivacyPage");
$RefreshReg$(_c0, "ConsentManagement");
$RefreshReg$(_c1, "ConsentConfirmationPage");
$RefreshReg$(_c10, "JobPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkIyYSxTQTBGaGEsVUExRmdhOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCM2EsU0FBUUEsU0FBU0MscUJBQW9CO0FBQ3JDLFNBQVNDLGFBQWFDLFlBQVlDLFlBQVlDLGNBQWNDLGFBQWFDLHNCQUFzQjtBQUMvRixTQUFTQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLFFBQVFDLFlBQVlDLFVBQVVDLGFBQWFDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUNuRyxTQUFTQyxVQUFVQyxzQkFBc0I7QUFDekMsU0FBU0MsT0FBT0MsUUFBUUMsS0FBS0MsUUFBUUMsVUFBVUMsa0JBQWtCQyxVQUFVQyxPQUFPQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFDdEgsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHlCQUF5QjtBQUVoQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxTQUFTQyxvQkFBb0I7QUFDdEMsU0FBU0MsUUFBUUMsYUFBYUMsa0JBQWtCO0FBQ2hELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBQ2pDLFNBQVNDLGlCQUFpQkMsaUJBQWlCQyxVQUFVQyxrQkFBa0JDLHVCQUF1QjtBQUM5RixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQkMsb0JBQW9CO0FBQzdDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVlDLE9BQU9DLFlBQVlDLFdBQVdDLFNBQVNDLE9BQU9DLFFBQVFDLGdCQUFnQkMsWUFBWUMsYUFBYUMsZUFBZUMsV0FBV0MsWUFBWUMsZ0JBQWdCQyxhQUFhO0FBQ3ZMLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxTQUFTO0FBQUEsRUFBRUM7QUFFcEIsR0FBRztBQUFFLFNBQU8sdUJBQUMsT0FBSSxXQUFVLFFBQU8sSUFBRyxnQkFBZSxVQUFVLElBQUksSUFBSSxDQUFDbEIsU0FBU21CLE1BQU1DLGtCQUFrQixFQUFFQyxTQUFTLHNCQUFzQkMsU0FBUyxPQUFPLENBQUMsR0FBRyxpQ0FBQyxTQUFNLFNBQVEsWUFBVyxJQUFJLENBQUN0QixTQUFTdUIsS0FBS0MsY0FBYyxFQUFFQyxPQUFPLFFBQVFDLFVBQVUsS0FBS0MsY0FBY3hFLFNBQVN5RSxPQUFPQyxLQUFLLENBQUMsR0FBRztBQUFBLDJCQUFDLFNBQU0sV0FBVSxPQUFNLFlBQVcsVUFBUyxJQUFJN0IsU0FBU3VCLEtBQUtPLGNBQWM7QUFBQSw2QkFBQyxVQUFPLElBQUksRUFBRVQsU0FBUyxnQkFBZ0JVLE9BQU9wRCxPQUFPcUQsU0FBUyxHQUFHLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLE1BQVMsdUJBQUMsY0FBVyxTQUFRLE1BQUssWUFBWTdFLFNBQVM4RSxXQUFXQyxXQUFXQyxXQUFXO0FBQUE7QUFBQSxRQUFTLHVCQUFDLE9BQUksV0FBVSxRQUFPLE9BQU0sZ0JBQWUsa0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJJO0FBQUEsU0FBblQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnVTtBQUFBLElBQVNqQjtBQUFBQSxPQUEzYztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9kLEtBQXJtQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZtQjtBQUFRO0FBQUNrQixLQUZ6bkJuQjtBQUdGLGdCQUFTb0IsWUFBWTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU0sRUFBRUMsU0FBU0MsUUFBUSxJQUFJeEIsV0FBVztBQUN4QyxRQUFNLENBQUN5QixNQUFNLElBQUkvRSxnQkFBZ0I7QUFDakMsUUFBTSxDQUFDZ0YsU0FBU0MsVUFBVSxJQUFJekYsU0FBUyxLQUFLLEdBQUcsQ0FBQzBGLE9BQU9DLFFBQVEsSUFBSTNGLFNBQXVCLElBQUk7QUFDOUYsUUFBTTRGLFFBQVEsWUFBWTtBQUFFSCxlQUFXLElBQUk7QUFBR0UsYUFBUyxJQUFJO0FBQUcsUUFBSTtBQUM5RCxZQUFNRSxPQUFPLE1BQU1uRSxRQUFRLGNBQWM7QUFDekNDLG1CQUFha0UsS0FBS0MsS0FBS0MsU0FBUztBQUNoQyxZQUFNMUIsT0FBTyxNQUFNM0MsUUFBUSxjQUFjLEVBQUVzRSxNQUFNLEVBQUVDLFVBQVUzRCxpQkFBaUJpRCxPQUFPVyxJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxDQUFDO0FBQzFILFlBQU1DLE1BQU0sSUFBSUMsSUFBSS9CLEtBQUt5QixLQUFLTyxnQkFBZ0I7QUFDOUMsVUFBSUYsSUFBSUcsYUFBYSxZQUFZLEVBQUVDLFlBQVlKLElBQUlLLFdBQVdDLFNBQVNEO0FBQ25FLGNBQU0sSUFBSUUsTUFBTSxrQ0FBa0M7QUFDdERDLGFBQU9GLFNBQVNHLE9BQU9ULElBQUlVLElBQUk7QUFBQSxJQUNuQyxTQUNPQyxHQUFHO0FBQ05uQixlQUFTbUIsYUFBYUosUUFBUUksSUFBSSxJQUFJSixNQUFNLDhCQUE4QixDQUFDO0FBQzNFakIsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFBRTtBQUNGLFNBQU8sdUJBQUMsWUFBUztBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxJQUFJM0MsU0FBU3VCLEtBQUswQyxlQUFlLGlDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBGO0FBQUEsSUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUksQ0FBQ2pFLFNBQVNrRSxXQUFXQyxxQkFBcUJuRSxTQUFTa0UsV0FBV0UsUUFBUSxHQUFHLGdGQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdMO0FBQUEsSUFBYSx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUdYLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSXpELFNBQVNrRSxXQUFXRSxVQUFVLCtFQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdIO0FBQUEsSUFBVTdCLFVBQVUsdUJBQUMsVUFBTyxXQUFTLE1BQUMsV0FBV2xGLFlBQVksSUFBRyxlQUFjLFNBQVEsYUFBWSxTQUFTLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsR0FBSyxxQ0FBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSSxJQUFZLHVCQUFDLFVBQU8sV0FBUyxNQUFDLFNBQVEsYUFBWSxNQUFLLFNBQVEsU0FBUyxNQUFNLEtBQUt5RixNQUFNLEdBQUcsVUFBVUosV0FBV0YsU0FBVUUsb0JBQVUsK0JBQStCZSxXQUFXLDJCQUEyQixzQ0FBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpTztBQUFBLElBQVUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsSUFBSSxDQUFDekQsU0FBU3FFLEtBQUtDLGVBQWUsRUFBRUMsU0FBUyxRQUFRLENBQUMsR0FBRyxrR0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnTTtBQUFBLE9BQS9oQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRpQztBQUN2akM7QUFBQ2pDLEdBbEJlRCxXQUFTO0FBQUEsVUFDUXJCLFlBQ1p0RCxlQUFlO0FBQUE7QUFBQSxNQUZwQjJFO0FBbUJULGdCQUFTbUMsaUJBQWlCO0FBQUFDLE1BQUE7QUFDN0IsUUFBTSxFQUFFbEMsU0FBU0MsU0FBU0ksT0FBTzhCLGFBQWEsSUFBSTFELFdBQVc7QUFDN0QsUUFBTTJELFFBQVFoSCxTQUFTLEVBQUVpSCxVQUFVLENBQUMsU0FBU3JDLFNBQVNzQyxLQUFLQyxFQUFFLEdBQUdDLFNBQVNBLENBQUMsRUFBRUMsT0FBTyxNQUFNcEcsUUFBUSxhQUFhLEVBQUVvRyxPQUFPLENBQUMsR0FBR0MsU0FBUyxDQUFDLENBQUMxQyxTQUFTMkMsT0FBTyxNQUFNLENBQUM7QUFDN0osUUFBTUMsVUFBVSxDQUFDUixNQUFNUyxXQUFXVCxNQUFNM0IsTUFBTUEsS0FBS3FDLFdBQVc7QUFDOUQsUUFBTUMsbUJBQW1CLHVCQUFDLFVBQU8sV0FBV2pJLFlBQVksSUFBRyxlQUFjLFNBQVEsYUFBWSw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRjtBQUN6RyxNQUFJLENBQUNtRixXQUFXLENBQUNELFdBQVdtQyx3QkFBd0J6RixZQUFZeUYsYUFBYWEsV0FBVztBQUNwRixXQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUN4QyxTQUFPLHVCQUFDLE9BQUksV0FBVSxRQUFPLElBQUcsZ0JBQWUsVUFBVSxJQUFJLElBQUksQ0FBQ3ZGLFNBQVNtQixNQUFNcUUsbUJBQW1CLEVBQUU5RCxVQUFVLE1BQU0rRCxJQUFJLFFBQVFuRSxTQUFTLE9BQU8sQ0FBQyxHQUFHO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLHNEQUFxRCxTQUFTLENBQUM2RCxXQUFXRyxvQkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSTtBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPWixnQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPQyxPQUFPLGdCQUFlLFdBQVdRLG9CQUFVLHVCQUFDLFNBQU0sTUFBSyxxQkFBb0IsUUFBUUcsb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsSUFBSyx1QkFBQyxlQUFZLFNBQVMsRUFBRUksSUFBSSxrQkFBa0JDLElBQUloQixNQUFNM0IsTUFBTUEsS0FBS3FDLFdBQVcsSUFBSSxtQkFBbUIsNEJBQTRCLEdBQUlWLGdCQUFNM0IsTUFBTUEsS0FBSzRDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFNLFNBQVEsWUFBc0IsSUFBSSxDQUFDN0YsU0FBUzhGLFFBQVFDLE9BQU8sRUFBRXBFLGNBQWN4RSxTQUFTeUUsT0FBT29FLE1BQU0sQ0FBQyxHQUFHO0FBQUEsNkJBQUMsVUFBTyxJQUFJLEVBQUUzRSxTQUFTMUMsT0FBT3NILFVBQVVsRSxPQUFPLGVBQWUsR0FBSThELFlBQUVLLEtBQUssQ0FBQyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFBUyx1QkFBQyxrQkFBZSxXQUFVLFdBQVU7QUFBQSwrQkFBQyxjQUFXLFNBQVEsTUFBTUwsWUFBRUssUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLGtCQUFrQkw7QUFBQUEsWUFBRU07QUFBQUEsVUFBUztBQUFBLFVBQUlOLEVBQUVPO0FBQUFBLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCO0FBQUE7QUFBQSxVQUFRN0QsU0FBUzhELFlBQVlDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV1gsRUFBRWYsRUFBRSxHQUFHMkIsTUFBTWIsSUFBSSxDQUFBYyxTQUFRakssY0FBY2lLLElBQUksQ0FBQyxFQUFFQyxLQUFLLElBQUksS0FBSztBQUFBLGFBQXJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUw7QUFBQSxXQUFsVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStWO0FBQUEsTUFBaUIsdUJBQUMsVUFBTyxXQUFXdEosWUFBWSxJQUFJLE1BQU13SSxFQUFFZixFQUFFLGFBQWEsV0FBUyxNQUFDLFNBQVEsWUFBVyxTQUFTLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsR0FBSyxJQUFJOUUsU0FBU3FFLEtBQUtDLGVBQWUsMkJBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUs7QUFBQSxTQUF2ckJ1QixFQUFFZixJQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQSt0QixDQUFRLEtBQXQ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXc0QixLQUFwZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtaEM7QUFBQSxPQUE3MEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwMUM7QUFDcjJDO0FBQUNMLElBUmVELGdCQUFjO0FBQUEsVUFDd0J4RCxZQUNwQ3JELFFBQVE7QUFBQTtBQUFBLE1BRlY2RztBQVNULGdCQUFTb0MsaUJBQWlCO0FBQUFDLE1BQUE7QUFDN0IsUUFBTUMsV0FBV3RKLFlBQVk7QUFDN0IsUUFBTSxFQUFFdUosUUFBUSxJQUFJL0YsV0FBVztBQUMvQixRQUFNZ0csUUFBUXBKLGVBQWU7QUFDN0IsUUFBTSxDQUFDc0ksTUFBTWUsT0FBTyxJQUFJL0osU0FBUyxFQUFFLEdBQUcsQ0FBQ2lKLFVBQVVlLFdBQVcsSUFBSWhLLFNBQVMsS0FBSyxHQUFHLENBQUNrSixVQUFVZSxXQUFXLElBQUlqSyxTQUFTLGdCQUFnQixHQUFHLENBQUN3RixTQUFTQyxVQUFVLElBQUl6RixTQUFTLEtBQUssR0FBRyxDQUFDMEYsT0FBT0MsUUFBUSxJQUFJM0YsU0FBdUIsSUFBSSxHQUFHLENBQUNrSyxpQkFBaUJDLGtCQUFrQixJQUFJbkssU0FBUyxLQUFLLEdBQUcsQ0FBQ29LLFdBQVdDLFlBQVksSUFBSXJLLFNBQVMsS0FBSztBQUNyVSxRQUFNc0ssY0FBY3ZLLE9BQXdCLElBQUk7QUFDaEQsUUFBTXdLLFdBQVd4SyxPQUFPLEVBQUNpSixNQUFNLElBQUdDLFVBQVUsT0FBTUMsVUFBVSxpQkFBZ0IsQ0FBQztBQUM3RSxRQUFNc0IsVUFBVXpLLE9BQU8sSUFBSTtBQUMzQkQsWUFBVSxNQUFNO0FBQUUwSyxZQUFRQyxVQUFRO0FBQU0sV0FBTyxNQUFNO0FBQUVELGNBQVFDLFVBQVE7QUFBQSxJQUFPO0FBQUEsRUFBRyxHQUFFLEVBQUU7QUFDckYsUUFBTUMsWUFBWS9ILGFBQWFxRyxTQUFPdUIsU0FBU0UsUUFBUXpCLFFBQVFDLGFBQVdzQixTQUFTRSxRQUFReEIsWUFBWUMsYUFBV3FCLFNBQVNFLFFBQVF2QixRQUFRO0FBQzNJLFFBQU15QixnQkFBZ0IsQ0FBQ3BJLGdCQUFnQjJHLFFBQVEsSUFBSSwrQ0FBK0M7QUFDbEcsUUFBTTBCLE9BQU8sWUFBWTtBQUFFUCxpQkFBYSxJQUFJO0FBQUcsUUFBSTdFLFdBQVcsQ0FBQ3dELEtBQUs2QixLQUFLLEtBQUtGLGNBQWU7QUFBUWxGLGVBQVcsSUFBSTtBQUFHRSxhQUFTLElBQUk7QUFBRyxRQUFJO0FBQ3ZJLFlBQU1tRixJQUFJLE1BQU1wSixRQUFRLGNBQWMsRUFBRXNFLE1BQU0sRUFBRWdELE1BQU1DLFVBQVVDLFVBQVU2QixRQUFRLFFBQVEsRUFBRSxDQUFDO0FBQzdGLFlBQU1sQixRQUFRO0FBQ2QsWUFBTUMsTUFBTWtCLGtCQUFrQixFQUFFdEQsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ3JELFVBQUksQ0FBQzhDLFFBQVFDLFFBQVM7QUFDdEJGLGVBQVNFLFVBQVEsRUFBQ3pCLE1BQUtDLFVBQVNDLFNBQVE7QUFDeEMsVUFBSW9CLFlBQVlHLFFBQVMvSCxnQkFBZTRILFlBQVlHLE9BQU87QUFDM0RiLGVBQVMsTUFBTWtCLEVBQUVoRixLQUFLOEIsRUFBRSxXQUFXO0FBQUEsSUFDdkMsU0FDT2QsR0FBRztBQUNOLFVBQUkwRCxRQUFRQyxRQUFTOUUsVUFBU21CLGFBQWFKLFFBQVFJLElBQUksSUFBSUosTUFBTSx5QkFBeUIsQ0FBQztBQUFBLElBQy9GLFVBQUM7QUFFRyxVQUFJOEQsUUFBUUMsUUFBU2hGLFlBQVcsS0FBSztBQUFBLElBQ3pDO0FBQUEsRUFBRTtBQUNGLFNBQU8sdUJBQUMsWUFBUztBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxJQUFJM0MsU0FBU3VCLEtBQUswQyxlQUFlLDRCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFGO0FBQUEsSUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUksQ0FBQ2pFLFNBQVNrRSxXQUFXQyxxQkFBcUJuRSxTQUFTa0UsV0FBV0UsUUFBUSxHQUFHLGdFQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdLO0FBQUEsSUFBYSx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUUsdUJBQUMsY0FBVyxXQUFVLFFBQU8sWUFBVSxNQUFDLEtBQUssQ0FBQStELFlBQVc7QUFBQ1gsa0JBQVlHLFVBQVFRO0FBQVFQLGdCQUFVTyxPQUFPO0FBQUEsSUFBRSxHQUFHLFVBQVUsQ0FBQUMsVUFBUztBQUFDQSxZQUFNQyxlQUFlO0FBQUUsV0FBS1AsS0FBSztBQUFBLElBQUUsR0FBRztBQUFBLDZCQUFDLGFBQVUsVUFBVXBGLFNBQVMsT0FBTSxnQkFBZSxPQUFPd0QsTUFBTSxVQUFVLENBQUFsQyxNQUFLaUQsUUFBUTNILGdCQUFnQjBFLEVBQUVzRSxPQUFPQyxPQUFPLEdBQUcsQ0FBQyxLQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZIO0FBQUEsTUFBRyx1QkFBQyxhQUFVLFVBQVU3RixTQUFTLE9BQU0saUJBQWdCLFFBQU0sTUFBQyxPQUFPeUQsVUFBVSxVQUFVLENBQUFuQyxNQUFLa0QsWUFBWWxELEVBQUVzRSxPQUFPQyxLQUFLLEdBQUksV0FBQyxPQUFPLE9BQU8sT0FBTyxLQUFLLEVBQUUzQyxJQUFJLENBQUE0QyxNQUFLLHVCQUFDLFlBQWlCLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixDQUFXLEtBQXpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMk07QUFBQSxNQUFZLHVCQUFDLGFBQVUsVUFBVTlGLFNBQVMsT0FBTSxXQUFVLE9BQU8wRCxVQUFVLFFBQVEsTUFBTWlCLG1CQUFtQixJQUFJLEdBQUcsVUFBVSxDQUFBckQsTUFBS21ELFlBQVluRCxFQUFFc0UsT0FBT0MsS0FBSyxHQUFHLFFBQVFuQixtQkFBbUJFLGNBQWMsQ0FBQyxDQUFDTyxlQUFlLGFBQWFULG1CQUFtQkUsY0FBY08sZ0JBQWdCQSxnQkFBZ0IsMkJBQTNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbVQ7QUFBQSxNQUFFLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJIQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtJO0FBQUEsTUFBUSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksVUFBVSxDQUFDM0IsS0FBSzZCLEtBQUssS0FBS3JGLFNBQVMsNEJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUY7QUFBQSxNQUFTLHVCQUFDLFVBQU8sV0FBV3JGLFlBQVksSUFBRyxlQUFjLHdCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsU0FBcmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOGxDO0FBQUEsT0FBbjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZzZDO0FBQzM2QztBQUFDd0osSUEzQmVELGdCQUFjO0FBQUEsVUFDVHBKLGFBQ0d3RCxZQUNOcEQsZ0JBTUlpQyxZQUFZO0FBQUE7QUFBQSxNQVRsQitHO0FBNEJULGdCQUFTNkIsbUJBQW1CO0FBQUFDLE1BQUE7QUFDL0IsUUFBTUMsUUFBUXZKLFNBQVM7QUFDdkIsUUFBTSxFQUFFd0osS0FBSyxJQUFJRDtBQUNqQixRQUFNM0IsUUFBUXBKLGVBQWU7QUFDN0IsUUFBTWlMLGdCQUFnQjFKLE9BQU8sYUFBYTtBQUMxQyxRQUFNMkosU0FBUzlKLFdBQVcsY0FBYyxDQUFDLFNBQVMsQ0FBQztBQUNuRCxRQUFNLENBQUNrSCxNQUFNZSxPQUFPLElBQUkvSixTQUFTMEwsS0FBSzFDLElBQUksR0FBRyxDQUFDRSxVQUFVZSxXQUFXLElBQUlqSyxTQUFTMEwsS0FBS3hDLFFBQVEsR0FBRyxDQUFDNkIsUUFBUWMsU0FBUyxJQUFJN0wsU0FBUzBMLEtBQUtYLE1BQU0sR0FBRyxDQUFDckYsT0FBT0MsUUFBUSxJQUFJM0YsU0FBdUIsSUFBSSxHQUFHLENBQUM4TCxPQUFPQyxRQUFRLElBQUkvTCxTQUFTLEtBQUssR0FBRyxDQUFDa0ssaUJBQWlCQyxrQkFBa0IsSUFBSW5LLFNBQVMsS0FBSyxHQUFHLENBQUNnTSxtQkFBbUJDLG9CQUFvQixJQUFJak0sU0FBUyxLQUFLO0FBQ3ZWLFFBQU1rTSxhQUFhdEssT0FBTyxTQUFTO0FBQ25DLFFBQU11SyxjQUFjRCxXQUFXcEcsUUFBUW9HLFdBQVdwRyxLQUFLQSxLQUFLc0csV0FBV1YsS0FBS1UsVUFBVUYsV0FBV3BHLEtBQUtBLE9BQU80RjtBQUM3RyxRQUFNVyxTQUFTekosa0JBQWtCO0FBQUEsSUFDN0IwSixVQUFVLEdBQUdaLEtBQUs5RCxFQUFFO0FBQUEsSUFDcEIyRSxRQUFRLEVBQUVILFNBQVNELFlBQVlDLFNBQVNJLFFBQVEsRUFBRXhELE1BQU1tRCxZQUFZbkQsTUFBTUUsVUFBVWlELFlBQVlqRCxVQUFVNkIsUUFBUW9CLFlBQVlwQixPQUFPLEVBQUU7QUFBQSxJQUN2STBCLE9BQU8sRUFBRXpELE1BQU1FLFVBQVU2QixPQUFPO0FBQUEsSUFDaEMyQixPQUFPQSxDQUFBRixXQUFVO0FBQUV6QyxjQUFReUMsT0FBT3hELElBQUk7QUFBR2lCLGtCQUFZdUMsT0FBT3RELFFBQVE7QUFBRzJDLGdCQUFVVyxPQUFPekIsTUFBTTtBQUFBLElBQUc7QUFBQSxJQUNqR2xCLFNBQVNBLE1BQU1xQyxXQUFXUyxRQUFRLEVBQUVDLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDNUQsQ0FBQztBQUNELFFBQU1DLFVBQVVsSyxhQUFhMEosT0FBT1MsS0FBSztBQUN6QyxRQUFNbkMsZ0JBQWdCLENBQUNwSSxnQkFBZ0IyRyxRQUFRLElBQUksK0NBQStDO0FBQ2xHLFFBQU0wQixPQUFPLFlBQVk7QUFDckJxQix5QkFBcUIsSUFBSTtBQUN6QixRQUFJLENBQUNqRCxLQUFLNkIsS0FBSyxLQUFLRixjQUFlO0FBQ25DaEYsYUFBUyxJQUFJO0FBQUdvRyxhQUFTLEtBQUs7QUFDOUIsVUFBTWdCLFdBQVdWLE9BQU9XLFFBQVE7QUFDaEMsUUFBSSxDQUFDRCxTQUFVO0FBQ2YsVUFBTTNDLFlBQVksRUFBRXBCLE1BQU1FLFVBQVU2QixPQUFPO0FBQzNDLFFBQUk7QUFDQSxZQUFNa0MsU0FBUyxNQUFNckIsT0FBT3NCLFFBQVEsRUFBRUMsTUFBTSxFQUFFN0QsUUFBUW9DLEtBQUs5RCxHQUFHLEdBQUd3RSxTQUFTVyxTQUFTWCxTQUFTcEcsTUFBTStHLFNBQVNLLE1BQU0sQ0FBQztBQUNsSHRELFlBQU11RCxhQUFhLENBQUMsUUFBUTVCLE1BQU1wRyxRQUFRc0MsS0FBS0MsSUFBSThELEtBQUs5RCxJQUFJNkQsTUFBTTZCLFdBQVdDLGlCQUFpQixHQUFHTixNQUFNO0FBQ3ZHWixhQUFPbUIsVUFBVSxFQUFFcEIsU0FBU2EsT0FBT25ILEtBQUtzRyxTQUFTSSxRQUFRLEVBQUV4RCxNQUFNaUUsT0FBT25ILEtBQUtrRCxNQUFNRSxVQUFVK0QsT0FBT25ILEtBQUtvRCxVQUFVNkIsUUFBUWtDLE9BQU9uSCxLQUFLaUYsT0FBTyxFQUFFLEdBQUdYLFNBQVM7QUFDNUoyQixlQUFTLElBQUk7QUFBQSxJQUNqQixTQUNPckcsUUFBTztBQUFFMkcsYUFBT29CLE9BQU8vSCxNQUFLO0FBQUdDLGVBQVNELGtCQUFpQmdCLFFBQVFoQixTQUFRLElBQUlnQixNQUFNLHlCQUF5QixDQUFDO0FBQUEsSUFBRztBQUFBLEVBQzNIO0FBQ0EsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxzQkFBcUIsVUFBUyxvRkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSTtBQUFBLElBQ2hJLHVCQUFDLGdCQUNHO0FBQUEsNkJBQUMsU0FBTSxPQUFNLG1CQUFrQixVQUFTLFNBQ3BDLGlDQUFDLGNBQVcsV0FBVSxRQUFPLEtBQUttRyxTQUFTLFlBQVUsTUFBQyxVQUFVLENBQUEzQixVQUFTO0FBQUVBLGNBQU1DLGVBQWU7QUFBRyxhQUFLUCxLQUFLO0FBQUEsTUFBRyxHQUM1RztBQUFBLCtCQUFDLGVBQVksT0FBT2xGLFNBQVNrRyxPQUFPbEcsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLGlCQUFjLFFBQWdCLFFBQVEsRUFBRXNELE1BQU0sZ0JBQWdCRSxVQUFVLFdBQVc2QixRQUFRLFdBQVcsR0FBRyxNQUFNYSxPQUFPcEcsV0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSDtBQUFBLFFBQzlIc0csU0FBUyx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVMseUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUMzRSx1QkFBQyxjQUFXLFdBQVcsRUFBRXRELElBQUksVUFBVWtGLElBQUksTUFBTSxHQUFHLFlBQVksRUFBRWxGLElBQUksV0FBV2tGLElBQUksUUFBUSxHQUN6RjtBQUFBLGlDQUFDLGFBQVUsT0FBTSxnQkFBZSxPQUFPMUUsTUFBTSxVQUFVLENBQUMyQyxlQUFlLFVBQVUsQ0FBQVQsVUFBUztBQUFFbkIsb0JBQVFtQixNQUFNRSxPQUFPQyxLQUFLO0FBQUdVLHFCQUFTLEtBQUs7QUFBQSxVQUFHLEdBQUcsSUFBSSxFQUFFNEIsTUFBTSxHQUFHQyxVQUFVLEVBQUUsS0FBeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEs7QUFBQSxVQUMxSyx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLE9BQU9sQyxLQUFLekMsVUFBVSxVQUFRLE1BQUMsWUFBVywwRUFBeUUsSUFBSSxFQUFFMEUsTUFBTSxHQUFHQyxVQUFVLEVBQUUsS0FBL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUw7QUFBQSxhQUZyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGNBQVcsV0FBVyxFQUFFcEYsSUFBSSxVQUFVa0YsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFbEYsSUFBSSxXQUFXa0YsSUFBSSxRQUFRLEdBQ3pGO0FBQUEsaUNBQUMsYUFBVSxPQUFNLFdBQVUsT0FBT3hFLFVBQVUsVUFBVSxDQUFDeUMsZUFBZSxRQUFRLE1BQU14QixtQkFBbUIsSUFBSSxHQUFHLFVBQVUsQ0FBQWUsVUFBUztBQUFFakIsd0JBQVlpQixNQUFNRSxPQUFPQyxLQUFLO0FBQUdVLHFCQUFTLEtBQUs7QUFBQSxVQUFHLEdBQUcsUUFBUTdCLG1CQUFtQjhCLHNCQUFzQixDQUFDLENBQUNyQixlQUFlLGFBQWFULG1CQUFtQjhCLHNCQUFzQnJCLGdCQUFnQkEsZ0JBQWdCLHVDQUF1QyxJQUFJLEVBQUVnRCxNQUFNLEdBQUdDLFVBQVUsRUFBRSxLQUFsWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvWjtBQUFBLFVBQ3BaLHVCQUFDLGFBQVUsT0FBTSxzQkFBcUIsT0FBTSxjQUFhLFVBQVEsTUFBQyxZQUFZLCtEQUErRDdDLE1BQU0sS0FBSyxJQUFJLEVBQUU0QyxNQUFNLEdBQUdDLFVBQVUsRUFBRSxLQUFuTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxTDtBQUFBLGFBRnpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsYUFBVSxPQUFNLGFBQVksT0FBTSw2QkFBNEIsVUFBUSxRQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkUsdUJBQUMsa0JBQWUsWUFBVyxlQUFjLE1BQUssVUFBUyxTQUFRLGFBQVksTUFBTWhDLE9BQU9wRyxTQUFTLFVBQVUsQ0FBQ21HLGlCQUFpQixDQUFDVSxPQUFPUyxTQUFTbEIsT0FBT3BHLFNBQVMsNEJBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEs7QUFBQSxXQWI5SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0EsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sZ0NBQStCLFVBQVMsZ0dBQStGLFVBQVMsU0FDekosaUNBQUMsU0FBTSxJQUFJMUMsU0FBUzhGLFFBQVFpRixtQkFDeEI7QUFBQSwrQkFBQyxTQUFNLFVBQVMsUUFBUXRIO0FBQUFBLHFCQUFXLDZGQUE2RjtBQUFBLFVBQXlEO0FBQUEsYUFBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyTztBQUFBLFFBQzNPLHVCQUFDLHNCQUFtQixPQUFNLDhCQUE2QixRQUFPLDRDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsUUFDdEcsdUJBQUMsc0JBQW1CLE9BQU0sd0NBQXVDLFFBQVFBLFdBQVcsMkNBQTJDLHdDQUF3QyxJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSxjQUFjLFFBQU8sMEJBQTdNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbU87QUFBQSxRQUNuTyx1QkFBQyxzQkFBbUIsT0FBTSw2QkFBNEIsUUFBTyw2REFBNEQsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUsa0JBQWtCLFFBQU8sd0JBQW5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUw7QUFBQSxRQUN2TCx1QkFBQyxzQkFBbUIsT0FBTSx5QkFBd0IsUUFBUXJCLFdBQVcsbURBQW1ELCtCQUErQixJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSwwQkFBMEIsUUFBTyxnQkFBek07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxTjtBQUFBLFFBQ3JOLHVCQUFDLHNCQUFtQixPQUFNLGNBQWEsUUFBUXJCLFdBQVcsa0NBQWtDLGlDQUFpQyxJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSxvQkFBb0IsUUFBTyx3QkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TDtBQUFBLFFBQzdMLHVCQUFDLHNCQUFtQixPQUFNLDRDQUEyQyxRQUFPLDJFQUEwRSxJQUFJLE1BQU04RCxLQUFLOUQsRUFBRSxjQUFjLFFBQU8sc0JBQTVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOE07QUFBQSxRQUM5TSx1QkFBQyxzQkFBbUIsT0FBTSx1QkFBc0IsUUFBTywwREFBeUQsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUscUJBQXFCLFFBQU8saUJBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEs7QUFBQSxRQUMxSyx1QkFBQyxzQkFBbUIsT0FBTSxzQ0FBcUMsUUFBTywrRkFBOEYsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUscUJBQXFCLFFBQU8scUJBQWpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa087QUFBQSxXQVR0TztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsT0FqQ0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDUDtBQUNKO0FBQUM0RCxJQXBFZUQsa0JBQWdCO0FBQUEsVUFDZHJKLFVBRUF4QixnQkFDUXVCLFFBQ1BILFlBRUlGLFFBRUpnQixtQkFPQ0QsWUFBWTtBQUFBO0FBQUEsTUFoQmhCNEk7QUFxRWhCLFNBQVN1QyxtQkFBbUIsRUFBRUMsT0FBTzFGLFFBQVEyRixJQUFJQyxPQUF3RSxHQUFHO0FBQ3hILFNBQU8sdUJBQUMsa0JBQWUsVUFBUywwQkFBeUIsV0FBVSxPQUFNLFlBQVksRUFBRXpGLElBQUksY0FBY0MsSUFBSSxTQUFTLEdBQUcsZ0JBQWUsaUJBQWdCLFVBQVMsUUFDN0o7QUFBQSwyQkFBQyxPQUFJO0FBQUEsNkJBQUMsY0FBVyxZQUFZeEksU0FBUzhFLFdBQVdDLFdBQVdrSixRQUFTSCxtQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBa0IxRixvQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLFNBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0s7QUFBQSxJQUMvSjJGLE1BQU1DLFVBQVUsdUJBQUMsYUFBVSxJQUFTQSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHUDtBQUNKO0FBQUNFLE1BTFFMO0FBTVQsTUFBTU0sYUFBbUM7QUFBQSxFQUNyQ0MsT0FBTztBQUFBLEVBQWdCQyxTQUFTO0FBQUEsRUFBV0MsT0FBTztBQUFBLEVBQVlDLFdBQVc7QUFBQSxFQUFpQkMsWUFBWTtBQUFBLEVBQVdDLFdBQVc7QUFBQSxFQUFlQyxRQUFRO0FBQ3ZKO0FBQ08sZ0JBQVNDLFdBQVc7QUFBQUMsTUFBQTtBQUN2QixRQUFNLEVBQUV4SixTQUFTcUcsS0FBSyxJQUFJeEosU0FBUztBQUNuQyxRQUFNNE0sT0FBT2xOLE9BQU8sZUFBZSxFQUFFbU4sT0FBT3RNLGFBQWEsYUFBYSxFQUFFLENBQUM7QUFDekUsUUFBTSxDQUFDdU0sVUFBVUMsV0FBVyxJQUFJalAsU0FBUyxFQUFFO0FBQzNDLFFBQU1rUCxTQUFTdE4sT0FBTyxhQUFhLEVBQUV1TCxNQUFNLEVBQUU2QixTQUFTLEVBQUUsR0FBR0csUUFBUUgsUUFBUSxDQUFDO0FBQzVFLFFBQU1JLFNBQVN0TixXQUFXLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztBQUN6RCxRQUFNOEosU0FBUzlKLFdBQVcscUJBQXFCLENBQUMsZUFBZSxXQUFXLENBQUM7QUFDM0UsUUFBTXVOLFNBQVN2TixXQUFXLG9CQUFvQixDQUFDLGVBQWUsV0FBVyxDQUFDO0FBQzFFLFFBQU0sQ0FBQ3dOLE1BQU1DLE9BQU8sSUFBSXZQLFNBQXdDLEdBQUcsQ0FBQ3dQLE9BQU9DLFFBQVEsSUFBSXpQLFNBQVMsRUFBRSxHQUFHLENBQUN1SixPQUFPbUcsUUFBUSxJQUFJMVAsU0FBaUIsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDMlAsUUFBUUMsU0FBUyxJQUFJNVAsU0FBNEIsSUFBSSxHQUFHLENBQUM2UCxjQUFjQyxlQUFlLElBQUk5UCxTQUFTLEVBQUU7QUFDN1AsUUFBTStQLE9BQU9BLENBQUMxRyxNQUF5QjtBQUFFeUcsb0JBQWdCLEVBQUU7QUFBR1AsWUFBUWxHLENBQUM7QUFBR29HLGFBQVMsRUFBRTtBQUFHQyxhQUFTckcsR0FBR0UsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLEVBQUc7QUFDMUgsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSx3QkFBdUIsVUFBUyxnRkFBK0UsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFRLGFBQVksU0FBUyxNQUFNd0csS0FBSyxJQUFJLEdBQUcsNkJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0csS0FBbFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvUTtBQUFBLElBQUdGLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVMsSUFBSS9NLFNBQVNrTixPQUFPOUksVUFBVzJJLDBCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9GO0FBQUEsSUFBUyx1QkFBQyxTQUFNO0FBQUEsNkJBQUMsV0FBUSxXQUFVLGlCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFBRyx1QkFBQyxjQUFXLE9BQU9mLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2hKLFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sNkJBQTRCLE1BQU1nSixLQUFLaEosS0FBS0EsTUFBTSxRQUFRLENBQUF1RCxNQUFLQSxFQUFFekIsSUFBSSxTQUFTO0FBQUEsVUFDcGtCLEVBQUVxSSxLQUFLLFFBQVEzUSxPQUFPLGFBQWE0USxRQUFRQSxDQUFBN0csTUFBS0EsRUFBRThHLFdBQVc5SyxRQUFRc0MsS0FBS0MsS0FBS3ZDLFFBQVFzQyxLQUFLeUksY0FBYyxlQUFlL0csRUFBRThHLE1BQU0sR0FBRztBQUFBLFVBQUcsRUFBRUYsS0FBSyxTQUFTM1EsT0FBTyxXQUFXNFEsUUFBUUEsQ0FBQTdHLE1BQUtBLEVBQUVFLE1BQU1iLElBQUksQ0FBQW9DLE1BQUtzRCxXQUFXdEQsQ0FBQyxDQUFDLEVBQUVyQixLQUFLLElBQUksRUFBRTtBQUFBLFVBQUcsRUFBRXdHLEtBQUssVUFBVTNRLE9BQU8sY0FBYzRRLFFBQVFBLENBQUE3RyxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRWhCLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUFHLEVBQUU0SCxLQUFLLFNBQVMzUSxPQUFPLGtCQUFrQjRRLFFBQVFBLENBQUE3RyxNQUFLLEdBQUdBLEVBQUVnSCxZQUFZbEksTUFBTSxhQUFha0IsRUFBRWtFLGlCQUFpQixHQUFHO0FBQUEsVUFDcmE7QUFBQSxZQUNJMEMsS0FBSztBQUFBLFlBQVczUSxPQUFPO0FBQUEsWUFBSTRRLFFBQVFBLENBQUE3RyxNQUFLLHVCQUFDLGVBQVksV0FBVSxPQUFNO0FBQUEscUNBQUMsVUFBTyxTQUFTLE1BQU00RixZQUFZNUYsRUFBRXpCLEVBQUUsR0FBRyxnQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUFTLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVMsTUFBTW1JLEtBQUsxRyxDQUFDLEdBQUcseUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZFO0FBQUEsY0FBaUIsdUJBQUMsa0JBQWUsWUFBVyxrQkFBaUIsT0FBTSxTQUFRLFVBQVVBLEVBQUU4RyxXQUFXOUssUUFBUXNDLEtBQUtDLE1BQU15QixFQUFFaEIsV0FBVyxXQUFXLFNBQVMsTUFBTXVILFVBQVV2RyxDQUFDLEdBQUcsdUJBQXpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdLO0FBQUEsaUJBQTlWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStXO0FBQUEsVUFDM1o7QUFBQSxRQUFDLEtBSm9lO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLdmU7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTXlGLEtBQUtoSixLQUFLcUIsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBTHVjO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLcmMsS0FMcVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtqWTtBQUFBLFNBTHVWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLMVU7QUFBQSxJQUN0RCx1QkFBQyxjQUFXLE1BQU0sQ0FBQyxDQUFDNkgsVUFBVSxPQUFNLG9CQUFtQixTQUFTLE1BQU1DLFlBQVksRUFBRSxHQUFHLFNBQVMsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLFlBQVksRUFBRSxHQUFHLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDLEdBQ3pJLGlDQUFDLGNBQVcsT0FBT0MsUUFBUSxnQkFBZSxXQUFXQSxpQkFBT3BKLFFBQVEsdUJBQUMsa0JBQ2pFO0FBQUEsNkJBQUMsY0FBVyxPQUFNLGFBQWFvSixpQkFBT3BKLEtBQUtBLEtBQUtxSyxXQUFXOUssUUFBUXNDLEtBQUtDLEtBQUt2QyxRQUFRc0MsS0FBS3lJLGNBQWMsaUJBQWlCbEIsT0FBT3BKLEtBQUtBLEtBQUtxSyxVQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlKO0FBQUEsTUFDakosdUJBQUMsY0FBVyxPQUFNLGlCQUFpQmpCLGlCQUFPcEosS0FBS0EsS0FBSzhCLE1BQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxjQUFhLGlDQUFDLFVBQU8sT0FBT3NILE9BQU9wSixLQUFLQSxLQUFLdUMsVUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QyxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFDNUksdUJBQUMsY0FBVyxPQUFNLFdBQVc2RyxpQkFBT3BKLEtBQUtBLEtBQUt5RCxNQUFNYixJQUFJLENBQUFjLFNBQVE0RSxXQUFXNUUsSUFBSSxDQUFDLEVBQUVDLEtBQUssSUFBSSxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZGO0FBQUEsTUFDN0YsdUJBQUMsY0FBVyxPQUFNLG1CQUFtQnlGLGlCQUFPcEosS0FBS0EsS0FBS3lILHFCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWtCMkIsaUJBQU9wSixLQUFLQSxLQUFLdUssWUFBWTVHLEtBQUssSUFBSSxLQUFLLG9CQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdHO0FBQUEsU0FKckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtwRSxLQUxBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLa0IsS0FOckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxjQUFXLE1BQU02RixTQUFTZ0IsUUFBVyxPQUFPaEIsT0FBTyxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTUMsUUFBUWUsTUFBUyxHQUFHLE1BQU1sQixPQUFPNUosV0FBV29HLE9BQU9wRyxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDK0QsTUFBTXBCLFVBQVcsQ0FBQ21ILFFBQVEsQ0FBQyw2QkFBNkJpQixLQUFLZixLQUFLLEtBQU1KLE9BQU81SixXQUFXb0csT0FBT3BHLFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUNqVixZQUFJOEosTUFBTTtBQUNOLGdCQUFNMUQsT0FBT3NCLFFBQVEsRUFBRUMsTUFBTSxFQUFFNkIsVUFBVU0sS0FBSzFILEdBQUcsR0FBR3dFLFNBQVNrRCxLQUFLL0IsbUJBQW1CdkgsTUFBTSxFQUFFdUQsTUFBTSxFQUFFLENBQUM7QUFDdEd1RywwQkFBZ0Isa0NBQWtDUixLQUFLYSxNQUFNLEdBQUc7QUFBQSxRQUNwRSxPQUFPO0FBQ0gsZ0JBQU1mLE9BQU9sQyxRQUFRLEVBQUVsSCxNQUFNLEVBQUV3SixPQUFPakcsTUFBTSxFQUFFLENBQUM7QUFDL0N1RywwQkFBZ0Isc0JBQXNCTixNQUFNM0UsS0FBSyxDQUFDLEdBQUc7QUFBQSxRQUN6RDtBQUNBMEUsZ0JBQVFlLE1BQVM7QUFBQSxNQUNyQixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsbUJBVjhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVM0ksR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT2xCLE9BQU8xSixTQUFTa0csT0FBT2xHLFNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxNQUFFLHVCQUFDLGNBQWE7QUFBQSxTQUFDNEosUUFBUSx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE1BQUssU0FBUSxPQUFPRSxPQUFPLFVBQVUsQ0FBQTFJLE1BQUsySSxTQUFTM0ksRUFBRXNFLE9BQU9DLEtBQUssS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFFBQUcsdUJBQUMsY0FBVyxTQUFRLGFBQVksNEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUFlbUYsT0FBT0MsS0FBS3JDLFVBQVUsRUFBYTFGLElBQUksQ0FBQWMsU0FBUSx1QkFBQyxvQkFBNEIsT0FBTyxHQUFHNEUsV0FBVzVFLElBQUksQ0FBQyxNQUFNaEksa0JBQWtCa1AsWUFBWWxILElBQUksR0FBR3JCLFVBQVUsQ0FBQyxVQUFVLFNBQVMsdUJBQUMsWUFBUyxTQUFTb0IsTUFBTW9ILFNBQVNuSCxJQUFJLEdBQUcsVUFBVSxDQUFBMUMsTUFBSzRJLFNBQVM1SSxFQUFFc0UsT0FBT3dGLFVBQVUsQ0FBQyxHQUFHckgsT0FBT0MsSUFBSSxJQUFJRCxNQUFNc0gsT0FBTyxDQUFBL0YsTUFBS0EsTUFBTXRCLElBQUksQ0FBQyxLQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNJLEtBQS9PQSxNQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlRLENBQUU7QUFBQSxRQUFFLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHVIQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlJO0FBQUEsV0FBeG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ29CO0FBQUEsU0FWL3RCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVNHVCO0FBQUEsSUFBYSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQ21HLFFBQVEsT0FBTSwyQkFBMEIsY0FBYSxpQkFBZ0IsYUFBYSxhQUFhQSxRQUFRUSxVQUFVLEVBQUUsVUFBVXpFLEtBQUsxQyxJQUFJLDBHQUEwRyxTQUFTLE1BQU00RyxVQUFVLElBQUksR0FBRyxNQUFNUCxPQUFPN0osU0FBUyxPQUFPNkosT0FBTzNKLE9BQU8sV0FBVyxZQUFZO0FBQzNsQyxVQUFJLENBQUNpSyxPQUFRO0FBQ2IsWUFBTU4sT0FBT25DLFFBQVEsRUFBRUMsTUFBTSxFQUFFNkIsVUFBVVcsT0FBTy9ILEdBQUcsR0FBR3dFLFNBQVN1RCxPQUFPcEMsa0JBQWtCLENBQUM7QUFBQSxJQUM3RixLQUhzdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdwdkI7QUFBQSxPQTNCSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJIO0FBQ1I7QUFBQ3NCLElBdENlRCxVQUFRO0FBQUEsVUFDTTFNLFVBQ2JOLFFBQStCYSxjQUU3QmIsUUFDQUUsWUFDQUEsWUFDQUEsVUFBVTtBQUFBO0FBQUEsTUFQYjhNO0FBdUNULGdCQUFTa0MsWUFBWTtBQUFBQyxNQUFBO0FBQUUsUUFBTSxFQUFFckYsS0FBSyxJQUFJeEosU0FBUztBQUFHLFFBQU00TSxPQUFPbE4sT0FBTyxtQkFBbUIsRUFBRW1OLE9BQU90TSxhQUFhLGlCQUFpQixFQUFFLENBQUM7QUFBRyxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHFCQUFvQixVQUFTLDJHQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNKO0FBQUEsSUFBRSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJSyxTQUFTa04sT0FBTzlJLFVBQVUsNE1BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaVA7QUFBQSxJQUFRLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUscUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBTzRILE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2hKLFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0scUJBQW9CLE1BQU1nSixLQUFLaEosS0FBS0EsTUFBTSxRQUFRLENBQUFrTCxNQUFLQSxFQUFFcEosSUFBSSxTQUFTO0FBQUEsVUFDNXVCLEVBQUVxSSxLQUFLLFFBQVEzUSxPQUFPLGFBQWE0USxRQUFRQSxDQUFBYyxNQUFLM08sU0FBUzJPLEVBQUVDLFlBQVl2RixLQUFLeEMsUUFBUSxFQUFFO0FBQUEsVUFBRyxFQUFFK0csS0FBSyxTQUFTM1EsT0FBTyxtQkFBbUI0USxRQUFRQSxDQUFBYyxNQUFLLGVBQWVBLEVBQUVFLE9BQU8sR0FBRztBQUFBLFVBQUcsRUFBRWpCLEtBQUssVUFBVTNRLE9BQU8sWUFBWTRRLFFBQVFBLENBQUFjLE1BQUtBLEVBQUUvQyxPQUFPO0FBQUEsVUFBRyxFQUFFZ0MsS0FBSyxVQUFVM1EsT0FBTyxhQUFhNFEsUUFBUUEsQ0FBQWMsTUFBSyxHQUFHQSxFQUFFRyxTQUFTQyxJQUFJLG9CQUFvQkosRUFBRUcsU0FBU3ZKLEVBQUUsR0FBRztBQUFBLFVBQUcsRUFBRXFJLEtBQUssV0FBVzNRLE9BQU8sV0FBVzRRLFFBQVFBLENBQUFjLE1BQUtBLEVBQUVLLFFBQVE7QUFBQSxVQUFHLEVBQUVwQixLQUFLLFNBQVMzUSxPQUFPLGVBQWU0USxRQUFRQSxDQUFBYyxNQUFLLHVCQUFDLGNBQVcsU0FBUSxXQUFXQSxZQUFFTSxhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxFQUFjO0FBQUEsUUFBQyxLQURvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRXZwQjtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNeEMsS0FBS2hKLEtBQUtxQixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGdW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFcm5CLEtBRnFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWpqQjtBQUFBLFNBRm1nQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXRmO0FBQUEsT0FGbUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUUzRjtBQUFLO0FBQUM0SixJQUZqREQsV0FBUztBQUFBLFVBQXNCNU8sVUFBeUJOLFFBQW1DYSxZQUFZO0FBQUE7QUFBQSxNQUF2R3FPO0FBR1QsZ0JBQVNTLGNBQWM7QUFBQUMsTUFBQTtBQUMxQixRQUFNLEVBQUU5RixLQUFLLElBQUl4SixTQUFTO0FBQzFCLFFBQU11UCxTQUFTN1AsT0FBTyxrQkFBa0I7QUFDeEMsUUFBTThQLFdBQVc5UCxPQUFPLHVCQUF1QixFQUFFbU4sT0FBT3RNLGFBQWEscUJBQXFCLEVBQUUsQ0FBQztBQUM3RixRQUFNbUksT0FBTzlJLFdBQVcsdUJBQXVCLENBQUMsa0JBQWtCLENBQUM7QUFDbkUsUUFBTTZQLFNBQVM3UCxXQUFXLHdCQUF3QixDQUFDLHFCQUFxQixDQUFDO0FBQ3pFLFFBQU0sQ0FBQzhQLE1BQU1DLE9BQU8sSUFBSTdSLFNBQVMsRUFBRSxHQUFHLENBQUM4UixNQUFNQyxPQUFPLElBQUkvUixTQUFTLEVBQUUsR0FBRyxDQUFDZ1MsWUFBWUMsV0FBVyxJQUFJalMsU0FBUyxFQUFFLEdBQUcsQ0FBQ2tTLE1BQU1DLE9BQU8sSUFBSW5TLFNBQThCLFFBQVEsR0FBRyxDQUFDb1MsUUFBUUMsU0FBUyxJQUFJclMsU0FBUyxFQUFFLEdBQUcsQ0FBQytQLE1BQU11QyxPQUFPLElBQUl0UyxTQUFTLEtBQUssR0FBRyxDQUFDdVMsYUFBYUMsY0FBYyxJQUFJeFMsU0FBUyxLQUFLLEdBQUcsQ0FBQ3lTLGFBQWFDLGNBQWMsSUFBSTFTLFNBQVMsS0FBSyxHQUFHLENBQUMyUyxpQkFBaUJDLGtCQUFrQixJQUFJNVMsU0FBUyxLQUFLLEdBQUcsQ0FBQzZTLGFBQWFDLGNBQWMsSUFBSTlTLFNBQVMsRUFBRTtBQUN4YixRQUFNK1MsbUJBQW1COVEsT0FBTyxnQkFBZ0I7QUFDaEQsUUFBTSxDQUFDK1EscUJBQXFCQyxzQkFBc0IsSUFBSWpULFNBQVMsRUFBRSxHQUFHLENBQUNrVCxnQkFBZ0JDLGlCQUFpQixJQUFJblQsU0FBUyxFQUFFO0FBQ3JIRixZQUFVLE1BQU07QUFDWixVQUFNc1QsUUFBUXpNLE9BQU8wTSxXQUFXLE1BQU1GLGtCQUFrQkgsb0JBQW9CbkksS0FBSyxDQUFDLEdBQUcsR0FBRztBQUN4RixXQUFPLE1BQU1sRSxPQUFPMk0sYUFBYUYsS0FBSztBQUFBLEVBQzFDLEdBQUcsQ0FBQ0osbUJBQW1CLENBQUM7QUFDeEIsUUFBTU8sWUFBWTFSLFlBQVksaUJBQWlCLEVBQUVrTixPQUFPLEVBQUV5RSxHQUFHTixrQkFBa0I1QyxPQUFVLEVBQUUsR0FBR3lDLGdCQUFnQjtBQUM5RyxRQUFNVSx5QkFBeUI3UixPQUFPLGVBQWUsRUFBRXVMLE1BQU0sRUFBRTZFLFdBQVcsRUFBRSxHQUFHZSxvQkFBb0IsQ0FBQyxDQUFDZixVQUFVO0FBQy9HLFFBQU0wQixtQkFBbUJILFVBQVV6TixNQUFNQSxLQUFLc0QsS0FBSyxDQUFBdUssYUFBWUEsU0FBUy9MLE9BQU9vSyxVQUFVLEtBQUt5Qix1QkFBdUIzTixNQUFNQTtBQUMzSCxRQUFNdUcsU0FBU3pKLGtCQUFrQjtBQUFBLElBQzdCMEosVUFBVSxHQUFHWixLQUFLOUQsRUFBRTtBQUFBLElBQ3BCMkUsUUFBUWtGLE9BQU8zTCxPQUFPLEVBQUVzRyxTQUFTcUYsT0FBTzNMLEtBQUtBLEtBQUtzRyxTQUFTSSxRQUFRLEVBQUVvRixNQUFNSCxPQUFPM0wsS0FBS0EsS0FBSzhOLG1CQUFtQkMsU0FBUyxLQUFLLElBQUkvQixNQUFNTCxPQUFPM0wsS0FBS0EsS0FBS2dPLGlCQUFpQixFQUFFLElBQUl4RDtBQUFBQSxJQUMvSzdELE9BQU8sRUFBRW1GLE1BQU1FLEtBQUs7QUFBQSxJQUNwQnBGLE9BQU9BLENBQUFGLFdBQVU7QUFBRXFGLGNBQVFyRixPQUFPb0YsSUFBSTtBQUFHRyxjQUFRdkYsT0FBT3NGLElBQUk7QUFBQSxJQUFHO0FBQUEsSUFDL0RqSSxTQUFTQSxNQUFNNEgsT0FBTzlFLFFBQVEsRUFBRUMsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUN4RCxDQUFDO0FBQ0QsUUFBTW1ILGFBQWFwUixhQUFhMEosT0FBT1MsS0FBSztBQUM1QyxRQUFNa0gsWUFBWSxDQUFDLFFBQVF6RCxLQUFLcUIsSUFBSSxLQUFLcUMsT0FBT3JDLElBQUksSUFBSSxLQUFLcUMsT0FBT3JDLElBQUksSUFBSSxRQUFRLHlDQUF5QztBQUM3SCxRQUFNc0MsWUFBWS9SLGdCQUFnQjJQLEtBQUtqSCxLQUFLLENBQUMsSUFBSSxLQUFLMUksZ0JBQWdCMlAsSUFBSSxJQUFJLE1BQU8sc0NBQXNDO0FBQzNILFFBQU1xQyxpQkFBaUI1QixlQUFlSSxvQkFBb0IsQ0FBQyxDQUFDcUI7QUFDNUQsUUFBTUksaUJBQWlCM0IsZUFBZUUsb0JBQW9CLENBQUMsQ0FBQ3VCO0FBQzVELFFBQU1HLGFBQWEsWUFBWTtBQUMzQnpCLHVCQUFtQixJQUFJO0FBQ3ZCLFFBQUlvQixhQUFhRSxhQUFhLENBQUM3SCxPQUFPUyxNQUFPO0FBQzdDLFVBQU1DLFdBQVdWLE9BQU9XLFFBQVE7QUFBRyxRQUFJLENBQUNELFNBQVU7QUFDbEQsVUFBTTNDLFlBQVksRUFBRXdILE1BQU1FLEtBQUs7QUFDL0JnQixtQkFBZSxFQUFFO0FBQ2pCLFFBQUk7QUFDQSxZQUFNN0YsU0FBUyxNQUFNckMsS0FBS3NDLFFBQVEsRUFBRWQsU0FBU1csU0FBU1gsU0FBU3BHLE1BQU07QUFBQSxRQUNqRSxHQUFJK0csU0FBU0ssTUFBTXdFLFNBQVN0QixTQUFZLEVBQUVzRCxtQkFBbUJLLE9BQU9sSCxTQUFTSyxNQUFNd0UsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLFFBQzlGLEdBQUk3RSxTQUFTSyxNQUFNMEUsU0FBU3hCLFNBQVksRUFBRXdELGtCQUFrQi9HLFNBQVNLLE1BQU0wRSxLQUFLLElBQUksQ0FBQztBQUFBLE1BQ3pGLEVBQUUsQ0FBQztBQUNILFlBQU13QyxRQUFRakksT0FBT21CLFVBQVUsRUFBRXBCLFNBQVNhLE9BQU9uSCxLQUFLc0csU0FBU0ksUUFBUSxFQUFFb0YsTUFBTTNFLE9BQU9uSCxLQUFLOE4sbUJBQW1CQyxTQUFTLEtBQUssSUFBSS9CLE1BQU03RSxPQUFPbkgsS0FBS2dPLGlCQUFpQixFQUFFLEdBQUcxSixTQUFTO0FBQ2pMMEkscUJBQWV3QixRQUFRLHdDQUF3QywrREFBK0Q7QUFBQSxJQUNsSSxTQUFTNU8sT0FBTztBQUFFMkcsYUFBT29CLE9BQU8vSCxLQUFLO0FBQUEsSUFBRztBQUFBLEVBQzVDO0FBQ0EsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxxQ0FBb0MsVUFBUyxxR0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSztBQUFBLElBQUUsdUJBQUMsZUFBWSxTQUFTLEVBQUU4QyxJQUFJLE9BQU8rTCxJQUFJLFlBQVksR0FBRztBQUFBLDZCQUFDLFNBQU0sT0FBTSxzQkFBcUIsVUFBUyxTQUFRLGlDQUFDLGNBQVcsT0FBTzlDLFFBQVEsZ0JBQWUsV0FBVSxpQ0FBQyxjQUFXLFdBQVUsUUFBTyxLQUFLc0MsWUFBWSxVQUFVLENBQUE3SSxVQUFTO0FBQUVBLGNBQU1DLGVBQWU7QUFBRyxhQUFLa0osV0FBVztBQUFBLE1BQUcsR0FBRztBQUFBLCtCQUFDLGVBQVksT0FBT3pKLEtBQUtsRixTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUVrTSxNQUFNLHlCQUF5QkUsTUFBTSw4QkFBOEIsR0FBRyxNQUFNbEgsS0FBS3BGLFdBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0k7QUFBQSxRQUFHcU4sZUFBZSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVVBLHlCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFBVXBCLE9BQU8zTCxRQUFRLHVCQUFDLFVBQU8sT0FBTzJMLE9BQU8zTCxLQUFLQSxLQUFLdUMsVUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQUcsdUJBQUMsYUFBVSxPQUFNLHlCQUF3QixPQUFPdUosTUFBTSxRQUFRLE1BQU1ZLGVBQWUsSUFBSSxHQUFHLFVBQVUsQ0FBQTFMLE1BQUs7QUFBRStLLGtCQUFRL0ssRUFBRXNFLE9BQU9DLEtBQUs7QUFBR21ILHlCQUFlLElBQUk7QUFBR00seUJBQWUsRUFBRTtBQUFBLFFBQUcsR0FBRyxNQUFLLFVBQVMsWUFBWSxFQUFFMEIsS0FBSyxHQUFHQyxLQUFLLE9BQU9DLE1BQU0sRUFBRSxHQUFHLE9BQU9QLGVBQWUsWUFBWUEsZ0JBQWdCSCxZQUFZLDBDQUExUztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlWO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sK0JBQThCLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBT2xDLE1BQU0sUUFBUSxNQUFNWSxlQUFlLElBQUksR0FBRyxVQUFVLENBQUE1TCxNQUFLO0FBQUVpTCxrQkFBUWpMLEVBQUVzRSxPQUFPQyxLQUFLO0FBQUdxSCx5QkFBZSxJQUFJO0FBQUdJLHlCQUFlLEVBQUU7QUFBQSxRQUFHLEdBQUcsT0FBT3NCLGVBQWUsWUFBWUEsZ0JBQWdCRixZQUFZLHdDQUEzUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdUO0FBQUEsUUFBRSx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixNQUFLLFVBQVMsU0FBUSxhQUFZLE1BQU10SixLQUFLcEYsU0FBUyxVQUFVLENBQUNpTSxPQUFPM0wsUUFBUSxDQUFDdUcsT0FBT1MsU0FBU2xDLEtBQUtwRixXQUFXLENBQUMsQ0FBQ3dPLGFBQWEsQ0FBQyxDQUFDRSxXQUFXLHVDQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdOO0FBQUEsUUFBaUIsdUJBQUMsU0FBTSxVQUFTLFFBQU8sMEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxXQUFyN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2N0MsS0FBai9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOC9DLEtBQWpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThqRDtBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLHFCQUFvQixRQUFRLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVMsTUFBTTVCLFFBQVEsSUFBSSxHQUFHLDJCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGLEdBQW1CLGlDQUFDLGNBQVcsT0FBT1osVUFBVSxnQkFBZSxXQUFXQSxtQkFBUzVMLFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sMEJBQXlCLE1BQU00TCxTQUFTNUwsS0FBS0EsTUFBTSxRQUFRLENBQUFnRixNQUFLQSxFQUFFbEQsSUFBSSxTQUFTO0FBQUEsVUFDOWxFLEVBQUVxSSxLQUFLLFlBQVkzUSxPQUFPLFNBQVM0USxRQUFRQSxDQUFBcEYsTUFBSyxrQkFBa0JBLEVBQUVrSCxVQUFVLEdBQUc7QUFBQSxVQUFHLEVBQUUvQixLQUFLLFFBQVEzUSxPQUFPLFdBQVc0USxRQUFRQSxDQUFBcEYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVvSCxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQixFQUFHO0FBQUEsVUFBRyxFQUFFakMsS0FBSyxTQUFTM1EsT0FBTyxjQUFjNFEsUUFBUUEsQ0FBQXBGLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFekMsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsRUFBRztBQUFBLFVBQUcsRUFBRTRILEtBQUssVUFBVTNRLE9BQU8sU0FBUzRRLFFBQVFBLENBQUFwRixNQUFLQSxFQUFFc0gsT0FBTztBQUFBLFFBQUMsS0FEd3REO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFaGdFO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1WLFNBQVM1TCxLQUFLcUIsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFdBRjQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTE5RCxLQUZrNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU5NEQsS0FGNnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFaHZEO0FBQUEsU0FGb0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUU1RztBQUFBLElBQWMsdUJBQUMscUJBQWtCLFdBQVdvTSxVQUFVek4sTUFBTUEsUUFBUSxJQUFJLGtCQUFvQyxRQUFRNEYsS0FBSzlELE1BQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEc7QUFBQSxJQUM5TCx1QkFBQyxjQUFXLE1BQVksT0FBTSwyQkFBMEIsU0FBUyxNQUFNMEssUUFBUSxLQUFLLEdBQUcsTUFBTVgsT0FBT25NLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUN3TSxjQUFjN1AsZ0JBQWdCaVEsT0FBT3ZILEtBQUssQ0FBQyxJQUFJLEtBQUs4RyxPQUFPbk0sU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJO0FBQ3JQLGNBQU1tTSxPQUFPekUsUUFBUSxFQUFFbEgsTUFBTSxFQUFFa00sTUFBTUYsWUFBWUksT0FBTyxFQUFFLENBQUM7QUFDM0RFLGdCQUFRLEtBQUs7QUFBQSxNQUNqQixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcscUNBSndGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJbkUsR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT1gsT0FBT2pNLFNBQVM2TixVQUFVN04sU0FBUytOLHVCQUF1Qi9OLFNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU0sa0JBQWlCLE9BQU9zTixxQkFBcUIsVUFBVSxDQUFBbE0sTUFBS21NLHVCQUF1Qm5NLEVBQUVzRSxPQUFPQyxLQUFLLEdBQUcsVUFBVSxDQUFDMEgsa0JBQWtCLFlBQVcsZ0VBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeU47QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxjQUFhLFFBQU0sTUFBQyxPQUFPZixZQUFZLFVBQVUsQ0FBQWxMLE1BQUttTCxZQUFZbkwsRUFBRXNFLE9BQU9DLEtBQUssR0FBRyxVQUFVLENBQUMwSCxvQkFBcUJRLFVBQVVvQixhQUFhLENBQUNwQixVQUFVek4sTUFBUWtNO0FBQUFBLHdCQUFjLENBQUN1QixVQUFVek4sTUFBTUEsS0FBSzhPLEtBQUssQ0FBQWpCLGFBQVlBLFNBQVMvTCxPQUFPb0ssVUFBVSxLQUFLLHVCQUFDLFlBQVMsT0FBT0EsWUFBYTBCLDRCQUFrQnRELGdCQUFnQnFELHVCQUF1QmtCLFlBQVksNEJBQTRCM0MsZUFBL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkk7QUFBQSxVQUFhdUIsVUFBVXpOLE1BQU1BLEtBQUs0QyxJQUFJLENBQUE0QyxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUUxRCxJQUFLMEQsWUFBRThFLGVBQXRCOUUsRUFBRTFELElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlELENBQVc7QUFBQSxhQUFwZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNmO0FBQUEsUUFBWSx1QkFBQyxrQkFBZSxPQUFNLGNBQWEsYUFBYTJMLFVBQVVzQixhQUFhLFNBQVN0QixVQUFVdUIsU0FBUyxNQUFNdkIsVUFBVXdCLGVBQWUsWUFBWXhCLFVBQVV5QixZQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlLO0FBQUEsUUFBR3pCLFVBQVVyTCxXQUFXLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLGdCQUFNcUwsVUFBVTBCLHVCQUF1QjFCLFVBQVV5QixTQUFTLElBQUl6QixVQUFVNUcsUUFBUTtBQUFBLFFBQUksR0FBRyx1Q0FBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSjtBQUFBLFFBQVUsdUJBQUMsYUFBVSxPQUFNLGdCQUFlLFFBQU0sTUFBQyxPQUFPdUYsTUFBTSxVQUFVLENBQUFwTCxNQUFLcUwsUUFBUXJMLEVBQUVzRSxPQUFPQyxLQUFvQixHQUFHO0FBQUEsaUNBQUMsWUFBUyxPQUFNLFVBQVMsb0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUyxtQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxhQUEvTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBOO0FBQUEsUUFBWSx1QkFBQyxhQUFVLE9BQU0sNEJBQTJCLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBTytHLFFBQVEsVUFBVSxDQUFBdEwsTUFBS3VMLFVBQVV2TCxFQUFFc0UsT0FBT0MsS0FBSyxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsV0FBajZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbTZDO0FBQUEsU0FKdmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJb2tEO0FBQUEsT0FQMWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPdWtEO0FBQ2xsRDtBQUFDbUcsSUFuRGVELGFBQVc7QUFBQSxVQUNOclAsVUFDRk4sUUFDRUEsUUFBdUNhLGNBQzNDWCxZQUNFQSxZQUVVRyxRQU1QSixhQUNhRCxRQUVoQmdCLG1CQU9JRCxZQUFZO0FBQUE7QUFBQSxNQXZCbkI0TztBQXFEaEIsTUFBTTJELHFCQUFxQjtBQUMzQixNQUFNQyx1QkFBdUI7QUFDN0IsU0FBU0Msa0JBQWtCLEVBQUU3QixXQUFXUixrQkFBa0J6SixPQUFvRixHQUFHO0FBQUErTCxNQUFBO0FBQzdJLFFBQU1DLGNBQWN6VCxZQUFZLHdCQUF3QixFQUFFa04sT0FBT3RNLGFBQWEsc0JBQXNCLEVBQUUsQ0FBQztBQUN2RyxRQUFNOFMsZ0JBQWdCMVQsWUFBWSxpQ0FBaUMsRUFBRWtOLE9BQU90TSxhQUFhLCtCQUErQixFQUFFLENBQUM7QUFDM0gsUUFBTStTLGtCQUFrQjFULFdBQVcsa0NBQWtDLENBQUMsK0JBQStCLENBQUM7QUFDdEcsUUFBTSxDQUFDMlQsb0JBQW9CQyxxQkFBcUIsSUFBSTFWLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUMyVixTQUFTQyxVQUFVLElBQUk1VixTQUF3QyxXQUFXO0FBQ2pGLFFBQU0sQ0FBQzZWLFNBQVNDLFVBQVUsSUFBSTlWLFNBQVMsS0FBSztBQUM1QyxRQUFNZ1MsYUFBYXVCLFVBQVVxQixLQUFLLENBQUFqQixjQUFZQSxVQUFTL0wsT0FBTzZOLGtCQUFrQixJQUFJQSxxQkFBcUJsQyxVQUFVLENBQUMsR0FBRzNMLE1BQU07QUFDN0gsUUFBTStMLFdBQVdKLFVBQVVuSyxLQUFLLENBQUEyTSxjQUFhQSxVQUFVbk8sT0FBT29LLFVBQVU7QUFDeEUsUUFBTWdFLFdBQVdyQyxVQUFVc0Msa0JBQWtCO0FBQzdDLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3RCLEVBQUU3SyxPQUFPLGFBQXNCL0wsT0FBTyxhQUFhNlcsV0FBV2hILFFBQVF3RSxVQUFVeUMsZ0JBQWdCLEVBQUU7QUFBQSxJQUNsRyxFQUFFL0ssT0FBTyxPQUFnQi9MLE9BQU8sT0FBTzZXLFdBQVdoSCxRQUFRd0UsVUFBVTBDLFNBQVMsQ0FBQ0wsU0FBU3JGLFNBQVMsT0FBTyxDQUFDLEVBQUU7QUFBQSxJQUMxRyxFQUFFdEYsT0FBTyxTQUFrQi9MLE9BQU8sU0FBUzZXLFdBQVdoSCxRQUFRd0UsVUFBVW5FLFNBQVMsQ0FBQ3dHLFNBQVNyRixTQUFTLE9BQU8sQ0FBQyxFQUFFO0FBQUEsRUFBQyxFQUNqSEUsT0FBTyxDQUFBeUYsU0FBUUEsS0FBS0gsU0FBUztBQUMvQixRQUFNSSxrQkFBa0JMLGtCQUFrQjlNLEtBQUssQ0FBQWtOLFNBQVFBLEtBQUtqTCxVQUFVc0ssT0FBTyxHQUFHdEssU0FBUzZLLGtCQUFrQixDQUFDLEdBQUc3SyxTQUFTc0s7QUFDeEgsUUFBTWEscUJBQXFCTixrQkFBa0J0QixLQUFLLENBQUEwQixTQUFRQSxLQUFLakwsVUFBVWtMLGVBQWU7QUFDeEYsUUFBTUUsd0JBQXdCLFlBQVk7QUFDdEMsUUFBSSxDQUFDekUsY0FBYyxDQUFDZSxvQkFBb0IsQ0FBQ3lELG1CQUFvQjtBQUM3RCxRQUFJO0FBQ0EsWUFBTWhCLGdCQUFnQnRJLFFBQVEsRUFBRUMsTUFBTSxFQUFFNkUsV0FBVyxHQUFHaE0sTUFBTSxFQUFFMFEsU0FBUyxhQUFhZixTQUFTWSxpQkFBaUJJLFNBQVN4QixzQkFBc0J5QixnQkFBZ0IxQixtQkFBbUIsRUFBRSxDQUFDO0FBQ25MWSxpQkFBVyxJQUFJO0FBQ2YsWUFBTWUsUUFBUUMsSUFBSSxDQUFDdkIsY0FBYzVJLFFBQVEsR0FBRzJJLFlBQVkzSSxRQUFRLENBQUMsQ0FBQztBQUFBLElBQ3RFLFFBQ007QUFBQSxJQUFFO0FBQUEsRUFDWjtBQUNBLFNBQU8sdUJBQUMsU0FBTSxPQUFNLHFDQUFvQyxXQUFVLFdBQVUsVUFBUyxTQUNqRixpQ0FBQyxjQUNHO0FBQUEsMkJBQUMsU0FBTSxVQUFTLFFBQU8sOE9BQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcVA7QUFBQSxJQUNwUG9HLG1CQUFtQixtQ0FDaEI7QUFBQSw2QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGNBQWEsT0FBT2YsWUFBWSxVQUFVLENBQUE5RyxVQUFTO0FBQUV3Syw4QkFBc0J4SyxNQUFNRSxPQUFPQyxLQUFLO0FBQUd5SyxtQkFBVyxLQUFLO0FBQUEsTUFBRyxHQUFHLFVBQVUsQ0FBQ25DLFVBQ3BKSixvQkFBVTdLLElBQUksQ0FBQTROLFNBQVEsdUJBQUMsWUFBdUIsT0FBT0EsS0FBSzFPLElBQUswTyxlQUFLbEcsZUFBL0JrRyxLQUFLMU8sSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRCxDQUFXLEtBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxxQkFBb0IsT0FBTzJPLGlCQUFpQixVQUFVLENBQUFyTCxVQUFTO0FBQUUwSyxtQkFBVzFLLE1BQU1FLE9BQU9DLEtBQXVCO0FBQUd5SyxtQkFBVyxLQUFLO0FBQUEsTUFBRyxHQUFHLFVBQVUsQ0FBQ0ksa0JBQWtCL04sUUFDekwrTiw0QkFBa0J4TixJQUFJLENBQUE0TixTQUFRLHVCQUFDLFlBQTBCLE9BQU9BLEtBQUtqTCxPQUFRaUwsZUFBS2hYLFNBQXJDZ1gsS0FBS2pMLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQsQ0FBVyxLQUR4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGNBQVcsT0FBTyxhQUFhNkosa0JBQWtCLElBQUtDLGtDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFDM0UsQ0FBQ2Usa0JBQWtCL04sVUFBVSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxzRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRjtBQUFBLE1BQzlHLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVEsYUFBWSxNQUFNcU4sZ0JBQWdCaFEsU0FBUyxVQUFVLENBQUN3TSxjQUFjLENBQUN3RSxzQkFBc0IsQ0FBQ3pELGtCQUFrQixTQUFTLE1BQU0sS0FBSzBELHNCQUFzQixHQUFHLHdDQUEvTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVPO0FBQUEsTUFDdk8sdUJBQUMsZUFBWSxPQUFPakIsZ0JBQWdCOVAsU0FBUzRQLFlBQVk1UCxTQUFTNlAsY0FBYzdQLFNBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxNQUNyRm1RLFdBQVcsdUJBQUMsU0FBTSxVQUFTLFdBQVUsTUFBSyxVQUFTLCtGQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVIO0FBQUEsU0FYbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlwQixJQUFNLHVCQUFDLFNBQU0sVUFBUyxXQUFVLGlHQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJHO0FBQUEsSUFDakgsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyw0QkFDaEM7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssd0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxjQUFXLE9BQU9QLGFBQWEsZ0JBQWUsV0FBV0Esc0JBQVl4UCxRQUFRLG1DQUMxRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSw4QkFBNkIsTUFBTXdQLFlBQVl4UCxLQUFLQSxNQUFNLFFBQVEsQ0FBQWlSLFdBQVVBLE9BQU9uUCxJQUFJLFNBQVM7QUFBQSxVQUM3RyxFQUFFcUksS0FBSyxZQUFZM1EsT0FBTyxTQUFTNFEsUUFBUUEsQ0FBQTZHLFdBQVUsa0JBQWtCQSxPQUFPL0UsVUFBVSxHQUFHO0FBQUEsVUFDM0YsRUFBRS9CLEtBQUssV0FBVzNRLE9BQU8sWUFBWTRRLFFBQVFBLENBQUE2RyxXQUFVeFgsY0FBY3dYLE9BQU9MLE9BQU8sRUFBRTtBQUFBLFVBQ3JGLEVBQUV6RyxLQUFLLFdBQVczUSxPQUFPLFFBQVE0USxRQUFRQSxDQUFBNkcsV0FBVXhYLGNBQWN3WCxPQUFPcEIsT0FBTyxFQUFFO0FBQUEsVUFDakYsRUFBRTFGLEtBQUssVUFBVTNRLE9BQU8sY0FBYzRRLFFBQVFBLENBQUE2RyxXQUFVLHVCQUFDLFVBQU8sT0FBT0EsT0FBTzFPLFFBQVEsUUFBTyxhQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxFQUFHO0FBQUEsVUFDekcsRUFBRTRILEtBQUssV0FBVzNRLE9BQU8sYUFBYTRRLFFBQVFBLENBQUE2RyxXQUFVQSxPQUFPM0ssUUFBUTtBQUFBLFVBQ3ZFLEVBQUU2RCxLQUFLLFlBQVkzUSxPQUFPLHVCQUF1QjRRLFFBQVFBLENBQUE2RyxXQUFVO0FBQUUsa0JBQU1DLFNBQVNELE9BQU9FLFFBQVFDLEdBQUcsRUFBRTtBQUFHLG1CQUFPRixTQUFTLEdBQUd6WCxjQUFjeVgsT0FBTy9JLFFBQVEsU0FBUyxDQUFDLE1BQU0rSSxPQUFPRyxZQUFZLE1BQU1ILE9BQU9JLHFCQUFxQixHQUFHLEtBQUs7QUFBQSxVQUFXLEVBQUU7QUFBQSxRQUFDLEtBTjFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPRTtBQUFBLFFBQ0YsdUJBQUMsU0FBTSxNQUFNOUIsWUFBWXhQLEtBQUtxQixRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsV0FUdUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVU5RSxLQVZBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVSTtBQUFBLFNBWlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFDQSx1QkFBQyxjQUFXLE1BQUssU0FBUSxjQUFXLDZCQUNoQztBQUFBLDZCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyx5Q0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2pFLHVCQUFDLGNBQVcsT0FBT29PLGVBQWUsZ0JBQWUsV0FBV0Esd0JBQWN6UCxRQUFRLG1DQUM5RTtBQUFBLCtCQUFDLGFBQVUsT0FBTSw2QkFBNEIsTUFBTXlQLGNBQWN6UCxLQUFLQSxNQUFNLFFBQVEsQ0FBQXVSLGNBQWFBLFVBQVV6UCxJQUFJLFNBQVM7QUFBQSxVQUNwSCxFQUFFcUksS0FBSyxZQUFZM1EsT0FBTyxTQUFTNFEsUUFBUUEsQ0FBQW1ILGNBQWEsa0JBQWtCQSxVQUFVckYsVUFBVSxHQUFHO0FBQUEsVUFDakcsRUFBRS9CLEtBQUssV0FBVzNRLE9BQU8sWUFBWTRRLFFBQVFBLENBQUFtSCxjQUFhOVgsY0FBYzhYLFVBQVVYLE9BQU8sRUFBRTtBQUFBLFVBQzNGLEVBQUV6RyxLQUFLLFdBQVczUSxPQUFPLFFBQVE0USxRQUFRQSxDQUFBbUgsY0FBYTlYLGNBQWM4WCxVQUFVMUIsT0FBTyxFQUFFO0FBQUEsVUFDdkYsRUFBRTFGLEtBQUssVUFBVTNRLE9BQU8sV0FBVzRRLFFBQVFBLENBQUFtSCxjQUFhQSxVQUFVcEosV0FBVyxhQUFhLG9CQUFvQixxQkFBcUI7QUFBQSxVQUNuSSxFQUFFZ0MsS0FBSyxVQUFVM1EsT0FBTyxjQUFjNFEsUUFBUUEsQ0FBQW1ILGNBQWEsdUJBQUMsVUFBTyxPQUFPQSxVQUFVaFAsUUFBUSxRQUFPLGFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlELEVBQUc7QUFBQSxVQUMvRyxFQUFFNEgsS0FBSyxXQUFXM1EsT0FBTyxXQUFXNFEsUUFBUUEsQ0FBQW1ILGNBQWFoVixTQUFTZ1YsVUFBVUMsV0FBVyxrQkFBa0IsRUFBRTtBQUFBLFFBQUMsS0FOaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9FO0FBQUEsUUFDRix1QkFBQyxTQUFNLE1BQU0vQixjQUFjelAsS0FBS3FCLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxXQVR5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVWxGLEtBVkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVJO0FBQUEsU0FaUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUNDNEwsb0JBQW9CLHVCQUFDLFVBQU8sV0FBVzVTLFlBQVksSUFBSSxNQUFNbUosTUFBTSxjQUFjLE1BQUssU0FBUSxJQUFJLEVBQUVpTyxXQUFXLGFBQWEsR0FBRyxrQ0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2SDtBQUFBLE9BM0N0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNENBLEtBN0NHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4Q1A7QUFDSjtBQUFDbEMsSUF6RVFELG1CQUFpQjtBQUFBLFVBQ0Z2VCxhQUE2Q1ksY0FDM0NaLGFBQXNEWSxjQUNwRFgsVUFBVTtBQUFBO0FBQUEsTUFIN0JzVDtBQTBFVCxTQUFTb0Msc0JBQXNCbk0sT0FBbUQ7QUFDOUUsTUFBSTtBQUFFckosaUJBQXlDLDhCQUE4QnFKLEtBQUs7QUFBRyxXQUFPQTtBQUFBQSxFQUFPLFFBQzdGO0FBQUUsV0FBTztBQUFBLEVBQU07QUFDekI7QUFDTyxnQkFBU29NLDBCQUEwQjtBQUFBQyxNQUFBO0FBQ3RDLFFBQU0sQ0FBQ25TLE1BQU0sSUFBSS9FLGdCQUFnQjtBQUNqQyxRQUFNaUcsWUFBV3BHLFlBQVk7QUFDN0IsUUFBTXVKLFdBQVd0SixZQUFZO0FBQzdCLFFBQU1xWCxRQUFRcFMsT0FBT1csSUFBSSxPQUFPLEtBQUs7QUFDckMsUUFBTSxDQUFDbVIsV0FBV08sWUFBWSxJQUFJNVgsU0FBNEMsTUFBTXdYLHNCQUF1Qi9RLFVBQVNvUixPQUFpREMsZ0JBQWdCLENBQUM7QUFDdEwsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUloWSxTQUFxQyxJQUFJO0FBQ2pGLFFBQU0sQ0FBQzBGLE9BQU9DLFFBQVEsSUFBSTNGLFNBQXVCLElBQUk7QUFDckQsUUFBTSxDQUFDd0YsU0FBU0MsVUFBVSxJQUFJekYsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2lZLG1CQUFtQkMsb0JBQW9CLElBQUlsWSxTQUFzQyxJQUFJO0FBQzVGLFFBQU1tWSxhQUFhcFksT0FBT3FZLE9BQU9DLFdBQVcsQ0FBQztBQUM3QyxRQUFNQyxpQkFBaUJ2WSxPQUErRCxJQUFJO0FBQzFGLFFBQU13WSxXQUFXLFlBQVk7QUFDekIsUUFBSSxDQUFDWixTQUFTblMsUUFBUztBQUN2QkMsZUFBVyxJQUFJO0FBQUdFLGFBQVMsSUFBSTtBQUMvQixRQUFJO0FBQ0EsWUFBTUUsT0FBTyxNQUFNbkUsUUFBUSxjQUFjO0FBQ3pDQyxtQkFBYWtFLEtBQUtDLEtBQUtDLFNBQVM7QUFDaEMsWUFBTWtILFNBQVMsTUFBTXZMLFFBQVEsNEJBQTRCLEVBQUVzRSxNQUFNLEVBQUUyUixNQUFNLEdBQUdhLGdCQUFnQkwsV0FBVzFOLFFBQVEsQ0FBQztBQUNoSG1OLG1CQUFhM0ssT0FBT25ILElBQUk7QUFDeEI4RCxlQUFTLG9CQUFvQixFQUFFNk8sU0FBUyxNQUFNWixPQUFPLEVBQUVDLGtCQUFrQjdLLE9BQU9uSCxLQUFLLEVBQUUsQ0FBQztBQUFBLElBQzVGLFNBQ09zTSxRQUFRO0FBQUV6TSxlQUFTeU0sa0JBQWtCMUwsUUFBUTBMLFNBQVMsSUFBSTFMLE1BQU0sK0JBQStCLENBQUM7QUFBQSxJQUFHLFVBQUM7QUFDakdqQixpQkFBVyxLQUFLO0FBQUEsSUFBRztBQUFBLEVBQ2pDO0FBQ0EsUUFBTWlULFVBQVUsT0FBT0MsYUFBbUM7QUFDdEQsUUFBSSxDQUFDdEIsYUFBYTdSLFdBQVd1UyxnQkFBaUJFLHFCQUFxQkEsc0JBQXNCVSxTQUFXO0FBQ3BHLFVBQU1DLFNBQVNOLGVBQWU3TixTQUFTa08sYUFBYUEsV0FBV0wsZUFBZTdOLFVBQVUsRUFBRWtPLFVBQVUxSSxLQUFLbUksT0FBT0MsV0FBVyxFQUFFO0FBQzdIQyxtQkFBZTdOLFVBQVVtTztBQUN6QlYseUJBQXFCUyxRQUFRO0FBQUdsVCxlQUFXLElBQUk7QUFBR0UsYUFBUyxJQUFJO0FBQy9ELFFBQUk7QUFDQSxZQUFNc0gsU0FBUyxNQUFNdkwsUUFBUSwyQkFBMkIsRUFBRXNFLE1BQU0sRUFBRTZTLG9CQUFvQnhCLFVBQVV3QixvQkFBb0JGLFVBQVUvQixnQkFBZ0JTLFVBQVVULGVBQWUsR0FBRzRCLGdCQUFnQkksT0FBTzNJLElBQUksQ0FBQztBQUN0TStILHNCQUFnQi9LLE9BQU9uSCxJQUFJO0FBQUEsSUFDL0IsU0FDT3NNLFFBQVE7QUFBRXpNLGVBQVN5TSxrQkFBa0IxTCxRQUFRMEwsU0FBUyxJQUFJMUwsTUFBTSx3REFBd0QsQ0FBQztBQUFBLElBQUcsVUFBQztBQUMxSGpCLGlCQUFXLEtBQUs7QUFBQSxJQUFHO0FBQUEsRUFDakM7QUFDQSxRQUFNcVQsYUFBYXpCLFdBQVdwSixXQUFXO0FBQ3pDLFFBQU04SyxzQkFBc0JoQixlQUN0QkEsYUFBYWlCLGtCQUFrQixjQUMzQixxR0FDQWpCLGFBQWExUCxXQUFXLGFBQ3BCLGtGQUNBLGtDQUNSO0FBQ04sU0FBTyx1QkFBQyxPQUFJLFdBQVUsUUFBTyxJQUFHLGdCQUFlLFVBQVUsSUFBSSxJQUFJLENBQUN2RixTQUFTbUIsTUFBTXFFLG1CQUFtQixFQUFFOUQsVUFBVSxLQUFLK0QsSUFBSSxRQUFRbkUsU0FBUyxPQUFPLENBQUMsR0FDOUk7QUFBQSwyQkFBQyxjQUFXLE9BQU0sK0JBQThCLFVBQVMsb0VBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUg7QUFBQSxJQUN6SCx1QkFBQyxTQUFNLE9BQU9pVCxZQUFZeUIsYUFBYSw2QkFBNkIsZ0NBQWdDLHFCQUFxQixVQUFTLFNBQzlILGlDQUFDLGNBQ0c7QUFBQSw2QkFBQyxTQUFNLFVBQVMsUUFBTyxnSEFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1SDtBQUFBLE1BQ3RIcFQsU0FBUyx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQjtBQUFBLE1BQ25DLENBQUMyUixhQUFhTSxTQUFTLG1DQUNwQjtBQUFBLCtCQUFDLGNBQVcsT0FBTSxrQkFBaUIsOEhBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUo7QUFBQSxRQUNqSix1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTLE1BQU0sS0FBS1ksU0FBUyxHQUFHLFVBQVUvUyxTQUFVQSxvQkFBVSxtQkFBbUJFLFFBQVEscUJBQXFCLDBCQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlLO0FBQUEsV0FGN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUd4QjtBQUFBLE1BQ0MsQ0FBQzJSLGFBQWEsQ0FBQ00sU0FBUyx1QkFBQyxTQUFNLFVBQVMsV0FBVSx5RkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRztBQUFBLE1BQzNITixhQUFhLG1DQUNWO0FBQUEsK0JBQUMsY0FBVyxPQUFNLFlBQVcseUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxjQUFXLE9BQU0sUUFBUTlYLHdCQUFjOFgsVUFBVTFCLE9BQU8sS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFFBQzNELHVCQUFDLGNBQVcsT0FBTSxtQkFBbUIwQixvQkFBVVYsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLGNBQVcsT0FBTSxzQkFBcUI7QUFBQTtBQUFBLFVBQUVVLFVBQVVUO0FBQUFBLGFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNsRSx1QkFBQyxjQUFXLE9BQU0sV0FBV3ZVLG1CQUFTZ1YsVUFBVUMsV0FBVyxrQkFBa0IsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBQzlFUyxlQUFlLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBVWdCLGlDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZELElBQVcsdUJBQUMsZUFDckY7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsYUFBWSxTQUFTLE1BQU0sS0FBS0wsUUFBUSxRQUFRLEdBQUcsVUFBVWxULFdBQVd5UyxzQkFBc0IsV0FBWXpTLHFCQUFXeVMsc0JBQXNCLFdBQVcsbUJBQW1CQSxzQkFBc0IsV0FBVywwQkFBMEJhLGFBQWEsNkJBQTZCLDJCQUE5UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzVDtBQUFBLFVBQ3RULHVCQUFDLFVBQU8sU0FBUSxZQUFXLFNBQVMsTUFBTSxLQUFLSixRQUFRLFNBQVMsR0FBRyxVQUFVbFQsV0FBV3lTLHNCQUFzQixVQUFXelMscUJBQVd5UyxzQkFBc0IsWUFBWSxtQkFBbUJBLHNCQUFzQixZQUFZLDBCQUEwQmEsYUFBYSx3QkFBd0IsNEJBQTFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1UO0FBQUEsYUFGL047QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd4RjtBQUFBLFdBVFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVkO0FBQUEsTUFDQ3ZTLFlBQVksdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsK0lBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0w7QUFBQSxTQW5Cck07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQSxLQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsT0F4Qkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCUDtBQUNKO0FBQUNtUixJQXZFZUQseUJBQXVCO0FBQUEsVUFDbEJqWCxpQkFDQUgsYUFDQUMsV0FBVztBQUFBO0FBQUEsTUFIaEJtWDtBQXdFVCxnQkFBU3dCLFVBQVU7QUFBQUMsTUFBQTtBQUN0QixRQUFNLEVBQUVDLFFBQVEsR0FBRyxJQUFJNVksVUFBVTtBQUNqQyxRQUFNLEVBQUVtTCxLQUFLLElBQUl4SixTQUFTO0FBQzFCLFFBQU1nRSxNQUFNdEUsT0FBTyxVQUFVLEVBQUV1TCxNQUFNLEVBQUVnTSxNQUFNLEVBQUUsQ0FBQztBQUNoRCxRQUFNQyxNQUFNbFQsSUFBSUosTUFBTUE7QUFDdEIsUUFBTXVULGVBQWVELEtBQUtFLGNBQWM5Vyx1QkFBdUI0VyxJQUFJRSxhQUFhN1MsU0FBU0QsUUFBUUQsUUFBUSxJQUFJO0FBQzdHLFFBQU1nVCxZQUFZSCxLQUFLL1E7QUFDdkIsUUFBTSxFQUFFc0UsUUFBUSxJQUFJekc7QUFDcEJwRyxZQUFVLE1BQU07QUFBRSxRQUFJLENBQUN5WixhQUFhLENBQUMsQ0FBQyxVQUFVLFNBQVMsRUFBRTVJLFNBQVM0SSxTQUFTO0FBQ3pFO0FBQVEsVUFBTW5HLFFBQVFvRyxZQUFZLE1BQU0sS0FBSzdNLFFBQVEsR0FBRyxHQUFJO0FBQUcsV0FBTyxNQUFNOE0sY0FBY3JHLEtBQUs7QUFBQSxFQUFHLEdBQUcsQ0FBQ21HLFdBQVc1TSxPQUFPLENBQUM7QUFDN0gsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTyxhQUFhd00sS0FBSyxJQUFJLFVBQVMseUVBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUg7QUFBQSxJQUFFLHVCQUFDLGNBQVcsT0FBT2pULEtBQUssZ0JBQWUsV0FBV2tULGlCQUFPLHVCQUFDLFNBQU0sT0FBTSxpQkFBZ0IsVUFBUyxTQUFRLGlDQUFDLGNBQVk7QUFBQSw2QkFBQyxVQUFPLE9BQU9BLElBQUkvUSxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU0sUUFBUTlJLHdCQUFjNlosSUFBSWxILElBQUksS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFdBQVdrSDtBQUFBQSxZQUFJTTtBQUFBQSxRQUFVO0FBQUEsUUFBSU4sSUFBSU8sU0FBUztBQUFBLFdBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxPQUFPUCxjQUFJUSxjQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sWUFBWXZYLG1CQUFTK1csSUFBSVMsV0FBV25PLEtBQUt4QyxRQUFRLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUFja1EsSUFBSVUsVUFBVTNSLFNBQVMsS0FBSyx1QkFBQyxhQUFVLE9BQU0scUJBQW9CLE1BQU1pUixJQUFJVSxXQUFXLFFBQVEsQ0FBQWhULE1BQUssR0FBR0EsRUFBRWlULEdBQUcsSUFBSWpULEVBQUVrVCxLQUFLLElBQUlsVCxFQUFFbVQsSUFBSSxJQUFJLFNBQVMsQ0FBQyxFQUFFaEssS0FBSyxPQUFPM1EsT0FBTyxRQUFRNFEsUUFBUUEsQ0FBQXBKLE1BQUtBLEVBQUVpVCxJQUFJLEdBQUcsRUFBRTlKLEtBQUssU0FBUzNRLE9BQU8sVUFBVTRRLFFBQVFBLENBQUFwSixNQUFLQSxFQUFFa1QsTUFBTSxHQUFHLEVBQUUvSixLQUFLLFdBQVczUSxPQUFPLE9BQU80USxRQUFRQSxDQUFBcEosTUFBS0EsRUFBRTZQLFFBQVEsQ0FBQyxLQUF0UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdSO0FBQUEsTUFBRyx1QkFBQyxVQUFPLFNBQVMsTUFBTSxLQUFLelEsSUFBSXlHLFFBQVEsR0FBRyxTQUFRLFlBQVcsNEJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEU7QUFBQSxNQUFVeU0sSUFBSUUsZUFBZSxDQUFDLGFBQWEsU0FBUyxFQUFFM0ksU0FBU3lJLElBQUkvUSxNQUFNLEtBQUtnUixnQkFBZ0IsdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNMVMsT0FBT29KLEtBQUtzSixjQUFjLFVBQVUscUJBQXFCLEdBQUcsK0JBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxNQUFXRCxJQUFJRSxlQUFlLENBQUMsYUFBYSxTQUFTLEVBQUUzSSxTQUFTeUksSUFBSS9RLE1BQU0sS0FBSyxDQUFDZ1IsZ0JBQWdCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHVFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsTUFBVUQsSUFBSS9RLFdBQVcsMkJBQTJCLHVCQUFDLGFBQVUsSUFBSSxNQUFNcUQsS0FBSzlELEVBQUUsWUFBWXdSLElBQUl4UixFQUFFLElBQUksb0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxTQUFyc0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrdEMsS0FBaHdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNndDLEtBQXQwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQSswQztBQUFBLE9BQTE4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXU5QztBQUNsK0M7QUFBQ3NSLElBWGVELFNBQU87QUFBQSxVQUNJMVksV0FDTjJCLFVBQ0xOLE1BQU07QUFBQTtBQUFBLE9BSE5xWDtBQUFPLElBQUEvVCxJQUFBZ1YsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQWxNLEtBQUFtTSxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUF6VixJQUFBO0FBQUEsYUFBQWdWLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBbE0sS0FBQTtBQUFBLGFBQUFtTSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLE1BQUEiLCJuYW1lcyI6WyJsYWJlbCIsImJ1c2luZXNzTGFiZWwiLCJBY3Rpb25Hcm91cCIsIkZpZWxkR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU2VjdGlvbkdyaWQiLCJTdXJmYWNlQ29udGVudCIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJMaW5rIiwiUm91dGVyTGluayIsIk5hdmlnYXRlIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJBbGVydCIsIkF2YXRhciIsIkJveCIsIkJ1dHRvbiIsIkNoZWNrYm94IiwiRm9ybUNvbnRyb2xMYWJlbCIsIk1lbnVJdGVtIiwiUGFwZXIiLCJTdGFjayIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJTbWFydFRveVJvdW5kZWQiLCJBcnJvd0ZvcndhcmRSb3VuZGVkIiwicGVybWlzc2lvbkNhdGFsb2ciLCJjb2xvcnMiLCJyZXF1ZXN0Iiwic2V0Q3NyZlRva2VuIiwidXNlQXBpIiwidXNlUGFnZWRBcGkiLCJ1c2VDb21tYW5kIiwiQXBpRXJyb3IiLCJhc3NlcnRTY2hlbWEiLCJ1c2VDYW4iLCJ1c2VTY29wZSIsImNvZGVQb2ludExlbmd0aCIsImxpbWl0Q29kZVBvaW50cyIsImRhdGVUaW1lIiwic2FmZUludGVybmFsUGF0aCIsImlzVmFsaWRUaW1lWm9uZSIsImF1dGhvcml6ZWREb3dubG9hZEhyZWYiLCJ1c2VMaXN0UXVlcnkiLCJtYXJrRHJhZnRDbGVhbiIsInVzZURyYWZ0Rm9ybSIsInVzZVZlcnNpb25lZERyYWZ0IiwiRHJhZnRDb25mbGljdCIsImxheW91dFN4IiwiUGFnZUhlYWRlciIsIlBhbmVsIiwiUXVlcnlTdGF0ZSIsIkRhdGFUYWJsZSIsIlRvb2xiYXIiLCJQYWdlciIsIlN0YXR1cyIsIk11dGF0aW9uQnV0dG9uIiwiRWRpdERpYWxvZyIsIkVycm9yTm90aWNlIiwiQ29uZmlybURpYWxvZyIsIlJvdXRlTGluayIsIkRldGFpbExpbmUiLCJMb29rdXBMb2FkTW9yZSIsIkVtcHR5IiwidXNlU2Vzc2lvbiIsIkF1dGhDYXJkIiwiY2hpbGRyZW4iLCJzaGVsbCIsImNlbnRlcmVkRmFsbGJhY2siLCJiZ2NvbG9yIiwib3V0bGluZSIsImF1dGgiLCJzdXJmYWNlSW5zZXQiLCJ3aWR0aCIsIm1heFdpZHRoIiwiYm9yZGVyUmFkaXVzIiwicmFkaXVzIiwiaGVybyIsImJyYW5kTWFya0dhcCIsImNvbG9yIiwib25BY2NlbnQiLCJ0eXBvZ3JhcGh5IiwiZm9udFdlaWdodCIsImV4dHJhQm9sZCIsIl9jIiwiTG9naW5QYWdlIiwiX3MiLCJzZXNzaW9uIiwibG9hZGluZyIsInBhcmFtcyIsInBlbmRpbmciLCJzZXRQZW5kaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvZ2luIiwiY3NyZiIsImRhdGEiLCJjc3JmVG9rZW4iLCJib2R5IiwicmV0dXJuVG8iLCJnZXQiLCJ1cmwiLCJVUkwiLCJhdXRob3JpemF0aW9uVXJsIiwicHJvdG9jb2wiLCJfX01PQ0tfXyIsIm9yaWdpbiIsImxvY2F0aW9uIiwiRXJyb3IiLCJ3aW5kb3ciLCJhc3NpZ24iLCJocmVmIiwiZSIsImJyYW5kVGl0bGVHYXAiLCJwYWdlSGVhZGVyIiwidGl0bGVEZXNjcmlwdGlvbkdhcCIsImFmdGVyR2FwIiwicGFnZSIsInNlY3Rpb25CZWZvcmUiLCJkaXNwbGF5IiwiV29ya3NwYWNlc1BhZ2UiLCJfczIiLCJzZXNzaW9uRXJyb3IiLCJzaG9wcyIsInF1ZXJ5S2V5IiwidXNlciIsImlkIiwicXVlcnlGbiIsInNpZ25hbCIsImVuYWJsZWQiLCJyZXRyeSIsImlzRW1wdHkiLCJpc0Vycm9yIiwibGVuZ3RoIiwiY3JlYXRlU2hvcEJ1dHRvbiIsInN0YXR1cyIsInBhZ2VGYWxsYmFja0luc2V0IiwibXgiLCJ4cyIsIm1kIiwibWFwIiwicyIsInN1cmZhY2UiLCJpbnNldCIsImxhcmdlIiwic2VsZWN0ZWQiLCJuYW1lIiwiY3VycmVuY3kiLCJ0aW1lem9uZSIsIm1lbWJlcnNoaXBzIiwiZmluZCIsIm0iLCJzaG9wSWQiLCJyb2xlcyIsInJvbGUiLCJqb2luIiwiT25ib2FyZGluZ1BhZ2UiLCJfczMiLCJuYXZpZ2F0ZSIsInJlZnJlc2giLCJjYWNoZSIsInNldE5hbWUiLCJzZXRDdXJyZW5jeSIsInNldFRpbWV6b25lIiwidGltZXpvbmVUb3VjaGVkIiwic2V0VGltZXpvbmVUb3VjaGVkIiwic3VibWl0dGVkIiwic2V0U3VibWl0dGVkIiwiZm9ybUVsZW1lbnQiLCJiYXNlbGluZSIsIm1vdW50ZWQiLCJjdXJyZW50IiwiYmluZERyYWZ0IiwidGltZXpvbmVFcnJvciIsInNhdmUiLCJ0cmltIiwiciIsImxvY2FsZSIsImludmFsaWRhdGVRdWVyaWVzIiwiZWxlbWVudCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsImMiLCJTaG9wU2V0dGluZ3NQYWdlIiwiX3M0Iiwic2NvcGUiLCJzaG9wIiwiY2FuTWFuYWdlU2hvcCIsInVwZGF0ZSIsInNldExvY2FsZSIsInNhdmVkIiwic2V0U2F2ZWQiLCJzZXR0aW5nc1N1Ym1pdHRlZCIsInNldFNldHRpbmdzU3VibWl0dGVkIiwibGF0ZXN0U2hvcCIsImN1cnJlbnRTaG9wIiwidmVyc2lvbiIsImVkaXRvciIsImlkZW50aXR5Iiwic291cmNlIiwidmFsdWVzIiwiZHJhZnQiLCJhcHBseSIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJmb3JtUmVmIiwiZGlydHkiLCJwcmVwYXJlZCIsInByZXBhcmUiLCJyZXN1bHQiLCJleGVjdXRlIiwicGF0aCIsInBhdGNoIiwic2V0UXVlcnlEYXRhIiwibWVtYmVyc2hpcCIsInBlcm1pc3Npb25WZXJzaW9uIiwiY29tbWl0dGVkIiwiZmFpbGVkIiwic20iLCJmbGV4IiwibWluV2lkdGgiLCJjb21wYWN0Q29udGVudEdhcCIsIlNldHVwQ2hlY2tsaXN0SXRlbSIsInRpdGxlIiwidG8iLCJhY3Rpb24iLCJzdHJvbmciLCJfYzYiLCJyb2xlTGFiZWxzIiwib3duZXIiLCJtYW5hZ2VyIiwic2FsZXMiLCJ3YXJlaG91c2UiLCJhY2NvdW50YW50IiwiYm90X2FkbWluIiwidmlld2VyIiwiVGVhbVBhZ2UiLCJfczUiLCJsaXN0IiwicXVlcnkiLCJtZW1iZXJJZCIsInNldE1lbWJlcklkIiwiZGV0YWlsIiwiQm9vbGVhbiIsImludml0ZSIsInJldm9rZSIsImVkaXQiLCJzZXRFZGl0IiwiZW1haWwiLCJzZXRFbWFpbCIsInNldFJvbGVzIiwicmVtb3ZlIiwic2V0UmVtb3ZlIiwic2F2ZWRNZXNzYWdlIiwic2V0U2F2ZWRNZXNzYWdlIiwib3BlbiIsIm5vdGljZSIsImtleSIsInJlbmRlciIsInVzZXJJZCIsImRpc3BsYXlOYW1lIiwicGVybWlzc2lvbnMiLCJ1bmRlZmluZWQiLCJ0ZXN0IiwiT2JqZWN0Iiwia2V5cyIsInJvbGVQcmVzZXRzIiwiaW5jbHVkZXMiLCJjaGVja2VkIiwiZmlsdGVyIiwiQXVkaXRQYWdlIiwiX3M2IiwiYSIsIm9jY3VycmVkQXQiLCJhY3RvcklkIiwicmVzb3VyY2UiLCJ0eXBlIiwic3VtbWFyeSIsInJlcXVlc3RJZCIsIlByaXZhY3lQYWdlIiwiX3M3IiwicG9saWN5IiwicmVxdWVzdHMiLCJjcmVhdGUiLCJkYXlzIiwic2V0RGF5cyIsIm5vdGUiLCJzZXROb3RlIiwiY3VzdG9tZXJJZCIsInNldEN1c3RvbWVyIiwia2luZCIsInNldEtpbmQiLCJyZWFzb24iLCJzZXRSZWFzb24iLCJzZXRPcGVuIiwiZGF5c1RvdWNoZWQiLCJzZXREYXlzVG91Y2hlZCIsIm5vdGVUb3VjaGVkIiwic2V0Tm90ZVRvdWNoZWQiLCJwb2xpY3lTdWJtaXR0ZWQiLCJzZXRQb2xpY3lTdWJtaXR0ZWQiLCJwb2xpY3lTYXZlZCIsInNldFBvbGljeVNhdmVkIiwiY2FuUmVhZEN1c3RvbWVycyIsImN1c3RvbWVyU2VhcmNoSW5wdXQiLCJzZXRDdXN0b21lclNlYXJjaElucHV0IiwiY3VzdG9tZXJTZWFyY2giLCJzZXRDdXN0b21lclNlYXJjaCIsInRpbWVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsImN1c3RvbWVycyIsInEiLCJzZWxlY3RlZEN1c3RvbWVyRGV0YWlsIiwic2VsZWN0ZWRDdXN0b21lciIsImN1c3RvbWVyIiwiY2hhdFJldGVudGlvbkRheXMiLCJ0b1N0cmluZyIsImp1cmlzZGljdGlvbk5vdGUiLCJwb2xpY3lGb3JtIiwiZGF5c0Vycm9yIiwiTnVtYmVyIiwibm90ZUVycm9yIiwic2hvd0RheXNFcnJvciIsInNob3dOb3RlRXJyb3IiLCJzYXZlUG9saWN5IiwiY2xlYW4iLCJsZyIsIm1pbiIsIm1heCIsInN0ZXAiLCJpc1BlbmRpbmciLCJzb21lIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaXNGZXRjaE5leHRQYWdlRXJyb3IiLCJjb25zZW50Q29weVZlcnNpb24iLCJjb25zZW50UmVjb25maXJtQ29weSIsIkNvbnNlbnRNYW5hZ2VtZW50IiwiX3M4IiwiY29uc2VudExpc3QiLCJjaGFsbGVuZ2VMaXN0IiwiY3JlYXRlQ2hhbGxlbmdlIiwic2VsZWN0ZWRDdXN0b21lcklkIiwic2V0U2VsZWN0ZWRDdXN0b21lcklkIiwiY2hhbm5lbCIsInNldENoYW5uZWwiLCJjcmVhdGVkIiwic2V0Q3JlYXRlZCIsImNhbmRpZGF0ZSIsInJlZGFjdGVkIiwicmVkYWN0ZWRGaWVsZHMiLCJhdmFpbGFibGVDaGFubmVscyIsImF2YWlsYWJsZSIsImV4dGVybmFsSWRlbnRpdHkiLCJwaG9uZSIsIml0ZW0iLCJzZWxlY3RlZENoYW5uZWwiLCJjaGFubmVsSXNBdmFpbGFibGUiLCJyZXF1ZXN0UmVjb25maXJtYXRpb24iLCJwdXJwb3NlIiwibWVzc2FnZSIsImNvbnRlbnRWZXJzaW9uIiwiUHJvbWlzZSIsImFsbCIsInJlY29yZCIsImxhdGVzdCIsImhpc3RvcnkiLCJhdCIsImV2aWRlbmNlVHlwZSIsImV2aWRlbmNlUmVmZXJlbmNlIiwiY2hhbGxlbmdlIiwiZXhwaXJlc0F0IiwiYWxpZ25TZWxmIiwic2F2ZWRDb25zZW50Q2hhbGxlbmdlIiwiQ29uc2VudENvbmZpcm1hdGlvblBhZ2UiLCJfczkiLCJ0b2tlbiIsInNldENoYWxsZW5nZSIsInN0YXRlIiwiY29uc2VudENoYWxsZW5nZSIsImNvbmZpcm1hdGlvbiIsInNldENvbmZpcm1hdGlvbiIsInN1Ym1pdHRlZERlY2lzaW9uIiwic2V0U3VibWl0dGVkRGVjaXNpb24iLCJleGNoYW5nZUlkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsImNvbmZpcm1hdGlvbklkIiwiZXhjaGFuZ2UiLCJpZGVtcG90ZW5jeUtleSIsInJlcGxhY2UiLCJjb25maXJtIiwiZGVjaXNpb24iLCJpbnRlbnQiLCJjaGFsbGVuZ2VTZXNzaW9uSWQiLCJ3aXRoZHJhd2FsIiwiY29uZmlybWF0aW9uTWVzc2FnZSIsImNvbnNlbnRTdGF0dXMiLCJKb2JQYWdlIiwiX3MwIiwiam9iSWQiLCJqb2IiLCJkb3dubG9hZEhyZWYiLCJkb3dubG9hZFVybCIsImpvYlN0YXR1cyIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsImNvbXBsZXRlZCIsInRvdGFsIiwiZXJyb3JDb3VudCIsInVwZGF0ZWRBdCIsInJvd0Vycm9ycyIsInJvdyIsImZpZWxkIiwiY29kZSIsIl9jMiIsIl9jMyIsIl9jNCIsIl9jNSIsIl9jNyIsIl9jOCIsIl9jOSIsIl9jMCIsIl9jMSIsIl9jMTAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7bGFiZWwgYXMgYnVzaW5lc3NMYWJlbH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvbGFiZWxzJztcbmltcG9ydCB7IEFjdGlvbkdyb3VwLCBGaWVsZEdyb3VwLCBGb3JtRmllbGRzLCBQYWdlU2VjdGlvbnMsIFNlY3Rpb25HcmlkLCBTdXJmYWNlQ29udGVudCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB2aXN1YWxTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL3Zpc3VhbCc7XG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmsgYXMgUm91dGVyTGluaywgTmF2aWdhdGUsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQgeyBBbGVydCwgQXZhdGFyLCBCb3gsIEJ1dHRvbiwgQ2hlY2tib3gsIEZvcm1Db250cm9sTGFiZWwsIE1lbnVJdGVtLCBQYXBlciwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IFNtYXJ0VG95Um91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL1NtYXJ0VG95Um91bmRlZCc7XG5pbXBvcnQgQXJyb3dGb3J3YXJkUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL0Fycm93Rm9yd2FyZFJvdW5kZWQnO1xuaW1wb3J0IHR5cGUgeyBDb25zZW50Q29uZmlybWF0aW9uLCBDdXN0b21lciwgTWVtYmVyc2hpcCwgUHVibGljQ29uc2VudENoYWxsZW5nZVZpZXcsIFJvbGUgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IHBlcm1pc3Npb25DYXRhbG9nIH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XG5pbXBvcnQgeyBjb2xvcnMgfSBmcm9tICdAYm90c2FsZXMvdG9rZW5zJztcbmltcG9ydCB7IHJlcXVlc3QsIHNldENzcmZUb2tlbiB9IGZyb20gJ0Avc2hhcmVkL2FwaS9jbGllbnQnO1xuaW1wb3J0IHsgdXNlQXBpLCB1c2VQYWdlZEFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJ0Avc2hhcmVkL2FwaS9lcnJvcnMnO1xuaW1wb3J0IHsgYXNzZXJ0U2NoZW1hIH0gZnJvbSAnQC9zaGFyZWQvYXBpL3ZhbGlkYXRpb24nO1xuaW1wb3J0IHsgdXNlQ2FuLCB1c2VTY29wZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IGNvZGVQb2ludExlbmd0aCwgbGltaXRDb2RlUG9pbnRzLCBkYXRlVGltZSwgc2FmZUludGVybmFsUGF0aCwgaXNWYWxpZFRpbWVab25lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcbmltcG9ydCB7IGF1dGhvcml6ZWREb3dubG9hZEhyZWYgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9kb3dubG9hZCc7XG5pbXBvcnQgeyB1c2VMaXN0UXVlcnkgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcbmltcG9ydCB7IG1hcmtEcmFmdENsZWFuLCB1c2VEcmFmdEZvcm0gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9kaXJ0eS1kcmFmdHMnO1xuaW1wb3J0IHsgdXNlVmVyc2lvbmVkRHJhZnQgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC92ZXJzaW9uZWQtZHJhZnQnO1xuaW1wb3J0IHsgRHJhZnRDb25mbGljdCB9IGZyb20gJ0Avc2hhcmVkL3VpL2RyYWZ0LWNvbmZsaWN0JztcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcbmltcG9ydCB7IFBhZ2VIZWFkZXIsIFBhbmVsLCBRdWVyeVN0YXRlLCBEYXRhVGFibGUsIFRvb2xiYXIsIFBhZ2VyLCBTdGF0dXMsIE11dGF0aW9uQnV0dG9uLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgQ29uZmlybURpYWxvZywgUm91dGVMaW5rLCBEZXRhaWxMaW5lLCBMb29rdXBMb2FkTW9yZSwgRW1wdHkgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcbmltcG9ydCB7IHVzZVNlc3Npb24gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9hdXRoJztcbmZ1bmN0aW9uIEF1dGhDYXJkKHsgY2hpbGRyZW4gfToge1xuICAgIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59KSB7IHJldHVybiA8Qm94IGNvbXBvbmVudD1cIm1haW5cIiBpZD1cIm1haW4tY29udGVudFwiIHRhYkluZGV4PXstMX0gc3g9e1tsYXlvdXRTeC5zaGVsbC5jZW50ZXJlZEZhbGxiYWNrLCB7IGJnY29sb3I6ICdiYWNrZ3JvdW5kLmRlZmF1bHQnLCBvdXRsaW5lOiAnbm9uZScgfV19PjxQYXBlciB2YXJpYW50PVwib3V0bGluZWRcIiBzeD17W2xheW91dFN4LmF1dGguc3VyZmFjZUluc2V0LCB7IHdpZHRoOiAnMTAwJScsIG1heFdpZHRoOiA1MjAsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmhlcm8gfV19PjxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgc3g9e2xheW91dFN4LmF1dGguYnJhbmRNYXJrR2FwfT48QXZhdGFyIHN4PXt7IGJnY29sb3I6ICdwcmltYXJ5Lm1haW4nLCBjb2xvcjogY29sb3JzLm9uQWNjZW50IH19PjxTbWFydFRveVJvdW5kZWQgLz48L0F2YXRhcj48VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIiBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuZXh0cmFCb2xkfT5Cb3RTYWxlcyA8Qm94IGNvbXBvbmVudD1cInNwYW5cIiBjb2xvcj1cInByaW1hcnkubWFpblwiPkFJPC9Cb3g+PC9UeXBvZ3JhcGh5PjwvU3RhY2s+e2NoaWxkcmVufTwvUGFwZXI+PC9Cb3g+OyB9XG5leHBvcnQgZnVuY3Rpb24gTG9naW5QYWdlKCkge1xuICAgIGNvbnN0IHsgc2Vzc2lvbiwgbG9hZGluZyB9ID0gdXNlU2Vzc2lvbigpO1xuICAgIGNvbnN0IFtwYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gICAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpLCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgbG9naW4gPSBhc3luYyAoKSA9PiB7IHNldFBlbmRpbmcodHJ1ZSk7IHNldEVycm9yKG51bGwpOyB0cnkge1xuICAgICAgICBjb25zdCBjc3JmID0gYXdhaXQgcmVxdWVzdCgnZ2V0Q3NyZlRva2VuJyk7XG4gICAgICAgIHNldENzcmZUb2tlbihjc3JmLmRhdGEuY3NyZlRva2VuKTtcbiAgICAgICAgY29uc3QgYXV0aCA9IGF3YWl0IHJlcXVlc3QoJ2JlZ2luTG9naW4nLCB7IGJvZHk6IHsgcmV0dXJuVG86IHNhZmVJbnRlcm5hbFBhdGgocGFyYW1zLmdldCgncmV0dXJuVG8nKSB8fCAnL3dvcmtzcGFjZXMnKSB9IH0pO1xuICAgICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKGF1dGguZGF0YS5hdXRob3JpemF0aW9uVXJsKTtcbiAgICAgICAgaWYgKHVybC5wcm90b2NvbCAhPT0gJ2h0dHBzOicgJiYgIShfX01PQ0tfXyAmJiB1cmwub3JpZ2luID09PSBsb2NhdGlvbi5vcmlnaW4pKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCfEkOG7i2EgY2jhu4kgxJHEg25nIG5o4bqtcCBraMO0bmcgYW4gdG/DoG4uJyk7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5hc3NpZ24odXJsLmhyZWYpO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgYuG6r3QgxJHhuqd1IMSRxrDhu6NjIMSRxINuZyBuaOG6rXAnKSk7XG4gICAgICAgIHNldFBlbmRpbmcoZmFsc2UpO1xuICAgIH0gfTtcbiAgICByZXR1cm4gPEF1dGhDYXJkPjxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgxXCIgdmFyaWFudD1cImg0XCIgc3g9e2xheW91dFN4LmF1dGguYnJhbmRUaXRsZUdhcH0+Q2jDoG8gbeG7q25nIHRy4bufIGzhuqFpPC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17W2xheW91dFN4LnBhZ2VIZWFkZXIudGl0bGVEZXNjcmlwdGlvbkdhcCwgbGF5b3V0U3gucGFnZUhlYWRlci5hZnRlckdhcF19Pk3hu5l0IGtow7RuZyBnaWFuIGNobyBiw6FuIGjDoG5nLCBraG8sIGvhur8gdG/DoW4gdsOgIMSR4buZaSBuZ8WpIEFJIGPhu6dhIGLhuqFuLjwvVHlwb2dyYXBoeT48RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yfS8+e19fTU9DS19fICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3gucGFnZUhlYWRlci5hZnRlckdhcH0+Q2jhur8gxJHhu5kgeGVtIGZyb250ZW5kOiB0w6BpIGtob+G6o24gZ2nhuqMgbOG6rXAsIGtow7RuZyBjw7MgbeG6rXQga2jhuql1IHRo4bqtdC48L0FsZXJ0Pn17c2Vzc2lvbiA/IDxCdXR0b24gZnVsbFdpZHRoIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89XCIvd29ya3NwYWNlc1wiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBlbmRJY29uPXs8QXJyb3dGb3J3YXJkUm91bmRlZCAvPn0+VGnhur9wIHThu6VjIHbDoG8gY+G7rWEgaMOgbmc8L0J1dHRvbj4gOiA8QnV0dG9uIGZ1bGxXaWR0aCB2YXJpYW50PVwiY29udGFpbmVkXCIgc2l6ZT1cImxhcmdlXCIgb25DbGljaz17KCkgPT4gdm9pZCBsb2dpbigpfSBkaXNhYmxlZD17cGVuZGluZyB8fCBsb2FkaW5nfT57cGVuZGluZyA/ICfEkGFuZyBjaHV54buDbiDEkeG6v24gxJHEg25nIG5o4bqtcOKApicgOiBfX01PQ0tfXyA/ICdWw6BvIHTDoGkga2hv4bqjbiBtw7QgcGjhu49uZycgOiAnxJDEg25nIG5o4bqtcCBi4bqxbmcgdMOgaSBraG/huqNuIGPDtG5nIHR5J308L0J1dHRvbj59PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e1tsYXlvdXRTeC5wYWdlLnNlY3Rpb25CZWZvcmUsIHsgZGlzcGxheTogJ2Jsb2NrJyB9XX0+UGhpw6puIMSRxINuZyBuaOG6rXAgxJHGsOG7o2MgcXXhuqNuIGzDvSDhu58gbcOheSBjaOG7py4gS2jDtG5nIGzGsHUgYWNjZXNzIHRva2VuIHRyb25nIGxvY2FsU3RvcmFnZS48L1R5cG9ncmFwaHk+PC9BdXRoQ2FyZD47XG59XG5leHBvcnQgZnVuY3Rpb24gV29ya3NwYWNlc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzZXNzaW9uLCBsb2FkaW5nLCBlcnJvcjogc2Vzc2lvbkVycm9yIH0gPSB1c2VTZXNzaW9uKCk7XG4gICAgY29uc3Qgc2hvcHMgPSB1c2VRdWVyeSh7IHF1ZXJ5S2V5OiBbJ3Nob3BzJywgc2Vzc2lvbj8udXNlci5pZF0sIHF1ZXJ5Rm46ICh7IHNpZ25hbCB9KSA9PiByZXF1ZXN0KCdsaXN0U2hvcHMnLCB7IHNpZ25hbCB9KSwgZW5hYmxlZDogISFzZXNzaW9uLCByZXRyeTogZmFsc2UgfSk7XG4gICAgY29uc3QgaXNFbXB0eSA9ICFzaG9wcy5pc0Vycm9yICYmIHNob3BzLmRhdGE/LmRhdGEubGVuZ3RoID09PSAwO1xuICAgIGNvbnN0IGNyZWF0ZVNob3BCdXR0b24gPSA8QnV0dG9uIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89XCIvb25ib2FyZGluZ1wiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5U4bqhbyBj4butYSBow6BuZzwvQnV0dG9uPjtcbiAgICBpZiAoIWxvYWRpbmcgJiYgIXNlc3Npb24gJiYgc2Vzc2lvbkVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgc2Vzc2lvbkVycm9yLnN0YXR1cyA9PT0gNDAxKVxuICAgICAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZS8+O1xuICAgIHJldHVybiA8Qm94IGNvbXBvbmVudD1cIm1haW5cIiBpZD1cIm1haW4tY29udGVudFwiIHRhYkluZGV4PXstMX0gc3g9e1tsYXlvdXRTeC5zaGVsbC5wYWdlRmFsbGJhY2tJbnNldCwgeyBtYXhXaWR0aDogMTEwMCwgbXg6ICdhdXRvJywgb3V0bGluZTogJ25vbmUnIH1dfT48UGFnZUhlYWRlciB0aXRsZT1cIkNo4buNbiBj4butYSBow6BuZ1wiIHN1YnRpdGxlPVwiTeG7l2kgY+G7rWEgaMOgbmcgbMOgIG3hu5l0IHbDuW5nIGThu68gbGnhu4d1IHbDoCBxdXnhu4FuIMSR4buZYyBs4bqtcC5cIiBhY3Rpb25zPXshaXNFbXB0eSAmJiBjcmVhdGVTaG9wQnV0dG9ufS8+PEVycm9yTm90aWNlIGVycm9yPXtzZXNzaW9uRXJyb3J9Lz48UXVlcnlTdGF0ZSBxdWVyeT17c2hvcHN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntpc0VtcHR5ID8gPEVtcHR5IHRleHQ9XCJDaMawYSBjw7MgY+G7rWEgaMOgbmcuXCIgYWN0aW9uPXtjcmVhdGVTaG9wQnV0dG9ufS8+IDogPFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICdtaW5tYXgoMCwgMWZyKScsIG1kOiBzaG9wcy5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMSA/ICdtaW5tYXgoMCwgMWZyKScgOiAncmVwZWF0KDIsIG1pbm1heCgwLCAxZnIpKScgfX0+e3Nob3BzLmRhdGE/LmRhdGEubWFwKHMgPT4gPFBhcGVyIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGtleT17cy5pZH0gc3g9e1tsYXlvdXRTeC5zdXJmYWNlLmluc2V0LCB7IGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmxhcmdlIH1dfT48QXZhdGFyIHN4PXt7IGJnY29sb3I6IGNvbG9ycy5zZWxlY3RlZCwgY29sb3I6ICdwcmltYXJ5Lm1haW4nIH19PntzLm5hbWVbMF19PC9BdmF0YXI+PFN1cmZhY2VDb250ZW50IGJlZm9yZUdhcD1cInN1cmZhY2VcIj48VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIj57cy5uYW1lfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3MuY3VycmVuY3l9IMK3IHtzLnRpbWV6b25lfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5RdXnhu4FuOiB7c2Vzc2lvbj8ubWVtYmVyc2hpcHMuZmluZChtID0+IG0uc2hvcElkID09PSBzLmlkKT8ucm9sZXMubWFwKHJvbGUgPT4gYnVzaW5lc3NMYWJlbChyb2xlKSkuam9pbignLCAnKSB8fCAnQ2jGsGEgY8OzIHF1eeG7gW4nfTwvVHlwb2dyYXBoeT48L1N1cmZhY2VDb250ZW50PjxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz17YC9zLyR7cy5pZH0vb3ZlcnZpZXdgfSBmdWxsV2lkdGggdmFyaWFudD1cIm91dGxpbmVkXCIgZW5kSWNvbj17PEFycm93Rm9yd2FyZFJvdW5kZWQgLz59IHN4PXtsYXlvdXRTeC5wYWdlLnNlY3Rpb25CZWZvcmV9Pk3hu58gY+G7rWEgaMOgbmc8L0J1dHRvbj48L1BhcGVyPil9PC9TZWN0aW9uR3JpZD59PC9RdWVyeVN0YXRlPjwvQm94Pjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBPbmJvYXJkaW5nUGFnZSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyByZWZyZXNoIH0gPSB1c2VTZXNzaW9uKCk7XG4gICAgY29uc3QgY2FjaGUgPSB1c2VRdWVyeUNsaWVudCgpO1xuICAgIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKCcnKSwgW2N1cnJlbmN5LCBzZXRDdXJyZW5jeV0gPSB1c2VTdGF0ZSgnVk5EJyksIFt0aW1lem9uZSwgc2V0VGltZXpvbmVdID0gdXNlU3RhdGUoJ0FzaWEvVmllbnRpYW5lJyksIFtwZW5kaW5nLCBzZXRQZW5kaW5nXSA9IHVzZVN0YXRlKGZhbHNlKSwgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpLCBbdGltZXpvbmVUb3VjaGVkLCBzZXRUaW1lem9uZVRvdWNoZWRdID0gdXNlU3RhdGUoZmFsc2UpLCBbc3VibWl0dGVkLCBzZXRTdWJtaXR0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGZvcm1FbGVtZW50ID0gdXNlUmVmPEhUTUxGb3JtRWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgYmFzZWxpbmUgPSB1c2VSZWYoe25hbWU6ICcnLGN1cnJlbmN5OiAnVk5EJyx0aW1lem9uZTogJ0FzaWEvVmllbnRpYW5lJ30pO1xuICAgIGNvbnN0IG1vdW50ZWQgPSB1c2VSZWYodHJ1ZSk7XG4gICAgdXNlRWZmZWN0KCgpID0+IHsgbW91bnRlZC5jdXJyZW50PXRydWU7IHJldHVybiAoKSA9PiB7IG1vdW50ZWQuY3VycmVudD1mYWxzZTsgfTsgfSxbXSk7XG4gICAgY29uc3QgYmluZERyYWZ0ID0gdXNlRHJhZnRGb3JtKG5hbWUhPT1iYXNlbGluZS5jdXJyZW50Lm5hbWUgfHwgY3VycmVuY3khPT1iYXNlbGluZS5jdXJyZW50LmN1cnJlbmN5IHx8IHRpbWV6b25lIT09YmFzZWxpbmUuY3VycmVudC50aW1lem9uZSk7XG4gICAgY29uc3QgdGltZXpvbmVFcnJvciA9ICFpc1ZhbGlkVGltZVpvbmUodGltZXpvbmUpID8gJ05o4bqtcCBtw7ppIGdp4budIGjhu6NwIGzhu4csIHbDrSBk4bulIEFzaWEvVmllbnRpYW5lLicgOiAnJztcbiAgICBjb25zdCBzYXZlID0gYXN5bmMgKCkgPT4geyBzZXRTdWJtaXR0ZWQodHJ1ZSk7IGlmIChwZW5kaW5nIHx8ICFuYW1lLnRyaW0oKSB8fCB0aW1lem9uZUVycm9yKSByZXR1cm47IHNldFBlbmRpbmcodHJ1ZSk7IHNldEVycm9yKG51bGwpOyB0cnkge1xuICAgICAgICBjb25zdCByID0gYXdhaXQgcmVxdWVzdCgnY3JlYXRlU2hvcCcsIHsgYm9keTogeyBuYW1lLCBjdXJyZW5jeSwgdGltZXpvbmUsIGxvY2FsZTogJ3ZpLVZOJyB9IH0pO1xuICAgICAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgICAgIGF3YWl0IGNhY2hlLmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnc2hvcHMnXSB9KTtcbiAgICAgICAgaWYgKCFtb3VudGVkLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgYmFzZWxpbmUuY3VycmVudD17bmFtZSxjdXJyZW5jeSx0aW1lem9uZX07XG4gICAgICAgIGlmIChmb3JtRWxlbWVudC5jdXJyZW50KSBtYXJrRHJhZnRDbGVhbihmb3JtRWxlbWVudC5jdXJyZW50KTtcbiAgICAgICAgbmF2aWdhdGUoYC9zLyR7ci5kYXRhLmlkfS9vdmVydmlld2ApO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBpZiAobW91bnRlZC5jdXJyZW50KSBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgdOG6oW8gxJHGsOG7o2MgY+G7rWEgaMOgbmcnKSk7XG4gICAgfVxuICAgIGZpbmFsbHkge1xuICAgICAgICBpZiAobW91bnRlZC5jdXJyZW50KSBzZXRQZW5kaW5nKGZhbHNlKTtcbiAgICB9IH07XG4gICAgcmV0dXJuIDxBdXRoQ2FyZD48VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoNFwiIHN4PXtsYXlvdXRTeC5hdXRoLmJyYW5kVGl0bGVHYXB9PlThuqFvIGPhu61hIGjDoG5nPC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17W2xheW91dFN4LnBhZ2VIZWFkZXIudGl0bGVEZXNjcmlwdGlvbkdhcCwgbGF5b3V0U3gucGFnZUhlYWRlci5hZnRlckdhcF19PkNo4buNbiB0aeG7gW4gdOG7hyBjxqEgc+G7nyB0csaw4bubYyBraGkgZ2hpIG5o4bqtbiBnaWFvIGThu4tjaC48L1R5cG9ncmFwaHk+PEVycm9yTm90aWNlIGVycm9yPXtlcnJvcn0vPjxGb3JtRmllbGRzIGNvbXBvbmVudD1cImZvcm1cIiBub1ZhbGlkYXRlIHJlZj17ZWxlbWVudCA9PiB7Zm9ybUVsZW1lbnQuY3VycmVudD1lbGVtZW50O2JpbmREcmFmdChlbGVtZW50KTt9fSBvblN1Ym1pdD17ZXZlbnQgPT4ge2V2ZW50LnByZXZlbnREZWZhdWx0KCk7dm9pZCBzYXZlKCk7fX0+PFRleHRGaWVsZCBkaXNhYmxlZD17cGVuZGluZ30gbGFiZWw9XCJUw6puIGPhu61hIGjDoG5nXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXtlID0+IHNldE5hbWUobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAxNjApKX0gLz48VGV4dEZpZWxkIGRpc2FibGVkPXtwZW5kaW5nfSBsYWJlbD1cIlRp4buBbiB04buHIGPGoSBz4bufXCIgc2VsZWN0IHZhbHVlPXtjdXJyZW5jeX0gb25DaGFuZ2U9e2UgPT4gc2V0Q3VycmVuY3koZS50YXJnZXQudmFsdWUpfT57WydWTkQnLCAnTEFLJywgJ1RIQicsICdVU0QnXS5tYXAoYyA9PiA8TWVudUl0ZW0ga2V5PXtjfSB2YWx1ZT17Y30+e2N9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxUZXh0RmllbGQgZGlzYWJsZWQ9e3BlbmRpbmd9IGxhYmVsPVwiTcO6aSBnaeG7nVwiIHZhbHVlPXt0aW1lem9uZX0gb25CbHVyPXsoKSA9PiBzZXRUaW1lem9uZVRvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtlID0+IHNldFRpbWV6b25lKGUudGFyZ2V0LnZhbHVlKX0gZXJyb3I9eyh0aW1lem9uZVRvdWNoZWQgfHwgc3VibWl0dGVkKSAmJiAhIXRpbWV6b25lRXJyb3J9IGhlbHBlclRleHQ9eyh0aW1lem9uZVRvdWNoZWQgfHwgc3VibWl0dGVkKSAmJiB0aW1lem9uZUVycm9yID8gdGltZXpvbmVFcnJvciA6ICdWw60gZOG7pTogQXNpYS9WaWVudGlhbmUnfS8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkdpYW8gZGnhu4duIEdyYXBoaXRlIEdvbGQgZGFyay1vbmx5IMSRw6MgY2jhu5F0LiBOaOG7r25nIGNow61uaCBzw6FjaCB0aOG6rXQgdsOgIGvhur90IG7hu5FpIG5nb8OgaSBjaMawYSB04buxIGLhuq10IGtoaSB04bqhbyBzaG9wLjwvQWxlcnQ+PEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshbmFtZS50cmltKCkgfHwgcGVuZGluZ30+VOG6oW8gY+G7rWEgaMOgbmc8L0J1dHRvbj48QnV0dG9uIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89XCIvd29ya3NwYWNlc1wiPlF1YXkgbOG6oWk8L0J1dHRvbj48L0Zvcm1GaWVsZHM+PC9BdXRoQ2FyZD47XG59XG5leHBvcnQgZnVuY3Rpb24gU2hvcFNldHRpbmdzUGFnZSgpIHtcbiAgICBjb25zdCBzY29wZSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgeyBzaG9wIH0gPSBzY29wZTtcbiAgICBjb25zdCBjYWNoZSA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gICAgY29uc3QgY2FuTWFuYWdlU2hvcCA9IHVzZUNhbignc2hvcC5tYW5hZ2UnKTtcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVTaG9wJywgWydnZXRTaG9wJ10pO1xuICAgIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKHNob3AubmFtZSksIFt0aW1lem9uZSwgc2V0VGltZXpvbmVdID0gdXNlU3RhdGUoc2hvcC50aW1lem9uZSksIFtsb2NhbGUsIHNldExvY2FsZV0gPSB1c2VTdGF0ZShzaG9wLmxvY2FsZSksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKSwgW3NhdmVkLCBzZXRTYXZlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFt0aW1lem9uZVRvdWNoZWQsIHNldFRpbWV6b25lVG91Y2hlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtzZXR0aW5nc1N1Ym1pdHRlZCwgc2V0U2V0dGluZ3NTdWJtaXR0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGxhdGVzdFNob3AgPSB1c2VBcGkoJ2dldFNob3AnKTtcbiAgICBjb25zdCBjdXJyZW50U2hvcCA9IGxhdGVzdFNob3AuZGF0YSAmJiBsYXRlc3RTaG9wLmRhdGEuZGF0YS52ZXJzaW9uID49IHNob3AudmVyc2lvbiA/IGxhdGVzdFNob3AuZGF0YS5kYXRhIDogc2hvcDtcbiAgICBjb25zdCBlZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XG4gICAgICAgIGlkZW50aXR5OiBgJHtzaG9wLmlkfTpzZXR0aW5nc2AsXG4gICAgICAgIHNvdXJjZTogeyB2ZXJzaW9uOiBjdXJyZW50U2hvcC52ZXJzaW9uLCB2YWx1ZXM6IHsgbmFtZTogY3VycmVudFNob3AubmFtZSwgdGltZXpvbmU6IGN1cnJlbnRTaG9wLnRpbWV6b25lLCBsb2NhbGU6IGN1cnJlbnRTaG9wLmxvY2FsZSB9IH0sXG4gICAgICAgIGRyYWZ0OiB7IG5hbWUsIHRpbWV6b25lLCBsb2NhbGUgfSxcbiAgICAgICAgYXBwbHk6IHZhbHVlcyA9PiB7IHNldE5hbWUodmFsdWVzLm5hbWUpOyBzZXRUaW1lem9uZSh2YWx1ZXMudGltZXpvbmUpOyBzZXRMb2NhbGUodmFsdWVzLmxvY2FsZSk7IH0sXG4gICAgICAgIHJlZnJlc2g6ICgpID0+IGxhdGVzdFNob3AucmVmZXRjaCh7IHRocm93T25FcnJvcjogdHJ1ZSB9KSxcbiAgICB9KTtcbiAgICBjb25zdCBmb3JtUmVmID0gdXNlRHJhZnRGb3JtKGVkaXRvci5kaXJ0eSk7XG4gICAgY29uc3QgdGltZXpvbmVFcnJvciA9ICFpc1ZhbGlkVGltZVpvbmUodGltZXpvbmUpID8gJ05o4bqtcCBtw7ppIGdp4budIGjhu6NwIGzhu4csIHbDrSBk4bulIEFzaWEvVmllbnRpYW5lLicgOiAnJztcbiAgICBjb25zdCBzYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRTZXR0aW5nc1N1Ym1pdHRlZCh0cnVlKTtcbiAgICAgICAgaWYgKCFuYW1lLnRyaW0oKSB8fCB0aW1lem9uZUVycm9yKSByZXR1cm47XG4gICAgICAgIHNldEVycm9yKG51bGwpOyBzZXRTYXZlZChmYWxzZSk7XG4gICAgICAgIGNvbnN0IHByZXBhcmVkID0gZWRpdG9yLnByZXBhcmUoKTtcbiAgICAgICAgaWYgKCFwcmVwYXJlZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBzdWJtaXR0ZWQgPSB7IG5hbWUsIHRpbWV6b25lLCBsb2NhbGUgfTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyBzaG9wSWQ6IHNob3AuaWQgfSwgdmVyc2lvbjogcHJlcGFyZWQudmVyc2lvbiwgYm9keTogcHJlcGFyZWQucGF0Y2ggfSk7XG4gICAgICAgICAgICBjYWNoZS5zZXRRdWVyeURhdGEoWydzaG9wJywgc2NvcGUuc2Vzc2lvbi51c2VyLmlkLCBzaG9wLmlkLCBzY29wZS5tZW1iZXJzaGlwLnBlcm1pc3Npb25WZXJzaW9uXSwgcmVzdWx0KTtcbiAgICAgICAgICAgIGVkaXRvci5jb21taXR0ZWQoeyB2ZXJzaW9uOiByZXN1bHQuZGF0YS52ZXJzaW9uLCB2YWx1ZXM6IHsgbmFtZTogcmVzdWx0LmRhdGEubmFtZSwgdGltZXpvbmU6IHJlc3VsdC5kYXRhLnRpbWV6b25lLCBsb2NhbGU6IHJlc3VsdC5kYXRhLmxvY2FsZSB9IH0sIHN1Ym1pdHRlZCk7XG4gICAgICAgICAgICBzZXRTYXZlZCh0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHsgZWRpdG9yLmZhaWxlZChlcnJvcik7IHNldEVycm9yKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvciA6IG5ldyBFcnJvcignS2jDtG5nIGzGsHUgxJHGsOG7o2MgY+G6pXUgaMOsbmgnKSk7IH1cbiAgICB9O1xuICAgIHJldHVybiA8PlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIlRoaeG6v3QgbOG6rXAgY+G7rWEgaMOgbmdcIiBzdWJ0aXRsZT1cIkPhuqV1IGjDrG5oIHJpw6puZyBj4bunYSBzaG9wIGtow7RuZyB0aGF5IMSR4buVaSBxdXkgdOG6r2MgQUkgbOG6rXAgdHLDrG5oIGhv4bq3YyBtw6B1IMSRw6MgZHV54buHdC5cIiAvPlxuICAgICAgICA8UGFnZVNlY3Rpb25zID5cbiAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIlRow7RuZyB0aW4gY8ahIHPhu59cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICAgICAgPEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIHJlZj17Zm9ybVJlZn0gbm9WYWxpZGF0ZSBvblN1Ym1pdD17ZXZlbnQgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyB2b2lkIHNhdmUoKTsgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3IgfHwgdXBkYXRlLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICA8RHJhZnRDb25mbGljdCBlZGl0b3I9e2VkaXRvcn0gbGFiZWxzPXt7IG5hbWU6ICdUw6puIGPhu61hIGjDoG5nJywgdGltZXpvbmU6ICdNw7ppIGdp4budJywgbG9jYWxlOiAnTmfDtG4gbmfhu68nIH19IGJ1c3k9e3VwZGF0ZS5wZW5kaW5nfS8+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZlZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPsSQw6MgbMawdSBj4bqldSBow6xuaCBj4butYSBow6BuZy48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgPEZpZWxkR3JvdXAgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdzdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVMOqbiBj4butYSBow6BuZ1wiIHZhbHVlPXtuYW1lfSBkaXNhYmxlZD17IWNhbk1hbmFnZVNob3B9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldE5hbWUoZXZlbnQudGFyZ2V0LnZhbHVlKTsgc2V0U2F2ZWQoZmFsc2UpOyB9fSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlRp4buBbiB04buHIGPGoSBz4bufXCIgdmFsdWU9e3Nob3AuY3VycmVuY3l9IGRpc2FibGVkIGhlbHBlclRleHQ9XCJLaMO0bmcgxJHhu5VpIHRp4buBbiB04buHIGLhurFuZyBz4butYSBnaWFvIGRp4buHbi4gQ+G6p24ga+G6vyBob+G6oWNoIGNodXnhu4NuIMSR4buVaSBk4buvIGxp4buHdS5cIiBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L0ZpZWxkR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgIDxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBhbGlnbkl0ZW1zPXt7IHhzOiAnc3RyZXRjaCcsIHNtOiAnc3RhcnQnIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk3DumkgZ2nhu51cIiB2YWx1ZT17dGltZXpvbmV9IGRpc2FibGVkPXshY2FuTWFuYWdlU2hvcH0gb25CbHVyPXsoKSA9PiBzZXRUaW1lem9uZVRvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldFRpbWV6b25lKGV2ZW50LnRhcmdldC52YWx1ZSk7IHNldFNhdmVkKGZhbHNlKTsgfX0gZXJyb3I9eyh0aW1lem9uZVRvdWNoZWQgfHwgc2V0dGluZ3NTdWJtaXR0ZWQpICYmICEhdGltZXpvbmVFcnJvcn0gaGVscGVyVGV4dD17KHRpbWV6b25lVG91Y2hlZCB8fCBzZXR0aW5nc1N1Ym1pdHRlZCkgJiYgdGltZXpvbmVFcnJvciA/IHRpbWV6b25lRXJyb3IgOiAnw4FwIGThu6VuZyBjaG8gbmfDoHkgZ2nhu50gdGhlbyBj4butYSBow6BuZy4nfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5nw7RuIG5n4buvIGdpYW8gZGnhu4duXCIgdmFsdWU9XCJUaeG6v25nIFZp4buHdFwiIGRpc2FibGVkIGhlbHBlclRleHQ9e2BHaWFvIGRp4buHbiBoaeG7h24gY2jhu4kgaOG7lyB0cuG7oyB0aeG6v25nIFZp4buHdC4gTG9jYWxlIGzGsHUgdHJvbmcgQVBJOiAke2xvY2FsZX0uYH0gc3g9e3sgZmxleDogMSwgbWluV2lkdGg6IDAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPlxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiR2lhbyBkaeG7h25cIiB2YWx1ZT1cIkdyYXBoaXRlIEdvbGQgwrcgRGFyay1vbmx5XCIgZGlzYWJsZWQgLz5cbiAgICAgICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJzaG9wLm1hbmFnZVwiIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17dXBkYXRlLnBlbmRpbmd9IGRpc2FibGVkPXshY2FuTWFuYWdlU2hvcCB8fCAhZWRpdG9yLmRpcnR5IHx8IHVwZGF0ZS5wZW5kaW5nfT5MxrB1IGPhuqV1IGjDrG5oPC9NdXRhdGlvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiQ2hlY2tsaXN0IHRoaeG6v3QgbOG6rXAgduG6rW4gaMOgbmhcIiBzdWJ0aXRsZT1cIkPDoWMgbeG7pWMga2jDtG5nIGPDsyB0csaw4budbmcgQVBJIMSRxrDhu6NjIGdp4buvIOG7nyB0cuG6oW5nIHRow6FpIGNoxrBhIHjDoWMgbWluaDsga2jDtG5nIHN1eSBkaeG7hW4gxJHDoyBz4bq1biBzw6BuZy5cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICAgICAgPFN0YWNrIHN4PXtsYXlvdXRTeC5zdXJmYWNlLmNvbXBhY3RDb250ZW50R2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPntfX01PQ0tfXyA/ICdC4bqjbiB4ZW0gdHLGsOG7m2MgbcO0IHBo4buPbmcuIENo4buJIHTDqm4sIHRp4buBbiB04buHLCBtw7ppIGdp4budIHbDoCBuZ8O0biBuZ+G7ryDEkcaw4bujYyBsxrB1IHF1YSBBUEkgaGnhu4duIHThuqFpLicgOiAnQVBJIGhp4buHbiBjaOG7iSBjaG8gcGjDqXAgc+G7rWEgdGjDtG5nIHRpbiBjxqEgc+G7nyDEkcaw4bujYyBo4buXIHRy4bujLid9IFF14buRYyBnaWEga2luaCBkb2FuaCBraMO0bmcgxJHGsOG7o2Mgc3V5IHJhIHThu6sgbcO6aSBnaeG7nS48L0FsZXJ0PlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiUXXhu5FjIGdpYSB2w6AgZ2nhu50ga2luaCBkb2FuaFwiIHN0YXR1cz1cIkNoxrBhIGPDsyB0csaw4budbmcgY+G6pXUgaMOsbmggdHJvbmcgY29udHJhY3RcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwixJDhu4thIGNo4buJLCB2w7luZyBnaWFvIHbDoCBwaMOtIHbhuq1uIGNodXnhu4NuXCIgc3RhdHVzPXtfX01PQ0tfXyA/ICdDw7MgcHJldmlldyBtw7QgcGjhu49uZywgY2jGsGEgbMawdSBj4bqldSBow6xuaCcgOiAnQ2jGsGEgY8OzIG9wZXJhdGlvbiBj4bqldSBow6xuaCB2w7luZyBnaWFvJ30gdG89e2Avcy8ke3Nob3AuaWR9L3NoaXBtZW50c2B9IGFjdGlvbj1cIlhlbSBwcmV2aWV3IHBow60gZ2lhb1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJOZ8aw4budaSBkdXnhu4d0IHbDoCB0aMOgbmggdmnDqm5cIiBzdGF0dXM9XCJRdXnhu4FuIGzhuqV5IHThu6sgbWVtYmVyc2hpcDsgY2jGsGEgY8OzIEFQSSBnw6FuIGNow61uaCBzw6FjaCBkdXnhu4d0XCIgdG89e2Avcy8ke3Nob3AuaWR9L3NldHRpbmdzL3RlYW1gfSBhY3Rpb249XCJRdeG6o24gbMO9IHRow6BuaCB2acOqblwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJL4bq/dCBu4buRaSBrw6puaCBiw6FuIGjDoG5nXCIgc3RhdHVzPXtfX01PQ0tfXyA/ICdL4bq/dCBu4buRaSBtw7QgcGjhu49uZzsga2jDtG5nIGPDsyBxdXnhu4FuIHByb3ZpZGVyIHRo4bqtdCcgOiAnS2nhu4NtIHRyYSB0cuG6oW5nIHRow6FpIGvhur90IG7hu5FpJ30gdG89e2Avcy8ke3Nob3AuaWR9L2ludGVncmF0aW9ucy9jaGFubmVsc2B9IGFjdGlvbj1cIk3hu58ga+G6v3QgbuG7kWlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiS+G6v3QgbuG7kWkgQUlcIiBzdGF0dXM9e19fTU9DS19fID8gJ0NhdGFsb2cgbmjDoCBjdW5nIGPhuqVwIG3DtCBwaOG7j25nJyA6ICdLaeG7g20gdHJhIGNhdGFsb2cgbmjDoCBjdW5nIGPhuqVwJ30gdG89e2Avcy8ke3Nob3AuaWR9L2ludGVncmF0aW9ucy9haWB9IGFjdGlvbj1cIk3hu58gbmjDoCBjdW5nIGPhuqVwIEFJXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIk7hu5lpIGR1bmcgc+G6o24gcGjhuqltIHbDoCBwaGnDqm4gYuG6o24ga2nhur9uIHRo4bupY1wiIHN0YXR1cz1cIk5ndeG7k24gbuG7mWkgZHVuZywgbOG7i2NoIHPhu60gcGhpw6puIGLhuqNuIHbDoCBkdXnhu4d0IG7hurFtIHRyb25nIGtodSB24buxYyBraeG6v24gdGjhu6ljLlwiIHRvPXtgL3MvJHtzaG9wLmlkfS9rbm93bGVkZ2VgfSBhY3Rpb249XCJRdeG6o24gbMO9IG7hu5lpIGR1bmdcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiVsOybmcgZ8OzcCDDvSBjw7MgZHV54buHdFwiIHN0YXR1cz1cIkfDs3Agw70gdOG6oW8gYuG6o24gbmjDoXA7IGtow7RuZyB04buxIGh14bqlbiBsdXnhu4duIGhv4bq3YyB4deG6pXQgYuG6o24uXCIgdG89e2Avcy8ke3Nob3AuaWR9L2tub3dsZWRnZS9yZXZpZXdgfSBhY3Rpb249XCJEdXnhu4d0IGfDs3Agw71cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiQ29uc2VudCB2w6Agbmfhu6tuZyBsacOqbiBo4buHIG1hcmtldGluZ1wiIHN0YXR1cz1cIkPDsyBi4bqjbiBnaGkgY29uc2VudCwgbOG7i2NoIHPhu60gdsOgIGx14buTbmcgeMOhYyBuaOG6rW4gY2hhbGxlbmdlOyBn4butaSBxdWEgbmjDoCBjdW5nIGPhuqVwIGNoxrBhIGvhur90IG7hu5FpLlwiIHRvPXtgL3MvJHtzaG9wLmlkfS9zZXR0aW5ncy9wcml2YWN5YH0gYWN0aW9uPVwiUXXhuqNuIGzDvSBjb25zZW50XCIgLz5cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgPC9QYWdlU2VjdGlvbnM+XG4gICAgPC8+O1xufVxuZnVuY3Rpb24gU2V0dXBDaGVja2xpc3RJdGVtKHsgdGl0bGUsIHN0YXR1cywgdG8sIGFjdGlvbiB9OiB7IHRpdGxlOiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyB0bz86IHN0cmluZzsgYWN0aW9uPzogc3RyaW5nIH0pIHtcbiAgICByZXR1cm4gPFN1cmZhY2VDb250ZW50IGJvZHlNb2RlPVwiY29tcGFjdENvbnRyb2xPdXRsaW5lZFwiIGRpcmVjdGlvbj1cInJvd1wiIGFsaWduSXRlbXM9e3sgeHM6ICdmbGV4LXN0YXJ0JywgbWQ6ICdjZW50ZXInIH19IGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIGZsZXhXcmFwPVwid3JhcFwiPlxuICAgICAgICA8Qm94PjxUeXBvZ3JhcGh5IGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmd9Pnt0aXRsZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPntzdGF0dXN9PC9UeXBvZ3JhcGh5PjwvQm94PlxuICAgICAgICB7dG8gJiYgYWN0aW9uICYmIDxSb3V0ZUxpbmsgdG89e3RvfT57YWN0aW9ufTwvUm91dGVMaW5rPn1cbiAgICA8L1N1cmZhY2VDb250ZW50Pjtcbn1cbmNvbnN0IHJvbGVMYWJlbHM6IFJlY29yZDxSb2xlLCBzdHJpbmc+ID0ge1xuICAgIG93bmVyOiAnQ2jhu6cgY+G7rWEgaMOgbmcnLCBtYW5hZ2VyOiAnUXXhuqNuIGzDvScsIHNhbGVzOiAnQsOhbiBow6BuZycsIHdhcmVob3VzZTogJ05ow6JuIHZpw6puIGtobycsIGFjY291bnRhbnQ6ICdL4bq/IHRvw6FuJywgYm90X2FkbWluOiAnUXXhuqNuIHRy4buLIEFJJywgdmlld2VyOiAnQ2jhu4kgeGVtJ1xufTtcbmV4cG9ydCBmdW5jdGlvbiBUZWFtUGFnZSgpIHtcbiAgICBjb25zdCB7IHNlc3Npb24sIHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdE1lbWJlcnMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RNZW1iZXJzJykgfSk7XG4gICAgY29uc3QgW21lbWJlcklkLCBzZXRNZW1iZXJJZF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgZGV0YWlsID0gdXNlQXBpKCdnZXRNZW1iZXInLCB7IHBhdGg6IHsgbWVtYmVySWQgfSB9LCBCb29sZWFuKG1lbWJlcklkKSk7XG4gICAgY29uc3QgaW52aXRlID0gdXNlQ29tbWFuZCgnaW52aXRlTWVtYmVyJywgWydsaXN0TWVtYmVycyddKTtcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVNZW1iZXJSb2xlcycsIFsnbGlzdE1lbWJlcnMnLCAnZ2V0TWVtYmVyJ10pO1xuICAgIGNvbnN0IHJldm9rZSA9IHVzZUNvbW1hbmQoJ3Jldm9rZU1lbWJlcnNoaXAnLCBbJ2xpc3RNZW1iZXJzJywgJ2dldE1lbWJlciddKTtcbiAgICBjb25zdCBbZWRpdCwgc2V0RWRpdF0gPSB1c2VTdGF0ZTxNZW1iZXJzaGlwIHwgbnVsbCB8IHVuZGVmaW5lZD4oKSwgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyksIFtyb2xlcywgc2V0Um9sZXNdID0gdXNlU3RhdGU8Um9sZVtdPihbJ3ZpZXdlciddKSwgW3JlbW92ZSwgc2V0UmVtb3ZlXSA9IHVzZVN0YXRlPE1lbWJlcnNoaXAgfCBudWxsPihudWxsKSwgW3NhdmVkTWVzc2FnZSwgc2V0U2F2ZWRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBvcGVuID0gKG06IE1lbWJlcnNoaXAgfCBudWxsKSA9PiB7IHNldFNhdmVkTWVzc2FnZSgnJyk7IHNldEVkaXQobSk7IHNldEVtYWlsKCcnKTsgc2V0Um9sZXMobT8ucm9sZXMgfHwgWyd2aWV3ZXInXSk7IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaMOibiBz4buxICYgcGjDom4gcXV54buBblwiIHN1YnRpdGxlPVwiVmFpIHRyw7IgbMOgIGLhu5kgcXV54buBbiBt4bq3YyDEkeG7i25oOyBBUEkgcXV54bq/dCDEkeG7i25oIHF1eeG7gW4gaGnhu4d1IGzhu7FjIOG7nyB04burbmcgdGhhbyB0w6FjLlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibWVtYmVycy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gb3BlbihudWxsKX0+TeG7nWkgbmjDom4gdmnDqm48L011dGF0aW9uQnV0dG9uPn0vPntzYXZlZE1lc3NhZ2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT57c2F2ZWRNZXNzYWdlfTwvQWxlcnQ+fTxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0TWVtYmVyc1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiTmjDom4gc+G7sSB2w6AgcXV54buBbiB0cnV5IGPhuq1wXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17bSA9PiBtLmlkfSBjb2x1bW5zPXtbXG4gICAgICAgIHsga2V5OiAndXNlcicsIGxhYmVsOiAnTmjDom4gdmnDqm4nLCByZW5kZXI6IG0gPT4gbS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/IHNlc3Npb24udXNlci5kaXNwbGF5TmFtZSA6IGBNw6MgbmjDom4gc+G7sTogJHttLnVzZXJJZH1gIH0sIHsga2V5OiAncm9sZXMnLCBsYWJlbDogJ1ZhaSB0csOyJywgcmVuZGVyOiBtID0+IG0ucm9sZXMubWFwKHIgPT4gcm9sZUxhYmVsc1tyXSkuam9pbignLCAnKSB9LCB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogbSA9PiA8U3RhdHVzIHZhbHVlPXttLnN0YXR1c30vPiB9LCB7IGtleTogJ3Blcm1zJywgbGFiZWw6ICdRdXnhu4FuIGhp4buHdSBs4buxYycsIHJlbmRlcjogbSA9PiBgJHttLnBlcm1pc3Npb25zLmxlbmd0aH0gcXV54buBbiDCtyB2JHttLnBlcm1pc3Npb25WZXJzaW9ufWAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAga2V5OiAnYWN0aW9ucycsIGxhYmVsOiAnJywgcmVuZGVyOiBtID0+IDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIj48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldE1lbWJlcklkKG0uaWQpfT5DaGkgdGnhur90IG5ow6JuIHPhu7E8L0J1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm1lbWJlcnMubWFuYWdlXCIgb25DbGljaz17KCkgPT4gb3BlbihtKX0+U+G7rWEgcXV54buBbjwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJtZW1iZXJzLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBkaXNhYmxlZD17bS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCB8fCBtLnN0YXR1cyA9PT0gJ3Jldm9rZWQnfSBvbkNsaWNrPXsoKSA9PiBzZXRSZW1vdmUobSl9PlRodSBo4buTaTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD5cbiAgICAgICAgfVxuICAgIF19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+XG4gPEVkaXREaWFsb2cgb3Blbj17ISFtZW1iZXJJZH0gdGl0bGU9XCJDaGkgdGnhur90IG5ow6JuIHPhu7FcIiBvbkNsb3NlPXsoKSA9PiBzZXRNZW1iZXJJZCgnJyl9IGFjdGlvbnM9ezxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0TWVtYmVySWQoJycpfT7EkMOzbmc8L0J1dHRvbj59PlxuICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntkZXRhaWwuZGF0YSAmJiA8U3VyZmFjZUNvbnRlbnQ+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiTmjDom4gdmnDqm5cIj57ZGV0YWlsLmRhdGEuZGF0YS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/IHNlc3Npb24udXNlci5kaXNwbGF5TmFtZSA6ICdNw6MgbmjDom4gc+G7sTogJyArIGRldGFpbC5kYXRhLmRhdGEudXNlcklkfTwvRGV0YWlsTGluZT5cbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJNw6MgdGjDoG5oIHZpw6puXCI+e2RldGFpbC5kYXRhLmRhdGEuaWR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiVHLhuqFuZyB0aMOhaVwiPjxTdGF0dXMgdmFsdWU9e2RldGFpbC5kYXRhLmRhdGEuc3RhdHVzfS8+PC9EZXRhaWxMaW5lPlxuICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlZhaSB0csOyXCI+e2RldGFpbC5kYXRhLmRhdGEucm9sZXMubWFwKHJvbGUgPT4gcm9sZUxhYmVsc1tyb2xlXSkuam9pbignLCAnKX08L0RldGFpbExpbmU+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiUGhpw6puIGLhuqNuIHF1eeG7gW5cIj57ZGV0YWlsLmRhdGEuZGF0YS5wZXJtaXNzaW9uVmVyc2lvbn08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJRdXnhu4FuIGhp4buHdSBs4buxY1wiPntkZXRhaWwuZGF0YS5kYXRhLnBlcm1pc3Npb25zLmpvaW4oJywgJykgfHwgJ0tow7RuZyBjw7MgcXV54buBbid9PC9EZXRhaWxMaW5lPlxuICAgIDwvU3VyZmFjZUNvbnRlbnQ+fTwvUXVlcnlTdGF0ZT5cbiA8L0VkaXREaWFsb2c+XG4gPEVkaXREaWFsb2cgb3Blbj17ZWRpdCAhPT0gdW5kZWZpbmVkfSB0aXRsZT17ZWRpdCA/ICdD4bqtcCBuaOG6rXQgcXV54buBbicgOiAnTeG7nWkgbmjDom4gdmnDqm4nfSBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0KHVuZGVmaW5lZCl9IGJ1c3k9e2ludml0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IXJvbGVzLmxlbmd0aCB8fCAoIWVkaXQgJiYgIS9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QoZW1haWwpKSB8fCBpbnZpdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBpZiAoZWRpdCkge1xuICAgICAgICAgICAgYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IG1lbWJlcklkOiBlZGl0LmlkIH0sIHZlcnNpb246IGVkaXQucGVybWlzc2lvblZlcnNpb24sIGJvZHk6IHsgcm9sZXMgfSB9KTtcbiAgICAgICAgICAgIHNldFNhdmVkTWVzc2FnZShgxJDDoyBj4bqtcCBuaOG6rXQgcXV54buBbiB0cnV5IGPhuq1wIGPhu6dhICR7ZWRpdC51c2VySWR9LmApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgaW52aXRlLmV4ZWN1dGUoeyBib2R5OiB7IGVtYWlsLCByb2xlcyB9IH0pO1xuICAgICAgICAgICAgc2V0U2F2ZWRNZXNzYWdlKGDEkMOjIGfhu61pIGzhu51pIG3hu51pIMSR4bq/biAke2VtYWlsLnRyaW0oKX0uYCk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0RWRpdCh1bmRlZmluZWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5MxrB1PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2ludml0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+eyFlZGl0ICYmIDxUZXh0RmllbGQgbGFiZWw9XCJFbWFpbCBuaMOibiB2acOqblwiIHR5cGU9XCJlbWFpbFwiIHZhbHVlPXtlbWFpbH0gb25DaGFuZ2U9e2UgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfS8+fTxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIj5QaMOibiB2YWkgdHLDsjwvVHlwb2dyYXBoeT57KE9iamVjdC5rZXlzKHJvbGVMYWJlbHMpIGFzIFJvbGVbXSkubWFwKHJvbGUgPT4gPEZvcm1Db250cm9sTGFiZWwga2V5PXtyb2xlfSBsYWJlbD17YCR7cm9sZUxhYmVsc1tyb2xlXX0gwrcgJHtwZXJtaXNzaW9uQ2F0YWxvZy5yb2xlUHJlc2V0c1tyb2xlXT8ubGVuZ3RoIHx8IDB9IHF1eeG7gW5gfSBjb250cm9sPXs8Q2hlY2tib3ggY2hlY2tlZD17cm9sZXMuaW5jbHVkZXMocm9sZSl9IG9uQ2hhbmdlPXtlID0+IHNldFJvbGVzKGUudGFyZ2V0LmNoZWNrZWQgPyBbLi4ucm9sZXMsIHJvbGVdIDogcm9sZXMuZmlsdGVyKHIgPT4gciAhPT0gcm9sZSkpfS8+fS8+KX08QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+UXV54buBbiBt4bubaSBwaOG6o2kgxJHGsOG7o2MgbcOheSBjaOG7pyBraeG7g20gbOG6oWkuIFRodSBo4buTaSBxdXnhu4FuIGzDoG0gbeG6pXQgaGnhu4d1IGzhu7FjIGNhY2hlIHbDoCBwaGnDqm4gdHJ1eSBj4bqtcCBsacOqbiBxdWFuLjwvQWxlcnQ+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48Q29uZmlybURpYWxvZyBvcGVuPXshIXJlbW92ZX0gdGl0bGU9XCJUaHUgaOG7k2kgcXV54buBbiBuaMOibiB2acOqblwiIGNvbmZpcm1MYWJlbD1cIlRodSBo4buTaSBxdXnhu4FuXCIgZGVzY3JpcHRpb249e2BOaMOibiB2acOqbiAke3JlbW92ZT8udXNlcklkIHx8IFwiXCJ9IHRyb25nICR7c2hvcC5uYW1lfTogbmfGsOG7nWkgbsOgeSBraMO0bmcgxJHGsOG7o2MgdGnhur9wIHThu6VjIHRydXkgY+G6rXAgZOG7ryBsaeG7h3UgY+G7rWEgaMOgbmcgc2F1IGtoaSB0aHUgaOG7k2kuIEzhu4tjaCBz4butIGhv4bqhdCDEkeG7mW5nIMSRxrDhu6NjIGdp4buvLmB9IG9uQ2xvc2U9eygpID0+IHNldFJlbW92ZShudWxsKX0gYnVzeT17cmV2b2tlLnBlbmRpbmd9IGVycm9yPXtyZXZva2UuZXJyb3J9IG9uQ29uZmlybT17YXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXJlbW92ZSkgcmV0dXJuO1xuICAgICAgICBhd2FpdCByZXZva2UuZXhlY3V0ZSh7IHBhdGg6IHsgbWVtYmVySWQ6IHJlbW92ZS5pZCB9LCB2ZXJzaW9uOiByZW1vdmUucGVybWlzc2lvblZlcnNpb24gfSk7XG4gICAgfX0vPjwvPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBBdWRpdFBhZ2UoKSB7IGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTsgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdEF1ZGl0RXZlbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0QXVkaXRFdmVudHMnKSB9KTsgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaOG6rXQga8O9IGhv4bqhdCDEkeG7mW5nXCIgc3VidGl0bGU9XCJBaSB0aOG7sWMgaGnhu4duLCB0aGFvIHTDoWMgbsOgbywgZOG7ryBsaeG7h3UgbsOgbyB2w6AgbcOjIHRydXkgduG6v3QuIEtow7RuZyBsxrB1IEFQSSBrZXkgaG/hurdjIHN1eSBsdeG6rW4gcmnDqm5nIGPhu6dhIEFJLlwiLz48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+QVBJIGhp4buHbiB0cuG6oyB24buBIG5nxrDhu51pIHRo4buxYyBoaeG7h24sIHRoYW8gdMOhYywgxJHhu5FpIHTGsOG7o25nLCB0aOG7nWkgZ2lhbiwgbcOjIHRydXkgduG6v3QgdsOgIHTDs20gdOG6r3QuIExv4bqhaSBhY3RvciwgcGhpw6puIGLhuqNuIHBvbGljeS9jb25maWcgdsOgIHNuYXBzaG90IGNoaSB0aeG6v3QgY2jGsGEgY8OzIHRyb25nIERUTyBuw6puIGtow7RuZyDEkcaw4bujYyBzdXkgxJFvw6FuLjwvQWxlcnQ+PFBhbmVsPjxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RBdWRpdEV2ZW50c1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiTmjhuq10IGvDvSBob+G6oXQgxJHhu5luZ1wiIHJvd3M9e2xpc3QuZGF0YS5kYXRhfSByb3dLZXk9e2EgPT4gYS5pZH0gY29sdW1ucz17W1xuICAgIHsga2V5OiAndGltZScsIGxhYmVsOiAnVGjhu51pIGdpYW4nLCByZW5kZXI6IGEgPT4gZGF0ZVRpbWUoYS5vY2N1cnJlZEF0LCBzaG9wLnRpbWV6b25lKSB9LCB7IGtleTogJ2FjdG9yJywgbGFiZWw6ICdOZ8aw4budaSB0aOG7sWMgaGnhu4duJywgcmVuZGVyOiBhID0+IGBNw6MgbmjDom4gc+G7sTogJHthLmFjdG9ySWR9YCB9LCB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnVGhhbyB0w6FjJywgcmVuZGVyOiBhID0+IGEuYWN0aW9uIH0sIHsga2V5OiAnc291cmNlJywgbGFiZWw6ICfEkOG7kWkgdMaw4bujbmcnLCByZW5kZXI6IGEgPT4gYCR7YS5yZXNvdXJjZS50eXBlfSDCtyBNw6MgxJHhu5FpIHTGsOG7o25nOiAke2EucmVzb3VyY2UuaWR9YCB9LCB7IGtleTogJ3N1bW1hcnknLCBsYWJlbDogJ0vhur90IHF14bqjJywgcmVuZGVyOiBhID0+IGEuc3VtbWFyeSB9LCB7IGtleTogJ3RyYWNlJywgbGFiZWw6ICdNw6MgdHJ1eSB24bq/dCcsIHJlbmRlcjogYSA9PiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPnthLnJlcXVlc3RJZH08L1R5cG9ncmFwaHk+IH1cbl19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PC8+OyB9XG5leHBvcnQgZnVuY3Rpb24gUHJpdmFjeVBhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IHBvbGljeSA9IHVzZUFwaSgnZ2V0UHJpdmFjeVBvbGljeScpO1xuICAgIGNvbnN0IHJlcXVlc3RzID0gdXNlQXBpKCdsaXN0UHJpdmFjeVJlcXVlc3RzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0UHJpdmFjeVJlcXVlc3RzJykgfSk7XG4gICAgY29uc3Qgc2F2ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZVByaXZhY3lQb2xpY3knLCBbJ2dldFByaXZhY3lQb2xpY3knXSk7XG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUHJpdmFjeVJlcXVlc3QnLCBbJ2xpc3RQcml2YWN5UmVxdWVzdHMnXSk7XG4gICAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoJycpLCBbbm90ZSwgc2V0Tm90ZV0gPSB1c2VTdGF0ZSgnJyksIFtjdXN0b21lcklkLCBzZXRDdXN0b21lcl0gPSB1c2VTdGF0ZSgnJyksIFtraW5kLCBzZXRLaW5kXSA9IHVzZVN0YXRlPCdleHBvcnQnIHwgJ2RlbGV0ZSc+KCdleHBvcnQnKSwgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKCcnKSwgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbZGF5c1RvdWNoZWQsIHNldERheXNUb3VjaGVkXSA9IHVzZVN0YXRlKGZhbHNlKSwgW25vdGVUb3VjaGVkLCBzZXROb3RlVG91Y2hlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtwb2xpY3lTdWJtaXR0ZWQsIHNldFBvbGljeVN1Ym1pdHRlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtwb2xpY3lTYXZlZCwgc2V0UG9saWN5U2F2ZWRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGNhblJlYWRDdXN0b21lcnMgPSB1c2VDYW4oJ2N1c3RvbWVycy5yZWFkJyk7XG4gICAgY29uc3QgW2N1c3RvbWVyU2VhcmNoSW5wdXQsIHNldEN1c3RvbWVyU2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoJycpLCBbY3VzdG9tZXJTZWFyY2gsIHNldEN1c3RvbWVyU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldEN1c3RvbWVyU2VhcmNoKGN1c3RvbWVyU2VhcmNoSW5wdXQudHJpbSgpKSwgMjUwKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xuICAgIH0sIFtjdXN0b21lclNlYXJjaElucHV0XSk7XG4gICAgY29uc3QgY3VzdG9tZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lcnMnLCB7IHF1ZXJ5OiB7IHE6IGN1c3RvbWVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0sIGNhblJlYWRDdXN0b21lcnMpO1xuICAgIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwgPSB1c2VBcGkoJ2dldEN1c3RvbWVyJywgeyBwYXRoOiB7IGN1c3RvbWVySWQgfSB9LCBjYW5SZWFkQ3VzdG9tZXJzICYmICEhY3VzdG9tZXJJZCk7XG4gICAgY29uc3Qgc2VsZWN0ZWRDdXN0b21lciA9IGN1c3RvbWVycy5kYXRhPy5kYXRhLmZpbmQoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IGN1c3RvbWVySWQpIHx8IHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwuZGF0YT8uZGF0YTtcbiAgICBjb25zdCBlZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XG4gICAgICAgIGlkZW50aXR5OiBgJHtzaG9wLmlkfTpwcml2YWN5YCxcbiAgICAgICAgc291cmNlOiBwb2xpY3kuZGF0YSA/IHsgdmVyc2lvbjogcG9saWN5LmRhdGEuZGF0YS52ZXJzaW9uLCB2YWx1ZXM6IHsgZGF5czogcG9saWN5LmRhdGEuZGF0YS5jaGF0UmV0ZW50aW9uRGF5cz8udG9TdHJpbmcoKSB8fCAnJywgbm90ZTogcG9saWN5LmRhdGEuZGF0YS5qdXJpc2RpY3Rpb25Ob3RlIH0gfSA6IHVuZGVmaW5lZCxcbiAgICAgICAgZHJhZnQ6IHsgZGF5cywgbm90ZSB9LFxuICAgICAgICBhcHBseTogdmFsdWVzID0+IHsgc2V0RGF5cyh2YWx1ZXMuZGF5cyk7IHNldE5vdGUodmFsdWVzLm5vdGUpOyB9LFxuICAgICAgICByZWZyZXNoOiAoKSA9PiBwb2xpY3kucmVmZXRjaCh7IHRocm93T25FcnJvcjogdHJ1ZSB9KSxcbiAgICB9KTtcbiAgICBjb25zdCBwb2xpY3lGb3JtID0gdXNlRHJhZnRGb3JtKGVkaXRvci5kaXJ0eSk7XG4gICAgY29uc3QgZGF5c0Vycm9yID0gIS9eXFxkKyQvLnRlc3QoZGF5cykgfHwgTnVtYmVyKGRheXMpIDwgMSB8fCBOdW1iZXIoZGF5cykgPiAzNjUwMCA/ICdOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gMzYuNTAwIG5nw6B5LicgOiAnJztcbiAgICBjb25zdCBub3RlRXJyb3IgPSBjb2RlUG9pbnRMZW5ndGgobm90ZS50cmltKCkpIDwgNSB8fCBjb2RlUG9pbnRMZW5ndGgobm90ZSkgPiAyMDAwID8gJ05o4bqtcCBjxINuIGPhu6kgdOG7qyA1IMSR4bq/biAyLjAwMCBrw70gdOG7sS4nIDogJyc7XG4gICAgY29uc3Qgc2hvd0RheXNFcnJvciA9IChkYXlzVG91Y2hlZCB8fCBwb2xpY3lTdWJtaXR0ZWQpICYmICEhZGF5c0Vycm9yO1xuICAgIGNvbnN0IHNob3dOb3RlRXJyb3IgPSAobm90ZVRvdWNoZWQgfHwgcG9saWN5U3VibWl0dGVkKSAmJiAhIW5vdGVFcnJvcjtcbiAgICBjb25zdCBzYXZlUG9saWN5ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRQb2xpY3lTdWJtaXR0ZWQodHJ1ZSk7XG4gICAgICAgIGlmIChkYXlzRXJyb3IgfHwgbm90ZUVycm9yIHx8ICFlZGl0b3IuZGlydHkpIHJldHVybjtcbiAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBlZGl0b3IucHJlcGFyZSgpOyBpZiAoIXByZXBhcmVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgZGF5cywgbm90ZSB9O1xuICAgICAgICBzZXRQb2xpY3lTYXZlZCgnJyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzYXZlLmV4ZWN1dGUoeyB2ZXJzaW9uOiBwcmVwYXJlZC52ZXJzaW9uLCBib2R5OiB7XG4gICAgICAgICAgICAgICAgLi4uKHByZXBhcmVkLnBhdGNoLmRheXMgIT09IHVuZGVmaW5lZCA/IHsgY2hhdFJldGVudGlvbkRheXM6IE51bWJlcihwcmVwYXJlZC5wYXRjaC5kYXlzKSB9IDoge30pLFxuICAgICAgICAgICAgICAgIC4uLihwcmVwYXJlZC5wYXRjaC5ub3RlICE9PSB1bmRlZmluZWQgPyB7IGp1cmlzZGljdGlvbk5vdGU6IHByZXBhcmVkLnBhdGNoLm5vdGUgfSA6IHt9KSxcbiAgICAgICAgICAgIH0gfSk7XG4gICAgICAgICAgICBjb25zdCBjbGVhbiA9IGVkaXRvci5jb21taXR0ZWQoeyB2ZXJzaW9uOiByZXN1bHQuZGF0YS52ZXJzaW9uLCB2YWx1ZXM6IHsgZGF5czogcmVzdWx0LmRhdGEuY2hhdFJldGVudGlvbkRheXM/LnRvU3RyaW5nKCkgfHwgJycsIG5vdGU6IHJlc3VsdC5kYXRhLmp1cmlzZGljdGlvbk5vdGUgfSB9LCBzdWJtaXR0ZWQpO1xuICAgICAgICAgICAgc2V0UG9saWN5U2F2ZWQoY2xlYW4gPyAnxJDDoyBsxrB1IGLhuqNuIG5ow6FwIGNow61uaCBzw6FjaCBsxrB1IHRy4buvLicgOiAnxJDDoyBsxrB1IHBo4bqnbiB0aGF5IMSR4buVaSDEkcOjIGfhu61pOyBjaOG7iW5oIHPhu61hIG3hu5tpIHbhuqtuIGNoxrBhIMSRxrDhu6NjIGzGsHUuJyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7IGVkaXRvci5mYWlsZWQoZXJyb3IpOyB9XG4gICAgfTtcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIlF1eeG7gW4gcmnDqm5nIHTGsCAmIHbDsm5nIMSR4budaSBk4buvIGxp4buHdVwiIHN1YnRpdGxlPVwiVMOhY2ggY+G6pXUgaMOsbmggbmjDoXAgduG7m2kgY2jDrW5oIHPDoWNoIMSRxrDhu6NjIGR1eeG7h3Q7IHnDqnUgY+G6p3UgeMOzYSBraMO0bmcgdOG7sSB2xrDhu6N0IMSRaeG7gXUga2nhu4duIGzGsHUgY2jhu6luZyB04burLlwiLz48U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMWZyIDEuNGZyJyB9fT48UGFuZWwgdGl0bGU9XCJDaMOtbmggc8OhY2ggbMawdSB0cuG7r1wiIGJvZHlNb2RlPVwiaW5zZXRcIj48UXVlcnlTdGF0ZSBxdWVyeT17cG9saWN5fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj48Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtwb2xpY3lGb3JtfSBvblN1Ym1pdD17ZXZlbnQgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyB2b2lkIHNhdmVQb2xpY3koKTsgfX0+PEVycm9yTm90aWNlIGVycm9yPXtzYXZlLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17eyBkYXlzOiAnU+G7kSBuZ8OgeSBsxrB1IGjhu5lpIHRob+G6oWknLCBub3RlOiAnQ8SDbiBj4bupIC8gdGjhu4sgdHLGsOG7nW5nIMOhcCBk4bulbmcnIH19IGJ1c3k9e3NhdmUucGVuZGluZ30vPntwb2xpY3lTYXZlZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPntwb2xpY3lTYXZlZH08L0FsZXJ0Pn17cG9saWN5LmRhdGEgJiYgPFN0YXR1cyB2YWx1ZT17cG9saWN5LmRhdGEuZGF0YS5zdGF0dXN9Lz59PFRleHRGaWVsZCBsYWJlbD1cIlPhu5EgbmfDoHkgbMawdSBo4buZaSB0aG/huqFpXCIgdmFsdWU9e2RheXN9IG9uQmx1cj17KCkgPT4gc2V0RGF5c1RvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtlID0+IHsgc2V0RGF5cyhlLnRhcmdldC52YWx1ZSk7IHNldERheXNUb3VjaGVkKHRydWUpOyBzZXRQb2xpY3lTYXZlZCgnJyk7IH19IHR5cGU9XCJudW1iZXJcIiBpbnB1dFByb3BzPXt7IG1pbjogMSwgbWF4OiAzNjUwMCwgc3RlcDogMSB9fSBlcnJvcj17c2hvd0RheXNFcnJvcn0gaGVscGVyVGV4dD17c2hvd0RheXNFcnJvciA/IGRheXNFcnJvciA6ICdOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gMzYuNTAwIG5nw6B5Lid9Lz48VGV4dEZpZWxkIGxhYmVsPVwiQ8SDbiBj4bupIC8gdGjhu4sgdHLGsOG7nW5nIMOhcCBk4bulbmdcIiBtdWx0aWxpbmUgbWluUm93cz17NH0gdmFsdWU9e25vdGV9IG9uQmx1cj17KCkgPT4gc2V0Tm90ZVRvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtlID0+IHsgc2V0Tm90ZShlLnRhcmdldC52YWx1ZSk7IHNldE5vdGVUb3VjaGVkKHRydWUpOyBzZXRQb2xpY3lTYXZlZCgnJyk7IH19IGVycm9yPXtzaG93Tm90ZUVycm9yfSBoZWxwZXJUZXh0PXtzaG93Tm90ZUVycm9yID8gbm90ZUVycm9yIDogJ1Thu5FpIHRoaeG7g3UgNSB2w6AgdOG7kWkgxJFhIDIuMDAwIGvDvSB04buxLid9Lz48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByaXZhY3kubWFuYWdlXCIgdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtzYXZlLnBlbmRpbmd9IGRpc2FibGVkPXshcG9saWN5LmRhdGEgfHwgIWVkaXRvci5kaXJ0eSB8fCBzYXZlLnBlbmRpbmcgfHwgISFkYXlzRXJyb3IgfHwgISFub3RlRXJyb3J9PkzGsHUgYuG6o24gbmjDoXAgY2jDrW5oIHPDoWNoPC9NdXRhdGlvbkJ1dHRvbj48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+S2jDtG5nIHThu7EgY2jhu6luZyBuaOG6rW4gdHXDom4gdGjhu6cgcGjDoXAgbHXhuq10LiBQaMOqIGR1eeG7h3QgecOqdSBj4bqndSB4w7NhIGPhuqduIHjDoWMgdGjhu7FjIG7Dom5nIGNhbyBj4bunYSBiYWNrZW5kOyBsdeG7k25nIE9JREMgc3RlcC11cCBjaMawYSDEkcaw4bujYyB4w6FjIG1pbmggdHJvbmcgZnJvbnRlbmQgbsOgeS48L0FsZXJ0PjwvRm9ybUZpZWxkcz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD48UGFuZWwgdGl0bGU9XCJZw6p1IGPhuqd1IGPhu6dhIGtow6FjaFwiIGFjdGlvbj17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcml2YWN5Lm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW4odHJ1ZSl9PlThuqFvIHnDqnUgY+G6p3U8L011dGF0aW9uQnV0dG9uPn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e3JlcXVlc3RzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57cmVxdWVzdHMuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJZw6p1IGPhuqd1IHF1eeG7gW4gcmnDqm5nIHTGsFwiIHJvd3M9e3JlcXVlc3RzLmRhdGEuZGF0YX0gcm93S2V5PXtyID0+IHIuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiByID0+IGBNw6Mga2jDoWNoIGjDoG5nOiAke3IuY3VzdG9tZXJJZH1gIH0sIHsga2V5OiAna2luZCcsIGxhYmVsOiAnWcOqdSBj4bqndScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLmtpbmR9Lz4gfSwgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLnN0YXR1c30vPiB9LCB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiByID0+IHIucmVhc29uIH1cbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e3JlcXVlc3RzLmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD48L1NlY3Rpb25HcmlkPjxDb25zZW50TWFuYWdlbWVudCBjdXN0b21lcnM9e2N1c3RvbWVycy5kYXRhPy5kYXRhIHx8IFtdfSBjYW5SZWFkQ3VzdG9tZXJzPXtjYW5SZWFkQ3VzdG9tZXJzfSBzaG9wSWQ9e3Nob3AuaWR9IC8+XG4gPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9XCJZw6p1IGPhuqd1IGThu68gbGnhu4d1IGPDoSBuaMOiblwiIG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfSBidXN5PXtjcmVhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjdXN0b21lcklkIHx8IGNvZGVQb2ludExlbmd0aChyZWFzb24udHJpbSgpKSA8IDUgfHwgY3JlYXRlLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IGtpbmQsIGN1c3RvbWVySWQsIHJlYXNvbiB9IH0pO1xuICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICB9XG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+VOG6oW8gecOqdSBj4bqndSBjaOG7nSBkdXnhu4d0PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvciB8fCBjdXN0b21lcnMuZXJyb3IgfHwgc2VsZWN0ZWRDdXN0b21lckRldGFpbC5lcnJvcn0vPjxGb3JtRmllbGRzID48VGV4dEZpZWxkIGxhYmVsPVwiVMOsbSBraMOhY2ggaMOgbmdcIiB2YWx1ZT17Y3VzdG9tZXJTZWFyY2hJbnB1dH0gb25DaGFuZ2U9e2UgPT4gc2V0Q3VzdG9tZXJTZWFyY2hJbnB1dChlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY2FuUmVhZEN1c3RvbWVyc30gaGVscGVyVGV4dD1cIlTDrG0gdGhlbyBtw6MgaG/hurdjIHTDqm4ga2jDoWNoOyBBUEkgaOG7lyB0cuG7oyB0w6xtIGtp4bq/bSB2w6AgY3Vyc29yLlwiLz48VGV4dEZpZWxkIGxhYmVsPVwiS2jDoWNoIGjDoG5nXCIgc2VsZWN0IHZhbHVlPXtjdXN0b21lcklkfSBvbkNoYW5nZT17ZSA9PiBzZXRDdXN0b21lcihlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY2FuUmVhZEN1c3RvbWVycyB8fCAoY3VzdG9tZXJzLmlzUGVuZGluZyAmJiAhY3VzdG9tZXJzLmRhdGEpfT57Y3VzdG9tZXJJZCAmJiAhY3VzdG9tZXJzLmRhdGE/LmRhdGEuc29tZShjdXN0b21lciA9PiBjdXN0b21lci5pZCA9PT0gY3VzdG9tZXJJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXtjdXN0b21lcklkfT57c2VsZWN0ZWRDdXN0b21lcj8uZGlzcGxheU5hbWUgfHwgKHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIGtow6FjaCDEkcOjIGNo4buNbuKApicgOiBjdXN0b21lcklkKX08L01lbnVJdGVtPn17Y3VzdG9tZXJzLmRhdGE/LmRhdGEubWFwKGMgPT4gPE1lbnVJdGVtIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PntjLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJraMOhY2ggaMOgbmdcIiBsb2FkZWRDb3VudD17Y3VzdG9tZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtjdXN0b21lcnMuaGFzTW9yZX0gYnVzeT17Y3VzdG9tZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2N1c3RvbWVycy5sb2FkTW9yZX0vPntjdXN0b21lcnMuaXNFcnJvciAmJiA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAoY3VzdG9tZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gY3VzdG9tZXJzLmxvYWRNb3JlKCkgOiBjdXN0b21lcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCBraMOhY2g8L0J1dHRvbj59PFRleHRGaWVsZCBsYWJlbD1cIkxv4bqhaSB5w6p1IGPhuqd1XCIgc2VsZWN0IHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZSA9PiBzZXRLaW5kKGUudGFyZ2V0LnZhbHVlIGFzIHR5cGVvZiBraW5kKX0+PE1lbnVJdGVtIHZhbHVlPVwiZXhwb3J0XCI+WHXhuqV0IGThu68gbGnhu4d1IGPDoSBuaMOibjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiZGVsZXRlXCI+WMOzYSBk4buvIGxp4buHdSBjw6EgbmjDom48L01lbnVJdGVtPjwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gLyB4w6FjIG1pbmggecOqdSBj4bqndVwiIG11bHRpbGluZSBtaW5Sb3dzPXszfSB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfS8+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48Lz47XG59XG50eXBlIENvbnNlbnRDdXN0b21lciA9IFBpY2s8Q3VzdG9tZXIsICdpZCcgfCAnZGlzcGxheU5hbWUnIHwgJ2VtYWlsJyB8ICdwaG9uZScgfCAnZXh0ZXJuYWxJZGVudGl0eScgfCAncmVkYWN0ZWRGaWVsZHMnPjtcbmNvbnN0IGNvbnNlbnRDb3B5VmVyc2lvbiA9IDE7XG5jb25zdCBjb25zZW50UmVjb25maXJtQ29weSA9ICdC4bqhbiBjw7MgxJHhu5NuZyDDvSBuaOG6rW4gbuG7mWkgZHVuZyB0aeG6v3AgdGjhu4sgdOG7qyBj4butYSBow6BuZyBxdWEga8OqbmggxJHDoyBjaOG7jW4ga2jDtG5nPyBC4bqhbiBjw7MgdGjhu4MgcsO6dCBs4bqhaSDEkeG7k25nIMO9IGLhuqV0IGPhu6kgbMO6YyBuw6BvLiBUaW4gbmjhuq9uIHBo4bulYyB24bulIMSRxqFuIGjDoG5nIGtow7RuZyB0aGF5IMSR4buVaS4nO1xuZnVuY3Rpb24gQ29uc2VudE1hbmFnZW1lbnQoeyBjdXN0b21lcnMsIGNhblJlYWRDdXN0b21lcnMsIHNob3BJZCB9OiB7IGN1c3RvbWVyczogQ29uc2VudEN1c3RvbWVyW107IGNhblJlYWRDdXN0b21lcnM6IGJvb2xlYW47IHNob3BJZDogc3RyaW5nIH0pIHtcbiAgICBjb25zdCBjb25zZW50TGlzdCA9IHVzZVBhZ2VkQXBpKCdsaXN0Q3VzdG9tZXJDb25zZW50cycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdEN1c3RvbWVyQ29uc2VudHMnKSB9KTtcbiAgICBjb25zdCBjaGFsbGVuZ2VMaXN0ID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lckNvbnNlbnRDaGFsbGVuZ2VzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0Q3VzdG9tZXJDb25zZW50Q2hhbGxlbmdlcycpIH0pO1xuICAgIGNvbnN0IGNyZWF0ZUNoYWxsZW5nZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUN1c3RvbWVyQ29uc2VudENoYWxsZW5nZScsIFsnbGlzdEN1c3RvbWVyQ29uc2VudENoYWxsZW5nZXMnXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJJZCwgc2V0U2VsZWN0ZWRDdXN0b21lcklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbY2hhbm5lbCwgc2V0Q2hhbm5lbF0gPSB1c2VTdGF0ZTwnbWVzc2VuZ2VyJyB8ICdlbWFpbCcgfCAnc21zJz4oJ21lc3NlbmdlcicpO1xuICAgIGNvbnN0IFtjcmVhdGVkLCBzZXRDcmVhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBjdXN0b21lcklkID0gY3VzdG9tZXJzLnNvbWUoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IHNlbGVjdGVkQ3VzdG9tZXJJZCkgPyBzZWxlY3RlZEN1c3RvbWVySWQgOiBjdXN0b21lcnNbMF0/LmlkIHx8ICcnO1xuICAgIGNvbnN0IGN1c3RvbWVyID0gY3VzdG9tZXJzLmZpbmQoY2FuZGlkYXRlID0+IGNhbmRpZGF0ZS5pZCA9PT0gY3VzdG9tZXJJZCk7XG4gICAgY29uc3QgcmVkYWN0ZWQgPSBjdXN0b21lcj8ucmVkYWN0ZWRGaWVsZHMgfHwgW107XG4gICAgY29uc3QgYXZhaWxhYmxlQ2hhbm5lbHMgPSBbXG4gICAgICAgIHsgdmFsdWU6ICdtZXNzZW5nZXInIGFzIGNvbnN0LCBsYWJlbDogJ01lc3NlbmdlcicsIGF2YWlsYWJsZTogQm9vbGVhbihjdXN0b21lcj8uZXh0ZXJuYWxJZGVudGl0eSkgfSxcbiAgICAgICAgeyB2YWx1ZTogJ3NtcycgYXMgY29uc3QsIGxhYmVsOiAnU01TJywgYXZhaWxhYmxlOiBCb29sZWFuKGN1c3RvbWVyPy5waG9uZSAmJiAhcmVkYWN0ZWQuaW5jbHVkZXMoJ3Bob25lJykpIH0sXG4gICAgICAgIHsgdmFsdWU6ICdlbWFpbCcgYXMgY29uc3QsIGxhYmVsOiAnRW1haWwnLCBhdmFpbGFibGU6IEJvb2xlYW4oY3VzdG9tZXI/LmVtYWlsICYmICFyZWRhY3RlZC5pbmNsdWRlcygnZW1haWwnKSkgfSxcbiAgICBdLmZpbHRlcihpdGVtID0+IGl0ZW0uYXZhaWxhYmxlKTtcbiAgICBjb25zdCBzZWxlY3RlZENoYW5uZWwgPSBhdmFpbGFibGVDaGFubmVscy5maW5kKGl0ZW0gPT4gaXRlbS52YWx1ZSA9PT0gY2hhbm5lbCk/LnZhbHVlIHx8IGF2YWlsYWJsZUNoYW5uZWxzWzBdPy52YWx1ZSB8fCBjaGFubmVsO1xuICAgIGNvbnN0IGNoYW5uZWxJc0F2YWlsYWJsZSA9IGF2YWlsYWJsZUNoYW5uZWxzLnNvbWUoaXRlbSA9PiBpdGVtLnZhbHVlID09PSBzZWxlY3RlZENoYW5uZWwpO1xuICAgIGNvbnN0IHJlcXVlc3RSZWNvbmZpcm1hdGlvbiA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFjdXN0b21lcklkIHx8ICFjYW5SZWFkQ3VzdG9tZXJzIHx8ICFjaGFubmVsSXNBdmFpbGFibGUpIHJldHVybjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZUNoYWxsZW5nZS5leGVjdXRlKHsgcGF0aDogeyBjdXN0b21lcklkIH0sIGJvZHk6IHsgcHVycG9zZTogJ21hcmtldGluZycsIGNoYW5uZWw6IHNlbGVjdGVkQ2hhbm5lbCwgbWVzc2FnZTogY29uc2VudFJlY29uZmlybUNvcHksIGNvbnRlbnRWZXJzaW9uOiBjb25zZW50Q29weVZlcnNpb24gfSB9KTtcbiAgICAgICAgICAgIHNldENyZWF0ZWQodHJ1ZSk7XG4gICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChbY2hhbGxlbmdlTGlzdC5yZWZldGNoKCksIGNvbnNlbnRMaXN0LnJlZmV0Y2goKV0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHsgLyogRXJyb3JOb3RpY2Uga2VlcHMgdGhlIEFQSSByZXN1bHQgdmlzaWJsZS4gKi8gfVxuICAgIH07XG4gICAgcmV0dXJuIDxQYW5lbCB0aXRsZT1cIkNvbnNlbnQgbWFya2V0aW5nIHbDoCB4w6FjIG5o4bqtbiBs4bqhaVwiIGJlZm9yZUdhcD1cInNlY3Rpb25cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgIDxGb3JtRmllbGRzPlxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkNvbnNlbnQgxJHGsOG7o2MgbMawdSB0aGVvIGtow6FjaCwgbeG7pWMgxJHDrWNoLCBrw6puaCwgcGhpw6puIGLhuqNuIHbDoCBs4buLY2ggc+G7rS4gVOG6oW8gecOqdSBj4bqndSBjaOG7iSB04bqhbyBjaGFsbGVuZ2UgxJFhbmcgY2jhu507IGtow7RuZyBi4bqtdCBjb25zZW50LiBNw7RpIHRyxrDhu51uZyBsb2NhbCBraMO0bmcgY8OzIG5ow6AgY3VuZyBj4bqlcCBn4butaSBlbWFpbC9TTVMvTWV0YSBuw6puIGtow7RuZyBraOG6s25nIMSR4buLbmggxJHDoyBn4butaSBsaW5rIHRo4bqtdC48L0FsZXJ0PlxuICAgICAgICAgICAge2NhblJlYWRDdXN0b21lcnMgPyA8PlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiS2jDoWNoIGjDoG5nXCIgdmFsdWU9e2N1c3RvbWVySWR9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldFNlbGVjdGVkQ3VzdG9tZXJJZChldmVudC50YXJnZXQudmFsdWUpOyBzZXRDcmVhdGVkKGZhbHNlKTsgfX0gZGlzYWJsZWQ9eyFjdXN0b21lcn0+XG4gICAgICAgICAgICAgICAgICAgIHtjdXN0b21lcnMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkvDqm5oIGPhuqduIHjDoWMgbmjhuq1uXCIgdmFsdWU9e3NlbGVjdGVkQ2hhbm5lbH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0Q2hhbm5lbChldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIGNoYW5uZWwpOyBzZXRDcmVhdGVkKGZhbHNlKTsgfX0gZGlzYWJsZWQ9eyFhdmFpbGFibGVDaGFubmVscy5sZW5ndGh9PlxuICAgICAgICAgICAgICAgICAgICB7YXZhaWxhYmxlQ2hhbm5lbHMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS52YWx1ZX0gdmFsdWU9e2l0ZW0udmFsdWV9PntpdGVtLmxhYmVsfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD17YE7hu5lpIGR1bmcgdiR7Y29uc2VudENvcHlWZXJzaW9ufWB9Pntjb25zZW50UmVjb25maXJtQ29weX08L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgeyFhdmFpbGFibGVDaGFubmVscy5sZW5ndGggJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPktow7RuZyBjw7Mga8OqbmggbGnDqm4gaOG7hyBjw7JuIHF1eeG7gW4geGVtIGNobyBraMOhY2ggxJHDoyBjaOG7jW4uPC9BbGVydD59XG4gICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcml2YWN5Lm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtjcmVhdGVDaGFsbGVuZ2UucGVuZGluZ30gZGlzYWJsZWQ9eyFjdXN0b21lcklkIHx8ICFjaGFubmVsSXNBdmFpbGFibGUgfHwgIWNhblJlYWRDdXN0b21lcnN9IG9uQ2xpY2s9eygpID0+IHZvaWQgcmVxdWVzdFJlY29uZmlybWF0aW9uKCl9PlThuqFvIHnDqnUgY+G6p3UgeMOhYyBuaOG6rW4gbOG6oWk8L011dGF0aW9uQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlQ2hhbGxlbmdlLmVycm9yIHx8IGNvbnNlbnRMaXN0LmVycm9yIHx8IGNoYWxsZW5nZUxpc3QuZXJyb3J9Lz5cbiAgICAgICAgICAgICAgICB7Y3JlYXRlZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPsSQw6MgdOG6oW8gY2hhbGxlbmdlIGNo4budIGtow6FjaCB4w6FjIG5o4bqtbi4gVHLhuqFuZyB0aMOhaSBuw6B5IGNoxrBhIHBo4bqjaSBjb25zZW50IMSRxrDhu6NjIGPhuqVwLjwvQWxlcnQ+fVxuICAgICAgICAgICAgPC8+IDogPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkPhuqduIHF1eeG7gW4gY3VzdG9tZXJzLnJlYWQgxJHhu4MgY2jhu41uIGtow6FjaC4gRGFuaCBzw6FjaCB2w6AgdGjDtG5nIHRpbiBuaOG6rW4gZOG6oW5nIMSRxrDhu6NjIOG6qW4uPC9BbGVydD59XG4gICAgICAgICAgICA8RmllbGRHcm91cCByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQuG6o24gZ2hpIGNvbnNlbnQgaGnhu4duIHThuqFpXCI+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIj5C4bqjbiBnaGkgY29uc2VudCBoaeG7h24gdOG6oWk8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2NvbnNlbnRMaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57Y29uc2VudExpc3QuZGF0YSAmJiA8PlxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiTOG7i2NoIHPhu60gY29uc2VudCBraMOhY2ggaMOgbmdcIiByb3dzPXtjb25zZW50TGlzdC5kYXRhLmRhdGF9IHJvd0tleT17cmVjb3JkID0+IHJlY29yZC5pZH0gY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiByZWNvcmQgPT4gYE3DoyBraMOhY2ggaMOgbmc6ICR7cmVjb3JkLmN1c3RvbWVySWR9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwdXJwb3NlJywgbGFiZWw6ICdN4bulYyDEkcOtY2gnLCByZW5kZXI6IHJlY29yZCA9PiBidXNpbmVzc0xhYmVsKHJlY29yZC5wdXJwb3NlKSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjaGFubmVsJywgbGFiZWw6ICdLw6puaCcsIHJlbmRlcjogcmVjb3JkID0+IGJ1c2luZXNzTGFiZWwocmVjb3JkLmNoYW5uZWwpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogcmVjb3JkID0+IDxTdGF0dXMgdmFsdWU9e3JlY29yZC5zdGF0dXN9IGRvbWFpbj1cImNvbnNlbnRcIi8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3ZlcnNpb24nLCBsYWJlbDogJ1BoacOqbiBi4bqjbicsIHJlbmRlcjogcmVjb3JkID0+IHJlY29yZC52ZXJzaW9uIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2V2aWRlbmNlJywgbGFiZWw6ICdC4bqxbmcgY2jhu6luZyBn4bqnbiBuaOG6pXQnLCByZW5kZXI6IHJlY29yZCA9PiB7IGNvbnN0IGxhdGVzdCA9IHJlY29yZC5oaXN0b3J5LmF0KC0xKTsgcmV0dXJuIGxhdGVzdCA/IGAke2J1c2luZXNzTGFiZWwobGF0ZXN0LmFjdGlvbiwgJ2NvbnNlbnQnKX0gwrcgJHtsYXRlc3QuZXZpZGVuY2VUeXBlfSDCtyAke2xhdGVzdC5ldmlkZW5jZVJlZmVyZW5jZSB8fCAn4oCUJ31gIDogJ0NoxrBhIGPDsyc7IH0gfSxcbiAgICAgICAgICAgICAgICAgICAgXX0vPlxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17Y29uc2VudExpc3QuZGF0YS5wYWdlfS8+XG4gICAgICAgICAgICAgICAgPC8+fTwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgIDwvRmllbGRHcm91cD5cbiAgICAgICAgICAgIDxGaWVsZEdyb3VwIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJZw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budXCI+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIj5Zw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtjaGFsbGVuZ2VMaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57Y2hhbGxlbmdlTGlzdC5kYXRhICYmIDw+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJZw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budXCIgcm93cz17Y2hhbGxlbmdlTGlzdC5kYXRhLmRhdGF9IHJvd0tleT17Y2hhbGxlbmdlID0+IGNoYWxsZW5nZS5pZH0gY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiBjaGFsbGVuZ2UgPT4gYE3DoyBraMOhY2ggaMOgbmc6ICR7Y2hhbGxlbmdlLmN1c3RvbWVySWR9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwdXJwb3NlJywgbGFiZWw6ICdN4bulYyDEkcOtY2gnLCByZW5kZXI6IGNoYWxsZW5nZSA9PiBidXNpbmVzc0xhYmVsKGNoYWxsZW5nZS5wdXJwb3NlKSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjaGFubmVsJywgbGFiZWw6ICdLw6puaCcsIHJlbmRlcjogY2hhbGxlbmdlID0+IGJ1c2luZXNzTGFiZWwoY2hhbGxlbmdlLmNoYW5uZWwpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnWcOqdSBj4bqndScsIHJlbmRlcjogY2hhbGxlbmdlID0+IGNoYWxsZW5nZS5hY3Rpb24gPT09ICd3aXRoZHJhdycgPyAnTmfhu6tuZyBtYXJrZXRpbmcnIDogJ1jDoWMgbmjhuq1uIG1hcmtldGluZycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnc3RhdHVzJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBjaGFsbGVuZ2UgPT4gPFN0YXR1cyB2YWx1ZT17Y2hhbGxlbmdlLnN0YXR1c30gZG9tYWluPVwiY29uc2VudFwiLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXhwaXJlcycsIGxhYmVsOiAnSOG6v3QgaOG6oW4nLCByZW5kZXI6IGNoYWxsZW5nZSA9PiBkYXRlVGltZShjaGFsbGVuZ2UuZXhwaXJlc0F0LCAnQXNpYS9Ib19DaGlfTWluaCcpIH0sXG4gICAgICAgICAgICAgICAgICAgIF19Lz5cbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VyIHBhZ2U9e2NoYWxsZW5nZUxpc3QuZGF0YS5wYWdlfS8+XG4gICAgICAgICAgICAgICAgPC8+fTwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgIDwvRmllbGRHcm91cD5cbiAgICAgICAgICAgIHtjYW5SZWFkQ3VzdG9tZXJzICYmIDxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz17YC9zLyR7c2hvcElkfS9jdXN0b21lcnNgfSBzaXplPVwic21hbGxcIiBzeD17eyBhbGlnblNlbGY6ICdmbGV4LXN0YXJ0JyB9fT5N4bufIGRhbmggc8OhY2gga2jDoWNoPC9CdXR0b24+fVxuICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgPC9QYW5lbD47XG59XG5mdW5jdGlvbiBzYXZlZENvbnNlbnRDaGFsbGVuZ2UodmFsdWU6IHVua25vd24pOiBQdWJsaWNDb25zZW50Q2hhbGxlbmdlVmlldyB8IG51bGwge1xuICAgIHRyeSB7IGFzc2VydFNjaGVtYTxQdWJsaWNDb25zZW50Q2hhbGxlbmdlVmlldz4oJ1B1YmxpY0NvbnNlbnRDaGFsbGVuZ2VWaWV3JywgdmFsdWUpOyByZXR1cm4gdmFsdWU7IH1cbiAgICBjYXRjaCB7IHJldHVybiBudWxsOyB9XG59XG5leHBvcnQgZnVuY3Rpb24gQ29uc2VudENvbmZpcm1hdGlvblBhZ2UoKSB7XG4gICAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHRva2VuID0gcGFyYW1zLmdldCgndG9rZW4nKSB8fCAnJztcbiAgICBjb25zdCBbY2hhbGxlbmdlLCBzZXRDaGFsbGVuZ2VdID0gdXNlU3RhdGU8UHVibGljQ29uc2VudENoYWxsZW5nZVZpZXcgfCBudWxsPigoKSA9PiBzYXZlZENvbnNlbnRDaGFsbGVuZ2UoKGxvY2F0aW9uLnN0YXRlIGFzIHsgY29uc2VudENoYWxsZW5nZT86IHVua25vd24gfSB8IG51bGwpPy5jb25zZW50Q2hhbGxlbmdlKSk7XG4gICAgY29uc3QgW2NvbmZpcm1hdGlvbiwgc2V0Q29uZmlybWF0aW9uXSA9IHVzZVN0YXRlPENvbnNlbnRDb25maXJtYXRpb24gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzdWJtaXR0ZWREZWNpc2lvbiwgc2V0U3VibWl0dGVkRGVjaXNpb25dID0gdXNlU3RhdGU8J2FjY2VwdCcgfCAnZGVjbGluZScgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBleGNoYW5nZUlkID0gdXNlUmVmKGNyeXB0by5yYW5kb21VVUlEKCkpO1xuICAgIGNvbnN0IGNvbmZpcm1hdGlvbklkID0gdXNlUmVmPHsgZGVjaXNpb246ICdhY2NlcHQnIHwgJ2RlY2xpbmUnOyBrZXk6IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgZXhjaGFuZ2UgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghdG9rZW4gfHwgcGVuZGluZykgcmV0dXJuO1xuICAgICAgICBzZXRQZW5kaW5nKHRydWUpOyBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGNzcmYgPSBhd2FpdCByZXF1ZXN0KCdnZXRDc3JmVG9rZW4nKTtcbiAgICAgICAgICAgIHNldENzcmZUb2tlbihjc3JmLmRhdGEuY3NyZlRva2VuKTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlcXVlc3QoJ2V4Y2hhbmdlQ29uc2VudENoYWxsZW5nZScsIHsgYm9keTogeyB0b2tlbiB9LCBpZGVtcG90ZW5jeUtleTogZXhjaGFuZ2VJZC5jdXJyZW50IH0pO1xuICAgICAgICAgICAgc2V0Q2hhbGxlbmdlKHJlc3VsdC5kYXRhKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY29uc2VudC9jb25maXJtJywgeyByZXBsYWNlOiB0cnVlLCBzdGF0ZTogeyBjb25zZW50Q2hhbGxlbmdlOiByZXN1bHQuZGF0YSB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChyZWFzb24pIHsgc2V0RXJyb3IocmVhc29uIGluc3RhbmNlb2YgRXJyb3IgPyByZWFzb24gOiBuZXcgRXJyb3IoJ0tow7RuZyB4w6FjIG1pbmggxJHGsOG7o2MgbGnDqm4ga+G6v3QuJykpOyB9XG4gICAgICAgIGZpbmFsbHkgeyBzZXRQZW5kaW5nKGZhbHNlKTsgfVxuICAgIH07XG4gICAgY29uc3QgY29uZmlybSA9IGFzeW5jIChkZWNpc2lvbjogJ2FjY2VwdCcgfCAnZGVjbGluZScpID0+IHtcbiAgICAgICAgaWYgKCFjaGFsbGVuZ2UgfHwgcGVuZGluZyB8fCBjb25maXJtYXRpb24gfHwgKHN1Ym1pdHRlZERlY2lzaW9uICYmIHN1Ym1pdHRlZERlY2lzaW9uICE9PSBkZWNpc2lvbikpIHJldHVybjtcbiAgICAgICAgY29uc3QgaW50ZW50ID0gY29uZmlybWF0aW9uSWQuY3VycmVudD8uZGVjaXNpb24gPT09IGRlY2lzaW9uID8gY29uZmlybWF0aW9uSWQuY3VycmVudCA6IHsgZGVjaXNpb24sIGtleTogY3J5cHRvLnJhbmRvbVVVSUQoKSB9O1xuICAgICAgICBjb25maXJtYXRpb25JZC5jdXJyZW50ID0gaW50ZW50O1xuICAgICAgICBzZXRTdWJtaXR0ZWREZWNpc2lvbihkZWNpc2lvbik7IHNldFBlbmRpbmcodHJ1ZSk7IHNldEVycm9yKG51bGwpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVxdWVzdCgnY29uZmlybUNvbnNlbnRDaGFsbGVuZ2UnLCB7IGJvZHk6IHsgY2hhbGxlbmdlU2Vzc2lvbklkOiBjaGFsbGVuZ2UuY2hhbGxlbmdlU2Vzc2lvbklkLCBkZWNpc2lvbiwgY29udGVudFZlcnNpb246IGNoYWxsZW5nZS5jb250ZW50VmVyc2lvbiB9LCBpZGVtcG90ZW5jeUtleTogaW50ZW50LmtleSB9KTtcbiAgICAgICAgICAgIHNldENvbmZpcm1hdGlvbihyZXN1bHQuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKHJlYXNvbikgeyBzZXRFcnJvcihyZWFzb24gaW5zdGFuY2VvZiBFcnJvciA/IHJlYXNvbiA6IG5ldyBFcnJvcignQ2jGsGEgeMOhYyBtaW5oIMSRxrDhu6NjIGvhur90IHF14bqjLiBIw6N5IHRo4butIGzhuqFpIGPDuW5nIGzhu7FhIGNo4buNbi4nKSk7IH1cbiAgICAgICAgZmluYWxseSB7IHNldFBlbmRpbmcoZmFsc2UpOyB9XG4gICAgfTtcbiAgICBjb25zdCB3aXRoZHJhd2FsID0gY2hhbGxlbmdlPy5hY3Rpb24gPT09ICd3aXRoZHJhdyc7XG4gICAgY29uc3QgY29uZmlybWF0aW9uTWVzc2FnZSA9IGNvbmZpcm1hdGlvblxuICAgICAgICA/IGNvbmZpcm1hdGlvbi5jb25zZW50U3RhdHVzID09PSAnd2l0aGRyYXduJ1xuICAgICAgICAgICAgPyAnxJDDoyBnaGkgbmjhuq1uIGtow7RuZyBuaOG6rW4gdGluIG1hcmtldGluZyBxdWEga8OqbmggbsOgeS4gVGluIG5o4bqvbiBwaOG7pWMgduG7pSDEkcahbiBow6BuZyBraMO0bmcgYuG7iyDhuqNuaCBoxrDhu59uZy4nXG4gICAgICAgICAgICA6IGNvbmZpcm1hdGlvbi5zdGF0dXMgPT09ICdkZWNsaW5lZCdcbiAgICAgICAgICAgICAgICA/ICdM4buxYSBjaOG7jW4gaGnhu4duIHThuqFpIMSRxrDhu6NjIGdp4buvIG5ndXnDqm47IGtow7RuZyBjw7MgcXV54buBbiBtYXJrZXRpbmcgbeG7m2kgbsOgbyDEkcaw4bujYyBj4bqlcC4nXG4gICAgICAgICAgICAgICAgOiAnxJDDoyBnaGkgbmjhuq1uIGzhu7FhIGNo4buNbiBj4bunYSBi4bqhbi4nXG4gICAgICAgIDogJyc7XG4gICAgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwibWFpblwiIGlkPVwibWFpbi1jb250ZW50XCIgdGFiSW5kZXg9ey0xfSBzeD17W2xheW91dFN4LnNoZWxsLnBhZ2VGYWxsYmFja0luc2V0LCB7IG1heFdpZHRoOiA5MDAsIG14OiAnYXV0bycsIG91dGxpbmU6ICdub25lJyB9XX0+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiWMOhYyBuaOG6rW4gbOG7sWEgY2jhu41uIG1hcmtldGluZ1wiIHN1YnRpdGxlPVwiTGnDqm4ga+G6v3Qgbmfhuq9uIGjhuqFuIGfhuq9uIHbhu5tpIMSRw7puZyBraMOhY2gsIGvDqm5oIHbDoCBu4buZaSBkdW5nIMSRw6MgZ+G7rWkuXCIvPlxuICAgICAgICA8UGFuZWwgdGl0bGU9e2NoYWxsZW5nZSA/IHdpdGhkcmF3YWwgPyAnTmfhu6tuZyBuaOG6rW4gdGluIG1hcmtldGluZycgOiAnWMOhYyBuaOG6rW4gbmjhuq1uIHRpbiBtYXJrZXRpbmcnIDogJ0tp4buDbSB0cmEgbGnDqm4ga+G6v3QnfSBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICA8Rm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+TOG7sWEgY2jhu41uIG7DoHkgY2jhu4kgw6FwIGThu6VuZyBjaG8gbuG7mWkgZHVuZyBtYXJrZXRpbmcuIFRyYW8gxJHhu5VpIHBo4bulYyB24bulIMSRxqFuIGjDoG5nIHbhuqtuIMSRxrDhu6NjIHjhu60gbMO9IHJpw6puZy48L0FsZXJ0PlxuICAgICAgICAgICAgICAgIHtlcnJvciAmJiA8RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yfS8+fVxuICAgICAgICAgICAgICAgIHshY2hhbGxlbmdlICYmIHRva2VuICYmIDw+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5MacOqbiBr4bq/dCBraMO0bmcgY2jhu6lhIHRow7RuZyB0aW4gY8OhIG5ow6JuLiBUaeG6v3AgdOG7pWMgxJHhu4Mga2nhu4NtIHRyYSBt4bulYyDEkcOtY2gsIGvDqm5oIHbDoCBu4buZaSBkdW5nIHRyxrDhu5tjIGtoaSBn4butaSBs4buxYSBjaOG7jW4uPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGV4Y2hhbmdlKCl9IGRpc2FibGVkPXtwZW5kaW5nfT57cGVuZGluZyA/ICfEkGFuZyBraeG7g20gdHJh4oCmJyA6IGVycm9yID8gJ1Ro4butIHjDoWMgbWluaCBs4bqhaScgOiAnWGVtIG7hu5lpIGR1bmcgecOqdSBj4bqndSd9PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC8+fVxuICAgICAgICAgICAgICAgIHshY2hhbGxlbmdlICYmICF0b2tlbiAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VGhp4bq/dSBsacOqbiBr4bq/dCBjaGFsbGVuZ2UuIEjDo3kgbeG7nyBsacOqbiBr4bq/dCDEkeG6p3kgxJHhu6cgZG8gY+G7rWEgaMOgbmcgZ+G7rWkgY2hvIGLhuqFuLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgIHtjaGFsbGVuZ2UgJiYgPD5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJN4bulYyDEkcOtY2hcIj5NYXJrZXRpbmc8L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiS8OqbmhcIj57YnVzaW5lc3NMYWJlbChjaGFsbGVuZ2UuY2hhbm5lbCl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk7hu5lpIGR1bmcgxJHDoyB4ZW1cIj57Y2hhbGxlbmdlLm1lc3NhZ2V9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlBoacOqbiBi4bqjbiBu4buZaSBkdW5nXCI+dntjaGFsbGVuZ2UuY29udGVudFZlcnNpb259PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkjhur90IGjhuqFuXCI+e2RhdGVUaW1lKGNoYWxsZW5nZS5leHBpcmVzQXQsICdBc2lhL0hvX0NoaV9NaW5oJyl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICB7Y29uZmlybWF0aW9uID8gPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIj57Y29uZmlybWF0aW9uTWVzc2FnZX08L0FsZXJ0PiA6IDxBY3Rpb25Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgY29uZmlybSgnYWNjZXB0Jyl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnZGVjbGluZSd9PntwZW5kaW5nICYmIHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0JyA/ICfEkGFuZyBnaGkgbmjhuq1u4oCmJyA6IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0JyA/ICdUaOG7rSBs4bqhaSBjw7luZyBs4buxYSBjaOG7jW4nIDogd2l0aGRyYXdhbCA/ICdYw6FjIG5o4bqtbiBuZ+G7q25nIG1hcmtldGluZycgOiAnxJDhu5NuZyDDvSBuaOG6rW4gbWFya2V0aW5nJ308L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVkXCIgb25DbGljaz17KCkgPT4gdm9pZCBjb25maXJtKCdkZWNsaW5lJyl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0J30+e3BlbmRpbmcgJiYgc3VibWl0dGVkRGVjaXNpb24gPT09ICdkZWNsaW5lJyA/ICfEkGFuZyBnaGkgbmjhuq1u4oCmJyA6IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnZGVjbGluZScgPyAnVGjhu60gbOG6oWkgY8O5bmcgbOG7sWEgY2jhu41uJyA6IHdpdGhkcmF3YWwgPyAnR2nhu68gbmd1ecOqbiBs4buxYSBjaOG7jW4nIDogJ0tow7RuZyDEkeG7k25nIMO9IG1hcmtldGluZyd9PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvQWN0aW9uR3JvdXA+fVxuICAgICAgICAgICAgICAgIDwvPn1cbiAgICAgICAgICAgICAgICB7X19NT0NLX18gJiYgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+TcO0aSB0csaw4budbmcgbG9jYWwgY2jhu4kgbcO0IHBo4buPbmcgaOG7o3AgxJHhu5NuZyB2w6AgZOG7ryBsaeG7h3U7IGtow7RuZyBn4butaSBlbWFpbC9TTVMvTWV0YSB2w6Aga2jDtG5nIGNo4bupbmcgbmjhuq1uIEJhY2tlbmQgaG/hurdjIG5ow6AgY3VuZyBj4bqlcCB0aOG6rXQuPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9QYW5lbD5cbiAgICA8L0JveD47XG59XG5leHBvcnQgZnVuY3Rpb24gSm9iUGFnZSgpIHtcbiAgICBjb25zdCB7IGpvYklkID0gJycgfSA9IHVzZVBhcmFtcygpO1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBnZXQgPSB1c2VBcGkoJ2dldEpvYicsIHsgcGF0aDogeyBqb2JJZCB9IH0pO1xuICAgIGNvbnN0IGpvYiA9IGdldC5kYXRhPy5kYXRhO1xuICAgIGNvbnN0IGRvd25sb2FkSHJlZiA9IGpvYj8uZG93bmxvYWRVcmwgPyBhdXRob3JpemVkRG93bmxvYWRIcmVmKGpvYi5kb3dubG9hZFVybCwgbG9jYXRpb24ub3JpZ2luLCBfX01PQ0tfXykgOiBudWxsO1xuICAgIGNvbnN0IGpvYlN0YXR1cyA9IGpvYj8uc3RhdHVzO1xuICAgIGNvbnN0IHsgcmVmZXRjaCB9ID0gZ2V0O1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7IGlmICgham9iU3RhdHVzIHx8ICFbJ3F1ZXVlZCcsICdydW5uaW5nJ10uaW5jbHVkZXMoam9iU3RhdHVzKSlcbiAgICAgICAgcmV0dXJuOyBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHZvaWQgcmVmZXRjaCgpLCAzMDAwKTsgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpOyB9LCBbam9iU3RhdHVzLCByZWZldGNoXSk7XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9e2BDw7RuZyB2aeG7h2MgJHtqb2JJZH1gfSBzdWJ0aXRsZT1cIlRoZW8gZMO1aSB0aeG6v24gxJHhu5kgdOG7qyBBUEkuIMSQxrDhu6NjIHRp4bq/cCBuaOG6rW4ga2jDtG5nIGPDsyBuZ2jEqWEgxJHDoyBob8OgbiB04bqldC5cIi8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2dldH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2pvYiAmJiA8UGFuZWwgdGl0bGU9XCJL4bq/dCBxdeG6oyB44butIGzDvVwiIGJvZHlNb2RlPVwiaW5zZXRcIj48Rm9ybUZpZWxkcyA+PFN0YXR1cyB2YWx1ZT17am9iLnN0YXR1c30vPjxEZXRhaWxMaW5lIGxhYmVsPVwiTG/huqFpXCI+e2J1c2luZXNzTGFiZWwoam9iLmtpbmQpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlRp4bq/biDEkeG7mVwiPntqb2IuY29tcGxldGVkfSAvIHtqb2IudG90YWwgPz8gJ0NoxrBhIGJp4bq/dCd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTOG7l2lcIj57am9iLmVycm9yQ291bnR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQ+G6rXAgbmjhuq10XCI+e2RhdGVUaW1lKGpvYi51cGRhdGVkQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT57am9iLnJvd0Vycm9ycy5sZW5ndGggPiAwICYmIDxEYXRhVGFibGUgbGFiZWw9XCJM4buXaSBjw7RuZyB2aeG7h2MgbuG7gW5cIiByb3dzPXtqb2Iucm93RXJyb3JzfSByb3dLZXk9e2UgPT4gYCR7ZS5yb3d9LSR7ZS5maWVsZH0tJHtlLmNvZGV9YH0gY29sdW1ucz17W3sga2V5OiAncm93JywgbGFiZWw6ICdEw7JuZycsIHJlbmRlcjogZSA9PiBlLnJvdyB9LCB7IGtleTogJ2ZpZWxkJywgbGFiZWw6ICdUcsaw4budbmcnLCByZW5kZXI6IGUgPT4gZS5maWVsZCB9LCB7IGtleTogJ21lc3NhZ2UnLCBsYWJlbDogJ0zhu5dpJywgcmVuZGVyOiBlID0+IGUubWVzc2FnZSB9XX0vPn08QnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgZ2V0LnJlZmV0Y2goKX0gdmFyaWFudD1cIm91dGxpbmVkXCI+S2nhu4NtIHRyYSBs4bqhaTwvQnV0dG9uPntqb2IuZG93bmxvYWRVcmwgJiYgWydzdWNjZWVkZWQnLCAncGFydGlhbCddLmluY2x1ZGVzKGpvYi5zdGF0dXMpICYmIGRvd25sb2FkSHJlZiAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cub3Blbihkb3dubG9hZEhyZWYsICdfYmxhbmsnLCAnbm9vcGVuZXIsbm9yZWZlcnJlcicpfT5N4bufIGvhur90IHF14bqjIHh14bqldDwvQnV0dG9uPn17am9iLmRvd25sb2FkVXJsICYmIFsnc3VjY2VlZGVkJywgJ3BhcnRpYWwnXS5pbmNsdWRlcyhqb2Iuc3RhdHVzKSAmJiAhZG93bmxvYWRIcmVmICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5VUkwgdOG6o2kga2jDtG5nIGFuIHRvw6BuIGhv4bq3YyBraMO0bmcgaOG7o3AgbOG7hyBuw6puIMSRw6MgYuG7iyBjaOG6t24uPC9BbGVydD59e2pvYi5zdGF0dXMgPT09ICdhd2FpdGluZ19jb25maXJtYXRpb24nICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ltcG9ydHMvJHtqb2IuaWR9YH0+WGVtIHbDoCB4w6FjIG5o4bqtbiBuaOG6rXA8L1JvdXRlTGluaz59PC9Gb3JtRmllbGRzPjwvUGFuZWw+fTwvUXVlcnlTdGF0ZT48Lz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9ldmlkZW5jZS9mcm9udGVuZC1jb21wbGV0ZW5lc3MtMjAyNjEwMTMtYWFmNzRiNy9jbGVhbi1pbnN0YWxsLXIyL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvd29ya3NwYWNlL2luZGV4LnRzeCJ9