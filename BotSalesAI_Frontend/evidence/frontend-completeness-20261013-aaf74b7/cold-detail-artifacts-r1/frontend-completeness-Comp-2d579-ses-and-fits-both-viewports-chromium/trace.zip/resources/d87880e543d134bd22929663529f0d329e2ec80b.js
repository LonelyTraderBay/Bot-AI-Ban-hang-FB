"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-TJQ5SMJY.js?v=b09c95f0";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-KKSKQFJH.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-QAEW75US.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-I7LQ6E3M.js?v=b09c95f0";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-BGQUJRJB.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-TNO3EQ4E.js?v=b09c95f0";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-PX6F3LHL.js?v=b09c95f0";

// ../../node_modules/@mui/icons-material/esm/NotificationsActiveRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var NotificationsActiveRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M18 16v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.68-1.5-1.51-1.5S10.5 3.17 10.5 4v.68C7.63 5.36 6 7.92 6 11v5l-1.3 1.29c-.63.63-.19 1.71.7 1.71h13.17c.89 0 1.34-1.08.71-1.71zm-6.01 6c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2M6.77 4.73c.42-.38.43-1.03.03-1.43-.38-.38-1-.39-1.39-.02C3.7 4.84 2.52 6.96 2.14 9.34c-.09.61.38 1.16 1 1.16.48 0 .9-.35.98-.83.3-1.94 1.26-3.67 2.65-4.94M18.6 3.28c-.4-.37-1.02-.36-1.4.02-.4.4-.38 1.04.03 1.42 1.38 1.27 2.35 3 2.65 4.94.07.48.49.83.98.83.61 0 1.09-.55.99-1.16-.38-2.37-1.55-4.48-3.25-6.05"
}), "NotificationsActiveRounded");
export {
  NotificationsActiveRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_NotificationsActiveRounded.js.map
