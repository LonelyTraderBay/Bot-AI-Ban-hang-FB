"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-TJQ5SMJY.js?v=b09c95f0";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-KKSKQFJH.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-QAEW75US.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-I7LQ6E3M.js?v=b09c95f0";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-BGQUJRJB.js?v=b09c95f0";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-TNO3EQ4E.js?v=b09c95f0";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/chunk-PX6F3LHL.js?v=b09c95f0";

// ../../node_modules/@mui/icons-material/esm/SmartphoneRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var SmartphoneRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M17 1.01 7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99M17 19H7V5h10z"
}), "SmartphoneRounded");
export {
  SmartphoneRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_SmartphoneRounded.js.map
