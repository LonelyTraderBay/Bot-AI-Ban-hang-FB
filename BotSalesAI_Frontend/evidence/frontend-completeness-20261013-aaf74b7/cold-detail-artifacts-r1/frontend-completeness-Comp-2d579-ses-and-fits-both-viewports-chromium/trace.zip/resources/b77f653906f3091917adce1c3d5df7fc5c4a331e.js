import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/notifications/index.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "demo", "PROD": false, "SSR": false, "VITE_APP_NAME": "BotSales AI", "VITE_WEB_PUSH_PUBLIC_KEY": ""};import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/react_jsx-dev-runtime.js?v=f7b97719"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { ActionGroup, FieldGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport8_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/react.js?v=f7b97719"; const useEffect = __vite__cjsImport8_react["useEffect"]; const useState = __vite__cjsImport8_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Alert, Box, Button, Checkbox, FormControlLabel, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/@mui_material.js?v=f9759e1e";
import NotificationsActiveRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/@mui_icons-material_NotificationsActiveRounded.js?v=a7114867";
import SmartphoneRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-58344f92-7b41-444b-9cce-ad9363efbcb4/deps/@mui_icons-material_SmartphoneRounded.js?v=8f52f40c";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, MutationButton, ErrorNotice, ConfirmDialog, EditDialog, DetailLine, RouteLink, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { assertPushCapability, assertPushPermissionGranted } from "/src/modules/notifications/push-capabilities.ts";
export function NotificationsPage() {
  _s();
  const { shop, session } = useScope();
  const list = useApi("listNotifications", { query: useListQuery("listNotifications") });
  const [detailId, setDetailId] = useState("");
  const detail = useApi("getNotification", { path: { resourceId: detailId } }, Boolean(detailId));
  const ack = useCommand("acknowledgeNotification", ["getNotification", "listNotifications", "listWorkItems", "listPrepJobs", "getOperationsSummary"]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Trung tâm thông báo", subtitle: "Đã gửi không đồng nghĩa đã đọc. Nhận việc là một xác nhận riêng.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/notifications/devices`, children: "Điện thoại & lịch trực" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 45,
      columnNumber: 137
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 45,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: ack.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 45,
      columnNumber: 229
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listNotifications" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 45,
        columnNumber: 269
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "inset", children: [
        list.data?.data.map((n) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.surface.inset, {
          border: 1,
          borderColor: n.acknowledgedAt ? "divider" : colors.heroBorder,
          borderRadius: visualSx.radius.large,
          bgcolor: n.acknowledgedAt ? "transparent" : colors.selected
        }], children: /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: { xs: "column", md: "row" }, justifyContent: "space-between", children: [
          /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: "row", children: [
            /* @__PURE__ */ jsxDEV(NotificationsActiveRounded, { sx: { color: "primary.main" } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 47,
              columnNumber: 134
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", children: n.title }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 47,
                columnNumber: 200
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.pageHeader.titleDescriptionGap, children: n.safeBody }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 47,
                columnNumber: 247
              }, this),
              /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "detail", children: [
                /* @__PURE__ */ jsxDEV(Status, { value: n.deliveryStatus }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 47,
                  columnNumber: 400
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { alignSelf: "center" }, children: [
                  businessLabel(n.channel),
                  " · ",
                  dateTime(n.createdAt, shop.timezone)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 47,
                  columnNumber: 435
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 47,
                columnNumber: 352
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: [layoutSx.detail.relatedContentGap, { display: "block" }], children: n.acknowledgedAt ? `Đã nhận việc lúc ${dateTime(n.acknowledgedAt, shop.timezone)}` : n.openedAt ? "Có ghi nhận mở thông báo; chưa nhận việc." : "Chưa có bằng chứng đã mở hoặc nhận việc." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 47,
                columnNumber: 588
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 47,
              columnNumber: 195
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 47,
            columnNumber: 102
          }, this),
          /* @__PURE__ */ jsxDEV(SurfaceContent, { justifyContent: "center", children: [
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(n.id), children: "Chi tiết thông báo" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 47,
              columnNumber: 968
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "operations.claim", allowedActions: n.allowedActions, action: "acknowledge", disabled: !n.workItemId || n.recipientUserId !== session.user.id, busy: ack.pending, variant: "contained", onClick: () => void ack.execute({ path: { resourceId: n.id }, body: { expectedVersion: n.version } }).catch(() => void 0), children: "Tôi nhận chuẩn bị đơn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 47,
              columnNumber: 1037
            }, this),
            n.source.type === "order" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${n.source.id}`, children: "Xem đơn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 47,
              columnNumber: 1437
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 47,
            columnNumber: 928
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 47,
          columnNumber: 15
        }, this) }, n.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 45,
          columnNumber: 396
        }, this)),
        list.data?.data.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: "Chưa có thông báo. Thông báo chuẩn bị được tạo sau khi đơn đã xác nhận và giữ hàng thành công." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 47,
          columnNumber: 1586
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data?.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 47,
          columnNumber: 1726
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 45,
        columnNumber: 335
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 45,
        columnNumber: 310
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 45,
      columnNumber: 262
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!detailId, title: "Chi tiết thông báo", onClose: () => setDetailId(""), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(""), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 48,
      columnNumber: 103
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, pendingProfile: "section", children: detail.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", children: detail.data.data.title }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 50,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { children: detail.data.data.safeBody }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 50,
        columnNumber: 75
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kênh", children: businessLabel(detail.data.data.channel) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giao thông báo", children: /* @__PURE__ */ jsxDEV(Status, { value: detail.data.data.deliveryStatus }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 51,
        columnNumber: 127
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 51,
        columnNumber: 92
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tạo lúc", children: dateTime(detail.data.data.createdAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mở lúc", children: dateTime(detail.data.data.openedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 52,
        columnNumber: 107
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nhận việc lúc", children: dateTime(detail.data.data.acknowledgedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 52,
        columnNumber: 199
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nguồn", children: [
        detail.data.data.source.type,
        " · ",
        detail.data.data.source.id
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 53,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã công việc", children: detail.data.data.workItemId || "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 53,
        columnNumber: 113
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 49,
      columnNumber: 77
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 48,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
    lineNumber: 45,
    columnNumber: 10
  }, this);
}
_s(NotificationsPage, "Lcaa6lCTdgewPS36EXD7Z1gIR8s=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand];
});
_c = NotificationsPage;
function base64Bytes(value) {
  const padded = (value + "=".repeat((4 - value.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(padded);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++)
    bytes[i] = raw.charCodeAt(i);
  return bytes;
}
function validatePolicy(input) {
  const reminder = input.minutes.trim();
  const maximum = input.max.trim();
  if (maximum === "" || !Number.isSafeInteger(Number(maximum)) || Number(maximum) < 0)
    return "Số lần nhắc tối đa phải là số nguyên từ 0 trở lên.";
  if (reminder && (!Number.isSafeInteger(Number(reminder)) || Number(reminder) < 1))
    return "Thời gian nhắc phải là số nguyên từ 1 phút trở lên.";
  if (input.enabled && !reminder)
    return "Cần nhập thời gian nhắc khi bật quy tắc.";
  if (input.enabled && !input.primary.length)
    return "Cần chọn ít nhất một người nhận chính khi bật quy tắc.";
  if (input.quiet && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.quietStart) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(input.quietEnd)))
    return "Giờ yên lặng cần có thời điểm bắt đầu và kết thúc hợp lệ.";
  if (input.channel === "telegram" && !input.telegramAvailable)
    return "Chưa có thiết bị Telegram active. Hoàn tất liên kết thật trước khi chọn kênh này.";
  return "";
}
export function DevicesPage() {
  _s2();
  const { shop, session } = useScope();
  const devices = usePagedApi("listDevices");
  const policy = useApi("getNotificationPolicy");
  const canManageMembers = useCan("members.manage");
  const [memberSearchInput, setMemberSearchInput] = useState(""), [memberSearch, setMemberSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setMemberSearch(memberSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [memberSearchInput]);
  const members = usePagedApi("listMembers", { query: { q: memberSearch || void 0 } }, canManageMembers);
  const register = useCommand("createDevice", ["listDevices"]);
  const test = useCommand("testDevice", ["listDevices", "listNotifications"]);
  const revoke = useCommand("revokeDevice", ["listDevices"]);
  const save = useCommand("updateNotificationPolicy", ["getNotificationPolicy"]);
  const pair = useCommand("beginTelegramPairing", []);
  const [deviceName, setDeviceName] = useState("Điện thoại của tôi"), [error, setError] = useState(null), [pending, setPending] = useState(false), [selected, setSelected] = useState(null), [pairing, setPairing] = useState(null), [deviceTestMessage, setDeviceTestMessage] = useState("");
  const [enabled, setEnabled] = useState(false), [minutes, setMinutes] = useState(""), [max, setMax] = useState("2"), [quiet, setQuiet] = useState(false), [quietStart, setQuietStart] = useState("22:00"), [quietEnd, setQuietEnd] = useState("08:00"), [primary, setPrimary] = useState([]), [fallback, setFallback] = useState([]), [channel, setChannel] = useState("none"), [urgent, setUrgent] = useState(false);
  const editor = useVersionedDraft({
    identity: `${shop.id}:notification-policy`,
    source: policy.data ? notificationSnapshot(policy.data.data) : void 0,
    draft: { enabled, minutes, max, quiet, quietStart, quietEnd, primary, fallback, channel, urgent },
    apply: (values) => {
      setEnabled(values.enabled);
      setMinutes(values.minutes);
      setMax(values.max);
      setQuiet(values.quiet);
      setQuietStart(values.quietStart);
      setQuietEnd(values.quietEnd);
      setPrimary(values.primary);
      setFallback(values.fallback);
      setChannel(values.channel);
      setUrgent(values.urgent);
    },
    refresh: () => policy.refetch({ throwOnError: true })
  });
  const policyForm = useDraftForm(editor.dirty);
  const deviceRegister = async () => {
    setError(null);
    setPending(true);
    try {
      if (__MOCK__) {
        await register.execute({ body: { deviceName: deviceName.trim(), endpoint: "https://example.test/mock-push", p256dh: "synthetic-device-public-key", auth: "synthetic-device-auth" } });
        return;
      }
      assertPushCapability({ secureContext: window.isSecureContext, serviceWorker: "serviceWorker" in navigator, pushManager: "PushManager" in window, notification: "Notification" in window });
      const key = import.meta.env.VITE_WEB_PUSH_PUBLIC_KEY;
      if (!key)
        throw new Error("Chưa có khóa VAPID công khai từ backend trong VITE_WEB_PUSH_PUBLIC_KEY.");
      assertPushPermissionGranted(await Notification.requestPermission());
      const service = await navigator.serviceWorker.register("/app-sw.js", { scope: "/" });
      await navigator.serviceWorker.ready;
      const subscription = await service.pushManager.getSubscription() || await service.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: base64Bytes(key) });
      const json = subscription.toJSON();
      if (!json.endpoint || !json.keys?.p256dh || !json.keys.auth)
        throw new Error("Đăng ký Push không trả đủ dữ liệu.");
      await register.execute({ body: { deviceName: deviceName.trim(), endpoint: json.endpoint, p256dh: json.keys.p256dh, auth: json.keys.auth } });
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không đăng ký được thiết bị"));
    } finally {
      setPending(false);
    }
  };
  const telegramAvailable = !!devices.data?.data.some((d) => d.channel === "telegram" && d.status === "active");
  const telegramAvailabilityPending = !telegramAvailable && (!devices.data || devices.hasMore || devices.isError);
  const policyError = validatePolicy({ enabled, minutes, max, primary, quiet, quietStart, quietEnd, channel, telegramAvailable });
  const savePolicy = async () => {
    if (!policy.data || policyError)
      return;
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { enabled, minutes, max, quiet, quietStart, quietEnd, primary, fallback, channel, urgent };
    const body = {
      expectedVersion: prepared.version,
      enabled,
      timezone: policy.data.data.timezone,
      quietHours: quiet ? { start: quietStart, end: quietEnd } : null,
      remindAfterMinutes: minutes.trim() ? Number(minutes) : null,
      maxReminders: Number(max),
      primaryUserIds: primary,
      fallbackUserIds: fallback,
      fallbackChannel: channel,
      urgentMayBypassQuietHours: urgent
    };
    try {
      const result = await save.execute({ body });
      editor.committed(notificationSnapshot(result.data), submitted);
    } catch (error2) {
      editor.failed(error2);
    }
  };
  const knownUsers = members.data?.data.filter((m) => m.status === "active").map((m) => ({ id: m.userId, label: m.userId === session.user.id ? "Bạn" : m.userId })) || [{ id: session.user.id, label: "Bạn" }];
  const selectedUserIds = [.../* @__PURE__ */ new Set([...primary, ...fallback])];
  const retainedUsers = selectedUserIds.filter((id) => !knownUsers.some((user) => user.id === id)).map((id) => ({ id, label: `${id} (đã lưu, chưa tải thành viên)` }));
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Điện thoại & lịch trực", subtitle: "Thiết bị, xác nhận nhận việc, giờ yên lặng và người dự phòng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 145,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1.2fr 1fr" }, shrinkChildren: true, geometry: { minWidth: 0 }, children: [
        /* @__PURE__ */ jsxDEV(PageSections, { shrinkChildren: true, geometry: { minWidth: 0 }, children: [
          /* @__PURE__ */ jsxDEV(Panel, { title: "Thiết bị nhận thông báo", bodyMode: "inset", children: [
            /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || register.error || test.error || pair.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 368
              }, this),
              deviceTestMessage && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: deviceTestMessage }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 465
              }, this),
              /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: "row", alignItems: "center", children: [
                /* @__PURE__ */ jsxDEV(SmartphoneRounded, { sx: { fontSize: tokens.iconSizes.devicePreview, color: "primary.main" } }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 145,
                  columnNumber: 568
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { children: "Thông báo tối giản trên màn hình khóa; xem địa chỉ khách sau khi đăng nhập." }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 145,
                  columnNumber: 662
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 516
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Tên thiết bị", value: deviceName, onChange: (e) => setDeviceName(limitCodePoints(e.target.value, 120)) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 779
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "contained", busy: pending, disabled: !deviceName.trim(), onClick: () => void deviceRegister(), children: __MOCK__ ? "Mô phỏng đăng ký thiết bị" : "Bật thông báo trên thiết bị này" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 902
              }, this),
              __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Mô phỏng không yêu cầu quyền hệ điều hành, không đăng ký Push thật và giữ thiết bị ở trạng thái chờ xác minh." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 145,
                columnNumber: 1161
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 145,
              columnNumber: 352
            }, this),
            devices.isError && !devices.data ? null : /* @__PURE__ */ jsxDEV(QueryState, { query: devices, pendingProfile: "section", children: devices.data && /* @__PURE__ */ jsxDEV(DataTable, { label: "Thiết bị nhận thông báo", rows: devices.data.data, rowKey: (d) => d.id, columns: [
              { key: "name", label: "Thiết bị", render: (d) => d.deviceName },
              { key: "state", label: "Trạng thái", render: (d) => /* @__PURE__ */ jsxDEV(Status, { value: d.status }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 146,
                columnNumber: 132
              }, this) },
              {
                key: "actions",
                label: "",
                render: (d) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", flexWrap: "wrap", children: [
                  /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", disabled: d.status === "revoked", busy: test.pending, onClick: async () => {
                    try {
                      await test.execute({ path: { resourceId: d.id }, body: { expectedVersion: d.version } });
                      setDeviceTestMessage(__MOCK__ ? "Mô phỏng: chưa gửi Push thật; thiết bị vẫn chờ xác minh." : "Yêu cầu kiểm tra đã được tiếp nhận; xem trạng thái backend trước khi kết luận đã gửi.");
                    } catch {
                      setDeviceTestMessage(__MOCK__ ? "Mô phỏng: không gửi Push thật; kiểm tra bị từ chối và trạng thái thiết bị không đổi." : "");
                    }
                  }, children: __MOCK__ ? "Kiểm tra mô phỏng" : "Gửi thử" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                    lineNumber: 148,
                    columnNumber: 98
                  }, this),
                  /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", color: "error", disabled: d.status === "revoked", onClick: () => setSelected(d), children: "Thu hồi" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                    lineNumber: 148,
                    columnNumber: 699
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 148,
                  columnNumber: 59
                }, this)
              }
            ] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 145,
              columnNumber: 1432
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 145,
              columnNumber: 1362
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "thiết bị", loadedCount: devices.loadedCount, hasMore: devices.hasMore, busy: devices.isLoadingMore, onLoadMore: devices.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 150,
              columnNumber: 34
            }, this),
            devices.isError && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: devices.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 150,
                columnNumber: 224
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (devices.isFetchNextPageError ? devices.loadMore() : devices.refetch());
              }, children: "Thử lại danh sách thiết bị" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 150,
                columnNumber: 261
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 150,
              columnNumber: 208
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 145,
            columnNumber: 296
          }, this),
          /* @__PURE__ */ jsxDEV(Panel, { title: "Telegram dự phòng", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Chỉ liên kết qua mã một lần. Không dán bot token vào trình duyệt." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 150,
              columnNumber: 505
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "outlined", busy: pair.pending, onClick: async () => {
              try {
                const r = await pair.execute();
                setPairing(r.data);
              } catch {
              }
            }, children: "Tạo mã liên kết" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 150,
              columnNumber: 618
            }, this),
            pairing && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
              __MOCK__ ? "Mã minh họa, không dùng để liên kết thật. " : "",
              "Bot: ",
              pairing.botUsername,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 196
              }, this),
              "Mã: ",
              pairing.pairingCode,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 227
              }, this),
              "Hết hạn ",
              dateTime(pairing.expiresAt, shop.timezone)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 85
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 150,
            columnNumber: 489
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 150,
            columnNumber: 439
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 145,
          columnNumber: 240
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Quy tắc nhận và nhắc việc", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: policy, pendingProfile: "section", children: [
          /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: policyForm, onSubmit: (event) => {
            event.preventDefault();
            void savePolicy();
          }, children: [
            /* @__PURE__ */ jsxDEV(ErrorNotice, { error: save.error }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 556
            }, this),
            /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { enabled: "Bật quy tắc", minutes: "Nhắc sau (phút)", max: "Số lần nhắc", quiet: "Giờ yên lặng", quietStart: "Giờ bắt đầu", quietEnd: "Giờ kết thúc", primary: "Người nhận chính", fallback: "Người dự phòng", channel: "Kênh dự phòng", urgent: "Ưu tiên khẩn" }, busy: save.pending }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 590
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Bật quy tắc thông báo", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: enabled, onChange: (e) => setEnabled(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 967
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 910
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Nhắc sau (phút), để trống nếu chưa chốt", value: minutes, onChange: (e) => setMinutes(e.target.value), type: "number", inputProps: { min: 1 } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1048
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Số lần nhắc tối đa", value: max, onChange: (e) => setMax(e.target.value), type: "number", inputProps: { min: 0 } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1208
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm thành viên", value: memberSearchInput, onChange: (event) => setMemberSearchInput(event.target.value), disabled: !canManageMembers, helperText: "Tìm kiếm dùng q của listMembers; mã người nhận đã lưu luôn được giữ." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1339
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Người nhận chính", value: primary, slotProps: { select: { multiple: true } }, onChange: (e) => setPrimary(typeof e.target.value === "string" ? e.target.value.split(",") : e.target.value), children: [...retainedUsers, ...knownUsers].map((u) => /* @__PURE__ */ jsxDEV(MenuItem, { value: u.id, children: u.label }, u.id, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1833
            }, this)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1575
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Người dự phòng", value: fallback, slotProps: { select: { multiple: true } }, onChange: (e) => setFallback(typeof e.target.value === "string" ? e.target.value.split(",") : e.target.value), children: [...retainedUsers, ...knownUsers].map((u) => /* @__PURE__ */ jsxDEV(MenuItem, { value: u.id, children: u.label }, u.id, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 2159
            }, this)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 1901
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "thành viên", loadedCount: members.loadedCount, hasMore: members.hasMore, busy: members.isLoadingMore, onLoadMore: members.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 2227
            }, this),
            members.isError && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: members.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 2419
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (members.isFetchNextPageError ? members.loadMore() : members.refetch());
              }, children: "Thử lại danh sách thành viên" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 2456
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 2403
            }, this),
            telegramAvailabilityPending && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: devices.isError ? "Không xác minh được danh sách thiết bị; hãy thử lại trước khi kết luận không có Telegram đang hoạt động." : devices.hasMore ? "Chưa tải hết thiết bị; hãy tải thêm trước khi kết luận không có Telegram đang hoạt động." : "Đang tải danh sách thiết bị để xác minh trạng thái Telegram." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 2660
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kênh dự phòng", value: channel, onChange: (e) => setChannel(e.target.value), children: [
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "none", children: "Chưa bật" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 3127
              }, this),
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "telegram", disabled: !telegramAvailable, children: telegramAvailable ? "Telegram đã liên kết" : telegramAvailabilityPending ? "Chưa xác minh Telegram" : "Telegram (chưa có thiết bị active)" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 3169
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 3008
            }, this),
            channel === "telegram" && !telegramAvailable && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Mã ghép đôi mô phỏng không liên kết Telegram. Chỉ chọn kênh này khi danh sách có thiết bị Telegram active." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 3438
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Có giờ yên lặng", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: quiet, onChange: (e) => setQuiet(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 3630
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 3579
            }, this),
            quiet && /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, children: [
              /* @__PURE__ */ jsxDEV(TextField, { type: "time", label: "Từ", value: quietStart, onChange: (e) => setQuietStart(e.target.value), fullWidth: true }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 3769
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { type: "time", label: "Đến", value: quietEnd, onChange: (e) => setQuietEnd(e.target.value), fullWidth: true }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 154,
                columnNumber: 3882
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 3717
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
              "Theo múi giờ ",
              shop.timezone
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 4006
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Cho phép thông báo khẩn vượt giờ yên lặng", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: urgent, onChange: (e) => setUrgent(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 4154
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 4077
            }, this),
            policyError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: policyError }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 154,
              columnNumber: 4249
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 154,
            columnNumber: 444
          }, this),
          /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "column", beforeGap: "form", children: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "contained", busy: save.pending, disabled: !policy.data || !!policyError || save.pending, onClick: () => void savePolicy(), children: "Lưu quy tắc" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 154,
            columnNumber: 4370
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 154,
            columnNumber: 4321
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 154,
          columnNumber: 392
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 154,
          columnNumber: 334
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 145,
        columnNumber: 144
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", "data-testid": "notification-protection-note", children: "Chống gửi lặp theo sự kiện, kiểm tra callback, thời hạn token và giới hạn tốc độ phải được bảo đảm bởi dịch vụ. Bản demo không phát thông báo thật và không xác minh các lớp bảo vệ phía máy chủ." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 154,
        columnNumber: 4628
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 145,
      columnNumber: 130
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: "Thu hồi thiết bị", confirmLabel: "Thu hồi thiết bị", description: `Thiết bị ${selected?.deviceName || ""} (${selected?.id || ""}): dừng thông báo mới đến đăng ký này. Thông báo đã được kênh tiếp nhận không thể thu hồi.`, onClose: () => setSelected(null), busy: revoke.pending, error: revoke.error, onConfirm: () => revoke.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 154,
      columnNumber: 4910
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
    lineNumber: 145,
    columnNumber: 10
  }, this);
}
_s2(DevicesPage, "LUctBdAf8B51ueYEh2JEWwvE6Lw=", false, function() {
  return [useScope, usePagedApi, useApi, useCan, usePagedApi, useCommand, useCommand, useCommand, useCommand, useCommand, useVersionedDraft, useDraftForm];
});
_c2 = DevicesPage;
function notificationSnapshot(policy) {
  return { version: policy.version, values: { enabled: policy.enabled, minutes: policy.remindAfterMinutes?.toString() || "", max: String(policy.maxReminders), quiet: !!policy.quietHours, quietStart: policy.quietHours?.start || "22:00", quietEnd: policy.quietHours?.end || "08:00", primary: policy.primaryUserIds, fallback: policy.fallbackUserIds, channel: policy.fallbackChannel, urgent: policy.urgentMayBypassQuietHours } };
}
var _c, _c2;
$RefreshReg$(_c, "NotificationsPage");
$RefreshReg$(_c2, "DevicesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJXLG1CQUErSCxjQUEvSDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6QlgsU0FBUUEsU0FBU0MscUJBQW9CO0FBQ3JDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGFBQWFDLFlBQVlDLFlBQVlDLGNBQWNDLGFBQWFDLHNCQUFzQjtBQUMvRixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLE9BQU9DLEtBQUtDLFFBQVFDLFVBQVVDLGtCQUFrQkMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQ3ZHLE9BQU9DLGdDQUFnQztBQUN2QyxPQUFPQyx1QkFBdUI7QUFFOUIsU0FBU0MsUUFBUUMsY0FBYztBQUMvQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsUUFBUUMsYUFBYUMsa0JBQWtCO0FBQ2hELFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUMsU0FBU0MsWUFBWUMsT0FBT0MsV0FBV0MsWUFBWUMsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxhQUFhQyxlQUFlQyxZQUFZQyxZQUFZQyxXQUFXQyxzQkFBc0I7QUFDaEwsU0FBU0Msc0JBQXNCQyxtQ0FBbUM7QUFDM0QsZ0JBQVNDLG9CQUFvQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsTUFBTUMsUUFBUSxJQUFJdkIsU0FBUztBQUNuQyxRQUFNd0IsT0FBTzVCLE9BQU8scUJBQXFCLEVBQUU2QixPQUFPeEIsYUFBYSxtQkFBbUIsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sQ0FBQ3lCLFVBQVVDLFdBQVcsSUFBSS9DLFNBQVMsRUFBRTtBQUMzQyxRQUFNZ0QsU0FBU2hDLE9BQU8sbUJBQW1CLEVBQUVpQyxNQUFNLEVBQUVDLFlBQVlKLFNBQVMsRUFBRSxHQUFHSyxRQUFRTCxRQUFRLENBQUM7QUFDOUYsUUFBTU0sTUFBTWxDLFdBQVcsMkJBQTJCLENBQUMsbUJBQW1CLHFCQUFxQixpQkFBaUIsZ0JBQWdCLHNCQUFzQixDQUFDO0FBQ25KLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sdUJBQXNCLFVBQVMsb0VBQW1FLFNBQVMsdUJBQUMsYUFBVSxJQUFJLE1BQU13QixLQUFLVyxFQUFFLDBCQUEwQixzQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RSxLQUF6TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNOO0FBQUEsSUFBRSx1QkFBQyxlQUFZLE9BQU9ELElBQUlFLFNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBT1YsTUFBTSxpQ0FBQyxrQkFBZSxVQUFTLFNBQVNBO0FBQUFBLGFBQUtXLE1BQU1BLEtBQUtDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxPQUFlLElBQUksQ0FBQzFDLFNBQVMyQyxRQUFRQyxPQUFPO0FBQUEsVUFDN2FDLFFBQVE7QUFBQSxVQUFHQyxhQUFhSixFQUFFSyxpQkFBaUIsWUFBWWpELE9BQU9rRDtBQUFBQSxVQUFZQyxjQUFjL0QsU0FBU2dFLE9BQU9DO0FBQUFBLFVBQU9DLFNBQVNWLEVBQUVLLGlCQUFpQixnQkFBZ0JqRCxPQUFPdUQ7QUFBQUEsUUFDdkssQ0FBQyxHQUFHLGlDQUFDLGtCQUFlLFdBQVcsRUFBRUMsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxnQkFBZSxpQkFBaUI7QUFBQSxpQ0FBQyxrQkFBZSxXQUFVLE9BQU87QUFBQSxtQ0FBQyw4QkFBMkIsSUFBSSxFQUFFQyxPQUFPLGVBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUFFLHVCQUFDLE9BQUk7QUFBQSxxQ0FBQyxjQUFXLFNBQVEsTUFBTWQsWUFBRWUsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFhLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSXpELFNBQVMwRCxXQUFXQyxxQkFBc0JqQixZQUFFa0IsWUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxjQUFhLHVCQUFDLGVBQVksV0FBVSxPQUFNLFdBQVUsVUFBUztBQUFBLHVDQUFDLFVBQU8sT0FBT2xCLEVBQUVtQixrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFBRSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxJQUFJLEVBQUVDLFdBQVcsU0FBUyxHQUFJeEY7QUFBQUEsZ0NBQWNvRSxFQUFFcUIsT0FBTztBQUFBLGtCQUFFO0FBQUEsa0JBQUl2RCxTQUFTa0MsRUFBRXNCLFdBQVdyQyxLQUFLc0MsUUFBUTtBQUFBLHFCQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4SDtBQUFBLG1CQUFoTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2TjtBQUFBLGNBQWMsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsSUFBSSxDQUFDakUsU0FBU2lDLE9BQU9pQyxtQkFBbUIsRUFBRUMsU0FBUyxRQUFRLENBQUMsR0FBSXpCLFlBQUVLLGlCQUFpQixvQkFBb0J2QyxTQUFTa0MsRUFBRUssZ0JBQWdCcEIsS0FBS3NDLFFBQVEsQ0FBQyxLQUFLdkIsRUFBRTBCLFdBQVcsOENBQThDLDhDQUFyUTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnVDtBQUFBLGlCQUF4ckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcXNCO0FBQUEsZUFBbHlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXd5QjtBQUFBLFVBQWlCLHVCQUFDLGtCQUFlLGdCQUFlLFVBQVU7QUFBQSxtQ0FBQyxVQUFPLFNBQVMsTUFBTXBDLFlBQVlVLEVBQUVKLEVBQUUsR0FBRyxrQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUFTLHVCQUFDLGtCQUFlLFlBQVcsb0JBQW1CLGdCQUFnQkksRUFBRTJCLGdCQUFnQixRQUFPLGVBQWMsVUFBVSxDQUFDM0IsRUFBRTRCLGNBQWM1QixFQUFFNkIsb0JBQW9CM0MsUUFBUTRDLEtBQUtsQyxJQUFJLE1BQU1ELElBQUlvQyxTQUFTLFNBQVEsYUFBWSxTQUFTLE1BQU0sS0FBS3BDLElBQUlxQyxRQUFRLEVBQUV4QyxNQUFNLEVBQUVDLFlBQVlPLEVBQUVKLEdBQUcsR0FBR3FDLE1BQU0sRUFBRUMsaUJBQWlCbEMsRUFBRW1DLFFBQVEsRUFBRSxDQUFDLEVBQUVDLE1BQU0sTUFBTUMsTUFBUyxHQUFHLHFDQUE1VTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpVztBQUFBLFlBQWtCckMsRUFBRXNDLE9BQU9DLFNBQVMsV0FBVyx1QkFBQyxhQUFVLElBQUksTUFBTXRELEtBQUtXLEVBQUUsV0FBV0ksRUFBRXNDLE9BQU8xQyxFQUFFLElBQUksdUJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsZUFBM2pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdrQjtBQUFBLGFBQXo5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTArQyxLQUYvbENJLEVBQUVKLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUUwbkMsQ0FBTTtBQUFBLFFBQUdULEtBQUtXLE1BQU1BLEtBQUswQyxXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFTLDhHQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1JO0FBQUEsUUFBUyx1QkFBQyxTQUFNLE1BQU1yRCxLQUFLVyxNQUFNMkMsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFdBRnY0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXk0QyxLQUZsNkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVtN0M7QUFBQSxTQUZuK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVnL0M7QUFBQSxJQUNqdkQsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQ3BELFVBQVUsT0FBTSxzQkFBcUIsU0FBUyxNQUFNQyxZQUFZLEVBQUUsR0FBRyxTQUFTLHVCQUFDLFVBQU8sU0FBUyxNQUFNQSxZQUFZLEVBQUUsR0FBRyxvQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QyxHQUMxSSxpQ0FBQyxjQUFXLE9BQU9DLFFBQVEsZ0JBQWUsV0FBV0EsaUJBQU9PLFFBQVEsdUJBQUMsa0JBQ2pFO0FBQUEsNkJBQUMsY0FBVyxTQUFRLE1BQU1QLGlCQUFPTyxLQUFLQSxLQUFLaUIsU0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQWEsdUJBQUMsY0FBWXhCLGlCQUFPTyxLQUFLQSxLQUFLb0IsWUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3JHLHVCQUFDLGNBQVcsT0FBTSxRQUFRdEYsd0JBQWMyRCxPQUFPTyxLQUFLQSxLQUFLdUIsT0FBTyxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLGlDQUFDLFVBQU8sT0FBTzlCLE9BQU9PLEtBQUtBLEtBQUtxQixrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQyxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GO0FBQUEsTUFDbkssdUJBQUMsY0FBVyxPQUFNLFdBQVdyRCxtQkFBU3lCLE9BQU9PLEtBQUtBLEtBQUt3QixXQUFXckMsS0FBS3NDLFFBQVEsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFVBQVV6RCxtQkFBU3lCLE9BQU9PLEtBQUtBLEtBQUs0QixVQUFVekMsS0FBS3NDLFFBQVEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQnpELG1CQUFTeUIsT0FBT08sS0FBS0EsS0FBS08sZ0JBQWdCcEIsS0FBS3NDLFFBQVEsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RjtBQUFBLE1BQ3RSLHVCQUFDLGNBQVcsT0FBTSxTQUFTaEM7QUFBQUEsZUFBT08sS0FBS0EsS0FBS3dDLE9BQU9DO0FBQUFBLFFBQUs7QUFBQSxRQUFJaEQsT0FBT08sS0FBS0EsS0FBS3dDLE9BQU8xQztBQUFBQSxXQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sZ0JBQWdCTCxpQkFBT08sS0FBS0EsS0FBSzhCLGNBQWMsYUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLFNBSi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLcEUsS0FMQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2tCLEtBTnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BVk87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVNO0FBQ2pCO0FBQUM1QyxHQWpCZUQsbUJBQWlCO0FBQUEsVUFDSHBCLFVBQ2JKLFFBQXFDSyxjQUVuQ0wsUUFDSEUsVUFBVTtBQUFBO0FBQUEsS0FMVnNCO0FBa0JoQixTQUFTMkQsWUFBWUMsT0FBZTtBQUFFLFFBQU1DLFVBQVVELFFBQVEsSUFBSUUsUUFBUSxJQUFJRixNQUFNSCxTQUFTLEtBQUssQ0FBQyxHQUFHTSxRQUFRLE1BQU0sR0FBRyxFQUFFQSxRQUFRLE1BQU0sR0FBRztBQUFHLFFBQU1DLE1BQU1DLEtBQUtKLE1BQU07QUFBRyxRQUFNSyxRQUFRLElBQUlDLFdBQVdILElBQUlQLE1BQU07QUFBRyxXQUFTVyxJQUFJLEdBQUdBLElBQUlKLElBQUlQLFFBQVFXO0FBQzdPRixVQUFNRSxDQUFDLElBQUlKLElBQUlLLFdBQVdELENBQUM7QUFBRyxTQUFPRjtBQUFPO0FBQ2hELFNBQVNJLGVBQWVDLE9BQThMO0FBQ2xOLFFBQU1DLFdBQVdELE1BQU1FLFFBQVFDLEtBQUs7QUFDcEMsUUFBTUMsVUFBVUosTUFBTUssSUFBSUYsS0FBSztBQUMvQixNQUFJQyxZQUFZLE1BQU0sQ0FBQ0UsT0FBT0MsY0FBY0QsT0FBT0YsT0FBTyxDQUFDLEtBQUtFLE9BQU9GLE9BQU8sSUFBSTtBQUM5RSxXQUFPO0FBQ1gsTUFBSUgsYUFBYSxDQUFDSyxPQUFPQyxjQUFjRCxPQUFPTCxRQUFRLENBQUMsS0FBS0ssT0FBT0wsUUFBUSxJQUFJO0FBQzNFLFdBQU87QUFDWCxNQUFJRCxNQUFNUSxXQUFXLENBQUNQO0FBQ2xCLFdBQU87QUFDWCxNQUFJRCxNQUFNUSxXQUFXLENBQUNSLE1BQU1TLFFBQVF2QjtBQUNoQyxXQUFPO0FBQ1gsTUFBSWMsTUFBTVUsVUFBVSxDQUFDLDRCQUE0QkMsS0FBS1gsTUFBTVksVUFBVSxLQUFLLENBQUMsNEJBQTRCRCxLQUFLWCxNQUFNYSxRQUFRO0FBQ3ZILFdBQU87QUFDWCxNQUFJYixNQUFNakMsWUFBWSxjQUFjLENBQUNpQyxNQUFNYztBQUN2QyxXQUFPO0FBQ1gsU0FBTztBQUNYO0FBQ08sZ0JBQVNDLGNBQWM7QUFBQUMsTUFBQTtBQUMxQixRQUFNLEVBQUVyRixNQUFNQyxRQUFRLElBQUl2QixTQUFTO0FBQ25DLFFBQU00RyxVQUFVL0csWUFBWSxhQUFhO0FBQ3pDLFFBQU1nSCxTQUFTakgsT0FBTyx1QkFBdUI7QUFDN0MsUUFBTWtILG1CQUFtQi9HLE9BQU8sZ0JBQWdCO0FBQ2hELFFBQU0sQ0FBQ2dILG1CQUFtQkMsb0JBQW9CLElBQUlwSSxTQUFTLEVBQUUsR0FBRyxDQUFDcUksY0FBY0MsZUFBZSxJQUFJdEksU0FBUyxFQUFFO0FBQzdHRCxZQUFVLE1BQU07QUFDWixVQUFNd0ksUUFBUUMsT0FBT0MsV0FBVyxNQUFNSCxnQkFBZ0JILGtCQUFrQmpCLEtBQUssQ0FBQyxHQUFHLEdBQUc7QUFDcEYsV0FBTyxNQUFNc0IsT0FBT0UsYUFBYUgsS0FBSztBQUFBLEVBQzFDLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUM7QUFDdEIsUUFBTVEsVUFBVTFILFlBQVksZUFBZSxFQUFFNEIsT0FBTyxFQUFFK0YsR0FBR1AsZ0JBQWdCdkMsT0FBVSxFQUFFLEdBQUdvQyxnQkFBZ0I7QUFDeEcsUUFBTVcsV0FBVzNILFdBQVcsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO0FBQzNELFFBQU13RyxPQUFPeEcsV0FBVyxjQUFjLENBQUMsZUFBZSxtQkFBbUIsQ0FBQztBQUMxRSxRQUFNNEgsU0FBUzVILFdBQVcsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO0FBQ3pELFFBQU02SCxPQUFPN0gsV0FBVyw0QkFBNEIsQ0FBQyx1QkFBdUIsQ0FBQztBQUM3RSxRQUFNOEgsT0FBTzlILFdBQVcsd0JBQXdCLEVBQUU7QUFDbEQsUUFBTSxDQUFDK0gsWUFBWUMsYUFBYSxJQUFJbEosU0FBUyxvQkFBb0IsR0FBRyxDQUFDc0QsT0FBTzZGLFFBQVEsSUFBSW5KLFNBQXVCLElBQUksR0FBRyxDQUFDd0YsU0FBUzRELFVBQVUsSUFBSXBKLFNBQVMsS0FBSyxHQUFHLENBQUNvRSxVQUFVaUYsV0FBVyxJQUFJckosU0FBb0MsSUFBSSxHQUFHLENBQUNzSixTQUFTQyxVQUFVLElBQUl2SixTQUFpQyxJQUFJLEdBQUcsQ0FBQ3dKLG1CQUFtQkMsb0JBQW9CLElBQUl6SixTQUFTLEVBQUU7QUFDM1YsUUFBTSxDQUFDdUgsU0FBU21DLFVBQVUsSUFBSTFKLFNBQVMsS0FBSyxHQUFHLENBQUNpSCxTQUFTMEMsVUFBVSxJQUFJM0osU0FBUyxFQUFFLEdBQUcsQ0FBQ29ILEtBQUt3QyxNQUFNLElBQUk1SixTQUFTLEdBQUcsR0FBRyxDQUFDeUgsT0FBT29DLFFBQVEsSUFBSTdKLFNBQVMsS0FBSyxHQUFHLENBQUMySCxZQUFZbUMsYUFBYSxJQUFJOUosU0FBUyxPQUFPLEdBQUcsQ0FBQzRILFVBQVVtQyxXQUFXLElBQUkvSixTQUFTLE9BQU8sR0FBRyxDQUFDd0gsU0FBU3dDLFVBQVUsSUFBSWhLLFNBQW1CLEVBQUUsR0FBRyxDQUFDaUssVUFBVUMsV0FBVyxJQUFJbEssU0FBbUIsRUFBRSxHQUFHLENBQUM4RSxTQUFTcUYsVUFBVSxJQUFJbkssU0FBOEIsTUFBTSxHQUFHLENBQUNvSyxRQUFRQyxTQUFTLElBQUlySyxTQUFTLEtBQUs7QUFDNWIsUUFBTXNLLFNBQVNoTCxrQkFBa0I7QUFBQSxJQUM3QmlMLFVBQVUsR0FBRzdILEtBQUtXLEVBQUU7QUFBQSxJQUF3QjBDLFFBQVFrQyxPQUFPMUUsT0FBT2lILHFCQUFxQnZDLE9BQU8xRSxLQUFLQSxJQUFJLElBQUl1QztBQUFBQSxJQUMzRzJFLE9BQU8sRUFBRWxELFNBQVNOLFNBQVNHLEtBQUtLLE9BQU9FLFlBQVlDLFVBQVVKLFNBQVN5QyxVQUFVbkYsU0FBU3NGLE9BQU87QUFBQSxJQUNoR00sT0FBT0EsQ0FBQUMsV0FBVTtBQUFFakIsaUJBQVdpQixPQUFPcEQsT0FBTztBQUFHb0MsaUJBQVdnQixPQUFPMUQsT0FBTztBQUFHMkMsYUFBT2UsT0FBT3ZELEdBQUc7QUFBR3lDLGVBQVNjLE9BQU9sRCxLQUFLO0FBQUdxQyxvQkFBY2EsT0FBT2hELFVBQVU7QUFBR29DLGtCQUFZWSxPQUFPL0MsUUFBUTtBQUFHb0MsaUJBQVdXLE9BQU9uRCxPQUFPO0FBQUcwQyxrQkFBWVMsT0FBT1YsUUFBUTtBQUFHRSxpQkFBV1EsT0FBTzdGLE9BQU87QUFBR3VGLGdCQUFVTSxPQUFPUCxNQUFNO0FBQUEsSUFBRztBQUFBLElBQ3ZTUSxTQUFTQSxNQUFNM0MsT0FBTzRDLFFBQVEsRUFBRUMsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUN4RCxDQUFDO0FBQ0QsUUFBTUMsYUFBYXhMLGFBQWErSyxPQUFPVSxLQUFLO0FBQzVDLFFBQU1DLGlCQUFpQixZQUFZO0FBQy9COUIsYUFBUyxJQUFJO0FBQ2JDLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxVQUFJOEIsVUFBVTtBQUNWLGNBQU1yQyxTQUFTcEQsUUFBUSxFQUFFQyxNQUFNLEVBQUV1RCxZQUFZQSxXQUFXL0IsS0FBSyxHQUFHaUUsVUFBVSxrQ0FBa0NDLFFBQVEsK0JBQStCQyxNQUFNLHdCQUF3QixFQUFFLENBQUM7QUFDcEw7QUFBQSxNQUNKO0FBQ0EvSSwyQkFBcUIsRUFBRWdKLGVBQWU5QyxPQUFPK0MsaUJBQWlCQyxlQUFlLG1CQUFtQkMsV0FBV0MsYUFBYSxpQkFBaUJsRCxRQUFRbUQsY0FBYyxrQkFBa0JuRCxPQUFPLENBQUM7QUFDekwsWUFBTW9ELE1BQU1DLFlBQVlDLElBQUlDO0FBQzVCLFVBQUksQ0FBQ0g7QUFDRCxjQUFNLElBQUlJLE1BQU0seUVBQXlFO0FBQzdGekosa0NBQTRCLE1BQU0wSixhQUFhQyxrQkFBa0IsQ0FBQztBQUNsRSxZQUFNQyxVQUFVLE1BQU1WLFVBQVVELGNBQWMzQyxTQUFTLGNBQWMsRUFBRXVELE9BQU8sSUFBSSxDQUFDO0FBQ25GLFlBQU1YLFVBQVVELGNBQWNhO0FBQzlCLFlBQU1DLGVBQWUsTUFBTUgsUUFBUVQsWUFBWWEsZ0JBQWdCLEtBQUssTUFBTUosUUFBUVQsWUFBWWMsVUFBVSxFQUFFQyxpQkFBaUIsTUFBTUMsc0JBQXNCdkcsWUFBWXlGLEdBQUcsRUFBRSxDQUFDO0FBQ3pLLFlBQU1lLE9BQU9MLGFBQWFNLE9BQU87QUFDakMsVUFBSSxDQUFDRCxLQUFLeEIsWUFBWSxDQUFDd0IsS0FBS0UsTUFBTXpCLFVBQVUsQ0FBQ3VCLEtBQUtFLEtBQUt4QjtBQUNuRCxjQUFNLElBQUlXLE1BQU0sb0NBQW9DO0FBQ3hELFlBQU1uRCxTQUFTcEQsUUFBUSxFQUFFQyxNQUFNLEVBQUV1RCxZQUFZQSxXQUFXL0IsS0FBSyxHQUFHaUUsVUFBVXdCLEtBQUt4QixVQUFVQyxRQUFRdUIsS0FBS0UsS0FBS3pCLFFBQVFDLE1BQU1zQixLQUFLRSxLQUFLeEIsS0FBSyxFQUFFLENBQUM7QUFBQSxJQUMvSSxTQUNPeUIsR0FBRztBQUNOM0QsZUFBUzJELGFBQWFkLFFBQVFjLElBQUksSUFBSWQsTUFBTSw2QkFBNkIsQ0FBQztBQUFBLElBQzlFLFVBQUM7QUFFRzVDLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFDQSxRQUFNdkIsb0JBQW9CLENBQUMsQ0FBQ0csUUFBUXpFLE1BQU1BLEtBQUt3SixLQUFLLENBQUFDLE1BQUtBLEVBQUVsSSxZQUFZLGNBQWNrSSxFQUFFQyxXQUFXLFFBQVE7QUFDMUcsUUFBTUMsOEJBQThCLENBQUNyRixzQkFBc0IsQ0FBQ0csUUFBUXpFLFFBQVF5RSxRQUFRbUYsV0FBV25GLFFBQVFvRjtBQUN2RyxRQUFNQyxjQUFjdkcsZUFBZSxFQUFFUyxTQUFTTixTQUFTRyxLQUFLSSxTQUFTQyxPQUFPRSxZQUFZQyxVQUFVOUMsU0FBUytDLGtCQUFrQixDQUFDO0FBQzlILFFBQU15RixhQUFhLFlBQVk7QUFBRSxRQUFJLENBQUNyRixPQUFPMUUsUUFBUThKO0FBQ2pEO0FBQVEsVUFBTUUsV0FBV2pELE9BQU9rRCxRQUFRO0FBQUcsUUFBSSxDQUFDRCxTQUFVO0FBQzFELFVBQU1FLFlBQVksRUFBRWxHLFNBQVNOLFNBQVNHLEtBQUtLLE9BQU9FLFlBQVlDLFVBQVVKLFNBQVN5QyxVQUFVbkYsU0FBU3NGLE9BQU87QUFDM0csVUFBTTFFLE9BQWdDO0FBQUEsTUFDdENDLGlCQUFpQjRILFNBQVMzSDtBQUFBQSxNQUFTMkI7QUFBQUEsTUFBU3ZDLFVBQVVpRCxPQUFPMUUsS0FBS0EsS0FBS3lCO0FBQUFBLE1BQVUwSSxZQUFZakcsUUFBUSxFQUFFa0csT0FBT2hHLFlBQVlpRyxLQUFLaEcsU0FBUyxJQUFJO0FBQUEsTUFBTWlHLG9CQUFvQjVHLFFBQVFDLEtBQUssSUFBSUcsT0FBT0osT0FBTyxJQUFJO0FBQUEsTUFBTTZHLGNBQWN6RyxPQUFPRCxHQUFHO0FBQUEsTUFBRzJHLGdCQUFnQnZHO0FBQUFBLE1BQVN3RyxpQkFBaUIvRDtBQUFBQSxNQUFVZ0UsaUJBQWlCbko7QUFBQUEsTUFBU29KLDJCQUEyQjlEO0FBQUFBLElBQ3ZWO0FBQUcsUUFBSTtBQUNILFlBQU0rRCxTQUFTLE1BQU1wRixLQUFLdEQsUUFBUSxFQUFFQyxLQUFLLENBQUM7QUFDMUM0RSxhQUFPOEQsVUFBVTVELHFCQUFxQjJELE9BQU81SyxJQUFJLEdBQUdrSyxTQUFTO0FBQUEsSUFDakUsU0FDT25LLFFBQU87QUFBRWdILGFBQU8rRCxPQUFPL0ssTUFBSztBQUFBLElBQUc7QUFBQSxFQUFFO0FBQ3hDLFFBQU1nTCxhQUFhM0YsUUFBUXBGLE1BQU1BLEtBQUtnTCxPQUFPLENBQUFDLE1BQUtBLEVBQUV2QixXQUFXLFFBQVEsRUFBRXpKLElBQUksQ0FBQWdMLE9BQU0sRUFBRW5MLElBQUltTCxFQUFFQyxRQUFRclAsT0FBT29QLEVBQUVDLFdBQVc5TCxRQUFRNEMsS0FBS2xDLEtBQUssUUFBUW1MLEVBQUVDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRXBMLElBQUlWLFFBQVE0QyxLQUFLbEMsSUFBSWpFLE9BQU8sTUFBTSxDQUFDO0FBQ3ZNLFFBQU1zUCxrQkFBa0IsQ0FBQyxHQUFHLG9CQUFJQyxJQUFJLENBQUMsR0FBR25ILFNBQVMsR0FBR3lDLFFBQVEsQ0FBQyxDQUFDO0FBQzlELFFBQU0yRSxnQkFBZ0JGLGdCQUFnQkgsT0FBTyxDQUFBbEwsT0FBTSxDQUFDaUwsV0FBV3ZCLEtBQUssQ0FBQXhILFNBQVFBLEtBQUtsQyxPQUFPQSxFQUFFLENBQUMsRUFBRUcsSUFBSSxDQUFBSCxRQUFPLEVBQUVBLElBQUlqRSxPQUFPLEdBQUdpRSxFQUFFLGlDQUFpQyxFQUFFO0FBQzdKLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sMEJBQXlCLFVBQVMsbUVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUg7QUFBQSxJQUFFLHVCQUFDLGdCQUFhO0FBQUEsNkJBQUMsZUFBWSxTQUFTLEVBQUVnQixJQUFJLE9BQU93SyxJQUFJLFlBQVksR0FBRyxnQkFBYyxNQUFDLFVBQVUsRUFBQ0MsVUFBVSxFQUFDLEdBQUc7QUFBQSwrQkFBQyxnQkFBYSxnQkFBYyxNQUFDLFVBQVUsRUFBQ0EsVUFBVSxFQUFDLEdBQUc7QUFBQSxpQ0FBQyxTQUFNLE9BQU0sMkJBQTBCLFVBQVMsU0FBUTtBQUFBLG1DQUFDLGtCQUFnQjtBQUFBLHFDQUFDLGVBQVksT0FBT3hMLFNBQVN1RixTQUFTdkYsU0FBU29FLEtBQUtwRSxTQUFTMEYsS0FBSzFGLFNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FBR2tHLHFCQUFxQix1QkFBQyxTQUFNLFVBQVMsUUFBUUEsK0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDO0FBQUEsY0FBUyx1QkFBQyxrQkFBZSxXQUFVLE9BQU8sWUFBVyxVQUFTO0FBQUEsdUNBQUMscUJBQWtCLElBQUksRUFBRXVGLFVBQVVqTyxPQUFPa08sVUFBVUMsZUFBZTFLLE9BQU8sZUFBZSxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRjtBQUFBLGdCQUFFLHVCQUFDLGNBQVcsMkZBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUY7QUFBQSxtQkFBek87QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc1A7QUFBQSxjQUFpQix1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsT0FBTzBFLFlBQVksVUFBVSxDQUFBNkQsTUFBSzVELGNBQWM1SCxnQkFBZ0J3TCxFQUFFb0MsT0FBTzlJLE9BQU8sR0FBRyxDQUFDLEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNIO0FBQUEsY0FBRyx1QkFBQyxrQkFBZSxZQUFXLHdCQUF1QixTQUFRLGFBQVksTUFBTVosU0FBUyxVQUFVLENBQUN5RCxXQUFXL0IsS0FBSyxHQUFHLFNBQVMsTUFBTSxLQUFLK0QsZUFBZSxHQUFJQyxxQkFBVyw4QkFBOEIscUNBQW5NO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFPO0FBQUEsY0FBa0JBLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sNkhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9JO0FBQUEsaUJBQTM2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvN0I7QUFBQSxZQUFrQmxELFFBQVFvRixXQUFXLENBQUNwRixRQUFRekUsT0FBTyxPQUFPLHVCQUFDLGNBQVcsT0FBT3lFLFNBQVMsZ0JBQWUsV0FBV0Esa0JBQVF6RSxRQUFRLHVCQUFDLGFBQVUsT0FBTSwyQkFBMEIsTUFBTXlFLFFBQVF6RSxLQUFLQSxNQUFNLFFBQVEsQ0FBQXlKLE1BQUtBLEVBQUUzSixJQUFJLFNBQVM7QUFBQSxjQUMxK0MsRUFBRXVJLEtBQUssUUFBUXhNLE9BQU8sWUFBWStQLFFBQVFBLENBQUFuQyxNQUFLQSxFQUFFL0QsV0FBVztBQUFBLGNBQUcsRUFBRTJDLEtBQUssU0FBU3hNLE9BQU8sY0FBYytQLFFBQVFBLENBQUFuQyxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRUMsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0IsRUFBRztBQUFBLGNBQzVJO0FBQUEsZ0JBQ0lyQixLQUFLO0FBQUEsZ0JBQVd4TSxPQUFPO0FBQUEsZ0JBQUkrUCxRQUFRQSxDQUFBbkMsTUFBSyx1QkFBQyxTQUFNLFdBQVUsT0FBTSxVQUFTLFFBQU87QUFBQSx5Q0FBQyxrQkFBZSxZQUFXLHdCQUF1QixVQUFVQSxFQUFFQyxXQUFXLFdBQVcsTUFBTXZGLEtBQUtsQyxTQUFTLFNBQVMsWUFBWTtBQUFFLHdCQUFJO0FBQUUsNEJBQU1rQyxLQUFLakMsUUFBUSxFQUFFeEMsTUFBTSxFQUFFQyxZQUFZOEosRUFBRTNKLEdBQUcsR0FBR3FDLE1BQU0sRUFBRUMsaUJBQWlCcUgsRUFBRXBILFFBQVEsRUFBRSxDQUFDO0FBQUc2RCwyQ0FBcUJ5QixXQUFXLDZEQUE2RCx1RkFBdUY7QUFBQSxvQkFBRyxRQUFRO0FBQUV6QiwyQ0FBcUJ5QixXQUFXLHlGQUF5RixFQUFFO0FBQUEsb0JBQUc7QUFBQSxrQkFBRSxHQUFJQSxxQkFBVyxzQkFBc0IsYUFBcmtCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStrQjtBQUFBLGtCQUFpQix1QkFBQyxrQkFBZSxZQUFXLHdCQUF1QixPQUFNLFNBQVEsVUFBVThCLEVBQUVDLFdBQVcsV0FBVyxTQUFTLE1BQU01RCxZQUFZMkQsQ0FBQyxHQUFHLHVCQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3STtBQUFBLHFCQUEvd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ3lCO0FBQUEsY0FDNTBCO0FBQUEsWUFBQyxLQUp5NEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLNTRDLEtBTHMwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtuMEM7QUFBQSxZQUFjLHVCQUFDLGtCQUFlLE9BQU0sWUFBVyxhQUFhaEYsUUFBUW9ILGFBQWEsU0FBU3BILFFBQVFtRixTQUFTLE1BQU1uRixRQUFRcUgsZUFBZSxZQUFZckgsUUFBUXNILFlBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVKO0FBQUEsWUFBR3RILFFBQVFvRixXQUFXLHVCQUFDLGtCQUFnQjtBQUFBLHFDQUFDLGVBQVksT0FBT3BGLFFBQVExRSxTQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQUUsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsc0JBQU0wRSxRQUFRdUgsdUJBQXVCdkgsUUFBUXNILFNBQVMsSUFBSXRILFFBQVE2QyxRQUFRO0FBQUEsY0FBSSxHQUFHLDBDQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSjtBQUFBLGlCQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErTTtBQUFBLGVBTC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS2lJO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU0scUJBQW9CLFVBQVMsU0FBUSxpQ0FBQyxrQkFBZ0I7QUFBQSxtQ0FBQyxjQUFXLE9BQU0sa0JBQWlCLGlGQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLFlBQWEsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsU0FBUSxZQUFXLE1BQU03QixLQUFLeEQsU0FBUyxTQUFTLFlBQVk7QUFBRSxrQkFBSTtBQUM3c0Isc0JBQU1nSyxJQUFJLE1BQU14RyxLQUFLdkQsUUFBUTtBQUM3QjhELDJCQUFXaUcsRUFBRWpNLElBQUk7QUFBQSxjQUNyQixRQUNNO0FBQUEsY0FBRTtBQUFBLFlBQWdCLEdBQUcsK0JBSmtrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUluakI7QUFBQSxZQUFrQitGLFdBQVcsdUJBQUMsU0FBTSxVQUFTLFFBQVE0QjtBQUFBQSx5QkFBVywrQ0FBK0M7QUFBQSxjQUFHO0FBQUEsY0FBTTVCLFFBQVFtRztBQUFBQSxjQUFZLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBRztBQUFBLGNBQUc7QUFBQSxjQUFLbkcsUUFBUW9HO0FBQUFBLGNBQVksdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFHO0FBQUEsY0FBRztBQUFBLGNBQVNuTyxTQUFTK0gsUUFBUXFHLFdBQVdqTixLQUFLc0MsUUFBUTtBQUFBLGlCQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3TTtBQUFBLGVBSjRNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSW5NLEtBSmlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSWhJO0FBQUEsYUFUL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVN1RTtBQUFBLFFBQWUsdUJBQUMsU0FBTSxPQUFNLDZCQUE0QixVQUFTLFNBQVEsaUNBQUMsY0FBVyxPQUFPaUQsUUFBUSxnQkFBZSxXQUFVO0FBQUEsaUNBQUMsY0FBVyxXQUFVLFFBQU8sS0FBSzhDLFlBQVksVUFBVSxDQUFBNkUsVUFBUztBQUFFQSxrQkFBTUMsZUFBZTtBQUFHLGlCQUFLdkMsV0FBVztBQUFBLFVBQUcsR0FBRztBQUFBLG1DQUFDLGVBQVksT0FBT3ZFLEtBQUt6RixTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQUUsdUJBQUMsaUJBQWMsUUFBZ0IsUUFBUSxFQUFFaUUsU0FBUyxlQUFlTixTQUFTLG1CQUFtQkcsS0FBSyxlQUFlSyxPQUFPLGdCQUFnQkUsWUFBWSxlQUFlQyxVQUFVLGdCQUFnQkosU0FBUyxvQkFBb0J5QyxVQUFVLGtCQUFrQm5GLFNBQVMsaUJBQWlCc0YsUUFBUSxlQUFlLEdBQUcsTUFBTXJCLEtBQUt2RCxXQUFyVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2VDtBQUFBLFlBQUUsdUJBQUMsb0JBQWlCLE9BQU0seUJBQXdCLFNBQVMsdUJBQUMsWUFBUyxTQUFTK0IsU0FBUyxVQUFVLENBQUF1RixNQUFLcEQsV0FBV29ELEVBQUVvQyxPQUFPWSxPQUFPLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9JO0FBQUEsWUFBRSx1QkFBQyxhQUFVLE9BQU0sMkNBQTBDLE9BQU83SSxTQUFTLFVBQVUsQ0FBQTZGLE1BQUtuRCxXQUFXbUQsRUFBRW9DLE9BQU85SSxLQUFLLEdBQUcsTUFBSyxVQUFTLFlBQVksRUFBRTJKLEtBQUssRUFBRSxLQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySjtBQUFBLFlBQUUsdUJBQUMsYUFBVSxPQUFNLHNCQUFxQixPQUFPM0ksS0FBSyxVQUFVLENBQUEwRixNQUFLbEQsT0FBT2tELEVBQUVvQyxPQUFPOUksS0FBSyxHQUFHLE1BQUssVUFBUyxZQUFZLEVBQUUySixLQUFLLEVBQUUsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEg7QUFBQSxZQUFFLHVCQUFDLGFBQVUsT0FBTSxrQkFBaUIsT0FBTzVILG1CQUFtQixVQUFVLENBQUF5SCxVQUFTeEgscUJBQXFCd0gsTUFBTVYsT0FBTzlJLEtBQUssR0FBRyxVQUFVLENBQUM4QixrQkFBa0IsWUFBVywwRUFBaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdU87QUFBQSxZQUFFLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sb0JBQW1CLE9BQU9WLFNBQVMsV0FBVyxFQUFFd0ksUUFBUSxFQUFFQyxVQUFVLEtBQUssRUFBRSxHQUFHLFVBQVUsQ0FBQW5ELE1BQUs5QyxXQUFXLE9BQU84QyxFQUFFb0MsT0FBTzlJLFVBQVUsV0FBVzBHLEVBQUVvQyxPQUFPOUksTUFBTThKLE1BQU0sR0FBRyxJQUFJcEQsRUFBRW9DLE9BQU85SSxLQUFLLEdBQUksV0FBQyxHQUFHd0ksZUFBZSxHQUFHTixVQUFVLEVBQUU5SyxJQUFJLENBQUEyTSxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUU5TSxJQUFLOE0sWUFBRS9RLFNBQXRCK1EsRUFBRTlNLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLENBQVcsS0FBcFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc1Q7QUFBQSxZQUFZLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sa0JBQWlCLE9BQU80RyxVQUFVLFdBQVcsRUFBRStGLFFBQVEsRUFBRUMsVUFBVSxLQUFLLEVBQUUsR0FBRyxVQUFVLENBQUFuRCxNQUFLNUMsWUFBWSxPQUFPNEMsRUFBRW9DLE9BQU85SSxVQUFVLFdBQVcwRyxFQUFFb0MsT0FBTzlJLE1BQU04SixNQUFNLEdBQUcsSUFBSXBELEVBQUVvQyxPQUFPOUksS0FBSyxHQUFJLFdBQUMsR0FBR3dJLGVBQWUsR0FBR04sVUFBVSxFQUFFOUssSUFBSSxDQUFBMk0sTUFBSyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFOU0sSUFBSzhNLFlBQUUvUSxTQUF0QitRLEVBQUU5TSxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQyxDQUFXLEtBQXBUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNUO0FBQUEsWUFBWSx1QkFBQyxrQkFBZSxPQUFNLGNBQWEsYUFBYXNGLFFBQVF5RyxhQUFhLFNBQVN6RyxRQUFRd0UsU0FBUyxNQUFNeEUsUUFBUTBHLGVBQWUsWUFBWTFHLFFBQVEyRyxZQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SjtBQUFBLFlBQUczRyxRQUFReUUsV0FBVyx1QkFBQyxrQkFBZ0I7QUFBQSxxQ0FBQyxlQUFZLE9BQU96RSxRQUFRckYsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFFLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLHNCQUFNcUYsUUFBUTRHLHVCQUF1QjVHLFFBQVEyRyxTQUFTLElBQUkzRyxRQUFRa0MsUUFBUTtBQUFBLGNBQUksR0FBRyw0Q0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUo7QUFBQSxpQkFBeE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaU47QUFBQSxZQUFtQnFDLCtCQUErQix1QkFBQyxTQUFNLFVBQVMsUUFBTyxNQUFLLFVBQVVsRixrQkFBUW9GLFVBQVUsNkdBQTZHcEYsUUFBUW1GLFVBQVUsNkZBQTZGLGtFQUFwUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtVjtBQUFBLFlBQVMsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxpQkFBZ0IsT0FBT3JJLFNBQVMsVUFBVSxDQUFBZ0ksTUFBSzNDLFdBQVcyQyxFQUFFb0MsT0FBTzlJLEtBQXVCLEdBQUc7QUFBQSxxQ0FBQyxZQUFTLE9BQU0sUUFBTyx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUFXLHVCQUFDLFlBQVMsT0FBTSxZQUFXLFVBQVUsQ0FBQ3lCLG1CQUFvQkEsOEJBQW9CLHlCQUF5QnFGLDhCQUE4QiwyQkFBMkIsd0NBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFNO0FBQUEsaUJBQXBXO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStXO0FBQUEsWUFBYXBJLFlBQVksY0FBYyxDQUFDK0MscUJBQXFCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLDBIQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSTtBQUFBLFlBQVMsdUJBQUMsb0JBQWlCLE9BQU0sbUJBQWtCLFNBQVMsdUJBQUMsWUFBUyxTQUFTSixPQUFPLFVBQVUsQ0FBQXFGLE1BQUtqRCxTQUFTaUQsRUFBRW9DLE9BQU9ZLE9BQU8sS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0UsS0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEg7QUFBQSxZQUFHckksU0FBUyx1QkFBQyxjQUFXLFdBQVcsRUFBRXBELElBQUksVUFBVStMLElBQUksTUFBTSxHQUFHO0FBQUEscUNBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxNQUFLLE9BQU96SSxZQUFZLFVBQVUsQ0FBQW1GLE1BQUtoRCxjQUFjZ0QsRUFBRW9DLE9BQU85SSxLQUFLLEdBQUcsV0FBUyxRQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RztBQUFBLGNBQUUsdUJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxPQUFNLE9BQU93QixVQUFVLFVBQVUsQ0FBQWtGLE1BQUsvQyxZQUFZK0MsRUFBRW9DLE9BQU85SSxLQUFLLEdBQUcsV0FBUyxRQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RztBQUFBLGlCQUEzUTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2UTtBQUFBLFlBQWMsdUJBQUMsY0FBVyxTQUFRLFdBQVU7QUFBQTtBQUFBLGNBQWMxRCxLQUFLc0M7QUFBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFBYSx1QkFBQyxvQkFBaUIsT0FBTSw2Q0FBNEMsU0FBUyx1QkFBQyxZQUFTLFNBQVNvRixRQUFRLFVBQVUsQ0FBQTBDLE1BQUt6QyxVQUFVeUMsRUFBRW9DLE9BQU9ZLE9BQU8sS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0UsS0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0o7QUFBQSxZQUFHekMsZUFBZSx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHlCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLGVBQTF1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtdkg7QUFBQSxVQUFhLHVCQUFDLGVBQVksV0FBVSxVQUFTLFdBQVUsUUFBTyxpQ0FBQyxrQkFBZSxZQUFXLHdCQUF1QixTQUFRLGFBQVksTUFBTXRFLEtBQUt2RCxTQUFTLFVBQVUsQ0FBQ3lDLE9BQU8xRSxRQUFRLENBQUMsQ0FBQzhKLGVBQWV0RSxLQUFLdkQsU0FBUyxTQUFTLE1BQU0sS0FBSzhILFdBQVcsR0FBRywyQkFBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ00sS0FBalA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa1E7QUFBQSxhQUF0akk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFva0ksS0FBOW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMm9JO0FBQUEsV0FUL3pJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTdTBJO0FBQUEsTUFBYyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxlQUFZLGdDQUErQixpTkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtUTtBQUFBLFNBVHRtSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUzhtSjtBQUFBLElBQWUsdUJBQUMsaUJBQWMsTUFBTSxDQUFDLENBQUNsSixVQUFVLE9BQU0sb0JBQW1CLGNBQWEsb0JBQW1CLGFBQWEsWUFBWUEsVUFBVTZFLGNBQWMsRUFBRSxLQUFLN0UsVUFBVWYsTUFBTSxFQUFFLDhGQUE4RixTQUFTLE1BQU1nRyxZQUFZLElBQUksR0FBRyxNQUFNUCxPQUFPdEQsU0FBUyxPQUFPc0QsT0FBT3hGLE9BQU8sV0FBVyxNQUFNd0YsT0FBT3JELFFBQVEsRUFBRXhDLE1BQU0sRUFBRUMsWUFBWWtCLFVBQVVmLE1BQU0sR0FBRyxHQUFHcUMsTUFBTSxFQUFFQyxpQkFBaUJ2QixVQUFVd0IsV0FBVyxFQUFFLEVBQUUsQ0FBQyxLQUE5YztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdkO0FBQUEsT0FUcHNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTc3NLO0FBQ2p0SztBQUFDbUMsSUEvRWVELGFBQVc7QUFBQSxVQUNHMUcsVUFDVkgsYUFDREQsUUFDVUcsUUFNVEYsYUFDQ0MsWUFDSkEsWUFDRUEsWUFDRkEsWUFDQUEsWUFHRTVCLG1CQU1JQyxZQUFZO0FBQUE7QUFBQSxNQXhCbkJ1STtBQWlGaEIsU0FBUzBDLHFCQUFxQnZDLFFBQTRCO0FBQ3RELFNBQU8sRUFBRXJDLFNBQVNxQyxPQUFPckMsU0FBUytFLFFBQVEsRUFBRXBELFNBQVNVLE9BQU9WLFNBQVNOLFNBQVNnQixPQUFPNEYsb0JBQW9Cd0MsU0FBUyxLQUFLLElBQUlqSixLQUFLa0osT0FBT3JJLE9BQU82RixZQUFZLEdBQUdyRyxPQUFPLENBQUMsQ0FBQ1EsT0FBT3lGLFlBQVkvRixZQUFZTSxPQUFPeUYsWUFBWUMsU0FBUyxTQUFTL0YsVUFBVUssT0FBT3lGLFlBQVlFLE9BQU8sU0FBU3BHLFNBQVNTLE9BQU84RixnQkFBZ0I5RCxVQUFVaEMsT0FBTytGLGlCQUFpQmxKLFNBQVNtRCxPQUFPZ0csaUJBQWlCN0QsUUFBUW5DLE9BQU9pRywwQkFBMEIsRUFBRTtBQUN6YTtBQUFDLElBQUFxQyxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwidXNlVmVyc2lvbmVkRHJhZnQiLCJ1c2VEcmFmdEZvcm0iLCJEcmFmdENvbmZsaWN0IiwiQWN0aW9uR3JvdXAiLCJGaWVsZEdyb3VwIiwiRm9ybUZpZWxkcyIsIlBhZ2VTZWN0aW9ucyIsIlNlY3Rpb25HcmlkIiwiU3VyZmFjZUNvbnRlbnQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInZpc3VhbFN4IiwiQWxlcnQiLCJCb3giLCJCdXR0b24iLCJDaGVja2JveCIsIkZvcm1Db250cm9sTGFiZWwiLCJNZW51SXRlbSIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsIk5vdGlmaWNhdGlvbnNBY3RpdmVSb3VuZGVkIiwiU21hcnRwaG9uZVJvdW5kZWQiLCJjb2xvcnMiLCJ0b2tlbnMiLCJsYXlvdXRTeCIsInVzZUFwaSIsInVzZVBhZ2VkQXBpIiwidXNlQ29tbWFuZCIsInVzZUNhbiIsInVzZVNjb3BlIiwidXNlTGlzdFF1ZXJ5IiwibGltaXRDb2RlUG9pbnRzIiwiZGF0ZVRpbWUiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJEYXRhVGFibGUiLCJRdWVyeVN0YXRlIiwiVG9vbGJhciIsIlBhZ2VyIiwiU3RhdHVzIiwiTXV0YXRpb25CdXR0b24iLCJFcnJvck5vdGljZSIsIkNvbmZpcm1EaWFsb2ciLCJFZGl0RGlhbG9nIiwiRGV0YWlsTGluZSIsIlJvdXRlTGluayIsIkxvb2t1cExvYWRNb3JlIiwiYXNzZXJ0UHVzaENhcGFiaWxpdHkiLCJhc3NlcnRQdXNoUGVybWlzc2lvbkdyYW50ZWQiLCJOb3RpZmljYXRpb25zUGFnZSIsIl9zIiwic2hvcCIsInNlc3Npb24iLCJsaXN0IiwicXVlcnkiLCJkZXRhaWxJZCIsInNldERldGFpbElkIiwiZGV0YWlsIiwicGF0aCIsInJlc291cmNlSWQiLCJCb29sZWFuIiwiYWNrIiwiaWQiLCJlcnJvciIsImRhdGEiLCJtYXAiLCJuIiwic3VyZmFjZSIsImluc2V0IiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJhY2tub3dsZWRnZWRBdCIsImhlcm9Cb3JkZXIiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJsYXJnZSIsImJnY29sb3IiLCJzZWxlY3RlZCIsInhzIiwibWQiLCJjb2xvciIsInRpdGxlIiwicGFnZUhlYWRlciIsInRpdGxlRGVzY3JpcHRpb25HYXAiLCJzYWZlQm9keSIsImRlbGl2ZXJ5U3RhdHVzIiwiYWxpZ25TZWxmIiwiY2hhbm5lbCIsImNyZWF0ZWRBdCIsInRpbWV6b25lIiwicmVsYXRlZENvbnRlbnRHYXAiLCJkaXNwbGF5Iiwib3BlbmVkQXQiLCJhbGxvd2VkQWN0aW9ucyIsIndvcmtJdGVtSWQiLCJyZWNpcGllbnRVc2VySWQiLCJ1c2VyIiwicGVuZGluZyIsImV4ZWN1dGUiLCJib2R5IiwiZXhwZWN0ZWRWZXJzaW9uIiwidmVyc2lvbiIsImNhdGNoIiwidW5kZWZpbmVkIiwic291cmNlIiwidHlwZSIsImxlbmd0aCIsInBhZ2UiLCJiYXNlNjRCeXRlcyIsInZhbHVlIiwicGFkZGVkIiwicmVwZWF0IiwicmVwbGFjZSIsInJhdyIsImF0b2IiLCJieXRlcyIsIlVpbnQ4QXJyYXkiLCJpIiwiY2hhckNvZGVBdCIsInZhbGlkYXRlUG9saWN5IiwiaW5wdXQiLCJyZW1pbmRlciIsIm1pbnV0ZXMiLCJ0cmltIiwibWF4aW11bSIsIm1heCIsIk51bWJlciIsImlzU2FmZUludGVnZXIiLCJlbmFibGVkIiwicHJpbWFyeSIsInF1aWV0IiwidGVzdCIsInF1aWV0U3RhcnQiLCJxdWlldEVuZCIsInRlbGVncmFtQXZhaWxhYmxlIiwiRGV2aWNlc1BhZ2UiLCJfczIiLCJkZXZpY2VzIiwicG9saWN5IiwiY2FuTWFuYWdlTWVtYmVycyIsIm1lbWJlclNlYXJjaElucHV0Iiwic2V0TWVtYmVyU2VhcmNoSW5wdXQiLCJtZW1iZXJTZWFyY2giLCJzZXRNZW1iZXJTZWFyY2giLCJ0aW1lciIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJtZW1iZXJzIiwicSIsInJlZ2lzdGVyIiwicmV2b2tlIiwic2F2ZSIsInBhaXIiLCJkZXZpY2VOYW1lIiwic2V0RGV2aWNlTmFtZSIsInNldEVycm9yIiwic2V0UGVuZGluZyIsInNldFNlbGVjdGVkIiwicGFpcmluZyIsInNldFBhaXJpbmciLCJkZXZpY2VUZXN0TWVzc2FnZSIsInNldERldmljZVRlc3RNZXNzYWdlIiwic2V0RW5hYmxlZCIsInNldE1pbnV0ZXMiLCJzZXRNYXgiLCJzZXRRdWlldCIsInNldFF1aWV0U3RhcnQiLCJzZXRRdWlldEVuZCIsInNldFByaW1hcnkiLCJmYWxsYmFjayIsInNldEZhbGxiYWNrIiwic2V0Q2hhbm5lbCIsInVyZ2VudCIsInNldFVyZ2VudCIsImVkaXRvciIsImlkZW50aXR5Iiwibm90aWZpY2F0aW9uU25hcHNob3QiLCJkcmFmdCIsImFwcGx5IiwidmFsdWVzIiwicmVmcmVzaCIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJwb2xpY3lGb3JtIiwiZGlydHkiLCJkZXZpY2VSZWdpc3RlciIsIl9fTU9DS19fIiwiZW5kcG9pbnQiLCJwMjU2ZGgiLCJhdXRoIiwic2VjdXJlQ29udGV4dCIsImlzU2VjdXJlQ29udGV4dCIsInNlcnZpY2VXb3JrZXIiLCJuYXZpZ2F0b3IiLCJwdXNoTWFuYWdlciIsIm5vdGlmaWNhdGlvbiIsImtleSIsImltcG9ydCIsImVudiIsIlZJVEVfV0VCX1BVU0hfUFVCTElDX0tFWSIsIkVycm9yIiwiTm90aWZpY2F0aW9uIiwicmVxdWVzdFBlcm1pc3Npb24iLCJzZXJ2aWNlIiwic2NvcGUiLCJyZWFkeSIsInN1YnNjcmlwdGlvbiIsImdldFN1YnNjcmlwdGlvbiIsInN1YnNjcmliZSIsInVzZXJWaXNpYmxlT25seSIsImFwcGxpY2F0aW9uU2VydmVyS2V5IiwianNvbiIsInRvSlNPTiIsImtleXMiLCJlIiwic29tZSIsImQiLCJzdGF0dXMiLCJ0ZWxlZ3JhbUF2YWlsYWJpbGl0eVBlbmRpbmciLCJoYXNNb3JlIiwiaXNFcnJvciIsInBvbGljeUVycm9yIiwic2F2ZVBvbGljeSIsInByZXBhcmVkIiwicHJlcGFyZSIsInN1Ym1pdHRlZCIsInF1aWV0SG91cnMiLCJzdGFydCIsImVuZCIsInJlbWluZEFmdGVyTWludXRlcyIsIm1heFJlbWluZGVycyIsInByaW1hcnlVc2VySWRzIiwiZmFsbGJhY2tVc2VySWRzIiwiZmFsbGJhY2tDaGFubmVsIiwidXJnZW50TWF5QnlwYXNzUXVpZXRIb3VycyIsInJlc3VsdCIsImNvbW1pdHRlZCIsImZhaWxlZCIsImtub3duVXNlcnMiLCJmaWx0ZXIiLCJtIiwidXNlcklkIiwic2VsZWN0ZWRVc2VySWRzIiwiU2V0IiwicmV0YWluZWRVc2VycyIsImxnIiwibWluV2lkdGgiLCJmb250U2l6ZSIsImljb25TaXplcyIsImRldmljZVByZXZpZXciLCJ0YXJnZXQiLCJyZW5kZXIiLCJsb2FkZWRDb3VudCIsImlzTG9hZGluZ01vcmUiLCJsb2FkTW9yZSIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwiciIsImJvdFVzZXJuYW1lIiwicGFpcmluZ0NvZGUiLCJleHBpcmVzQXQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwiY2hlY2tlZCIsIm1pbiIsInNlbGVjdCIsIm11bHRpcGxlIiwic3BsaXQiLCJ1Iiwic20iLCJ0b1N0cmluZyIsIlN0cmluZyIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2xhYmVsIGFzIGJ1c2luZXNzTGFiZWx9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2xhYmVscyc7XG5pbXBvcnQgeyB1c2VWZXJzaW9uZWREcmFmdCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XHJcbmltcG9ydCB7IHVzZURyYWZ0Rm9ybSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XHJcbmltcG9ydCB7IERyYWZ0Q29uZmxpY3QgfSBmcm9tICdAL3NoYXJlZC91aS9kcmFmdC1jb25mbGljdCc7XHJcbmltcG9ydCB7IEFjdGlvbkdyb3VwLCBGaWVsZEdyb3VwLCBGb3JtRmllbGRzLCBQYWdlU2VjdGlvbnMsIFNlY3Rpb25HcmlkLCBTdXJmYWNlQ29udGVudCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcclxuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBDaGVja2JveCwgRm9ybUNvbnRyb2xMYWJlbCwgTWVudUl0ZW0sIFN0YWNrLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcclxuaW1wb3J0IE5vdGlmaWNhdGlvbnNBY3RpdmVSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvTm90aWZpY2F0aW9uc0FjdGl2ZVJvdW5kZWQnO1xyXG5pbXBvcnQgU21hcnRwaG9uZVJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9TbWFydHBob25lUm91bmRlZCc7XHJcbmltcG9ydCB0eXBlIHsgRGV2aWNlU3Vic2NyaXB0aW9uLCBOb3RpZmljYXRpb25Qb2xpY3ksIE5vdGlmaWNhdGlvblBvbGljeVdyaXRlLCBUZWxlZ3JhbVBhaXJpbmcgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcclxuaW1wb3J0IHsgY29sb3JzLCB0b2tlbnMgfSBmcm9tICdAYm90c2FsZXMvdG9rZW5zJztcclxuaW1wb3J0IHsgbGF5b3V0U3ggfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvbGF5b3V0JztcclxuaW1wb3J0IHsgdXNlQXBpLCB1c2VQYWdlZEFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZUNhbiwgdXNlU2NvcGUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xyXG5pbXBvcnQgeyBsaW1pdENvZGVQb2ludHMsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgUGFnZUhlYWRlciwgUGFuZWwsIERhdGFUYWJsZSwgUXVlcnlTdGF0ZSwgVG9vbGJhciwgUGFnZXIsIFN0YXR1cywgTXV0YXRpb25CdXR0b24sIEVycm9yTm90aWNlLCBDb25maXJtRGlhbG9nLCBFZGl0RGlhbG9nLCBEZXRhaWxMaW5lLCBSb3V0ZUxpbmssIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmltcG9ydCB7IGFzc2VydFB1c2hDYXBhYmlsaXR5LCBhc3NlcnRQdXNoUGVybWlzc2lvbkdyYW50ZWQgfSBmcm9tICcuL3B1c2gtY2FwYWJpbGl0aWVzJztcclxuZXhwb3J0IGZ1bmN0aW9uIE5vdGlmaWNhdGlvbnNQYWdlKCkge1xyXG4gICAgY29uc3QgeyBzaG9wLCBzZXNzaW9uIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdE5vdGlmaWNhdGlvbnMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3ROb3RpZmljYXRpb25zJykgfSk7XHJcbiAgICBjb25zdCBbZGV0YWlsSWQsIHNldERldGFpbElkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldE5vdGlmaWNhdGlvbicsIHsgcGF0aDogeyByZXNvdXJjZUlkOiBkZXRhaWxJZCB9IH0sIEJvb2xlYW4oZGV0YWlsSWQpKTtcbiAgICBjb25zdCBhY2sgPSB1c2VDb21tYW5kKCdhY2tub3dsZWRnZU5vdGlmaWNhdGlvbicsIFsnZ2V0Tm90aWZpY2F0aW9uJywgJ2xpc3ROb3RpZmljYXRpb25zJywgJ2xpc3RXb3JrSXRlbXMnLCAnbGlzdFByZXBKb2JzJywgJ2dldE9wZXJhdGlvbnNTdW1tYXJ5J10pO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJUcnVuZyB0w6JtIHRow7RuZyBiw6FvXCIgc3VidGl0bGU9XCLEkMOjIGfhu61pIGtow7RuZyDEkeG7k25nIG5naMSpYSDEkcOjIMSR4buNYy4gTmjhuq1uIHZp4buHYyBsw6AgbeG7mXQgeMOhYyBuaOG6rW4gcmnDqm5nLlwiIGFjdGlvbnM9ezxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L25vdGlmaWNhdGlvbnMvZGV2aWNlc2B9PsSQaeG7h24gdGhv4bqhaSAmIGzhu4tjaCB0cuG7sWM8L1JvdXRlTGluaz59Lz48RXJyb3JOb3RpY2UgZXJyb3I9e2Fjay5lcnJvcn0vPjxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0Tm90aWZpY2F0aW9uc1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9PjxTdXJmYWNlQ29udGVudCBib2R5TW9kZT1cImluc2V0XCI+e2xpc3QuZGF0YT8uZGF0YS5tYXAobiA9PiA8Qm94IGtleT17bi5pZH0gc3g9e1tsYXlvdXRTeC5zdXJmYWNlLmluc2V0LCB7XHJcbiAgICAgICAgIGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6IG4uYWNrbm93bGVkZ2VkQXQgPyAnZGl2aWRlcicgOiBjb2xvcnMuaGVyb0JvcmRlciwgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMubGFyZ2UsIGJnY29sb3I6IG4uYWNrbm93bGVkZ2VkQXQgPyAndHJhbnNwYXJlbnQnIDogY29sb3JzLnNlbGVjdGVkXHJcbiAgICB9XX0+PFN1cmZhY2VDb250ZW50IGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIG1kOiAncm93JyB9fSBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiA+PFN1cmZhY2VDb250ZW50IGRpcmVjdGlvbj1cInJvd1wiID48Tm90aWZpY2F0aW9uc0FjdGl2ZVJvdW5kZWQgc3g9e3sgY29sb3I6ICdwcmltYXJ5Lm1haW4nIH19Lz48Qm94PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiPntuLnRpdGxlfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LnBhZ2VIZWFkZXIudGl0bGVEZXNjcmlwdGlvbkdhcH0+e24uc2FmZUJvZHl9PC9UeXBvZ3JhcGh5PjxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiBiZWZvcmVHYXA9XCJkZXRhaWxcIj48U3RhdHVzIHZhbHVlPXtuLmRlbGl2ZXJ5U3RhdHVzfS8+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBzeD17eyBhbGlnblNlbGY6ICdjZW50ZXInIH19PntidXNpbmVzc0xhYmVsKG4uY2hhbm5lbCl9IMK3IHtkYXRlVGltZShuLmNyZWF0ZWRBdCwgc2hvcC50aW1lem9uZSl9PC9UeXBvZ3JhcGh5PjwvQWN0aW9uR3JvdXA+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e1tsYXlvdXRTeC5kZXRhaWwucmVsYXRlZENvbnRlbnRHYXAsIHsgZGlzcGxheTogJ2Jsb2NrJyB9XX0+e24uYWNrbm93bGVkZ2VkQXQgPyBgxJDDoyBuaOG6rW4gdmnhu4djIGzDumMgJHtkYXRlVGltZShuLmFja25vd2xlZGdlZEF0LCBzaG9wLnRpbWV6b25lKX1gIDogbi5vcGVuZWRBdCA/ICdDw7MgZ2hpIG5o4bqtbiBt4bufIHRow7RuZyBiw6FvOyBjaMawYSBuaOG6rW4gdmnhu4djLicgOiAnQ2jGsGEgY8OzIGLhurFuZyBjaOG7qW5nIMSRw6MgbeG7nyBob+G6t2Mgbmjhuq1uIHZp4buHYy4nfTwvVHlwb2dyYXBoeT48L0JveD48L1N1cmZhY2VDb250ZW50PjxTdXJmYWNlQ29udGVudCBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiID48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldERldGFpbElkKG4uaWQpfT5DaGkgdGnhur90IHRow7RuZyBiw6FvPC9CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJvcGVyYXRpb25zLmNsYWltXCIgYWxsb3dlZEFjdGlvbnM9e24uYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cImFja25vd2xlZGdlXCIgZGlzYWJsZWQ9eyFuLndvcmtJdGVtSWQgfHwgbi5yZWNpcGllbnRVc2VySWQgIT09IHNlc3Npb24udXNlci5pZH0gYnVzeT17YWNrLnBlbmRpbmd9IHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGFjay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBuLmlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBuLnZlcnNpb24gfSB9KS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpfT5Uw7RpIG5o4bqtbiBjaHXhuqluIGLhu4sgxJHGoW48L011dGF0aW9uQnV0dG9uPntuLnNvdXJjZS50eXBlID09PSAnb3JkZXInICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy8ke24uc291cmNlLmlkfWB9PlhlbSDEkcahbjwvUm91dGVMaW5rPn08L1N1cmZhY2VDb250ZW50PjwvU3VyZmFjZUNvbnRlbnQ+PC9Cb3g+KX17bGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgcm9sZT1cInN0YXR1c1wiPkNoxrBhIGPDsyB0aMO0bmcgYsOhby4gVGjDtG5nIGLDoW8gY2h14bqpbiBi4buLIMSRxrDhu6NjIHThuqFvIHNhdSBraGkgxJHGoW4gxJHDoyB4w6FjIG5o4bqtbiB2w6AgZ2nhu68gaMOgbmcgdGjDoG5oIGPDtG5nLjwvQWxlcnQ+fTxQYWdlciBwYWdlPXtsaXN0LmRhdGE/LnBhZ2V9Lz48L1N1cmZhY2VDb250ZW50PjwvUXVlcnlTdGF0ZT48L1BhbmVsPlxuICAgIDxFZGl0RGlhbG9nIG9wZW49eyEhZGV0YWlsSWR9IHRpdGxlPVwiQ2hpIHRp4bq/dCB0aMO0bmcgYsOhb1wiIG9uQ2xvc2U9eygpID0+IHNldERldGFpbElkKCcnKX0gYWN0aW9ucz17PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXRhaWxJZCgnJyl9PsSQw7NuZzwvQnV0dG9uPn0+XG4gICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntkZXRhaWwuZGF0YSAmJiA8U3VyZmFjZUNvbnRlbnQ+XG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIj57ZGV0YWlsLmRhdGEuZGF0YS50aXRsZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHk+e2RldGFpbC5kYXRhLmRhdGEuc2FmZUJvZHl9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLw6puaFwiPntidXNpbmVzc0xhYmVsKGRldGFpbC5kYXRhLmRhdGEuY2hhbm5lbCl9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiR2lhbyB0aMO0bmcgYsOhb1wiPjxTdGF0dXMgdmFsdWU9e2RldGFpbC5kYXRhLmRhdGEuZGVsaXZlcnlTdGF0dXN9Lz48L0RldGFpbExpbmU+XG4gICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlThuqFvIGzDumNcIj57ZGF0ZVRpbWUoZGV0YWlsLmRhdGEuZGF0YS5jcmVhdGVkQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIk3hu58gbMO6Y1wiPntkYXRlVGltZShkZXRhaWwuZGF0YS5kYXRhLm9wZW5lZEF0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJOaOG6rW4gdmnhu4djIGzDumNcIj57ZGF0ZVRpbWUoZGV0YWlsLmRhdGEuZGF0YS5hY2tub3dsZWRnZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJOZ3Xhu5NuXCI+e2RldGFpbC5kYXRhLmRhdGEuc291cmNlLnR5cGV9IMK3IHtkZXRhaWwuZGF0YS5kYXRhLnNvdXJjZS5pZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJNw6MgY8O0bmcgdmnhu4djXCI+e2RldGFpbC5kYXRhLmRhdGEud29ya0l0ZW1JZCB8fCAnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+XG4gICAgICAgIDwvU3VyZmFjZUNvbnRlbnQ+fTwvUXVlcnlTdGF0ZT5cbiAgICA8L0VkaXREaWFsb2c+PC8+O1xyXG59XHJcbmZ1bmN0aW9uIGJhc2U2NEJ5dGVzKHZhbHVlOiBzdHJpbmcpIHsgY29uc3QgcGFkZGVkID0gKHZhbHVlICsgJz0nLnJlcGVhdCgoNCAtIHZhbHVlLmxlbmd0aCAlIDQpICUgNCkpLnJlcGxhY2UoLy0vZywgJysnKS5yZXBsYWNlKC9fL2csICcvJyk7IGNvbnN0IHJhdyA9IGF0b2IocGFkZGVkKTsgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShyYXcubGVuZ3RoKTsgZm9yIChsZXQgaSA9IDA7IGkgPCByYXcubGVuZ3RoOyBpKyspXHJcbiAgICBieXRlc1tpXSA9IHJhdy5jaGFyQ29kZUF0KGkpOyByZXR1cm4gYnl0ZXM7IH1cclxuZnVuY3Rpb24gdmFsaWRhdGVQb2xpY3koaW5wdXQ6IHsgZW5hYmxlZDogYm9vbGVhbjsgbWludXRlczogc3RyaW5nOyBtYXg6IHN0cmluZzsgcHJpbWFyeTogc3RyaW5nW107IHF1aWV0OiBib29sZWFuOyBxdWlldFN0YXJ0OiBzdHJpbmc7IHF1aWV0RW5kOiBzdHJpbmc7IGNoYW5uZWw6ICdub25lJyB8ICd0ZWxlZ3JhbSc7IHRlbGVncmFtQXZhaWxhYmxlOiBib29sZWFuIH0pIHtcclxuICAgIGNvbnN0IHJlbWluZGVyID0gaW5wdXQubWludXRlcy50cmltKCk7XHJcbiAgICBjb25zdCBtYXhpbXVtID0gaW5wdXQubWF4LnRyaW0oKTtcclxuICAgIGlmIChtYXhpbXVtID09PSAnJyB8fCAhTnVtYmVyLmlzU2FmZUludGVnZXIoTnVtYmVyKG1heGltdW0pKSB8fCBOdW1iZXIobWF4aW11bSkgPCAwKVxyXG4gICAgICAgIHJldHVybiAnU+G7kSBs4bqnbiBuaOG6r2MgdOG7kWkgxJFhIHBo4bqjaSBsw6Agc+G7kSBuZ3V5w6puIHThu6sgMCB0cuG7nyBsw6puLic7XHJcbiAgICBpZiAocmVtaW5kZXIgJiYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihOdW1iZXIocmVtaW5kZXIpKSB8fCBOdW1iZXIocmVtaW5kZXIpIDwgMSkpXHJcbiAgICAgICAgcmV0dXJuICdUaOG7nWkgZ2lhbiBuaOG6r2MgcGjhuqNpIGzDoCBz4buRIG5ndXnDqm4gdOG7qyAxIHBow7p0IHRy4bufIGzDqm4uJztcclxuICAgIGlmIChpbnB1dC5lbmFibGVkICYmICFyZW1pbmRlcilcclxuICAgICAgICByZXR1cm4gJ0PhuqduIG5o4bqtcCB0aOG7nWkgZ2lhbiBuaOG6r2Mga2hpIGLhuq10IHF1eSB04bqvYy4nO1xyXG4gICAgaWYgKGlucHV0LmVuYWJsZWQgJiYgIWlucHV0LnByaW1hcnkubGVuZ3RoKVxyXG4gICAgICAgIHJldHVybiAnQ+G6p24gY2jhu41uIMOtdCBuaOG6pXQgbeG7mXQgbmfGsOG7nWkgbmjhuq1uIGNow61uaCBraGkgYuG6rXQgcXV5IHThuq9jLic7XHJcbiAgICBpZiAoaW5wdXQucXVpZXQgJiYgKCEvXihbMDFdXFxkfDJbMC0zXSk6WzAtNV1cXGQkLy50ZXN0KGlucHV0LnF1aWV0U3RhcnQpIHx8ICEvXihbMDFdXFxkfDJbMC0zXSk6WzAtNV1cXGQkLy50ZXN0KGlucHV0LnF1aWV0RW5kKSkpXHJcbiAgICAgICAgcmV0dXJuICdHaeG7nSB5w6puIGzhurduZyBj4bqnbiBjw7MgdGjhu51pIMSRaeG7g20gYuG6r3QgxJHhuqd1IHbDoCBr4bq/dCB0aMO6YyBo4bujcCBs4buHLic7XHJcbiAgICBpZiAoaW5wdXQuY2hhbm5lbCA9PT0gJ3RlbGVncmFtJyAmJiAhaW5wdXQudGVsZWdyYW1BdmFpbGFibGUpXHJcbiAgICAgICAgcmV0dXJuICdDaMawYSBjw7MgdGhp4bq/dCBi4buLIFRlbGVncmFtIGFjdGl2ZS4gSG/DoG4gdOG6pXQgbGnDqm4ga+G6v3QgdGjhuq10IHRyxrDhu5tjIGtoaSBjaOG7jW4ga8OqbmggbsOgeS4nO1xyXG4gICAgcmV0dXJuICcnO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBEZXZpY2VzUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCwgc2Vzc2lvbiB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGRldmljZXMgPSB1c2VQYWdlZEFwaSgnbGlzdERldmljZXMnKTtcclxuICAgIGNvbnN0IHBvbGljeSA9IHVzZUFwaSgnZ2V0Tm90aWZpY2F0aW9uUG9saWN5Jyk7XHJcbiAgICBjb25zdCBjYW5NYW5hZ2VNZW1iZXJzID0gdXNlQ2FuKCdtZW1iZXJzLm1hbmFnZScpO1xyXG4gICAgY29uc3QgW21lbWJlclNlYXJjaElucHV0LCBzZXRNZW1iZXJTZWFyY2hJbnB1dF0gPSB1c2VTdGF0ZSgnJyksIFttZW1iZXJTZWFyY2gsIHNldE1lbWJlclNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0TWVtYmVyU2VhcmNoKG1lbWJlclNlYXJjaElucHV0LnRyaW0oKSksIDI1MCk7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgfSwgW21lbWJlclNlYXJjaElucHV0XSk7XHJcbiAgICBjb25zdCBtZW1iZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RNZW1iZXJzJywgeyBxdWVyeTogeyBxOiBtZW1iZXJTZWFyY2ggfHwgdW5kZWZpbmVkIH0gfSwgY2FuTWFuYWdlTWVtYmVycyk7XHJcbiAgICBjb25zdCByZWdpc3RlciA9IHVzZUNvbW1hbmQoJ2NyZWF0ZURldmljZScsIFsnbGlzdERldmljZXMnXSk7XHJcbiAgICBjb25zdCB0ZXN0ID0gdXNlQ29tbWFuZCgndGVzdERldmljZScsIFsnbGlzdERldmljZXMnLCAnbGlzdE5vdGlmaWNhdGlvbnMnXSk7XHJcbiAgICBjb25zdCByZXZva2UgPSB1c2VDb21tYW5kKCdyZXZva2VEZXZpY2UnLCBbJ2xpc3REZXZpY2VzJ10pO1xyXG4gICAgY29uc3Qgc2F2ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZU5vdGlmaWNhdGlvblBvbGljeScsIFsnZ2V0Tm90aWZpY2F0aW9uUG9saWN5J10pO1xyXG4gICAgY29uc3QgcGFpciA9IHVzZUNvbW1hbmQoJ2JlZ2luVGVsZWdyYW1QYWlyaW5nJywgW10pO1xyXG4gICAgY29uc3QgW2RldmljZU5hbWUsIHNldERldmljZU5hbWVdID0gdXNlU3RhdGUoJ8SQaeG7h24gdGhv4bqhaSBj4bunYSB0w7RpJyksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKSwgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpLCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPERldmljZVN1YnNjcmlwdGlvbiB8IG51bGw+KG51bGwpLCBbcGFpcmluZywgc2V0UGFpcmluZ10gPSB1c2VTdGF0ZTxUZWxlZ3JhbVBhaXJpbmcgfCBudWxsPihudWxsKSwgW2RldmljZVRlc3RNZXNzYWdlLCBzZXREZXZpY2VUZXN0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbZW5hYmxlZCwgc2V0RW5hYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFttaW51dGVzLCBzZXRNaW51dGVzXSA9IHVzZVN0YXRlKCcnKSwgW21heCwgc2V0TWF4XSA9IHVzZVN0YXRlKCcyJyksIFtxdWlldCwgc2V0UXVpZXRdID0gdXNlU3RhdGUoZmFsc2UpLCBbcXVpZXRTdGFydCwgc2V0UXVpZXRTdGFydF0gPSB1c2VTdGF0ZSgnMjI6MDAnKSwgW3F1aWV0RW5kLCBzZXRRdWlldEVuZF0gPSB1c2VTdGF0ZSgnMDg6MDAnKSwgW3ByaW1hcnksIHNldFByaW1hcnldID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKSwgW2ZhbGxiYWNrLCBzZXRGYWxsYmFja10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pLCBbY2hhbm5lbCwgc2V0Q2hhbm5lbF0gPSB1c2VTdGF0ZTwnbm9uZScgfCAndGVsZWdyYW0nPignbm9uZScpLCBbdXJnZW50LCBzZXRVcmdlbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgZWRpdG9yID0gdXNlVmVyc2lvbmVkRHJhZnQoe1xyXG4gICAgICAgIGlkZW50aXR5OiBgJHtzaG9wLmlkfTpub3RpZmljYXRpb24tcG9saWN5YCwgc291cmNlOiBwb2xpY3kuZGF0YSA/IG5vdGlmaWNhdGlvblNuYXBzaG90KHBvbGljeS5kYXRhLmRhdGEpIDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGRyYWZ0OiB7IGVuYWJsZWQsIG1pbnV0ZXMsIG1heCwgcXVpZXQsIHF1aWV0U3RhcnQsIHF1aWV0RW5kLCBwcmltYXJ5LCBmYWxsYmFjaywgY2hhbm5lbCwgdXJnZW50IH0sXHJcbiAgICAgICAgYXBwbHk6IHZhbHVlcyA9PiB7IHNldEVuYWJsZWQodmFsdWVzLmVuYWJsZWQpOyBzZXRNaW51dGVzKHZhbHVlcy5taW51dGVzKTsgc2V0TWF4KHZhbHVlcy5tYXgpOyBzZXRRdWlldCh2YWx1ZXMucXVpZXQpOyBzZXRRdWlldFN0YXJ0KHZhbHVlcy5xdWlldFN0YXJ0KTsgc2V0UXVpZXRFbmQodmFsdWVzLnF1aWV0RW5kKTsgc2V0UHJpbWFyeSh2YWx1ZXMucHJpbWFyeSk7IHNldEZhbGxiYWNrKHZhbHVlcy5mYWxsYmFjayk7IHNldENoYW5uZWwodmFsdWVzLmNoYW5uZWwpOyBzZXRVcmdlbnQodmFsdWVzLnVyZ2VudCk7IH0sXHJcbiAgICAgICAgcmVmcmVzaDogKCkgPT4gcG9saWN5LnJlZmV0Y2goeyB0aHJvd09uRXJyb3I6IHRydWUgfSksXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHBvbGljeUZvcm0gPSB1c2VEcmFmdEZvcm0oZWRpdG9yLmRpcnR5KTtcclxuICAgIGNvbnN0IGRldmljZVJlZ2lzdGVyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHNldEVycm9yKG51bGwpO1xyXG4gICAgICAgIHNldFBlbmRpbmcodHJ1ZSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKF9fTU9DS19fKSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCByZWdpc3Rlci5leGVjdXRlKHsgYm9keTogeyBkZXZpY2VOYW1lOiBkZXZpY2VOYW1lLnRyaW0oKSwgZW5kcG9pbnQ6ICdodHRwczovL2V4YW1wbGUudGVzdC9tb2NrLXB1c2gnLCBwMjU2ZGg6ICdzeW50aGV0aWMtZGV2aWNlLXB1YmxpYy1rZXknLCBhdXRoOiAnc3ludGhldGljLWRldmljZS1hdXRoJyB9IH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGFzc2VydFB1c2hDYXBhYmlsaXR5KHsgc2VjdXJlQ29udGV4dDogd2luZG93LmlzU2VjdXJlQ29udGV4dCwgc2VydmljZVdvcmtlcjogJ3NlcnZpY2VXb3JrZXInIGluIG5hdmlnYXRvciwgcHVzaE1hbmFnZXI6ICdQdXNoTWFuYWdlcicgaW4gd2luZG93LCBub3RpZmljYXRpb246ICdOb3RpZmljYXRpb24nIGluIHdpbmRvdyB9KTtcclxuICAgICAgICAgICAgY29uc3Qga2V5ID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfV0VCX1BVU0hfUFVCTElDX0tFWTtcclxuICAgICAgICAgICAgaWYgKCFrZXkpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NoxrBhIGPDsyBraMOzYSBWQVBJRCBjw7RuZyBraGFpIHThu6sgYmFja2VuZCB0cm9uZyBWSVRFX1dFQl9QVVNIX1BVQkxJQ19LRVkuJyk7XHJcbiAgICAgICAgICAgIGFzc2VydFB1c2hQZXJtaXNzaW9uR3JhbnRlZChhd2FpdCBOb3RpZmljYXRpb24ucmVxdWVzdFBlcm1pc3Npb24oKSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHNlcnZpY2UgPSBhd2FpdCBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5yZWdpc3RlcignL2FwcC1zdy5qcycsIHsgc2NvcGU6ICcvJyB9KTtcclxuICAgICAgICAgICAgYXdhaXQgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIucmVhZHk7XHJcbiAgICAgICAgICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IGF3YWl0IHNlcnZpY2UucHVzaE1hbmFnZXIuZ2V0U3Vic2NyaXB0aW9uKCkgfHwgYXdhaXQgc2VydmljZS5wdXNoTWFuYWdlci5zdWJzY3JpYmUoeyB1c2VyVmlzaWJsZU9ubHk6IHRydWUsIGFwcGxpY2F0aW9uU2VydmVyS2V5OiBiYXNlNjRCeXRlcyhrZXkpIH0pO1xyXG4gICAgICAgICAgICBjb25zdCBqc29uID0gc3Vic2NyaXB0aW9uLnRvSlNPTigpO1xyXG4gICAgICAgICAgICBpZiAoIWpzb24uZW5kcG9pbnQgfHwgIWpzb24ua2V5cz8ucDI1NmRoIHx8ICFqc29uLmtleXMuYXV0aClcclxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignxJDEg25nIGvDvSBQdXNoIGtow7RuZyB0cuG6oyDEkeG7pyBk4buvIGxp4buHdS4nKTtcclxuICAgICAgICAgICAgYXdhaXQgcmVnaXN0ZXIuZXhlY3V0ZSh7IGJvZHk6IHsgZGV2aWNlTmFtZTogZGV2aWNlTmFtZS50cmltKCksIGVuZHBvaW50OiBqc29uLmVuZHBvaW50LCBwMjU2ZGg6IGpzb24ua2V5cy5wMjU2ZGgsIGF1dGg6IGpzb24ua2V5cy5hdXRoIH0gfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUgOiBuZXcgRXJyb3IoJ0tow7RuZyDEkcSDbmcga8O9IMSRxrDhu6NjIHRoaeG6v3QgYuG7iycpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldFBlbmRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBjb25zdCB0ZWxlZ3JhbUF2YWlsYWJsZSA9ICEhZGV2aWNlcy5kYXRhPy5kYXRhLnNvbWUoZCA9PiBkLmNoYW5uZWwgPT09ICd0ZWxlZ3JhbScgJiYgZC5zdGF0dXMgPT09ICdhY3RpdmUnKTtcclxuICAgIGNvbnN0IHRlbGVncmFtQXZhaWxhYmlsaXR5UGVuZGluZyA9ICF0ZWxlZ3JhbUF2YWlsYWJsZSAmJiAoIWRldmljZXMuZGF0YSB8fCBkZXZpY2VzLmhhc01vcmUgfHwgZGV2aWNlcy5pc0Vycm9yKTtcclxuICAgIGNvbnN0IHBvbGljeUVycm9yID0gdmFsaWRhdGVQb2xpY3koeyBlbmFibGVkLCBtaW51dGVzLCBtYXgsIHByaW1hcnksIHF1aWV0LCBxdWlldFN0YXJ0LCBxdWlldEVuZCwgY2hhbm5lbCwgdGVsZWdyYW1BdmFpbGFibGUgfSk7XHJcbiAgICBjb25zdCBzYXZlUG9saWN5ID0gYXN5bmMgKCkgPT4geyBpZiAoIXBvbGljeS5kYXRhIHx8IHBvbGljeUVycm9yKVxyXG4gICAgICAgIHJldHVybjsgY29uc3QgcHJlcGFyZWQgPSBlZGl0b3IucHJlcGFyZSgpOyBpZiAoIXByZXBhcmVkKSByZXR1cm47XHJcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkID0geyBlbmFibGVkLCBtaW51dGVzLCBtYXgsIHF1aWV0LCBxdWlldFN0YXJ0LCBxdWlldEVuZCwgcHJpbWFyeSwgZmFsbGJhY2ssIGNoYW5uZWwsIHVyZ2VudCB9O1xyXG4gICAgICAgIGNvbnN0IGJvZHk6IE5vdGlmaWNhdGlvblBvbGljeVdyaXRlID0ge1xyXG4gICAgICAgIGV4cGVjdGVkVmVyc2lvbjogcHJlcGFyZWQudmVyc2lvbiwgZW5hYmxlZCwgdGltZXpvbmU6IHBvbGljeS5kYXRhLmRhdGEudGltZXpvbmUsIHF1aWV0SG91cnM6IHF1aWV0ID8geyBzdGFydDogcXVpZXRTdGFydCwgZW5kOiBxdWlldEVuZCB9IDogbnVsbCwgcmVtaW5kQWZ0ZXJNaW51dGVzOiBtaW51dGVzLnRyaW0oKSA/IE51bWJlcihtaW51dGVzKSA6IG51bGwsIG1heFJlbWluZGVyczogTnVtYmVyKG1heCksIHByaW1hcnlVc2VySWRzOiBwcmltYXJ5LCBmYWxsYmFja1VzZXJJZHM6IGZhbGxiYWNrLCBmYWxsYmFja0NoYW5uZWw6IGNoYW5uZWwsIHVyZ2VudE1heUJ5cGFzc1F1aWV0SG91cnM6IHVyZ2VudFxyXG4gICAgfTsgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzYXZlLmV4ZWN1dGUoeyBib2R5IH0pO1xyXG4gICAgICAgIGVkaXRvci5jb21taXR0ZWQobm90aWZpY2F0aW9uU25hcHNob3QocmVzdWx0LmRhdGEpLCBzdWJtaXR0ZWQpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGVkaXRvci5mYWlsZWQoZXJyb3IpOyB9IH07XHJcbiAgICBjb25zdCBrbm93blVzZXJzID0gbWVtYmVycy5kYXRhPy5kYXRhLmZpbHRlcihtID0+IG0uc3RhdHVzID09PSAnYWN0aXZlJykubWFwKG0gPT4gKHsgaWQ6IG0udXNlcklkLCBsYWJlbDogbS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/ICdC4bqhbicgOiBtLnVzZXJJZCB9KSkgfHwgW3sgaWQ6IHNlc3Npb24udXNlci5pZCwgbGFiZWw6ICdC4bqhbicgfV07XHJcbiAgICBjb25zdCBzZWxlY3RlZFVzZXJJZHMgPSBbLi4ubmV3IFNldChbLi4ucHJpbWFyeSwgLi4uZmFsbGJhY2tdKV07XHJcbiAgICBjb25zdCByZXRhaW5lZFVzZXJzID0gc2VsZWN0ZWRVc2VySWRzLmZpbHRlcihpZCA9PiAha25vd25Vc2Vycy5zb21lKHVzZXIgPT4gdXNlci5pZCA9PT0gaWQpKS5tYXAoaWQgPT4gKHsgaWQsIGxhYmVsOiBgJHtpZH0gKMSRw6MgbMawdSwgY2jGsGEgdOG6o2kgdGjDoG5oIHZpw6puKWAgfSkpO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCLEkGnhu4duIHRob+G6oWkgJiBs4buLY2ggdHLhu7FjXCIgc3VidGl0bGU9XCJUaGnhur90IGLhu4ssIHjDoWMgbmjhuq1uIG5o4bqtbiB2aeG7h2MsIGdp4budIHnDqm4gbOG6t25nIHbDoCBuZ8aw4budaSBk4buxIHBow7JuZy5cIi8+PFBhZ2VTZWN0aW9ucz48U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMS4yZnIgMWZyJyB9fSBzaHJpbmtDaGlsZHJlbiBnZW9tZXRyeT17e21pbldpZHRoOiAwfX0+PFBhZ2VTZWN0aW9ucyBzaHJpbmtDaGlsZHJlbiBnZW9tZXRyeT17e21pbldpZHRoOiAwfX0+PFBhbmVsIHRpdGxlPVwiVGhp4bq/dCBi4buLIG5o4bqtbiB0aMO0bmcgYsOhb1wiIGJvZHlNb2RlPVwiaW5zZXRcIj48U3VyZmFjZUNvbnRlbnQgPjxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3IgfHwgcmVnaXN0ZXIuZXJyb3IgfHwgdGVzdC5lcnJvciB8fCBwYWlyLmVycm9yfS8+e2RldmljZVRlc3RNZXNzYWdlICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj57ZGV2aWNlVGVzdE1lc3NhZ2V9PC9BbGVydD59PFN1cmZhY2VDb250ZW50IGRpcmVjdGlvbj1cInJvd1wiICBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+PFNtYXJ0cGhvbmVSb3VuZGVkIHN4PXt7IGZvbnRTaXplOiB0b2tlbnMuaWNvblNpemVzLmRldmljZVByZXZpZXcsIGNvbG9yOiAncHJpbWFyeS5tYWluJyB9fS8+PFR5cG9ncmFwaHk+VGjDtG5nIGLDoW8gdOG7kWkgZ2nhuqNuIHRyw6puIG3DoG4gaMOsbmgga2jDs2E7IHhlbSDEkeG7i2EgY2jhu4kga2jDoWNoIHNhdSBraGkgxJHEg25nIG5o4bqtcC48L1R5cG9ncmFwaHk+PC9TdXJmYWNlQ29udGVudD48VGV4dEZpZWxkIGxhYmVsPVwiVMOqbiB0aGnhur90IGLhu4tcIiB2YWx1ZT17ZGV2aWNlTmFtZX0gb25DaGFuZ2U9e2UgPT4gc2V0RGV2aWNlTmFtZShsaW1pdENvZGVQb2ludHMoZS50YXJnZXQudmFsdWUsIDEyMCkpfSAvPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibm90aWZpY2F0aW9ucy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17cGVuZGluZ30gZGlzYWJsZWQ9eyFkZXZpY2VOYW1lLnRyaW0oKX0gb25DbGljaz17KCkgPT4gdm9pZCBkZXZpY2VSZWdpc3RlcigpfT57X19NT0NLX18gPyAnTcO0IHBo4buPbmcgxJHEg25nIGvDvSB0aGnhur90IGLhu4snIDogJ0Lhuq10IHRow7RuZyBiw6FvIHRyw6puIHRoaeG6v3QgYuG7iyBuw6B5J308L011dGF0aW9uQnV0dG9uPntfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+TcO0IHBo4buPbmcga2jDtG5nIHnDqnUgY+G6p3UgcXV54buBbiBo4buHIMSRaeG7gXUgaMOgbmgsIGtow7RuZyDEkcSDbmcga8O9IFB1c2ggdGjhuq10IHbDoCBnaeG7ryB0aGnhur90IGLhu4sg4bufIHRy4bqhbmcgdGjDoWkgY2jhu50geMOhYyBtaW5oLjwvQWxlcnQ+fTwvU3VyZmFjZUNvbnRlbnQ+e2RldmljZXMuaXNFcnJvciAmJiAhZGV2aWNlcy5kYXRhID8gbnVsbCA6IDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXZpY2VzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57ZGV2aWNlcy5kYXRhICYmIDxEYXRhVGFibGUgbGFiZWw9XCJUaGnhur90IGLhu4sgbmjhuq1uIHRow7RuZyBiw6FvXCIgcm93cz17ZGV2aWNlcy5kYXRhLmRhdGF9IHJvd0tleT17ZCA9PiBkLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICduYW1lJywgbGFiZWw6ICdUaGnhur90IGLhu4snLCByZW5kZXI6IGQgPT4gZC5kZXZpY2VOYW1lIH0sIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGQgPT4gPFN0YXR1cyB2YWx1ZT17ZC5zdGF0dXN9Lz4gfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ2FjdGlvbnMnLCBsYWJlbDogJycsIHJlbmRlcjogZCA9PiA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgZmxleFdyYXA9XCJ3cmFwXCI+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJub3RpZmljYXRpb25zLm1hbmFnZVwiIGRpc2FibGVkPXtkLnN0YXR1cyA9PT0gJ3Jldm9rZWQnfSBidXN5PXt0ZXN0LnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHsgYXdhaXQgdGVzdC5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBkLmlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBkLnZlcnNpb24gfSB9KTsgc2V0RGV2aWNlVGVzdE1lc3NhZ2UoX19NT0NLX18gPyAnTcO0IHBo4buPbmc6IGNoxrBhIGfhu61pIFB1c2ggdGjhuq10OyB0aGnhur90IGLhu4sgduG6q24gY2jhu50geMOhYyBtaW5oLicgOiAnWcOqdSBj4bqndSBraeG7g20gdHJhIMSRw6MgxJHGsOG7o2MgdGnhur9wIG5o4bqtbjsgeGVtIHRy4bqhbmcgdGjDoWkgYmFja2VuZCB0csaw4bubYyBraGkga+G6v3QgbHXhuq1uIMSRw6MgZ+G7rWkuJyk7IH0gY2F0Y2ggeyBzZXREZXZpY2VUZXN0TWVzc2FnZShfX01PQ0tfXyA/ICdNw7QgcGjhu49uZzoga2jDtG5nIGfhu61pIFB1c2ggdGjhuq10OyBraeG7g20gdHJhIGLhu4sgdOG7qyBjaOG7kWkgdsOgIHRy4bqhbmcgdGjDoWkgdGhp4bq/dCBi4buLIGtow7RuZyDEkeG7lWkuJyA6ICcnKTsgfSB9fT57X19NT0NLX18gPyAnS2nhu4NtIHRyYSBtw7QgcGjhu49uZycgOiAnR+G7rWkgdGjhu60nfTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJub3RpZmljYXRpb25zLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBkaXNhYmxlZD17ZC5zdGF0dXMgPT09ICdyZXZva2VkJ30gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoZCl9PlRodSBo4buTaTwvTXV0YXRpb25CdXR0b24+PC9TdGFjaz5cclxuICAgICAgICB9XHJcbiAgICBdfS8+fTwvUXVlcnlTdGF0ZT59PExvb2t1cExvYWRNb3JlIGxhYmVsPVwidGhp4bq/dCBi4buLXCIgbG9hZGVkQ291bnQ9e2RldmljZXMubG9hZGVkQ291bnR9IGhhc01vcmU9e2RldmljZXMuaGFzTW9yZX0gYnVzeT17ZGV2aWNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtkZXZpY2VzLmxvYWRNb3JlfS8+e2RldmljZXMuaXNFcnJvciAmJiA8U3VyZmFjZUNvbnRlbnQgPjxFcnJvck5vdGljZSBlcnJvcj17ZGV2aWNlcy5lcnJvcn0vPjxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChkZXZpY2VzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gZGV2aWNlcy5sb2FkTW9yZSgpIDogZGV2aWNlcy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIHPDoWNoIHRoaeG6v3QgYuG7izwvQnV0dG9uPjwvU3VyZmFjZUNvbnRlbnQ+fTwvUGFuZWw+PFBhbmVsIHRpdGxlPVwiVGVsZWdyYW0gZOG7sSBwaMOybmdcIiBib2R5TW9kZT1cImluc2V0XCI+PFN1cmZhY2VDb250ZW50ID48VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+Q2jhu4kgbGnDqm4ga+G6v3QgcXVhIG3DoyBt4buZdCBs4bqnbi4gS2jDtG5nIGTDoW4gYm90IHRva2VuIHbDoG8gdHLDrG5oIGR1eeG7h3QuPC9UeXBvZ3JhcGh5PjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibm90aWZpY2F0aW9ucy5tYW5hZ2VcIiB2YXJpYW50PVwib3V0bGluZWRcIiBidXN5PXtwYWlyLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcclxuICAgICAgICBjb25zdCByID0gYXdhaXQgcGFpci5leGVjdXRlKCk7XHJcbiAgICAgICAgc2V0UGFpcmluZyhyLmRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+VOG6oW8gbcOjIGxpw6puIGvhur90PC9NdXRhdGlvbkJ1dHRvbj57cGFpcmluZyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e19fTU9DS19fID8gJ03DoyBtaW5oIGjhu41hLCBraMO0bmcgZMO5bmcgxJHhu4MgbGnDqm4ga+G6v3QgdGjhuq10LiAnIDogJyd9Qm90OiB7cGFpcmluZy5ib3RVc2VybmFtZX08YnIgLz5Nw6M6IHtwYWlyaW5nLnBhaXJpbmdDb2RlfTxiciAvPkjhur90IGjhuqFuIHtkYXRlVGltZShwYWlyaW5nLmV4cGlyZXNBdCwgc2hvcC50aW1lem9uZSl9PC9BbGVydD59PC9TdXJmYWNlQ29udGVudD48L1BhbmVsPjwvUGFnZVNlY3Rpb25zPjxQYW5lbCB0aXRsZT1cIlF1eSB04bqvYyBuaOG6rW4gdsOgIG5o4bqvYyB2aeG7h2NcIiBib2R5TW9kZT1cImluc2V0XCI+PFF1ZXJ5U3RhdGUgcXVlcnk9e3BvbGljeX0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+PEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIHJlZj17cG9saWN5Rm9ybX0gb25TdWJtaXQ9e2V2ZW50ID0+IHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgdm9pZCBzYXZlUG9saWN5KCk7IH19PjxFcnJvck5vdGljZSBlcnJvcj17c2F2ZS5lcnJvcn0vPjxEcmFmdENvbmZsaWN0IGVkaXRvcj17ZWRpdG9yfSBsYWJlbHM9e3sgZW5hYmxlZDogJ0Lhuq10IHF1eSB04bqvYycsIG1pbnV0ZXM6ICdOaOG6r2Mgc2F1IChwaMO6dCknLCBtYXg6ICdT4buRIGzhuqduIG5o4bqvYycsIHF1aWV0OiAnR2nhu50gecOqbiBs4bq3bmcnLCBxdWlldFN0YXJ0OiAnR2nhu50gYuG6r3QgxJHhuqd1JywgcXVpZXRFbmQ6ICdHaeG7nSBr4bq/dCB0aMO6YycsIHByaW1hcnk6ICdOZ8aw4budaSBuaOG6rW4gY2jDrW5oJywgZmFsbGJhY2s6ICdOZ8aw4budaSBk4buxIHBow7JuZycsIGNoYW5uZWw6ICdLw6puaCBk4buxIHBow7JuZycsIHVyZ2VudDogJ8avdSB0acOqbiBraOG6qW4nIH19IGJ1c3k9e3NhdmUucGVuZGluZ30vPjxGb3JtQ29udHJvbExhYmVsIGxhYmVsPVwiQuG6rXQgcXV5IHThuq9jIHRow7RuZyBiw6FvXCIgY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e2VuYWJsZWR9IG9uQ2hhbmdlPXtlID0+IHNldEVuYWJsZWQoZS50YXJnZXQuY2hlY2tlZCl9Lz59Lz48VGV4dEZpZWxkIGxhYmVsPVwiTmjhuq9jIHNhdSAocGjDunQpLCDEkeG7gyB0cuG7kW5nIG7hur91IGNoxrBhIGNo4buRdFwiIHZhbHVlPXttaW51dGVzfSBvbkNoYW5nZT17ZSA9PiBzZXRNaW51dGVzKGUudGFyZ2V0LnZhbHVlKX0gdHlwZT1cIm51bWJlclwiIGlucHV0UHJvcHM9e3sgbWluOiAxIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiU+G7kSBs4bqnbiBuaOG6r2MgdOG7kWkgxJFhXCIgdmFsdWU9e21heH0gb25DaGFuZ2U9e2UgPT4gc2V0TWF4KGUudGFyZ2V0LnZhbHVlKX0gdHlwZT1cIm51bWJlclwiIGlucHV0UHJvcHM9e3sgbWluOiAwIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiVMOsbSB0aMOgbmggdmnDqm5cIiB2YWx1ZT17bWVtYmVyU2VhcmNoSW5wdXR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRNZW1iZXJTZWFyY2hJbnB1dChldmVudC50YXJnZXQudmFsdWUpfSBkaXNhYmxlZD17IWNhbk1hbmFnZU1lbWJlcnN9IGhlbHBlclRleHQ9XCJUw6xtIGtp4bq/bSBkw7luZyBxIGPhu6dhIGxpc3RNZW1iZXJzOyBtw6MgbmfGsOG7nWkgbmjhuq1uIMSRw6MgbMawdSBsdcO0biDEkcaw4bujYyBnaeG7ry5cIi8+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJOZ8aw4budaSBuaOG6rW4gY2jDrW5oXCIgdmFsdWU9e3ByaW1hcnl9IHNsb3RQcm9wcz17eyBzZWxlY3Q6IHsgbXVsdGlwbGU6IHRydWUgfSB9fSBvbkNoYW5nZT17ZSA9PiBzZXRQcmltYXJ5KHR5cGVvZiBlLnRhcmdldC52YWx1ZSA9PT0gJ3N0cmluZycgPyBlLnRhcmdldC52YWx1ZS5zcGxpdCgnLCcpIDogZS50YXJnZXQudmFsdWUpfT57Wy4uLnJldGFpbmVkVXNlcnMsIC4uLmtub3duVXNlcnNdLm1hcCh1ID0+IDxNZW51SXRlbSBrZXk9e3UuaWR9IHZhbHVlPXt1LmlkfT57dS5sYWJlbH08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJOZ8aw4budaSBk4buxIHBow7JuZ1wiIHZhbHVlPXtmYWxsYmFja30gc2xvdFByb3BzPXt7IHNlbGVjdDogeyBtdWx0aXBsZTogdHJ1ZSB9IH19IG9uQ2hhbmdlPXtlID0+IHNldEZhbGxiYWNrKHR5cGVvZiBlLnRhcmdldC52YWx1ZSA9PT0gJ3N0cmluZycgPyBlLnRhcmdldC52YWx1ZS5zcGxpdCgnLCcpIDogZS50YXJnZXQudmFsdWUpfT57Wy4uLnJldGFpbmVkVXNlcnMsIC4uLmtub3duVXNlcnNdLm1hcCh1ID0+IDxNZW51SXRlbSBrZXk9e3UuaWR9IHZhbHVlPXt1LmlkfT57dS5sYWJlbH08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwidGjDoG5oIHZpw6puXCIgbG9hZGVkQ291bnQ9e21lbWJlcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e21lbWJlcnMuaGFzTW9yZX0gYnVzeT17bWVtYmVycy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXttZW1iZXJzLmxvYWRNb3JlfS8+e21lbWJlcnMuaXNFcnJvciAmJiA8U3VyZmFjZUNvbnRlbnQgPjxFcnJvck5vdGljZSBlcnJvcj17bWVtYmVycy5lcnJvcn0vPjxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChtZW1iZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gbWVtYmVycy5sb2FkTW9yZSgpIDogbWVtYmVycy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIHPDoWNoIHRow6BuaCB2acOqbjwvQnV0dG9uPjwvU3VyZmFjZUNvbnRlbnQ+fXt0ZWxlZ3JhbUF2YWlsYWJpbGl0eVBlbmRpbmcgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHJvbGU9XCJzdGF0dXNcIj57ZGV2aWNlcy5pc0Vycm9yID8gJ0tow7RuZyB4w6FjIG1pbmggxJHGsOG7o2MgZGFuaCBzw6FjaCB0aGnhur90IGLhu4s7IGjDo3kgdGjhu60gbOG6oWkgdHLGsOG7m2Mga2hpIGvhur90IGx14bqtbiBraMO0bmcgY8OzIFRlbGVncmFtIMSRYW5nIGhv4bqhdCDEkeG7mW5nLicgOiBkZXZpY2VzLmhhc01vcmUgPyAnQ2jGsGEgdOG6o2kgaOG6v3QgdGhp4bq/dCBi4buLOyBow6N5IHThuqNpIHRow6ptIHRyxrDhu5tjIGtoaSBr4bq/dCBsdeG6rW4ga2jDtG5nIGPDsyBUZWxlZ3JhbSDEkWFuZyBob+G6oXQgxJHhu5luZy4nIDogJ8SQYW5nIHThuqNpIGRhbmggc8OhY2ggdGhp4bq/dCBi4buLIMSR4buDIHjDoWMgbWluaCB0cuG6oW5nIHRow6FpIFRlbGVncmFtLid9PC9BbGVydD59PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJLw6puaCBk4buxIHBow7JuZ1wiIHZhbHVlPXtjaGFubmVsfSBvbkNoYW5nZT17ZSA9PiBzZXRDaGFubmVsKGUudGFyZ2V0LnZhbHVlIGFzIHR5cGVvZiBjaGFubmVsKX0+PE1lbnVJdGVtIHZhbHVlPVwibm9uZVwiPkNoxrBhIGLhuq10PC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJ0ZWxlZ3JhbVwiIGRpc2FibGVkPXshdGVsZWdyYW1BdmFpbGFibGV9Pnt0ZWxlZ3JhbUF2YWlsYWJsZSA/ICdUZWxlZ3JhbSDEkcOjIGxpw6puIGvhur90JyA6IHRlbGVncmFtQXZhaWxhYmlsaXR5UGVuZGluZyA/ICdDaMawYSB4w6FjIG1pbmggVGVsZWdyYW0nIDogJ1RlbGVncmFtIChjaMawYSBjw7MgdGhp4bq/dCBi4buLIGFjdGl2ZSknfTwvTWVudUl0ZW0+PC9UZXh0RmllbGQ+e2NoYW5uZWwgPT09ICd0ZWxlZ3JhbScgJiYgIXRlbGVncmFtQXZhaWxhYmxlICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5Nw6MgZ2jDqXAgxJHDtGkgbcO0IHBo4buPbmcga2jDtG5nIGxpw6puIGvhur90IFRlbGVncmFtLiBDaOG7iSBjaOG7jW4ga8OqbmggbsOgeSBraGkgZGFuaCBzw6FjaCBjw7MgdGhp4bq/dCBi4buLIFRlbGVncmFtIGFjdGl2ZS48L0FsZXJ0Pn08Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIkPDsyBnaeG7nSB5w6puIGzhurduZ1wiIGNvbnRyb2w9ezxDaGVja2JveCBjaGVja2VkPXtxdWlldH0gb25DaGFuZ2U9e2UgPT4gc2V0UXVpZXQoZS50YXJnZXQuY2hlY2tlZCl9Lz59Lz57cXVpZXQgJiYgPEZpZWxkR3JvdXAgZGlyZWN0aW9uPXt7IHhzOiBcImNvbHVtblwiLCBzbTogXCJyb3dcIiB9fT48VGV4dEZpZWxkIHR5cGU9XCJ0aW1lXCIgbGFiZWw9XCJU4burXCIgdmFsdWU9e3F1aWV0U3RhcnR9IG9uQ2hhbmdlPXtlID0+IHNldFF1aWV0U3RhcnQoZS50YXJnZXQudmFsdWUpfSBmdWxsV2lkdGgvPjxUZXh0RmllbGQgdHlwZT1cInRpbWVcIiBsYWJlbD1cIsSQ4bq/blwiIHZhbHVlPXtxdWlldEVuZH0gb25DaGFuZ2U9e2UgPT4gc2V0UXVpZXRFbmQoZS50YXJnZXQudmFsdWUpfSBmdWxsV2lkdGgvPjwvRmllbGRHcm91cD59PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj5UaGVvIG3DumkgZ2nhu50ge3Nob3AudGltZXpvbmV9PC9UeXBvZ3JhcGh5PjxGb3JtQ29udHJvbExhYmVsIGxhYmVsPVwiQ2hvIHBow6lwIHRow7RuZyBiw6FvIGto4bqpbiB2xrDhu6N0IGdp4budIHnDqm4gbOG6t25nXCIgY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e3VyZ2VudH0gb25DaGFuZ2U9e2UgPT4gc2V0VXJnZW50KGUudGFyZ2V0LmNoZWNrZWQpfS8+fS8+e3BvbGljeUVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3BvbGljeUVycm9yfTwvQWxlcnQ+fTwvRm9ybUZpZWxkcz48QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwiY29sdW1uXCIgYmVmb3JlR2FwPVwiZm9ybVwiPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibm90aWZpY2F0aW9ucy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17c2F2ZS5wZW5kaW5nfSBkaXNhYmxlZD17IXBvbGljeS5kYXRhIHx8ICEhcG9saWN5RXJyb3IgfHwgc2F2ZS5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHNhdmVQb2xpY3koKX0+TMawdSBxdXkgdOG6r2M8L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+PC9RdWVyeVN0YXRlPjwvUGFuZWw+PC9TZWN0aW9uR3JpZD48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgZGF0YS10ZXN0aWQ9XCJub3RpZmljYXRpb24tcHJvdGVjdGlvbi1ub3RlXCI+Q2jhu5FuZyBn4butaSBs4bq3cCB0aGVvIHPhu7Ega2nhu4duLCBraeG7g20gdHJhIGNhbGxiYWNrLCB0aOG7nWkgaOG6oW4gdG9rZW4gdsOgIGdp4bubaSBo4bqhbiB04buRYyDEkeG7mSBwaOG6o2kgxJHGsOG7o2MgYuG6o28gxJHhuqNtIGLhu59pIGThu4tjaCB24bulLiBC4bqjbiBkZW1vIGtow7RuZyBwaMOhdCB0aMO0bmcgYsOhbyB0aOG6rXQgdsOgIGtow7RuZyB4w6FjIG1pbmggY8OhYyBs4bubcCBi4bqjbyB24buHIHBow61hIG3DoXkgY2jhu6cuPC9BbGVydD48L1BhZ2VTZWN0aW9ucz48Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT1cIlRodSBo4buTaSB0aGnhur90IGLhu4tcIiBjb25maXJtTGFiZWw9XCJUaHUgaOG7k2kgdGhp4bq/dCBi4buLXCIgZGVzY3JpcHRpb249e2BUaGnhur90IGLhu4sgJHtzZWxlY3RlZD8uZGV2aWNlTmFtZSB8fCBcIlwifSAoJHtzZWxlY3RlZD8uaWQgfHwgXCJcIn0pOiBk4burbmcgdGjDtG5nIGLDoW8gbeG7m2kgxJHhur9uIMSRxINuZyBrw70gbsOgeS4gVGjDtG5nIGLDoW8gxJHDoyDEkcaw4bujYyBrw6puaCB0aeG6v3Agbmjhuq1uIGtow7RuZyB0aOG7gyB0aHUgaOG7k2kuYH0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGJ1c3k9e3Jldm9rZS5wZW5kaW5nfSBlcnJvcj17cmV2b2tlLmVycm9yfSBvbkNvbmZpcm09eygpID0+IHJldm9rZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZD8uaWQgfHwgJycgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkPy52ZXJzaW9uIHx8IDEgfSB9KX0vPjwvPjtcclxufVxyXG5cclxuZnVuY3Rpb24gbm90aWZpY2F0aW9uU25hcHNob3QocG9saWN5OiBOb3RpZmljYXRpb25Qb2xpY3kpIHtcclxuICAgIHJldHVybiB7IHZlcnNpb246IHBvbGljeS52ZXJzaW9uLCB2YWx1ZXM6IHsgZW5hYmxlZDogcG9saWN5LmVuYWJsZWQsIG1pbnV0ZXM6IHBvbGljeS5yZW1pbmRBZnRlck1pbnV0ZXM/LnRvU3RyaW5nKCkgfHwgJycsIG1heDogU3RyaW5nKHBvbGljeS5tYXhSZW1pbmRlcnMpLCBxdWlldDogISFwb2xpY3kucXVpZXRIb3VycywgcXVpZXRTdGFydDogcG9saWN5LnF1aWV0SG91cnM/LnN0YXJ0IHx8ICcyMjowMCcsIHF1aWV0RW5kOiBwb2xpY3kucXVpZXRIb3Vycz8uZW5kIHx8ICcwODowMCcsIHByaW1hcnk6IHBvbGljeS5wcmltYXJ5VXNlcklkcywgZmFsbGJhY2s6IHBvbGljeS5mYWxsYmFja1VzZXJJZHMsIGNoYW5uZWw6IHBvbGljeS5mYWxsYmFja0NoYW5uZWwsIHVyZ2VudDogcG9saWN5LnVyZ2VudE1heUJ5cGFzc1F1aWV0SG91cnMgfSB9O1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2V2aWRlbmNlL2Zyb250ZW5kLWNvbXBsZXRlbmVzcy0yMDI2MTAxMy1hYWY3NGI3L2NsZWFuLWluc3RhbGwtcjIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9ub3RpZmljYXRpb25zL2luZGV4LnRzeCJ9