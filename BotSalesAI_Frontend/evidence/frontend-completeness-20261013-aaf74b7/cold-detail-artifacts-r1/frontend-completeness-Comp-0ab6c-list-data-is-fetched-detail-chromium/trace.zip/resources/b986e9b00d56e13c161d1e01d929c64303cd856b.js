import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/integrations/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-72764146-749c-4a95-8cd0-4d1f9722ed6f/deps/react_jsx-dev-runtime.js?v=19f17c79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-72764146-749c-4a95-8cd0-4d1f9722ed6f/deps/react.js?v=19f17c79"; const useState = __vite__cjsImport4_react["useState"];
import { capabilityName } from "/src/shared/model/labels.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { Alert, Box, Button, Chip, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/57fc7465e4bf2ba490f6/test-demo/playwright-78864-380df793-f896-4f99-b7a4-048285560cf5-frontend-completeness-72764146-749c-4a95-8cd0-4d1f9722ed6f/deps/@mui_material.js?v=e636be89";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { ConfirmDialog, DetailLine, EditDialog, Empty, ErrorNotice, MutationButton, PageHeader, Panel, QueryState, RouteLink, Status } from "/src/shared/ui/components.tsx";
function authorize(url) {
  const target = new URL(url, location.origin);
  if (target.protocol !== "https:" && !(__MOCK__ && target.origin === location.origin))
    throw new Error("Đường dẫn xác thực không dùng HTTPS.");
  location.assign(target.href);
}
export function ChannelsPage() {
  _s();
  const { shop } = useScope();
  const list = useApi("listChannels");
  const [detailId, setDetailId] = useState("");
  const detail = useApi("getChannel", { path: { channelId: detailId } }, Boolean(detailId));
  const connect = useCommand("beginChannelConnect", []), reconnect = useCommand("reconnectChannel", []), disconnect = useCommand("disconnectChannel", ["listChannels", "getChannel"]), check = useCommand("checkChannelHealth", ["listChannels", "getChannel"]);
  const [selected, setSelected] = useState(null), [jobId, setJob] = useState(""), [error, setError] = useState(null);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const connectButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", busy: connect.pending, onClick: () => void start(), children: "Kết nối Page" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 41,
    columnNumber: 25
  }, this);
  const start = async (channelId) => {
    setError(null);
    try {
      const body = { returnPath: `/s/${shop.id}/integrations/channels`, channelKind: "facebook_messenger" };
      const r = channelId ? await reconnect.execute({ path: { channelId }, body }) : await connect.execute({ body });
      authorize(r.data.authorizationUrl);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không thể bắt đầu xác thực."));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Kết nối Facebook", subtitle: "Kết nối bằng luồng cấp quyền. Page token chỉ được giữ ở backend.", actions: !isEmpty && connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || connect.error || reconnect.error || check.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 163
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Đây là mô phỏng. Không đăng nhập Facebook và không gửi tin thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 256
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có Page kết nối. Dùng nút bên dưới để bắt đầu.", action: connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 481
    }, this) : /* @__PURE__ */ jsxDEV(PageSections, { children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: __MOCK__ ? /* @__PURE__ */ jsxDEV(Chip, { label: "Mô phỏng, chưa liên kết thật", color: "warning", variant: "outlined" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 686
    }, this) : /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 769
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Page ID", children: c.externalPageId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 803
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Webhook gần nhất", children: dateTime(c.lastWebhookAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 862
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: c.policyVersion || "Chưa xác minh" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 954
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kiểm chính sách lúc", children: dateTime(c.policyVerifiedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 1034
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "surface", afterGap: "notice", children: c.capabilities.map((cap) => /* @__PURE__ */ jsxDEV(Chip, { label: capabilityName(cap), title: cap }, cap, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 1228
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 1132
      }, this),
      c.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: w }, w, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 1325
      }, this)),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(c.id), children: "Chi tiết kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 50,
          columnNumber: 1431
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: check.pending, onClick: async () => {
          try {
            setJob((await check.execute({ path: { channelId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 50,
          columnNumber: 1498
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: reconnect.pending, onClick: () => void start(c.id), children: "Kết nối lại" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 53,
          columnNumber: 70
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setSelected(c), children: "Ngắt kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 53,
          columnNumber: 205
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 50,
        columnNumber: 1402
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 798
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 617
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 575
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 382
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Xem kết quả kiểm tra" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 53,
      columnNumber: 397
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!detailId, title: "Chi tiết kết nối Facebook", onClose: () => setDetailId(""), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(""), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 53,
      columnNumber: 581
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, pendingProfile: "section", children: detail.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tên Page", children: detail.data.data.name }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 55,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Page ID", children: detail.data.data.externalPageId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 55,
        columnNumber: 78
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: detail.data.data.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 56,
        columnNumber: 44
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 56,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Webhook gần nhất", children: dateTime(detail.data.data.lastWebhookAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 56,
        columnNumber: 99
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: detail.data.data.policyVersion || "Chưa xác minh" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 57,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kiểm chính sách lúc", children: dateTime(detail.data.data.policyVerifiedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 57,
        columnNumber: 108
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khả năng", children: detail.data.data.capabilities.map(capabilityName).join(", ") || "Chưa xác minh" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 58,
        columnNumber: 13
      }, this),
      detail.data.data.warnings.map((warning) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: warning }, warning, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 59,
        columnNumber: 57
      }, this))
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 54,
      columnNumber: 77
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 53,
      columnNumber: 476
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: "Ngắt kết nối Page", confirmLabel: "Ngắt kết nối Page", description: `Page ${selected?.name || ""} (${selected?.externalPageId || ""}): dừng gửi mới qua kết nối. Lịch sử đơn hàng và hội thoại được giữ; tin đã tiếp nhận không thể thu hồi.`, requireReason: true, onClose: () => setSelected(null), busy: disconnect.pending, error: disconnect.error, onConfirm: (reason) => disconnect.execute({ path: { channelId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
}
_s(ChannelsPage, "Rmvs9JY2hKblgMESxZV/PkFByBA=", false, function() {
  return [useScope, useApi, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c = ChannelsPage;
export function AIProvidersPage() {
  _s2();
  const { shop } = useScope();
  const list = useApi("listAIConnections"), catalog = useApi("getProviderCatalog");
  const [detailId, setDetailId] = useState("");
  const detail = useApi("getAIConnection", { path: { connectionId: detailId } }, Boolean(detailId));
  const create = useCommand("createAIConnection", ["listAIConnections"]), update = useCommand("updateAIConnection", ["listAIConnections", "getAIConnection"]), remove = useCommand("deleteAIConnection", ["listAIConnections", "getAIConnection"]), test = useCommand("testAIConnection", ["listAIConnections", "getAIConnection"]);
  const [open, setOpen] = useState(false), [editing, setEditing] = useState(null), [name, setName] = useState(""), [provider, setProvider] = useState(""), [model, setModel] = useState(""), [endpoint, setEndpoint] = useState(""), [key, setKey] = useState(""), [formError, setFormError] = useState(null), [deleting, setDeleting] = useState(null), [jobId, setJob] = useState("");
  const descriptor = catalog.data?.data.find((p) => p.providerId === provider);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const addConnectionButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", onClick: () => start(null), children: "Thêm kết nối AI" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 72,
    columnNumber: 31
  }, this);
  const start = (connection) => {
    setEditing(connection);
    setName(connection?.name || "");
    setProvider(connection?.providerId || catalog.data?.data[0]?.providerId || "");
    setModel(connection?.modelId || "");
    setEndpoint(connection?.endpointUrl || "");
    setKey("");
    setFormError(null);
    setOpen(true);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhà cung cấp AI", subtitle: "Mỗi adapter công bố khả năng; không giả định mọi API key có thể thay thế nhau.", actions: !isEmpty && addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: test.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 182
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có kết nối AI. Thêm một kết nối để cấu hình nhà cung cấp.", action: addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 315
    }, this) : /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "minmax(0, 1fr)", lg: list.data?.data.length === 1 ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))" }, children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 643
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Provider / adapter", children: [
        c.providerId,
        " / ",
        c.adapterId
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 677
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Model", children: c.modelId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 759
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khóa", children: c.hasCredential ? `•••• ${c.keyLast4 || ""}` : "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 809
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lần kiểm gần nhất", children: dateTime(c.lastCheckedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 905
      }, this),
      /* @__PURE__ */ jsxDEV(SurfaceContent, { rhythm: "dividedRows", beforeGap: "surface", afterGap: "notice", children: Object.entries(c.capabilities).filter(([k]) => k !== "lastVerifiedAt").map(([k, v]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: capabilityName(k), children: typeof v === "string" ? /* @__PURE__ */ jsxDEV(Status, { value: v, domain: "capability", density: "compact" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 1232
      }, this) : "Chưa xác minh" }, k, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 1161
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 998
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(c.id), children: "Chi tiết kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 74,
          columnNumber: 1370
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", onClick: () => start(c), children: "Sửa / xoay khóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 74,
          columnNumber: 1437
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: test.pending, onClick: async () => {
          try {
            setJob((await test.execute({ path: { connectionId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 74,
          columnNumber: 1543
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setDeleting(c), children: "Xóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 77,
          columnNumber: 70
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 74,
        columnNumber: 1341
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 672
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 585
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 426
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 74,
      columnNumber: 216
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Kết quả kiểm tra kết nối" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 77,
      columnNumber: 252
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!detailId, title: "Chi tiết kết nối AI", onClose: () => setDetailId(""), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDetailId(""), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 78,
      columnNumber: 101
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, pendingProfile: "section", children: detail.data && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tên kết nối", children: detail.data.data.name }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Provider / adapter", children: [
        detail.data.data.providerId,
        " / ",
        detail.data.data.adapterId
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 80,
        columnNumber: 77
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Model", children: detail.data.data.modelId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 81,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: detail.data.data.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 81,
        columnNumber: 105
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 81,
        columnNumber: 74
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khóa", children: detail.data.data.hasCredential ? "•••• " + (detail.data.data.keyLast4 || "") : "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lần kiểm gần nhất", children: dateTime(detail.data.data.lastCheckedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      Object.entries(detail.data.data.capabilities).filter(([key2]) => key2 !== "lastVerifiedAt").map(([key2, value]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: capabilityName(key2), children: typeof value === "string" ? /* @__PURE__ */ jsxDEV(Status, { value, domain: "capability", density: "compact" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 84,
        columnNumber: 201
      }, this) : "Chưa xác minh" }, key2, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 84,
        columnNumber: 122
      }, this))
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 79,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 79,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 78,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: editing ? "Sửa kết nối / xoay khóa" : "Kết nối AI mới", onClose: () => {
      setKey("");
      setFormError(null);
      setOpen(false);
    }, busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !name.trim() || !model.trim() || !editing && (!descriptor || !key) || create.pending || update.pending, onClick: async () => {
      setFormError(null);
      const submittedCredential = key;
      try {
        if (__MOCK__ && submittedCredential && !submittedCredential.startsWith("demo-"))
          throw new Error("Chỉ nhập khóa giả bắt đầu bằng demo- trong bản mô phỏng.");
        if (editing)
          await update.execute({ path: { connectionId: editing.id }, version: editing.version, body: { name: name.trim(), modelId: model.trim(), ...submittedCredential ? { credential: submittedCredential } : {} } });
        else
          await create.execute({ body: { name: name.trim(), providerId: provider, adapterId: descriptor?.adapterId || "", modelId: model.trim(), endpointUrl: endpoint || null, credential: submittedCredential } });
        setOpen(false);
      } catch (e) {
        const message = e instanceof Error ? e.message : "Không lưu được cấu hình kết nối.";
        setFormError(new Error(submittedCredential && message.includes(submittedCredential) ? message.replaceAll(submittedCredential, "[đã ẩn]") : message));
      } finally {
        setKey("");
      }
    }, children: "Lưu cấu hình" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 87,
      columnNumber: 202
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: formError || create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 106,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không nhập khóa thật. Dùng demo-key; request mô phỏng chỉ kiểm tra giao diện, không giữ khóa và không kết nối AI thật." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 121
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên kết nối", value: name, onChange: (e) => setName(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 274
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Provider đã có adapter", value: provider, disabled: !!editing, onChange: (e) => {
          setProvider(e.target.value);
          setModel("");
        }, children: catalog.data?.data.map((p) => /* @__PURE__ */ jsxDEV(MenuItem, { value: p.providerId, children: p.label }, p.providerId, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 542
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 362
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Model ID được adapter hỗ trợ", value: model, onChange: (e) => setModel(e.target.value), helperText: descriptor?.models.map((m) => m.modelId).join(", ") || "Xem catalog từ backend" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 626
        }, this),
        !editing && descriptor?.endpointEditable && /* @__PURE__ */ jsxDEV(TextField, { label: "Endpoint HTTPS được backend cho phép", value: endpoint, onChange: (e) => setEndpoint(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 871
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: editing ? "Khóa mới (để trống để giữ nguyên)" : "Khóa API", type: "password", autoComplete: "new-password", value: key, onChange: (e) => setKey(limitCodePoints(e.target.value, 16384)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 993
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Secret chỉ được gửi theo trường writeOnly của contract. Response và danh sách không trả secret gốc." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 106,
          columnNumber: 1194
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 106,
        columnNumber: 96
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 87,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!deleting, title: "Xóa kết nối AI", confirmLabel: "Xóa kết nối AI", description: `Kết nối AI ${deleting?.name || ""} (${deleting?.id || ""}), model ${deleting?.modelId || ""}: chỉ xóa khi không còn cấu hình đang sử dụng. Không tự chuyển dữ liệu sang nhà cung cấp khác.`, requireReason: true, onClose: () => setDeleting(null), error: remove.error, busy: remove.pending, onConfirm: async () => {
      if (!deleting) return;
      await remove.execute({ path: { connectionId: deleting.id }, version: deleting.version });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 107,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 74,
    columnNumber: 10
  }, this);
}
_s2(AIProvidersPage, "ub/C2MtmzNUqEubW1CMOUnaIZxQ=", false, function() {
  return [useScope, useApi, useApi, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c2 = AIProvidersPage;
var _c, _c2;
$RefreshReg$(_c, "ChannelsPage");
$RefreshReg$(_c2, "AIProvidersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/evidence/frontend-completeness-20261013-aaf74b7/clean-install-r2/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUIwQixTQVNmLFVBVGU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBckIxQixTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxhQUFhQyxzQkFBc0I7QUFDbkYsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVFDLHNCQUFxQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsTUFBTUMsVUFBVUMsaUJBQWlCO0FBRTlELFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUMsU0FBU0MsZUFBZUMsWUFBWUMsWUFBWUMsT0FBT0MsYUFBYUMsZ0JBQWdCQyxZQUFZQyxPQUFPQyxZQUFZQyxXQUFXQyxjQUFjO0FBRTVJLFNBQVNDLFVBQVVDLEtBQWE7QUFBRSxRQUFNQyxTQUFTLElBQUlDLElBQUlGLEtBQUtHLFNBQVNDLE1BQU07QUFBRyxNQUFJSCxPQUFPSSxhQUFhLFlBQVksRUFBRUMsWUFBWUwsT0FBT0csV0FBV0QsU0FBU0M7QUFDekosVUFBTSxJQUFJRyxNQUFNLHNDQUFzQztBQUFHSixXQUFTSyxPQUFPUCxPQUFPUSxJQUFJO0FBQUc7QUFDcEYsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNLEVBQUVDLEtBQUssSUFBSTNCLFNBQVM7QUFDMUIsUUFBTTRCLE9BQU85QixPQUFPLGNBQWM7QUFDbEMsUUFBTSxDQUFDK0IsVUFBVUMsV0FBVyxJQUFJekMsU0FBUyxFQUFFO0FBQzNDLFFBQU0wQyxTQUFTakMsT0FBTyxjQUFjLEVBQUVrQyxNQUFNLEVBQUVDLFdBQVdKLFNBQVMsRUFBRSxHQUFHSyxRQUFRTCxRQUFRLENBQUM7QUFDeEYsUUFBTU0sVUFBVXBDLFdBQVcsdUJBQXVCLEVBQUUsR0FBR3FDLFlBQVlyQyxXQUFXLG9CQUFvQixFQUFFLEdBQUdzQyxhQUFhdEMsV0FBVyxxQkFBcUIsQ0FBQyxnQkFBZ0IsWUFBWSxDQUFDLEdBQUd1QyxRQUFRdkMsV0FBVyxzQkFBc0IsQ0FBQyxnQkFBZ0IsWUFBWSxDQUFDO0FBQzVQLFFBQU0sQ0FBQ3dDLFVBQVVDLFdBQVcsSUFBSW5ELFNBQXlCLElBQUksR0FBRyxDQUFDb0QsT0FBT0MsTUFBTSxJQUFJckQsU0FBUyxFQUFFLEdBQUcsQ0FBQ3NELE9BQU9DLFFBQVEsSUFBSXZELFNBQXVCLElBQUk7QUFDL0ksUUFBTXdELFVBQVUsQ0FBQ2pCLEtBQUtrQixXQUFXbEIsS0FBS21CLE1BQU1BLEtBQUtDLFdBQVc7QUFDNUQsUUFBTUMsZ0JBQWdCLHVCQUFDLGtCQUFlLFlBQVcsdUJBQXNCLFNBQVEsYUFBWSxNQUFNZCxRQUFRZSxTQUFTLFNBQVMsTUFBTSxLQUFLQyxNQUFNLEdBQUcsNEJBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUk7QUFDM0osUUFBTUEsUUFBUSxPQUFPbEIsY0FBdUI7QUFBRVcsYUFBUyxJQUFJO0FBQUcsUUFBSTtBQUM5RCxZQUFNUSxPQUFPLEVBQUVDLFlBQVksTUFBTTFCLEtBQUsyQixFQUFFLDBCQUEwQkMsYUFBYSxxQkFBOEI7QUFDN0csWUFBTUMsSUFBSXZCLFlBQVksTUFBTUcsVUFBVXFCLFFBQVEsRUFBRXpCLE1BQU0sRUFBRUMsVUFBVSxHQUFHbUIsS0FBSyxDQUFDLElBQUksTUFBTWpCLFFBQVFzQixRQUFRLEVBQUVMLEtBQUssQ0FBQztBQUM3R3RDLGdCQUFVMEMsRUFBRVQsS0FBS1csZ0JBQWdCO0FBQUEsSUFDckMsU0FDT0MsR0FBRztBQUNOZixlQUFTZSxhQUFhckMsUUFBUXFDLElBQUksSUFBSXJDLE1BQU0sNkJBQTZCLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQUU7QUFDRixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLG9CQUFtQixVQUFTLG9FQUFtRSxTQUFTLENBQUN1QixXQUFXSSxpQkFBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvSjtBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPTixTQUFTUixRQUFRUSxTQUFTUCxVQUFVTyxTQUFTTCxNQUFNSyxTQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZFO0FBQUEsSUFBR3RCLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSTlCLFNBQVNxRSxPQUFPQyxVQUFVLGdGQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFIO0FBQUEsSUFBUyx1QkFBQyxjQUFXLE9BQU9qQyxNQUFNLGdCQUFlLFdBQVdBLGVBQUttQixNQUFNQSxLQUFLQyxXQUFXLEtBQUssQ0FBQ3BCLEtBQUtrQixVQUFVLHVCQUFDLFNBQU0sTUFBSyx1REFBc0QsUUFBUUcsaUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0YsSUFBSyx1QkFBQyxnQkFBZXJCLGVBQUttQixNQUFNQSxLQUFLZSxJQUFJLENBQUFDLE1BQUssdUJBQUMsU0FBaUIsT0FBT0EsRUFBRUMsTUFBTSxVQUFTLFNBQVEsUUFBUTNDLFdBQVcsdUJBQUMsUUFBSyxPQUFNLGdDQUErQixPQUFNLFdBQVUsU0FBUSxjQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZFLElBQUssdUJBQUMsVUFBTyxPQUFPMEMsRUFBRUUsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixHQUFJLGlDQUFDLE9BQUk7QUFBQSw2QkFBQyxjQUFXLE9BQU0sV0FBV0YsWUFBRUcsa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxvQkFBb0JoRSxtQkFBUzZELEVBQUVJLGVBQWV4QyxLQUFLeUMsUUFBUSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sY0FBY0wsWUFBRU0saUJBQWlCLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sdUJBQXVCbkUsbUJBQVM2RCxFQUFFTyxrQkFBa0IzQyxLQUFLeUMsUUFBUSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFBYSx1QkFBQyxlQUFZLFdBQVUsT0FBTSxXQUFVLFdBQVUsVUFBUyxVQUFVTCxZQUFFUSxhQUFhVCxJQUFJLENBQUFVLFFBQU8sdUJBQUMsUUFBSyxPQUFPbEYsZUFBZWtGLEdBQUcsR0FBRyxPQUFPQSxPQUFVQSxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVELENBQUUsS0FBdko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5SjtBQUFBLE1BQWVULEVBQUVVLFNBQVNYLElBQUksQ0FBQVksTUFBSyx1QkFBQyxTQUFNLFVBQVMsV0FBa0IsSUFBSW5GLFNBQVNxRSxPQUFPQyxVQUFXYSxlQUFsQ0EsR0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRSxDQUFRO0FBQUEsTUFBRSx1QkFBQyxlQUFZLFdBQVUsT0FBTztBQUFBLCtCQUFDLFVBQU8sU0FBUyxNQUFNNUMsWUFBWWlDLEVBQUVULEVBQUUsR0FBRyxnQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFFBQVMsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsTUFBTWhCLE1BQU1ZLFNBQVMsU0FBUyxZQUFZO0FBQUUsY0FBSTtBQUMxaURSLG9CQUFRLE1BQU1KLE1BQU1tQixRQUFRLEVBQUV6QixNQUFNLEVBQUVDLFdBQVc4QixFQUFFVCxHQUFHLEVBQUUsQ0FBQyxHQUFHUCxLQUFLTyxFQUFFO0FBQUEsVUFDdkUsUUFDTTtBQUFBLFVBQUU7QUFBQSxRQUFnQixHQUFHLDRCQUhrN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd0NkM7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixNQUFNbEIsVUFBVWMsU0FBUyxTQUFTLE1BQU0sS0FBS0MsTUFBTVksRUFBRVQsRUFBRSxHQUFHLDJCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsT0FBTSxTQUFRLFNBQVMsTUFBTWQsWUFBWXVCLENBQUMsR0FBRyw0QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFdBSG1rQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR2xqQztBQUFBLFNBSDJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHN2MsS0FIc1NBLEVBQUVULElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdwUixDQUFRLEtBSG1PO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHak8sS0FIaUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdqQjtBQUFBLElBQWNiLFNBQVMsdUJBQUMsYUFBVSxJQUFJLE1BQU1kLEtBQUsyQixFQUFFLFNBQVNiLEtBQUssSUFBSSxvQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLElBQWEsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQ1osVUFBVSxPQUFNLDZCQUE0QixTQUFTLE1BQU1DLFlBQVksRUFBRSxHQUFHLFNBQVMsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLFlBQVksRUFBRSxHQUFHLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDLEdBQy9sQixpQ0FBQyxjQUFXLE9BQU9DLFFBQVEsZ0JBQWUsV0FBV0EsaUJBQU9nQixRQUFRLHVCQUFDLGtCQUNqRTtBQUFBLDZCQUFDLGNBQVcsT0FBTSxZQUFZaEIsaUJBQU9nQixLQUFLQSxLQUFLaUIsUUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFdBQVdqQyxpQkFBT2dCLEtBQUtBLEtBQUttQixrQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzlILHVCQUFDLGNBQVcsT0FBTSxjQUFhLGlDQUFDLFVBQU8sT0FBT25DLE9BQU9nQixLQUFLQSxLQUFLa0IsVUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QyxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sb0JBQW9CL0QsbUJBQVM2QixPQUFPZ0IsS0FBS0EsS0FBS29CLGVBQWV4QyxLQUFLeUMsUUFBUSxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThGO0FBQUEsTUFDbkwsdUJBQUMsY0FBVyxPQUFNLGNBQWNyQyxpQkFBT2dCLEtBQUtBLEtBQUtzQixpQkFBaUIsbUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSx1QkFBdUJuRSxtQkFBUzZCLE9BQU9nQixLQUFLQSxLQUFLdUIsa0JBQWtCM0MsS0FBS3lDLFFBQVEsS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRztBQUFBLE1BQ25NLHVCQUFDLGNBQVcsT0FBTSxZQUFZckMsaUJBQU9nQixLQUFLQSxLQUFLd0IsYUFBYVQsSUFBSXhFLGNBQWMsRUFBRXFGLEtBQUssSUFBSSxLQUFLLG1CQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThHO0FBQUEsTUFDN0c1QyxPQUFPZ0IsS0FBS0EsS0FBSzBCLFNBQVNYLElBQUksQ0FBQWMsWUFBVyx1QkFBQyxTQUFvQixVQUFTLFdBQVdBLHFCQUE3QkEsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlELENBQVE7QUFBQSxTQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTXBFLEtBTkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1rQixLQVB3YjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUTljO0FBQUEsSUFBYSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQ3JDLFVBQVUsT0FBTSxxQkFBb0IsY0FBYSxxQkFBb0IsYUFBYSxRQUFRQSxVQUFVeUIsUUFBUSxFQUFFLEtBQUt6QixVQUFVMkIsa0JBQWtCLEVBQUUsNEdBQTRHLGVBQWEsTUFBQyxTQUFTLE1BQU0xQixZQUFZLElBQUksR0FBRyxNQUFNSCxXQUFXYSxTQUFTLE9BQU9iLFdBQVdNLE9BQU8sV0FBVyxDQUFBa0MsV0FBVXhDLFdBQVdvQixRQUFRLEVBQUV6QixNQUFNLEVBQUVDLFdBQVdNLFVBQVVlLE1BQU0sR0FBRyxHQUFHRixNQUFNLEVBQUUwQixpQkFBaUJ2QyxVQUFVd0MsV0FBVyxHQUFHRixPQUFPLEVBQUUsQ0FBQyxLQUFyZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1Z0I7QUFBQSxPQVg3Z0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVcrZ0I7QUFDMWhCO0FBQUNuRCxHQTdCZUQsY0FBWTtBQUFBLFVBQ1B6QixVQUNKRixRQUVFQSxRQUNDQyxZQUFtREEsWUFBaURBLFlBQXlFQSxVQUFVO0FBQUE7QUFBQSxLQUwzTDBCO0FBOEJULGdCQUFTdUQsa0JBQWtCO0FBQUFDLE1BQUE7QUFDOUIsUUFBTSxFQUFFdEQsS0FBSyxJQUFJM0IsU0FBUztBQUMxQixRQUFNNEIsT0FBTzlCLE9BQU8sbUJBQW1CLEdBQUdvRixVQUFVcEYsT0FBTyxvQkFBb0I7QUFDL0UsUUFBTSxDQUFDK0IsVUFBVUMsV0FBVyxJQUFJekMsU0FBUyxFQUFFO0FBQzNDLFFBQU0wQyxTQUFTakMsT0FBTyxtQkFBbUIsRUFBRWtDLE1BQU0sRUFBRW1ELGNBQWN0RCxTQUFTLEVBQUUsR0FBR0ssUUFBUUwsUUFBUSxDQUFDO0FBQ2hHLFFBQU11RCxTQUFTckYsV0FBVyxzQkFBc0IsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHc0YsU0FBU3RGLFdBQVcsc0JBQXNCLENBQUMscUJBQXFCLGlCQUFpQixDQUFDLEdBQUd1RixTQUFTdkYsV0FBVyxzQkFBc0IsQ0FBQyxxQkFBcUIsaUJBQWlCLENBQUMsR0FBR3dGLE9BQU94RixXQUFXLG9CQUFvQixDQUFDLHFCQUFxQixpQkFBaUIsQ0FBQztBQUNoVSxRQUFNLENBQUN5RixNQUFNQyxPQUFPLElBQUlwRyxTQUFTLEtBQUssR0FBRyxDQUFDcUcsU0FBU0MsVUFBVSxJQUFJdEcsU0FBOEIsSUFBSSxHQUFHLENBQUMyRSxNQUFNNEIsT0FBTyxJQUFJdkcsU0FBUyxFQUFFLEdBQUcsQ0FBQ3dHLFVBQVVDLFdBQVcsSUFBSXpHLFNBQVMsRUFBRSxHQUFHLENBQUMwRyxPQUFPQyxRQUFRLElBQUkzRyxTQUFTLEVBQUUsR0FBRyxDQUFDNEcsVUFBVUMsV0FBVyxJQUFJN0csU0FBUyxFQUFFLEdBQUcsQ0FBQzhHLEtBQUtDLE1BQU0sSUFBSS9HLFNBQVMsRUFBRSxHQUFHLENBQUNnSCxXQUFXQyxZQUFZLElBQUlqSCxTQUF1QixJQUFJLEdBQUcsQ0FBQ2tILFVBQVVDLFdBQVcsSUFBSW5ILFNBQThCLElBQUksR0FBRyxDQUFDb0QsT0FBT0MsTUFBTSxJQUFJckQsU0FBUyxFQUFFO0FBQzVhLFFBQU1vSCxhQUFhdkIsUUFBUW5DLE1BQU1BLEtBQUsyRCxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLGVBQWVmLFFBQVE7QUFDekUsUUFBTWhELFVBQVUsQ0FBQ2pCLEtBQUtrQixXQUFXbEIsS0FBS21CLE1BQU1BLEtBQUtDLFdBQVc7QUFDNUQsUUFBTTZELHNCQUFzQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFRLGFBQVksU0FBUyxNQUFNMUQsTUFBTSxJQUFJLEdBQUcsK0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0g7QUFDNUksUUFBTUEsUUFBUUEsQ0FBQzJELGVBQW9DO0FBQUVuQixlQUFXbUIsVUFBVTtBQUFHbEIsWUFBUWtCLFlBQVk5QyxRQUFRLEVBQUU7QUFBRzhCLGdCQUFZZ0IsWUFBWUYsY0FBYzFCLFFBQVFuQyxNQUFNQSxLQUFLLENBQUMsR0FBRzZELGNBQWMsRUFBRTtBQUFHWixhQUFTYyxZQUFZQyxXQUFXLEVBQUU7QUFBR2IsZ0JBQVlZLFlBQVlFLGVBQWUsRUFBRTtBQUFHWixXQUFPLEVBQUU7QUFBR0UsaUJBQWEsSUFBSTtBQUFHYixZQUFRLElBQUk7QUFBQSxFQUFHO0FBQzlULFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sbUJBQWtCLFVBQVMsa0ZBQWlGLFNBQVMsQ0FBQzVDLFdBQVdnRSx1QkFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SztBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPdEIsS0FBSzVDLFNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxJQUFFLHVCQUFDLGNBQVcsT0FBT2YsTUFBTSxnQkFBZSxXQUFXQSxlQUFLbUIsTUFBTUEsS0FBS0MsV0FBVyxLQUFLLENBQUNwQixLQUFLa0IsVUFBVSx1QkFBQyxTQUFNLE1BQUssa0VBQWlFLFFBQVErRCx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RyxJQUFLLHVCQUFDLGVBQVksU0FBUyxFQUFFSSxJQUFJLGtCQUFrQkMsSUFBSXRGLEtBQUttQixNQUFNQSxLQUFLQyxXQUFXLElBQUksbUJBQW1CLDRCQUE0QixHQUFJcEIsZUFBS21CLE1BQU1BLEtBQUtlLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFpQixPQUFPQSxFQUFFQyxNQUFNLFVBQVMsU0FBUSxRQUFRLHVCQUFDLFVBQU8sT0FBT0QsRUFBRUUsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixHQUFJLGlDQUFDLE9BQUk7QUFBQSw2QkFBQyxjQUFXLE9BQU0sc0JBQXNCRjtBQUFBQSxVQUFFNkM7QUFBQUEsUUFBVztBQUFBLFFBQUk3QyxFQUFFb0Q7QUFBQUEsV0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFNBQVNwRCxZQUFFZ0QsV0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFFBQVFoRCxZQUFFcUQsZ0JBQWdCLFFBQVFyRCxFQUFFc0QsWUFBWSxFQUFFLEtBQUssYUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLHFCQUFxQm5ILG1CQUFTNkQsRUFBRXVELGVBQWUzRixLQUFLeUMsUUFBUSxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsTUFBYSx1QkFBQyxrQkFBZSxRQUFPLGVBQWMsV0FBVSxXQUFVLFVBQVMsVUFBVW1ELGlCQUFPQyxRQUFRekQsRUFBRVEsWUFBWSxFQUFFa0QsT0FBTyxDQUFDLENBQUNDLENBQUMsTUFBTUEsTUFBTSxnQkFBZ0IsRUFBRTVELElBQUksQ0FBQyxDQUFDNEQsR0FBR0MsQ0FBQyxNQUFNLHVCQUFDLGNBQW1CLE9BQU9ySSxlQUFlb0ksQ0FBQyxHQUFJLGlCQUFPQyxNQUFNLFdBQVcsdUJBQUMsVUFBTyxPQUFPQSxHQUFHLFFBQU8sY0FBYSxTQUFRLGFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQsSUFBSyxtQkFBbEhELEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUosQ0FBYSxLQUFuVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFVO0FBQUEsTUFBaUIsdUJBQUMsZUFBWSxXQUFVLE9BQU87QUFBQSwrQkFBQyxVQUFPLFNBQVMsTUFBTTVGLFlBQVlpQyxFQUFFVCxFQUFFLEdBQUcsZ0NBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxRQUFTLHVCQUFDLGtCQUFlLFlBQVcsdUJBQXNCLFNBQVMsTUFBTUgsTUFBTVksQ0FBQyxHQUFHLCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsTUFBTXdCLEtBQUtyQyxTQUFTLFNBQVMsWUFBWTtBQUFFLGNBQUk7QUFDMWxEUixvQkFBUSxNQUFNNkMsS0FBSzlCLFFBQVEsRUFBRXpCLE1BQU0sRUFBRW1ELGNBQWNwQixFQUFFVCxHQUFHLEVBQUUsQ0FBQyxHQUFHUCxLQUFLTyxFQUFFO0FBQUEsVUFDekUsUUFDTTtBQUFBLFVBQUU7QUFBQSxRQUFnQixHQUFHLDRCQUhtK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd2OUM7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixPQUFNLFNBQVEsU0FBUyxNQUFNa0QsWUFBWXpDLENBQUMsR0FBRyxtQkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRztBQUFBLFdBSDBwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR3pvQztBQUFBLFNBSDZlO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHL2QsS0FIcVpBLEVBQUVULElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUduWSxDQUFRLEtBSDhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHNU4sS0FIVztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0k7QUFBQSxJQUFjYixTQUFTLHVCQUFDLGFBQVUsSUFBSSxNQUFNZCxLQUFLMkIsRUFBRSxTQUFTYixLQUFLLElBQUksd0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0U7QUFBQSxJQUN2VCx1QkFBQyxjQUFXLE1BQU0sQ0FBQyxDQUFDWixVQUFVLE9BQU0sdUJBQXNCLFNBQVMsTUFBTUMsWUFBWSxFQUFFLEdBQUcsU0FBUyx1QkFBQyxVQUFPLFNBQVMsTUFBTUEsWUFBWSxFQUFFLEdBQUcsb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEMsR0FDNUksaUNBQUMsY0FBVyxPQUFPQyxRQUFRLGdCQUFlLFdBQVdBLGlCQUFPZ0IsUUFBUSx1QkFBQyxrQkFDakU7QUFBQSw2QkFBQyxjQUFXLE9BQU0sZUFBZWhCLGlCQUFPZ0IsS0FBS0EsS0FBS2lCLFFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxzQkFBc0JqQztBQUFBQSxlQUFPZ0IsS0FBS0EsS0FBSzZEO0FBQUFBLFFBQVc7QUFBQSxRQUFJN0UsT0FBT2dCLEtBQUtBLEtBQUtvRTtBQUFBQSxXQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1HO0FBQUEsTUFDdkssdUJBQUMsY0FBVyxPQUFNLFNBQVNwRixpQkFBT2dCLEtBQUtBLEtBQUtnRSxXQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sY0FBYSxpQ0FBQyxVQUFPLE9BQU9oRixPQUFPZ0IsS0FBS0EsS0FBS2tCLFVBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUMsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3pJLHVCQUFDLGNBQVcsT0FBTSxRQUFRbEMsaUJBQU9nQixLQUFLQSxLQUFLcUUsZ0JBQWdCLFdBQVdyRixPQUFPZ0IsS0FBS0EsS0FBS3NFLFlBQVksTUFBTSxhQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1IO0FBQUEsTUFDbkgsdUJBQUMsY0FBVyxPQUFNLHFCQUFxQm5ILG1CQUFTNkIsT0FBT2dCLEtBQUtBLEtBQUt1RSxlQUFlM0YsS0FBS3lDLFFBQVEsS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRjtBQUFBLE1BQzlGbUQsT0FBT0MsUUFBUXpGLE9BQU9nQixLQUFLQSxLQUFLd0IsWUFBWSxFQUFFa0QsT0FBTyxDQUFDLENBQUN0QixJQUFHLE1BQU1BLFNBQVEsZ0JBQWdCLEVBQUVyQyxJQUFJLENBQUMsQ0FBQ3FDLE1BQUt5QixLQUFLLE1BQU0sdUJBQUMsY0FBcUIsT0FBT3RJLGVBQWU2RyxJQUFHLEdBQUksaUJBQU95QixVQUFVLFdBQVcsdUJBQUMsVUFBTyxPQUFjLFFBQU8sY0FBYSxTQUFRLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQsSUFBSyxtQkFBOUh6QixNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStKLENBQWE7QUFBQSxTQUw3TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTXBFLEtBTkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1rQixLQVByQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsTUFBWSxPQUFPVCxVQUFVLDRCQUE0QixrQkFBa0IsU0FBUyxNQUFNO0FBQUVVLGFBQU8sRUFBRTtBQUFHRSxtQkFBYSxJQUFJO0FBQUdiLGNBQVEsS0FBSztBQUFBLElBQUcsR0FBRyxNQUFNTCxPQUFPbEMsV0FBV21DLE9BQU9uQyxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDYyxLQUFLNkQsS0FBSyxLQUFLLENBQUM5QixNQUFNOEIsS0FBSyxLQUFNLENBQUNuQyxZQUFZLENBQUNlLGNBQWMsQ0FBQ04sUUFBU2YsT0FBT2xDLFdBQVdtQyxPQUFPbkMsU0FBUyxTQUFTLFlBQVk7QUFDMVdvRCxtQkFBYSxJQUFJO0FBQ2pCLFlBQU13QixzQkFBc0IzQjtBQUM1QixVQUFJO0FBQ0EsWUFBSTlFLFlBQVl5Ryx1QkFBdUIsQ0FBQ0Esb0JBQW9CQyxXQUFXLE9BQU87QUFDMUUsZ0JBQU0sSUFBSXpHLE1BQU0sMERBQTBEO0FBQzlFLFlBQUlvRTtBQUNBLGdCQUFNTCxPQUFPNUIsUUFBUSxFQUFFekIsTUFBTSxFQUFFbUQsY0FBY08sUUFBUXBDLEdBQUcsR0FBR3lCLFNBQVNXLFFBQVFYLFNBQVMzQixNQUFNLEVBQUVZLE1BQU1BLEtBQUs2RCxLQUFLLEdBQUdkLFNBQVNoQixNQUFNOEIsS0FBSyxHQUFHLEdBQUlDLHNCQUFzQixFQUFFRSxZQUFZRixvQkFBb0IsSUFBSSxDQUFDLEVBQUcsRUFBRSxDQUFDO0FBQUE7QUFFOU0sZ0JBQU0xQyxPQUFPM0IsUUFBUSxFQUFFTCxNQUFNLEVBQUVZLE1BQU1BLEtBQUs2RCxLQUFLLEdBQUdqQixZQUFZZixVQUFVc0IsV0FBV1YsWUFBWVUsYUFBYSxJQUFJSixTQUFTaEIsTUFBTThCLEtBQUssR0FBR2IsYUFBYWYsWUFBWSxNQUFNK0IsWUFBWUYsb0JBQW9CLEVBQUUsQ0FBQztBQUM3TXJDLGdCQUFRLEtBQUs7QUFBQSxNQUNqQixTQUNPOUIsR0FBRztBQUNOLGNBQU1zRSxVQUFVdEUsYUFBYXJDLFFBQVFxQyxFQUFFc0UsVUFBVTtBQUNqRDNCLHFCQUFhLElBQUloRixNQUFNd0csdUJBQXVCRyxRQUFRQyxTQUFTSixtQkFBbUIsSUFBSUcsUUFBUUUsV0FBV0wscUJBQXFCLFNBQVMsSUFBSUcsT0FBTyxDQUFDO0FBQUEsTUFDdkosVUFBQztBQUVHN0IsZUFBTyxFQUFFO0FBQUEsTUFDYjtBQUFBLElBQ0osR0FBRyw0QkFuQnNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQjFMLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9DLGFBQWFqQixPQUFPekMsU0FBUzBDLE9BQU8xQyxTQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFBRSx1QkFBQyxjQUFhdEI7QUFBQUEsb0JBQVksdUJBQUMsU0FBTSxVQUFTLFdBQVUsc0lBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0o7QUFBQSxRQUFTLHVCQUFDLGFBQVUsT0FBTSxlQUFjLE9BQU8yQyxNQUFNLFVBQVUsQ0FBQUwsTUFBS2lDLFFBQVFqQyxFQUFFM0MsT0FBTzRHLEtBQUssS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFFBQUUsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSwwQkFBeUIsT0FBTy9CLFVBQVUsVUFBVSxDQUFDLENBQUNILFNBQVMsVUFBVSxDQUFBL0IsTUFBSztBQUFFbUMsc0JBQVluQyxFQUFFM0MsT0FBTzRHLEtBQUs7QUFBRzVCLG1CQUFTLEVBQUU7QUFBQSxRQUFHLEdBQUlkLGtCQUFRbkMsTUFBTUEsS0FBS2UsSUFBSSxDQUFBNkMsTUFBSyx1QkFBQyxZQUFTLE9BQU9BLEVBQUVDLFlBQWdDRCxZQUFFeUIsU0FBakJ6QixFQUFFQyxZQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJELENBQVcsS0FBelA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyUDtBQUFBLFFBQVksdUJBQUMsYUFBVSxPQUFNLGdDQUErQixPQUFPYixPQUFPLFVBQVUsQ0FBQXBDLE1BQUtxQyxTQUFTckMsRUFBRTNDLE9BQU80RyxLQUFLLEdBQUcsWUFBWW5CLFlBQVk0QixPQUFPdkUsSUFBSSxDQUFBd0UsTUFBS0EsRUFBRXZCLE9BQU8sRUFBRXBDLEtBQUssSUFBSSxLQUFLLDRCQUF4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlNO0FBQUEsUUFBRyxDQUFDZSxXQUFXZSxZQUFZOEIsb0JBQW9CLHVCQUFDLGFBQVUsT0FBTSx3Q0FBdUMsT0FBT3RDLFVBQVUsVUFBVSxDQUFBdEMsTUFBS3VDLFlBQVl2QyxFQUFFM0MsT0FBTzRHLEtBQUssS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSDtBQUFBLFFBQUcsdUJBQUMsYUFBVSxPQUFPbEMsVUFBVSxzQ0FBc0MsWUFBWSxNQUFLLFlBQVcsY0FBYSxnQkFBZSxPQUFPUyxLQUFLLFVBQVUsQ0FBQXhDLE1BQUt5QyxPQUFPbkcsZ0JBQWdCMEQsRUFBRTNDLE9BQU80RyxPQUFPLEtBQUssQ0FBQyxLQUFsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9NO0FBQUEsUUFBRyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxtSEFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBQXZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStyQztBQUFBLFNBbkI1eEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CeXlDO0FBQUEsSUFDenlDLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDckIsVUFBVSxPQUFNLGtCQUFpQixjQUFhLGtCQUFpQixhQUFhLGNBQWNBLFVBQVV2QyxRQUFRLEVBQUUsS0FBS3VDLFVBQVVqRCxNQUFNLEVBQUUsWUFBWWlELFVBQVVRLFdBQVcsRUFBRSxrR0FBa0csZUFBYSxNQUFDLFNBQVMsTUFBTVAsWUFBWSxJQUFJLEdBQUcsT0FBT2xCLE9BQU8zQyxPQUFPLE1BQU0yQyxPQUFPcEMsU0FBUyxXQUFXLFlBQVk7QUFDNVksVUFBSSxDQUFDcUQsU0FBVTtBQUNmLFlBQU1qQixPQUFPN0IsUUFBUSxFQUFFekIsTUFBTSxFQUFFbUQsY0FBY29CLFNBQVNqRCxHQUFHLEdBQUd5QixTQUFTd0IsU0FBU3hCLFFBQVEsQ0FBQztBQUFBLElBQzNGLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdLO0FBQUEsT0FwQ0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DSDtBQUNSO0FBQUNFLElBaERlRCxpQkFBZTtBQUFBLFVBQ1ZoRixVQUNKRixRQUF1Q0EsUUFFckNBLFFBQ0FDLFlBQWtFQSxZQUFxRkEsWUFBbUZBLFVBQVU7QUFBQTtBQUFBLE1BTHZQaUY7QUFBZSxJQUFBd0QsSUFBQUM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIkFjdGlvbkdyb3VwIiwiRm9ybUZpZWxkcyIsIlBhZ2VTZWN0aW9ucyIsIlNlY3Rpb25HcmlkIiwiU3VyZmFjZUNvbnRlbnQiLCJ1c2VTdGF0ZSIsImNhcGFiaWxpdHlOYW1lIiwibGF5b3V0U3giLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIkNoaXAiLCJNZW51SXRlbSIsIlRleHRGaWVsZCIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsImxpbWl0Q29kZVBvaW50cyIsImRhdGVUaW1lIiwiQ29uZmlybURpYWxvZyIsIkRldGFpbExpbmUiLCJFZGl0RGlhbG9nIiwiRW1wdHkiLCJFcnJvck5vdGljZSIsIk11dGF0aW9uQnV0dG9uIiwiUGFnZUhlYWRlciIsIlBhbmVsIiwiUXVlcnlTdGF0ZSIsIlJvdXRlTGluayIsIlN0YXR1cyIsImF1dGhvcml6ZSIsInVybCIsInRhcmdldCIsIlVSTCIsImxvY2F0aW9uIiwib3JpZ2luIiwicHJvdG9jb2wiLCJfX01PQ0tfXyIsIkVycm9yIiwiYXNzaWduIiwiaHJlZiIsIkNoYW5uZWxzUGFnZSIsIl9zIiwic2hvcCIsImxpc3QiLCJkZXRhaWxJZCIsInNldERldGFpbElkIiwiZGV0YWlsIiwicGF0aCIsImNoYW5uZWxJZCIsIkJvb2xlYW4iLCJjb25uZWN0IiwicmVjb25uZWN0IiwiZGlzY29ubmVjdCIsImNoZWNrIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImpvYklkIiwic2V0Sm9iIiwiZXJyb3IiLCJzZXRFcnJvciIsImlzRW1wdHkiLCJpc0Vycm9yIiwiZGF0YSIsImxlbmd0aCIsImNvbm5lY3RCdXR0b24iLCJwZW5kaW5nIiwic3RhcnQiLCJib2R5IiwicmV0dXJuUGF0aCIsImlkIiwiY2hhbm5lbEtpbmQiLCJyIiwiZXhlY3V0ZSIsImF1dGhvcml6YXRpb25VcmwiLCJlIiwibm90aWNlIiwiYWZ0ZXJHYXAiLCJtYXAiLCJjIiwibmFtZSIsInN0YXR1cyIsImV4dGVybmFsUGFnZUlkIiwibGFzdFdlYmhvb2tBdCIsInRpbWV6b25lIiwicG9saWN5VmVyc2lvbiIsInBvbGljeVZlcmlmaWVkQXQiLCJjYXBhYmlsaXRpZXMiLCJjYXAiLCJ3YXJuaW5ncyIsInciLCJqb2luIiwid2FybmluZyIsInJlYXNvbiIsImV4cGVjdGVkVmVyc2lvbiIsInZlcnNpb24iLCJBSVByb3ZpZGVyc1BhZ2UiLCJfczIiLCJjYXRhbG9nIiwiY29ubmVjdGlvbklkIiwiY3JlYXRlIiwidXBkYXRlIiwicmVtb3ZlIiwidGVzdCIsIm9wZW4iLCJzZXRPcGVuIiwiZWRpdGluZyIsInNldEVkaXRpbmciLCJzZXROYW1lIiwicHJvdmlkZXIiLCJzZXRQcm92aWRlciIsIm1vZGVsIiwic2V0TW9kZWwiLCJlbmRwb2ludCIsInNldEVuZHBvaW50Iiwia2V5Iiwic2V0S2V5IiwiZm9ybUVycm9yIiwic2V0Rm9ybUVycm9yIiwiZGVsZXRpbmciLCJzZXREZWxldGluZyIsImRlc2NyaXB0b3IiLCJmaW5kIiwicCIsInByb3ZpZGVySWQiLCJhZGRDb25uZWN0aW9uQnV0dG9uIiwiY29ubmVjdGlvbiIsIm1vZGVsSWQiLCJlbmRwb2ludFVybCIsInhzIiwibGciLCJhZGFwdGVySWQiLCJoYXNDcmVkZW50aWFsIiwia2V5TGFzdDQiLCJsYXN0Q2hlY2tlZEF0IiwiT2JqZWN0IiwiZW50cmllcyIsImZpbHRlciIsImsiLCJ2IiwidmFsdWUiLCJ0cmltIiwic3VibWl0dGVkQ3JlZGVudGlhbCIsInN0YXJ0c1dpdGgiLCJjcmVkZW50aWFsIiwibWVzc2FnZSIsImluY2x1ZGVzIiwicmVwbGFjZUFsbCIsImxhYmVsIiwibW9kZWxzIiwibSIsImVuZHBvaW50RWRpdGFibGUiLCJfYyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQsIFN1cmZhY2VDb250ZW50IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtjYXBhYmlsaXR5TmFtZX0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvbGFiZWxzJztcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2xheW91dCc7XG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIENoaXAsIE1lbnVJdGVtLCBUZXh0RmllbGQgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB0eXBlIHsgQUlDb25uZWN0aW9uLCBDaGFubmVsIH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICcuLi8uLi9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7IHVzZVNjb3BlIH0gZnJvbSAnLi4vLi4vc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IGxpbWl0Q29kZVBvaW50cywgZGF0ZVRpbWUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgQ29uZmlybURpYWxvZywgRGV0YWlsTGluZSwgRWRpdERpYWxvZywgRW1wdHksIEVycm9yTm90aWNlLCBNdXRhdGlvbkJ1dHRvbiwgUGFnZUhlYWRlciwgUGFuZWwsIFF1ZXJ5U3RhdGUsIFJvdXRlTGluaywgU3RhdHVzIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xuLyoqIFRoZSBiYWNrZW5kIHN1cHBsaWVzIHRoZSBwcm92aWRlciBVUkw7IHRoZSBicm93c2VyIHN0aWxsIHJlZnVzZXMgdW5zYWZlIHNjaGVtZXMuICovXG5mdW5jdGlvbiBhdXRob3JpemUodXJsOiBzdHJpbmcpIHsgY29uc3QgdGFyZ2V0ID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLm9yaWdpbik7IGlmICh0YXJnZXQucHJvdG9jb2wgIT09ICdodHRwczonICYmICEoX19NT0NLX18gJiYgdGFyZ2V0Lm9yaWdpbiA9PT0gbG9jYXRpb24ub3JpZ2luKSlcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ8SQxrDhu51uZyBk4bqrbiB4w6FjIHRo4buxYyBraMO0bmcgZMO5bmcgSFRUUFMuJyk7IGxvY2F0aW9uLmFzc2lnbih0YXJnZXQuaHJlZik7IH1cbmV4cG9ydCBmdW5jdGlvbiBDaGFubmVsc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RDaGFubmVscycpO1xuICAgIGNvbnN0IFtkZXRhaWxJZCwgc2V0RGV0YWlsSWRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGRldGFpbCA9IHVzZUFwaSgnZ2V0Q2hhbm5lbCcsIHsgcGF0aDogeyBjaGFubmVsSWQ6IGRldGFpbElkIH0gfSwgQm9vbGVhbihkZXRhaWxJZCkpO1xuICAgIGNvbnN0IGNvbm5lY3QgPSB1c2VDb21tYW5kKCdiZWdpbkNoYW5uZWxDb25uZWN0JywgW10pLCByZWNvbm5lY3QgPSB1c2VDb21tYW5kKCdyZWNvbm5lY3RDaGFubmVsJywgW10pLCBkaXNjb25uZWN0ID0gdXNlQ29tbWFuZCgnZGlzY29ubmVjdENoYW5uZWwnLCBbJ2xpc3RDaGFubmVscycsICdnZXRDaGFubmVsJ10pLCBjaGVjayA9IHVzZUNvbW1hbmQoJ2NoZWNrQ2hhbm5lbEhlYWx0aCcsIFsnbGlzdENoYW5uZWxzJywgJ2dldENoYW5uZWwnXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxDaGFubmVsIHwgbnVsbD4obnVsbCksIFtqb2JJZCwgc2V0Sm9iXSA9IHVzZVN0YXRlKCcnKSwgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGlzRW1wdHkgPSAhbGlzdC5pc0Vycm9yICYmIGxpc3QuZGF0YT8uZGF0YS5sZW5ndGggPT09IDA7XG4gICAgY29uc3QgY29ubmVjdEJ1dHRvbiA9IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtjb25uZWN0LnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnQoKX0+S+G6v3QgbuG7kWkgUGFnZTwvTXV0YXRpb25CdXR0b24+O1xuICAgIGNvbnN0IHN0YXJ0ID0gYXN5bmMgKGNoYW5uZWxJZD86IHN0cmluZykgPT4geyBzZXRFcnJvcihudWxsKTsgdHJ5IHtcbiAgICAgICAgY29uc3QgYm9keSA9IHsgcmV0dXJuUGF0aDogYC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2NoYW5uZWxzYCwgY2hhbm5lbEtpbmQ6ICdmYWNlYm9va19tZXNzZW5nZXInIGFzIGNvbnN0IH07XG4gICAgICAgIGNvbnN0IHIgPSBjaGFubmVsSWQgPyBhd2FpdCByZWNvbm5lY3QuZXhlY3V0ZSh7IHBhdGg6IHsgY2hhbm5lbElkIH0sIGJvZHkgfSkgOiBhd2FpdCBjb25uZWN0LmV4ZWN1dGUoeyBib2R5IH0pO1xuICAgICAgICBhdXRob3JpemUoci5kYXRhLmF1dGhvcml6YXRpb25VcmwpO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgdGjhu4MgYuG6r3QgxJHhuqd1IHjDoWMgdGjhu7FjLicpKTtcbiAgICB9IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJL4bq/dCBu4buRaSBGYWNlYm9va1wiIHN1YnRpdGxlPVwiS+G6v3QgbuG7kWkgYuG6sW5nIGx14buTbmcgY+G6pXAgcXV54buBbi4gUGFnZSB0b2tlbiBjaOG7iSDEkcaw4bujYyBnaeG7ryDhu58gYmFja2VuZC5cIiBhY3Rpb25zPXshaXNFbXB0eSAmJiBjb25uZWN0QnV0dG9ufS8+PEVycm9yTm90aWNlIGVycm9yPXtlcnJvciB8fCBjb25uZWN0LmVycm9yIHx8IHJlY29ubmVjdC5lcnJvciB8fCBjaGVjay5lcnJvcn0vPntfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+xJDDonkgbMOgIG3DtCBwaOG7j25nLiBLaMO0bmcgxJHEg25nIG5o4bqtcCBGYWNlYm9vayB2w6Aga2jDtG5nIGfhu61pIHRpbiB0aOG6rXQuPC9BbGVydD59PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAwICYmICFsaXN0LmlzRXJyb3IgPyA8RW1wdHkgdGV4dD1cIkNoxrBhIGPDsyBQYWdlIGvhur90IG7hu5FpLiBEw7luZyBuw7p0IGLDqm4gZMaw4bubaSDEkeG7gyBi4bqvdCDEkeG6p3UuXCIgYWN0aW9uPXtjb25uZWN0QnV0dG9ufS8+IDogPFBhZ2VTZWN0aW9ucyA+e2xpc3QuZGF0YT8uZGF0YS5tYXAoYyA9PiA8UGFuZWwga2V5PXtjLmlkfSB0aXRsZT17Yy5uYW1lfSBib2R5TW9kZT1cImluc2V0XCIgYWN0aW9uPXtfX01PQ0tfXyA/IDxDaGlwIGxhYmVsPVwiTcO0IHBo4buPbmcsIGNoxrBhIGxpw6puIGvhur90IHRo4bqtdFwiIGNvbG9yPVwid2FybmluZ1wiIHZhcmlhbnQ9XCJvdXRsaW5lZFwiLz4gOiA8U3RhdHVzIHZhbHVlPXtjLnN0YXR1c30vPn0+PEJveD48RGV0YWlsTGluZSBsYWJlbD1cIlBhZ2UgSURcIj57Yy5leHRlcm5hbFBhZ2VJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJXZWJob29rIGfhuqduIG5o4bqldFwiPntkYXRlVGltZShjLmxhc3RXZWJob29rQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPntjLnBvbGljeVZlcnNpb24gfHwgJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiS2nhu4NtIGNow61uaCBzw6FjaCBsw7pjXCI+e2RhdGVUaW1lKGMucG9saWN5VmVyaWZpZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPjxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiBiZWZvcmVHYXA9XCJzdXJmYWNlXCIgYWZ0ZXJHYXA9XCJub3RpY2VcIj57Yy5jYXBhYmlsaXRpZXMubWFwKGNhcCA9PiA8Q2hpcCBsYWJlbD17Y2FwYWJpbGl0eU5hbWUoY2FwKX0gdGl0bGU9e2NhcH0ga2V5PXtjYXB9Lz4pfTwvQWN0aW9uR3JvdXA+e2Mud2FybmluZ3MubWFwKHcgPT4gPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIGtleT17d30gc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+e3d9PC9BbGVydD4pfTxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiA+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXRhaWxJZChjLmlkKX0+Q2hpIHRp4bq/dCBr4bq/dCBu4buRaTwvQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGJ1c3k9e2NoZWNrLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgc2V0Sm9iKChhd2FpdCBjaGVjay5leGVjdXRlKHsgcGF0aDogeyBjaGFubmVsSWQ6IGMuaWQgfSB9KSkuZGF0YS5pZCk7XG4gICAgfVxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19Pktp4buDbSBr4bq/dCBu4buRaTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJpbnRlZ3JhdGlvbnMubWFuYWdlXCIgYnVzeT17cmVjb25uZWN0LnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnQoYy5pZCl9Pkvhur90IG7hu5FpIGzhuqFpPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBjb2xvcj1cImVycm9yXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoYyl9Pk5n4bqvdCBr4bq/dCBu4buRaTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD48L0JveD48L1BhbmVsPil9PC9QYWdlU2VjdGlvbnM+fTwvUXVlcnlTdGF0ZT57am9iSWQgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2pvYklkfWB9PlhlbSBr4bq/dCBxdeG6oyBraeG7g20gdHJhPC9Sb3V0ZUxpbms+fTxFZGl0RGlhbG9nIG9wZW49eyEhZGV0YWlsSWR9IHRpdGxlPVwiQ2hpIHRp4bq/dCBr4bq/dCBu4buRaSBGYWNlYm9va1wiIG9uQ2xvc2U9eygpID0+IHNldERldGFpbElkKCcnKX0gYWN0aW9ucz17PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXRhaWxJZCgnJyl9PsSQw7NuZzwvQnV0dG9uPn0+XG4gICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntkZXRhaWwuZGF0YSAmJiA8U3VyZmFjZUNvbnRlbnQ+XG4gICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlTDqm4gUGFnZVwiPntkZXRhaWwuZGF0YS5kYXRhLm5hbWV9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiUGFnZSBJRFwiPntkZXRhaWwuZGF0YS5kYXRhLmV4dGVybmFsUGFnZUlkfTwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiVHLhuqFuZyB0aMOhaVwiPjxTdGF0dXMgdmFsdWU9e2RldGFpbC5kYXRhLmRhdGEuc3RhdHVzfS8+PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiV2ViaG9vayBn4bqnbiBuaOG6pXRcIj57ZGF0ZVRpbWUoZGV0YWlsLmRhdGEuZGF0YS5sYXN0V2ViaG9va0F0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+XG4gICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPntkZXRhaWwuZGF0YS5kYXRhLnBvbGljeVZlcnNpb24gfHwgJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiS2nhu4NtIGNow61uaCBzw6FjaCBsw7pjXCI+e2RhdGVUaW1lKGRldGFpbC5kYXRhLmRhdGEucG9saWN5VmVyaWZpZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLaOG6oyBuxINuZ1wiPntkZXRhaWwuZGF0YS5kYXRhLmNhcGFiaWxpdGllcy5tYXAoY2FwYWJpbGl0eU5hbWUpLmpvaW4oJywgJykgfHwgJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAge2RldGFpbC5kYXRhLmRhdGEud2FybmluZ3MubWFwKHdhcm5pbmcgPT4gPEFsZXJ0IGtleT17d2FybmluZ30gc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+e3dhcm5pbmd9PC9BbGVydD4pfVxuICAgICAgICA8L1N1cmZhY2VDb250ZW50Pn08L1F1ZXJ5U3RhdGU+XG4gICAgPC9FZGl0RGlhbG9nPjxDb25maXJtRGlhbG9nIG9wZW49eyEhc2VsZWN0ZWR9IHRpdGxlPVwiTmfhuq90IGvhur90IG7hu5FpIFBhZ2VcIiBjb25maXJtTGFiZWw9XCJOZ+G6r3Qga+G6v3QgbuG7kWkgUGFnZVwiIGRlc2NyaXB0aW9uPXtgUGFnZSAke3NlbGVjdGVkPy5uYW1lIHx8IFwiXCJ9ICgke3NlbGVjdGVkPy5leHRlcm5hbFBhZ2VJZCB8fCBcIlwifSk6IGThu6tuZyBn4butaSBt4bubaSBxdWEga+G6v3QgbuG7kWkuIEzhu4tjaCBz4butIMSRxqFuIGjDoG5nIHbDoCBo4buZaSB0aG/huqFpIMSRxrDhu6NjIGdp4buvOyB0aW4gxJHDoyB0aeG6v3Agbmjhuq1uIGtow7RuZyB0aOG7gyB0aHUgaOG7k2kuYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17ZGlzY29ubmVjdC5wZW5kaW5nfSBlcnJvcj17ZGlzY29ubmVjdC5lcnJvcn0gb25Db25maXJtPXtyZWFzb24gPT4gZGlzY29ubmVjdC5leGVjdXRlKHsgcGF0aDogeyBjaGFubmVsSWQ6IHNlbGVjdGVkPy5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LnZlcnNpb24gfHwgMSwgcmVhc29uIH0gfSl9Lz48Lz47XG59XG5leHBvcnQgZnVuY3Rpb24gQUlQcm92aWRlcnNQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0QUlDb25uZWN0aW9ucycpLCBjYXRhbG9nID0gdXNlQXBpKCdnZXRQcm92aWRlckNhdGFsb2cnKTtcbiAgICBjb25zdCBbZGV0YWlsSWQsIHNldERldGFpbElkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldEFJQ29ubmVjdGlvbicsIHsgcGF0aDogeyBjb25uZWN0aW9uSWQ6IGRldGFpbElkIH0gfSwgQm9vbGVhbihkZXRhaWxJZCkpO1xuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnXSksIHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZUFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnLCAnZ2V0QUlDb25uZWN0aW9uJ10pLCByZW1vdmUgPSB1c2VDb21tYW5kKCdkZWxldGVBSUNvbm5lY3Rpb24nLCBbJ2xpc3RBSUNvbm5lY3Rpb25zJywgJ2dldEFJQ29ubmVjdGlvbiddKSwgdGVzdCA9IHVzZUNvbW1hbmQoJ3Rlc3RBSUNvbm5lY3Rpb24nLCBbJ2xpc3RBSUNvbm5lY3Rpb25zJywgJ2dldEFJQ29ubmVjdGlvbiddKTtcbiAgICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSksIFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPEFJQ29ubmVjdGlvbiB8IG51bGw+KG51bGwpLCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJyksIFtwcm92aWRlciwgc2V0UHJvdmlkZXJdID0gdXNlU3RhdGUoJycpLCBbbW9kZWwsIHNldE1vZGVsXSA9IHVzZVN0YXRlKCcnKSwgW2VuZHBvaW50LCBzZXRFbmRwb2ludF0gPSB1c2VTdGF0ZSgnJyksIFtrZXksIHNldEtleV0gPSB1c2VTdGF0ZSgnJyksIFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpLCBbZGVsZXRpbmcsIHNldERlbGV0aW5nXSA9IHVzZVN0YXRlPEFJQ29ubmVjdGlvbiB8IG51bGw+KG51bGwpLCBbam9iSWQsIHNldEpvYl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgZGVzY3JpcHRvciA9IGNhdGFsb2cuZGF0YT8uZGF0YS5maW5kKHAgPT4gcC5wcm92aWRlcklkID09PSBwcm92aWRlcik7XG4gICAgY29uc3QgaXNFbXB0eSA9ICFsaXN0LmlzRXJyb3IgJiYgbGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMDtcbiAgICBjb25zdCBhZGRDb25uZWN0aW9uQnV0dG9uID0gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJpbnRlZ3JhdGlvbnMubWFuYWdlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHN0YXJ0KG51bGwpfT5UaMOqbSBr4bq/dCBu4buRaSBBSTwvTXV0YXRpb25CdXR0b24+O1xuICAgIGNvbnN0IHN0YXJ0ID0gKGNvbm5lY3Rpb246IEFJQ29ubmVjdGlvbiB8IG51bGwpID0+IHsgc2V0RWRpdGluZyhjb25uZWN0aW9uKTsgc2V0TmFtZShjb25uZWN0aW9uPy5uYW1lIHx8ICcnKTsgc2V0UHJvdmlkZXIoY29ubmVjdGlvbj8ucHJvdmlkZXJJZCB8fCBjYXRhbG9nLmRhdGE/LmRhdGFbMF0/LnByb3ZpZGVySWQgfHwgJycpOyBzZXRNb2RlbChjb25uZWN0aW9uPy5tb2RlbElkIHx8ICcnKTsgc2V0RW5kcG9pbnQoY29ubmVjdGlvbj8uZW5kcG9pbnRVcmwgfHwgJycpOyBzZXRLZXkoJycpOyBzZXRGb3JtRXJyb3IobnVsbCk7IHNldE9wZW4odHJ1ZSk7IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaMOgIGN1bmcgY+G6pXAgQUlcIiBzdWJ0aXRsZT1cIk3hu5dpIGFkYXB0ZXIgY8O0bmcgYuG7kSBraOG6oyBuxINuZzsga2jDtG5nIGdp4bqjIMSR4buLbmggbeG7jWkgQVBJIGtleSBjw7MgdGjhu4MgdGhheSB0aOG6vyBuaGF1LlwiIGFjdGlvbnM9eyFpc0VtcHR5ICYmIGFkZENvbm5lY3Rpb25CdXR0b259Lz48RXJyb3JOb3RpY2UgZXJyb3I9e3Rlc3QuZXJyb3J9Lz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YT8uZGF0YS5sZW5ndGggPT09IDAgJiYgIWxpc3QuaXNFcnJvciA/IDxFbXB0eSB0ZXh0PVwiQ2jGsGEgY8OzIGvhur90IG7hu5FpIEFJLiBUaMOqbSBt4buZdCBr4bq/dCBu4buRaSDEkeG7gyBj4bqldSBow6xuaCBuaMOgIGN1bmcgY+G6pXAuXCIgYWN0aW9uPXthZGRDb25uZWN0aW9uQnV0dG9ufS8+IDogPFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICdtaW5tYXgoMCwgMWZyKScsIGxnOiBsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAxID8gJ21pbm1heCgwLCAxZnIpJyA6ICdyZXBlYXQoMiwgbWlubWF4KDAsIDFmcikpJyB9fT57bGlzdC5kYXRhPy5kYXRhLm1hcChjID0+IDxQYW5lbCBrZXk9e2MuaWR9IHRpdGxlPXtjLm5hbWV9IGJvZHlNb2RlPVwiaW5zZXRcIiBhY3Rpb249ezxTdGF0dXMgdmFsdWU9e2Muc3RhdHVzfS8+fT48Qm94PjxEZXRhaWxMaW5lIGxhYmVsPVwiUHJvdmlkZXIgLyBhZGFwdGVyXCI+e2MucHJvdmlkZXJJZH0gLyB7Yy5hZGFwdGVySWR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTW9kZWxcIj57Yy5tb2RlbElkfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIktow7NhXCI+e2MuaGFzQ3JlZGVudGlhbCA/IGDigKLigKLigKLigKIgJHtjLmtleUxhc3Q0IHx8ICcnfWAgOiAnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJM4bqnbiBraeG7g20gZ+G6p24gbmjhuqV0XCI+e2RhdGVUaW1lKGMubGFzdENoZWNrZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPjxTdXJmYWNlQ29udGVudCByaHl0aG09XCJkaXZpZGVkUm93c1wiIGJlZm9yZUdhcD1cInN1cmZhY2VcIiBhZnRlckdhcD1cIm5vdGljZVwiPntPYmplY3QuZW50cmllcyhjLmNhcGFiaWxpdGllcykuZmlsdGVyKChba10pID0+IGsgIT09ICdsYXN0VmVyaWZpZWRBdCcpLm1hcCgoW2ssIHZdKSA9PiA8RGV0YWlsTGluZSBrZXk9e2t9IGxhYmVsPXtjYXBhYmlsaXR5TmFtZShrKX0+e3R5cGVvZiB2ID09PSAnc3RyaW5nJyA/IDxTdGF0dXMgdmFsdWU9e3Z9IGRvbWFpbj1cImNhcGFiaWxpdHlcIiBkZW5zaXR5PVwiY29tcGFjdFwiLz4gOiAnQ2jGsGEgeMOhYyBtaW5oJ308L0RldGFpbExpbmU+KX08L1N1cmZhY2VDb250ZW50PjxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiA+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXREZXRhaWxJZChjLmlkKX0+Q2hpIHRp4bq/dCBr4bq/dCBu4buRaTwvQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHN0YXJ0KGMpfT5T4butYSAvIHhvYXkga2jDs2E8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGJ1c3k9e3Rlc3QucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBzZXRKb2IoKGF3YWl0IHRlc3QuZXhlY3V0ZSh7IHBhdGg6IHsgY29ubmVjdGlvbklkOiBjLmlkIH0gfSkpLmRhdGEuaWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5LaeG7g20ga+G6v3QgbuG7kWk8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBvbkNsaWNrPXsoKSA9PiBzZXREZWxldGluZyhjKX0+WMOzYTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD48L0JveD48L1BhbmVsPil9PC9TZWN0aW9uR3JpZD59PC9RdWVyeVN0YXRlPntqb2JJZCAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7am9iSWR9YH0+S+G6v3QgcXXhuqMga2nhu4NtIHRyYSBr4bq/dCBu4buRaTwvUm91dGVMaW5rPn1cbiA8RWRpdERpYWxvZyBvcGVuPXshIWRldGFpbElkfSB0aXRsZT1cIkNoaSB0aeG6v3Qga+G6v3QgbuG7kWkgQUlcIiBvbkNsb3NlPXsoKSA9PiBzZXREZXRhaWxJZCgnJyl9IGFjdGlvbnM9ezxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RGV0YWlsSWQoJycpfT7EkMOzbmc8L0J1dHRvbj59PlxuICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntkZXRhaWwuZGF0YSAmJiA8U3VyZmFjZUNvbnRlbnQ+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiVMOqbiBr4bq/dCBu4buRaVwiPntkZXRhaWwuZGF0YS5kYXRhLm5hbWV9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiUHJvdmlkZXIgLyBhZGFwdGVyXCI+e2RldGFpbC5kYXRhLmRhdGEucHJvdmlkZXJJZH0gLyB7ZGV0YWlsLmRhdGEuZGF0YS5hZGFwdGVySWR9PC9EZXRhaWxMaW5lPlxuICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk1vZGVsXCI+e2RldGFpbC5kYXRhLmRhdGEubW9kZWxJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJUcuG6oW5nIHRow6FpXCI+PFN0YXR1cyB2YWx1ZT17ZGV0YWlsLmRhdGEuZGF0YS5zdGF0dXN9Lz48L0RldGFpbExpbmU+XG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiS2jDs2FcIj57ZGV0YWlsLmRhdGEuZGF0YS5oYXNDcmVkZW50aWFsID8gJ+KAouKAouKAouKAoiAnICsgKGRldGFpbC5kYXRhLmRhdGEua2V5TGFzdDQgfHwgJycpIDogJ0NoxrBhIGPDsyd9PC9EZXRhaWxMaW5lPlxuICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkzhuqduIGtp4buDbSBn4bqnbiBuaOG6pXRcIj57ZGF0ZVRpbWUoZGV0YWlsLmRhdGEuZGF0YS5sYXN0Q2hlY2tlZEF0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+XG4gICAgICAgIHtPYmplY3QuZW50cmllcyhkZXRhaWwuZGF0YS5kYXRhLmNhcGFiaWxpdGllcykuZmlsdGVyKChba2V5XSkgPT4ga2V5ICE9PSAnbGFzdFZlcmlmaWVkQXQnKS5tYXAoKFtrZXksIHZhbHVlXSkgPT4gPERldGFpbExpbmUga2V5PXtrZXl9IGxhYmVsPXtjYXBhYmlsaXR5TmFtZShrZXkpfT57dHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IDxTdGF0dXMgdmFsdWU9e3ZhbHVlfSBkb21haW49XCJjYXBhYmlsaXR5XCIgZGVuc2l0eT1cImNvbXBhY3RcIi8+IDogJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPil9XG4gICAgPC9TdXJmYWNlQ29udGVudD59PC9RdWVyeVN0YXRlPlxuIDwvRWRpdERpYWxvZz5cbiA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT17ZWRpdGluZyA/ICdT4butYSBr4bq/dCBu4buRaSAvIHhvYXkga2jDs2EnIDogJ0vhur90IG7hu5FpIEFJIG3hu5tpJ30gb25DbG9zZT17KCkgPT4geyBzZXRLZXkoJycpOyBzZXRGb3JtRXJyb3IobnVsbCk7IHNldE9wZW4oZmFsc2UpOyB9fSBidXN5PXtjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFuYW1lLnRyaW0oKSB8fCAhbW9kZWwudHJpbSgpIHx8ICghZWRpdGluZyAmJiAoIWRlc2NyaXB0b3IgfHwgIWtleSkpIHx8IGNyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgIHNldEZvcm1FcnJvcihudWxsKTtcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkQ3JlZGVudGlhbCA9IGtleTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChfX01PQ0tfXyAmJiBzdWJtaXR0ZWRDcmVkZW50aWFsICYmICFzdWJtaXR0ZWRDcmVkZW50aWFsLnN0YXJ0c1dpdGgoJ2RlbW8tJykpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDaOG7iSBuaOG6rXAga2jDs2EgZ2nhuqMgYuG6r3QgxJHhuqd1IGLhurFuZyBkZW1vLSB0cm9uZyBi4bqjbiBtw7QgcGjhu49uZy4nKTtcbiAgICAgICAgICAgIGlmIChlZGl0aW5nKVxuICAgICAgICAgICAgICAgIGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyBjb25uZWN0aW9uSWQ6IGVkaXRpbmcuaWQgfSwgdmVyc2lvbjogZWRpdGluZy52ZXJzaW9uLCBib2R5OiB7IG5hbWU6IG5hbWUudHJpbSgpLCBtb2RlbElkOiBtb2RlbC50cmltKCksIC4uLihzdWJtaXR0ZWRDcmVkZW50aWFsID8geyBjcmVkZW50aWFsOiBzdWJtaXR0ZWRDcmVkZW50aWFsIH0gOiB7fSkgfSB9KTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHk6IHsgbmFtZTogbmFtZS50cmltKCksIHByb3ZpZGVySWQ6IHByb3ZpZGVyLCBhZGFwdGVySWQ6IGRlc2NyaXB0b3I/LmFkYXB0ZXJJZCB8fCAnJywgbW9kZWxJZDogbW9kZWwudHJpbSgpLCBlbmRwb2ludFVybDogZW5kcG9pbnQgfHwgbnVsbCwgY3JlZGVudGlhbDogc3VibWl0dGVkQ3JlZGVudGlhbCB9IH0pO1xuICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiAnS2jDtG5nIGzGsHUgxJHGsOG7o2MgY+G6pXUgaMOsbmgga+G6v3QgbuG7kWkuJztcbiAgICAgICAgICAgIHNldEZvcm1FcnJvcihuZXcgRXJyb3Ioc3VibWl0dGVkQ3JlZGVudGlhbCAmJiBtZXNzYWdlLmluY2x1ZGVzKHN1Ym1pdHRlZENyZWRlbnRpYWwpID8gbWVzc2FnZS5yZXBsYWNlQWxsKHN1Ym1pdHRlZENyZWRlbnRpYWwsICdbxJHDoyDhuqluXScpIDogbWVzc2FnZSkpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0S2V5KCcnKTtcbiAgICAgICAgfVxuICAgIH19PkzGsHUgY+G6pXUgaMOsbmg8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17Zm9ybUVycm9yIHx8IGNyZWF0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+e19fTU9DS19fICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5LaMO0bmcgbmjhuq1wIGtow7NhIHRo4bqtdC4gRMO5bmcgZGVtby1rZXk7IHJlcXVlc3QgbcO0IHBo4buPbmcgY2jhu4kga2nhu4NtIHRyYSBnaWFvIGRp4buHbiwga2jDtG5nIGdp4buvIGtow7NhIHbDoCBraMO0bmcga+G6v3QgbuG7kWkgQUkgdGjhuq10LjwvQWxlcnQ+fTxUZXh0RmllbGQgbGFiZWw9XCJUw6puIGvhur90IG7hu5FpXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXtlID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfS8+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJQcm92aWRlciDEkcOjIGPDsyBhZGFwdGVyXCIgdmFsdWU9e3Byb3ZpZGVyfSBkaXNhYmxlZD17ISFlZGl0aW5nfSBvbkNoYW5nZT17ZSA9PiB7IHNldFByb3ZpZGVyKGUudGFyZ2V0LnZhbHVlKTsgc2V0TW9kZWwoJycpOyB9fT57Y2F0YWxvZy5kYXRhPy5kYXRhLm1hcChwID0+IDxNZW51SXRlbSB2YWx1ZT17cC5wcm92aWRlcklkfSBrZXk9e3AucHJvdmlkZXJJZH0+e3AubGFiZWx9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJNb2RlbCBJRCDEkcaw4bujYyBhZGFwdGVyIGjhu5cgdHLhu6NcIiB2YWx1ZT17bW9kZWx9IG9uQ2hhbmdlPXtlID0+IHNldE1vZGVsKGUudGFyZ2V0LnZhbHVlKX0gaGVscGVyVGV4dD17ZGVzY3JpcHRvcj8ubW9kZWxzLm1hcChtID0+IG0ubW9kZWxJZCkuam9pbignLCAnKSB8fCAnWGVtIGNhdGFsb2cgdOG7qyBiYWNrZW5kJ30vPnshZWRpdGluZyAmJiBkZXNjcmlwdG9yPy5lbmRwb2ludEVkaXRhYmxlICYmIDxUZXh0RmllbGQgbGFiZWw9XCJFbmRwb2ludCBIVFRQUyDEkcaw4bujYyBiYWNrZW5kIGNobyBwaMOpcFwiIHZhbHVlPXtlbmRwb2ludH0gb25DaGFuZ2U9e2UgPT4gc2V0RW5kcG9pbnQoZS50YXJnZXQudmFsdWUpfS8+fTxUZXh0RmllbGQgbGFiZWw9e2VkaXRpbmcgPyAnS2jDs2EgbeG7m2kgKMSR4buDIHRy4buRbmcgxJHhu4MgZ2nhu68gbmd1ecOqbiknIDogJ0tow7NhIEFQSSd9IHR5cGU9XCJwYXNzd29yZFwiIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiIHZhbHVlPXtrZXl9IG9uQ2hhbmdlPXtlID0+IHNldEtleShsaW1pdENvZGVQb2ludHMoZS50YXJnZXQudmFsdWUsIDE2Mzg0KSl9IC8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlNlY3JldCBjaOG7iSDEkcaw4bujYyBn4butaSB0aGVvIHRyxrDhu51uZyB3cml0ZU9ubHkgY+G7p2EgY29udHJhY3QuIFJlc3BvbnNlIHbDoCBkYW5oIHPDoWNoIGtow7RuZyB0cuG6oyBzZWNyZXQgZ+G7kWMuPC9BbGVydD48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPlxuIDxDb25maXJtRGlhbG9nIG9wZW49eyEhZGVsZXRpbmd9IHRpdGxlPVwiWMOzYSBr4bq/dCBu4buRaSBBSVwiIGNvbmZpcm1MYWJlbD1cIljDs2Ega+G6v3QgbuG7kWkgQUlcIiBkZXNjcmlwdGlvbj17YEvhur90IG7hu5FpIEFJICR7ZGVsZXRpbmc/Lm5hbWUgfHwgXCJcIn0gKCR7ZGVsZXRpbmc/LmlkIHx8IFwiXCJ9KSwgbW9kZWwgJHtkZWxldGluZz8ubW9kZWxJZCB8fCBcIlwifTogY2jhu4kgeMOzYSBraGkga2jDtG5nIGPDsm4gY+G6pXUgaMOsbmggxJFhbmcgc+G7rSBk4bulbmcuIEtow7RuZyB04buxIGNodXnhu4NuIGThu68gbGnhu4d1IHNhbmcgbmjDoCBjdW5nIGPhuqVwIGtow6FjLmB9IHJlcXVpcmVSZWFzb24gb25DbG9zZT17KCkgPT4gc2V0RGVsZXRpbmcobnVsbCl9IGVycm9yPXtyZW1vdmUuZXJyb3J9IGJ1c3k9e3JlbW92ZS5wZW5kaW5nfSBvbkNvbmZpcm09e2FzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFkZWxldGluZykgcmV0dXJuO1xuICAgICAgICBhd2FpdCByZW1vdmUuZXhlY3V0ZSh7IHBhdGg6IHsgY29ubmVjdGlvbklkOiBkZWxldGluZy5pZCB9LCB2ZXJzaW9uOiBkZWxldGluZy52ZXJzaW9uIH0pO1xuICAgIH19Lz48Lz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9ldmlkZW5jZS9mcm9udGVuZC1jb21wbGV0ZW5lc3MtMjAyNjEwMTMtYWFmNzRiNy9jbGVhbi1pbnN0YWxsLXIyL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvaW50ZWdyYXRpb25zL2luZGV4LnRzeCJ9