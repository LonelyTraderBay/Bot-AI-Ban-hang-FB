import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/integrations/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-20844-c0b9087f-8231-4ba3-a390-f612ee4c30f1/deps/react_jsx-dev-runtime.js?v=56132fdd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-20844-c0b9087f-8231-4ba3-a390-f612ee4c30f1/deps/react.js?v=56132fdd"; const useState = __vite__cjsImport4_react["useState"];
import { layoutSx } from "/src/shared/ui/layout.ts";
import { Alert, Box, Button, Chip, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-20844-c0b9087f-8231-4ba3-a390-f612ee4c30f1/deps/@mui_material.js?v=22c6c9d5";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { ConfirmDialog, DetailLine, EditDialog, Empty, ErrorNotice, MutationButton, PageHeader, Panel, QueryState, RouteLink, Status } from "/src/shared/ui/components.tsx";
function authorize(url) {
  const target = new URL(url, location.origin);
  if (target.protocol !== "https:" && !(__MOCK__ && target.origin === location.origin))
    throw new Error("Đường dẫn xác thực không dùng HTTPS.");
  location.assign(target.href);
}
export function ChannelsPage() {
  _s();
  const { shop } = useScope();
  const list = useApi("listChannels");
  const connect = useCommand("beginChannelConnect", []), reconnect = useCommand("reconnectChannel", []), disconnect = useCommand("disconnectChannel", ["listChannels"]), check = useCommand("checkChannelHealth", ["listChannels"]);
  const [selected, setSelected] = useState(null), [jobId, setJob] = useState(""), [error, setError] = useState(null);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const connectButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", busy: connect.pending, onClick: () => void start(), children: "Kết nối Page" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 38,
    columnNumber: 25
  }, this);
  const start = async (channelId) => {
    setError(null);
    try {
      const body = { returnPath: `/s/${shop.id}/integrations/channels`, channelKind: "facebook_messenger" };
      const r = channelId ? await reconnect.execute({ path: { channelId }, body }) : await connect.execute({ body });
      authorize(r.data.authorizationUrl);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không thể bắt đầu xác thực."));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Kết nối Facebook", subtitle: "Kết nối bằng luồng cấp quyền. Page token chỉ được giữ ở backend.", actions: !isEmpty && connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || connect.error || reconnect.error || check.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 163
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Đây là mô phỏng. Không đăng nhập Facebook và không gửi tin thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 256
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có Page kết nối. Dùng nút bên dưới để bắt đầu.", action: connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 481
    }, this) : /* @__PURE__ */ jsxDEV(PageSections, { children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: __MOCK__ ? /* @__PURE__ */ jsxDEV(Chip, { label: "Mô phỏng, chưa liên kết thật", color: "warning", variant: "outlined" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 686
    }, this) : /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 769
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Page ID", children: c.externalPageId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 803
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Webhook gần nhất", children: dateTime(c.lastWebhookAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 862
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: c.policyVersion || "Chưa xác minh" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 954
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kiểm chính sách lúc", children: dateTime(c.policyVerifiedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 1034
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "surface", afterGap: "notice", children: c.capabilities.map((cap) => /* @__PURE__ */ jsxDEV(Chip, { label: cap }, cap, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 1228
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 1132
      }, this),
      c.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: w }, w, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 1297
      }, this)),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: check.pending, onClick: async () => {
          try {
            setJob((await check.execute({ path: { channelId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 47,
          columnNumber: 1403
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: reconnect.pending, onClick: () => void start(c.id), children: "Kết nối lại" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 50,
          columnNumber: 70
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setSelected(c), children: "Ngắt kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 50,
          columnNumber: 205
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 47,
        columnNumber: 1374
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 798
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 617
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 575
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 47,
      columnNumber: 382
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Xem kết quả kiểm tra" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 397
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: "Ngắt kết nối Page", description: "Dừng gửi mới và thu hồi kết nối ở backend. Không xóa lịch sử đơn hàng/hội thoại.", requireReason: true, onClose: () => setSelected(null), busy: disconnect.pending, error: disconnect.error, onConfirm: (reason) => disconnect.execute({ path: { channelId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 50,
      columnNumber: 476
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
}
_s(ChannelsPage, "ZavHqp2lD+aTYBQU4i5iyqgpR8Q=", false, function() {
  return [useScope, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c = ChannelsPage;
export function AIProvidersPage() {
  _s2();
  const { shop } = useScope();
  const list = useApi("listAIConnections"), catalog = useApi("getProviderCatalog");
  const create = useCommand("createAIConnection", ["listAIConnections"]), update = useCommand("updateAIConnection", ["listAIConnections"]), remove = useCommand("deleteAIConnection", ["listAIConnections"]), test = useCommand("testAIConnection", ["listAIConnections"]);
  const [open, setOpen] = useState(false), [editing, setEditing] = useState(null), [name, setName] = useState(""), [provider, setProvider] = useState(""), [model, setModel] = useState(""), [endpoint, setEndpoint] = useState(""), [key, setKey] = useState(""), [formError, setFormError] = useState(null), [deleting, setDeleting] = useState(null), [jobId, setJob] = useState("");
  const descriptor = catalog.data?.data.find((p) => p.providerId === provider);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const addConnectionButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", onClick: () => start(null), children: "Thêm kết nối AI" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 59,
    columnNumber: 31
  }, this);
  const start = (connection) => {
    setEditing(connection);
    setName(connection?.name || "");
    setProvider(connection?.providerId || catalog.data?.data[0]?.providerId || "");
    setModel(connection?.modelId || "");
    setEndpoint(connection?.endpointUrl || "");
    setKey("");
    setFormError(null);
    setOpen(true);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhà cung cấp AI", subtitle: "Mỗi adapter công bố khả năng; không giả định mọi API key có thể thay thế nhau.", actions: !isEmpty && addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: test.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 182
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có kết nối AI. Thêm một kết nối để cấu hình nhà cung cấp.", action: addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 315
    }, this) : /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "minmax(0, 1fr)", lg: list.data?.data.length === 1 ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))" }, children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 643
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Provider / adapter", children: [
        c.providerId,
        " / ",
        c.adapterId
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 677
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Model", children: c.modelId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 759
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khóa", children: c.hasCredential ? `•••• ${c.keyLast4 || ""}` : "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 809
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lần kiểm gần nhất", children: dateTime(c.lastCheckedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 905
      }, this),
      /* @__PURE__ */ jsxDEV(SurfaceContent, { rhythm: "dividedRows", beforeGap: "surface", afterGap: "notice", children: Object.entries(c.capabilities).filter(([k]) => k !== "lastVerifiedAt").map(([k, v]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: k, children: typeof v === "string" ? v : "Chưa rõ" }, k, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 1161
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 998
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", onClick: () => start(c), children: "Sửa / xoay khóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 61,
          columnNumber: 1291
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: test.pending, onClick: async () => {
          try {
            setJob((await test.execute({ path: { connectionId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 61,
          columnNumber: 1397
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setDeleting(c), children: "Xóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 64,
          columnNumber: 70
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 61,
        columnNumber: 1262
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 672
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 585
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 426
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 61,
      columnNumber: 216
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Kết quả kiểm tra kết nối" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 64,
      columnNumber: 252
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: editing ? "Sửa kết nối / xoay khóa" : "Kết nối AI mới", onClose: () => {
      setKey("");
      setFormError(null);
      setOpen(false);
    }, busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !name.trim() || !model.trim() || !editing && (!descriptor || !key) || create.pending || update.pending, onClick: async () => {
      setFormError(null);
      const submittedCredential = key;
      try {
        if (__MOCK__ && submittedCredential && !submittedCredential.startsWith("demo-"))
          throw new Error("Chỉ nhập khóa giả bắt đầu bằng demo- trong bản mô phỏng.");
        if (editing)
          await update.execute({ path: { connectionId: editing.id }, version: editing.version, body: { name: name.trim(), modelId: model.trim(), ...submittedCredential ? { credential: submittedCredential } : {} } });
        else
          await create.execute({ body: { name: name.trim(), providerId: provider, adapterId: descriptor?.adapterId || "", modelId: model.trim(), endpointUrl: endpoint || null, credential: submittedCredential } });
        setOpen(false);
      } catch (e) {
        const message = e instanceof Error ? e.message : "Không lưu được cấu hình kết nối.";
        setFormError(new Error(submittedCredential && message.includes(submittedCredential) ? message.replaceAll(submittedCredential, "[đã ẩn]") : message));
      } finally {
        setKey("");
      }
    }, children: "Lưu cấu hình" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 65,
      columnNumber: 202
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: formError || create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 84,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không nhập khóa thật. Dùng demo-key; request mô phỏng chỉ kiểm tra giao diện, không giữ khóa và không kết nối AI thật." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 121
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên kết nối", value: name, onChange: (e) => setName(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 274
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Provider đã có adapter", value: provider, disabled: !!editing, onChange: (e) => {
          setProvider(e.target.value);
          setModel("");
        }, children: catalog.data?.data.map((p) => /* @__PURE__ */ jsxDEV(MenuItem, { value: p.providerId, children: p.label }, p.providerId, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 542
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 362
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Model ID được adapter hỗ trợ", value: model, onChange: (e) => setModel(e.target.value), helperText: descriptor?.models.map((m) => m.modelId).join(", ") || "Xem catalog từ backend" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 626
        }, this),
        !editing && descriptor?.endpointEditable && /* @__PURE__ */ jsxDEV(TextField, { label: "Endpoint HTTPS được backend cho phép", value: endpoint, onChange: (e) => setEndpoint(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 871
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: editing ? "Khóa mới (để trống để giữ nguyên)" : "Khóa API", type: "password", autoComplete: "new-password", value: key, onChange: (e) => setKey(limitCodePoints(e.target.value, 16384)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 993
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Secret chỉ được gửi theo trường writeOnly của contract. Response và danh sách không trả secret gốc." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 84,
          columnNumber: 1194
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 84,
        columnNumber: 96
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 65,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!deleting, title: "Xóa kết nối AI", description: "Backend kiểm các cấu hình đang sử dụng trước khi xóa; không tự chuyển dữ liệu sang provider khác.", requireReason: true, onClose: () => setDeleting(null), error: remove.error, busy: remove.pending, onConfirm: async () => {
      if (!deleting) return;
      await remove.execute({ path: { connectionId: deleting.id }, version: deleting.version });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 85,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 61,
    columnNumber: 10
  }, this);
}
_s2(AIProvidersPage, "MnwpftGyLZzRVfWHEZz/v/QjesE=", false, function() {
  return [useScope, useApi, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c2 = AIProvidersPage;
var _c, _c2;
$RefreshReg$(_c, "ChannelsPage");
$RefreshReg$(_c2, "AIProvidersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0IwQixTQVNmLFVBVGU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbEIxQixTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxhQUFhQyxzQkFBc0I7QUFDbkYsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxNQUFNQyxVQUFVQyxpQkFBaUI7QUFFOUQsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUJDLGdCQUFnQjtBQUMxQyxTQUFTQyxlQUFlQyxZQUFZQyxZQUFZQyxPQUFPQyxhQUFhQyxnQkFBZ0JDLFlBQVlDLE9BQU9DLFlBQVlDLFdBQVdDLGNBQWM7QUFFNUksU0FBU0MsVUFBVUMsS0FBYTtBQUFFLFFBQU1DLFNBQVMsSUFBSUMsSUFBSUYsS0FBS0csU0FBU0MsTUFBTTtBQUFHLE1BQUlILE9BQU9JLGFBQWEsWUFBWSxFQUFFQyxZQUFZTCxPQUFPRyxXQUFXRCxTQUFTQztBQUN6SixVQUFNLElBQUlHLE1BQU0sc0NBQXNDO0FBQUdKLFdBQVNLLE9BQU9QLE9BQU9RLElBQUk7QUFBRztBQUNwRixnQkFBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sRUFBRUMsS0FBSyxJQUFJM0IsU0FBUztBQUMxQixRQUFNNEIsT0FBTzlCLE9BQU8sY0FBYztBQUNsQyxRQUFNK0IsVUFBVTlCLFdBQVcsdUJBQXVCLEVBQUUsR0FBRytCLFlBQVkvQixXQUFXLG9CQUFvQixFQUFFLEdBQUdnQyxhQUFhaEMsV0FBVyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsR0FBR2lDLFFBQVFqQyxXQUFXLHNCQUFzQixDQUFDLGNBQWMsQ0FBQztBQUNoTyxRQUFNLENBQUNrQyxVQUFVQyxXQUFXLElBQUk1QyxTQUF5QixJQUFJLEdBQUcsQ0FBQzZDLE9BQU9DLE1BQU0sSUFBSTlDLFNBQVMsRUFBRSxHQUFHLENBQUMrQyxPQUFPQyxRQUFRLElBQUloRCxTQUF1QixJQUFJO0FBQy9JLFFBQU1pRCxVQUFVLENBQUNYLEtBQUtZLFdBQVdaLEtBQUthLE1BQU1BLEtBQUtDLFdBQVc7QUFDNUQsUUFBTUMsZ0JBQWdCLHVCQUFDLGtCQUFlLFlBQVcsdUJBQXNCLFNBQVEsYUFBWSxNQUFNZCxRQUFRZSxTQUFTLFNBQVMsTUFBTSxLQUFLQyxNQUFNLEdBQUcsNEJBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUk7QUFDM0osUUFBTUEsUUFBUSxPQUFPQyxjQUF1QjtBQUFFUixhQUFTLElBQUk7QUFBRyxRQUFJO0FBQzlELFlBQU1TLE9BQU8sRUFBRUMsWUFBWSxNQUFNckIsS0FBS3NCLEVBQUUsMEJBQTBCQyxhQUFhLHFCQUE4QjtBQUM3RyxZQUFNQyxJQUFJTCxZQUFZLE1BQU1oQixVQUFVc0IsUUFBUSxFQUFFQyxNQUFNLEVBQUVQLFVBQVUsR0FBR0MsS0FBSyxDQUFDLElBQUksTUFBTWxCLFFBQVF1QixRQUFRLEVBQUVMLEtBQUssQ0FBQztBQUM3R2pDLGdCQUFVcUMsRUFBRVYsS0FBS2EsZ0JBQWdCO0FBQUEsSUFDckMsU0FDT0MsR0FBRztBQUNOakIsZUFBU2lCLGFBQWFqQyxRQUFRaUMsSUFBSSxJQUFJakMsTUFBTSw2QkFBNkIsQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFBRTtBQUNGLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sb0JBQW1CLFVBQVMsb0VBQW1FLFNBQVMsQ0FBQ2lCLFdBQVdJLGlCQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9KO0FBQUEsSUFBRSx1QkFBQyxlQUFZLE9BQU9OLFNBQVNSLFFBQVFRLFNBQVNQLFVBQVVPLFNBQVNMLE1BQU1LLFNBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkU7QUFBQSxJQUFHaEIsWUFBWSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJOUIsU0FBU2lFLE9BQU9DLFVBQVUsZ0ZBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUg7QUFBQSxJQUFTLHVCQUFDLGNBQVcsT0FBTzdCLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2EsTUFBTUEsS0FBS0MsV0FBVyxLQUFLLENBQUNkLEtBQUtZLFVBQVUsdUJBQUMsU0FBTSxNQUFLLHVEQUFzRCxRQUFRRyxpQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RixJQUFLLHVCQUFDLGdCQUFlZixlQUFLYSxNQUFNQSxLQUFLaUIsSUFBSSxDQUFBQyxNQUFLLHVCQUFDLFNBQWlCLE9BQU9BLEVBQUVDLE1BQU0sVUFBUyxTQUFRLFFBQVF2QyxXQUFXLHVCQUFDLFFBQUssT0FBTSxnQ0FBK0IsT0FBTSxXQUFVLFNBQVEsY0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RSxJQUFLLHVCQUFDLFVBQU8sT0FBT3NDLEVBQUVFLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsR0FBSSxpQ0FBQyxPQUFJO0FBQUEsNkJBQUMsY0FBVyxPQUFNLFdBQVdGLFlBQUVHLGtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sb0JBQW9CNUQsbUJBQVN5RCxFQUFFSSxlQUFlcEMsS0FBS3FDLFFBQVEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGNBQWNMLFlBQUVNLGlCQUFpQixtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLHVCQUF1Qi9ELG1CQUFTeUQsRUFBRU8sa0JBQWtCdkMsS0FBS3FDLFFBQVEsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLE1BQWEsdUJBQUMsZUFBWSxXQUFVLE9BQU0sV0FBVSxXQUFVLFVBQVMsVUFBVUwsWUFBRVEsYUFBYVQsSUFBSSxDQUFBVSxRQUFPLHVCQUFDLFFBQUssT0FBT0EsT0FBVUEsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQixDQUFFLEtBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkg7QUFBQSxNQUFlVCxFQUFFVSxTQUFTWCxJQUFJLENBQUFZLE1BQUssdUJBQUMsU0FBTSxVQUFTLFdBQWtCLElBQUkvRSxTQUFTaUUsT0FBT0MsVUFBV2EsZUFBbENBLEdBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUUsQ0FBUTtBQUFBLE1BQUUsdUJBQUMsZUFBWSxXQUFVLE9BQU87QUFBQSwrQkFBQyxrQkFBZSxZQUFXLHVCQUFzQixNQUFNdEMsTUFBTVksU0FBUyxTQUFTLFlBQVk7QUFBRSxjQUFJO0FBQzM4Q1Isb0JBQVEsTUFBTUosTUFBTW9CLFFBQVEsRUFBRUMsTUFBTSxFQUFFUCxXQUFXYSxFQUFFVixHQUFHLEVBQUUsQ0FBQyxHQUFHUixLQUFLUSxFQUFFO0FBQUEsVUFDdkUsUUFDTTtBQUFBLFVBQUU7QUFBQSxRQUFnQixHQUFHLDRCQUhtMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUd2MEM7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixNQUFNbkIsVUFBVWMsU0FBUyxTQUFTLE1BQU0sS0FBS0MsTUFBTWMsRUFBRVYsRUFBRSxHQUFHLDJCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsT0FBTSxTQUFRLFNBQVMsTUFBTWYsWUFBWXlCLENBQUMsR0FBRyw0QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFdBSHVpQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR3RoQztBQUFBLFNBSDJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHN2MsS0FIc1NBLEVBQUVWLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdwUixDQUFRLEtBSG1PO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHak8sS0FIaUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdqQjtBQUFBLElBQWNkLFNBQVMsdUJBQUMsYUFBVSxJQUFJLE1BQU1SLEtBQUtzQixFQUFFLFNBQVNkLEtBQUssSUFBSSxvQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLElBQWEsdUJBQUMsaUJBQWMsTUFBTSxDQUFDLENBQUNGLFVBQVUsT0FBTSxxQkFBb0IsYUFBWSxvRkFBbUYsZUFBYSxNQUFDLFNBQVMsTUFBTUMsWUFBWSxJQUFJLEdBQUcsTUFBTUgsV0FBV2EsU0FBUyxPQUFPYixXQUFXTSxPQUFPLFdBQVcsQ0FBQWtDLFdBQVV4QyxXQUFXcUIsUUFBUSxFQUFFQyxNQUFNLEVBQUVQLFdBQVdiLFVBQVVnQixNQUFNLEdBQUcsR0FBR0YsTUFBTSxFQUFFeUIsaUJBQWlCdkMsVUFBVXdDLFdBQVcsR0FBR0YsT0FBTyxFQUFFLENBQUMsS0FBM1k7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2WTtBQUFBLE9BSHAxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR3MxQjtBQUNqMkI7QUFBQzdDLEdBbkJlRCxjQUFZO0FBQUEsVUFDUHpCLFVBQ0pGLFFBQ0dDLFlBQW1EQSxZQUFpREEsWUFBMkRBLFVBQVU7QUFBQTtBQUFBLEtBSDdLMEI7QUFvQlQsZ0JBQVNpRCxrQkFBa0I7QUFBQUMsTUFBQTtBQUM5QixRQUFNLEVBQUVoRCxLQUFLLElBQUkzQixTQUFTO0FBQzFCLFFBQU00QixPQUFPOUIsT0FBTyxtQkFBbUIsR0FBRzhFLFVBQVU5RSxPQUFPLG9CQUFvQjtBQUMvRSxRQUFNK0UsU0FBUzlFLFdBQVcsc0JBQXNCLENBQUMsbUJBQW1CLENBQUMsR0FBRytFLFNBQVMvRSxXQUFXLHNCQUFzQixDQUFDLG1CQUFtQixDQUFDLEdBQUdnRixTQUFTaEYsV0FBVyxzQkFBc0IsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHaUYsT0FBT2pGLFdBQVcsb0JBQW9CLENBQUMsbUJBQW1CLENBQUM7QUFDdlEsUUFBTSxDQUFDa0YsTUFBTUMsT0FBTyxJQUFJNUYsU0FBUyxLQUFLLEdBQUcsQ0FBQzZGLFNBQVNDLFVBQVUsSUFBSTlGLFNBQThCLElBQUksR0FBRyxDQUFDc0UsTUFBTXlCLE9BQU8sSUFBSS9GLFNBQVMsRUFBRSxHQUFHLENBQUNnRyxVQUFVQyxXQUFXLElBQUlqRyxTQUFTLEVBQUUsR0FBRyxDQUFDa0csT0FBT0MsUUFBUSxJQUFJbkcsU0FBUyxFQUFFLEdBQUcsQ0FBQ29HLFVBQVVDLFdBQVcsSUFBSXJHLFNBQVMsRUFBRSxHQUFHLENBQUNzRyxLQUFLQyxNQUFNLElBQUl2RyxTQUFTLEVBQUUsR0FBRyxDQUFDd0csV0FBV0MsWUFBWSxJQUFJekcsU0FBdUIsSUFBSSxHQUFHLENBQUMwRyxVQUFVQyxXQUFXLElBQUkzRyxTQUE4QixJQUFJLEdBQUcsQ0FBQzZDLE9BQU9DLE1BQU0sSUFBSTlDLFNBQVMsRUFBRTtBQUM1YSxRQUFNNEcsYUFBYXRCLFFBQVFuQyxNQUFNQSxLQUFLMEQsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxlQUFlZixRQUFRO0FBQ3pFLFFBQU0vQyxVQUFVLENBQUNYLEtBQUtZLFdBQVdaLEtBQUthLE1BQU1BLEtBQUtDLFdBQVc7QUFDNUQsUUFBTTRELHNCQUFzQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFRLGFBQVksU0FBUyxNQUFNekQsTUFBTSxJQUFJLEdBQUcsK0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0g7QUFDNUksUUFBTUEsUUFBUUEsQ0FBQzBELGVBQW9DO0FBQUVuQixlQUFXbUIsVUFBVTtBQUFHbEIsWUFBUWtCLFlBQVkzQyxRQUFRLEVBQUU7QUFBRzJCLGdCQUFZZ0IsWUFBWUYsY0FBY3pCLFFBQVFuQyxNQUFNQSxLQUFLLENBQUMsR0FBRzRELGNBQWMsRUFBRTtBQUFHWixhQUFTYyxZQUFZQyxXQUFXLEVBQUU7QUFBR2IsZ0JBQVlZLFlBQVlFLGVBQWUsRUFBRTtBQUFHWixXQUFPLEVBQUU7QUFBR0UsaUJBQWEsSUFBSTtBQUFHYixZQUFRLElBQUk7QUFBQSxFQUFHO0FBQzlULFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sbUJBQWtCLFVBQVMsa0ZBQWlGLFNBQVMsQ0FBQzNDLFdBQVcrRCx1QkFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SztBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPdEIsS0FBSzNDLFNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxJQUFFLHVCQUFDLGNBQVcsT0FBT1QsTUFBTSxnQkFBZSxXQUFXQSxlQUFLYSxNQUFNQSxLQUFLQyxXQUFXLEtBQUssQ0FBQ2QsS0FBS1ksVUFBVSx1QkFBQyxTQUFNLE1BQUssa0VBQWlFLFFBQVE4RCx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RyxJQUFLLHVCQUFDLGVBQVksU0FBUyxFQUFFSSxJQUFJLGtCQUFrQkMsSUFBSS9FLEtBQUthLE1BQU1BLEtBQUtDLFdBQVcsSUFBSSxtQkFBbUIsNEJBQTRCLEdBQUlkLGVBQUthLE1BQU1BLEtBQUtpQixJQUFJLENBQUFDLE1BQUssdUJBQUMsU0FBaUIsT0FBT0EsRUFBRUMsTUFBTSxVQUFTLFNBQVEsUUFBUSx1QkFBQyxVQUFPLE9BQU9ELEVBQUVFLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsR0FBSSxpQ0FBQyxPQUFJO0FBQUEsNkJBQUMsY0FBVyxPQUFNLHNCQUFzQkY7QUFBQUEsVUFBRTBDO0FBQUFBLFFBQVc7QUFBQSxRQUFJMUMsRUFBRWlEO0FBQUFBLFdBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxTQUFTakQsWUFBRTZDLFdBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxRQUFRN0MsWUFBRWtELGdCQUFnQixRQUFRbEQsRUFBRW1ELFlBQVksRUFBRSxLQUFLLGFBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxxQkFBcUI1RyxtQkFBU3lELEVBQUVvRCxlQUFlcEYsS0FBS3FDLFFBQVEsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRjtBQUFBLE1BQWEsdUJBQUMsa0JBQWUsUUFBTyxlQUFjLFdBQVUsV0FBVSxVQUFTLFVBQVVnRCxpQkFBT0MsUUFBUXRELEVBQUVRLFlBQVksRUFBRStDLE9BQU8sQ0FBQyxDQUFDQyxDQUFDLE1BQU1BLE1BQU0sZ0JBQWdCLEVBQUV6RCxJQUFJLENBQUMsQ0FBQ3lELEdBQUdDLENBQUMsTUFBTSx1QkFBQyxjQUFtQixPQUFPRCxHQUFJLGlCQUFPQyxNQUFNLFdBQVdBLElBQUksYUFBMUNELEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUUsQ0FBYSxLQUFyUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVQO0FBQUEsTUFBaUIsdUJBQUMsZUFBWSxXQUFVLE9BQU87QUFBQSwrQkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFTLE1BQU10RSxNQUFNYyxDQUFDLEdBQUcsK0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixNQUFNcUIsS0FBS3BDLFNBQVMsU0FBUyxZQUFZO0FBQUUsY0FBSTtBQUN6OENSLG9CQUFRLE1BQU00QyxLQUFLNUIsUUFBUSxFQUFFQyxNQUFNLEVBQUVnRSxjQUFjMUQsRUFBRVYsR0FBRyxFQUFFLENBQUMsR0FBR1IsS0FBS1EsRUFBRTtBQUFBLFVBQ3pFLFFBQ007QUFBQSxVQUFFO0FBQUEsUUFBZ0IsR0FBRyw0QkFIazFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHdDBDO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsT0FBTSxTQUFRLFNBQVMsTUFBTWdELFlBQVl0QyxDQUFDLEdBQUcsbUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxXQUg0a0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUczakM7QUFBQSxTQUg2ZTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRy9kLEtBSHFaQSxFQUFFVixJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHblksQ0FBUSxLQUg4TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRzVOLEtBSFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdJO0FBQUEsSUFBY2QsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTVIsS0FBS3NCLEVBQUUsU0FBU2QsS0FBSyxJQUFJLHdDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNFO0FBQUEsSUFDdlQsdUJBQUMsY0FBVyxNQUFZLE9BQU9nRCxVQUFVLDRCQUE0QixrQkFBa0IsU0FBUyxNQUFNO0FBQUVVLGFBQU8sRUFBRTtBQUFHRSxtQkFBYSxJQUFJO0FBQUdiLGNBQVEsS0FBSztBQUFBLElBQUcsR0FBRyxNQUFNTCxPQUFPakMsV0FBV2tDLE9BQU9sQyxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDZ0IsS0FBSzBELEtBQUssS0FBSyxDQUFDOUIsTUFBTThCLEtBQUssS0FBTSxDQUFDbkMsWUFBWSxDQUFDZSxjQUFjLENBQUNOLFFBQVNmLE9BQU9qQyxXQUFXa0MsT0FBT2xDLFNBQVMsU0FBUyxZQUFZO0FBQzFXbUQsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0Isc0JBQXNCM0I7QUFDNUIsVUFBSTtBQUNBLFlBQUl2RSxZQUFZa0csdUJBQXVCLENBQUNBLG9CQUFvQkMsV0FBVyxPQUFPO0FBQzFFLGdCQUFNLElBQUlsRyxNQUFNLDBEQUEwRDtBQUM5RSxZQUFJNkQ7QUFDQSxnQkFBTUwsT0FBTzFCLFFBQVEsRUFBRUMsTUFBTSxFQUFFZ0UsY0FBY2xDLFFBQVFsQyxHQUFHLEdBQUd3QixTQUFTVSxRQUFRVixTQUFTMUIsTUFBTSxFQUFFYSxNQUFNQSxLQUFLMEQsS0FBSyxHQUFHZCxTQUFTaEIsTUFBTThCLEtBQUssR0FBRyxHQUFJQyxzQkFBc0IsRUFBRUUsWUFBWUYsb0JBQW9CLElBQUksQ0FBQyxFQUFHLEVBQUUsQ0FBQztBQUFBO0FBRTlNLGdCQUFNMUMsT0FBT3pCLFFBQVEsRUFBRUwsTUFBTSxFQUFFYSxNQUFNQSxLQUFLMEQsS0FBSyxHQUFHakIsWUFBWWYsVUFBVXNCLFdBQVdWLFlBQVlVLGFBQWEsSUFBSUosU0FBU2hCLE1BQU04QixLQUFLLEdBQUdiLGFBQWFmLFlBQVksTUFBTStCLFlBQVlGLG9CQUFvQixFQUFFLENBQUM7QUFDN01yQyxnQkFBUSxLQUFLO0FBQUEsTUFDakIsU0FDTzNCLEdBQUc7QUFDTixjQUFNbUUsVUFBVW5FLGFBQWFqQyxRQUFRaUMsRUFBRW1FLFVBQVU7QUFDakQzQixxQkFBYSxJQUFJekUsTUFBTWlHLHVCQUF1QkcsUUFBUUMsU0FBU0osbUJBQW1CLElBQUlHLFFBQVFFLFdBQVdMLHFCQUFxQixTQUFTLElBQUlHLE9BQU8sQ0FBQztBQUFBLE1BQ3ZKLFVBQUM7QUFFRzdCLGVBQU8sRUFBRTtBQUFBLE1BQ2I7QUFBQSxJQUNKLEdBQUcsNEJBbkJzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUIxTCxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPQyxhQUFhakIsT0FBT3hDLFNBQVN5QyxPQUFPekMsU0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BQUUsdUJBQUMsY0FBYWhCO0FBQUFBLG9CQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHNJQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdKO0FBQUEsUUFBUyx1QkFBQyxhQUFVLE9BQU0sZUFBYyxPQUFPdUMsTUFBTSxVQUFVLENBQUFMLE1BQUs4QixRQUFROUIsRUFBRXZDLE9BQU82RyxLQUFLLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUFFLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sMEJBQXlCLE9BQU92QyxVQUFVLFVBQVUsQ0FBQyxDQUFDSCxTQUFTLFVBQVUsQ0FBQTVCLE1BQUs7QUFBRWdDLHNCQUFZaEMsRUFBRXZDLE9BQU82RyxLQUFLO0FBQUdwQyxtQkFBUyxFQUFFO0FBQUEsUUFBRyxHQUFJYixrQkFBUW5DLE1BQU1BLEtBQUtpQixJQUFJLENBQUEwQyxNQUFLLHVCQUFDLFlBQVMsT0FBT0EsRUFBRUMsWUFBZ0NELFlBQUUwQixTQUFqQjFCLEVBQUVDLFlBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQsQ0FBVyxLQUF6UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJQO0FBQUEsUUFBWSx1QkFBQyxhQUFVLE9BQU0sZ0NBQStCLE9BQU9iLE9BQU8sVUFBVSxDQUFBakMsTUFBS2tDLFNBQVNsQyxFQUFFdkMsT0FBTzZHLEtBQUssR0FBRyxZQUFZM0IsWUFBWTZCLE9BQU9yRSxJQUFJLENBQUFzRSxNQUFLQSxFQUFFeEIsT0FBTyxFQUFFeUIsS0FBSyxJQUFJLEtBQUssNEJBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaU07QUFBQSxRQUFHLENBQUM5QyxXQUFXZSxZQUFZZ0Msb0JBQW9CLHVCQUFDLGFBQVUsT0FBTSx3Q0FBdUMsT0FBT3hDLFVBQVUsVUFBVSxDQUFBbkMsTUFBS29DLFlBQVlwQyxFQUFFdkMsT0FBTzZHLEtBQUssS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSDtBQUFBLFFBQUcsdUJBQUMsYUFBVSxPQUFPMUMsVUFBVSxzQ0FBc0MsWUFBWSxNQUFLLFlBQVcsY0FBYSxnQkFBZSxPQUFPUyxLQUFLLFVBQVUsQ0FBQXJDLE1BQUtzQyxPQUFPNUYsZ0JBQWdCc0QsRUFBRXZDLE9BQU82RyxPQUFPLEtBQUssQ0FBQyxLQUFsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9NO0FBQUEsUUFBRyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxtSEFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBQXZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStyQztBQUFBLFNBbkI1eEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CeXlDO0FBQUEsSUFDenlDLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDN0IsVUFBVSxPQUFNLGtCQUFpQixhQUFZLHFHQUFvRyxlQUFhLE1BQUMsU0FBUyxNQUFNQyxZQUFZLElBQUksR0FBRyxPQUFPbEIsT0FBTzFDLE9BQU8sTUFBTTBDLE9BQU9uQyxTQUFTLFdBQVcsWUFBWTtBQUNuUixVQUFJLENBQUNvRCxTQUFVO0FBQ2YsWUFBTWpCLE9BQU8zQixRQUFRLEVBQUVDLE1BQU0sRUFBRWdFLGNBQWNyQixTQUFTL0MsR0FBRyxHQUFHd0IsU0FBU3VCLFNBQVN2QixRQUFRLENBQUM7QUFBQSxJQUMzRixLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHSztBQUFBLE9BM0JLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkg7QUFDUjtBQUFDRSxJQXJDZUQsaUJBQWU7QUFBQSxVQUNWMUUsVUFDSkYsUUFBdUNBLFFBQ3JDQyxZQUFrRUEsWUFBa0VBLFlBQWdFQSxVQUFVO0FBQUE7QUFBQSxNQUhqTjJFO0FBQWUsSUFBQXlELElBQUFDO0FBQUEsYUFBQUQsSUFBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJBY3Rpb25Hcm91cCIsIkZvcm1GaWVsZHMiLCJQYWdlU2VjdGlvbnMiLCJTZWN0aW9uR3JpZCIsIlN1cmZhY2VDb250ZW50IiwidXNlU3RhdGUiLCJsYXlvdXRTeCIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiQ2hpcCIsIk1lbnVJdGVtIiwiVGV4dEZpZWxkIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwibGltaXRDb2RlUG9pbnRzIiwiZGF0ZVRpbWUiLCJDb25maXJtRGlhbG9nIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFbXB0eSIsIkVycm9yTm90aWNlIiwiTXV0YXRpb25CdXR0b24iLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJRdWVyeVN0YXRlIiwiUm91dGVMaW5rIiwiU3RhdHVzIiwiYXV0aG9yaXplIiwidXJsIiwidGFyZ2V0IiwiVVJMIiwibG9jYXRpb24iLCJvcmlnaW4iLCJwcm90b2NvbCIsIl9fTU9DS19fIiwiRXJyb3IiLCJhc3NpZ24iLCJocmVmIiwiQ2hhbm5lbHNQYWdlIiwiX3MiLCJzaG9wIiwibGlzdCIsImNvbm5lY3QiLCJyZWNvbm5lY3QiLCJkaXNjb25uZWN0IiwiY2hlY2siLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiam9iSWQiLCJzZXRKb2IiLCJlcnJvciIsInNldEVycm9yIiwiaXNFbXB0eSIsImlzRXJyb3IiLCJkYXRhIiwibGVuZ3RoIiwiY29ubmVjdEJ1dHRvbiIsInBlbmRpbmciLCJzdGFydCIsImNoYW5uZWxJZCIsImJvZHkiLCJyZXR1cm5QYXRoIiwiaWQiLCJjaGFubmVsS2luZCIsInIiLCJleGVjdXRlIiwicGF0aCIsImF1dGhvcml6YXRpb25VcmwiLCJlIiwibm90aWNlIiwiYWZ0ZXJHYXAiLCJtYXAiLCJjIiwibmFtZSIsInN0YXR1cyIsImV4dGVybmFsUGFnZUlkIiwibGFzdFdlYmhvb2tBdCIsInRpbWV6b25lIiwicG9saWN5VmVyc2lvbiIsInBvbGljeVZlcmlmaWVkQXQiLCJjYXBhYmlsaXRpZXMiLCJjYXAiLCJ3YXJuaW5ncyIsInciLCJyZWFzb24iLCJleHBlY3RlZFZlcnNpb24iLCJ2ZXJzaW9uIiwiQUlQcm92aWRlcnNQYWdlIiwiX3MyIiwiY2F0YWxvZyIsImNyZWF0ZSIsInVwZGF0ZSIsInJlbW92ZSIsInRlc3QiLCJvcGVuIiwic2V0T3BlbiIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwic2V0TmFtZSIsInByb3ZpZGVyIiwic2V0UHJvdmlkZXIiLCJtb2RlbCIsInNldE1vZGVsIiwiZW5kcG9pbnQiLCJzZXRFbmRwb2ludCIsImtleSIsInNldEtleSIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsImRlbGV0aW5nIiwic2V0RGVsZXRpbmciLCJkZXNjcmlwdG9yIiwiZmluZCIsInAiLCJwcm92aWRlcklkIiwiYWRkQ29ubmVjdGlvbkJ1dHRvbiIsImNvbm5lY3Rpb24iLCJtb2RlbElkIiwiZW5kcG9pbnRVcmwiLCJ4cyIsImxnIiwiYWRhcHRlcklkIiwiaGFzQ3JlZGVudGlhbCIsImtleUxhc3Q0IiwibGFzdENoZWNrZWRBdCIsIk9iamVjdCIsImVudHJpZXMiLCJmaWx0ZXIiLCJrIiwidiIsImNvbm5lY3Rpb25JZCIsInRyaW0iLCJzdWJtaXR0ZWRDcmVkZW50aWFsIiwic3RhcnRzV2l0aCIsImNyZWRlbnRpYWwiLCJtZXNzYWdlIiwiaW5jbHVkZXMiLCJyZXBsYWNlQWxsIiwidmFsdWUiLCJsYWJlbCIsIm1vZGVscyIsIm0iLCJqb2luIiwiZW5kcG9pbnRFZGl0YWJsZSIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpb25Hcm91cCwgRm9ybUZpZWxkcywgUGFnZVNlY3Rpb25zLCBTZWN0aW9uR3JpZCwgU3VyZmFjZUNvbnRlbnQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9sYXlvdXQnO1xuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBDaGlwLCBNZW51SXRlbSwgVGV4dEZpZWxkIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgdHlwZSB7IEFJQ29ubmVjdGlvbiwgQ2hhbm5lbCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgdXNlQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnLi4vLi4vc2hhcmVkL2FwaS9ob29rcyc7XG5pbXBvcnQgeyB1c2VTY29wZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyBsaW1pdENvZGVQb2ludHMsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcbmltcG9ydCB7IENvbmZpcm1EaWFsb2csIERldGFpbExpbmUsIEVkaXREaWFsb2csIEVtcHR5LCBFcnJvck5vdGljZSwgTXV0YXRpb25CdXR0b24sIFBhZ2VIZWFkZXIsIFBhbmVsLCBRdWVyeVN0YXRlLCBSb3V0ZUxpbmssIFN0YXR1cyB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb25lbnRzJztcbi8qKiBUaGUgYmFja2VuZCBzdXBwbGllcyB0aGUgcHJvdmlkZXIgVVJMOyB0aGUgYnJvd3NlciBzdGlsbCByZWZ1c2VzIHVuc2FmZSBzY2hlbWVzLiAqL1xuZnVuY3Rpb24gYXV0aG9yaXplKHVybDogc3RyaW5nKSB7IGNvbnN0IHRhcmdldCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5vcmlnaW4pOyBpZiAodGFyZ2V0LnByb3RvY29sICE9PSAnaHR0cHM6JyAmJiAhKF9fTU9DS19fICYmIHRhcmdldC5vcmlnaW4gPT09IGxvY2F0aW9uLm9yaWdpbikpXG4gICAgdGhyb3cgbmV3IEVycm9yKCfEkMaw4budbmcgZOG6q24geMOhYyB0aOG7sWMga2jDtG5nIGTDuW5nIEhUVFBTLicpOyBsb2NhdGlvbi5hc3NpZ24odGFyZ2V0LmhyZWYpOyB9XG5leHBvcnQgZnVuY3Rpb24gQ2hhbm5lbHNQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0Q2hhbm5lbHMnKTtcbiAgICBjb25zdCBjb25uZWN0ID0gdXNlQ29tbWFuZCgnYmVnaW5DaGFubmVsQ29ubmVjdCcsIFtdKSwgcmVjb25uZWN0ID0gdXNlQ29tbWFuZCgncmVjb25uZWN0Q2hhbm5lbCcsIFtdKSwgZGlzY29ubmVjdCA9IHVzZUNvbW1hbmQoJ2Rpc2Nvbm5lY3RDaGFubmVsJywgWydsaXN0Q2hhbm5lbHMnXSksIGNoZWNrID0gdXNlQ29tbWFuZCgnY2hlY2tDaGFubmVsSGVhbHRoJywgWydsaXN0Q2hhbm5lbHMnXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxDaGFubmVsIHwgbnVsbD4obnVsbCksIFtqb2JJZCwgc2V0Sm9iXSA9IHVzZVN0YXRlKCcnKSwgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGlzRW1wdHkgPSAhbGlzdC5pc0Vycm9yICYmIGxpc3QuZGF0YT8uZGF0YS5sZW5ndGggPT09IDA7XG4gICAgY29uc3QgY29ubmVjdEJ1dHRvbiA9IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtjb25uZWN0LnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnQoKX0+S+G6v3QgbuG7kWkgUGFnZTwvTXV0YXRpb25CdXR0b24+O1xuICAgIGNvbnN0IHN0YXJ0ID0gYXN5bmMgKGNoYW5uZWxJZD86IHN0cmluZykgPT4geyBzZXRFcnJvcihudWxsKTsgdHJ5IHtcbiAgICAgICAgY29uc3QgYm9keSA9IHsgcmV0dXJuUGF0aDogYC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2NoYW5uZWxzYCwgY2hhbm5lbEtpbmQ6ICdmYWNlYm9va19tZXNzZW5nZXInIGFzIGNvbnN0IH07XG4gICAgICAgIGNvbnN0IHIgPSBjaGFubmVsSWQgPyBhd2FpdCByZWNvbm5lY3QuZXhlY3V0ZSh7IHBhdGg6IHsgY2hhbm5lbElkIH0sIGJvZHkgfSkgOiBhd2FpdCBjb25uZWN0LmV4ZWN1dGUoeyBib2R5IH0pO1xuICAgICAgICBhdXRob3JpemUoci5kYXRhLmF1dGhvcml6YXRpb25VcmwpO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgdGjhu4MgYuG6r3QgxJHhuqd1IHjDoWMgdGjhu7FjLicpKTtcbiAgICB9IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJL4bq/dCBu4buRaSBGYWNlYm9va1wiIHN1YnRpdGxlPVwiS+G6v3QgbuG7kWkgYuG6sW5nIGx14buTbmcgY+G6pXAgcXV54buBbi4gUGFnZSB0b2tlbiBjaOG7iSDEkcaw4bujYyBnaeG7ryDhu58gYmFja2VuZC5cIiBhY3Rpb25zPXshaXNFbXB0eSAmJiBjb25uZWN0QnV0dG9ufS8+PEVycm9yTm90aWNlIGVycm9yPXtlcnJvciB8fCBjb25uZWN0LmVycm9yIHx8IHJlY29ubmVjdC5lcnJvciB8fCBjaGVjay5lcnJvcn0vPntfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+xJDDonkgbMOgIG3DtCBwaOG7j25nLiBLaMO0bmcgxJHEg25nIG5o4bqtcCBGYWNlYm9vayB2w6Aga2jDtG5nIGfhu61pIHRpbiB0aOG6rXQuPC9BbGVydD59PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAwICYmICFsaXN0LmlzRXJyb3IgPyA8RW1wdHkgdGV4dD1cIkNoxrBhIGPDsyBQYWdlIGvhur90IG7hu5FpLiBEw7luZyBuw7p0IGLDqm4gZMaw4bubaSDEkeG7gyBi4bqvdCDEkeG6p3UuXCIgYWN0aW9uPXtjb25uZWN0QnV0dG9ufS8+IDogPFBhZ2VTZWN0aW9ucyA+e2xpc3QuZGF0YT8uZGF0YS5tYXAoYyA9PiA8UGFuZWwga2V5PXtjLmlkfSB0aXRsZT17Yy5uYW1lfSBib2R5TW9kZT1cImluc2V0XCIgYWN0aW9uPXtfX01PQ0tfXyA/IDxDaGlwIGxhYmVsPVwiTcO0IHBo4buPbmcsIGNoxrBhIGxpw6puIGvhur90IHRo4bqtdFwiIGNvbG9yPVwid2FybmluZ1wiIHZhcmlhbnQ9XCJvdXRsaW5lZFwiLz4gOiA8U3RhdHVzIHZhbHVlPXtjLnN0YXR1c30vPn0+PEJveD48RGV0YWlsTGluZSBsYWJlbD1cIlBhZ2UgSURcIj57Yy5leHRlcm5hbFBhZ2VJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJXZWJob29rIGfhuqduIG5o4bqldFwiPntkYXRlVGltZShjLmxhc3RXZWJob29rQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPntjLnBvbGljeVZlcnNpb24gfHwgJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiS2nhu4NtIGNow61uaCBzw6FjaCBsw7pjXCI+e2RhdGVUaW1lKGMucG9saWN5VmVyaWZpZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPjxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiBiZWZvcmVHYXA9XCJzdXJmYWNlXCIgYWZ0ZXJHYXA9XCJub3RpY2VcIj57Yy5jYXBhYmlsaXRpZXMubWFwKGNhcCA9PiA8Q2hpcCBsYWJlbD17Y2FwfSBrZXk9e2NhcH0vPil9PC9BY3Rpb25Hcm91cD57Yy53YXJuaW5ncy5tYXAodyA9PiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCIga2V5PXt3fSBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT57d308L0FsZXJ0Pil9PEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiID48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBidXN5PXtjaGVjay5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XG4gICAgICAgIHNldEpvYigoYXdhaXQgY2hlY2suZXhlY3V0ZSh7IHBhdGg6IHsgY2hhbm5lbElkOiBjLmlkIH0gfSkpLmRhdGEuaWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5LaeG7g20ga+G6v3QgbuG7kWk8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGJ1c3k9e3JlY29ubmVjdC5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHN0YXJ0KGMuaWQpfT5L4bq/dCBu4buRaSBs4bqhaTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJpbnRlZ3JhdGlvbnMubWFuYWdlXCIgY29sb3I9XCJlcnJvclwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKGMpfT5OZ+G6r3Qga+G6v3QgbuG7kWk8L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+PC9Cb3g+PC9QYW5lbD4pfTwvUGFnZVNlY3Rpb25zPn08L1F1ZXJ5U3RhdGU+e2pvYklkICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2pvYnMvJHtqb2JJZH1gfT5YZW0ga+G6v3QgcXXhuqMga2nhu4NtIHRyYTwvUm91dGVMaW5rPn08Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT1cIk5n4bqvdCBr4bq/dCBu4buRaSBQYWdlXCIgZGVzY3JpcHRpb249XCJE4burbmcgZ+G7rWkgbeG7m2kgdsOgIHRodSBo4buTaSBr4bq/dCBu4buRaSDhu58gYmFja2VuZC4gS2jDtG5nIHjDs2EgbOG7i2NoIHPhu60gxJHGoW4gaMOgbmcvaOG7mWkgdGhv4bqhaS5cIiByZXF1aXJlUmVhc29uIG9uQ2xvc2U9eygpID0+IHNldFNlbGVjdGVkKG51bGwpfSBidXN5PXtkaXNjb25uZWN0LnBlbmRpbmd9IGVycm9yPXtkaXNjb25uZWN0LmVycm9yfSBvbkNvbmZpcm09e3JlYXNvbiA9PiBkaXNjb25uZWN0LmV4ZWN1dGUoeyBwYXRoOiB7IGNoYW5uZWxJZDogc2VsZWN0ZWQ/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzZWxlY3RlZD8udmVyc2lvbiB8fCAxLCByZWFzb24gfSB9KX0vPjwvPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBBSVByb3ZpZGVyc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RBSUNvbm5lY3Rpb25zJyksIGNhdGFsb2cgPSB1c2VBcGkoJ2dldFByb3ZpZGVyQ2F0YWxvZycpO1xuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnXSksIHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZUFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnXSksIHJlbW92ZSA9IHVzZUNvbW1hbmQoJ2RlbGV0ZUFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnXSksIHRlc3QgPSB1c2VDb21tYW5kKCd0ZXN0QUlDb25uZWN0aW9uJywgWydsaXN0QUlDb25uZWN0aW9ucyddKTtcbiAgICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSksIFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPEFJQ29ubmVjdGlvbiB8IG51bGw+KG51bGwpLCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJyksIFtwcm92aWRlciwgc2V0UHJvdmlkZXJdID0gdXNlU3RhdGUoJycpLCBbbW9kZWwsIHNldE1vZGVsXSA9IHVzZVN0YXRlKCcnKSwgW2VuZHBvaW50LCBzZXRFbmRwb2ludF0gPSB1c2VTdGF0ZSgnJyksIFtrZXksIHNldEtleV0gPSB1c2VTdGF0ZSgnJyksIFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpLCBbZGVsZXRpbmcsIHNldERlbGV0aW5nXSA9IHVzZVN0YXRlPEFJQ29ubmVjdGlvbiB8IG51bGw+KG51bGwpLCBbam9iSWQsIHNldEpvYl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgZGVzY3JpcHRvciA9IGNhdGFsb2cuZGF0YT8uZGF0YS5maW5kKHAgPT4gcC5wcm92aWRlcklkID09PSBwcm92aWRlcik7XG4gICAgY29uc3QgaXNFbXB0eSA9ICFsaXN0LmlzRXJyb3IgJiYgbGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMDtcbiAgICBjb25zdCBhZGRDb25uZWN0aW9uQnV0dG9uID0gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJpbnRlZ3JhdGlvbnMubWFuYWdlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHN0YXJ0KG51bGwpfT5UaMOqbSBr4bq/dCBu4buRaSBBSTwvTXV0YXRpb25CdXR0b24+O1xuICAgIGNvbnN0IHN0YXJ0ID0gKGNvbm5lY3Rpb246IEFJQ29ubmVjdGlvbiB8IG51bGwpID0+IHsgc2V0RWRpdGluZyhjb25uZWN0aW9uKTsgc2V0TmFtZShjb25uZWN0aW9uPy5uYW1lIHx8ICcnKTsgc2V0UHJvdmlkZXIoY29ubmVjdGlvbj8ucHJvdmlkZXJJZCB8fCBjYXRhbG9nLmRhdGE/LmRhdGFbMF0/LnByb3ZpZGVySWQgfHwgJycpOyBzZXRNb2RlbChjb25uZWN0aW9uPy5tb2RlbElkIHx8ICcnKTsgc2V0RW5kcG9pbnQoY29ubmVjdGlvbj8uZW5kcG9pbnRVcmwgfHwgJycpOyBzZXRLZXkoJycpOyBzZXRGb3JtRXJyb3IobnVsbCk7IHNldE9wZW4odHJ1ZSk7IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaMOgIGN1bmcgY+G6pXAgQUlcIiBzdWJ0aXRsZT1cIk3hu5dpIGFkYXB0ZXIgY8O0bmcgYuG7kSBraOG6oyBuxINuZzsga2jDtG5nIGdp4bqjIMSR4buLbmggbeG7jWkgQVBJIGtleSBjw7MgdGjhu4MgdGhheSB0aOG6vyBuaGF1LlwiIGFjdGlvbnM9eyFpc0VtcHR5ICYmIGFkZENvbm5lY3Rpb25CdXR0b259Lz48RXJyb3JOb3RpY2UgZXJyb3I9e3Rlc3QuZXJyb3J9Lz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YT8uZGF0YS5sZW5ndGggPT09IDAgJiYgIWxpc3QuaXNFcnJvciA/IDxFbXB0eSB0ZXh0PVwiQ2jGsGEgY8OzIGvhur90IG7hu5FpIEFJLiBUaMOqbSBt4buZdCBr4bq/dCBu4buRaSDEkeG7gyBj4bqldSBow6xuaCBuaMOgIGN1bmcgY+G6pXAuXCIgYWN0aW9uPXthZGRDb25uZWN0aW9uQnV0dG9ufS8+IDogPFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICdtaW5tYXgoMCwgMWZyKScsIGxnOiBsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAxID8gJ21pbm1heCgwLCAxZnIpJyA6ICdyZXBlYXQoMiwgbWlubWF4KDAsIDFmcikpJyB9fT57bGlzdC5kYXRhPy5kYXRhLm1hcChjID0+IDxQYW5lbCBrZXk9e2MuaWR9IHRpdGxlPXtjLm5hbWV9IGJvZHlNb2RlPVwiaW5zZXRcIiBhY3Rpb249ezxTdGF0dXMgdmFsdWU9e2Muc3RhdHVzfS8+fT48Qm94PjxEZXRhaWxMaW5lIGxhYmVsPVwiUHJvdmlkZXIgLyBhZGFwdGVyXCI+e2MucHJvdmlkZXJJZH0gLyB7Yy5hZGFwdGVySWR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTW9kZWxcIj57Yy5tb2RlbElkfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIktow7NhXCI+e2MuaGFzQ3JlZGVudGlhbCA/IGDigKLigKLigKLigKIgJHtjLmtleUxhc3Q0IHx8ICcnfWAgOiAnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJM4bqnbiBraeG7g20gZ+G6p24gbmjhuqV0XCI+e2RhdGVUaW1lKGMubGFzdENoZWNrZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPjxTdXJmYWNlQ29udGVudCByaHl0aG09XCJkaXZpZGVkUm93c1wiIGJlZm9yZUdhcD1cInN1cmZhY2VcIiBhZnRlckdhcD1cIm5vdGljZVwiPntPYmplY3QuZW50cmllcyhjLmNhcGFiaWxpdGllcykuZmlsdGVyKChba10pID0+IGsgIT09ICdsYXN0VmVyaWZpZWRBdCcpLm1hcCgoW2ssIHZdKSA9PiA8RGV0YWlsTGluZSBrZXk9e2t9IGxhYmVsPXtrfT57dHlwZW9mIHYgPT09ICdzdHJpbmcnID8gdiA6ICdDaMawYSByw7UnfTwvRGV0YWlsTGluZT4pfTwvU3VyZmFjZUNvbnRlbnQ+PEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiID48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBvbkNsaWNrPXsoKSA9PiBzdGFydChjKX0+U+G7rWEgLyB4b2F5IGtow7NhPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBidXN5PXt0ZXN0LnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgc2V0Sm9iKChhd2FpdCB0ZXN0LmV4ZWN1dGUoeyBwYXRoOiB7IGNvbm5lY3Rpb25JZDogYy5pZCB9IH0pKS5kYXRhLmlkKTtcbiAgICB9XG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+S2nhu4NtIGvhur90IG7hu5FpPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBjb2xvcj1cImVycm9yXCIgb25DbGljaz17KCkgPT4gc2V0RGVsZXRpbmcoYyl9PljDs2E8L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+PC9Cb3g+PC9QYW5lbD4pfTwvU2VjdGlvbkdyaWQ+fTwvUXVlcnlTdGF0ZT57am9iSWQgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2pvYklkfWB9Pkvhur90IHF14bqjIGtp4buDbSB0cmEga+G6v3QgbuG7kWk8L1JvdXRlTGluaz59XG4gPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9e2VkaXRpbmcgPyAnU+G7rWEga+G6v3QgbuG7kWkgLyB4b2F5IGtow7NhJyA6ICdL4bq/dCBu4buRaSBBSSBt4bubaSd9IG9uQ2xvc2U9eygpID0+IHsgc2V0S2V5KCcnKTsgc2V0Rm9ybUVycm9yKG51bGwpOyBzZXRPcGVuKGZhbHNlKTsgfX0gYnVzeT17Y3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshbmFtZS50cmltKCkgfHwgIW1vZGVsLnRyaW0oKSB8fCAoIWVkaXRpbmcgJiYgKCFkZXNjcmlwdG9yIHx8ICFrZXkpKSB8fCBjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRGb3JtRXJyb3IobnVsbCk7XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZENyZWRlbnRpYWwgPSBrZXk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoX19NT0NLX18gJiYgc3VibWl0dGVkQ3JlZGVudGlhbCAmJiAhc3VibWl0dGVkQ3JlZGVudGlhbC5zdGFydHNXaXRoKCdkZW1vLScpKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2jhu4kgbmjhuq1wIGtow7NhIGdp4bqjIGLhuq90IMSR4bqndSBi4bqxbmcgZGVtby0gdHJvbmcgYuG6o24gbcO0IHBo4buPbmcuJyk7XG4gICAgICAgICAgICBpZiAoZWRpdGluZylcbiAgICAgICAgICAgICAgICBhd2FpdCB1cGRhdGUuZXhlY3V0ZSh7IHBhdGg6IHsgY29ubmVjdGlvbklkOiBlZGl0aW5nLmlkIH0sIHZlcnNpb246IGVkaXRpbmcudmVyc2lvbiwgYm9keTogeyBuYW1lOiBuYW1lLnRyaW0oKSwgbW9kZWxJZDogbW9kZWwudHJpbSgpLCAuLi4oc3VibWl0dGVkQ3JlZGVudGlhbCA/IHsgY3JlZGVudGlhbDogc3VibWl0dGVkQ3JlZGVudGlhbCB9IDoge30pIH0gfSk7XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IG5hbWU6IG5hbWUudHJpbSgpLCBwcm92aWRlcklkOiBwcm92aWRlciwgYWRhcHRlcklkOiBkZXNjcmlwdG9yPy5hZGFwdGVySWQgfHwgJycsIG1vZGVsSWQ6IG1vZGVsLnRyaW0oKSwgZW5kcG9pbnRVcmw6IGVuZHBvaW50IHx8IG51bGwsIGNyZWRlbnRpYWw6IHN1Ym1pdHRlZENyZWRlbnRpYWwgfSB9KTtcbiAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogJ0tow7RuZyBsxrB1IMSRxrDhu6NjIGPhuqV1IGjDrG5oIGvhur90IG7hu5FpLic7XG4gICAgICAgICAgICBzZXRGb3JtRXJyb3IobmV3IEVycm9yKHN1Ym1pdHRlZENyZWRlbnRpYWwgJiYgbWVzc2FnZS5pbmNsdWRlcyhzdWJtaXR0ZWRDcmVkZW50aWFsKSA/IG1lc3NhZ2UucmVwbGFjZUFsbChzdWJtaXR0ZWRDcmVkZW50aWFsLCAnW8SRw6Mg4bqpbl0nKSA6IG1lc3NhZ2UpKTtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEtleSgnJyk7XG4gICAgICAgIH1cbiAgICB9fT5MxrB1IGPhuqV1IGjDrG5oPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2Zvcm1FcnJvciB8fCBjcmVhdGUuZXJyb3IgfHwgdXBkYXRlLmVycm9yfS8+PEZvcm1GaWVsZHMgPntfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+S2jDtG5nIG5o4bqtcCBraMOzYSB0aOG6rXQuIETDuW5nIGRlbW8ta2V5OyByZXF1ZXN0IG3DtCBwaOG7j25nIGNo4buJIGtp4buDbSB0cmEgZ2lhbyBkaeG7h24sIGtow7RuZyBnaeG7ryBraMOzYSB2w6Aga2jDtG5nIGvhur90IG7hu5FpIEFJIHRo4bqtdC48L0FsZXJ0Pn08VGV4dEZpZWxkIGxhYmVsPVwiVMOqbiBr4bq/dCBu4buRaVwiIHZhbHVlPXtuYW1lfSBvbkNoYW5nZT17ZSA9PiBzZXROYW1lKGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiUHJvdmlkZXIgxJHDoyBjw7MgYWRhcHRlclwiIHZhbHVlPXtwcm92aWRlcn0gZGlzYWJsZWQ9eyEhZWRpdGluZ30gb25DaGFuZ2U9e2UgPT4geyBzZXRQcm92aWRlcihlLnRhcmdldC52YWx1ZSk7IHNldE1vZGVsKCcnKTsgfX0+e2NhdGFsb2cuZGF0YT8uZGF0YS5tYXAocCA9PiA8TWVudUl0ZW0gdmFsdWU9e3AucHJvdmlkZXJJZH0ga2V5PXtwLnByb3ZpZGVySWR9PntwLmxhYmVsfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48VGV4dEZpZWxkIGxhYmVsPVwiTW9kZWwgSUQgxJHGsOG7o2MgYWRhcHRlciBo4buXIHRy4bujXCIgdmFsdWU9e21vZGVsfSBvbkNoYW5nZT17ZSA9PiBzZXRNb2RlbChlLnRhcmdldC52YWx1ZSl9IGhlbHBlclRleHQ9e2Rlc2NyaXB0b3I/Lm1vZGVscy5tYXAobSA9PiBtLm1vZGVsSWQpLmpvaW4oJywgJykgfHwgJ1hlbSBjYXRhbG9nIHThu6sgYmFja2VuZCd9Lz57IWVkaXRpbmcgJiYgZGVzY3JpcHRvcj8uZW5kcG9pbnRFZGl0YWJsZSAmJiA8VGV4dEZpZWxkIGxhYmVsPVwiRW5kcG9pbnQgSFRUUFMgxJHGsOG7o2MgYmFja2VuZCBjaG8gcGjDqXBcIiB2YWx1ZT17ZW5kcG9pbnR9IG9uQ2hhbmdlPXtlID0+IHNldEVuZHBvaW50KGUudGFyZ2V0LnZhbHVlKX0vPn08VGV4dEZpZWxkIGxhYmVsPXtlZGl0aW5nID8gJ0tow7NhIG3hu5tpICjEkeG7gyB0cuG7kW5nIMSR4buDIGdp4buvIG5ndXnDqm4pJyA6ICdLaMOzYSBBUEknfSB0eXBlPVwicGFzc3dvcmRcIiBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIiB2YWx1ZT17a2V5fSBvbkNoYW5nZT17ZSA9PiBzZXRLZXkobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAxNjM4NCkpfSAvPjxBbGVydCBzZXZlcml0eT1cImluZm9cIj5TZWNyZXQgY2jhu4kgxJHGsOG7o2MgZ+G7rWkgdGhlbyB0csaw4budbmcgd3JpdGVPbmx5IGPhu6dhIGNvbnRyYWN0LiBSZXNwb25zZSB2w6AgZGFuaCBzw6FjaCBraMO0bmcgdHLhuqMgc2VjcmV0IGfhu5FjLjwvQWxlcnQ+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz5cbiA8Q29uZmlybURpYWxvZyBvcGVuPXshIWRlbGV0aW5nfSB0aXRsZT1cIljDs2Ega+G6v3QgbuG7kWkgQUlcIiBkZXNjcmlwdGlvbj1cIkJhY2tlbmQga2nhu4NtIGPDoWMgY+G6pXUgaMOsbmggxJFhbmcgc+G7rSBk4bulbmcgdHLGsOG7m2Mga2hpIHjDs2E7IGtow7RuZyB04buxIGNodXnhu4NuIGThu68gbGnhu4d1IHNhbmcgcHJvdmlkZXIga2jDoWMuXCIgcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXREZWxldGluZyhudWxsKX0gZXJyb3I9e3JlbW92ZS5lcnJvcn0gYnVzeT17cmVtb3ZlLnBlbmRpbmd9IG9uQ29uZmlybT17YXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWRlbGV0aW5nKSByZXR1cm47XG4gICAgICAgIGF3YWl0IHJlbW92ZS5leGVjdXRlKHsgcGF0aDogeyBjb25uZWN0aW9uSWQ6IGRlbGV0aW5nLmlkIH0sIHZlcnNpb246IGRlbGV0aW5nLnZlcnNpb24gfSk7XG4gICAgfX0vPjwvPjtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2ludGVncmF0aW9ucy9pbmRleC50c3gifQ==