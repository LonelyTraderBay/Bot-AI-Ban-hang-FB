"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-TJQ5SMJY.js?v=865c61ce";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-YVU6SLE6.js?v=865c61ce";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-TQYMLHGU.js?v=865c61ce";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-FJYLEWCQ.js?v=865c61ce";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-QF5IVN5P.js?v=865c61ce";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-QU3FZV7L.js?v=865c61ce";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27532-d4311257-69ad-4e22-b7b2-dfb63f97db0f/deps/chunk-PX6F3LHL.js?v=865c61ce";

// ../../node_modules/@mui/icons-material/esm/SmartphoneRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var SmartphoneRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M17 1.01 7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99M17 19H7V5h10z"
}), "SmartphoneRounded");
export {
  SmartphoneRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_SmartphoneRounded.js.map
