"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-TJQ5SMJY.js?v=13ddee04";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-YVU6SLE6.js?v=13ddee04";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-TQYMLHGU.js?v=13ddee04";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-FJYLEWCQ.js?v=13ddee04";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-QF5IVN5P.js?v=13ddee04";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-QU3FZV7L.js?v=13ddee04";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/chunk-PX6F3LHL.js?v=13ddee04";

// ../../node_modules/@mui/icons-material/esm/SmartphoneRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var SmartphoneRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M17 1.01 7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99M17 19H7V5h10z"
}), "SmartphoneRounded");
export {
  SmartphoneRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_SmartphoneRounded.js.map
