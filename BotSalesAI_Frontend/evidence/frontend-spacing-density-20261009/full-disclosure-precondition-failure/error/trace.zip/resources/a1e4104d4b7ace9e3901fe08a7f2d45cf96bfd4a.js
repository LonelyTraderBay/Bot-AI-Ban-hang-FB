import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/notifications/index.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "demo", "PROD": false, "SSR": false, "VITE_APP_NAME": "BotSales AI", "VITE_WEB_PUSH_PUBLIC_KEY": ""};import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/react_jsx-dev-runtime.js?v=f338fbf6"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { ActionGroup, FieldGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport7_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/react.js?v=f338fbf6"; const useEffect = __vite__cjsImport7_react["useEffect"]; const useState = __vite__cjsImport7_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Alert, Box, Button, Checkbox, FormControlLabel, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/@mui_material.js?v=a5266ff2";
import NotificationsActiveRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/@mui_icons-material_NotificationsActiveRounded.js?v=4e5086ed";
import SmartphoneRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-27596-e82f836e-247e-47ae-88e7-f9f3235fa328/deps/@mui_icons-material_SmartphoneRounded.js?v=e2119a7f";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, MutationButton, ErrorNotice, ConfirmDialog, RouteLink, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { assertPushCapability, assertPushPermissionGranted } from "/src/modules/notifications/push-capabilities.ts";
export function NotificationsPage() {
  _s();
  const { shop, session } = useScope();
  const list = useApi("listNotifications", { query: useListQuery("listNotifications") });
  const ack = useCommand("acknowledgeNotification", ["listNotifications", "listWorkItems", "listPrepJobs", "getOperationsSummary"]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Trung tâm thông báo", subtitle: "Đã gửi không đồng nghĩa đã đọc. Nhận việc là một xác nhận riêng.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/notifications/devices`, children: "Điện thoại & lịch trực" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 42,
      columnNumber: 137
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 42,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: ack.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 42,
      columnNumber: 229
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listNotifications" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 42,
        columnNumber: 269
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "inset", children: [
        list.data?.data.map((n) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.surface.inset, {
          border: 1,
          borderColor: n.acknowledgedAt ? "divider" : colors.heroBorder,
          borderRadius: visualSx.radius.large,
          bgcolor: n.acknowledgedAt ? "transparent" : colors.selected
        }], children: /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: { xs: "column", md: "row" }, justifyContent: "space-between", children: [
          /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: "row", children: [
            /* @__PURE__ */ jsxDEV(NotificationsActiveRounded, { sx: { color: "primary.main" } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 44,
              columnNumber: 134
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", children: n.title }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 44,
                columnNumber: 200
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.pageHeader.titleDescriptionGap, children: n.safeBody }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 44,
                columnNumber: 247
              }, this),
              /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "detail", children: [
                /* @__PURE__ */ jsxDEV(Status, { value: n.deliveryStatus }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 44,
                  columnNumber: 400
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { alignSelf: "center" }, children: [
                  n.channel,
                  " · ",
                  dateTime(n.createdAt, shop.timezone)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 44,
                  columnNumber: 435
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 44,
                columnNumber: 352
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: [layoutSx.detail.relatedContentGap, { display: "block" }], children: n.acknowledgedAt ? `Đã nhận việc lúc ${dateTime(n.acknowledgedAt, shop.timezone)}` : n.openedAt ? "Có ghi nhận mở thông báo; chưa nhận việc." : "Chưa có bằng chứng đã mở hoặc nhận việc." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 44,
                columnNumber: 573
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 44,
              columnNumber: 195
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 44,
            columnNumber: 102
          }, this),
          /* @__PURE__ */ jsxDEV(SurfaceContent, { justifyContent: "center", children: [
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "operations.claim", allowedActions: n.allowedActions, action: "acknowledge", disabled: !n.workItemId || n.recipientUserId !== session.user.id, busy: ack.pending, variant: "contained", onClick: () => void ack.execute({ path: { resourceId: n.id }, body: { expectedVersion: n.version } }).catch(() => void 0), children: "Tôi nhận chuẩn bị đơn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 44,
              columnNumber: 953
            }, this),
            n.source.type === "order" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${n.source.id}`, children: "Xem đơn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 44,
              columnNumber: 1353
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 44,
            columnNumber: 913
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 44,
          columnNumber: 15
        }, this) }, n.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 42,
          columnNumber: 396
        }, this)),
        list.data?.data.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: "Chưa có thông báo. Thông báo chuẩn bị được tạo sau khi đơn đã xác nhận và giữ hàng thành công." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 44,
          columnNumber: 1502
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data?.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 44,
          columnNumber: 1642
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 42,
        columnNumber: 335
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 42,
        columnNumber: 310
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 42,
      columnNumber: 262
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
}
_s(NotificationsPage, "le1+xAz05rHsK3CLbiKrCqiZCVw=", false, function() {
  return [useScope, useApi, useListQuery, useCommand];
});
_c = NotificationsPage;
function base64Bytes(value) {
  const padded = (value + "=".repeat((4 - value.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(padded);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++)
    bytes[i] = raw.charCodeAt(i);
  return bytes;
}
function validatePolicy(input) {
  const reminder = input.minutes.trim();
  const maximum = input.max.trim();
  if (maximum === "" || !Number.isSafeInteger(Number(maximum)) || Number(maximum) < 0)
    return "Số lần nhắc tối đa phải là số nguyên từ 0 trở lên.";
  if (reminder && (!Number.isSafeInteger(Number(reminder)) || Number(reminder) < 1))
    return "Thời gian nhắc phải là số nguyên từ 1 phút trở lên.";
  if (input.enabled && !reminder)
    return "Cần nhập thời gian nhắc khi bật quy tắc.";
  if (input.enabled && !input.primary.length)
    return "Cần chọn ít nhất một người nhận chính khi bật quy tắc.";
  if (input.quiet && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.quietStart) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(input.quietEnd)))
    return "Giờ yên lặng cần có thời điểm bắt đầu và kết thúc hợp lệ.";
  if (input.channel === "telegram" && !input.telegramAvailable)
    return "Chưa có thiết bị Telegram active. Hoàn tất liên kết thật trước khi chọn kênh này.";
  return "";
}
export function DevicesPage() {
  _s2();
  const { shop, session } = useScope();
  const devices = usePagedApi("listDevices");
  const policy = useApi("getNotificationPolicy");
  const canManageMembers = useCan("members.manage");
  const [memberSearchInput, setMemberSearchInput] = useState(""), [memberSearch, setMemberSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setMemberSearch(memberSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [memberSearchInput]);
  const members = usePagedApi("listMembers", { query: { q: memberSearch || void 0 } }, canManageMembers);
  const register = useCommand("createDevice", ["listDevices"]);
  const test = useCommand("testDevice", ["listDevices", "listNotifications"]);
  const revoke = useCommand("revokeDevice", ["listDevices"]);
  const save = useCommand("updateNotificationPolicy", ["getNotificationPolicy"]);
  const pair = useCommand("beginTelegramPairing", []);
  const [deviceName, setDeviceName] = useState("Điện thoại của tôi"), [error, setError] = useState(null), [pending, setPending] = useState(false), [selected, setSelected] = useState(null), [pairing, setPairing] = useState(null), [deviceTestMessage, setDeviceTestMessage] = useState("");
  const [enabled, setEnabled] = useState(false), [minutes, setMinutes] = useState(""), [max, setMax] = useState("2"), [quiet, setQuiet] = useState(false), [quietStart, setQuietStart] = useState("22:00"), [quietEnd, setQuietEnd] = useState("08:00"), [primary, setPrimary] = useState([]), [fallback, setFallback] = useState([]), [channel, setChannel] = useState("none"), [urgent, setUrgent] = useState(false);
  const editor = useVersionedDraft({
    identity: `${shop.id}:notification-policy`,
    source: policy.data ? notificationSnapshot(policy.data.data) : void 0,
    draft: { enabled, minutes, max, quiet, quietStart, quietEnd, primary, fallback, channel, urgent },
    apply: (values) => {
      setEnabled(values.enabled);
      setMinutes(values.minutes);
      setMax(values.max);
      setQuiet(values.quiet);
      setQuietStart(values.quietStart);
      setQuietEnd(values.quietEnd);
      setPrimary(values.primary);
      setFallback(values.fallback);
      setChannel(values.channel);
      setUrgent(values.urgent);
    },
    refresh: () => policy.refetch({ throwOnError: true })
  });
  const policyForm = useDraftForm(editor.dirty);
  const deviceRegister = async () => {
    setError(null);
    setPending(true);
    try {
      if (__MOCK__) {
        await register.execute({ body: { deviceName: deviceName.trim(), endpoint: "https://example.test/mock-push", p256dh: "synthetic-device-public-key", auth: "synthetic-device-auth" } });
        return;
      }
      assertPushCapability({ secureContext: window.isSecureContext, serviceWorker: "serviceWorker" in navigator, pushManager: "PushManager" in window, notification: "Notification" in window });
      const key = import.meta.env.VITE_WEB_PUSH_PUBLIC_KEY;
      if (!key)
        throw new Error("Chưa có khóa VAPID công khai từ backend trong VITE_WEB_PUSH_PUBLIC_KEY.");
      assertPushPermissionGranted(await Notification.requestPermission());
      const service = await navigator.serviceWorker.register("/app-sw.js", { scope: "/" });
      await navigator.serviceWorker.ready;
      const subscription = await service.pushManager.getSubscription() || await service.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: base64Bytes(key) });
      const json = subscription.toJSON();
      if (!json.endpoint || !json.keys?.p256dh || !json.keys.auth)
        throw new Error("Đăng ký Push không trả đủ dữ liệu.");
      await register.execute({ body: { deviceName: deviceName.trim(), endpoint: json.endpoint, p256dh: json.keys.p256dh, auth: json.keys.auth } });
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không đăng ký được thiết bị"));
    } finally {
      setPending(false);
    }
  };
  const telegramAvailable = !!devices.data?.data.some((d) => d.channel === "telegram" && d.status === "active");
  const telegramAvailabilityPending = !telegramAvailable && (!devices.data || devices.hasMore || devices.isError);
  const policyError = validatePolicy({ enabled, minutes, max, primary, quiet, quietStart, quietEnd, channel, telegramAvailable });
  const savePolicy = async () => {
    if (!policy.data || policyError)
      return;
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { enabled, minutes, max, quiet, quietStart, quietEnd, primary, fallback, channel, urgent };
    const body = {
      expectedVersion: prepared.version,
      enabled,
      timezone: policy.data.data.timezone,
      quietHours: quiet ? { start: quietStart, end: quietEnd } : null,
      remindAfterMinutes: minutes.trim() ? Number(minutes) : null,
      maxReminders: Number(max),
      primaryUserIds: primary,
      fallbackUserIds: fallback,
      fallbackChannel: channel,
      urgentMayBypassQuietHours: urgent
    };
    try {
      const result = await save.execute({ body });
      editor.committed(notificationSnapshot(result.data), submitted);
    } catch (error2) {
      editor.failed(error2);
    }
  };
  const knownUsers = members.data?.data.filter((m) => m.status === "active").map((m) => ({ id: m.userId, label: m.userId === session.user.id ? "Bạn" : m.userId })) || [{ id: session.user.id, label: "Bạn" }];
  const selectedUserIds = [.../* @__PURE__ */ new Set([...primary, ...fallback])];
  const retainedUsers = selectedUserIds.filter((id) => !knownUsers.some((user) => user.id === id)).map((id) => ({ id, label: `${id} (đã lưu, chưa tải thành viên)` }));
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Điện thoại & lịch trực", subtitle: "Thiết bị, xác nhận nhận việc, giờ yên lặng và người dự phòng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 134,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1.2fr 1fr" }, shrinkChildren: true, geometry: { minWidth: 0 }, children: [
        /* @__PURE__ */ jsxDEV(PageSections, { shrinkChildren: true, geometry: { minWidth: 0 }, children: [
          /* @__PURE__ */ jsxDEV(Panel, { title: "Thiết bị nhận thông báo", bodyMode: "inset", children: [
            /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || register.error || test.error || pair.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 368
              }, this),
              deviceTestMessage && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: deviceTestMessage }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 465
              }, this),
              /* @__PURE__ */ jsxDEV(SurfaceContent, { direction: "row", alignItems: "center", children: [
                /* @__PURE__ */ jsxDEV(SmartphoneRounded, { sx: { fontSize: tokens.iconSizes.devicePreview, color: "primary.main" } }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 134,
                  columnNumber: 568
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { children: "Thông báo tối giản trên màn hình khóa; xem địa chỉ khách sau khi đăng nhập." }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 134,
                  columnNumber: 662
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 516
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Tên thiết bị", value: deviceName, onChange: (e) => setDeviceName(limitCodePoints(e.target.value, 120)) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 779
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "contained", busy: pending, disabled: !deviceName.trim(), onClick: () => void deviceRegister(), children: __MOCK__ ? "Mô phỏng đăng ký thiết bị" : "Bật thông báo trên thiết bị này" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 902
              }, this),
              __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Mô phỏng không yêu cầu quyền hệ điều hành, không đăng ký Push thật và giữ thiết bị ở trạng thái chờ xác minh." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 134,
                columnNumber: 1161
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 134,
              columnNumber: 352
            }, this),
            devices.isError && !devices.data ? null : /* @__PURE__ */ jsxDEV(QueryState, { query: devices, pendingProfile: "section", children: devices.data && /* @__PURE__ */ jsxDEV(DataTable, { rows: devices.data.data, rowKey: (d) => d.id, columns: [
              { key: "name", label: "Thiết bị", render: (d) => d.deviceName },
              { key: "state", label: "Trạng thái", render: (d) => /* @__PURE__ */ jsxDEV(Status, { value: d.status }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 135,
                columnNumber: 132
              }, this) },
              {
                key: "actions",
                label: "",
                render: (d) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", flexWrap: "wrap", children: [
                  /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", disabled: d.status === "revoked", busy: test.pending, onClick: async () => {
                    try {
                      await test.execute({ path: { resourceId: d.id }, body: { expectedVersion: d.version } });
                      setDeviceTestMessage(__MOCK__ ? "Mô phỏng: chưa gửi Push thật; thiết bị vẫn chờ xác minh." : "Yêu cầu kiểm tra đã được tiếp nhận; xem trạng thái backend trước khi kết luận đã gửi.");
                    } catch {
                      setDeviceTestMessage(__MOCK__ ? "Mô phỏng: không gửi Push thật; kiểm tra bị từ chối và trạng thái thiết bị không đổi." : "");
                    }
                  }, children: __MOCK__ ? "Kiểm tra mô phỏng" : "Gửi thử" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                    lineNumber: 137,
                    columnNumber: 98
                  }, this),
                  /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", color: "error", disabled: d.status === "revoked", onClick: () => setSelected(d), children: "Thu hồi" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                    lineNumber: 137,
                    columnNumber: 699
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                  lineNumber: 137,
                  columnNumber: 59
                }, this)
              }
            ] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 134,
              columnNumber: 1432
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 134,
              columnNumber: 1362
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "thiết bị", loadedCount: devices.loadedCount, hasMore: devices.hasMore, busy: devices.isLoadingMore, onLoadMore: devices.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 139,
              columnNumber: 34
            }, this),
            devices.isError && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: devices.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 139,
                columnNumber: 224
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (devices.isFetchNextPageError ? devices.loadMore() : devices.refetch());
              }, children: "Thử lại danh sách thiết bị" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 139,
                columnNumber: 261
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 139,
              columnNumber: 208
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 134,
            columnNumber: 296
          }, this),
          /* @__PURE__ */ jsxDEV(Panel, { title: "Telegram dự phòng", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Chỉ liên kết qua mã một lần. Không dán bot token vào trình duyệt." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 139,
              columnNumber: 505
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "outlined", busy: pair.pending, onClick: async () => {
              try {
                const r = await pair.execute();
                setPairing(r.data);
              } catch {
              }
            }, children: "Tạo mã liên kết" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 139,
              columnNumber: 618
            }, this),
            pairing && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
              __MOCK__ ? "Mã minh họa, không dùng để liên kết thật. " : "",
              "Bot: ",
              pairing.botUsername,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 196
              }, this),
              "Mã: ",
              pairing.pairingCode,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 227
              }, this),
              "Hết hạn ",
              dateTime(pairing.expiresAt, shop.timezone)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 85
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 139,
            columnNumber: 489
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 139,
            columnNumber: 439
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 134,
          columnNumber: 240
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Quy tắc nhận và nhắc việc", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: policy, pendingProfile: "section", children: [
          /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: policyForm, onSubmit: (event) => {
            event.preventDefault();
            void savePolicy();
          }, children: [
            /* @__PURE__ */ jsxDEV(ErrorNotice, { error: save.error }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 556
            }, this),
            /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { enabled: "Bật quy tắc", minutes: "Nhắc sau (phút)", max: "Số lần nhắc", quiet: "Giờ yên lặng", quietStart: "Giờ bắt đầu", quietEnd: "Giờ kết thúc", primary: "Người nhận chính", fallback: "Người dự phòng", channel: "Kênh dự phòng", urgent: "Ưu tiên khẩn" }, busy: save.pending }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 590
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Bật quy tắc thông báo", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: enabled, onChange: (e) => setEnabled(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 967
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 910
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Nhắc sau (phút), để trống nếu chưa chốt", value: minutes, onChange: (e) => setMinutes(e.target.value), type: "number", inputProps: { min: 1 } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1048
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Số lần nhắc tối đa", value: max, onChange: (e) => setMax(e.target.value), type: "number", inputProps: { min: 0 } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1208
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm thành viên", value: memberSearchInput, onChange: (event) => setMemberSearchInput(event.target.value), disabled: !canManageMembers, helperText: "Tìm kiếm dùng q của listMembers; mã người nhận đã lưu luôn được giữ." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1339
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Người nhận chính", value: primary, slotProps: { select: { multiple: true } }, onChange: (e) => setPrimary(typeof e.target.value === "string" ? e.target.value.split(",") : e.target.value), children: [...retainedUsers, ...knownUsers].map((u) => /* @__PURE__ */ jsxDEV(MenuItem, { value: u.id, children: u.label }, u.id, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1833
            }, this)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1575
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Người dự phòng", value: fallback, slotProps: { select: { multiple: true } }, onChange: (e) => setFallback(typeof e.target.value === "string" ? e.target.value.split(",") : e.target.value), children: [...retainedUsers, ...knownUsers].map((u) => /* @__PURE__ */ jsxDEV(MenuItem, { value: u.id, children: u.label }, u.id, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 2159
            }, this)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 1901
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "thành viên", loadedCount: members.loadedCount, hasMore: members.hasMore, busy: members.isLoadingMore, onLoadMore: members.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 2227
            }, this),
            members.isError && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: members.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 2419
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (members.isFetchNextPageError ? members.loadMore() : members.refetch());
              }, children: "Thử lại danh sách thành viên" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 2456
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 2403
            }, this),
            telegramAvailabilityPending && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: devices.isError ? "Không xác minh được danh sách thiết bị; hãy thử lại trước khi kết luận không có Telegram đang hoạt động." : devices.hasMore ? "Chưa tải hết thiết bị; hãy tải thêm trước khi kết luận không có Telegram đang hoạt động." : "Đang tải danh sách thiết bị để xác minh trạng thái Telegram." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 2660
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kênh dự phòng", value: channel, onChange: (e) => setChannel(e.target.value), children: [
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "none", children: "Chưa bật" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 3127
              }, this),
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "telegram", disabled: !telegramAvailable, children: telegramAvailable ? "Telegram đã liên kết" : telegramAvailabilityPending ? "Chưa xác minh Telegram" : "Telegram (chưa có thiết bị active)" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 3169
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 3008
            }, this),
            channel === "telegram" && !telegramAvailable && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Mã ghép đôi mô phỏng không liên kết Telegram. Chỉ chọn kênh này khi danh sách có thiết bị Telegram active." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 3438
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Có giờ yên lặng", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: quiet, onChange: (e) => setQuiet(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 3630
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 3579
            }, this),
            quiet && /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, children: [
              /* @__PURE__ */ jsxDEV(TextField, { type: "time", label: "Từ", value: quietStart, onChange: (e) => setQuietStart(e.target.value), fullWidth: true }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 3769
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { type: "time", label: "Đến", value: quietEnd, onChange: (e) => setQuietEnd(e.target.value), fullWidth: true }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
                lineNumber: 143,
                columnNumber: 3882
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 3717
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
              "Theo múi giờ ",
              shop.timezone
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 4006
            }, this),
            /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Cho phép thông báo khẩn vượt giờ yên lặng", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: urgent, onChange: (e) => setUrgent(e.target.checked) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 4154
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 4077
            }, this),
            policyError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: policyError }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
              lineNumber: 143,
              columnNumber: 4249
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 143,
            columnNumber: 444
          }, this),
          /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "column", beforeGap: "form", children: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "notifications.manage", variant: "contained", busy: save.pending, disabled: !policy.data || !!policyError || save.pending, onClick: () => void savePolicy(), children: "Lưu quy tắc" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 143,
            columnNumber: 4370
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
            lineNumber: 143,
            columnNumber: 4321
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 143,
          columnNumber: 392
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
          lineNumber: 143,
          columnNumber: 334
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 134,
        columnNumber: 144
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", "data-testid": "notification-protection-note", children: "Chống gửi lặp theo sự kiện, kiểm tra callback, thời hạn token và giới hạn tốc độ phải được bảo đảm bởi dịch vụ. Bản demo không phát thông báo thật và không xác minh các lớp bảo vệ phía máy chủ." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
        lineNumber: 143,
        columnNumber: 4628
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 134,
      columnNumber: 130
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: "Thu hồi thiết bị", description: "Máy chủ phải dừng mọi thông báo đến subscription này.", onClose: () => setSelected(null), busy: revoke.pending, error: revoke.error, onConfirm: () => revoke.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
      lineNumber: 143,
      columnNumber: 4910
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx",
    lineNumber: 134,
    columnNumber: 10
  }, this);
}
_s2(DevicesPage, "LUctBdAf8B51ueYEh2JEWwvE6Lw=", false, function() {
  return [useScope, usePagedApi, useApi, useCan, usePagedApi, useCommand, useCommand, useCommand, useCommand, useCommand, useVersionedDraft, useDraftForm];
});
_c2 = DevicesPage;
function notificationSnapshot(policy) {
  return { version: policy.version, values: { enabled: policy.enabled, minutes: policy.remindAfterMinutes?.toString() || "", max: String(policy.maxReminders), quiet: !!policy.quietHours, quietStart: policy.quietHours?.start || "22:00", quietEnd: policy.quietHours?.end || "08:00", primary: policy.primaryUserIds, fallback: policy.fallbackUserIds, channel: policy.fallbackChannel, urgent: policy.urgentMayBypassQuietHours } };
}
var _c, _c2;
$RefreshReg$(_c, "NotificationsPage");
$RefreshReg$(_c2, "DevicesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/notifications/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JXLG1CQUErSCxjQUEvSDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QlgsU0FBU0EseUJBQXlCO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsYUFBYUMsWUFBWUMsWUFBWUMsY0FBY0MsYUFBYUMsc0JBQXNCO0FBQy9GLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsVUFBVUMsa0JBQWtCQyxVQUFVQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFDdkcsT0FBT0MsZ0NBQWdDO0FBQ3ZDLE9BQU9DLHVCQUF1QjtBQUU5QixTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxRQUFRQyxhQUFhQyxrQkFBa0I7QUFDaEQsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBQ2pDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxpQkFBaUJDLGdCQUFnQjtBQUMxQyxTQUFTQyxZQUFZQyxPQUFPQyxXQUFXQyxZQUFZQyxTQUFTQyxPQUFPQyxRQUFRQyxnQkFBZ0JDLGFBQWFDLGVBQWVDLFdBQVdDLHNCQUFzQjtBQUN4SixTQUFTQyxzQkFBc0JDLG1DQUFtQztBQUMzRCxnQkFBU0Msb0JBQW9CO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxNQUFNQyxRQUFRLElBQUlyQixTQUFTO0FBQ25DLFFBQU1zQixPQUFPMUIsT0FBTyxxQkFBcUIsRUFBRTJCLE9BQU90QixhQUFhLG1CQUFtQixFQUFFLENBQUM7QUFDckYsUUFBTXVCLE1BQU0xQixXQUFXLDJCQUEyQixDQUFDLHFCQUFxQixpQkFBaUIsZ0JBQWdCLHNCQUFzQixDQUFDO0FBQ2hJLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sdUJBQXNCLFVBQVMsb0VBQW1FLFNBQVMsdUJBQUMsYUFBVSxJQUFJLE1BQU1zQixLQUFLSyxFQUFFLDBCQUEwQixzQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RSxLQUF6TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNOO0FBQUEsSUFBRSx1QkFBQyxlQUFZLE9BQU9ELElBQUlFLFNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBT0osTUFBTSxpQ0FBQyxrQkFBZSxVQUFTLFNBQVNBO0FBQUFBLGFBQUtLLE1BQU1BLEtBQUtDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxPQUFlLElBQUksQ0FBQ2xDLFNBQVNtQyxRQUFRQyxPQUFPO0FBQUEsVUFDN2FDLFFBQVE7QUFBQSxVQUFHQyxhQUFhSixFQUFFSyxpQkFBaUIsWUFBWXpDLE9BQU8wQztBQUFBQSxVQUFZQyxjQUFjdkQsU0FBU3dELE9BQU9DO0FBQUFBLFVBQU9DLFNBQVNWLEVBQUVLLGlCQUFpQixnQkFBZ0J6QyxPQUFPK0M7QUFBQUEsUUFDdkssQ0FBQyxHQUFHLGlDQUFDLGtCQUFlLFdBQVcsRUFBRUMsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxnQkFBZSxpQkFBaUI7QUFBQSxpQ0FBQyxrQkFBZSxXQUFVLE9BQU87QUFBQSxtQ0FBQyw4QkFBMkIsSUFBSSxFQUFFQyxPQUFPLGVBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUFFLHVCQUFDLE9BQUk7QUFBQSxxQ0FBQyxjQUFXLFNBQVEsTUFBTWQsWUFBRWUsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFhLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSWpELFNBQVNrRCxXQUFXQyxxQkFBc0JqQixZQUFFa0IsWUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxjQUFhLHVCQUFDLGVBQVksV0FBVSxPQUFNLFdBQVUsVUFBUztBQUFBLHVDQUFDLFVBQU8sT0FBT2xCLEVBQUVtQixrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFBRSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxJQUFJLEVBQUVDLFdBQVcsU0FBUyxHQUFJcEI7QUFBQUEsb0JBQUVxQjtBQUFBQSxrQkFBUTtBQUFBLGtCQUFJL0MsU0FBUzBCLEVBQUVzQixXQUFXL0IsS0FBS2dDLFFBQVE7QUFBQSxxQkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0c7QUFBQSxtQkFBak07QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOE07QUFBQSxjQUFjLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCLElBQUksQ0FBQ3pELFNBQVMwRCxPQUFPQyxtQkFBbUIsRUFBRUMsU0FBUyxRQUFRLENBQUMsR0FBSTFCLFlBQUVLLGlCQUFpQixvQkFBb0IvQixTQUFTMEIsRUFBRUssZ0JBQWdCZCxLQUFLZ0MsUUFBUSxDQUFDLEtBQUt2QixFQUFFMkIsV0FBVyw4Q0FBOEMsOENBQXJRO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdUO0FBQUEsaUJBQXpxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzckI7QUFBQSxlQUFueEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeXhCO0FBQUEsVUFBaUIsdUJBQUMsa0JBQWUsZ0JBQWUsVUFBVTtBQUFBLG1DQUFDLGtCQUFlLFlBQVcsb0JBQW1CLGdCQUFnQjNCLEVBQUU0QixnQkFBZ0IsUUFBTyxlQUFjLFVBQVUsQ0FBQzVCLEVBQUU2QixjQUFjN0IsRUFBRThCLG9CQUFvQnRDLFFBQVF1QyxLQUFLbkMsSUFBSSxNQUFNRCxJQUFJcUMsU0FBUyxTQUFRLGFBQVksU0FBUyxNQUFNLEtBQUtyQyxJQUFJc0MsUUFBUSxFQUFFQyxNQUFNLEVBQUVDLFlBQVluQyxFQUFFSixHQUFHLEdBQUd3QyxNQUFNLEVBQUVDLGlCQUFpQnJDLEVBQUVzQyxRQUFRLEVBQUUsQ0FBQyxFQUFFQyxNQUFNLE1BQU1DLE1BQVMsR0FBRyxxQ0FBNVU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaVc7QUFBQSxZQUFrQnhDLEVBQUV5QyxPQUFPQyxTQUFTLFdBQVcsdUJBQUMsYUFBVSxJQUFJLE1BQU1uRCxLQUFLSyxFQUFFLFdBQVdJLEVBQUV5QyxPQUFPN0MsRUFBRSxJQUFJLHVCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLGVBQXRmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1nQjtBQUFBLGFBQXI0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXM1QyxLQUYzZ0NJLEVBQUVKLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVzaUMsQ0FBTTtBQUFBLFFBQUdILEtBQUtLLE1BQU1BLEtBQUs2QyxXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFTLDhHQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1JO0FBQUEsUUFBUyx1QkFBQyxTQUFNLE1BQU1sRCxLQUFLSyxNQUFNOEMsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFdBRm56QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXF6QyxLQUY5MEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUrMUM7QUFBQSxTQUYvNEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUU0NUM7QUFBQSxPQUZ0cEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUU4cEQ7QUFDenFEO0FBQUN0RCxHQVBlRCxtQkFBaUI7QUFBQSxVQUNIbEIsVUFDYkosUUFBcUNLLGNBQ3RDSCxVQUFVO0FBQUE7QUFBQSxLQUhWb0I7QUFRaEIsU0FBU3dELFlBQVlDLE9BQWU7QUFBRSxRQUFNQyxVQUFVRCxRQUFRLElBQUlFLFFBQVEsSUFBSUYsTUFBTUgsU0FBUyxLQUFLLENBQUMsR0FBR00sUUFBUSxNQUFNLEdBQUcsRUFBRUEsUUFBUSxNQUFNLEdBQUc7QUFBRyxRQUFNQyxNQUFNQyxLQUFLSixNQUFNO0FBQUcsUUFBTUssUUFBUSxJQUFJQyxXQUFXSCxJQUFJUCxNQUFNO0FBQUcsV0FBU1csSUFBSSxHQUFHQSxJQUFJSixJQUFJUCxRQUFRVztBQUM3T0YsVUFBTUUsQ0FBQyxJQUFJSixJQUFJSyxXQUFXRCxDQUFDO0FBQUcsU0FBT0Y7QUFBTztBQUNoRCxTQUFTSSxlQUFlQyxPQUE4TDtBQUNsTixRQUFNQyxXQUFXRCxNQUFNRSxRQUFRQyxLQUFLO0FBQ3BDLFFBQU1DLFVBQVVKLE1BQU1LLElBQUlGLEtBQUs7QUFDL0IsTUFBSUMsWUFBWSxNQUFNLENBQUNFLE9BQU9DLGNBQWNELE9BQU9GLE9BQU8sQ0FBQyxLQUFLRSxPQUFPRixPQUFPLElBQUk7QUFDOUUsV0FBTztBQUNYLE1BQUlILGFBQWEsQ0FBQ0ssT0FBT0MsY0FBY0QsT0FBT0wsUUFBUSxDQUFDLEtBQUtLLE9BQU9MLFFBQVEsSUFBSTtBQUMzRSxXQUFPO0FBQ1gsTUFBSUQsTUFBTVEsV0FBVyxDQUFDUDtBQUNsQixXQUFPO0FBQ1gsTUFBSUQsTUFBTVEsV0FBVyxDQUFDUixNQUFNUyxRQUFRdkI7QUFDaEMsV0FBTztBQUNYLE1BQUljLE1BQU1VLFVBQVUsQ0FBQyw0QkFBNEJDLEtBQUtYLE1BQU1ZLFVBQVUsS0FBSyxDQUFDLDRCQUE0QkQsS0FBS1gsTUFBTWEsUUFBUTtBQUN2SCxXQUFPO0FBQ1gsTUFBSWIsTUFBTXBDLFlBQVksY0FBYyxDQUFDb0MsTUFBTWM7QUFDdkMsV0FBTztBQUNYLFNBQU87QUFDWDtBQUNPLGdCQUFTQyxjQUFjO0FBQUFDLE1BQUE7QUFDMUIsUUFBTSxFQUFFbEYsTUFBTUMsUUFBUSxJQUFJckIsU0FBUztBQUNuQyxRQUFNdUcsVUFBVTFHLFlBQVksYUFBYTtBQUN6QyxRQUFNMkcsU0FBUzVHLE9BQU8sdUJBQXVCO0FBQzdDLFFBQU02RyxtQkFBbUIxRyxPQUFPLGdCQUFnQjtBQUNoRCxRQUFNLENBQUMyRyxtQkFBbUJDLG9CQUFvQixJQUFJL0gsU0FBUyxFQUFFLEdBQUcsQ0FBQ2dJLGNBQWNDLGVBQWUsSUFBSWpJLFNBQVMsRUFBRTtBQUM3R0QsWUFBVSxNQUFNO0FBQ1osVUFBTW1JLFFBQVFDLE9BQU9DLFdBQVcsTUFBTUgsZ0JBQWdCSCxrQkFBa0JqQixLQUFLLENBQUMsR0FBRyxHQUFHO0FBQ3BGLFdBQU8sTUFBTXNCLE9BQU9FLGFBQWFILEtBQUs7QUFBQSxFQUMxQyxHQUFHLENBQUNKLGlCQUFpQixDQUFDO0FBQ3RCLFFBQU1RLFVBQVVySCxZQUFZLGVBQWUsRUFBRTBCLE9BQU8sRUFBRTRGLEdBQUdQLGdCQUFnQnZDLE9BQVUsRUFBRSxHQUFHb0MsZ0JBQWdCO0FBQ3hHLFFBQU1XLFdBQVd0SCxXQUFXLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztBQUMzRCxRQUFNbUcsT0FBT25HLFdBQVcsY0FBYyxDQUFDLGVBQWUsbUJBQW1CLENBQUM7QUFDMUUsUUFBTXVILFNBQVN2SCxXQUFXLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztBQUN6RCxRQUFNd0gsT0FBT3hILFdBQVcsNEJBQTRCLENBQUMsdUJBQXVCLENBQUM7QUFDN0UsUUFBTXlILE9BQU96SCxXQUFXLHdCQUF3QixFQUFFO0FBQ2xELFFBQU0sQ0FBQzBILFlBQVlDLGFBQWEsSUFBSTdJLFNBQVMsb0JBQW9CLEdBQUcsQ0FBQzhDLE9BQU9nRyxRQUFRLElBQUk5SSxTQUF1QixJQUFJLEdBQUcsQ0FBQ2lGLFNBQVM4RCxVQUFVLElBQUkvSSxTQUFTLEtBQUssR0FBRyxDQUFDNEQsVUFBVW9GLFdBQVcsSUFBSWhKLFNBQW9DLElBQUksR0FBRyxDQUFDaUosU0FBU0MsVUFBVSxJQUFJbEosU0FBaUMsSUFBSSxHQUFHLENBQUNtSixtQkFBbUJDLG9CQUFvQixJQUFJcEosU0FBUyxFQUFFO0FBQzNWLFFBQU0sQ0FBQ2tILFNBQVNtQyxVQUFVLElBQUlySixTQUFTLEtBQUssR0FBRyxDQUFDNEcsU0FBUzBDLFVBQVUsSUFBSXRKLFNBQVMsRUFBRSxHQUFHLENBQUMrRyxLQUFLd0MsTUFBTSxJQUFJdkosU0FBUyxHQUFHLEdBQUcsQ0FBQ29ILE9BQU9vQyxRQUFRLElBQUl4SixTQUFTLEtBQUssR0FBRyxDQUFDc0gsWUFBWW1DLGFBQWEsSUFBSXpKLFNBQVMsT0FBTyxHQUFHLENBQUN1SCxVQUFVbUMsV0FBVyxJQUFJMUosU0FBUyxPQUFPLEdBQUcsQ0FBQ21ILFNBQVN3QyxVQUFVLElBQUkzSixTQUFtQixFQUFFLEdBQUcsQ0FBQzRKLFVBQVVDLFdBQVcsSUFBSTdKLFNBQW1CLEVBQUUsR0FBRyxDQUFDc0UsU0FBU3dGLFVBQVUsSUFBSTlKLFNBQThCLE1BQU0sR0FBRyxDQUFDK0osUUFBUUMsU0FBUyxJQUFJaEssU0FBUyxLQUFLO0FBQzViLFFBQU1pSyxTQUFTM0ssa0JBQWtCO0FBQUEsSUFDN0I0SyxVQUFVLEdBQUcxSCxLQUFLSyxFQUFFO0FBQUEsSUFBd0I2QyxRQUFRa0MsT0FBTzdFLE9BQU9vSCxxQkFBcUJ2QyxPQUFPN0UsS0FBS0EsSUFBSSxJQUFJMEM7QUFBQUEsSUFDM0cyRSxPQUFPLEVBQUVsRCxTQUFTTixTQUFTRyxLQUFLSyxPQUFPRSxZQUFZQyxVQUFVSixTQUFTeUMsVUFBVXRGLFNBQVN5RixPQUFPO0FBQUEsSUFDaEdNLE9BQU9BLENBQUFDLFdBQVU7QUFBRWpCLGlCQUFXaUIsT0FBT3BELE9BQU87QUFBR29DLGlCQUFXZ0IsT0FBTzFELE9BQU87QUFBRzJDLGFBQU9lLE9BQU92RCxHQUFHO0FBQUd5QyxlQUFTYyxPQUFPbEQsS0FBSztBQUFHcUMsb0JBQWNhLE9BQU9oRCxVQUFVO0FBQUdvQyxrQkFBWVksT0FBTy9DLFFBQVE7QUFBR29DLGlCQUFXVyxPQUFPbkQsT0FBTztBQUFHMEMsa0JBQVlTLE9BQU9WLFFBQVE7QUFBR0UsaUJBQVdRLE9BQU9oRyxPQUFPO0FBQUcwRixnQkFBVU0sT0FBT1AsTUFBTTtBQUFBLElBQUc7QUFBQSxJQUN2U1EsU0FBU0EsTUFBTTNDLE9BQU80QyxRQUFRLEVBQUVDLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDeEQsQ0FBQztBQUNELFFBQU1DLGFBQWFuTCxhQUFhMEssT0FBT1UsS0FBSztBQUM1QyxRQUFNQyxpQkFBaUIsWUFBWTtBQUMvQjlCLGFBQVMsSUFBSTtBQUNiQyxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsVUFBSThCLFVBQVU7QUFDVixjQUFNckMsU0FBU3RELFFBQVEsRUFBRUcsTUFBTSxFQUFFdUQsWUFBWUEsV0FBVy9CLEtBQUssR0FBR2lFLFVBQVUsa0NBQWtDQyxRQUFRLCtCQUErQkMsTUFBTSx3QkFBd0IsRUFBRSxDQUFDO0FBQ3BMO0FBQUEsTUFDSjtBQUNBNUksMkJBQXFCLEVBQUU2SSxlQUFlOUMsT0FBTytDLGlCQUFpQkMsZUFBZSxtQkFBbUJDLFdBQVdDLGFBQWEsaUJBQWlCbEQsUUFBUW1ELGNBQWMsa0JBQWtCbkQsT0FBTyxDQUFDO0FBQ3pMLFlBQU1vRCxNQUFNQyxZQUFZQyxJQUFJQztBQUM1QixVQUFJLENBQUNIO0FBQ0QsY0FBTSxJQUFJSSxNQUFNLHlFQUF5RTtBQUM3RnRKLGtDQUE0QixNQUFNdUosYUFBYUMsa0JBQWtCLENBQUM7QUFDbEUsWUFBTUMsVUFBVSxNQUFNVixVQUFVRCxjQUFjM0MsU0FBUyxjQUFjLEVBQUV1RCxPQUFPLElBQUksQ0FBQztBQUNuRixZQUFNWCxVQUFVRCxjQUFjYTtBQUM5QixZQUFNQyxlQUFlLE1BQU1ILFFBQVFULFlBQVlhLGdCQUFnQixLQUFLLE1BQU1KLFFBQVFULFlBQVljLFVBQVUsRUFBRUMsaUJBQWlCLE1BQU1DLHNCQUFzQnZHLFlBQVl5RixHQUFHLEVBQUUsQ0FBQztBQUN6SyxZQUFNZSxPQUFPTCxhQUFhTSxPQUFPO0FBQ2pDLFVBQUksQ0FBQ0QsS0FBS3hCLFlBQVksQ0FBQ3dCLEtBQUtFLE1BQU16QixVQUFVLENBQUN1QixLQUFLRSxLQUFLeEI7QUFDbkQsY0FBTSxJQUFJVyxNQUFNLG9DQUFvQztBQUN4RCxZQUFNbkQsU0FBU3RELFFBQVEsRUFBRUcsTUFBTSxFQUFFdUQsWUFBWUEsV0FBVy9CLEtBQUssR0FBR2lFLFVBQVV3QixLQUFLeEIsVUFBVUMsUUFBUXVCLEtBQUtFLEtBQUt6QixRQUFRQyxNQUFNc0IsS0FBS0UsS0FBS3hCLEtBQUssRUFBRSxDQUFDO0FBQUEsSUFDL0ksU0FDT3lCLEdBQUc7QUFDTjNELGVBQVMyRCxhQUFhZCxRQUFRYyxJQUFJLElBQUlkLE1BQU0sNkJBQTZCLENBQUM7QUFBQSxJQUM5RSxVQUFDO0FBRUc1QyxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQ0EsUUFBTXZCLG9CQUFvQixDQUFDLENBQUNHLFFBQVE1RSxNQUFNQSxLQUFLMkosS0FBSyxDQUFBQyxNQUFLQSxFQUFFckksWUFBWSxjQUFjcUksRUFBRUMsV0FBVyxRQUFRO0FBQzFHLFFBQU1DLDhCQUE4QixDQUFDckYsc0JBQXNCLENBQUNHLFFBQVE1RSxRQUFRNEUsUUFBUW1GLFdBQVduRixRQUFRb0Y7QUFDdkcsUUFBTUMsY0FBY3ZHLGVBQWUsRUFBRVMsU0FBU04sU0FBU0csS0FBS0ksU0FBU0MsT0FBT0UsWUFBWUMsVUFBVWpELFNBQVNrRCxrQkFBa0IsQ0FBQztBQUM5SCxRQUFNeUYsYUFBYSxZQUFZO0FBQUUsUUFBSSxDQUFDckYsT0FBTzdFLFFBQVFpSztBQUNqRDtBQUFRLFVBQU1FLFdBQVdqRCxPQUFPa0QsUUFBUTtBQUFHLFFBQUksQ0FBQ0QsU0FBVTtBQUMxRCxVQUFNRSxZQUFZLEVBQUVsRyxTQUFTTixTQUFTRyxLQUFLSyxPQUFPRSxZQUFZQyxVQUFVSixTQUFTeUMsVUFBVXRGLFNBQVN5RixPQUFPO0FBQzNHLFVBQU0xRSxPQUFnQztBQUFBLE1BQ3RDQyxpQkFBaUI0SCxTQUFTM0g7QUFBQUEsTUFBUzJCO0FBQUFBLE1BQVMxQyxVQUFVb0QsT0FBTzdFLEtBQUtBLEtBQUt5QjtBQUFBQSxNQUFVNkksWUFBWWpHLFFBQVEsRUFBRWtHLE9BQU9oRyxZQUFZaUcsS0FBS2hHLFNBQVMsSUFBSTtBQUFBLE1BQU1pRyxvQkFBb0I1RyxRQUFRQyxLQUFLLElBQUlHLE9BQU9KLE9BQU8sSUFBSTtBQUFBLE1BQU02RyxjQUFjekcsT0FBT0QsR0FBRztBQUFBLE1BQUcyRyxnQkFBZ0J2RztBQUFBQSxNQUFTd0csaUJBQWlCL0Q7QUFBQUEsTUFBVWdFLGlCQUFpQnRKO0FBQUFBLE1BQVN1SiwyQkFBMkI5RDtBQUFBQSxJQUN2VjtBQUFHLFFBQUk7QUFDSCxZQUFNK0QsU0FBUyxNQUFNcEYsS0FBS3hELFFBQVEsRUFBRUcsS0FBSyxDQUFDO0FBQzFDNEUsYUFBTzhELFVBQVU1RCxxQkFBcUIyRCxPQUFPL0ssSUFBSSxHQUFHcUssU0FBUztBQUFBLElBQ2pFLFNBQ090SyxRQUFPO0FBQUVtSCxhQUFPK0QsT0FBT2xMLE1BQUs7QUFBQSxJQUFHO0FBQUEsRUFBRTtBQUN4QyxRQUFNbUwsYUFBYTNGLFFBQVF2RixNQUFNQSxLQUFLbUwsT0FBTyxDQUFBQyxNQUFLQSxFQUFFdkIsV0FBVyxRQUFRLEVBQUU1SixJQUFJLENBQUFtTCxPQUFNLEVBQUV0TCxJQUFJc0wsRUFBRUMsUUFBUUMsT0FBT0YsRUFBRUMsV0FBVzNMLFFBQVF1QyxLQUFLbkMsS0FBSyxRQUFRc0wsRUFBRUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFdkwsSUFBSUosUUFBUXVDLEtBQUtuQyxJQUFJd0wsT0FBTyxNQUFNLENBQUM7QUFDdk0sUUFBTUMsa0JBQWtCLENBQUMsR0FBRyxvQkFBSUMsSUFBSSxDQUFDLEdBQUdwSCxTQUFTLEdBQUd5QyxRQUFRLENBQUMsQ0FBQztBQUM5RCxRQUFNNEUsZ0JBQWdCRixnQkFBZ0JKLE9BQU8sQ0FBQXJMLE9BQU0sQ0FBQ29MLFdBQVd2QixLQUFLLENBQUExSCxTQUFRQSxLQUFLbkMsT0FBT0EsRUFBRSxDQUFDLEVBQUVHLElBQUksQ0FBQUgsUUFBTyxFQUFFQSxJQUFJd0wsT0FBTyxHQUFHeEwsRUFBRSxpQ0FBaUMsRUFBRTtBQUM3SixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLDBCQUF5QixVQUFTLG1FQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1IO0FBQUEsSUFBRSx1QkFBQyxnQkFBYTtBQUFBLDZCQUFDLGVBQVksU0FBUyxFQUFFZ0IsSUFBSSxPQUFPNEssSUFBSSxZQUFZLEdBQUcsZ0JBQWMsTUFBQyxVQUFVLEVBQUNDLFVBQVUsRUFBQyxHQUFHO0FBQUEsK0JBQUMsZ0JBQWEsZ0JBQWMsTUFBQyxVQUFVLEVBQUNBLFVBQVUsRUFBQyxHQUFHO0FBQUEsaUNBQUMsU0FBTSxPQUFNLDJCQUEwQixVQUFTLFNBQVE7QUFBQSxtQ0FBQyxrQkFBZ0I7QUFBQSxxQ0FBQyxlQUFZLE9BQU81TCxTQUFTMEYsU0FBUzFGLFNBQVN1RSxLQUFLdkUsU0FBUzZGLEtBQUs3RixTQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBQUdxRyxxQkFBcUIsdUJBQUMsU0FBTSxVQUFTLFFBQVFBLCtCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGNBQVMsdUJBQUMsa0JBQWUsV0FBVSxPQUFPLFlBQVcsVUFBUztBQUFBLHVDQUFDLHFCQUFrQixJQUFJLEVBQUV3RixVQUFVN04sT0FBTzhOLFVBQVVDLGVBQWU5SyxPQUFPLGVBQWUsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkY7QUFBQSxnQkFBRSx1QkFBQyxjQUFXLDJGQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVGO0FBQUEsbUJBQXpPO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNQO0FBQUEsY0FBaUIsdUJBQUMsYUFBVSxPQUFNLGdCQUFlLE9BQU82RSxZQUFZLFVBQVUsQ0FBQTZELE1BQUs1RCxjQUFjdkgsZ0JBQWdCbUwsRUFBRXFDLE9BQU8vSSxPQUFPLEdBQUcsQ0FBQyxLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzSDtBQUFBLGNBQUcsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsU0FBUSxhQUFZLE1BQU1kLFNBQVMsVUFBVSxDQUFDMkQsV0FBVy9CLEtBQUssR0FBRyxTQUFTLE1BQU0sS0FBSytELGVBQWUsR0FBSUMscUJBQVcsOEJBQThCLHFDQUFuTTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxTztBQUFBLGNBQWtCQSxZQUFZLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDZIQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvSTtBQUFBLGlCQUEzNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbzdCO0FBQUEsWUFBa0JsRCxRQUFRb0YsV0FBVyxDQUFDcEYsUUFBUTVFLE9BQU8sT0FBTyx1QkFBQyxjQUFXLE9BQU80RSxTQUFTLGdCQUFlLFdBQVdBLGtCQUFRNUUsUUFBUSx1QkFBQyxhQUFVLE1BQU00RSxRQUFRNUUsS0FBS0EsTUFBTSxRQUFRLENBQUE0SixNQUFLQSxFQUFFOUosSUFBSSxTQUFTO0FBQUEsY0FDMThDLEVBQUUwSSxLQUFLLFFBQVE4QyxPQUFPLFlBQVlVLFFBQVFBLENBQUFwQyxNQUFLQSxFQUFFL0QsV0FBVztBQUFBLGNBQUcsRUFBRTJDLEtBQUssU0FBUzhDLE9BQU8sY0FBY1UsUUFBUUEsQ0FBQXBDLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFQyxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QixFQUFHO0FBQUEsY0FDNUk7QUFBQSxnQkFDSXJCLEtBQUs7QUFBQSxnQkFBVzhDLE9BQU87QUFBQSxnQkFBSVUsUUFBUUEsQ0FBQXBDLE1BQUssdUJBQUMsU0FBTSxXQUFVLE9BQU0sVUFBUyxRQUFPO0FBQUEseUNBQUMsa0JBQWUsWUFBVyx3QkFBdUIsVUFBVUEsRUFBRUMsV0FBVyxXQUFXLE1BQU12RixLQUFLcEMsU0FBUyxTQUFTLFlBQVk7QUFBRSx3QkFBSTtBQUFFLDRCQUFNb0MsS0FBS25DLFFBQVEsRUFBRUMsTUFBTSxFQUFFQyxZQUFZdUgsRUFBRTlKLEdBQUcsR0FBR3dDLE1BQU0sRUFBRUMsaUJBQWlCcUgsRUFBRXBILFFBQVEsRUFBRSxDQUFDO0FBQUc2RCwyQ0FBcUJ5QixXQUFXLDZEQUE2RCx1RkFBdUY7QUFBQSxvQkFBRyxRQUFRO0FBQUV6QiwyQ0FBcUJ5QixXQUFXLHlGQUF5RixFQUFFO0FBQUEsb0JBQUc7QUFBQSxrQkFBRSxHQUFJQSxxQkFBVyxzQkFBc0IsYUFBcmtCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStrQjtBQUFBLGtCQUFpQix1QkFBQyxrQkFBZSxZQUFXLHdCQUF1QixPQUFNLFNBQVEsVUFBVThCLEVBQUVDLFdBQVcsV0FBVyxTQUFTLE1BQU01RCxZQUFZMkQsQ0FBQyxHQUFHLHVCQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3STtBQUFBLHFCQUEvd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ3lCO0FBQUEsY0FDNTBCO0FBQUEsWUFBQyxLQUp5NEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLNTRDLEtBTHMwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtuMEM7QUFBQSxZQUFjLHVCQUFDLGtCQUFlLE9BQU0sWUFBVyxhQUFhaEYsUUFBUXFILGFBQWEsU0FBU3JILFFBQVFtRixTQUFTLE1BQU1uRixRQUFRc0gsZUFBZSxZQUFZdEgsUUFBUXVILFlBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVKO0FBQUEsWUFBR3ZILFFBQVFvRixXQUFXLHVCQUFDLGtCQUFnQjtBQUFBLHFDQUFDLGVBQVksT0FBT3BGLFFBQVE3RSxTQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQUUsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsc0JBQU02RSxRQUFRd0gsdUJBQXVCeEgsUUFBUXVILFNBQVMsSUFBSXZILFFBQVE2QyxRQUFRO0FBQUEsY0FBSSxHQUFHLDBDQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSjtBQUFBLGlCQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErTTtBQUFBLGVBTC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS2lJO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU0scUJBQW9CLFVBQVMsU0FBUSxpQ0FBQyxrQkFBZ0I7QUFBQSxtQ0FBQyxjQUFXLE9BQU0sa0JBQWlCLGlGQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLFlBQWEsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsU0FBUSxZQUFXLE1BQU03QixLQUFLMUQsU0FBUyxTQUFTLFlBQVk7QUFBRSxrQkFBSTtBQUM3c0Isc0JBQU1tSyxJQUFJLE1BQU16RyxLQUFLekQsUUFBUTtBQUM3QmdFLDJCQUFXa0csRUFBRXJNLElBQUk7QUFBQSxjQUNyQixRQUNNO0FBQUEsY0FBRTtBQUFBLFlBQWdCLEdBQUcsK0JBSmtrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUluakI7QUFBQSxZQUFrQmtHLFdBQVcsdUJBQUMsU0FBTSxVQUFTLFFBQVE0QjtBQUFBQSx5QkFBVywrQ0FBK0M7QUFBQSxjQUFHO0FBQUEsY0FBTTVCLFFBQVFvRztBQUFBQSxjQUFZLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBRztBQUFBLGNBQUc7QUFBQSxjQUFLcEcsUUFBUXFHO0FBQUFBLGNBQVksdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFHO0FBQUEsY0FBRztBQUFBLGNBQVMvTixTQUFTMEgsUUFBUXNHLFdBQVcvTSxLQUFLZ0MsUUFBUTtBQUFBLGlCQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3TTtBQUFBLGVBSjRNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSW5NLEtBSmlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSWhJO0FBQUEsYUFUL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVN1RTtBQUFBLFFBQWUsdUJBQUMsU0FBTSxPQUFNLDZCQUE0QixVQUFTLFNBQVEsaUNBQUMsY0FBVyxPQUFPb0QsUUFBUSxnQkFBZSxXQUFVO0FBQUEsaUNBQUMsY0FBVyxXQUFVLFFBQU8sS0FBSzhDLFlBQVksVUFBVSxDQUFBOEUsVUFBUztBQUFFQSxrQkFBTUMsZUFBZTtBQUFHLGlCQUFLeEMsV0FBVztBQUFBLFVBQUcsR0FBRztBQUFBLG1DQUFDLGVBQVksT0FBT3ZFLEtBQUs1RixTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQUUsdUJBQUMsaUJBQWMsUUFBZ0IsUUFBUSxFQUFFb0UsU0FBUyxlQUFlTixTQUFTLG1CQUFtQkcsS0FBSyxlQUFlSyxPQUFPLGdCQUFnQkUsWUFBWSxlQUFlQyxVQUFVLGdCQUFnQkosU0FBUyxvQkFBb0J5QyxVQUFVLGtCQUFrQnRGLFNBQVMsaUJBQWlCeUYsUUFBUSxlQUFlLEdBQUcsTUFBTXJCLEtBQUt6RCxXQUFyVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2VDtBQUFBLFlBQUUsdUJBQUMsb0JBQWlCLE9BQU0seUJBQXdCLFNBQVMsdUJBQUMsWUFBUyxTQUFTaUMsU0FBUyxVQUFVLENBQUF1RixNQUFLcEQsV0FBV29ELEVBQUVxQyxPQUFPWSxPQUFPLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9JO0FBQUEsWUFBRSx1QkFBQyxhQUFVLE9BQU0sMkNBQTBDLE9BQU85SSxTQUFTLFVBQVUsQ0FBQTZGLE1BQUtuRCxXQUFXbUQsRUFBRXFDLE9BQU8vSSxLQUFLLEdBQUcsTUFBSyxVQUFTLFlBQVksRUFBRTRKLEtBQUssRUFBRSxLQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySjtBQUFBLFlBQUUsdUJBQUMsYUFBVSxPQUFNLHNCQUFxQixPQUFPNUksS0FBSyxVQUFVLENBQUEwRixNQUFLbEQsT0FBT2tELEVBQUVxQyxPQUFPL0ksS0FBSyxHQUFHLE1BQUssVUFBUyxZQUFZLEVBQUU0SixLQUFLLEVBQUUsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEg7QUFBQSxZQUFFLHVCQUFDLGFBQVUsT0FBTSxrQkFBaUIsT0FBTzdILG1CQUFtQixVQUFVLENBQUEwSCxVQUFTekgscUJBQXFCeUgsTUFBTVYsT0FBTy9JLEtBQUssR0FBRyxVQUFVLENBQUM4QixrQkFBa0IsWUFBVywwRUFBaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdU87QUFBQSxZQUFFLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sb0JBQW1CLE9BQU9WLFNBQVMsV0FBVyxFQUFFeUksUUFBUSxFQUFFQyxVQUFVLEtBQUssRUFBRSxHQUFHLFVBQVUsQ0FBQXBELE1BQUs5QyxXQUFXLE9BQU84QyxFQUFFcUMsT0FBTy9JLFVBQVUsV0FBVzBHLEVBQUVxQyxPQUFPL0ksTUFBTStKLE1BQU0sR0FBRyxJQUFJckQsRUFBRXFDLE9BQU8vSSxLQUFLLEdBQUksV0FBQyxHQUFHeUksZUFBZSxHQUFHUCxVQUFVLEVBQUVqTCxJQUFJLENBQUErTSxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVsTixJQUFLa04sWUFBRTFCLFNBQXRCMEIsRUFBRWxOLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLENBQVcsS0FBcFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc1Q7QUFBQSxZQUFZLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sa0JBQWlCLE9BQU8rRyxVQUFVLFdBQVcsRUFBRWdHLFFBQVEsRUFBRUMsVUFBVSxLQUFLLEVBQUUsR0FBRyxVQUFVLENBQUFwRCxNQUFLNUMsWUFBWSxPQUFPNEMsRUFBRXFDLE9BQU8vSSxVQUFVLFdBQVcwRyxFQUFFcUMsT0FBTy9JLE1BQU0rSixNQUFNLEdBQUcsSUFBSXJELEVBQUVxQyxPQUFPL0ksS0FBSyxHQUFJLFdBQUMsR0FBR3lJLGVBQWUsR0FBR1AsVUFBVSxFQUFFakwsSUFBSSxDQUFBK00sTUFBSyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFbE4sSUFBS2tOLFlBQUUxQixTQUF0QjBCLEVBQUVsTixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQyxDQUFXLEtBQXBUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNUO0FBQUEsWUFBWSx1QkFBQyxrQkFBZSxPQUFNLGNBQWEsYUFBYXlGLFFBQVEwRyxhQUFhLFNBQVMxRyxRQUFRd0UsU0FBUyxNQUFNeEUsUUFBUTJHLGVBQWUsWUFBWTNHLFFBQVE0RyxZQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SjtBQUFBLFlBQUc1RyxRQUFReUUsV0FBVyx1QkFBQyxrQkFBZ0I7QUFBQSxxQ0FBQyxlQUFZLE9BQU96RSxRQUFReEYsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFFLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLHNCQUFNd0YsUUFBUTZHLHVCQUF1QjdHLFFBQVE0RyxTQUFTLElBQUk1RyxRQUFRa0MsUUFBUTtBQUFBLGNBQUksR0FBRyw0Q0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUo7QUFBQSxpQkFBeE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaU47QUFBQSxZQUFtQnFDLCtCQUErQix1QkFBQyxTQUFNLFVBQVMsUUFBTyxNQUFLLFVBQVVsRixrQkFBUW9GLFVBQVUsNkdBQTZHcEYsUUFBUW1GLFVBQVUsNkZBQTZGLGtFQUFwUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtVjtBQUFBLFlBQVMsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxpQkFBZ0IsT0FBT3hJLFNBQVMsVUFBVSxDQUFBbUksTUFBSzNDLFdBQVcyQyxFQUFFcUMsT0FBTy9JLEtBQXVCLEdBQUc7QUFBQSxxQ0FBQyxZQUFTLE9BQU0sUUFBTyx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUFXLHVCQUFDLFlBQVMsT0FBTSxZQUFXLFVBQVUsQ0FBQ3lCLG1CQUFvQkEsOEJBQW9CLHlCQUF5QnFGLDhCQUE4QiwyQkFBMkIsd0NBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFNO0FBQUEsaUJBQXBXO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStXO0FBQUEsWUFBYXZJLFlBQVksY0FBYyxDQUFDa0QscUJBQXFCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLDBIQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSTtBQUFBLFlBQVMsdUJBQUMsb0JBQWlCLE9BQU0sbUJBQWtCLFNBQVMsdUJBQUMsWUFBUyxTQUFTSixPQUFPLFVBQVUsQ0FBQXFGLE1BQUtqRCxTQUFTaUQsRUFBRXFDLE9BQU9ZLE9BQU8sS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0UsS0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEg7QUFBQSxZQUFHdEksU0FBUyx1QkFBQyxjQUFXLFdBQVcsRUFBRXZELElBQUksVUFBVW1NLElBQUksTUFBTSxHQUFHO0FBQUEscUNBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxNQUFLLE9BQU8xSSxZQUFZLFVBQVUsQ0FBQW1GLE1BQUtoRCxjQUFjZ0QsRUFBRXFDLE9BQU8vSSxLQUFLLEdBQUcsV0FBUyxRQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RztBQUFBLGNBQUUsdUJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxPQUFNLE9BQU93QixVQUFVLFVBQVUsQ0FBQWtGLE1BQUsvQyxZQUFZK0MsRUFBRXFDLE9BQU8vSSxLQUFLLEdBQUcsV0FBUyxRQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RztBQUFBLGlCQUEzUTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2UTtBQUFBLFlBQWMsdUJBQUMsY0FBVyxTQUFRLFdBQVU7QUFBQTtBQUFBLGNBQWN2RCxLQUFLZ0M7QUFBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFBYSx1QkFBQyxvQkFBaUIsT0FBTSw2Q0FBNEMsU0FBUyx1QkFBQyxZQUFTLFNBQVN1RixRQUFRLFVBQVUsQ0FBQTBDLE1BQUt6QyxVQUFVeUMsRUFBRXFDLE9BQU9ZLE9BQU8sS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0UsS0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0o7QUFBQSxZQUFHMUMsZUFBZSx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHlCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLGVBQTF1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtdkg7QUFBQSxVQUFhLHVCQUFDLGVBQVksV0FBVSxVQUFTLFdBQVUsUUFBTyxpQ0FBQyxrQkFBZSxZQUFXLHdCQUF1QixTQUFRLGFBQVksTUFBTXRFLEtBQUt6RCxTQUFTLFVBQVUsQ0FBQzJDLE9BQU83RSxRQUFRLENBQUMsQ0FBQ2lLLGVBQWV0RSxLQUFLekQsU0FBUyxTQUFTLE1BQU0sS0FBS2dJLFdBQVcsR0FBRywyQkFBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ00sS0FBalA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa1E7QUFBQSxhQUF0akk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFva0ksS0FBOW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMm9JO0FBQUEsV0FUL3pJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTdTBJO0FBQUEsTUFBYyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxlQUFZLGdDQUErQixpTkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtUTtBQUFBLFNBVHRtSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUzhtSjtBQUFBLElBQWUsdUJBQUMsaUJBQWMsTUFBTSxDQUFDLENBQUNySixVQUFVLE9BQU0sb0JBQW1CLGFBQVkseURBQXdELFNBQVMsTUFBTW9GLFlBQVksSUFBSSxHQUFHLE1BQU1QLE9BQU94RCxTQUFTLE9BQU93RCxPQUFPM0YsT0FBTyxXQUFXLE1BQU0yRixPQUFPdkQsUUFBUSxFQUFFQyxNQUFNLEVBQUVDLFlBQVl4QixVQUFVZixNQUFNLEdBQUcsR0FBR3dDLE1BQU0sRUFBRUMsaUJBQWlCMUIsVUFBVTJCLFdBQVcsRUFBRSxFQUFFLENBQUMsS0FBMVU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0VTtBQUFBLE9BVGhrSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU2trSztBQUM3a0s7QUFBQ21DLElBL0VlRCxhQUFXO0FBQUEsVUFDR3JHLFVBQ1ZILGFBQ0RELFFBQ1VHLFFBTVRGLGFBQ0NDLFlBQ0pBLFlBQ0VBLFlBQ0ZBLFlBQ0FBLFlBR0U1QixtQkFNSUMsWUFBWTtBQUFBO0FBQUEsTUF4Qm5Ca0k7QUFpRmhCLFNBQVMwQyxxQkFBcUJ2QyxRQUE0QjtBQUN0RCxTQUFPLEVBQUVyQyxTQUFTcUMsT0FBT3JDLFNBQVMrRSxRQUFRLEVBQUVwRCxTQUFTVSxPQUFPVixTQUFTTixTQUFTZ0IsT0FBTzRGLG9CQUFvQnlDLFNBQVMsS0FBSyxJQUFJbEosS0FBS21KLE9BQU90SSxPQUFPNkYsWUFBWSxHQUFHckcsT0FBTyxDQUFDLENBQUNRLE9BQU95RixZQUFZL0YsWUFBWU0sT0FBT3lGLFlBQVlDLFNBQVMsU0FBUy9GLFVBQVVLLE9BQU95RixZQUFZRSxPQUFPLFNBQVNwRyxTQUFTUyxPQUFPOEYsZ0JBQWdCOUQsVUFBVWhDLE9BQU8rRixpQkFBaUJySixTQUFTc0QsT0FBT2dHLGlCQUFpQjdELFFBQVFuQyxPQUFPaUcsMEJBQTBCLEVBQUU7QUFDemE7QUFBQyxJQUFBc0MsSUFBQUM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVZlcnNpb25lZERyYWZ0IiwidXNlRHJhZnRGb3JtIiwiRHJhZnRDb25mbGljdCIsIkFjdGlvbkdyb3VwIiwiRmllbGRHcm91cCIsIkZvcm1GaWVsZHMiLCJQYWdlU2VjdGlvbnMiLCJTZWN0aW9uR3JpZCIsIlN1cmZhY2VDb250ZW50IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiQ2hlY2tib3giLCJGb3JtQ29udHJvbExhYmVsIiwiTWVudUl0ZW0iLCJTdGFjayIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJOb3RpZmljYXRpb25zQWN0aXZlUm91bmRlZCIsIlNtYXJ0cGhvbmVSb3VuZGVkIiwiY29sb3JzIiwidG9rZW5zIiwibGF5b3V0U3giLCJ1c2VBcGkiLCJ1c2VQYWdlZEFwaSIsInVzZUNvbW1hbmQiLCJ1c2VDYW4iLCJ1c2VTY29wZSIsInVzZUxpc3RRdWVyeSIsImxpbWl0Q29kZVBvaW50cyIsImRhdGVUaW1lIiwiUGFnZUhlYWRlciIsIlBhbmVsIiwiRGF0YVRhYmxlIiwiUXVlcnlTdGF0ZSIsIlRvb2xiYXIiLCJQYWdlciIsIlN0YXR1cyIsIk11dGF0aW9uQnV0dG9uIiwiRXJyb3JOb3RpY2UiLCJDb25maXJtRGlhbG9nIiwiUm91dGVMaW5rIiwiTG9va3VwTG9hZE1vcmUiLCJhc3NlcnRQdXNoQ2FwYWJpbGl0eSIsImFzc2VydFB1c2hQZXJtaXNzaW9uR3JhbnRlZCIsIk5vdGlmaWNhdGlvbnNQYWdlIiwiX3MiLCJzaG9wIiwic2Vzc2lvbiIsImxpc3QiLCJxdWVyeSIsImFjayIsImlkIiwiZXJyb3IiLCJkYXRhIiwibWFwIiwibiIsInN1cmZhY2UiLCJpbnNldCIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYWNrbm93bGVkZ2VkQXQiLCJoZXJvQm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwicmFkaXVzIiwibGFyZ2UiLCJiZ2NvbG9yIiwic2VsZWN0ZWQiLCJ4cyIsIm1kIiwiY29sb3IiLCJ0aXRsZSIsInBhZ2VIZWFkZXIiLCJ0aXRsZURlc2NyaXB0aW9uR2FwIiwic2FmZUJvZHkiLCJkZWxpdmVyeVN0YXR1cyIsImFsaWduU2VsZiIsImNoYW5uZWwiLCJjcmVhdGVkQXQiLCJ0aW1lem9uZSIsImRldGFpbCIsInJlbGF0ZWRDb250ZW50R2FwIiwiZGlzcGxheSIsIm9wZW5lZEF0IiwiYWxsb3dlZEFjdGlvbnMiLCJ3b3JrSXRlbUlkIiwicmVjaXBpZW50VXNlcklkIiwidXNlciIsInBlbmRpbmciLCJleGVjdXRlIiwicGF0aCIsInJlc291cmNlSWQiLCJib2R5IiwiZXhwZWN0ZWRWZXJzaW9uIiwidmVyc2lvbiIsImNhdGNoIiwidW5kZWZpbmVkIiwic291cmNlIiwidHlwZSIsImxlbmd0aCIsInBhZ2UiLCJiYXNlNjRCeXRlcyIsInZhbHVlIiwicGFkZGVkIiwicmVwZWF0IiwicmVwbGFjZSIsInJhdyIsImF0b2IiLCJieXRlcyIsIlVpbnQ4QXJyYXkiLCJpIiwiY2hhckNvZGVBdCIsInZhbGlkYXRlUG9saWN5IiwiaW5wdXQiLCJyZW1pbmRlciIsIm1pbnV0ZXMiLCJ0cmltIiwibWF4aW11bSIsIm1heCIsIk51bWJlciIsImlzU2FmZUludGVnZXIiLCJlbmFibGVkIiwicHJpbWFyeSIsInF1aWV0IiwidGVzdCIsInF1aWV0U3RhcnQiLCJxdWlldEVuZCIsInRlbGVncmFtQXZhaWxhYmxlIiwiRGV2aWNlc1BhZ2UiLCJfczIiLCJkZXZpY2VzIiwicG9saWN5IiwiY2FuTWFuYWdlTWVtYmVycyIsIm1lbWJlclNlYXJjaElucHV0Iiwic2V0TWVtYmVyU2VhcmNoSW5wdXQiLCJtZW1iZXJTZWFyY2giLCJzZXRNZW1iZXJTZWFyY2giLCJ0aW1lciIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJtZW1iZXJzIiwicSIsInJlZ2lzdGVyIiwicmV2b2tlIiwic2F2ZSIsInBhaXIiLCJkZXZpY2VOYW1lIiwic2V0RGV2aWNlTmFtZSIsInNldEVycm9yIiwic2V0UGVuZGluZyIsInNldFNlbGVjdGVkIiwicGFpcmluZyIsInNldFBhaXJpbmciLCJkZXZpY2VUZXN0TWVzc2FnZSIsInNldERldmljZVRlc3RNZXNzYWdlIiwic2V0RW5hYmxlZCIsInNldE1pbnV0ZXMiLCJzZXRNYXgiLCJzZXRRdWlldCIsInNldFF1aWV0U3RhcnQiLCJzZXRRdWlldEVuZCIsInNldFByaW1hcnkiLCJmYWxsYmFjayIsInNldEZhbGxiYWNrIiwic2V0Q2hhbm5lbCIsInVyZ2VudCIsInNldFVyZ2VudCIsImVkaXRvciIsImlkZW50aXR5Iiwibm90aWZpY2F0aW9uU25hcHNob3QiLCJkcmFmdCIsImFwcGx5IiwidmFsdWVzIiwicmVmcmVzaCIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJwb2xpY3lGb3JtIiwiZGlydHkiLCJkZXZpY2VSZWdpc3RlciIsIl9fTU9DS19fIiwiZW5kcG9pbnQiLCJwMjU2ZGgiLCJhdXRoIiwic2VjdXJlQ29udGV4dCIsImlzU2VjdXJlQ29udGV4dCIsInNlcnZpY2VXb3JrZXIiLCJuYXZpZ2F0b3IiLCJwdXNoTWFuYWdlciIsIm5vdGlmaWNhdGlvbiIsImtleSIsImltcG9ydCIsImVudiIsIlZJVEVfV0VCX1BVU0hfUFVCTElDX0tFWSIsIkVycm9yIiwiTm90aWZpY2F0aW9uIiwicmVxdWVzdFBlcm1pc3Npb24iLCJzZXJ2aWNlIiwic2NvcGUiLCJyZWFkeSIsInN1YnNjcmlwdGlvbiIsImdldFN1YnNjcmlwdGlvbiIsInN1YnNjcmliZSIsInVzZXJWaXNpYmxlT25seSIsImFwcGxpY2F0aW9uU2VydmVyS2V5IiwianNvbiIsInRvSlNPTiIsImtleXMiLCJlIiwic29tZSIsImQiLCJzdGF0dXMiLCJ0ZWxlZ3JhbUF2YWlsYWJpbGl0eVBlbmRpbmciLCJoYXNNb3JlIiwiaXNFcnJvciIsInBvbGljeUVycm9yIiwic2F2ZVBvbGljeSIsInByZXBhcmVkIiwicHJlcGFyZSIsInN1Ym1pdHRlZCIsInF1aWV0SG91cnMiLCJzdGFydCIsImVuZCIsInJlbWluZEFmdGVyTWludXRlcyIsIm1heFJlbWluZGVycyIsInByaW1hcnlVc2VySWRzIiwiZmFsbGJhY2tVc2VySWRzIiwiZmFsbGJhY2tDaGFubmVsIiwidXJnZW50TWF5QnlwYXNzUXVpZXRIb3VycyIsInJlc3VsdCIsImNvbW1pdHRlZCIsImZhaWxlZCIsImtub3duVXNlcnMiLCJmaWx0ZXIiLCJtIiwidXNlcklkIiwibGFiZWwiLCJzZWxlY3RlZFVzZXJJZHMiLCJTZXQiLCJyZXRhaW5lZFVzZXJzIiwibGciLCJtaW5XaWR0aCIsImZvbnRTaXplIiwiaWNvblNpemVzIiwiZGV2aWNlUHJldmlldyIsInRhcmdldCIsInJlbmRlciIsImxvYWRlZENvdW50IiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaXNGZXRjaE5leHRQYWdlRXJyb3IiLCJyIiwiYm90VXNlcm5hbWUiLCJwYWlyaW5nQ29kZSIsImV4cGlyZXNBdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJjaGVja2VkIiwibWluIiwic2VsZWN0IiwibXVsdGlwbGUiLCJzcGxpdCIsInUiLCJzbSIsInRvU3RyaW5nIiwiU3RyaW5nIiwiX2MiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVZlcnNpb25lZERyYWZ0IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvdmVyc2lvbmVkLWRyYWZ0JztcclxuaW1wb3J0IHsgdXNlRHJhZnRGb3JtIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZGlydHktZHJhZnRzJztcclxuaW1wb3J0IHsgRHJhZnRDb25mbGljdCB9IGZyb20gJ0Avc2hhcmVkL3VpL2RyYWZ0LWNvbmZsaWN0JztcclxuaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZpZWxkR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQsIFN1cmZhY2VDb250ZW50IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIENoZWNrYm94LCBGb3JtQ29udHJvbExhYmVsLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgTm90aWZpY2F0aW9uc0FjdGl2ZVJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9Ob3RpZmljYXRpb25zQWN0aXZlUm91bmRlZCc7XHJcbmltcG9ydCBTbWFydHBob25lUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL1NtYXJ0cGhvbmVSb3VuZGVkJztcclxuaW1wb3J0IHR5cGUgeyBEZXZpY2VTdWJzY3JpcHRpb24sIE5vdGlmaWNhdGlvblBvbGljeSwgTm90aWZpY2F0aW9uUG9saWN5V3JpdGUsIFRlbGVncmFtUGFpcmluZyB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xyXG5pbXBvcnQgeyBjb2xvcnMsIHRva2VucyB9IGZyb20gJ0Bib3RzYWxlcy90b2tlbnMnO1xyXG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9sYXlvdXQnO1xyXG5pbXBvcnQgeyB1c2VBcGksIHVzZVBhZ2VkQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcclxuaW1wb3J0IHsgdXNlQ2FuLCB1c2VTY29wZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcclxuaW1wb3J0IHsgdXNlTGlzdFF1ZXJ5IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZmlsdGVycyc7XHJcbmltcG9ydCB7IGxpbWl0Q29kZVBvaW50cywgZGF0ZVRpbWUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xyXG5pbXBvcnQgeyBQYWdlSGVhZGVyLCBQYW5lbCwgRGF0YVRhYmxlLCBRdWVyeVN0YXRlLCBUb29sYmFyLCBQYWdlciwgU3RhdHVzLCBNdXRhdGlvbkJ1dHRvbiwgRXJyb3JOb3RpY2UsIENvbmZpcm1EaWFsb2csIFJvdXRlTGluaywgTG9va3VwTG9hZE1vcmUgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcclxuaW1wb3J0IHsgYXNzZXJ0UHVzaENhcGFiaWxpdHksIGFzc2VydFB1c2hQZXJtaXNzaW9uR3JhbnRlZCB9IGZyb20gJy4vcHVzaC1jYXBhYmlsaXRpZXMnO1xyXG5leHBvcnQgZnVuY3Rpb24gTm90aWZpY2F0aW9uc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AsIHNlc3Npb24gfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0Tm90aWZpY2F0aW9ucycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdE5vdGlmaWNhdGlvbnMnKSB9KTtcclxuICAgIGNvbnN0IGFjayA9IHVzZUNvbW1hbmQoJ2Fja25vd2xlZGdlTm90aWZpY2F0aW9uJywgWydsaXN0Tm90aWZpY2F0aW9ucycsICdsaXN0V29ya0l0ZW1zJywgJ2xpc3RQcmVwSm9icycsICdnZXRPcGVyYXRpb25zU3VtbWFyeSddKTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiVHJ1bmcgdMOibSB0aMO0bmcgYsOhb1wiIHN1YnRpdGxlPVwixJDDoyBn4butaSBraMO0bmcgxJHhu5NuZyBuZ2jEqWEgxJHDoyDEkeG7jWMuIE5o4bqtbiB2aeG7h2MgbMOgIG3hu5l0IHjDoWMgbmjhuq1uIHJpw6puZy5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9ub3RpZmljYXRpb25zL2RldmljZXNgfT7EkGnhu4duIHRob+G6oWkgJiBs4buLY2ggdHLhu7FjPC9Sb3V0ZUxpbms+fS8+PEVycm9yTm90aWNlIGVycm9yPXthY2suZXJyb3J9Lz48UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdE5vdGlmaWNhdGlvbnNcIiAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fT48U3VyZmFjZUNvbnRlbnQgYm9keU1vZGU9XCJpbnNldFwiPntsaXN0LmRhdGE/LmRhdGEubWFwKG4gPT4gPEJveCBrZXk9e24uaWR9IHN4PXtbbGF5b3V0U3guc3VyZmFjZS5pbnNldCwge1xyXG4gICAgICAgICBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiBuLmFja25vd2xlZGdlZEF0ID8gJ2RpdmlkZXInIDogY29sb3JzLmhlcm9Cb3JkZXIsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmxhcmdlLCBiZ2NvbG9yOiBuLmFja25vd2xlZGdlZEF0ID8gJ3RyYW5zcGFyZW50JyA6IGNvbG9ycy5zZWxlY3RlZFxyXG4gICAgfV19PjxTdXJmYWNlQ29udGVudCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBtZDogJ3JvdycgfX0ganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgPjxTdXJmYWNlQ29udGVudCBkaXJlY3Rpb249XCJyb3dcIiA+PE5vdGlmaWNhdGlvbnNBY3RpdmVSb3VuZGVkIHN4PXt7IGNvbG9yOiAncHJpbWFyeS5tYWluJyB9fS8+PEJveD48VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIj57bi50aXRsZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtsYXlvdXRTeC5wYWdlSGVhZGVyLnRpdGxlRGVzY3JpcHRpb25HYXB9PntuLnNhZmVCb2R5fTwvVHlwb2dyYXBoeT48QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgYmVmb3JlR2FwPVwiZGV0YWlsXCI+PFN0YXR1cyB2YWx1ZT17bi5kZWxpdmVyeVN0YXR1c30vPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgc3g9e3sgYWxpZ25TZWxmOiAnY2VudGVyJyB9fT57bi5jaGFubmVsfSDCtyB7ZGF0ZVRpbWUobi5jcmVhdGVkQXQsIHNob3AudGltZXpvbmUpfTwvVHlwb2dyYXBoeT48L0FjdGlvbkdyb3VwPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtbbGF5b3V0U3guZGV0YWlsLnJlbGF0ZWRDb250ZW50R2FwLCB7IGRpc3BsYXk6ICdibG9jaycgfV19PntuLmFja25vd2xlZGdlZEF0ID8gYMSQw6Mgbmjhuq1uIHZp4buHYyBsw7pjICR7ZGF0ZVRpbWUobi5hY2tub3dsZWRnZWRBdCwgc2hvcC50aW1lem9uZSl9YCA6IG4ub3BlbmVkQXQgPyAnQ8OzIGdoaSBuaOG6rW4gbeG7nyB0aMO0bmcgYsOhbzsgY2jGsGEgbmjhuq1uIHZp4buHYy4nIDogJ0NoxrBhIGPDsyBi4bqxbmcgY2jhu6luZyDEkcOjIG3hu58gaG/hurdjIG5o4bqtbiB2aeG7h2MuJ308L1R5cG9ncmFwaHk+PC9Cb3g+PC9TdXJmYWNlQ29udGVudD48U3VyZmFjZUNvbnRlbnQganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIiA+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJvcGVyYXRpb25zLmNsYWltXCIgYWxsb3dlZEFjdGlvbnM9e24uYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cImFja25vd2xlZGdlXCIgZGlzYWJsZWQ9eyFuLndvcmtJdGVtSWQgfHwgbi5yZWNpcGllbnRVc2VySWQgIT09IHNlc3Npb24udXNlci5pZH0gYnVzeT17YWNrLnBlbmRpbmd9IHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGFjay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBuLmlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBuLnZlcnNpb24gfSB9KS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpfT5Uw7RpIG5o4bqtbiBjaHXhuqluIGLhu4sgxJHGoW48L011dGF0aW9uQnV0dG9uPntuLnNvdXJjZS50eXBlID09PSAnb3JkZXInICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy8ke24uc291cmNlLmlkfWB9PlhlbSDEkcahbjwvUm91dGVMaW5rPn08L1N1cmZhY2VDb250ZW50PjwvU3VyZmFjZUNvbnRlbnQ+PC9Cb3g+KX17bGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgcm9sZT1cInN0YXR1c1wiPkNoxrBhIGPDsyB0aMO0bmcgYsOhby4gVGjDtG5nIGLDoW8gY2h14bqpbiBi4buLIMSRxrDhu6NjIHThuqFvIHNhdSBraGkgxJHGoW4gxJHDoyB4w6FjIG5o4bqtbiB2w6AgZ2nhu68gaMOgbmcgdGjDoG5oIGPDtG5nLjwvQWxlcnQ+fTxQYWdlciBwYWdlPXtsaXN0LmRhdGE/LnBhZ2V9Lz48L1N1cmZhY2VDb250ZW50PjwvUXVlcnlTdGF0ZT48L1BhbmVsPjwvPjtcclxufVxyXG5mdW5jdGlvbiBiYXNlNjRCeXRlcyh2YWx1ZTogc3RyaW5nKSB7IGNvbnN0IHBhZGRlZCA9ICh2YWx1ZSArICc9Jy5yZXBlYXQoKDQgLSB2YWx1ZS5sZW5ndGggJSA0KSAlIDQpKS5yZXBsYWNlKC8tL2csICcrJykucmVwbGFjZSgvXy9nLCAnLycpOyBjb25zdCByYXcgPSBhdG9iKHBhZGRlZCk7IGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkocmF3Lmxlbmd0aCk7IGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Lmxlbmd0aDsgaSsrKVxyXG4gICAgYnl0ZXNbaV0gPSByYXcuY2hhckNvZGVBdChpKTsgcmV0dXJuIGJ5dGVzOyB9XHJcbmZ1bmN0aW9uIHZhbGlkYXRlUG9saWN5KGlucHV0OiB7IGVuYWJsZWQ6IGJvb2xlYW47IG1pbnV0ZXM6IHN0cmluZzsgbWF4OiBzdHJpbmc7IHByaW1hcnk6IHN0cmluZ1tdOyBxdWlldDogYm9vbGVhbjsgcXVpZXRTdGFydDogc3RyaW5nOyBxdWlldEVuZDogc3RyaW5nOyBjaGFubmVsOiAnbm9uZScgfCAndGVsZWdyYW0nOyB0ZWxlZ3JhbUF2YWlsYWJsZTogYm9vbGVhbiB9KSB7XHJcbiAgICBjb25zdCByZW1pbmRlciA9IGlucHV0Lm1pbnV0ZXMudHJpbSgpO1xyXG4gICAgY29uc3QgbWF4aW11bSA9IGlucHV0Lm1heC50cmltKCk7XHJcbiAgICBpZiAobWF4aW11bSA9PT0gJycgfHwgIU51bWJlci5pc1NhZmVJbnRlZ2VyKE51bWJlcihtYXhpbXVtKSkgfHwgTnVtYmVyKG1heGltdW0pIDwgMClcclxuICAgICAgICByZXR1cm4gJ1Phu5EgbOG6p24gbmjhuq9jIHThu5FpIMSRYSBwaOG6o2kgbMOgIHPhu5Egbmd1ecOqbiB04burIDAgdHLhu58gbMOqbi4nO1xyXG4gICAgaWYgKHJlbWluZGVyICYmICghTnVtYmVyLmlzU2FmZUludGVnZXIoTnVtYmVyKHJlbWluZGVyKSkgfHwgTnVtYmVyKHJlbWluZGVyKSA8IDEpKVxyXG4gICAgICAgIHJldHVybiAnVGjhu51pIGdpYW4gbmjhuq9jIHBo4bqjaSBsw6Agc+G7kSBuZ3V5w6puIHThu6sgMSBwaMO6dCB0cuG7nyBsw6puLic7XHJcbiAgICBpZiAoaW5wdXQuZW5hYmxlZCAmJiAhcmVtaW5kZXIpXHJcbiAgICAgICAgcmV0dXJuICdD4bqnbiBuaOG6rXAgdGjhu51pIGdpYW4gbmjhuq9jIGtoaSBi4bqtdCBxdXkgdOG6r2MuJztcclxuICAgIGlmIChpbnB1dC5lbmFibGVkICYmICFpbnB1dC5wcmltYXJ5Lmxlbmd0aClcclxuICAgICAgICByZXR1cm4gJ0PhuqduIGNo4buNbiDDrXQgbmjhuqV0IG3hu5l0IG5nxrDhu51pIG5o4bqtbiBjaMOtbmgga2hpIGLhuq10IHF1eSB04bqvYy4nO1xyXG4gICAgaWYgKGlucHV0LnF1aWV0ICYmICghL14oWzAxXVxcZHwyWzAtM10pOlswLTVdXFxkJC8udGVzdChpbnB1dC5xdWlldFN0YXJ0KSB8fCAhL14oWzAxXVxcZHwyWzAtM10pOlswLTVdXFxkJC8udGVzdChpbnB1dC5xdWlldEVuZCkpKVxyXG4gICAgICAgIHJldHVybiAnR2nhu50gecOqbiBs4bq3bmcgY+G6p24gY8OzIHRo4budaSDEkWnhu4NtIGLhuq90IMSR4bqndSB2w6Aga+G6v3QgdGjDumMgaOG7o3AgbOG7hy4nO1xyXG4gICAgaWYgKGlucHV0LmNoYW5uZWwgPT09ICd0ZWxlZ3JhbScgJiYgIWlucHV0LnRlbGVncmFtQXZhaWxhYmxlKVxyXG4gICAgICAgIHJldHVybiAnQ2jGsGEgY8OzIHRoaeG6v3QgYuG7iyBUZWxlZ3JhbSBhY3RpdmUuIEhvw6BuIHThuqV0IGxpw6puIGvhur90IHRo4bqtdCB0csaw4bubYyBraGkgY2jhu41uIGvDqm5oIG7DoHkuJztcclxuICAgIHJldHVybiAnJztcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gRGV2aWNlc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AsIHNlc3Npb24gfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBkZXZpY2VzID0gdXNlUGFnZWRBcGkoJ2xpc3REZXZpY2VzJyk7XHJcbiAgICBjb25zdCBwb2xpY3kgPSB1c2VBcGkoJ2dldE5vdGlmaWNhdGlvblBvbGljeScpO1xyXG4gICAgY29uc3QgY2FuTWFuYWdlTWVtYmVycyA9IHVzZUNhbignbWVtYmVycy5tYW5hZ2UnKTtcclxuICAgIGNvbnN0IFttZW1iZXJTZWFyY2hJbnB1dCwgc2V0TWVtYmVyU2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoJycpLCBbbWVtYmVyU2VhcmNoLCBzZXRNZW1iZXJTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldE1lbWJlclNlYXJjaChtZW1iZXJTZWFyY2hJbnB1dC50cmltKCkpLCAyNTApO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH0sIFttZW1iZXJTZWFyY2hJbnB1dF0pO1xyXG4gICAgY29uc3QgbWVtYmVycyA9IHVzZVBhZ2VkQXBpKCdsaXN0TWVtYmVycycsIHsgcXVlcnk6IHsgcTogbWVtYmVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0sIGNhbk1hbmFnZU1lbWJlcnMpO1xyXG4gICAgY29uc3QgcmVnaXN0ZXIgPSB1c2VDb21tYW5kKCdjcmVhdGVEZXZpY2UnLCBbJ2xpc3REZXZpY2VzJ10pO1xyXG4gICAgY29uc3QgdGVzdCA9IHVzZUNvbW1hbmQoJ3Rlc3REZXZpY2UnLCBbJ2xpc3REZXZpY2VzJywgJ2xpc3ROb3RpZmljYXRpb25zJ10pO1xyXG4gICAgY29uc3QgcmV2b2tlID0gdXNlQ29tbWFuZCgncmV2b2tlRGV2aWNlJywgWydsaXN0RGV2aWNlcyddKTtcclxuICAgIGNvbnN0IHNhdmUgPSB1c2VDb21tYW5kKCd1cGRhdGVOb3RpZmljYXRpb25Qb2xpY3knLCBbJ2dldE5vdGlmaWNhdGlvblBvbGljeSddKTtcclxuICAgIGNvbnN0IHBhaXIgPSB1c2VDb21tYW5kKCdiZWdpblRlbGVncmFtUGFpcmluZycsIFtdKTtcclxuICAgIGNvbnN0IFtkZXZpY2VOYW1lLCBzZXREZXZpY2VOYW1lXSA9IHVzZVN0YXRlKCfEkGnhu4duIHRob+G6oWkgY+G7p2EgdMO0aScpLCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCksIFtwZW5kaW5nLCBzZXRQZW5kaW5nXSA9IHVzZVN0YXRlKGZhbHNlKSwgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxEZXZpY2VTdWJzY3JpcHRpb24gfCBudWxsPihudWxsKSwgW3BhaXJpbmcsIHNldFBhaXJpbmddID0gdXNlU3RhdGU8VGVsZWdyYW1QYWlyaW5nIHwgbnVsbD4obnVsbCksIFtkZXZpY2VUZXN0TWVzc2FnZSwgc2V0RGV2aWNlVGVzdE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW2VuYWJsZWQsIHNldEVuYWJsZWRdID0gdXNlU3RhdGUoZmFsc2UpLCBbbWludXRlcywgc2V0TWludXRlc10gPSB1c2VTdGF0ZSgnJyksIFttYXgsIHNldE1heF0gPSB1c2VTdGF0ZSgnMicpLCBbcXVpZXQsIHNldFF1aWV0XSA9IHVzZVN0YXRlKGZhbHNlKSwgW3F1aWV0U3RhcnQsIHNldFF1aWV0U3RhcnRdID0gdXNlU3RhdGUoJzIyOjAwJyksIFtxdWlldEVuZCwgc2V0UXVpZXRFbmRdID0gdXNlU3RhdGUoJzA4OjAwJyksIFtwcmltYXJ5LCBzZXRQcmltYXJ5XSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSksIFtmYWxsYmFjaywgc2V0RmFsbGJhY2tdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKSwgW2NoYW5uZWwsIHNldENoYW5uZWxdID0gdXNlU3RhdGU8J25vbmUnIHwgJ3RlbGVncmFtJz4oJ25vbmUnKSwgW3VyZ2VudCwgc2V0VXJnZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IGVkaXRvciA9IHVzZVZlcnNpb25lZERyYWZ0KHtcclxuICAgICAgICBpZGVudGl0eTogYCR7c2hvcC5pZH06bm90aWZpY2F0aW9uLXBvbGljeWAsIHNvdXJjZTogcG9saWN5LmRhdGEgPyBub3RpZmljYXRpb25TbmFwc2hvdChwb2xpY3kuZGF0YS5kYXRhKSA6IHVuZGVmaW5lZCxcclxuICAgICAgICBkcmFmdDogeyBlbmFibGVkLCBtaW51dGVzLCBtYXgsIHF1aWV0LCBxdWlldFN0YXJ0LCBxdWlldEVuZCwgcHJpbWFyeSwgZmFsbGJhY2ssIGNoYW5uZWwsIHVyZ2VudCB9LFxyXG4gICAgICAgIGFwcGx5OiB2YWx1ZXMgPT4geyBzZXRFbmFibGVkKHZhbHVlcy5lbmFibGVkKTsgc2V0TWludXRlcyh2YWx1ZXMubWludXRlcyk7IHNldE1heCh2YWx1ZXMubWF4KTsgc2V0UXVpZXQodmFsdWVzLnF1aWV0KTsgc2V0UXVpZXRTdGFydCh2YWx1ZXMucXVpZXRTdGFydCk7IHNldFF1aWV0RW5kKHZhbHVlcy5xdWlldEVuZCk7IHNldFByaW1hcnkodmFsdWVzLnByaW1hcnkpOyBzZXRGYWxsYmFjayh2YWx1ZXMuZmFsbGJhY2spOyBzZXRDaGFubmVsKHZhbHVlcy5jaGFubmVsKTsgc2V0VXJnZW50KHZhbHVlcy51cmdlbnQpOyB9LFxyXG4gICAgICAgIHJlZnJlc2g6ICgpID0+IHBvbGljeS5yZWZldGNoKHsgdGhyb3dPbkVycm9yOiB0cnVlIH0pLFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBwb2xpY3lGb3JtID0gdXNlRHJhZnRGb3JtKGVkaXRvci5kaXJ0eSk7XHJcbiAgICBjb25zdCBkZXZpY2VSZWdpc3RlciA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuICAgICAgICBzZXRQZW5kaW5nKHRydWUpO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChfX01PQ0tfXykge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgcmVnaXN0ZXIuZXhlY3V0ZSh7IGJvZHk6IHsgZGV2aWNlTmFtZTogZGV2aWNlTmFtZS50cmltKCksIGVuZHBvaW50OiAnaHR0cHM6Ly9leGFtcGxlLnRlc3QvbW9jay1wdXNoJywgcDI1NmRoOiAnc3ludGhldGljLWRldmljZS1wdWJsaWMta2V5JywgYXV0aDogJ3N5bnRoZXRpYy1kZXZpY2UtYXV0aCcgfSB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBhc3NlcnRQdXNoQ2FwYWJpbGl0eSh7IHNlY3VyZUNvbnRleHQ6IHdpbmRvdy5pc1NlY3VyZUNvbnRleHQsIHNlcnZpY2VXb3JrZXI6ICdzZXJ2aWNlV29ya2VyJyBpbiBuYXZpZ2F0b3IsIHB1c2hNYW5hZ2VyOiAnUHVzaE1hbmFnZXInIGluIHdpbmRvdywgbm90aWZpY2F0aW9uOiAnTm90aWZpY2F0aW9uJyBpbiB3aW5kb3cgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IGltcG9ydC5tZXRhLmVudi5WSVRFX1dFQl9QVVNIX1BVQkxJQ19LRVk7XHJcbiAgICAgICAgICAgIGlmICgha2V5KVxyXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDaMawYSBjw7Mga2jDs2EgVkFQSUQgY8O0bmcga2hhaSB04burIGJhY2tlbmQgdHJvbmcgVklURV9XRUJfUFVTSF9QVUJMSUNfS0VZLicpO1xyXG4gICAgICAgICAgICBhc3NlcnRQdXNoUGVybWlzc2lvbkdyYW50ZWQoYXdhaXQgTm90aWZpY2F0aW9uLnJlcXVlc3RQZXJtaXNzaW9uKCkpO1xyXG4gICAgICAgICAgICBjb25zdCBzZXJ2aWNlID0gYXdhaXQgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIucmVnaXN0ZXIoJy9hcHAtc3cuanMnLCB7IHNjb3BlOiAnLycgfSk7XHJcbiAgICAgICAgICAgIGF3YWl0IG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLnJlYWR5O1xyXG4gICAgICAgICAgICBjb25zdCBzdWJzY3JpcHRpb24gPSBhd2FpdCBzZXJ2aWNlLnB1c2hNYW5hZ2VyLmdldFN1YnNjcmlwdGlvbigpIHx8IGF3YWl0IHNlcnZpY2UucHVzaE1hbmFnZXIuc3Vic2NyaWJlKHsgdXNlclZpc2libGVPbmx5OiB0cnVlLCBhcHBsaWNhdGlvblNlcnZlcktleTogYmFzZTY0Qnl0ZXMoa2V5KSB9KTtcclxuICAgICAgICAgICAgY29uc3QganNvbiA9IHN1YnNjcmlwdGlvbi50b0pTT04oKTtcclxuICAgICAgICAgICAgaWYgKCFqc29uLmVuZHBvaW50IHx8ICFqc29uLmtleXM/LnAyNTZkaCB8fCAhanNvbi5rZXlzLmF1dGgpXHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ8SQxINuZyBrw70gUHVzaCBraMO0bmcgdHLhuqMgxJHhu6cgZOG7ryBsaeG7h3UuJyk7XHJcbiAgICAgICAgICAgIGF3YWl0IHJlZ2lzdGVyLmV4ZWN1dGUoeyBib2R5OiB7IGRldmljZU5hbWU6IGRldmljZU5hbWUudHJpbSgpLCBlbmRwb2ludDoganNvbi5lbmRwb2ludCwgcDI1NmRoOiBqc29uLmtleXMucDI1NmRoLCBhdXRoOiBqc29uLmtleXMuYXV0aCB9IH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogbmV3IEVycm9yKCdLaMO0bmcgxJHEg25nIGvDvSDEkcaw4bujYyB0aGnhur90IGLhu4snKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRQZW5kaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgY29uc3QgdGVsZWdyYW1BdmFpbGFibGUgPSAhIWRldmljZXMuZGF0YT8uZGF0YS5zb21lKGQgPT4gZC5jaGFubmVsID09PSAndGVsZWdyYW0nICYmIGQuc3RhdHVzID09PSAnYWN0aXZlJyk7XHJcbiAgICBjb25zdCB0ZWxlZ3JhbUF2YWlsYWJpbGl0eVBlbmRpbmcgPSAhdGVsZWdyYW1BdmFpbGFibGUgJiYgKCFkZXZpY2VzLmRhdGEgfHwgZGV2aWNlcy5oYXNNb3JlIHx8IGRldmljZXMuaXNFcnJvcik7XHJcbiAgICBjb25zdCBwb2xpY3lFcnJvciA9IHZhbGlkYXRlUG9saWN5KHsgZW5hYmxlZCwgbWludXRlcywgbWF4LCBwcmltYXJ5LCBxdWlldCwgcXVpZXRTdGFydCwgcXVpZXRFbmQsIGNoYW5uZWwsIHRlbGVncmFtQXZhaWxhYmxlIH0pO1xyXG4gICAgY29uc3Qgc2F2ZVBvbGljeSA9IGFzeW5jICgpID0+IHsgaWYgKCFwb2xpY3kuZGF0YSB8fCBwb2xpY3lFcnJvcilcclxuICAgICAgICByZXR1cm47IGNvbnN0IHByZXBhcmVkID0gZWRpdG9yLnByZXBhcmUoKTsgaWYgKCFwcmVwYXJlZCkgcmV0dXJuO1xyXG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgZW5hYmxlZCwgbWludXRlcywgbWF4LCBxdWlldCwgcXVpZXRTdGFydCwgcXVpZXRFbmQsIHByaW1hcnksIGZhbGxiYWNrLCBjaGFubmVsLCB1cmdlbnQgfTtcclxuICAgICAgICBjb25zdCBib2R5OiBOb3RpZmljYXRpb25Qb2xpY3lXcml0ZSA9IHtcclxuICAgICAgICBleHBlY3RlZFZlcnNpb246IHByZXBhcmVkLnZlcnNpb24sIGVuYWJsZWQsIHRpbWV6b25lOiBwb2xpY3kuZGF0YS5kYXRhLnRpbWV6b25lLCBxdWlldEhvdXJzOiBxdWlldCA/IHsgc3RhcnQ6IHF1aWV0U3RhcnQsIGVuZDogcXVpZXRFbmQgfSA6IG51bGwsIHJlbWluZEFmdGVyTWludXRlczogbWludXRlcy50cmltKCkgPyBOdW1iZXIobWludXRlcykgOiBudWxsLCBtYXhSZW1pbmRlcnM6IE51bWJlcihtYXgpLCBwcmltYXJ5VXNlcklkczogcHJpbWFyeSwgZmFsbGJhY2tVc2VySWRzOiBmYWxsYmFjaywgZmFsbGJhY2tDaGFubmVsOiBjaGFubmVsLCB1cmdlbnRNYXlCeXBhc3NRdWlldEhvdXJzOiB1cmdlbnRcclxuICAgIH07IHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc2F2ZS5leGVjdXRlKHsgYm9keSB9KTtcclxuICAgICAgICBlZGl0b3IuY29tbWl0dGVkKG5vdGlmaWNhdGlvblNuYXBzaG90KHJlc3VsdC5kYXRhKSwgc3VibWl0dGVkKTtcclxuICAgIH1cclxuICAgIGNhdGNoIChlcnJvcikgeyBlZGl0b3IuZmFpbGVkKGVycm9yKTsgfSB9O1xyXG4gICAgY29uc3Qga25vd25Vc2VycyA9IG1lbWJlcnMuZGF0YT8uZGF0YS5maWx0ZXIobSA9PiBtLnN0YXR1cyA9PT0gJ2FjdGl2ZScpLm1hcChtID0+ICh7IGlkOiBtLnVzZXJJZCwgbGFiZWw6IG0udXNlcklkID09PSBzZXNzaW9uLnVzZXIuaWQgPyAnQuG6oW4nIDogbS51c2VySWQgfSkpIHx8IFt7IGlkOiBzZXNzaW9uLnVzZXIuaWQsIGxhYmVsOiAnQuG6oW4nIH1dO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRVc2VySWRzID0gWy4uLm5ldyBTZXQoWy4uLnByaW1hcnksIC4uLmZhbGxiYWNrXSldO1xyXG4gICAgY29uc3QgcmV0YWluZWRVc2VycyA9IHNlbGVjdGVkVXNlcklkcy5maWx0ZXIoaWQgPT4gIWtub3duVXNlcnMuc29tZSh1c2VyID0+IHVzZXIuaWQgPT09IGlkKSkubWFwKGlkID0+ICh7IGlkLCBsYWJlbDogYCR7aWR9ICjEkcOjIGzGsHUsIGNoxrBhIHThuqNpIHRow6BuaCB2acOqbilgIH0pKTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwixJBp4buHbiB0aG/huqFpICYgbOG7i2NoIHRy4buxY1wiIHN1YnRpdGxlPVwiVGhp4bq/dCBi4buLLCB4w6FjIG5o4bqtbiBuaOG6rW4gdmnhu4djLCBnaeG7nSB5w6puIGzhurduZyB2w6AgbmfGsOG7nWkgZOG7sSBwaMOybmcuXCIvPjxQYWdlU2VjdGlvbnM+PFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICcxZnInLCBsZzogJzEuMmZyIDFmcicgfX0gc2hyaW5rQ2hpbGRyZW4gZ2VvbWV0cnk9e3ttaW5XaWR0aDogMH19PjxQYWdlU2VjdGlvbnMgc2hyaW5rQ2hpbGRyZW4gZ2VvbWV0cnk9e3ttaW5XaWR0aDogMH19PjxQYW5lbCB0aXRsZT1cIlRoaeG6v3QgYuG7iyBuaOG6rW4gdGjDtG5nIGLDoW9cIiBib2R5TW9kZT1cImluc2V0XCI+PFN1cmZhY2VDb250ZW50ID48RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yIHx8IHJlZ2lzdGVyLmVycm9yIHx8IHRlc3QuZXJyb3IgfHwgcGFpci5lcnJvcn0vPntkZXZpY2VUZXN0TWVzc2FnZSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e2RldmljZVRlc3RNZXNzYWdlfTwvQWxlcnQ+fTxTdXJmYWNlQ29udGVudCBkaXJlY3Rpb249XCJyb3dcIiAgYWxpZ25JdGVtcz1cImNlbnRlclwiPjxTbWFydHBob25lUm91bmRlZCBzeD17eyBmb250U2l6ZTogdG9rZW5zLmljb25TaXplcy5kZXZpY2VQcmV2aWV3LCBjb2xvcjogJ3ByaW1hcnkubWFpbicgfX0vPjxUeXBvZ3JhcGh5PlRow7RuZyBiw6FvIHThu5FpIGdp4bqjbiB0csOqbiBtw6BuIGjDrG5oIGtow7NhOyB4ZW0gxJHhu4thIGNo4buJIGtow6FjaCBzYXUga2hpIMSRxINuZyBuaOG6rXAuPC9UeXBvZ3JhcGh5PjwvU3VyZmFjZUNvbnRlbnQ+PFRleHRGaWVsZCBsYWJlbD1cIlTDqm4gdGhp4bq/dCBi4buLXCIgdmFsdWU9e2RldmljZU5hbWV9IG9uQ2hhbmdlPXtlID0+IHNldERldmljZU5hbWUobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAxMjApKX0gLz48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm5vdGlmaWNhdGlvbnMubWFuYWdlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e3BlbmRpbmd9IGRpc2FibGVkPXshZGV2aWNlTmFtZS50cmltKCl9IG9uQ2xpY2s9eygpID0+IHZvaWQgZGV2aWNlUmVnaXN0ZXIoKX0+e19fTU9DS19fID8gJ03DtCBwaOG7j25nIMSRxINuZyBrw70gdGhp4bq/dCBi4buLJyA6ICdC4bqtdCB0aMO0bmcgYsOhbyB0csOqbiB0aGnhur90IGLhu4sgbsOgeSd9PC9NdXRhdGlvbkJ1dHRvbj57X19NT0NLX18gJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPk3DtCBwaOG7j25nIGtow7RuZyB5w6p1IGPhuqd1IHF1eeG7gW4gaOG7hyDEkWnhu4F1IGjDoG5oLCBraMO0bmcgxJHEg25nIGvDvSBQdXNoIHRo4bqtdCB2w6AgZ2nhu68gdGhp4bq/dCBi4buLIOG7nyB0cuG6oW5nIHRow6FpIGNo4budIHjDoWMgbWluaC48L0FsZXJ0Pn08L1N1cmZhY2VDb250ZW50PntkZXZpY2VzLmlzRXJyb3IgJiYgIWRldmljZXMuZGF0YSA/IG51bGwgOiA8UXVlcnlTdGF0ZSBxdWVyeT17ZGV2aWNlc30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2RldmljZXMuZGF0YSAmJiA8RGF0YVRhYmxlIHJvd3M9e2RldmljZXMuZGF0YS5kYXRhfSByb3dLZXk9e2QgPT4gZC5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnbmFtZScsIGxhYmVsOiAnVGhp4bq/dCBi4buLJywgcmVuZGVyOiBkID0+IGQuZGV2aWNlTmFtZSB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBkID0+IDxTdGF0dXMgdmFsdWU9e2Quc3RhdHVzfS8+IH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6ICdhY3Rpb25zJywgbGFiZWw6ICcnLCByZW5kZXI6IGQgPT4gPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGZsZXhXcmFwPVwid3JhcFwiPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibm90aWZpY2F0aW9ucy5tYW5hZ2VcIiBkaXNhYmxlZD17ZC5zdGF0dXMgPT09ICdyZXZva2VkJ30gYnVzeT17dGVzdC5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IHRlc3QuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogZC5pZCB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogZC52ZXJzaW9uIH0gfSk7IHNldERldmljZVRlc3RNZXNzYWdlKF9fTU9DS19fID8gJ03DtCBwaOG7j25nOiBjaMawYSBn4butaSBQdXNoIHRo4bqtdDsgdGhp4bq/dCBi4buLIHbhuqtuIGNo4budIHjDoWMgbWluaC4nIDogJ1nDqnUgY+G6p3Uga2nhu4NtIHRyYSDEkcOjIMSRxrDhu6NjIHRp4bq/cCBuaOG6rW47IHhlbSB0cuG6oW5nIHRow6FpIGJhY2tlbmQgdHLGsOG7m2Mga2hpIGvhur90IGx14bqtbiDEkcOjIGfhu61pLicpOyB9IGNhdGNoIHsgc2V0RGV2aWNlVGVzdE1lc3NhZ2UoX19NT0NLX18gPyAnTcO0IHBo4buPbmc6IGtow7RuZyBn4butaSBQdXNoIHRo4bqtdDsga2nhu4NtIHRyYSBi4buLIHThu6sgY2jhu5FpIHbDoCB0cuG6oW5nIHRow6FpIHRoaeG6v3QgYuG7iyBraMO0bmcgxJHhu5VpLicgOiAnJyk7IH0gfX0+e19fTU9DS19fID8gJ0tp4buDbSB0cmEgbcO0IHBo4buPbmcnIDogJ0fhu61pIHRo4butJ308L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibm90aWZpY2F0aW9ucy5tYW5hZ2VcIiBjb2xvcj1cImVycm9yXCIgZGlzYWJsZWQ9e2Quc3RhdHVzID09PSAncmV2b2tlZCd9IG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKGQpfT5UaHUgaOG7k2k8L011dGF0aW9uQnV0dG9uPjwvU3RhY2s+XHJcbiAgICAgICAgfVxyXG4gICAgXX0vPn08L1F1ZXJ5U3RhdGU+fTxMb29rdXBMb2FkTW9yZSBsYWJlbD1cInRoaeG6v3QgYuG7i1wiIGxvYWRlZENvdW50PXtkZXZpY2VzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtkZXZpY2VzLmhhc01vcmV9IGJ1c3k9e2RldmljZXMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17ZGV2aWNlcy5sb2FkTW9yZX0vPntkZXZpY2VzLmlzRXJyb3IgJiYgPFN1cmZhY2VDb250ZW50ID48RXJyb3JOb3RpY2UgZXJyb3I9e2RldmljZXMuZXJyb3J9Lz48QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAoZGV2aWNlcy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IGRldmljZXMubG9hZE1vcmUoKSA6IGRldmljZXMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCB0aGnhur90IGLhu4s8L0J1dHRvbj48L1N1cmZhY2VDb250ZW50Pn08L1BhbmVsPjxQYW5lbCB0aXRsZT1cIlRlbGVncmFtIGThu7EgcGjDsm5nXCIgYm9keU1vZGU9XCJpbnNldFwiPjxTdXJmYWNlQ29udGVudCA+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkNo4buJIGxpw6puIGvhur90IHF1YSBtw6MgbeG7mXQgbOG6p24uIEtow7RuZyBkw6FuIGJvdCB0b2tlbiB2w6BvIHRyw6xuaCBkdXnhu4d0LjwvVHlwb2dyYXBoeT48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm5vdGlmaWNhdGlvbnMubWFuYWdlXCIgdmFyaWFudD1cIm91dGxpbmVkXCIgYnVzeT17cGFpci5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgY29uc3QgciA9IGF3YWl0IHBhaXIuZXhlY3V0ZSgpO1xyXG4gICAgICAgIHNldFBhaXJpbmcoci5kYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PlThuqFvIG3DoyBsacOqbiBr4bq/dDwvTXV0YXRpb25CdXR0b24+e3BhaXJpbmcgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPntfX01PQ0tfXyA/ICdNw6MgbWluaCBo4buNYSwga2jDtG5nIGTDuW5nIMSR4buDIGxpw6puIGvhur90IHRo4bqtdC4gJyA6ICcnfUJvdDoge3BhaXJpbmcuYm90VXNlcm5hbWV9PGJyIC8+TcOjOiB7cGFpcmluZy5wYWlyaW5nQ29kZX08YnIgLz5I4bq/dCBo4bqhbiB7ZGF0ZVRpbWUocGFpcmluZy5leHBpcmVzQXQsIHNob3AudGltZXpvbmUpfTwvQWxlcnQ+fTwvU3VyZmFjZUNvbnRlbnQ+PC9QYW5lbD48L1BhZ2VTZWN0aW9ucz48UGFuZWwgdGl0bGU9XCJRdXkgdOG6r2Mgbmjhuq1uIHbDoCBuaOG6r2Mgdmnhu4djXCIgYm9keU1vZGU9XCJpbnNldFwiPjxRdWVyeVN0YXRlIHF1ZXJ5PXtwb2xpY3l9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPjxGb3JtRmllbGRzIGNvbXBvbmVudD1cImZvcm1cIiByZWY9e3BvbGljeUZvcm19IG9uU3VibWl0PXtldmVudCA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHZvaWQgc2F2ZVBvbGljeSgpOyB9fT48RXJyb3JOb3RpY2UgZXJyb3I9e3NhdmUuZXJyb3J9Lz48RHJhZnRDb25mbGljdCBlZGl0b3I9e2VkaXRvcn0gbGFiZWxzPXt7IGVuYWJsZWQ6ICdC4bqtdCBxdXkgdOG6r2MnLCBtaW51dGVzOiAnTmjhuq9jIHNhdSAocGjDunQpJywgbWF4OiAnU+G7kSBs4bqnbiBuaOG6r2MnLCBxdWlldDogJ0dp4budIHnDqm4gbOG6t25nJywgcXVpZXRTdGFydDogJ0dp4budIGLhuq90IMSR4bqndScsIHF1aWV0RW5kOiAnR2nhu50ga+G6v3QgdGjDumMnLCBwcmltYXJ5OiAnTmfGsOG7nWkgbmjhuq1uIGNow61uaCcsIGZhbGxiYWNrOiAnTmfGsOG7nWkgZOG7sSBwaMOybmcnLCBjaGFubmVsOiAnS8OqbmggZOG7sSBwaMOybmcnLCB1cmdlbnQ6ICfGr3UgdGnDqm4ga2jhuqluJyB9fSBidXN5PXtzYXZlLnBlbmRpbmd9Lz48Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIkLhuq10IHF1eSB04bqvYyB0aMO0bmcgYsOhb1wiIGNvbnRyb2w9ezxDaGVja2JveCBjaGVja2VkPXtlbmFibGVkfSBvbkNoYW5nZT17ZSA9PiBzZXRFbmFibGVkKGUudGFyZ2V0LmNoZWNrZWQpfS8+fS8+PFRleHRGaWVsZCBsYWJlbD1cIk5o4bqvYyBzYXUgKHBow7p0KSwgxJHhu4MgdHLhu5FuZyBu4bq/dSBjaMawYSBjaOG7kXRcIiB2YWx1ZT17bWludXRlc30gb25DaGFuZ2U9e2UgPT4gc2V0TWludXRlcyhlLnRhcmdldC52YWx1ZSl9IHR5cGU9XCJudW1iZXJcIiBpbnB1dFByb3BzPXt7IG1pbjogMSB9fS8+PFRleHRGaWVsZCBsYWJlbD1cIlPhu5EgbOG6p24gbmjhuq9jIHThu5FpIMSRYVwiIHZhbHVlPXttYXh9IG9uQ2hhbmdlPXtlID0+IHNldE1heChlLnRhcmdldC52YWx1ZSl9IHR5cGU9XCJudW1iZXJcIiBpbnB1dFByb3BzPXt7IG1pbjogMCB9fS8+PFRleHRGaWVsZCBsYWJlbD1cIlTDrG0gdGjDoG5oIHZpw6puXCIgdmFsdWU9e21lbWJlclNlYXJjaElucHV0fSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TWVtYmVyU2VhcmNoSW5wdXQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VNZW1iZXJzfSBoZWxwZXJUZXh0PVwiVMOsbSBraeG6v20gZMO5bmcgcSBj4bunYSBsaXN0TWVtYmVyczsgbcOjIG5nxrDhu51pIG5o4bqtbiDEkcOjIGzGsHUgbHXDtG4gxJHGsOG7o2MgZ2nhu68uXCIvPjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTmfGsOG7nWkgbmjhuq1uIGNow61uaFwiIHZhbHVlPXtwcmltYXJ5fSBzbG90UHJvcHM9e3sgc2VsZWN0OiB7IG11bHRpcGxlOiB0cnVlIH0gfX0gb25DaGFuZ2U9e2UgPT4gc2V0UHJpbWFyeSh0eXBlb2YgZS50YXJnZXQudmFsdWUgPT09ICdzdHJpbmcnID8gZS50YXJnZXQudmFsdWUuc3BsaXQoJywnKSA6IGUudGFyZ2V0LnZhbHVlKX0+e1suLi5yZXRhaW5lZFVzZXJzLCAuLi5rbm93blVzZXJzXS5tYXAodSA9PiA8TWVudUl0ZW0ga2V5PXt1LmlkfSB2YWx1ZT17dS5pZH0+e3UubGFiZWx9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTmfGsOG7nWkgZOG7sSBwaMOybmdcIiB2YWx1ZT17ZmFsbGJhY2t9IHNsb3RQcm9wcz17eyBzZWxlY3Q6IHsgbXVsdGlwbGU6IHRydWUgfSB9fSBvbkNoYW5nZT17ZSA9PiBzZXRGYWxsYmFjayh0eXBlb2YgZS50YXJnZXQudmFsdWUgPT09ICdzdHJpbmcnID8gZS50YXJnZXQudmFsdWUuc3BsaXQoJywnKSA6IGUudGFyZ2V0LnZhbHVlKX0+e1suLi5yZXRhaW5lZFVzZXJzLCAuLi5rbm93blVzZXJzXS5tYXAodSA9PiA8TWVudUl0ZW0ga2V5PXt1LmlkfSB2YWx1ZT17dS5pZH0+e3UubGFiZWx9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cInRow6BuaCB2acOqblwiIGxvYWRlZENvdW50PXttZW1iZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXttZW1iZXJzLmhhc01vcmV9IGJ1c3k9e21lbWJlcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17bWVtYmVycy5sb2FkTW9yZX0vPnttZW1iZXJzLmlzRXJyb3IgJiYgPFN1cmZhY2VDb250ZW50ID48RXJyb3JOb3RpY2UgZXJyb3I9e21lbWJlcnMuZXJyb3J9Lz48QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAobWVtYmVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IG1lbWJlcnMubG9hZE1vcmUoKSA6IG1lbWJlcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCB0aMOgbmggdmnDqm48L0J1dHRvbj48L1N1cmZhY2VDb250ZW50Pn17dGVsZWdyYW1BdmFpbGFiaWxpdHlQZW5kaW5nICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiByb2xlPVwic3RhdHVzXCI+e2RldmljZXMuaXNFcnJvciA/ICdLaMO0bmcgeMOhYyBtaW5oIMSRxrDhu6NjIGRhbmggc8OhY2ggdGhp4bq/dCBi4buLOyBow6N5IHRo4butIGzhuqFpIHRyxrDhu5tjIGtoaSBr4bq/dCBsdeG6rW4ga2jDtG5nIGPDsyBUZWxlZ3JhbSDEkWFuZyBob+G6oXQgxJHhu5luZy4nIDogZGV2aWNlcy5oYXNNb3JlID8gJ0NoxrBhIHThuqNpIGjhur90IHRoaeG6v3QgYuG7izsgaMOjeSB04bqjaSB0aMOqbSB0csaw4bubYyBraGkga+G6v3QgbHXhuq1uIGtow7RuZyBjw7MgVGVsZWdyYW0gxJFhbmcgaG/huqF0IMSR4buZbmcuJyA6ICfEkGFuZyB04bqjaSBkYW5oIHPDoWNoIHRoaeG6v3QgYuG7iyDEkeG7gyB4w6FjIG1pbmggdHLhuqFuZyB0aMOhaSBUZWxlZ3JhbS4nfTwvQWxlcnQ+fTxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiS8OqbmggZOG7sSBwaMOybmdcIiB2YWx1ZT17Y2hhbm5lbH0gb25DaGFuZ2U9e2UgPT4gc2V0Q2hhbm5lbChlLnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgY2hhbm5lbCl9PjxNZW51SXRlbSB2YWx1ZT1cIm5vbmVcIj5DaMawYSBi4bqtdDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwidGVsZWdyYW1cIiBkaXNhYmxlZD17IXRlbGVncmFtQXZhaWxhYmxlfT57dGVsZWdyYW1BdmFpbGFibGUgPyAnVGVsZWdyYW0gxJHDoyBsacOqbiBr4bq/dCcgOiB0ZWxlZ3JhbUF2YWlsYWJpbGl0eVBlbmRpbmcgPyAnQ2jGsGEgeMOhYyBtaW5oIFRlbGVncmFtJyA6ICdUZWxlZ3JhbSAoY2jGsGEgY8OzIHRoaeG6v3QgYuG7iyBhY3RpdmUpJ308L01lbnVJdGVtPjwvVGV4dEZpZWxkPntjaGFubmVsID09PSAndGVsZWdyYW0nICYmICF0ZWxlZ3JhbUF2YWlsYWJsZSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+TcOjIGdow6lwIMSRw7RpIG3DtCBwaOG7j25nIGtow7RuZyBsacOqbiBr4bq/dCBUZWxlZ3JhbS4gQ2jhu4kgY2jhu41uIGvDqm5oIG7DoHkga2hpIGRhbmggc8OhY2ggY8OzIHRoaeG6v3QgYuG7iyBUZWxlZ3JhbSBhY3RpdmUuPC9BbGVydD59PEZvcm1Db250cm9sTGFiZWwgbGFiZWw9XCJDw7MgZ2nhu50gecOqbiBs4bq3bmdcIiBjb250cm9sPXs8Q2hlY2tib3ggY2hlY2tlZD17cXVpZXR9IG9uQ2hhbmdlPXtlID0+IHNldFF1aWV0KGUudGFyZ2V0LmNoZWNrZWQpfS8+fS8+e3F1aWV0ICYmIDxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogXCJjb2x1bW5cIiwgc206IFwicm93XCIgfX0+PFRleHRGaWVsZCB0eXBlPVwidGltZVwiIGxhYmVsPVwiVOG7q1wiIHZhbHVlPXtxdWlldFN0YXJ0fSBvbkNoYW5nZT17ZSA9PiBzZXRRdWlldFN0YXJ0KGUudGFyZ2V0LnZhbHVlKX0gZnVsbFdpZHRoLz48VGV4dEZpZWxkIHR5cGU9XCJ0aW1lXCIgbGFiZWw9XCLEkOG6v25cIiB2YWx1ZT17cXVpZXRFbmR9IG9uQ2hhbmdlPXtlID0+IHNldFF1aWV0RW5kKGUudGFyZ2V0LnZhbHVlKX0gZnVsbFdpZHRoLz48L0ZpZWxkR3JvdXA+fTxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCI+VGhlbyBtw7ppIGdp4budIHtzaG9wLnRpbWV6b25lfTwvVHlwb2dyYXBoeT48Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIkNobyBwaMOpcCB0aMO0bmcgYsOhbyBraOG6qW4gdsaw4bujdCBnaeG7nSB5w6puIGzhurduZ1wiIGNvbnRyb2w9ezxDaGVja2JveCBjaGVja2VkPXt1cmdlbnR9IG9uQ2hhbmdlPXtlID0+IHNldFVyZ2VudChlLnRhcmdldC5jaGVja2VkKX0vPn0vPntwb2xpY3lFcnJvciAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPntwb2xpY3lFcnJvcn08L0FsZXJ0Pn08L0Zvcm1GaWVsZHM+PEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cImNvbHVtblwiIGJlZm9yZUdhcD1cImZvcm1cIj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm5vdGlmaWNhdGlvbnMubWFuYWdlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e3NhdmUucGVuZGluZ30gZGlzYWJsZWQ9eyFwb2xpY3kuZGF0YSB8fCAhIXBvbGljeUVycm9yIHx8IHNhdmUucGVuZGluZ30gb25DbGljaz17KCkgPT4gdm9pZCBzYXZlUG9saWN5KCl9PkzGsHUgcXV5IHThuq9jPC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPjwvUXVlcnlTdGF0ZT48L1BhbmVsPjwvU2VjdGlvbkdyaWQ+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIGRhdGEtdGVzdGlkPVwibm90aWZpY2F0aW9uLXByb3RlY3Rpb24tbm90ZVwiPkNo4buRbmcgZ+G7rWkgbOG6t3AgdGhlbyBz4buxIGtp4buHbiwga2nhu4NtIHRyYSBjYWxsYmFjaywgdGjhu51pIGjhuqFuIHRva2VuIHbDoCBnaeG7m2kgaOG6oW4gdOG7kWMgxJHhu5kgcGjhuqNpIMSRxrDhu6NjIGLhuqNvIMSR4bqjbSBi4bufaSBk4buLY2ggduG7pS4gQuG6o24gZGVtbyBraMO0bmcgcGjDoXQgdGjDtG5nIGLDoW8gdGjhuq10IHbDoCBraMO0bmcgeMOhYyBtaW5oIGPDoWMgbOG7m3AgYuG6o28gduG7hyBwaMOtYSBtw6F5IGNo4bunLjwvQWxlcnQ+PC9QYWdlU2VjdGlvbnM+PENvbmZpcm1EaWFsb2cgb3Blbj17ISFzZWxlY3RlZH0gdGl0bGU9XCJUaHUgaOG7k2kgdGhp4bq/dCBi4buLXCIgZGVzY3JpcHRpb249XCJNw6F5IGNo4bunIHBo4bqjaSBk4burbmcgbeG7jWkgdGjDtG5nIGLDoW8gxJHhur9uIHN1YnNjcmlwdGlvbiBuw6B5LlwiIG9uQ2xvc2U9eygpID0+IHNldFNlbGVjdGVkKG51bGwpfSBidXN5PXtyZXZva2UucGVuZGluZ30gZXJyb3I9e3Jldm9rZS5lcnJvcn0gb25Db25maXJtPXsoKSA9PiByZXZva2UuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2VsZWN0ZWQ/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzZWxlY3RlZD8udmVyc2lvbiB8fCAxIH0gfSl9Lz48Lz47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG5vdGlmaWNhdGlvblNuYXBzaG90KHBvbGljeTogTm90aWZpY2F0aW9uUG9saWN5KSB7XHJcbiAgICByZXR1cm4geyB2ZXJzaW9uOiBwb2xpY3kudmVyc2lvbiwgdmFsdWVzOiB7IGVuYWJsZWQ6IHBvbGljeS5lbmFibGVkLCBtaW51dGVzOiBwb2xpY3kucmVtaW5kQWZ0ZXJNaW51dGVzPy50b1N0cmluZygpIHx8ICcnLCBtYXg6IFN0cmluZyhwb2xpY3kubWF4UmVtaW5kZXJzKSwgcXVpZXQ6ICEhcG9saWN5LnF1aWV0SG91cnMsIHF1aWV0U3RhcnQ6IHBvbGljeS5xdWlldEhvdXJzPy5zdGFydCB8fCAnMjI6MDAnLCBxdWlldEVuZDogcG9saWN5LnF1aWV0SG91cnM/LmVuZCB8fCAnMDg6MDAnLCBwcmltYXJ5OiBwb2xpY3kucHJpbWFyeVVzZXJJZHMsIGZhbGxiYWNrOiBwb2xpY3kuZmFsbGJhY2tVc2VySWRzLCBjaGFubmVsOiBwb2xpY3kuZmFsbGJhY2tDaGFubmVsLCB1cmdlbnQ6IHBvbGljeS51cmdlbnRNYXlCeXBhc3NRdWlldEhvdXJzIH0gfTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9ub3RpZmljYXRpb25zL2luZGV4LnRzeCJ9