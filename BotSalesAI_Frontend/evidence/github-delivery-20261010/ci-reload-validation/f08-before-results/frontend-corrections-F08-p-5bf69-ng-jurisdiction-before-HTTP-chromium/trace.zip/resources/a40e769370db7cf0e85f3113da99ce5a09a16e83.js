import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/workspace/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/react_jsx-dev-runtime.js?v=2fdea4aa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s0 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import { ActionGroup, FieldGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport5_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/react.js?v=2fdea4aa"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useRef = __vite__cjsImport5_react["useRef"]; const useState = __vite__cjsImport5_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Link as RouterLink, Navigate, useLocation, useNavigate, useParams, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/react-router-dom.js?v=efff4962";
import { useQuery, useQueryClient } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/@tanstack_react-query.js?v=e1f23df4";
import { Alert, Avatar, Box, Button, Checkbox, FormControlLabel, MenuItem, Paper, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/@mui_material.js?v=237cc5ba";
import SmartToyRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/@mui_icons-material_SmartToyRounded.js?v=297e3e34";
import ArrowForwardRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-85408-8fb017a2-a986-477e-8bcd-aad65cddc217-frontend-corrections/deps/@mui_icons-material_ArrowForwardRounded.js?v=95a12d6a";
import { permissionCatalog } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/contracts/src/index.ts";
import { colors } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { request, setCsrfToken } from "/src/shared/api/client.ts";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { ApiError } from "/src/shared/api/errors.ts";
import { assertSchema } from "/src/shared/api/validation.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { codePointLength, limitCodePoints, dateTime, safeInternalPath, isValidTimeZone } from "/src/shared/model/format.ts";
import { authorizedDownloadHref } from "/src/shared/model/download.ts";
import { useListQuery } from "/src/shared/model/filters.ts";
import { markDraftClean, useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { PageHeader, Panel, QueryState, DataTable, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine, LookupLoadMore, Empty } from "/src/shared/ui/components.tsx";
import { useSession } from "/src/shared/model/auth.ts";
function AuthCard({
  children
}) {
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.centeredFallback, { bgcolor: "background.default", outline: "none" }], children: /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: [layoutSx.auth.surfaceInset, { width: "100%", maxWidth: 520, borderRadius: visualSx.radius.hero }], children: [
    /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: layoutSx.auth.brandMarkGap, children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: "primary.main", color: colors.onAccent }, children: /* @__PURE__ */ jsxDEV(SmartToyRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 451
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 386
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: visualSx.typography.fontWeight.extraBold, children: [
        "BotSales ",
        /* @__PURE__ */ jsxDEV(Box, { component: "span", color: "primary.main", children: "AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 49,
          columnNumber: 567
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 49,
        columnNumber: 479
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 49,
      columnNumber: 311
    }, this),
    children
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 49,
    columnNumber: 181
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 49,
    columnNumber: 36
  }, this);
}
_c = AuthCard;
export function LoginPage() {
  _s();
  const { session, loading } = useSession();
  const [params] = useSearchParams();
  const [pending, setPending] = useState(false), [error, setError] = useState(null);
  const login = async () => {
    setPending(true);
    setError(null);
    try {
      const csrf = await request("getCsrfToken");
      setCsrfToken(csrf.data.csrfToken);
      const auth = await request("beginLogin", { body: { returnTo: safeInternalPath(params.get("returnTo") || "/workspaces") } });
      const url = new URL(auth.data.authorizationUrl);
      if (url.protocol !== "https:" && !(__MOCK__ && url.origin === location.origin))
        throw new Error("Địa chỉ đăng nhập không an toàn.");
      window.location.assign(url.href);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không bắt đầu được đăng nhập"));
      setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: layoutSx.auth.brandTitleGap, children: "Chào mừng trở lại" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: [layoutSx.pageHeader.titleDescriptionGap, layoutSx.pageHeader.afterGap], children: "Một không gian cho bán hàng, kho, kế toán và đội ngũ AI của bạn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 123
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 312
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.pageHeader.afterGap, children: "Chế độ xem frontend: tài khoản giả lập, không có mật khẩu thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 354
    }, this),
    session ? /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, component: RouterLink, to: "/workspaces", variant: "contained", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 581
    }, this), children: "Tiếp tục vào cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 494
    }, this) : /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, variant: "contained", size: "large", onClick: () => void login(), disabled: pending || loading, children: pending ? "Đang chuyển đến đăng nhập…" : __MOCK__ ? "Vào tài khoản mô phỏng" : "Đăng nhập bằng tài khoản công ty" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 639
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: [layoutSx.page.sectionBefore, { display: "block" }], children: "Phiên đăng nhập được quản lý ở máy chủ. Không lưu access token trong localStorage." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 67,
      columnNumber: 874
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 67,
    columnNumber: 10
  }, this);
}
_s(LoginPage, "tICyXXnoQDGPm2VsFQW+6n6svQk=", false, function() {
  return [useSession, useSearchParams];
});
_c2 = LoginPage;
export function WorkspacesPage() {
  _s2();
  const { session, loading, error: sessionError } = useSession();
  const shops = useQuery({ queryKey: ["shops", session?.user.id], queryFn: ({ signal }) => request("listShops", { signal }), enabled: !!session, retry: false });
  const isEmpty = !shops.isError && shops.data?.data.length === 0;
  const createShopButton = /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/onboarding", variant: "contained", children: "Tạo cửa hàng" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 73,
    columnNumber: 28
  }, this);
  if (!loading && !session && sessionError instanceof ApiError && sessionError.status === 401)
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 75,
      columnNumber: 10
    }, this);
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.pageFallbackInset, { maxWidth: 1100, mx: "auto", outline: "none" }], children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Chọn cửa hàng", subtitle: "Mỗi cửa hàng là một vùng dữ liệu và quyền độc lập.", actions: !isEmpty && createShopButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 153
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: sessionError }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 290
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: shops, pendingProfile: "section", children: isEmpty ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có cửa hàng.", action: createShopButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 388
    }, this) : /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "minmax(0, 1fr)", md: shops.data?.data.length === 1 ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))" }, children: shops.data?.data.map((s) => /* @__PURE__ */ jsxDEV(Paper, { variant: "outlined", sx: [layoutSx.surface.inset, { borderRadius: visualSx.radius.large }], children: [
      /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: colors.selected, color: "primary.main" }, children: s.name[0] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 720
      }, this),
      /* @__PURE__ */ jsxDEV(SurfaceContent, { beforeGap: "surface", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", children: s.name }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 841
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: [
          s.currency,
          " · ",
          s.timezone
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 887
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Quyền: ",
          session?.memberships.find((m) => m.shopId === s.id)?.roles.map((role) => businessLabel(role)).join(", ") || "Chưa có quyền"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 76,
          columnNumber: 962
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 805
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: `/s/${s.id}/overview`, fullWidth: true, variant: "outlined", endIcon: /* @__PURE__ */ jsxDEV(ArrowForwardRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 1273
      }, this), sx: layoutSx.page.sectionBefore, children: "Mở cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 76,
        columnNumber: 1177
      }, this)
    ] }, s.id, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 612
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 451
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 76,
      columnNumber: 326
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 76,
    columnNumber: 10
  }, this);
}
_s2(WorkspacesPage, "9VKV6RNilsXVUNYTqRFP3NwfT3I=", false, function() {
  return [useSession, useQuery];
});
_c3 = WorkspacesPage;
export function OnboardingPage() {
  _s3();
  const navigate = useNavigate();
  const { refresh } = useSession();
  const cache = useQueryClient();
  const [name, setName] = useState(""), [currency, setCurrency] = useState("VND"), [timezone, setTimezone] = useState("Asia/Vientiane"), [pending, setPending] = useState(false), [error, setError] = useState(null), [timezoneTouched, setTimezoneTouched] = useState(false), [submitted, setSubmitted] = useState(false);
  const formElement = useRef(null);
  const baseline = useRef({ name: "", currency: "VND", timezone: "Asia/Vientiane" });
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const bindDraft = useDraftForm(name !== baseline.current.name || currency !== baseline.current.currency || timezone !== baseline.current.timezone);
  const timezoneError = !isValidTimeZone(timezone) ? "Nhập múi giờ hợp lệ, ví dụ Asia/Vientiane." : "";
  const save = async () => {
    setSubmitted(true);
    if (pending || !name.trim() || timezoneError) return;
    setPending(true);
    setError(null);
    try {
      const r = await request("createShop", { body: { name, currency, timezone, locale: "vi-VN" } });
      await refresh();
      await cache.invalidateQueries({ queryKey: ["shops"] });
      if (!mounted.current) return;
      baseline.current = { name, currency, timezone };
      if (formElement.current) markDraftClean(formElement.current);
      navigate(`/s/${r.data.id}/overview`);
    } catch (e) {
      if (mounted.current) setError(e instanceof Error ? e : new Error("Không tạo được cửa hàng"));
    } finally {
      if (mounted.current) setPending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthCard, { children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", sx: layoutSx.auth.brandTitleGap, children: "Tạo cửa hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: [layoutSx.pageHeader.titleDescriptionGap, layoutSx.pageHeader.afterGap], children: "Chọn tiền tệ cơ sở trước khi ghi nhận giao dịch." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 118
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 291
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { component: "form", noValidate: true, ref: (element) => {
      formElement.current = element;
      bindDraft(element);
    }, onSubmit: (event) => {
      event.preventDefault();
      void save();
    }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Tên cửa hàng", value: name, onChange: (e) => setName(limitCodePoints(e.target.value, 160)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 491
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Tiền tệ cơ sở", select: true, value: currency, onChange: (e) => setCurrency(e.target.value), children: ["VND", "LAK", "THB", "USD"].map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c, children: c }, c, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 784
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 621
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { disabled: pending, label: "Múi giờ", value: timezone, onBlur: () => setTimezoneTouched(true), onChange: (e) => setTimezone(e.target.value), error: (timezoneTouched || submitted) && !!timezoneError, helperText: (timezoneTouched || submitted) && timezoneError ? timezoneError : "Ví dụ: Asia/Vientiane" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 840
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giao diện Graphite Gold dark-only đã chốt. Những chính sách thật và kết nối ngoài chưa tự bật khi tạo shop." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1152
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", disabled: !name.trim() || pending, children: "Tạo cửa hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1290
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: "/workspaces", children: "Quay lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 104,
        columnNumber: 1388
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 104,
      columnNumber: 320
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 104,
    columnNumber: 10
  }, this);
}
_s3(OnboardingPage, "+O2BjTy3yRtrAgt9iSgKUSEAFUI=", false, function() {
  return [useNavigate, useSession, useQueryClient, useDraftForm];
});
_c4 = OnboardingPage;
export function ShopSettingsPage() {
  _s4();
  const scope = useScope();
  const { shop } = scope;
  const cache = useQueryClient();
  const canManageShop = useCan("shop.manage");
  const update = useCommand("updateShop", ["getShop"]);
  const [name, setName] = useState(shop.name), [timezone, setTimezone] = useState(shop.timezone), [locale, setLocale] = useState(shop.locale), [error, setError] = useState(null), [saved, setSaved] = useState(false), [timezoneTouched, setTimezoneTouched] = useState(false), [settingsSubmitted, setSettingsSubmitted] = useState(false);
  const latestShop = useApi("getShop");
  const currentShop = latestShop.data && latestShop.data.data.version >= shop.version ? latestShop.data.data : shop;
  const editor = useVersionedDraft({
    identity: `${shop.id}:settings`,
    source: { version: currentShop.version, values: { name: currentShop.name, timezone: currentShop.timezone, locale: currentShop.locale } },
    draft: { name, timezone, locale },
    apply: (values) => {
      setName(values.name);
      setTimezone(values.timezone);
      setLocale(values.locale);
    },
    refresh: () => latestShop.refetch({ throwOnError: true })
  });
  const formRef = useDraftForm(editor.dirty);
  const timezoneError = !isValidTimeZone(timezone) ? "Nhập múi giờ hợp lệ, ví dụ Asia/Vientiane." : "";
  const save = async () => {
    setSettingsSubmitted(true);
    if (!name.trim() || timezoneError) return;
    setError(null);
    setSaved(false);
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { name, timezone, locale };
    try {
      const result = await update.execute({ path: { shopId: shop.id }, version: prepared.version, body: prepared.patch });
      cache.setQueryData(["shop", scope.session.user.id, shop.id, scope.membership.permissionVersion], result);
      editor.committed({ version: result.data.version, values: { name: result.data.name, timezone: result.data.timezone, locale: result.data.locale } }, submitted);
      setSaved(true);
    } catch (error2) {
      editor.failed(error2);
      setError(error2 instanceof Error ? error2 : new Error("Không lưu được cấu hình"));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thiết lập cửa hàng", subtitle: "Cấu hình riêng của shop không thay đổi quy tắc AI lập trình hoặc màu đã duyệt." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Thông tin cơ sở", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: formRef, noValidate: true, onSubmit: (event) => {
        event.preventDefault();
        void save();
      }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || update.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 144,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { name: "Tên cửa hàng", timezone: "Múi giờ", locale: "Ngôn ngữ" }, busy: update.pending }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 145,
          columnNumber: 21
        }, this),
        saved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã lưu cấu hình cửa hàng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 146,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tên cửa hàng", value: name, disabled: !canManageShop, onChange: (event) => {
            setName(event.target.value);
            setSaved(false);
          }, sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 148,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tiền tệ cơ sở", value: shop.currency, disabled: true, helperText: "Không đổi tiền tệ bằng sửa giao diện. Cần kế hoạch chuyển đổi dữ liệu.", sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 149,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 147,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Múi giờ", value: timezone, disabled: !canManageShop, onBlur: () => setTimezoneTouched(true), onChange: (event) => {
            setTimezone(event.target.value);
            setSaved(false);
          }, error: (timezoneTouched || settingsSubmitted) && !!timezoneError, helperText: (timezoneTouched || settingsSubmitted) && timezoneError ? timezoneError : "Áp dụng cho ngày giờ theo cửa hàng.", sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 152,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Ngôn ngữ giao diện", value: "Tiếng Việt", disabled: true, helperText: `Giao diện hiện chỉ hỗ trợ tiếng Việt. Locale lưu trong API: ${locale}.`, sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 153,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 151,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao diện", value: "Graphite Gold · Dark-only", disabled: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 155,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "shop.manage", type: "submit", variant: "contained", busy: update.pending, disabled: !canManageShop || !editor.dirty || update.pending, children: "Lưu cấu hình" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 156,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 143,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 142,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Checklist thiết lập vận hành", subtitle: "Các mục không có trường API được giữ ở trạng thái chưa xác minh; không suy diễn đã sẵn sàng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.surface.compactContentGap, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          __MOCK__ ? "Bản xem trước mô phỏng. Chỉ tên, tiền tệ, múi giờ và ngôn ngữ được lưu qua API hiện tại." : "API hiện chỉ cho phép sửa thông tin cơ sở được hỗ trợ.",
          " Quốc gia kinh doanh không được suy ra từ múi giờ."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Quốc gia và giờ kinh doanh", status: "Chưa có trường cấu hình trong contract" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 162,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Địa chỉ, vùng giao và phí vận chuyển", status: __MOCK__ ? "Có preview mô phỏng, chưa lưu cấu hình" : "Chưa có operation cấu hình vùng giao", to: `/s/${shop.id}/shipments`, action: "Xem preview phí giao" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 163,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Người duyệt và thành viên", status: "Quyền lấy từ membership; chưa có API gán chính sách duyệt", to: `/s/${shop.id}/settings/team`, action: "Quản lý thành viên" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 164,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối kênh bán hàng", status: __MOCK__ ? "Kết nối mô phỏng; không có quyền provider thật" : "Kiểm tra trạng thái kết nối", to: `/s/${shop.id}/integrations/channels`, action: "Mở kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 165,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Kết nối AI", status: __MOCK__ ? "Catalog nhà cung cấp mô phỏng" : "Kiểm tra catalog nhà cung cấp", to: `/s/${shop.id}/integrations/ai`, action: "Mở nhà cung cấp AI" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 166,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Nội dung sản phẩm và phiên bản kiến thức", status: "Nguồn nội dung, lịch sử phiên bản và duyệt nằm trong khu vực kiến thức.", to: `/s/${shop.id}/knowledge`, action: "Quản lý nội dung" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 167,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Vòng góp ý có duyệt", status: "Góp ý tạo bản nháp; không tự huấn luyện hoặc xuất bản.", to: `/s/${shop.id}/knowledge/review`, action: "Duyệt góp ý" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 168,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(SetupChecklistItem, { title: "Consent và ngừng liên hệ marketing", status: "Có bản ghi consent, lịch sử và luồng xác nhận challenge; gửi qua nhà cung cấp chưa kết nối.", to: `/s/${shop.id}/settings/privacy`, action: "Quản lý consent" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 169,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 160,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 159,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 139,
    columnNumber: 10
  }, this);
}
_s4(ShopSettingsPage, "pjSWA3i3YfXp4xheEW2BgOwAgnQ=", false, function() {
  return [useScope, useQueryClient, useCan, useCommand, useApi, useVersionedDraft, useDraftForm];
});
_c5 = ShopSettingsPage;
function SetupChecklistItem({ title, status, to, action }) {
  return /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactControlOutlined", direction: "row", alignItems: { xs: "flex-start", md: "center" }, justifyContent: "space-between", flexWrap: "wrap", children: [
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: title }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 177,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 177,
        columnNumber: 97
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 177,
      columnNumber: 9
    }, this),
    to && action && /* @__PURE__ */ jsxDEV(RouteLink, { to, children: action }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 178,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 176,
    columnNumber: 10
  }, this);
}
_c6 = SetupChecklistItem;
const roleLabels = {
  owner: "Chủ cửa hàng",
  manager: "Quản lý",
  sales: "Bán hàng",
  warehouse: "Nhân viên kho",
  accountant: "Kế toán",
  bot_admin: "Quản trị AI",
  viewer: "Chỉ xem"
};
export function TeamPage() {
  _s5();
  const { session, shop } = useScope();
  const list = useApi("listMembers", { query: useListQuery("listMembers") });
  const invite = useCommand("inviteMember", ["listMembers"]);
  const update = useCommand("updateMemberRoles", ["listMembers"]);
  const revoke = useCommand("revokeMembership", ["listMembers"]);
  const [edit, setEdit] = useState(), [email, setEmail] = useState(""), [roles, setRoles] = useState(["viewer"]), [remove, setRemove] = useState(null), [savedMessage, setSavedMessage] = useState("");
  const open = (m) => {
    setSavedMessage("");
    setEdit(m);
    setEmail("");
    setRoles(m?.roles || ["viewer"]);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhân sự & phân quyền", subtitle: "Vai trò là bộ quyền mặc định; API quyết định quyền hiệu lực ở từng thao tác.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", variant: "contained", onClick: () => open(null), children: "Mời nhân viên" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 192,
      columnNumber: 150
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 192,
      columnNumber: 12
    }, this),
    savedMessage && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", sx: layoutSx.notice.afterGap, children: savedMessage }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 192,
      columnNumber: 292
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listMembers" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 192,
        columnNumber: 392
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Nhân sự và quyền truy cập", rows: list.data.data, rowKey: (m) => m.id, columns: [
          { key: "user", label: "Nhân viên", render: (m) => m.userId === session.user.id ? session.user.displayName : `Mã nhân sự: ${m.userId}` },
          { key: "roles", label: "Vai trò", render: (m) => m.roles.map((r) => roleLabels[r]).join(", ") },
          { key: "status", label: "Trạng thái", render: (m) => /* @__PURE__ */ jsxDEV(Status, { value: m.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 193,
            columnNumber: 298
          }, this) },
          { key: "perms", label: "Quyền hiệu lực", render: (m) => `${m.permissions.length} quyền · v${m.permissionVersion}` },
          {
            key: "actions",
            label: "",
            render: (m) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", children: [
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", onClick: () => open(m), children: "Sửa quyền" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 195,
                columnNumber: 78
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "members.manage", color: "error", disabled: m.userId === session.user.id || m.status === "revoked", onClick: () => setRemove(m), children: "Thu hồi" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
                lineNumber: 195,
                columnNumber: 172
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
              lineNumber: 195,
              columnNumber: 55
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 192,
          columnNumber: 493
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 197,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 192,
        columnNumber: 491
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 192,
        columnNumber: 427
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 192,
      columnNumber: 385
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: edit !== void 0, title: edit ? "Cập nhật quyền" : "Mời nhân viên", onClose: () => setEdit(void 0), busy: invite.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !roles.length || !edit && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || invite.pending || update.pending, onClick: async () => {
      try {
        if (edit) {
          await update.execute({ path: { memberId: edit.id }, version: edit.permissionVersion, body: { roles } });
          setSavedMessage(`Đã cập nhật quyền truy cập của ${edit.userId}.`);
        } else {
          await invite.execute({ body: { email, roles } });
          setSavedMessage(`Đã gửi lời mời đến ${email.trim()}.`);
        }
        setEdit(void 0);
      } catch {
      }
    }, children: "Lưu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 198,
      columnNumber: 174
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: invite.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 208,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        !edit && /* @__PURE__ */ jsxDEV(TextField, { label: "Email nhân viên", type: "email", value: email, onChange: (e) => setEmail(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 208,
          columnNumber: 119
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", children: "Phân vai trò" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 208,
          columnNumber: 227
        }, this),
        Object.keys(roleLabels).map((role) => /* @__PURE__ */ jsxDEV(FormControlLabel, { label: `${roleLabels[role]} · ${permissionCatalog.rolePresets[role]?.length || 0} quyền`, control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: roles.includes(role), onChange: (e) => setRoles(e.target.checked ? [...roles, role] : roles.filter((r) => r !== role)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 208,
          columnNumber: 463
        }, this) }, role, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 208,
          columnNumber: 335
        }, this)),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Quyền mới phải được máy chủ kiểm lại. Thu hồi quyền làm mất hiệu lực cache và phiên truy cập liên quan." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 208,
          columnNumber: 610
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 208,
        columnNumber: 97
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 198,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!remove, title: "Thu hồi quyền nhân viên", confirmLabel: "Thu hồi quyền", description: `Nhân viên ${remove?.userId || ""} trong ${shop.name}: người này không được tiếp tục truy cập dữ liệu cửa hàng sau khi thu hồi. Lịch sử hoạt động được giữ.`, onClose: () => setRemove(null), busy: revoke.pending, error: revoke.error, onConfirm: async () => {
      if (!remove) return;
      await revoke.execute({ path: { memberId: remove.id }, version: remove.permissionVersion });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 208,
      columnNumber: 773
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 192,
    columnNumber: 10
  }, this);
}
_s5(TeamPage, "NjTnYG0BAm5eQ0BS4pFldL3g1IA=", false, function() {
  return [useScope, useApi, useListQuery, useCommand, useCommand, useCommand];
});
_c7 = TeamPage;
export function AuditPage() {
  _s6();
  const { shop } = useScope();
  const list = useApi("listAuditEvents", { query: useListQuery("listAuditEvents") });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhật ký hoạt động", subtitle: "Ai thực hiện, thao tác nào, dữ liệu nào và mã truy vết. Không lưu API key hoặc suy luận riêng của AI." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 213,
      columnNumber: 156
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "API hiện trả về người thực hiện, thao tác, đối tượng, thời gian, mã truy vết và tóm tắt. Loại actor, phiên bản policy/config và snapshot chi tiết chưa có trong DTO nên không được suy đoán." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 213,
      columnNumber: 309
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listAuditEvents" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 213,
        columnNumber: 565
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Nhật ký hoạt động", rows: list.data.data, rowKey: (a) => a.id, columns: [
          { key: "time", label: "Thời gian", render: (a) => dateTime(a.occurredAt, shop.timezone) },
          { key: "actor", label: "Người thực hiện", render: (a) => `Mã nhân sự: ${a.actorId}` },
          { key: "action", label: "Thao tác", render: (a) => a.action },
          { key: "source", label: "Đối tượng", render: (a) => `${a.resource.type} · Mã đối tượng: ${a.resource.id}` },
          { key: "summary", label: "Kết quả", render: (a) => a.summary },
          { key: "trace", label: "Mã truy vết", render: (a) => /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: a.requestId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 214,
            columnNumber: 478
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 213,
          columnNumber: 670
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 215,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 213,
        columnNumber: 668
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 213,
        columnNumber: 604
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 213,
      columnNumber: 558
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 213,
    columnNumber: 154
  }, this);
}
_s6(AuditPage, "Jtgiv7AS0Y0EHZdenzTKkK6QaXU=", false, function() {
  return [useScope, useApi, useListQuery];
});
_c8 = AuditPage;
export function PrivacyPage() {
  _s7();
  const { shop } = useScope();
  const policy = useApi("getPrivacyPolicy");
  const requests = useApi("listPrivacyRequests", { query: useListQuery("listPrivacyRequests") });
  const save = useCommand("updatePrivacyPolicy", ["getPrivacyPolicy"]);
  const create = useCommand("createPrivacyRequest", ["listPrivacyRequests"]);
  const [days, setDays] = useState(""), [note, setNote] = useState(""), [customerId, setCustomer] = useState(""), [kind, setKind] = useState("export"), [reason, setReason] = useState(""), [open, setOpen] = useState(false), [daysTouched, setDaysTouched] = useState(false), [noteTouched, setNoteTouched] = useState(false), [policySubmitted, setPolicySubmitted] = useState(false), [policySaved, setPolicySaved] = useState("");
  const canReadCustomers = useCan("customers.read");
  const [customerSearchInput, setCustomerSearchInput] = useState(""), [customerSearch, setCustomerSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setCustomerSearch(customerSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [customerSearchInput]);
  const customers = usePagedApi("listCustomers", { query: { q: customerSearch || void 0 } }, canReadCustomers);
  const selectedCustomerDetail = useApi("getCustomer", { path: { customerId } }, canReadCustomers && !!customerId);
  const selectedCustomer = customers.data?.data.find((customer) => customer.id === customerId) || selectedCustomerDetail.data?.data;
  const editor = useVersionedDraft({
    identity: `${shop.id}:privacy`,
    source: policy.data ? { version: policy.data.data.version, values: { days: policy.data.data.chatRetentionDays?.toString() || "", note: policy.data.data.jurisdictionNote } } : void 0,
    draft: { days, note },
    apply: (values) => {
      setDays(values.days);
      setNote(values.note);
    },
    refresh: () => policy.refetch({ throwOnError: true })
  });
  const policyForm = useDraftForm(editor.dirty);
  const daysError = !/^\d+$/.test(days) || Number(days) < 1 || Number(days) > 36500 ? "Nhập số nguyên từ 1 đến 36.500 ngày." : "";
  const noteError = codePointLength(note.trim()) < 5 || codePointLength(note) > 2e3 ? "Nhập căn cứ từ 5 đến 2.000 ký tự." : "";
  const showDaysError = (daysTouched || policySubmitted) && !!daysError;
  const showNoteError = (noteTouched || policySubmitted) && !!noteError;
  const savePolicy = async () => {
    setPolicySubmitted(true);
    if (daysError || noteError || !editor.dirty) return;
    const prepared = editor.prepare();
    if (!prepared) return;
    const submitted = { days, note };
    setPolicySaved("");
    try {
      const result = await save.execute({ version: prepared.version, body: {
        ...prepared.patch.days !== void 0 ? { chatRetentionDays: Number(prepared.patch.days) } : {},
        ...prepared.patch.note !== void 0 ? { jurisdictionNote: prepared.patch.note } : {}
      } });
      const clean = editor.committed({ version: result.data.version, values: { days: result.data.chatRetentionDays?.toString() || "", note: result.data.jurisdictionNote } }, submitted);
      setPolicySaved(clean ? "Đã lưu bản nháp chính sách lưu trữ." : "Đã lưu phần thay đổi đã gửi; chỉnh sửa mới vẫn chưa được lưu.");
    } catch (error) {
      editor.failed(error);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Quyền riêng tư & vòng đời dữ liệu", subtitle: "Tách cấu hình nháp với chính sách được duyệt; yêu cầu xóa không tự vượt điều kiện lưu chứng từ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 259,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1fr 1.4fr" }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Chính sách lưu trữ", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: policy, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: policyForm, onSubmit: (event) => {
        event.preventDefault();
        void savePolicy();
      }, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: save.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 444
        }, this),
        /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { days: "Số ngày lưu hội thoại", note: "Căn cứ / thị trường áp dụng" }, busy: save.pending }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 478
        }, this),
        policySaved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: policySaved }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 627
        }, this),
        policy.data && /* @__PURE__ */ jsxDEV(Status, { value: policy.data.data.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 705
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Số ngày lưu hội thoại", value: days, onBlur: () => setDaysTouched(true), onChange: (e) => {
          setDays(e.target.value);
          setDaysTouched(true);
          setPolicySaved("");
        }, type: "number", inputProps: { min: 1, max: 36500, step: 1 }, error: showDaysError, helperText: showDaysError ? daysError : "Nhập số nguyên từ 1 đến 36.500 ngày." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 748
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Căn cứ / thị trường áp dụng", multiline: true, minRows: 4, value: note, onBlur: () => setNoteTouched(true), onChange: (e) => {
          setNote(e.target.value);
          setNoteTouched(true);
          setPolicySaved("");
        }, error: showNoteError, helperText: showNoteError ? noteError : "Tối thiểu 5 và tối đa 2.000 ký tự." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 1086
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", type: "submit", variant: "contained", busy: save.pending, disabled: !policy.data || !editor.dirty || save.pending || !!daysError || !!noteError, children: "Lưu bản nháp chính sách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 1391
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Không tự chứng nhận tuân thủ pháp luật. Phê duyệt yêu cầu xóa cần xác thực nâng cao của backend; luồng OIDC step-up chưa được xác minh trong frontend này." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 1616
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 332
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 280
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 229
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Yêu cầu của khách", action: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", onClick: () => setOpen(true), children: "Tạo yêu cầu" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 1876
      }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: requests, pendingProfile: "section", children: requests.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu quyền riêng tư", rows: requests.data.data, rowKey: (r) => r.id, columns: [
          { key: "customer", label: "Khách", render: (r) => `Mã khách hàng: ${r.customerId}` },
          { key: "kind", label: "Yêu cầu", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.kind }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 260,
            columnNumber: 147
          }, this) },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 260,
            columnNumber: 228
          }, this) },
          { key: "reason", label: "Lý do", render: (r) => r.reason }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 259,
          columnNumber: 2054
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: requests.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 261,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 2052
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 1980
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 259,
        columnNumber: 1835
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 259,
      columnNumber: 175
    }, this),
    /* @__PURE__ */ jsxDEV(ConsentManagement, { customers: customers.data?.data || [], canReadCustomers, shopId: shop.id }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 261,
      columnNumber: 91
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Yêu cầu dữ liệu cá nhân", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !customerId || codePointLength(reason.trim()) < 5 || create.pending, onClick: async () => {
      try {
        await create.execute({ body: { kind, customerId, reason } });
        setOpen(false);
      } catch {
      }
    }, children: "Tạo yêu cầu chờ duyệt" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 262,
      columnNumber: 120
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || customers.error || selectedCustomerDetail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 266,
        columnNumber: 63
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm khách hàng", value: customerSearchInput, onChange: (e) => setCustomerSearchInput(e.target.value), disabled: !canReadCustomers, helperText: "Tìm theo mã hoặc tên khách; API hỗ trợ tìm kiếm và cursor." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 162
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Khách hàng", select: true, value: customerId, onChange: (e) => setCustomer(e.target.value), disabled: !canReadCustomers || customers.isPending && !customers.data, children: [
          customerId && !customers.data?.data.some((customer) => customer.id === customerId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: customerId, children: selectedCustomer?.displayName || (selectedCustomerDetail.isPending ? "Đang tải khách đã chọn…" : customerId) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 266,
            columnNumber: 644
          }, this),
          customers.data?.data.map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: c.displayName }, c.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 266,
            columnNumber: 828
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 384
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "khách hàng", loadedCount: customers.loadedCount, hasMore: customers.hasMore, busy: customers.isLoadingMore, onLoadMore: customers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 902
        }, this),
        customers.isError && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void (customers.isFetchNextPageError ? customers.loadMore() : customers.refetch());
        }, children: "Thử lại danh sách khách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 1088
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Loại yêu cầu", select: true, value: kind, onChange: (e) => setKind(e.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "export", children: "Xuất dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 266,
            columnNumber: 1353
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "delete", children: "Xóa dữ liệu cá nhân" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 266,
            columnNumber: 1409
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 1244
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do / xác minh yêu cầu", multiline: true, minRows: 3, value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 266,
          columnNumber: 1476
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 266,
        columnNumber: 150
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 262,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 259,
    columnNumber: 10
  }, this);
}
_s7(PrivacyPage, "TGmX92/FKzju/bSKHvgcch3C6G0=", false, function() {
  return [useScope, useApi, useApi, useListQuery, useCommand, useCommand, useCan, usePagedApi, useApi, useVersionedDraft, useDraftForm];
});
_c9 = PrivacyPage;
const consentCopyVersion = 1;
const consentReconfirmCopy = "Bạn có đồng ý nhận nội dung tiếp thị từ cửa hàng qua kênh đã chọn không? Bạn có thể rút lại đồng ý bất cứ lúc nào. Tin nhắn phục vụ đơn hàng không thay đổi.";
function ConsentManagement({ customers, canReadCustomers, shopId }) {
  _s8();
  const consentList = usePagedApi("listCustomerConsents", { query: useListQuery("listCustomerConsents") });
  const challengeList = usePagedApi("listCustomerConsentChallenges", { query: useListQuery("listCustomerConsentChallenges") });
  const createChallenge = useCommand("createCustomerConsentChallenge", ["listCustomerConsentChallenges"]);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [channel, setChannel] = useState("messenger");
  const [created, setCreated] = useState(false);
  const customerId = customers.some((customer2) => customer2.id === selectedCustomerId) ? selectedCustomerId : customers[0]?.id || "";
  const customer = customers.find((candidate) => candidate.id === customerId);
  const redacted = customer?.redactedFields || [];
  const availableChannels = [
    { value: "messenger", label: "Messenger", available: Boolean(customer?.externalIdentity) },
    { value: "sms", label: "SMS", available: Boolean(customer?.phone && !redacted.includes("phone")) },
    { value: "email", label: "Email", available: Boolean(customer?.email && !redacted.includes("email")) }
  ].filter((item) => item.available);
  const selectedChannel = availableChannels.find((item) => item.value === channel)?.value || availableChannels[0]?.value || channel;
  const channelIsAvailable = availableChannels.some((item) => item.value === selectedChannel);
  const requestReconfirmation = async () => {
    if (!customerId || !canReadCustomers || !channelIsAvailable) return;
    try {
      await createChallenge.execute({ path: { customerId }, body: { purpose: "marketing", channel: selectedChannel, message: consentReconfirmCopy, contentVersion: consentCopyVersion } });
      setCreated(true);
      await Promise.all([challengeList.refetch(), consentList.refetch()]);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Consent marketing và xác nhận lại", beforeGap: "section", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Consent được lưu theo khách, mục đích, kênh, phiên bản và lịch sử. Tạo yêu cầu chỉ tạo challenge đang chờ; không bật consent. Môi trường local không có nhà cung cấp gửi email/SMS/Meta nên không khẳng định đã gửi link thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 299,
      columnNumber: 13
    }, this),
    canReadCustomers ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khách hàng", value: customerId, onChange: (event) => {
        setSelectedCustomerId(event.target.value);
        setCreated(false);
      }, disabled: !customer, children: customers.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.displayName }, item.id, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 302,
        columnNumber: 46
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 301,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kênh cần xác nhận", value: selectedChannel, onChange: (event) => {
        setChannel(event.target.value);
        setCreated(false);
      }, disabled: !availableChannels.length, children: availableChannels.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.value, children: item.label }, item.value, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 305,
        columnNumber: 54
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 304,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: `Nội dung v${consentCopyVersion}`, children: consentReconfirmCopy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 307,
        columnNumber: 17
      }, this),
      !availableChannels.length && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không có kênh liên hệ còn quyền xem cho khách đã chọn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 308,
        columnNumber: 47
      }, this),
      /* @__PURE__ */ jsxDEV(MutationButton, { permission: "privacy.manage", variant: "contained", busy: createChallenge.pending, disabled: !customerId || !channelIsAvailable || !canReadCustomers, onClick: () => void requestReconfirmation(), children: "Tạo yêu cầu xác nhận lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 309,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: createChallenge.error || consentList.error || challengeList.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 310,
        columnNumber: 17
      }, this),
      created && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã tạo challenge chờ khách xác nhận. Trạng thái này chưa phải consent được cấp." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 311,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 300,
      columnNumber: 33
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Cần quyền customers.read để chọn khách. Danh sách và thông tin nhận dạng được ẩn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 312,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Bản ghi consent hiện tại", children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", children: "Bản ghi consent hiện tại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 314,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: consentList, pendingProfile: "section", children: consentList.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử consent khách hàng", rows: consentList.data.data, rowKey: (record) => record.id, columns: [
          { key: "customer", label: "Khách", render: (record) => `Mã khách hàng: ${record.customerId}` },
          { key: "purpose", label: "Mục đích", render: (record) => businessLabel(record.purpose) },
          { key: "channel", label: "Kênh", render: (record) => businessLabel(record.channel) },
          { key: "status", label: "Trạng thái", render: (record) => /* @__PURE__ */ jsxDEV(Status, { value: record.status, domain: "consent" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 320,
            columnNumber: 71
          }, this) },
          { key: "version", label: "Phiên bản", render: (record) => record.version },
          { key: "evidence", label: "Bằng chứng gần nhất", render: (record) => {
            const latest = record.history.at(-1);
            return latest ? `${businessLabel(latest.action, "consent")} · ${latest.evidenceType} · ${latest.evidenceReference || "—"}` : "Chưa có";
          } }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 316,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: consentList.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 324,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 315,
        columnNumber: 95
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 315,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 313,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Yêu cầu xác nhận đang chờ", children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", children: "Yêu cầu xác nhận đang chờ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 328,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: challengeList, pendingProfile: "section", children: challengeList.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu xác nhận đang chờ", rows: challengeList.data.data, rowKey: (challenge) => challenge.id, columns: [
          { key: "customer", label: "Khách", render: (challenge) => `Mã khách hàng: ${challenge.customerId}` },
          { key: "purpose", label: "Mục đích", render: (challenge) => businessLabel(challenge.purpose) },
          { key: "channel", label: "Kênh", render: (challenge) => businessLabel(challenge.channel) },
          { key: "action", label: "Yêu cầu", render: (challenge) => challenge.action === "withdraw" ? "Ngừng marketing" : "Xác nhận marketing" },
          { key: "status", label: "Trạng thái", render: (challenge) => /* @__PURE__ */ jsxDEV(Status, { value: challenge.status, domain: "consent" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 335,
            columnNumber: 74
          }, this) },
          { key: "expires", label: "Hết hạn", render: (challenge) => dateTime(challenge.expiresAt, "Asia/Ho_Chi_Minh") }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 330,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: challengeList.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 338,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 329,
        columnNumber: 99
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 329,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 327,
      columnNumber: 13
    }, this),
    canReadCustomers && /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: `/s/${shopId}/customers`, size: "small", sx: { alignSelf: "flex-start" }, children: "Mở danh sách khách" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 341,
      columnNumber: 34
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 298,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 297,
    columnNumber: 10
  }, this);
}
_s8(ConsentManagement, "dM1/KXSS4/1TbEyxTpM5R96mHrQ=", false, function() {
  return [usePagedApi, useListQuery, usePagedApi, useListQuery, useCommand];
});
_c0 = ConsentManagement;
function savedConsentChallenge(value) {
  try {
    assertSchema("PublicConsentChallengeView", value);
    return value;
  } catch {
    return null;
  }
}
export function ConsentConfirmationPage() {
  _s9();
  const [params] = useSearchParams();
  const location2 = useLocation();
  const navigate = useNavigate();
  const token = params.get("token") || "";
  const [challenge, setChallenge] = useState(() => savedConsentChallenge(location2.state?.consentChallenge));
  const [confirmation, setConfirmation] = useState(null);
  const [error, setError] = useState(null);
  const [pending, setPending] = useState(false);
  const [submittedDecision, setSubmittedDecision] = useState(null);
  const exchangeId = useRef(crypto.randomUUID());
  const confirmationId = useRef(null);
  const exchange = async () => {
    if (!token || pending) return;
    setPending(true);
    setError(null);
    try {
      const csrf = await request("getCsrfToken");
      setCsrfToken(csrf.data.csrfToken);
      const result = await request("exchangeConsentChallenge", { body: { token }, idempotencyKey: exchangeId.current });
      setChallenge(result.data);
      navigate("/consent/confirm", { replace: true, state: { consentChallenge: result.data } });
    } catch (reason) {
      setError(reason instanceof Error ? reason : new Error("Không xác minh được liên kết."));
    } finally {
      setPending(false);
    }
  };
  const confirm = async (decision) => {
    if (!challenge || pending || confirmation || submittedDecision && submittedDecision !== decision) return;
    const intent = confirmationId.current?.decision === decision ? confirmationId.current : { decision, key: crypto.randomUUID() };
    confirmationId.current = intent;
    setSubmittedDecision(decision);
    setPending(true);
    setError(null);
    try {
      const result = await request("confirmConsentChallenge", { body: { challengeSessionId: challenge.challengeSessionId, decision, contentVersion: challenge.contentVersion }, idempotencyKey: intent.key });
      setConfirmation(result.data);
    } catch (reason) {
      setError(reason instanceof Error ? reason : new Error("Chưa xác minh được kết quả. Hãy thử lại cùng lựa chọn."));
    } finally {
      setPending(false);
    }
  };
  const withdrawal = challenge?.action === "withdraw";
  const confirmationMessage = confirmation ? confirmation.consentStatus === "withdrawn" ? "Đã ghi nhận không nhận tin marketing qua kênh này. Tin nhắn phục vụ đơn hàng không bị ảnh hưởng." : confirmation.status === "declined" ? "Lựa chọn hiện tại được giữ nguyên; không có quyền marketing mới nào được cấp." : "Đã ghi nhận lựa chọn của bạn." : "";
  return /* @__PURE__ */ jsxDEV(Box, { component: "main", id: "main-content", tabIndex: -1, sx: [layoutSx.shell.pageFallbackInset, { maxWidth: 900, mx: "auto", outline: "none" }], children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Xác nhận lựa chọn marketing", subtitle: "Liên kết ngắn hạn gắn với đúng khách, kênh và nội dung đã gửi." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 395,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: challenge ? withdrawal ? "Ngừng nhận tin marketing" : "Xác nhận nhận tin marketing" : "Kiểm tra liên kết", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Lựa chọn này chỉ áp dụng cho nội dung marketing. Trao đổi phục vụ đơn hàng vẫn được xử lý riêng." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 398,
        columnNumber: 17
      }, this),
      error && /* @__PURE__ */ jsxDEV(ErrorNotice, { error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 399,
        columnNumber: 27
      }, this),
      !challenge && token && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Liên kết không chứa thông tin cá nhân. Tiếp tục để kiểm tra mục đích, kênh và nội dung trước khi gửi lựa chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 401,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => void exchange(), disabled: pending, children: pending ? "Đang kiểm tra…" : error ? "Thử xác minh lại" : "Xem nội dung yêu cầu" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 402,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 400,
        columnNumber: 41
      }, this),
      !challenge && !token && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Thiếu liên kết challenge. Hãy mở liên kết đầy đủ do cửa hàng gửi cho bạn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 404,
        columnNumber: 42
      }, this),
      challenge && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mục đích", children: "Marketing" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 406,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kênh", children: businessLabel(challenge.channel) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 407,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nội dung đã xem", children: challenge.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 408,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phiên bản nội dung", children: [
          "v",
          challenge.contentVersion
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 409,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Hết hạn", children: dateTime(challenge.expiresAt, "Asia/Ho_Chi_Minh") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 410,
          columnNumber: 21
        }, this),
        confirmation ? /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: confirmationMessage }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 411,
          columnNumber: 37
        }, this) : /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => void confirm("accept"), disabled: pending || submittedDecision === "decline", children: pending && submittedDecision === "accept" ? "Đang ghi nhận…" : submittedDecision === "accept" ? "Thử lại cùng lựa chọn" : withdrawal ? "Xác nhận ngừng marketing" : "Đồng ý nhận marketing" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 412,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", onClick: () => void confirm("decline"), disabled: pending || submittedDecision === "accept", children: pending && submittedDecision === "decline" ? "Đang ghi nhận…" : submittedDecision === "decline" ? "Thử lại cùng lựa chọn" : withdrawal ? "Giữ nguyên lựa chọn" : "Không đồng ý marketing" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
            lineNumber: 413,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
          lineNumber: 411,
          columnNumber: 109
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 405,
        columnNumber: 31
      }, this),
      __MOCK__ && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Môi trường local chỉ mô phỏng hợp đồng và dữ liệu; không gửi email/SMS/Meta và không chứng nhận Backend hoặc nhà cung cấp thật." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 416,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 397,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 396,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 394,
    columnNumber: 10
  }, this);
}
_s9(ConsentConfirmationPage, "DaywKdEVtETRwsgWsiOsX589mWw=", false, function() {
  return [useSearchParams, useLocation, useNavigate];
});
_c1 = ConsentConfirmationPage;
export function JobPage() {
  _s0();
  const { jobId = "" } = useParams();
  const { shop } = useScope();
  const get = useApi("getJob", { path: { jobId } });
  const job = get.data?.data;
  const downloadHref = job?.downloadUrl ? authorizedDownloadHref(job.downloadUrl, location.origin, __MOCK__) : null;
  const jobStatus = job?.status;
  const { refetch } = get;
  useEffect(() => {
    if (!jobStatus || !["queued", "running"].includes(jobStatus))
      return;
    const timer = setInterval(() => void refetch(), 3e3);
    return () => clearInterval(timer);
  }, [jobStatus, refetch]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: `Công việc ${jobId}`, subtitle: "Theo dõi tiến độ từ API. Được tiếp nhận không có nghĩa đã hoàn tất." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 431,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: get, pendingProfile: "section", children: job && /* @__PURE__ */ jsxDEV(Panel, { title: "Kết quả xử lý", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 249
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Loại", children: businessLabel(job.kind) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 278
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tiến độ", children: [
        job.completed,
        " / ",
        job.total ?? "Chưa biết"
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 341
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lỗi", children: job.errorCount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 426
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cập nhật", children: dateTime(job.updatedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 479
      }, this),
      job.rowErrors.length > 0 && /* @__PURE__ */ jsxDEV(DataTable, { label: "Lỗi công việc nền", rows: job.rowErrors, rowKey: (e) => `${e.row}-${e.field}-${e.code}`, columns: [{ key: "row", label: "Dòng", render: (e) => e.row }, { key: "field", label: "Trường", render: (e) => e.field }, { key: "message", label: "Lỗi", render: (e) => e.message }] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 590
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => void get.refetch(), variant: "outlined", children: "Kiểm tra lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 882
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && downloadHref && /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => window.open(downloadHref, "_blank", "noopener,noreferrer"), children: "Mở kết quả xuất" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 1050
      }, this),
      job.downloadUrl && ["succeeded", "partial"].includes(job.status) && !downloadHref && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không an toàn hoặc không hợp lệ nên đã bị chặn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 1264
      }, this),
      job.status === "awaiting_confirmation" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/imports/${job.id}`, children: "Xem và xác nhận nhập" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
        lineNumber: 431,
        columnNumber: 1397
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 431,
      columnNumber: 237
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 431,
      columnNumber: 191
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
      lineNumber: 431,
      columnNumber: 134
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx",
    lineNumber: 431,
    columnNumber: 10
  }, this);
}
_s0(JobPage, "l5lsqPeM5OsNbf4sk4jY+IabZuk=", false, function() {
  return [useParams, useScope, useApi];
});
_c10 = JobPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10;
$RefreshReg$(_c, "AuthCard");
$RefreshReg$(_c2, "LoginPage");
$RefreshReg$(_c3, "WorkspacesPage");
$RefreshReg$(_c4, "OnboardingPage");
$RefreshReg$(_c5, "ShopSettingsPage");
$RefreshReg$(_c6, "SetupChecklistItem");
$RefreshReg$(_c7, "TeamPage");
$RefreshReg$(_c8, "AuditPage");
$RefreshReg$(_c9, "PrivacyPage");
$RefreshReg$(_c0, "ConsentManagement");
$RefreshReg$(_c1, "ConsentConfirmationPage");
$RefreshReg$(_c10, "JobPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/workspace/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkIyYSxTQTBGaGEsVUExRmdhOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCM2EsU0FBUUEsU0FBU0MscUJBQW9CO0FBQ3JDLFNBQVNDLGFBQWFDLFlBQVlDLFlBQVlDLGNBQWNDLGFBQWFDLHNCQUFzQjtBQUMvRixTQUFTQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLFFBQVFDLFlBQVlDLFVBQVVDLGFBQWFDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUNuRyxTQUFTQyxVQUFVQyxzQkFBc0I7QUFDekMsU0FBU0MsT0FBT0MsUUFBUUMsS0FBS0MsUUFBUUMsVUFBVUMsa0JBQWtCQyxVQUFVQyxPQUFPQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFDdEgsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHlCQUF5QjtBQUVoQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxTQUFTQyxvQkFBb0I7QUFDdEMsU0FBU0MsUUFBUUMsYUFBYUMsa0JBQWtCO0FBQ2hELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBQ2pDLFNBQVNDLGlCQUFpQkMsaUJBQWlCQyxVQUFVQyxrQkFBa0JDLHVCQUF1QjtBQUM5RixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdCQUFnQkMsb0JBQW9CO0FBQzdDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVlDLE9BQU9DLFlBQVlDLFdBQVdDLFNBQVNDLE9BQU9DLFFBQVFDLGdCQUFnQkMsWUFBWUMsYUFBYUMsZUFBZUMsV0FBV0MsWUFBWUMsZ0JBQWdCQyxhQUFhO0FBQ3ZMLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxTQUFTO0FBQUEsRUFBRUM7QUFFcEIsR0FBRztBQUFFLFNBQU8sdUJBQUMsT0FBSSxXQUFVLFFBQU8sSUFBRyxnQkFBZSxVQUFVLElBQUksSUFBSSxDQUFDbEIsU0FBU21CLE1BQU1DLGtCQUFrQixFQUFFQyxTQUFTLHNCQUFzQkMsU0FBUyxPQUFPLENBQUMsR0FBRyxpQ0FBQyxTQUFNLFNBQVEsWUFBVyxJQUFJLENBQUN0QixTQUFTdUIsS0FBS0MsY0FBYyxFQUFFQyxPQUFPLFFBQVFDLFVBQVUsS0FBS0MsY0FBY3hFLFNBQVN5RSxPQUFPQyxLQUFLLENBQUMsR0FBRztBQUFBLDJCQUFDLFNBQU0sV0FBVSxPQUFNLFlBQVcsVUFBUyxJQUFJN0IsU0FBU3VCLEtBQUtPLGNBQWM7QUFBQSw2QkFBQyxVQUFPLElBQUksRUFBRVQsU0FBUyxnQkFBZ0JVLE9BQU9wRCxPQUFPcUQsU0FBUyxHQUFHLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLE1BQVMsdUJBQUMsY0FBVyxTQUFRLE1BQUssWUFBWTdFLFNBQVM4RSxXQUFXQyxXQUFXQyxXQUFXO0FBQUE7QUFBQSxRQUFTLHVCQUFDLE9BQUksV0FBVSxRQUFPLE9BQU0sZ0JBQWUsa0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJJO0FBQUEsU0FBblQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnVTtBQUFBLElBQVNqQjtBQUFBQSxPQUEzYztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9kLEtBQXJtQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZtQjtBQUFRO0FBQUNrQixLQUZ6bkJuQjtBQUdGLGdCQUFTb0IsWUFBWTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU0sRUFBRUMsU0FBU0MsUUFBUSxJQUFJeEIsV0FBVztBQUN4QyxRQUFNLENBQUN5QixNQUFNLElBQUkvRSxnQkFBZ0I7QUFDakMsUUFBTSxDQUFDZ0YsU0FBU0MsVUFBVSxJQUFJekYsU0FBUyxLQUFLLEdBQUcsQ0FBQzBGLE9BQU9DLFFBQVEsSUFBSTNGLFNBQXVCLElBQUk7QUFDOUYsUUFBTTRGLFFBQVEsWUFBWTtBQUFFSCxlQUFXLElBQUk7QUFBR0UsYUFBUyxJQUFJO0FBQUcsUUFBSTtBQUM5RCxZQUFNRSxPQUFPLE1BQU1uRSxRQUFRLGNBQWM7QUFDekNDLG1CQUFha0UsS0FBS0MsS0FBS0MsU0FBUztBQUNoQyxZQUFNMUIsT0FBTyxNQUFNM0MsUUFBUSxjQUFjLEVBQUVzRSxNQUFNLEVBQUVDLFVBQVUzRCxpQkFBaUJpRCxPQUFPVyxJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUUsRUFBRSxDQUFDO0FBQzFILFlBQU1DLE1BQU0sSUFBSUMsSUFBSS9CLEtBQUt5QixLQUFLTyxnQkFBZ0I7QUFDOUMsVUFBSUYsSUFBSUcsYUFBYSxZQUFZLEVBQUVDLFlBQVlKLElBQUlLLFdBQVdDLFNBQVNEO0FBQ25FLGNBQU0sSUFBSUUsTUFBTSxrQ0FBa0M7QUFDdERDLGFBQU9GLFNBQVNHLE9BQU9ULElBQUlVLElBQUk7QUFBQSxJQUNuQyxTQUNPQyxHQUFHO0FBQ05uQixlQUFTbUIsYUFBYUosUUFBUUksSUFBSSxJQUFJSixNQUFNLDhCQUE4QixDQUFDO0FBQzNFakIsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFBRTtBQUNGLFNBQU8sdUJBQUMsWUFBUztBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxJQUFJM0MsU0FBU3VCLEtBQUswQyxlQUFlLGlDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBGO0FBQUEsSUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUksQ0FBQ2pFLFNBQVNrRSxXQUFXQyxxQkFBcUJuRSxTQUFTa0UsV0FBV0UsUUFBUSxHQUFHLGdGQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdMO0FBQUEsSUFBYSx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUdYLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSXpELFNBQVNrRSxXQUFXRSxVQUFVLCtFQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdIO0FBQUEsSUFBVTdCLFVBQVUsdUJBQUMsVUFBTyxXQUFTLE1BQUMsV0FBV2xGLFlBQVksSUFBRyxlQUFjLFNBQVEsYUFBWSxTQUFTLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsR0FBSyxxQ0FBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSSxJQUFZLHVCQUFDLFVBQU8sV0FBUyxNQUFDLFNBQVEsYUFBWSxNQUFLLFNBQVEsU0FBUyxNQUFNLEtBQUt5RixNQUFNLEdBQUcsVUFBVUosV0FBV0YsU0FBVUUsb0JBQVUsK0JBQStCZSxXQUFXLDJCQUEyQixzQ0FBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpTztBQUFBLElBQVUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsSUFBSSxDQUFDekQsU0FBU3FFLEtBQUtDLGVBQWUsRUFBRUMsU0FBUyxRQUFRLENBQUMsR0FBRyxrR0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnTTtBQUFBLE9BQS9oQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRpQztBQUN2akM7QUFBQ2pDLEdBbEJlRCxXQUFTO0FBQUEsVUFDUXJCLFlBQ1p0RCxlQUFlO0FBQUE7QUFBQSxNQUZwQjJFO0FBbUJULGdCQUFTbUMsaUJBQWlCO0FBQUFDLE1BQUE7QUFDN0IsUUFBTSxFQUFFbEMsU0FBU0MsU0FBU0ksT0FBTzhCLGFBQWEsSUFBSTFELFdBQVc7QUFDN0QsUUFBTTJELFFBQVFoSCxTQUFTLEVBQUVpSCxVQUFVLENBQUMsU0FBU3JDLFNBQVNzQyxLQUFLQyxFQUFFLEdBQUdDLFNBQVNBLENBQUMsRUFBRUMsT0FBTyxNQUFNcEcsUUFBUSxhQUFhLEVBQUVvRyxPQUFPLENBQUMsR0FBR0MsU0FBUyxDQUFDLENBQUMxQyxTQUFTMkMsT0FBTyxNQUFNLENBQUM7QUFDN0osUUFBTUMsVUFBVSxDQUFDUixNQUFNUyxXQUFXVCxNQUFNM0IsTUFBTUEsS0FBS3FDLFdBQVc7QUFDOUQsUUFBTUMsbUJBQW1CLHVCQUFDLFVBQU8sV0FBV2pJLFlBQVksSUFBRyxlQUFjLFNBQVEsYUFBWSw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRjtBQUN6RyxNQUFJLENBQUNtRixXQUFXLENBQUNELFdBQVdtQyx3QkFBd0J6RixZQUFZeUYsYUFBYWEsV0FBVztBQUNwRixXQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUN4QyxTQUFPLHVCQUFDLE9BQUksV0FBVSxRQUFPLElBQUcsZ0JBQWUsVUFBVSxJQUFJLElBQUksQ0FBQ3ZGLFNBQVNtQixNQUFNcUUsbUJBQW1CLEVBQUU5RCxVQUFVLE1BQU0rRCxJQUFJLFFBQVFuRSxTQUFTLE9BQU8sQ0FBQyxHQUFHO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLHNEQUFxRCxTQUFTLENBQUM2RCxXQUFXRyxvQkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzSTtBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPWixnQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPQyxPQUFPLGdCQUFlLFdBQVdRLG9CQUFVLHVCQUFDLFNBQU0sTUFBSyxxQkFBb0IsUUFBUUcsb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsSUFBSyx1QkFBQyxlQUFZLFNBQVMsRUFBRUksSUFBSSxrQkFBa0JDLElBQUloQixNQUFNM0IsTUFBTUEsS0FBS3FDLFdBQVcsSUFBSSxtQkFBbUIsNEJBQTRCLEdBQUlWLGdCQUFNM0IsTUFBTUEsS0FBSzRDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFNLFNBQVEsWUFBc0IsSUFBSSxDQUFDN0YsU0FBUzhGLFFBQVFDLE9BQU8sRUFBRXBFLGNBQWN4RSxTQUFTeUUsT0FBT29FLE1BQU0sQ0FBQyxHQUFHO0FBQUEsNkJBQUMsVUFBTyxJQUFJLEVBQUUzRSxTQUFTMUMsT0FBT3NILFVBQVVsRSxPQUFPLGVBQWUsR0FBSThELFlBQUVLLEtBQUssQ0FBQyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFBUyx1QkFBQyxrQkFBZSxXQUFVLFdBQVU7QUFBQSwrQkFBQyxjQUFXLFNBQVEsTUFBTUwsWUFBRUssUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLGtCQUFrQkw7QUFBQUEsWUFBRU07QUFBQUEsVUFBUztBQUFBLFVBQUlOLEVBQUVPO0FBQUFBLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCO0FBQUE7QUFBQSxVQUFRN0QsU0FBUzhELFlBQVlDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV1gsRUFBRWYsRUFBRSxHQUFHMkIsTUFBTWIsSUFBSSxDQUFBYyxTQUFRakssY0FBY2lLLElBQUksQ0FBQyxFQUFFQyxLQUFLLElBQUksS0FBSztBQUFBLGFBQXJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUw7QUFBQSxXQUFsVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStWO0FBQUEsTUFBaUIsdUJBQUMsVUFBTyxXQUFXdEosWUFBWSxJQUFJLE1BQU13SSxFQUFFZixFQUFFLGFBQWEsV0FBUyxNQUFDLFNBQVEsWUFBVyxTQUFTLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsR0FBSyxJQUFJOUUsU0FBU3FFLEtBQUtDLGVBQWUsMkJBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUs7QUFBQSxTQUF2ckJ1QixFQUFFZixJQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQSt0QixDQUFRLEtBQXQ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXc0QixLQUFwZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtaEM7QUFBQSxPQUE3MEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwMUM7QUFDcjJDO0FBQUNMLElBUmVELGdCQUFjO0FBQUEsVUFDd0J4RCxZQUNwQ3JELFFBQVE7QUFBQTtBQUFBLE1BRlY2RztBQVNULGdCQUFTb0MsaUJBQWlCO0FBQUFDLE1BQUE7QUFDN0IsUUFBTUMsV0FBV3RKLFlBQVk7QUFDN0IsUUFBTSxFQUFFdUosUUFBUSxJQUFJL0YsV0FBVztBQUMvQixRQUFNZ0csUUFBUXBKLGVBQWU7QUFDN0IsUUFBTSxDQUFDc0ksTUFBTWUsT0FBTyxJQUFJL0osU0FBUyxFQUFFLEdBQUcsQ0FBQ2lKLFVBQVVlLFdBQVcsSUFBSWhLLFNBQVMsS0FBSyxHQUFHLENBQUNrSixVQUFVZSxXQUFXLElBQUlqSyxTQUFTLGdCQUFnQixHQUFHLENBQUN3RixTQUFTQyxVQUFVLElBQUl6RixTQUFTLEtBQUssR0FBRyxDQUFDMEYsT0FBT0MsUUFBUSxJQUFJM0YsU0FBdUIsSUFBSSxHQUFHLENBQUNrSyxpQkFBaUJDLGtCQUFrQixJQUFJbkssU0FBUyxLQUFLLEdBQUcsQ0FBQ29LLFdBQVdDLFlBQVksSUFBSXJLLFNBQVMsS0FBSztBQUNyVSxRQUFNc0ssY0FBY3ZLLE9BQXdCLElBQUk7QUFDaEQsUUFBTXdLLFdBQVd4SyxPQUFPLEVBQUNpSixNQUFNLElBQUdDLFVBQVUsT0FBTUMsVUFBVSxpQkFBZ0IsQ0FBQztBQUM3RSxRQUFNc0IsVUFBVXpLLE9BQU8sSUFBSTtBQUMzQkQsWUFBVSxNQUFNO0FBQUUwSyxZQUFRQyxVQUFRO0FBQU0sV0FBTyxNQUFNO0FBQUVELGNBQVFDLFVBQVE7QUFBQSxJQUFPO0FBQUEsRUFBRyxHQUFFLEVBQUU7QUFDckYsUUFBTUMsWUFBWS9ILGFBQWFxRyxTQUFPdUIsU0FBU0UsUUFBUXpCLFFBQVFDLGFBQVdzQixTQUFTRSxRQUFReEIsWUFBWUMsYUFBV3FCLFNBQVNFLFFBQVF2QixRQUFRO0FBQzNJLFFBQU15QixnQkFBZ0IsQ0FBQ3BJLGdCQUFnQjJHLFFBQVEsSUFBSSwrQ0FBK0M7QUFDbEcsUUFBTTBCLE9BQU8sWUFBWTtBQUFFUCxpQkFBYSxJQUFJO0FBQUcsUUFBSTdFLFdBQVcsQ0FBQ3dELEtBQUs2QixLQUFLLEtBQUtGLGNBQWU7QUFBUWxGLGVBQVcsSUFBSTtBQUFHRSxhQUFTLElBQUk7QUFBRyxRQUFJO0FBQ3ZJLFlBQU1tRixJQUFJLE1BQU1wSixRQUFRLGNBQWMsRUFBRXNFLE1BQU0sRUFBRWdELE1BQU1DLFVBQVVDLFVBQVU2QixRQUFRLFFBQVEsRUFBRSxDQUFDO0FBQzdGLFlBQU1sQixRQUFRO0FBQ2QsWUFBTUMsTUFBTWtCLGtCQUFrQixFQUFFdEQsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ3JELFVBQUksQ0FBQzhDLFFBQVFDLFFBQVM7QUFDdEJGLGVBQVNFLFVBQVEsRUFBQ3pCLE1BQUtDLFVBQVNDLFNBQVE7QUFDeEMsVUFBSW9CLFlBQVlHLFFBQVMvSCxnQkFBZTRILFlBQVlHLE9BQU87QUFDM0RiLGVBQVMsTUFBTWtCLEVBQUVoRixLQUFLOEIsRUFBRSxXQUFXO0FBQUEsSUFDdkMsU0FDT2QsR0FBRztBQUNOLFVBQUkwRCxRQUFRQyxRQUFTOUUsVUFBU21CLGFBQWFKLFFBQVFJLElBQUksSUFBSUosTUFBTSx5QkFBeUIsQ0FBQztBQUFBLElBQy9GLFVBQUM7QUFFRyxVQUFJOEQsUUFBUUMsUUFBU2hGLFlBQVcsS0FBSztBQUFBLElBQ3pDO0FBQUEsRUFBRTtBQUNGLFNBQU8sdUJBQUMsWUFBUztBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxJQUFJM0MsU0FBU3VCLEtBQUswQyxlQUFlLDRCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFGO0FBQUEsSUFBYSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUksQ0FBQ2pFLFNBQVNrRSxXQUFXQyxxQkFBcUJuRSxTQUFTa0UsV0FBV0UsUUFBUSxHQUFHLGdFQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdLO0FBQUEsSUFBYSx1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUUsdUJBQUMsY0FBVyxXQUFVLFFBQU8sWUFBVSxNQUFDLEtBQUssQ0FBQStELFlBQVc7QUFBQ1gsa0JBQVlHLFVBQVFRO0FBQVFQLGdCQUFVTyxPQUFPO0FBQUEsSUFBRSxHQUFHLFVBQVUsQ0FBQUMsVUFBUztBQUFDQSxZQUFNQyxlQUFlO0FBQUUsV0FBS1AsS0FBSztBQUFBLElBQUUsR0FBRztBQUFBLDZCQUFDLGFBQVUsVUFBVXBGLFNBQVMsT0FBTSxnQkFBZSxPQUFPd0QsTUFBTSxVQUFVLENBQUFsQyxNQUFLaUQsUUFBUTNILGdCQUFnQjBFLEVBQUVzRSxPQUFPQyxPQUFPLEdBQUcsQ0FBQyxLQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZIO0FBQUEsTUFBRyx1QkFBQyxhQUFVLFVBQVU3RixTQUFTLE9BQU0saUJBQWdCLFFBQU0sTUFBQyxPQUFPeUQsVUFBVSxVQUFVLENBQUFuQyxNQUFLa0QsWUFBWWxELEVBQUVzRSxPQUFPQyxLQUFLLEdBQUksV0FBQyxPQUFPLE9BQU8sT0FBTyxLQUFLLEVBQUUzQyxJQUFJLENBQUE0QyxNQUFLLHVCQUFDLFlBQWlCLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixDQUFXLEtBQXpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMk07QUFBQSxNQUFZLHVCQUFDLGFBQVUsVUFBVTlGLFNBQVMsT0FBTSxXQUFVLE9BQU8wRCxVQUFVLFFBQVEsTUFBTWlCLG1CQUFtQixJQUFJLEdBQUcsVUFBVSxDQUFBckQsTUFBS21ELFlBQVluRCxFQUFFc0UsT0FBT0MsS0FBSyxHQUFHLFFBQVFuQixtQkFBbUJFLGNBQWMsQ0FBQyxDQUFDTyxlQUFlLGFBQWFULG1CQUFtQkUsY0FBY08sZ0JBQWdCQSxnQkFBZ0IsMkJBQTNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbVQ7QUFBQSxNQUFFLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJIQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtJO0FBQUEsTUFBUSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksVUFBVSxDQUFDM0IsS0FBSzZCLEtBQUssS0FBS3JGLFNBQVMsNEJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUY7QUFBQSxNQUFTLHVCQUFDLFVBQU8sV0FBV3JGLFlBQVksSUFBRyxlQUFjLHdCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsU0FBcmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOGxDO0FBQUEsT0FBbjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZzZDO0FBQzM2QztBQUFDd0osSUEzQmVELGdCQUFjO0FBQUEsVUFDVHBKLGFBQ0d3RCxZQUNOcEQsZ0JBTUlpQyxZQUFZO0FBQUE7QUFBQSxNQVRsQitHO0FBNEJULGdCQUFTNkIsbUJBQW1CO0FBQUFDLE1BQUE7QUFDL0IsUUFBTUMsUUFBUXZKLFNBQVM7QUFDdkIsUUFBTSxFQUFFd0osS0FBSyxJQUFJRDtBQUNqQixRQUFNM0IsUUFBUXBKLGVBQWU7QUFDN0IsUUFBTWlMLGdCQUFnQjFKLE9BQU8sYUFBYTtBQUMxQyxRQUFNMkosU0FBUzlKLFdBQVcsY0FBYyxDQUFDLFNBQVMsQ0FBQztBQUNuRCxRQUFNLENBQUNrSCxNQUFNZSxPQUFPLElBQUkvSixTQUFTMEwsS0FBSzFDLElBQUksR0FBRyxDQUFDRSxVQUFVZSxXQUFXLElBQUlqSyxTQUFTMEwsS0FBS3hDLFFBQVEsR0FBRyxDQUFDNkIsUUFBUWMsU0FBUyxJQUFJN0wsU0FBUzBMLEtBQUtYLE1BQU0sR0FBRyxDQUFDckYsT0FBT0MsUUFBUSxJQUFJM0YsU0FBdUIsSUFBSSxHQUFHLENBQUM4TCxPQUFPQyxRQUFRLElBQUkvTCxTQUFTLEtBQUssR0FBRyxDQUFDa0ssaUJBQWlCQyxrQkFBa0IsSUFBSW5LLFNBQVMsS0FBSyxHQUFHLENBQUNnTSxtQkFBbUJDLG9CQUFvQixJQUFJak0sU0FBUyxLQUFLO0FBQ3ZWLFFBQU1rTSxhQUFhdEssT0FBTyxTQUFTO0FBQ25DLFFBQU11SyxjQUFjRCxXQUFXcEcsUUFBUW9HLFdBQVdwRyxLQUFLQSxLQUFLc0csV0FBV1YsS0FBS1UsVUFBVUYsV0FBV3BHLEtBQUtBLE9BQU80RjtBQUM3RyxRQUFNVyxTQUFTekosa0JBQWtCO0FBQUEsSUFDN0IwSixVQUFVLEdBQUdaLEtBQUs5RCxFQUFFO0FBQUEsSUFDcEIyRSxRQUFRLEVBQUVILFNBQVNELFlBQVlDLFNBQVNJLFFBQVEsRUFBRXhELE1BQU1tRCxZQUFZbkQsTUFBTUUsVUFBVWlELFlBQVlqRCxVQUFVNkIsUUFBUW9CLFlBQVlwQixPQUFPLEVBQUU7QUFBQSxJQUN2STBCLE9BQU8sRUFBRXpELE1BQU1FLFVBQVU2QixPQUFPO0FBQUEsSUFDaEMyQixPQUFPQSxDQUFBRixXQUFVO0FBQUV6QyxjQUFReUMsT0FBT3hELElBQUk7QUFBR2lCLGtCQUFZdUMsT0FBT3RELFFBQVE7QUFBRzJDLGdCQUFVVyxPQUFPekIsTUFBTTtBQUFBLElBQUc7QUFBQSxJQUNqR2xCLFNBQVNBLE1BQU1xQyxXQUFXUyxRQUFRLEVBQUVDLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDNUQsQ0FBQztBQUNELFFBQU1DLFVBQVVsSyxhQUFhMEosT0FBT1MsS0FBSztBQUN6QyxRQUFNbkMsZ0JBQWdCLENBQUNwSSxnQkFBZ0IyRyxRQUFRLElBQUksK0NBQStDO0FBQ2xHLFFBQU0wQixPQUFPLFlBQVk7QUFDckJxQix5QkFBcUIsSUFBSTtBQUN6QixRQUFJLENBQUNqRCxLQUFLNkIsS0FBSyxLQUFLRixjQUFlO0FBQ25DaEYsYUFBUyxJQUFJO0FBQUdvRyxhQUFTLEtBQUs7QUFDOUIsVUFBTWdCLFdBQVdWLE9BQU9XLFFBQVE7QUFDaEMsUUFBSSxDQUFDRCxTQUFVO0FBQ2YsVUFBTTNDLFlBQVksRUFBRXBCLE1BQU1FLFVBQVU2QixPQUFPO0FBQzNDLFFBQUk7QUFDQSxZQUFNa0MsU0FBUyxNQUFNckIsT0FBT3NCLFFBQVEsRUFBRUMsTUFBTSxFQUFFN0QsUUFBUW9DLEtBQUs5RCxHQUFHLEdBQUd3RSxTQUFTVyxTQUFTWCxTQUFTcEcsTUFBTStHLFNBQVNLLE1BQU0sQ0FBQztBQUNsSHRELFlBQU11RCxhQUFhLENBQUMsUUFBUTVCLE1BQU1wRyxRQUFRc0MsS0FBS0MsSUFBSThELEtBQUs5RCxJQUFJNkQsTUFBTTZCLFdBQVdDLGlCQUFpQixHQUFHTixNQUFNO0FBQ3ZHWixhQUFPbUIsVUFBVSxFQUFFcEIsU0FBU2EsT0FBT25ILEtBQUtzRyxTQUFTSSxRQUFRLEVBQUV4RCxNQUFNaUUsT0FBT25ILEtBQUtrRCxNQUFNRSxVQUFVK0QsT0FBT25ILEtBQUtvRCxVQUFVNkIsUUFBUWtDLE9BQU9uSCxLQUFLaUYsT0FBTyxFQUFFLEdBQUdYLFNBQVM7QUFDNUoyQixlQUFTLElBQUk7QUFBQSxJQUNqQixTQUNPckcsUUFBTztBQUFFMkcsYUFBT29CLE9BQU8vSCxNQUFLO0FBQUdDLGVBQVNELGtCQUFpQmdCLFFBQVFoQixTQUFRLElBQUlnQixNQUFNLHlCQUF5QixDQUFDO0FBQUEsSUFBRztBQUFBLEVBQzNIO0FBQ0EsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxzQkFBcUIsVUFBUyxvRkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSTtBQUFBLElBQ2hJLHVCQUFDLGdCQUNHO0FBQUEsNkJBQUMsU0FBTSxPQUFNLG1CQUFrQixVQUFTLFNBQ3BDLGlDQUFDLGNBQVcsV0FBVSxRQUFPLEtBQUttRyxTQUFTLFlBQVUsTUFBQyxVQUFVLENBQUEzQixVQUFTO0FBQUVBLGNBQU1DLGVBQWU7QUFBRyxhQUFLUCxLQUFLO0FBQUEsTUFBRyxHQUM1RztBQUFBLCtCQUFDLGVBQVksT0FBT2xGLFNBQVNrRyxPQUFPbEcsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLGlCQUFjLFFBQWdCLFFBQVEsRUFBRXNELE1BQU0sZ0JBQWdCRSxVQUFVLFdBQVc2QixRQUFRLFdBQVcsR0FBRyxNQUFNYSxPQUFPcEcsV0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSDtBQUFBLFFBQzlIc0csU0FBUyx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVMseUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUMzRSx1QkFBQyxjQUFXLFdBQVcsRUFBRXRELElBQUksVUFBVWtGLElBQUksTUFBTSxHQUFHLFlBQVksRUFBRWxGLElBQUksV0FBV2tGLElBQUksUUFBUSxHQUN6RjtBQUFBLGlDQUFDLGFBQVUsT0FBTSxnQkFBZSxPQUFPMUUsTUFBTSxVQUFVLENBQUMyQyxlQUFlLFVBQVUsQ0FBQVQsVUFBUztBQUFFbkIsb0JBQVFtQixNQUFNRSxPQUFPQyxLQUFLO0FBQUdVLHFCQUFTLEtBQUs7QUFBQSxVQUFHLEdBQUcsSUFBSSxFQUFFNEIsTUFBTSxHQUFHQyxVQUFVLEVBQUUsS0FBeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEs7QUFBQSxVQUMxSyx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLE9BQU9sQyxLQUFLekMsVUFBVSxVQUFRLE1BQUMsWUFBVywwRUFBeUUsSUFBSSxFQUFFMEUsTUFBTSxHQUFHQyxVQUFVLEVBQUUsS0FBL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUw7QUFBQSxhQUZyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGNBQVcsV0FBVyxFQUFFcEYsSUFBSSxVQUFVa0YsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFbEYsSUFBSSxXQUFXa0YsSUFBSSxRQUFRLEdBQ3pGO0FBQUEsaUNBQUMsYUFBVSxPQUFNLFdBQVUsT0FBT3hFLFVBQVUsVUFBVSxDQUFDeUMsZUFBZSxRQUFRLE1BQU14QixtQkFBbUIsSUFBSSxHQUFHLFVBQVUsQ0FBQWUsVUFBUztBQUFFakIsd0JBQVlpQixNQUFNRSxPQUFPQyxLQUFLO0FBQUdVLHFCQUFTLEtBQUs7QUFBQSxVQUFHLEdBQUcsUUFBUTdCLG1CQUFtQjhCLHNCQUFzQixDQUFDLENBQUNyQixlQUFlLGFBQWFULG1CQUFtQjhCLHNCQUFzQnJCLGdCQUFnQkEsZ0JBQWdCLHVDQUF1QyxJQUFJLEVBQUVnRCxNQUFNLEdBQUdDLFVBQVUsRUFBRSxLQUFsWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvWjtBQUFBLFVBQ3BaLHVCQUFDLGFBQVUsT0FBTSxzQkFBcUIsT0FBTSxjQUFhLFVBQVEsTUFBQyxZQUFZLCtEQUErRDdDLE1BQU0sS0FBSyxJQUFJLEVBQUU0QyxNQUFNLEdBQUdDLFVBQVUsRUFBRSxLQUFuTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxTDtBQUFBLGFBRnpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsYUFBVSxPQUFNLGFBQVksT0FBTSw2QkFBNEIsVUFBUSxRQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkUsdUJBQUMsa0JBQWUsWUFBVyxlQUFjLE1BQUssVUFBUyxTQUFRLGFBQVksTUFBTWhDLE9BQU9wRyxTQUFTLFVBQVUsQ0FBQ21HLGlCQUFpQixDQUFDVSxPQUFPUyxTQUFTbEIsT0FBT3BHLFNBQVMsNEJBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEs7QUFBQSxXQWI5SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0EsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sZ0NBQStCLFVBQVMsZ0dBQStGLFVBQVMsU0FDekosaUNBQUMsU0FBTSxJQUFJMUMsU0FBUzhGLFFBQVFpRixtQkFDeEI7QUFBQSwrQkFBQyxTQUFNLFVBQVMsUUFBUXRIO0FBQUFBLHFCQUFXLDZGQUE2RjtBQUFBLFVBQXlEO0FBQUEsYUFBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyTztBQUFBLFFBQzNPLHVCQUFDLHNCQUFtQixPQUFNLDhCQUE2QixRQUFPLDRDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsUUFDdEcsdUJBQUMsc0JBQW1CLE9BQU0sd0NBQXVDLFFBQVFBLFdBQVcsMkNBQTJDLHdDQUF3QyxJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSxjQUFjLFFBQU8sMEJBQTdNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbU87QUFBQSxRQUNuTyx1QkFBQyxzQkFBbUIsT0FBTSw2QkFBNEIsUUFBTyw2REFBNEQsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUsa0JBQWtCLFFBQU8sd0JBQW5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUw7QUFBQSxRQUN2TCx1QkFBQyxzQkFBbUIsT0FBTSx5QkFBd0IsUUFBUXJCLFdBQVcsbURBQW1ELCtCQUErQixJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSwwQkFBMEIsUUFBTyxnQkFBek07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxTjtBQUFBLFFBQ3JOLHVCQUFDLHNCQUFtQixPQUFNLGNBQWEsUUFBUXJCLFdBQVcsa0NBQWtDLGlDQUFpQyxJQUFJLE1BQU1tRixLQUFLOUQsRUFBRSxvQkFBb0IsUUFBTyx3QkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TDtBQUFBLFFBQzdMLHVCQUFDLHNCQUFtQixPQUFNLDRDQUEyQyxRQUFPLDJFQUEwRSxJQUFJLE1BQU04RCxLQUFLOUQsRUFBRSxjQUFjLFFBQU8sc0JBQTVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOE07QUFBQSxRQUM5TSx1QkFBQyxzQkFBbUIsT0FBTSx1QkFBc0IsUUFBTywwREFBeUQsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUscUJBQXFCLFFBQU8saUJBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEs7QUFBQSxRQUMxSyx1QkFBQyxzQkFBbUIsT0FBTSxzQ0FBcUMsUUFBTywrRkFBOEYsSUFBSSxNQUFNOEQsS0FBSzlELEVBQUUscUJBQXFCLFFBQU8scUJBQWpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa087QUFBQSxXQVR0TztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsT0FqQ0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDUDtBQUNKO0FBQUM0RCxJQXBFZUQsa0JBQWdCO0FBQUEsVUFDZHJKLFVBRUF4QixnQkFDUXVCLFFBQ1BILFlBRUlGLFFBRUpnQixtQkFPQ0QsWUFBWTtBQUFBO0FBQUEsTUFoQmhCNEk7QUFxRWhCLFNBQVN1QyxtQkFBbUIsRUFBRUMsT0FBTzFGLFFBQVEyRixJQUFJQyxPQUF3RSxHQUFHO0FBQ3hILFNBQU8sdUJBQUMsa0JBQWUsVUFBUywwQkFBeUIsV0FBVSxPQUFNLFlBQVksRUFBRXpGLElBQUksY0FBY0MsSUFBSSxTQUFTLEdBQUcsZ0JBQWUsaUJBQWdCLFVBQVMsUUFDN0o7QUFBQSwyQkFBQyxPQUFJO0FBQUEsNkJBQUMsY0FBVyxZQUFZeEksU0FBUzhFLFdBQVdDLFdBQVdrSixRQUFTSCxtQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBa0IxRixvQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLFNBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0s7QUFBQSxJQUMvSjJGLE1BQU1DLFVBQVUsdUJBQUMsYUFBVSxJQUFTQSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHUDtBQUNKO0FBQUNFLE1BTFFMO0FBTVQsTUFBTU0sYUFBbUM7QUFBQSxFQUNyQ0MsT0FBTztBQUFBLEVBQWdCQyxTQUFTO0FBQUEsRUFBV0MsT0FBTztBQUFBLEVBQVlDLFdBQVc7QUFBQSxFQUFpQkMsWUFBWTtBQUFBLEVBQVdDLFdBQVc7QUFBQSxFQUFlQyxRQUFRO0FBQ3ZKO0FBQ08sZ0JBQVNDLFdBQVc7QUFBQUMsTUFBQTtBQUN2QixRQUFNLEVBQUV4SixTQUFTcUcsS0FBSyxJQUFJeEosU0FBUztBQUNuQyxRQUFNNE0sT0FBT2xOLE9BQU8sZUFBZSxFQUFFbU4sT0FBT3RNLGFBQWEsYUFBYSxFQUFFLENBQUM7QUFDekUsUUFBTXVNLFNBQVNsTixXQUFXLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztBQUN6RCxRQUFNOEosU0FBUzlKLFdBQVcscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQzlELFFBQU1tTixTQUFTbk4sV0FBVyxvQkFBb0IsQ0FBQyxhQUFhLENBQUM7QUFDN0QsUUFBTSxDQUFDb04sTUFBTUMsT0FBTyxJQUFJblAsU0FBd0MsR0FBRyxDQUFDb1AsT0FBT0MsUUFBUSxJQUFJclAsU0FBUyxFQUFFLEdBQUcsQ0FBQ3VKLE9BQU8rRixRQUFRLElBQUl0UCxTQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUN1UCxRQUFRQyxTQUFTLElBQUl4UCxTQUE0QixJQUFJLEdBQUcsQ0FBQ3lQLGNBQWNDLGVBQWUsSUFBSTFQLFNBQVMsRUFBRTtBQUM3UCxRQUFNMlAsT0FBT0EsQ0FBQ3RHLE1BQXlCO0FBQUVxRyxvQkFBZ0IsRUFBRTtBQUFHUCxZQUFROUYsQ0FBQztBQUFHZ0csYUFBUyxFQUFFO0FBQUdDLGFBQVNqRyxHQUFHRSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsRUFBRztBQUMxSCxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHdCQUF1QixVQUFTLGdGQUErRSxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVEsYUFBWSxTQUFTLE1BQU1vRyxLQUFLLElBQUksR0FBRyw2QkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RyxLQUFsUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9RO0FBQUEsSUFBR0YsZ0JBQWdCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBUyxJQUFJM00sU0FBUzhNLE9BQU8xSSxVQUFXdUksMEJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Y7QUFBQSxJQUFTLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsaUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBT1gsTUFBTSxnQkFBZSxXQUFXQSxlQUFLaEosUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSw2QkFBNEIsTUFBTWdKLEtBQUtoSixLQUFLQSxNQUFNLFFBQVEsQ0FBQXVELE1BQUtBLEVBQUV6QixJQUFJLFNBQVM7QUFBQSxVQUNwa0IsRUFBRWlJLEtBQUssUUFBUXZRLE9BQU8sYUFBYXdRLFFBQVFBLENBQUF6RyxNQUFLQSxFQUFFMEcsV0FBVzFLLFFBQVFzQyxLQUFLQyxLQUFLdkMsUUFBUXNDLEtBQUtxSSxjQUFjLGVBQWUzRyxFQUFFMEcsTUFBTSxHQUFHO0FBQUEsVUFBRyxFQUFFRixLQUFLLFNBQVN2USxPQUFPLFdBQVd3USxRQUFRQSxDQUFBekcsTUFBS0EsRUFBRUUsTUFBTWIsSUFBSSxDQUFBb0MsTUFBS3NELFdBQVd0RCxDQUFDLENBQUMsRUFBRXJCLEtBQUssSUFBSSxFQUFFO0FBQUEsVUFBRyxFQUFFb0csS0FBSyxVQUFVdlEsT0FBTyxjQUFjd1EsUUFBUUEsQ0FBQXpHLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFaEIsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsRUFBRztBQUFBLFVBQUcsRUFBRXdILEtBQUssU0FBU3ZRLE9BQU8sa0JBQWtCd1EsUUFBUUEsQ0FBQXpHLE1BQUssR0FBR0EsRUFBRTRHLFlBQVk5SCxNQUFNLGFBQWFrQixFQUFFa0UsaUJBQWlCLEdBQUc7QUFBQSxVQUNyYTtBQUFBLFlBQ0lzQyxLQUFLO0FBQUEsWUFBV3ZRLE9BQU87QUFBQSxZQUFJd1EsUUFBUUEsQ0FBQXpHLE1BQUssdUJBQUMsU0FBTSxXQUFVLE9BQU07QUFBQSxxQ0FBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFTLE1BQU1zRyxLQUFLdEcsQ0FBQyxHQUFHLHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQWlCLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLE9BQU0sU0FBUSxVQUFVQSxFQUFFMEcsV0FBVzFLLFFBQVFzQyxLQUFLQyxNQUFNeUIsRUFBRWhCLFdBQVcsV0FBVyxTQUFTLE1BQU1tSCxVQUFVbkcsQ0FBQyxHQUFHLHVCQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnSztBQUFBLGlCQUFyUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzUztBQUFBLFVBQ2xWO0FBQUEsUUFBQyxLQUpvZTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3ZlO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU15RixLQUFLaEosS0FBS3FCLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQUx1YztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS3JjLEtBTHFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLalk7QUFBQSxTQUx1VjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzFVO0FBQUEsSUFDdEQsdUJBQUMsY0FBVyxNQUFNK0gsU0FBU2dCLFFBQVcsT0FBT2hCLE9BQU8sbUJBQW1CLGlCQUFpQixTQUFTLE1BQU1DLFFBQVFlLE1BQVMsR0FBRyxNQUFNbEIsT0FBT3hKLFdBQVdvRyxPQUFPcEcsU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQytELE1BQU1wQixVQUFXLENBQUMrRyxRQUFRLENBQUMsNkJBQTZCaUIsS0FBS2YsS0FBSyxLQUFNSixPQUFPeEosV0FBV29HLE9BQU9wRyxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDalYsWUFBSTBKLE1BQU07QUFDTixnQkFBTXRELE9BQU9zQixRQUFRLEVBQUVDLE1BQU0sRUFBRWlELFVBQVVsQixLQUFLdEgsR0FBRyxHQUFHd0UsU0FBUzhDLEtBQUszQixtQkFBbUJ2SCxNQUFNLEVBQUV1RCxNQUFNLEVBQUUsQ0FBQztBQUN0R21HLDBCQUFnQixrQ0FBa0NSLEtBQUthLE1BQU0sR0FBRztBQUFBLFFBQ3BFLE9BQU87QUFDSCxnQkFBTWYsT0FBTzlCLFFBQVEsRUFBRWxILE1BQU0sRUFBRW9KLE9BQU83RixNQUFNLEVBQUUsQ0FBQztBQUMvQ21HLDBCQUFnQixzQkFBc0JOLE1BQU12RSxLQUFLLENBQUMsR0FBRztBQUFBLFFBQ3pEO0FBQ0FzRSxnQkFBUWUsTUFBUztBQUFBLE1BQ3JCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyxtQkFWOEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVUzSSxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPbEIsT0FBT3RKLFNBQVNrRyxPQUFPbEcsU0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQUUsdUJBQUMsY0FBYTtBQUFBLFNBQUN3SixRQUFRLHVCQUFDLGFBQVUsT0FBTSxtQkFBa0IsTUFBSyxTQUFRLE9BQU9FLE9BQU8sVUFBVSxDQUFBdEksTUFBS3VJLFNBQVN2SSxFQUFFc0UsT0FBT0MsS0FBSyxLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsUUFBRyx1QkFBQyxjQUFXLFNBQVEsYUFBWSw0QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQWVnRixPQUFPQyxLQUFLbEMsVUFBVSxFQUFhMUYsSUFBSSxDQUFBYyxTQUFRLHVCQUFDLG9CQUE0QixPQUFPLEdBQUc0RSxXQUFXNUUsSUFBSSxDQUFDLE1BQU1oSSxrQkFBa0IrTyxZQUFZL0csSUFBSSxHQUFHckIsVUFBVSxDQUFDLFVBQVUsU0FBUyx1QkFBQyxZQUFTLFNBQVNvQixNQUFNaUgsU0FBU2hILElBQUksR0FBRyxVQUFVLENBQUExQyxNQUFLd0ksU0FBU3hJLEVBQUVzRSxPQUFPcUYsVUFBVSxDQUFDLEdBQUdsSCxPQUFPQyxJQUFJLElBQUlELE1BQU1tSCxPQUFPLENBQUE1RixNQUFLQSxNQUFNdEIsSUFBSSxDQUFDLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0ksS0FBL09BLE1BQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeVEsQ0FBRTtBQUFBLFFBQUUsdUJBQUMsU0FBTSxVQUFTLFdBQVUsdUhBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUk7QUFBQSxXQUF4bkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnb0I7QUFBQSxTQVYvdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVU0dUI7QUFBQSxJQUFhLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDK0YsUUFBUSxPQUFNLDJCQUEwQixjQUFhLGlCQUFnQixhQUFhLGFBQWFBLFFBQVFRLFVBQVUsRUFBRSxVQUFVckUsS0FBSzFDLElBQUksMEdBQTBHLFNBQVMsTUFBTXdHLFVBQVUsSUFBSSxHQUFHLE1BQU1QLE9BQU96SixTQUFTLE9BQU95SixPQUFPdkosT0FBTyxXQUFXLFlBQVk7QUFDM2xDLFVBQUksQ0FBQzZKLE9BQVE7QUFDYixZQUFNTixPQUFPL0IsUUFBUSxFQUFFQyxNQUFNLEVBQUVpRCxVQUFVYixPQUFPM0gsR0FBRyxHQUFHd0UsU0FBU21ELE9BQU9oQyxrQkFBa0IsQ0FBQztBQUFBLElBQzdGLEtBSHN2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR3B2QjtBQUFBLE9BbkJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkg7QUFDUjtBQUFDc0IsSUE1QmVELFVBQVE7QUFBQSxVQUNNMU0sVUFDYk4sUUFBK0JhLGNBQzdCWCxZQUNBQSxZQUNBQSxVQUFVO0FBQUE7QUFBQSxNQUxiOE07QUE2QlQsZ0JBQVMrQixZQUFZO0FBQUFDLE1BQUE7QUFBRSxRQUFNLEVBQUVsRixLQUFLLElBQUl4SixTQUFTO0FBQUcsUUFBTTRNLE9BQU9sTixPQUFPLG1CQUFtQixFQUFFbU4sT0FBT3RNLGFBQWEsaUJBQWlCLEVBQUUsQ0FBQztBQUFHLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0scUJBQW9CLFVBQVMsMkdBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0o7QUFBQSxJQUFFLHVCQUFDLFNBQU0sVUFBUyxRQUFPLElBQUlLLFNBQVM4TSxPQUFPMUksVUFBVSw0TUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpUDtBQUFBLElBQVEsdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxxQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPNEgsTUFBTSxnQkFBZSxXQUFXQSxlQUFLaEosUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxxQkFBb0IsTUFBTWdKLEtBQUtoSixLQUFLQSxNQUFNLFFBQVEsQ0FBQStLLE1BQUtBLEVBQUVqSixJQUFJLFNBQVM7QUFBQSxVQUM1dUIsRUFBRWlJLEtBQUssUUFBUXZRLE9BQU8sYUFBYXdRLFFBQVFBLENBQUFlLE1BQUt4TyxTQUFTd08sRUFBRUMsWUFBWXBGLEtBQUt4QyxRQUFRLEVBQUU7QUFBQSxVQUFHLEVBQUUyRyxLQUFLLFNBQVN2USxPQUFPLG1CQUFtQndRLFFBQVFBLENBQUFlLE1BQUssZUFBZUEsRUFBRUUsT0FBTyxHQUFHO0FBQUEsVUFBRyxFQUFFbEIsS0FBSyxVQUFVdlEsT0FBTyxZQUFZd1EsUUFBUUEsQ0FBQWUsTUFBS0EsRUFBRTVDLE9BQU87QUFBQSxVQUFHLEVBQUU0QixLQUFLLFVBQVV2USxPQUFPLGFBQWF3USxRQUFRQSxDQUFBZSxNQUFLLEdBQUdBLEVBQUVHLFNBQVNDLElBQUksb0JBQW9CSixFQUFFRyxTQUFTcEosRUFBRSxHQUFHO0FBQUEsVUFBRyxFQUFFaUksS0FBSyxXQUFXdlEsT0FBTyxXQUFXd1EsUUFBUUEsQ0FBQWUsTUFBS0EsRUFBRUssUUFBUTtBQUFBLFVBQUcsRUFBRXJCLEtBQUssU0FBU3ZRLE9BQU8sZUFBZXdRLFFBQVFBLENBQUFlLE1BQUssdUJBQUMsY0FBVyxTQUFRLFdBQVdBLFlBQUVNLGFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDLEVBQWM7QUFBQSxRQUFDLEtBRG9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFdnBCO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1yQyxLQUFLaEosS0FBS3FCLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQUZ1bkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVybkIsS0FGcWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFampCO0FBQUEsU0FGbWdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFdGY7QUFBQSxPQUZtRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRTNGO0FBQUs7QUFBQ3lKLElBRmpERCxXQUFTO0FBQUEsVUFBc0J6TyxVQUF5Qk4sUUFBbUNhLFlBQVk7QUFBQTtBQUFBLE1BQXZHa087QUFHVCxnQkFBU1MsY0FBYztBQUFBQyxNQUFBO0FBQzFCLFFBQU0sRUFBRTNGLEtBQUssSUFBSXhKLFNBQVM7QUFDMUIsUUFBTW9QLFNBQVMxUCxPQUFPLGtCQUFrQjtBQUN4QyxRQUFNMlAsV0FBVzNQLE9BQU8sdUJBQXVCLEVBQUVtTixPQUFPdE0sYUFBYSxxQkFBcUIsRUFBRSxDQUFDO0FBQzdGLFFBQU1tSSxPQUFPOUksV0FBVyx1QkFBdUIsQ0FBQyxrQkFBa0IsQ0FBQztBQUNuRSxRQUFNMFAsU0FBUzFQLFdBQVcsd0JBQXdCLENBQUMscUJBQXFCLENBQUM7QUFDekUsUUFBTSxDQUFDMlAsTUFBTUMsT0FBTyxJQUFJMVIsU0FBUyxFQUFFLEdBQUcsQ0FBQzJSLE1BQU1DLE9BQU8sSUFBSTVSLFNBQVMsRUFBRSxHQUFHLENBQUM2UixZQUFZQyxXQUFXLElBQUk5UixTQUFTLEVBQUUsR0FBRyxDQUFDK1IsTUFBTUMsT0FBTyxJQUFJaFMsU0FBOEIsUUFBUSxHQUFHLENBQUNpUyxRQUFRQyxTQUFTLElBQUlsUyxTQUFTLEVBQUUsR0FBRyxDQUFDMlAsTUFBTXdDLE9BQU8sSUFBSW5TLFNBQVMsS0FBSyxHQUFHLENBQUNvUyxhQUFhQyxjQUFjLElBQUlyUyxTQUFTLEtBQUssR0FBRyxDQUFDc1MsYUFBYUMsY0FBYyxJQUFJdlMsU0FBUyxLQUFLLEdBQUcsQ0FBQ3dTLGlCQUFpQkMsa0JBQWtCLElBQUl6UyxTQUFTLEtBQUssR0FBRyxDQUFDMFMsYUFBYUMsY0FBYyxJQUFJM1MsU0FBUyxFQUFFO0FBQ3hiLFFBQU00UyxtQkFBbUIzUSxPQUFPLGdCQUFnQjtBQUNoRCxRQUFNLENBQUM0USxxQkFBcUJDLHNCQUFzQixJQUFJOVMsU0FBUyxFQUFFLEdBQUcsQ0FBQytTLGdCQUFnQkMsaUJBQWlCLElBQUloVCxTQUFTLEVBQUU7QUFDckhGLFlBQVUsTUFBTTtBQUNaLFVBQU1tVCxRQUFRdE0sT0FBT3VNLFdBQVcsTUFBTUYsa0JBQWtCSCxvQkFBb0JoSSxLQUFLLENBQUMsR0FBRyxHQUFHO0FBQ3hGLFdBQU8sTUFBTWxFLE9BQU93TSxhQUFhRixLQUFLO0FBQUEsRUFDMUMsR0FBRyxDQUFDSixtQkFBbUIsQ0FBQztBQUN4QixRQUFNTyxZQUFZdlIsWUFBWSxpQkFBaUIsRUFBRWtOLE9BQU8sRUFBRXNFLEdBQUdOLGtCQUFrQjdDLE9BQVUsRUFBRSxHQUFHMEMsZ0JBQWdCO0FBQzlHLFFBQU1VLHlCQUF5QjFSLE9BQU8sZUFBZSxFQUFFdUwsTUFBTSxFQUFFMEUsV0FBVyxFQUFFLEdBQUdlLG9CQUFvQixDQUFDLENBQUNmLFVBQVU7QUFDL0csUUFBTTBCLG1CQUFtQkgsVUFBVXROLE1BQU1BLEtBQUtzRCxLQUFLLENBQUFvSyxhQUFZQSxTQUFTNUwsT0FBT2lLLFVBQVUsS0FBS3lCLHVCQUF1QnhOLE1BQU1BO0FBQzNILFFBQU11RyxTQUFTekosa0JBQWtCO0FBQUEsSUFDN0IwSixVQUFVLEdBQUdaLEtBQUs5RCxFQUFFO0FBQUEsSUFDcEIyRSxRQUFRK0UsT0FBT3hMLE9BQU8sRUFBRXNHLFNBQVNrRixPQUFPeEwsS0FBS0EsS0FBS3NHLFNBQVNJLFFBQVEsRUFBRWlGLE1BQU1ILE9BQU94TCxLQUFLQSxLQUFLMk4sbUJBQW1CQyxTQUFTLEtBQUssSUFBSS9CLE1BQU1MLE9BQU94TCxLQUFLQSxLQUFLNk4saUJBQWlCLEVBQUUsSUFBSXpEO0FBQUFBLElBQy9LekQsT0FBTyxFQUFFZ0YsTUFBTUUsS0FBSztBQUFBLElBQ3BCakYsT0FBT0EsQ0FBQUYsV0FBVTtBQUFFa0YsY0FBUWxGLE9BQU9pRixJQUFJO0FBQUdHLGNBQVFwRixPQUFPbUYsSUFBSTtBQUFBLElBQUc7QUFBQSxJQUMvRDlILFNBQVNBLE1BQU15SCxPQUFPM0UsUUFBUSxFQUFFQyxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3hELENBQUM7QUFDRCxRQUFNZ0gsYUFBYWpSLGFBQWEwSixPQUFPUyxLQUFLO0FBQzVDLFFBQU0rRyxZQUFZLENBQUMsUUFBUTFELEtBQUtzQixJQUFJLEtBQUtxQyxPQUFPckMsSUFBSSxJQUFJLEtBQUtxQyxPQUFPckMsSUFBSSxJQUFJLFFBQVEseUNBQXlDO0FBQzdILFFBQU1zQyxZQUFZNVIsZ0JBQWdCd1AsS0FBSzlHLEtBQUssQ0FBQyxJQUFJLEtBQUsxSSxnQkFBZ0J3UCxJQUFJLElBQUksTUFBTyxzQ0FBc0M7QUFDM0gsUUFBTXFDLGlCQUFpQjVCLGVBQWVJLG9CQUFvQixDQUFDLENBQUNxQjtBQUM1RCxRQUFNSSxpQkFBaUIzQixlQUFlRSxvQkFBb0IsQ0FBQyxDQUFDdUI7QUFDNUQsUUFBTUcsYUFBYSxZQUFZO0FBQzNCekIsdUJBQW1CLElBQUk7QUFDdkIsUUFBSW9CLGFBQWFFLGFBQWEsQ0FBQzFILE9BQU9TLE1BQU87QUFDN0MsVUFBTUMsV0FBV1YsT0FBT1csUUFBUTtBQUFHLFFBQUksQ0FBQ0QsU0FBVTtBQUNsRCxVQUFNM0MsWUFBWSxFQUFFcUgsTUFBTUUsS0FBSztBQUMvQmdCLG1CQUFlLEVBQUU7QUFDakIsUUFBSTtBQUNBLFlBQU0xRixTQUFTLE1BQU1yQyxLQUFLc0MsUUFBUSxFQUFFZCxTQUFTVyxTQUFTWCxTQUFTcEcsTUFBTTtBQUFBLFFBQ2pFLEdBQUkrRyxTQUFTSyxNQUFNcUUsU0FBU3ZCLFNBQVksRUFBRXVELG1CQUFtQkssT0FBTy9HLFNBQVNLLE1BQU1xRSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsUUFDOUYsR0FBSTFFLFNBQVNLLE1BQU11RSxTQUFTekIsU0FBWSxFQUFFeUQsa0JBQWtCNUcsU0FBU0ssTUFBTXVFLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDekYsRUFBRSxDQUFDO0FBQ0gsWUFBTXdDLFFBQVE5SCxPQUFPbUIsVUFBVSxFQUFFcEIsU0FBU2EsT0FBT25ILEtBQUtzRyxTQUFTSSxRQUFRLEVBQUVpRixNQUFNeEUsT0FBT25ILEtBQUsyTixtQkFBbUJDLFNBQVMsS0FBSyxJQUFJL0IsTUFBTTFFLE9BQU9uSCxLQUFLNk4saUJBQWlCLEVBQUUsR0FBR3ZKLFNBQVM7QUFDakx1SSxxQkFBZXdCLFFBQVEsd0NBQXdDLCtEQUErRDtBQUFBLElBQ2xJLFNBQVN6TyxPQUFPO0FBQUUyRyxhQUFPb0IsT0FBTy9ILEtBQUs7QUFBQSxJQUFHO0FBQUEsRUFDNUM7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHFDQUFvQyxVQUFTLHFHQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdLO0FBQUEsSUFBRSx1QkFBQyxlQUFZLFNBQVMsRUFBRThDLElBQUksT0FBTzRMLElBQUksWUFBWSxHQUFHO0FBQUEsNkJBQUMsU0FBTSxPQUFNLHNCQUFxQixVQUFTLFNBQVEsaUNBQUMsY0FBVyxPQUFPOUMsUUFBUSxnQkFBZSxXQUFVLGlDQUFDLGNBQVcsV0FBVSxRQUFPLEtBQUtzQyxZQUFZLFVBQVUsQ0FBQTFJLFVBQVM7QUFBRUEsY0FBTUMsZUFBZTtBQUFHLGFBQUsrSSxXQUFXO0FBQUEsTUFBRyxHQUFHO0FBQUEsK0JBQUMsZUFBWSxPQUFPdEosS0FBS2xGLFNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxRQUFFLHVCQUFDLGlCQUFjLFFBQWdCLFFBQVEsRUFBRStMLE1BQU0seUJBQXlCRSxNQUFNLDhCQUE4QixHQUFHLE1BQU0vRyxLQUFLcEYsV0FBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSTtBQUFBLFFBQUdrTixlQUFlLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBVUEseUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUFVcEIsT0FBT3hMLFFBQVEsdUJBQUMsVUFBTyxPQUFPd0wsT0FBT3hMLEtBQUtBLEtBQUt1QyxVQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFBRyx1QkFBQyxhQUFVLE9BQU0seUJBQXdCLE9BQU9vSixNQUFNLFFBQVEsTUFBTVksZUFBZSxJQUFJLEdBQUcsVUFBVSxDQUFBdkwsTUFBSztBQUFFNEssa0JBQVE1SyxFQUFFc0UsT0FBT0MsS0FBSztBQUFHZ0gseUJBQWUsSUFBSTtBQUFHTSx5QkFBZSxFQUFFO0FBQUEsUUFBRyxHQUFHLE1BQUssVUFBUyxZQUFZLEVBQUUwQixLQUFLLEdBQUdDLEtBQUssT0FBT0MsTUFBTSxFQUFFLEdBQUcsT0FBT1AsZUFBZSxZQUFZQSxnQkFBZ0JILFlBQVksMENBQTFTO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaVY7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSwrQkFBOEIsV0FBUyxNQUFDLFNBQVMsR0FBRyxPQUFPbEMsTUFBTSxRQUFRLE1BQU1ZLGVBQWUsSUFBSSxHQUFHLFVBQVUsQ0FBQXpMLE1BQUs7QUFBRThLLGtCQUFROUssRUFBRXNFLE9BQU9DLEtBQUs7QUFBR2tILHlCQUFlLElBQUk7QUFBR0kseUJBQWUsRUFBRTtBQUFBLFFBQUcsR0FBRyxPQUFPc0IsZUFBZSxZQUFZQSxnQkFBZ0JGLFlBQVksd0NBQTNRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ1Q7QUFBQSxRQUFFLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLE1BQUssVUFBUyxTQUFRLGFBQVksTUFBTW5KLEtBQUtwRixTQUFTLFVBQVUsQ0FBQzhMLE9BQU94TCxRQUFRLENBQUN1RyxPQUFPUyxTQUFTbEMsS0FBS3BGLFdBQVcsQ0FBQyxDQUFDcU8sYUFBYSxDQUFDLENBQUNFLFdBQVcsdUNBQXpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ047QUFBQSxRQUFpQix1QkFBQyxTQUFNLFVBQVMsUUFBTywwS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTDtBQUFBLFdBQXI3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTY3QyxLQUFqL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4L0MsS0FBampEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOGpEO0FBQUEsTUFBUSx1QkFBQyxTQUFNLE9BQU0scUJBQW9CLFFBQVEsdUJBQUMsa0JBQWUsWUFBVyxrQkFBaUIsU0FBUyxNQUFNNUIsUUFBUSxJQUFJLEdBQUcsMkJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUYsR0FBbUIsaUNBQUMsY0FBVyxPQUFPWixVQUFVLGdCQUFlLFdBQVdBLG1CQUFTekwsUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSwwQkFBeUIsTUFBTXlMLFNBQVN6TCxLQUFLQSxNQUFNLFFBQVEsQ0FBQWdGLE1BQUtBLEVBQUVsRCxJQUFJLFNBQVM7QUFBQSxVQUM5bEUsRUFBRWlJLEtBQUssWUFBWXZRLE9BQU8sU0FBU3dRLFFBQVFBLENBQUFoRixNQUFLLGtCQUFrQkEsRUFBRStHLFVBQVUsR0FBRztBQUFBLFVBQUcsRUFBRWhDLEtBQUssUUFBUXZRLE9BQU8sV0FBV3dRLFFBQVFBLENBQUFoRixNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRWlILFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCLEVBQUc7QUFBQSxVQUFHLEVBQUVsQyxLQUFLLFNBQVN2USxPQUFPLGNBQWN3USxRQUFRQSxDQUFBaEYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUV6QyxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QixFQUFHO0FBQUEsVUFBRyxFQUFFd0gsS0FBSyxVQUFVdlEsT0FBTyxTQUFTd1EsUUFBUUEsQ0FBQWhGLE1BQUtBLEVBQUVtSCxPQUFPO0FBQUEsUUFBQyxLQUR3dEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVoZ0U7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTVYsU0FBU3pMLEtBQUtxQixRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FGNDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFMTlELEtBRms1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTk0RCxLQUY2dkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVodkQ7QUFBQSxTQUZvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRTVHO0FBQUEsSUFBYyx1QkFBQyxxQkFBa0IsV0FBV2lNLFVBQVV0TixNQUFNQSxRQUFRLElBQUksa0JBQW9DLFFBQVE0RixLQUFLOUQsTUFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RztBQUFBLElBQzlMLHVCQUFDLGNBQVcsTUFBWSxPQUFNLDJCQUEwQixTQUFTLE1BQU11SyxRQUFRLEtBQUssR0FBRyxNQUFNWCxPQUFPaE0sU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQ3FNLGNBQWMxUCxnQkFBZ0I4UCxPQUFPcEgsS0FBSyxDQUFDLElBQUksS0FBSzJHLE9BQU9oTSxTQUFTLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDclAsY0FBTWdNLE9BQU90RSxRQUFRLEVBQUVsSCxNQUFNLEVBQUUrTCxNQUFNRixZQUFZSSxPQUFPLEVBQUUsQ0FBQztBQUMzREUsZ0JBQVEsS0FBSztBQUFBLE1BQ2pCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyxxQ0FKd0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUluRSxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPWCxPQUFPOUwsU0FBUzBOLFVBQVUxTixTQUFTNE4sdUJBQXVCNU4sU0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLE1BQUUsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxrQkFBaUIsT0FBT21OLHFCQUFxQixVQUFVLENBQUEvTCxNQUFLZ00sdUJBQXVCaE0sRUFBRXNFLE9BQU9DLEtBQUssR0FBRyxVQUFVLENBQUN1SCxrQkFBa0IsWUFBVyxnRUFBN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5TjtBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLGNBQWEsUUFBTSxNQUFDLE9BQU9mLFlBQVksVUFBVSxDQUFBL0ssTUFBS2dMLFlBQVloTCxFQUFFc0UsT0FBT0MsS0FBSyxHQUFHLFVBQVUsQ0FBQ3VILG9CQUFxQlEsVUFBVW9CLGFBQWEsQ0FBQ3BCLFVBQVV0TixNQUFRK0w7QUFBQUEsd0JBQWMsQ0FBQ3VCLFVBQVV0TixNQUFNQSxLQUFLMk8sS0FBSyxDQUFBakIsYUFBWUEsU0FBUzVMLE9BQU9pSyxVQUFVLEtBQUssdUJBQUMsWUFBUyxPQUFPQSxZQUFhMEIsNEJBQWtCdkQsZ0JBQWdCc0QsdUJBQXVCa0IsWUFBWSw0QkFBNEIzQyxlQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySTtBQUFBLFVBQWF1QixVQUFVdE4sTUFBTUEsS0FBSzRDLElBQUksQ0FBQTRDLE1BQUssdUJBQUMsWUFBb0IsT0FBT0EsRUFBRTFELElBQUswRCxZQUFFMEUsZUFBdEIxRSxFQUFFMUQsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQsQ0FBVztBQUFBLGFBQXBmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc2Y7QUFBQSxRQUFZLHVCQUFDLGtCQUFlLE9BQU0sY0FBYSxhQUFhd0wsVUFBVXNCLGFBQWEsU0FBU3RCLFVBQVV1QixTQUFTLE1BQU12QixVQUFVd0IsZUFBZSxZQUFZeEIsVUFBVXlCLFlBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUs7QUFBQSxRQUFHekIsVUFBVWxMLFdBQVcsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsZ0JBQU1rTCxVQUFVMEIsdUJBQXVCMUIsVUFBVXlCLFNBQVMsSUFBSXpCLFVBQVV6RyxRQUFRO0FBQUEsUUFBSSxHQUFHLHVDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9KO0FBQUEsUUFBVSx1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsUUFBTSxNQUFDLE9BQU9vRixNQUFNLFVBQVUsQ0FBQWpMLE1BQUtrTCxRQUFRbEwsRUFBRXNFLE9BQU9DLEtBQW9CLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sVUFBUyxvQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxVQUFTLG1DQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLGFBQS9NO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBME47QUFBQSxRQUFZLHVCQUFDLGFBQVUsT0FBTSw0QkFBMkIsV0FBUyxNQUFDLFNBQVMsR0FBRyxPQUFPNEcsUUFBUSxVQUFVLENBQUFuTCxNQUFLb0wsVUFBVXBMLEVBQUVzRSxPQUFPQyxLQUFLLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEg7QUFBQSxXQUFqNkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtNkM7QUFBQSxTQUp2akQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlva0Q7QUFBQSxPQVAxakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU91a0Q7QUFDbGxEO0FBQUNnRyxJQW5EZUQsYUFBVztBQUFBLFVBQ05sUCxVQUNGTixRQUNFQSxRQUF1Q2EsY0FDM0NYLFlBQ0VBLFlBRVVHLFFBTVBKLGFBQ2FELFFBRWhCZ0IsbUJBT0lELFlBQVk7QUFBQTtBQUFBLE1BdkJuQnlPO0FBcURoQixNQUFNMkQscUJBQXFCO0FBQzNCLE1BQU1DLHVCQUF1QjtBQUM3QixTQUFTQyxrQkFBa0IsRUFBRTdCLFdBQVdSLGtCQUFrQnRKLE9BQW9GLEdBQUc7QUFBQTRMLE1BQUE7QUFDN0ksUUFBTUMsY0FBY3RULFlBQVksd0JBQXdCLEVBQUVrTixPQUFPdE0sYUFBYSxzQkFBc0IsRUFBRSxDQUFDO0FBQ3ZHLFFBQU0yUyxnQkFBZ0J2VCxZQUFZLGlDQUFpQyxFQUFFa04sT0FBT3RNLGFBQWEsK0JBQStCLEVBQUUsQ0FBQztBQUMzSCxRQUFNNFMsa0JBQWtCdlQsV0FBVyxrQ0FBa0MsQ0FBQywrQkFBK0IsQ0FBQztBQUN0RyxRQUFNLENBQUN3VCxvQkFBb0JDLHFCQUFxQixJQUFJdlYsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ3dWLFNBQVNDLFVBQVUsSUFBSXpWLFNBQXdDLFdBQVc7QUFDakYsUUFBTSxDQUFDMFYsU0FBU0MsVUFBVSxJQUFJM1YsU0FBUyxLQUFLO0FBQzVDLFFBQU02UixhQUFhdUIsVUFBVXFCLEtBQUssQ0FBQWpCLGNBQVlBLFVBQVM1TCxPQUFPME4sa0JBQWtCLElBQUlBLHFCQUFxQmxDLFVBQVUsQ0FBQyxHQUFHeEwsTUFBTTtBQUM3SCxRQUFNNEwsV0FBV0osVUFBVWhLLEtBQUssQ0FBQXdNLGNBQWFBLFVBQVVoTyxPQUFPaUssVUFBVTtBQUN4RSxRQUFNZ0UsV0FBV3JDLFVBQVVzQyxrQkFBa0I7QUFDN0MsUUFBTUMsb0JBQW9CO0FBQUEsSUFDdEIsRUFBRTFLLE9BQU8sYUFBc0IvTCxPQUFPLGFBQWEwVyxXQUFXQyxRQUFRekMsVUFBVTBDLGdCQUFnQixFQUFFO0FBQUEsSUFDbEcsRUFBRTdLLE9BQU8sT0FBZ0IvTCxPQUFPLE9BQU8wVyxXQUFXQyxRQUFRekMsVUFBVTJDLFNBQVMsQ0FBQ04sU0FBU3JGLFNBQVMsT0FBTyxDQUFDLEVBQUU7QUFBQSxJQUMxRyxFQUFFbkYsT0FBTyxTQUFrQi9MLE9BQU8sU0FBUzBXLFdBQVdDLFFBQVF6QyxVQUFVcEUsU0FBUyxDQUFDeUcsU0FBU3JGLFNBQVMsT0FBTyxDQUFDLEVBQUU7QUFBQSxFQUFDLEVBQ2pIRSxPQUFPLENBQUEwRixTQUFRQSxLQUFLSixTQUFTO0FBQy9CLFFBQU1LLGtCQUFrQk4sa0JBQWtCM00sS0FBSyxDQUFBZ04sU0FBUUEsS0FBSy9LLFVBQVVtSyxPQUFPLEdBQUduSyxTQUFTMEssa0JBQWtCLENBQUMsR0FBRzFLLFNBQVNtSztBQUN4SCxRQUFNYyxxQkFBcUJQLGtCQUFrQnRCLEtBQUssQ0FBQTJCLFNBQVFBLEtBQUsvSyxVQUFVZ0wsZUFBZTtBQUN4RixRQUFNRSx3QkFBd0IsWUFBWTtBQUN0QyxRQUFJLENBQUMxRSxjQUFjLENBQUNlLG9CQUFvQixDQUFDMEQsbUJBQW9CO0FBQzdELFFBQUk7QUFDQSxZQUFNakIsZ0JBQWdCbkksUUFBUSxFQUFFQyxNQUFNLEVBQUUwRSxXQUFXLEdBQUc3TCxNQUFNLEVBQUV3USxTQUFTLGFBQWFoQixTQUFTYSxpQkFBaUJJLFNBQVN6QixzQkFBc0IwQixnQkFBZ0IzQixtQkFBbUIsRUFBRSxDQUFDO0FBQ25MWSxpQkFBVyxJQUFJO0FBQ2YsWUFBTWdCLFFBQVFDLElBQUksQ0FBQ3hCLGNBQWN6SSxRQUFRLEdBQUd3SSxZQUFZeEksUUFBUSxDQUFDLENBQUM7QUFBQSxJQUN0RSxRQUNNO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFDQSxTQUFPLHVCQUFDLFNBQU0sT0FBTSxxQ0FBb0MsV0FBVSxXQUFVLFVBQVMsU0FDakYsaUNBQUMsY0FDRztBQUFBLDJCQUFDLFNBQU0sVUFBUyxRQUFPLDhPQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFQO0FBQUEsSUFDcFBpRyxtQkFBbUIsbUNBQ2hCO0FBQUEsNkJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxjQUFhLE9BQU9mLFlBQVksVUFBVSxDQUFBM0csVUFBUztBQUFFcUssOEJBQXNCckssTUFBTUUsT0FBT0MsS0FBSztBQUFHc0ssbUJBQVcsS0FBSztBQUFBLE1BQUcsR0FBRyxVQUFVLENBQUNuQyxVQUNwSkosb0JBQVUxSyxJQUFJLENBQUEwTixTQUFRLHVCQUFDLFlBQXVCLE9BQU9BLEtBQUt4TyxJQUFLd08sZUFBS3BHLGVBQS9Cb0csS0FBS3hPLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQsQ0FBVyxLQURoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0scUJBQW9CLE9BQU95TyxpQkFBaUIsVUFBVSxDQUFBbkwsVUFBUztBQUFFdUssbUJBQVd2SyxNQUFNRSxPQUFPQyxLQUF1QjtBQUFHc0ssbUJBQVcsS0FBSztBQUFBLE1BQUcsR0FBRyxVQUFVLENBQUNJLGtCQUFrQjVOLFFBQ3pMNE4sNEJBQWtCck4sSUFBSSxDQUFBME4sU0FBUSx1QkFBQyxZQUEwQixPQUFPQSxLQUFLL0ssT0FBUStLLGVBQUs5VyxTQUFyQzhXLEtBQUsvSyxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBELENBQVcsS0FEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLE9BQU8sYUFBYTBKLGtCQUFrQixJQUFLQyxrQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQzNFLENBQUNlLGtCQUFrQjVOLFVBQVUsdUJBQUMsU0FBTSxVQUFTLFdBQVUsc0VBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUM5Ryx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFRLGFBQVksTUFBTWtOLGdCQUFnQjdQLFNBQVMsVUFBVSxDQUFDcU0sY0FBYyxDQUFDeUUsc0JBQXNCLENBQUMxRCxrQkFBa0IsU0FBUyxNQUFNLEtBQUsyRCxzQkFBc0IsR0FBRyx3Q0FBL007QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1TztBQUFBLE1BQ3ZPLHVCQUFDLGVBQVksT0FBT2xCLGdCQUFnQjNQLFNBQVN5UCxZQUFZelAsU0FBUzBQLGNBQWMxUCxTQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNGO0FBQUEsTUFDckZnUSxXQUFXLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBUywrRkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1SDtBQUFBLFNBWG5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZcEIsSUFBTSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxpR0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRztBQUFBLElBQ2pILHVCQUFDLGNBQVcsTUFBSyxTQUFRLGNBQVcsNEJBQ2hDO0FBQUEsNkJBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxNQUFLLHdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMsY0FBVyxPQUFPUCxhQUFhLGdCQUFlLFdBQVdBLHNCQUFZclAsUUFBUSxtQ0FDMUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sOEJBQTZCLE1BQU1xUCxZQUFZclAsS0FBS0EsTUFBTSxRQUFRLENBQUErUSxXQUFVQSxPQUFPalAsSUFBSSxTQUFTO0FBQUEsVUFDN0csRUFBRWlJLEtBQUssWUFBWXZRLE9BQU8sU0FBU3dRLFFBQVFBLENBQUErRyxXQUFVLGtCQUFrQkEsT0FBT2hGLFVBQVUsR0FBRztBQUFBLFVBQzNGLEVBQUVoQyxLQUFLLFdBQVd2USxPQUFPLFlBQVl3USxRQUFRQSxDQUFBK0csV0FBVXRYLGNBQWNzWCxPQUFPTCxPQUFPLEVBQUU7QUFBQSxVQUNyRixFQUFFM0csS0FBSyxXQUFXdlEsT0FBTyxRQUFRd1EsUUFBUUEsQ0FBQStHLFdBQVV0WCxjQUFjc1gsT0FBT3JCLE9BQU8sRUFBRTtBQUFBLFVBQ2pGLEVBQUUzRixLQUFLLFVBQVV2USxPQUFPLGNBQWN3USxRQUFRQSxDQUFBK0csV0FBVSx1QkFBQyxVQUFPLE9BQU9BLE9BQU94TyxRQUFRLFFBQU8sYUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEMsRUFBRztBQUFBLFVBQ3pHLEVBQUV3SCxLQUFLLFdBQVd2USxPQUFPLGFBQWF3USxRQUFRQSxDQUFBK0csV0FBVUEsT0FBT3pLLFFBQVE7QUFBQSxVQUN2RSxFQUFFeUQsS0FBSyxZQUFZdlEsT0FBTyx1QkFBdUJ3USxRQUFRQSxDQUFBK0csV0FBVTtBQUFFLGtCQUFNQyxTQUFTRCxPQUFPRSxRQUFRQyxHQUFHLEVBQUU7QUFBRyxtQkFBT0YsU0FBUyxHQUFHdlgsY0FBY3VYLE9BQU83SSxRQUFRLFNBQVMsQ0FBQyxNQUFNNkksT0FBT0csWUFBWSxNQUFNSCxPQUFPSSxxQkFBcUIsR0FBRyxLQUFLO0FBQUEsVUFBVyxFQUFFO0FBQUEsUUFBQyxLQU4xUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0U7QUFBQSxRQUNGLHVCQUFDLFNBQU0sTUFBTS9CLFlBQVlyUCxLQUFLcUIsUUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFdBVHVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVOUUsS0FWQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUk7QUFBQSxTQVpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyw2QkFDaEM7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUsseUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUNqRSx1QkFBQyxjQUFXLE9BQU9pTyxlQUFlLGdCQUFlLFdBQVdBLHdCQUFjdFAsUUFBUSxtQ0FDOUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sNkJBQTRCLE1BQU1zUCxjQUFjdFAsS0FBS0EsTUFBTSxRQUFRLENBQUFxUixjQUFhQSxVQUFVdlAsSUFBSSxTQUFTO0FBQUEsVUFDcEgsRUFBRWlJLEtBQUssWUFBWXZRLE9BQU8sU0FBU3dRLFFBQVFBLENBQUFxSCxjQUFhLGtCQUFrQkEsVUFBVXRGLFVBQVUsR0FBRztBQUFBLFVBQ2pHLEVBQUVoQyxLQUFLLFdBQVd2USxPQUFPLFlBQVl3USxRQUFRQSxDQUFBcUgsY0FBYTVYLGNBQWM0WCxVQUFVWCxPQUFPLEVBQUU7QUFBQSxVQUMzRixFQUFFM0csS0FBSyxXQUFXdlEsT0FBTyxRQUFRd1EsUUFBUUEsQ0FBQXFILGNBQWE1WCxjQUFjNFgsVUFBVTNCLE9BQU8sRUFBRTtBQUFBLFVBQ3ZGLEVBQUUzRixLQUFLLFVBQVV2USxPQUFPLFdBQVd3USxRQUFRQSxDQUFBcUgsY0FBYUEsVUFBVWxKLFdBQVcsYUFBYSxvQkFBb0IscUJBQXFCO0FBQUEsVUFDbkksRUFBRTRCLEtBQUssVUFBVXZRLE9BQU8sY0FBY3dRLFFBQVFBLENBQUFxSCxjQUFhLHVCQUFDLFVBQU8sT0FBT0EsVUFBVTlPLFFBQVEsUUFBTyxhQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRCxFQUFHO0FBQUEsVUFDL0csRUFBRXdILEtBQUssV0FBV3ZRLE9BQU8sV0FBV3dRLFFBQVFBLENBQUFxSCxjQUFhOVUsU0FBUzhVLFVBQVVDLFdBQVcsa0JBQWtCLEVBQUU7QUFBQSxRQUFDLEtBTmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPRTtBQUFBLFFBQ0YsdUJBQUMsU0FBTSxNQUFNaEMsY0FBY3RQLEtBQUtxQixRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsV0FUeUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVsRixLQVZBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVSTtBQUFBLFNBWlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFDQ3lMLG9CQUFvQix1QkFBQyxVQUFPLFdBQVd6UyxZQUFZLElBQUksTUFBTW1KLE1BQU0sY0FBYyxNQUFLLFNBQVEsSUFBSSxFQUFFK04sV0FBVyxhQUFhLEdBQUcsa0NBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkg7QUFBQSxPQTNDdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQSxLQTdDRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENQO0FBQ0o7QUFBQ25DLElBekVRRCxtQkFBaUI7QUFBQSxVQUNGcFQsYUFBNkNZLGNBQzNDWixhQUFzRFksY0FDcERYLFVBQVU7QUFBQTtBQUFBLE1BSDdCbVQ7QUEwRVQsU0FBU3FDLHNCQUFzQmpNLE9BQW1EO0FBQzlFLE1BQUk7QUFBRXJKLGlCQUF5Qyw4QkFBOEJxSixLQUFLO0FBQUcsV0FBT0E7QUFBQUEsRUFBTyxRQUM3RjtBQUFFLFdBQU87QUFBQSxFQUFNO0FBQ3pCO0FBQ08sZ0JBQVNrTSwwQkFBMEI7QUFBQUMsTUFBQTtBQUN0QyxRQUFNLENBQUNqUyxNQUFNLElBQUkvRSxnQkFBZ0I7QUFDakMsUUFBTWlHLFlBQVdwRyxZQUFZO0FBQzdCLFFBQU11SixXQUFXdEosWUFBWTtBQUM3QixRQUFNbVgsUUFBUWxTLE9BQU9XLElBQUksT0FBTyxLQUFLO0FBQ3JDLFFBQU0sQ0FBQ2lSLFdBQVdPLFlBQVksSUFBSTFYLFNBQTRDLE1BQU1zWCxzQkFBdUI3USxVQUFTa1IsT0FBaURDLGdCQUFnQixDQUFDO0FBQ3RMLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJOVgsU0FBcUMsSUFBSTtBQUNqRixRQUFNLENBQUMwRixPQUFPQyxRQUFRLElBQUkzRixTQUF1QixJQUFJO0FBQ3JELFFBQU0sQ0FBQ3dGLFNBQVNDLFVBQVUsSUFBSXpGLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUMrWCxtQkFBbUJDLG9CQUFvQixJQUFJaFksU0FBc0MsSUFBSTtBQUM1RixRQUFNaVksYUFBYWxZLE9BQU9tWSxPQUFPQyxXQUFXLENBQUM7QUFDN0MsUUFBTUMsaUJBQWlCclksT0FBK0QsSUFBSTtBQUMxRixRQUFNc1ksV0FBVyxZQUFZO0FBQ3pCLFFBQUksQ0FBQ1osU0FBU2pTLFFBQVM7QUFDdkJDLGVBQVcsSUFBSTtBQUFHRSxhQUFTLElBQUk7QUFDL0IsUUFBSTtBQUNBLFlBQU1FLE9BQU8sTUFBTW5FLFFBQVEsY0FBYztBQUN6Q0MsbUJBQWFrRSxLQUFLQyxLQUFLQyxTQUFTO0FBQ2hDLFlBQU1rSCxTQUFTLE1BQU12TCxRQUFRLDRCQUE0QixFQUFFc0UsTUFBTSxFQUFFeVIsTUFBTSxHQUFHYSxnQkFBZ0JMLFdBQVd4TixRQUFRLENBQUM7QUFDaEhpTixtQkFBYXpLLE9BQU9uSCxJQUFJO0FBQ3hCOEQsZUFBUyxvQkFBb0IsRUFBRTJPLFNBQVMsTUFBTVosT0FBTyxFQUFFQyxrQkFBa0IzSyxPQUFPbkgsS0FBSyxFQUFFLENBQUM7QUFBQSxJQUM1RixTQUNPbU0sUUFBUTtBQUFFdE0sZUFBU3NNLGtCQUFrQnZMLFFBQVF1TCxTQUFTLElBQUl2TCxNQUFNLCtCQUErQixDQUFDO0FBQUEsSUFBRyxVQUFDO0FBQ2pHakIsaUJBQVcsS0FBSztBQUFBLElBQUc7QUFBQSxFQUNqQztBQUNBLFFBQU0rUyxVQUFVLE9BQU9DLGFBQW1DO0FBQ3RELFFBQUksQ0FBQ3RCLGFBQWEzUixXQUFXcVMsZ0JBQWlCRSxxQkFBcUJBLHNCQUFzQlUsU0FBVztBQUNwRyxVQUFNQyxTQUFTTixlQUFlM04sU0FBU2dPLGFBQWFBLFdBQVdMLGVBQWUzTixVQUFVLEVBQUVnTyxVQUFVNUksS0FBS3FJLE9BQU9DLFdBQVcsRUFBRTtBQUM3SEMsbUJBQWUzTixVQUFVaU87QUFDekJWLHlCQUFxQlMsUUFBUTtBQUFHaFQsZUFBVyxJQUFJO0FBQUdFLGFBQVMsSUFBSTtBQUMvRCxRQUFJO0FBQ0EsWUFBTXNILFNBQVMsTUFBTXZMLFFBQVEsMkJBQTJCLEVBQUVzRSxNQUFNLEVBQUUyUyxvQkFBb0J4QixVQUFVd0Isb0JBQW9CRixVQUFVL0IsZ0JBQWdCUyxVQUFVVCxlQUFlLEdBQUc0QixnQkFBZ0JJLE9BQU83SSxJQUFJLENBQUM7QUFDdE1pSSxzQkFBZ0I3SyxPQUFPbkgsSUFBSTtBQUFBLElBQy9CLFNBQ09tTSxRQUFRO0FBQUV0TSxlQUFTc00sa0JBQWtCdkwsUUFBUXVMLFNBQVMsSUFBSXZMLE1BQU0sd0RBQXdELENBQUM7QUFBQSxJQUFHLFVBQUM7QUFDMUhqQixpQkFBVyxLQUFLO0FBQUEsSUFBRztBQUFBLEVBQ2pDO0FBQ0EsUUFBTW1ULGFBQWF6QixXQUFXbEosV0FBVztBQUN6QyxRQUFNNEssc0JBQXNCaEIsZUFDdEJBLGFBQWFpQixrQkFBa0IsY0FDM0IscUdBQ0FqQixhQUFheFAsV0FBVyxhQUNwQixrRkFDQSxrQ0FDUjtBQUNOLFNBQU8sdUJBQUMsT0FBSSxXQUFVLFFBQU8sSUFBRyxnQkFBZSxVQUFVLElBQUksSUFBSSxDQUFDdkYsU0FBU21CLE1BQU1xRSxtQkFBbUIsRUFBRTlELFVBQVUsS0FBSytELElBQUksUUFBUW5FLFNBQVMsT0FBTyxDQUFDLEdBQzlJO0FBQUEsMkJBQUMsY0FBVyxPQUFNLCtCQUE4QixVQUFTLG9FQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlIO0FBQUEsSUFDekgsdUJBQUMsU0FBTSxPQUFPK1MsWUFBWXlCLGFBQWEsNkJBQTZCLGdDQUFnQyxxQkFBcUIsVUFBUyxTQUM5SCxpQ0FBQyxjQUNHO0FBQUEsNkJBQUMsU0FBTSxVQUFTLFFBQU8sZ0hBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUg7QUFBQSxNQUN0SGxULFNBQVMsdUJBQUMsZUFBWSxTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxNQUNuQyxDQUFDeVIsYUFBYU0sU0FBUyxtQ0FDcEI7QUFBQSwrQkFBQyxjQUFXLE9BQU0sa0JBQWlCLDhIQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlKO0FBQUEsUUFDakosdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNLEtBQUtZLFNBQVMsR0FBRyxVQUFVN1MsU0FBVUEsb0JBQVUsbUJBQW1CRSxRQUFRLHFCQUFxQiwwQkFBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSztBQUFBLFdBRjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHeEI7QUFBQSxNQUNDLENBQUN5UixhQUFhLENBQUNNLFNBQVMsdUJBQUMsU0FBTSxVQUFTLFdBQVUseUZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUc7QUFBQSxNQUMzSE4sYUFBYSxtQ0FDVjtBQUFBLCtCQUFDLGNBQVcsT0FBTSxZQUFXLHlCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFDdEMsdUJBQUMsY0FBVyxPQUFNLFFBQVE1WCx3QkFBYzRYLFVBQVUzQixPQUFPLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxjQUFXLE9BQU0sbUJBQW1CMkIsb0JBQVVWLFdBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQ7QUFBQSxRQUN2RCx1QkFBQyxjQUFXLE9BQU0sc0JBQXFCO0FBQUE7QUFBQSxVQUFFVSxVQUFVVDtBQUFBQSxhQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDbEUsdUJBQUMsY0FBVyxPQUFNLFdBQVdyVSxtQkFBUzhVLFVBQVVDLFdBQVcsa0JBQWtCLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUM5RVMsZUFBZSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVVnQixpQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RCxJQUFXLHVCQUFDLGVBQ3JGO0FBQUEsaUNBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNLEtBQUtMLFFBQVEsUUFBUSxHQUFHLFVBQVVoVCxXQUFXdVMsc0JBQXNCLFdBQVl2UyxxQkFBV3VTLHNCQUFzQixXQUFXLG1CQUFtQkEsc0JBQXNCLFdBQVcsMEJBQTBCYSxhQUFhLDZCQUE2QiwyQkFBOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc1Q7QUFBQSxVQUN0VCx1QkFBQyxVQUFPLFNBQVEsWUFBVyxTQUFTLE1BQU0sS0FBS0osUUFBUSxTQUFTLEdBQUcsVUFBVWhULFdBQVd1UyxzQkFBc0IsVUFBV3ZTLHFCQUFXdVMsc0JBQXNCLFlBQVksbUJBQW1CQSxzQkFBc0IsWUFBWSwwQkFBMEJhLGFBQWEsd0JBQXdCLDRCQUExUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtVDtBQUFBLGFBRi9OO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHeEY7QUFBQSxXQVRVO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVZDtBQUFBLE1BQ0NyUyxZQUFZLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCLCtJQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9MO0FBQUEsU0FuQnJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkEsS0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLE9BeEJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QlA7QUFDSjtBQUFDaVIsSUF2RWVELHlCQUF1QjtBQUFBLFVBQ2xCL1csaUJBQ0FILGFBQ0FDLFdBQVc7QUFBQTtBQUFBLE1BSGhCaVg7QUF3RVQsZ0JBQVN3QixVQUFVO0FBQUFDLE1BQUE7QUFDdEIsUUFBTSxFQUFFQyxRQUFRLEdBQUcsSUFBSTFZLFVBQVU7QUFDakMsUUFBTSxFQUFFbUwsS0FBSyxJQUFJeEosU0FBUztBQUMxQixRQUFNZ0UsTUFBTXRFLE9BQU8sVUFBVSxFQUFFdUwsTUFBTSxFQUFFOEwsTUFBTSxFQUFFLENBQUM7QUFDaEQsUUFBTUMsTUFBTWhULElBQUlKLE1BQU1BO0FBQ3RCLFFBQU1xVCxlQUFlRCxLQUFLRSxjQUFjNVcsdUJBQXVCMFcsSUFBSUUsYUFBYTNTLFNBQVNELFFBQVFELFFBQVEsSUFBSTtBQUM3RyxRQUFNOFMsWUFBWUgsS0FBSzdRO0FBQ3ZCLFFBQU0sRUFBRXNFLFFBQVEsSUFBSXpHO0FBQ3BCcEcsWUFBVSxNQUFNO0FBQUUsUUFBSSxDQUFDdVosYUFBYSxDQUFDLENBQUMsVUFBVSxTQUFTLEVBQUU3SSxTQUFTNkksU0FBUztBQUN6RTtBQUFRLFVBQU1wRyxRQUFRcUcsWUFBWSxNQUFNLEtBQUszTSxRQUFRLEdBQUcsR0FBSTtBQUFHLFdBQU8sTUFBTTRNLGNBQWN0RyxLQUFLO0FBQUEsRUFBRyxHQUFHLENBQUNvRyxXQUFXMU0sT0FBTyxDQUFDO0FBQzdILFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU8sYUFBYXNNLEtBQUssSUFBSSxVQUFTLHlFQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVIO0FBQUEsSUFBRSx1QkFBQyxjQUFXLE9BQU8vUyxLQUFLLGdCQUFlLFdBQVdnVCxpQkFBTyx1QkFBQyxTQUFNLE9BQU0saUJBQWdCLFVBQVMsU0FBUSxpQ0FBQyxjQUFZO0FBQUEsNkJBQUMsVUFBTyxPQUFPQSxJQUFJN1EsVUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQjtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFNLFFBQVE5SSx3QkFBYzJaLElBQUluSCxJQUFJLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxXQUFXbUg7QUFBQUEsWUFBSU07QUFBQUEsUUFBVTtBQUFBLFFBQUlOLElBQUlPLFNBQVM7QUFBQSxXQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sT0FBT1AsY0FBSVEsY0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFlBQVlyWCxtQkFBUzZXLElBQUlTLFdBQVdqTyxLQUFLeEMsUUFBUSxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFBY2dRLElBQUlVLFVBQVV6UixTQUFTLEtBQUssdUJBQUMsYUFBVSxPQUFNLHFCQUFvQixNQUFNK1EsSUFBSVUsV0FBVyxRQUFRLENBQUE5UyxNQUFLLEdBQUdBLEVBQUUrUyxHQUFHLElBQUkvUyxFQUFFZ1QsS0FBSyxJQUFJaFQsRUFBRWlULElBQUksSUFBSSxTQUFTLENBQUMsRUFBRWxLLEtBQUssT0FBT3ZRLE9BQU8sUUFBUXdRLFFBQVFBLENBQUFoSixNQUFLQSxFQUFFK1MsSUFBSSxHQUFHLEVBQUVoSyxLQUFLLFNBQVN2USxPQUFPLFVBQVV3USxRQUFRQSxDQUFBaEosTUFBS0EsRUFBRWdULE1BQU0sR0FBRyxFQUFFakssS0FBSyxXQUFXdlEsT0FBTyxPQUFPd1EsUUFBUUEsQ0FBQWhKLE1BQUtBLEVBQUUyUCxRQUFRLENBQUMsS0FBdFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3UjtBQUFBLE1BQUcsdUJBQUMsVUFBTyxTQUFTLE1BQU0sS0FBS3ZRLElBQUl5RyxRQUFRLEdBQUcsU0FBUSxZQUFXLDRCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFBVXVNLElBQUlFLGVBQWUsQ0FBQyxhQUFhLFNBQVMsRUFBRTVJLFNBQVMwSSxJQUFJN1EsTUFBTSxLQUFLOFEsZ0JBQWdCLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVMsTUFBTXhTLE9BQU9nSixLQUFLd0osY0FBYyxVQUFVLHFCQUFxQixHQUFHLCtCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNIO0FBQUEsTUFBV0QsSUFBSUUsZUFBZSxDQUFDLGFBQWEsU0FBUyxFQUFFNUksU0FBUzBJLElBQUk3USxNQUFNLEtBQUssQ0FBQzhRLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSx1RUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQVVELElBQUk3USxXQUFXLDJCQUEyQix1QkFBQyxhQUFVLElBQUksTUFBTXFELEtBQUs5RCxFQUFFLFlBQVlzUixJQUFJdFIsRUFBRSxJQUFJLG9DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsU0FBcnNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa3RDLEtBQWh3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZ3QyxLQUF0MEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErMEM7QUFBQSxPQUExOEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1OUM7QUFDbCtDO0FBQUNvUixJQVhlRCxTQUFPO0FBQUEsVUFDSXhZLFdBQ04yQixVQUNMTixNQUFNO0FBQUE7QUFBQSxPQUhObVg7QUFBTyxJQUFBN1QsSUFBQThVLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFoTSxLQUFBaU0sS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUM7QUFBQSxhQUFBdlYsSUFBQTtBQUFBLGFBQUE4VSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQWhNLEtBQUE7QUFBQSxhQUFBaU0sS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxNQUFBIiwibmFtZXMiOlsibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwiQWN0aW9uR3JvdXAiLCJGaWVsZEdyb3VwIiwiRm9ybUZpZWxkcyIsIlBhZ2VTZWN0aW9ucyIsIlNlY3Rpb25HcmlkIiwiU3VyZmFjZUNvbnRlbnQiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInZpc3VhbFN4IiwiTGluayIsIlJvdXRlckxpbmsiLCJOYXZpZ2F0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ1c2VTZWFyY2hQYXJhbXMiLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwiQWxlcnQiLCJBdmF0YXIiLCJCb3giLCJCdXR0b24iLCJDaGVja2JveCIsIkZvcm1Db250cm9sTGFiZWwiLCJNZW51SXRlbSIsIlBhcGVyIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwiU21hcnRUb3lSb3VuZGVkIiwiQXJyb3dGb3J3YXJkUm91bmRlZCIsInBlcm1pc3Npb25DYXRhbG9nIiwiY29sb3JzIiwicmVxdWVzdCIsInNldENzcmZUb2tlbiIsInVzZUFwaSIsInVzZVBhZ2VkQXBpIiwidXNlQ29tbWFuZCIsIkFwaUVycm9yIiwiYXNzZXJ0U2NoZW1hIiwidXNlQ2FuIiwidXNlU2NvcGUiLCJjb2RlUG9pbnRMZW5ndGgiLCJsaW1pdENvZGVQb2ludHMiLCJkYXRlVGltZSIsInNhZmVJbnRlcm5hbFBhdGgiLCJpc1ZhbGlkVGltZVpvbmUiLCJhdXRob3JpemVkRG93bmxvYWRIcmVmIiwidXNlTGlzdFF1ZXJ5IiwibWFya0RyYWZ0Q2xlYW4iLCJ1c2VEcmFmdEZvcm0iLCJ1c2VWZXJzaW9uZWREcmFmdCIsIkRyYWZ0Q29uZmxpY3QiLCJsYXlvdXRTeCIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIlF1ZXJ5U3RhdGUiLCJEYXRhVGFibGUiLCJUb29sYmFyIiwiUGFnZXIiLCJTdGF0dXMiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkNvbmZpcm1EaWFsb2ciLCJSb3V0ZUxpbmsiLCJEZXRhaWxMaW5lIiwiTG9va3VwTG9hZE1vcmUiLCJFbXB0eSIsInVzZVNlc3Npb24iLCJBdXRoQ2FyZCIsImNoaWxkcmVuIiwic2hlbGwiLCJjZW50ZXJlZEZhbGxiYWNrIiwiYmdjb2xvciIsIm91dGxpbmUiLCJhdXRoIiwic3VyZmFjZUluc2V0Iiwid2lkdGgiLCJtYXhXaWR0aCIsImJvcmRlclJhZGl1cyIsInJhZGl1cyIsImhlcm8iLCJicmFuZE1hcmtHYXAiLCJjb2xvciIsIm9uQWNjZW50IiwidHlwb2dyYXBoeSIsImZvbnRXZWlnaHQiLCJleHRyYUJvbGQiLCJfYyIsIkxvZ2luUGFnZSIsIl9zIiwic2Vzc2lvbiIsImxvYWRpbmciLCJwYXJhbXMiLCJwZW5kaW5nIiwic2V0UGVuZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJsb2dpbiIsImNzcmYiLCJkYXRhIiwiY3NyZlRva2VuIiwiYm9keSIsInJldHVyblRvIiwiZ2V0IiwidXJsIiwiVVJMIiwiYXV0aG9yaXphdGlvblVybCIsInByb3RvY29sIiwiX19NT0NLX18iLCJvcmlnaW4iLCJsb2NhdGlvbiIsIkVycm9yIiwid2luZG93IiwiYXNzaWduIiwiaHJlZiIsImUiLCJicmFuZFRpdGxlR2FwIiwicGFnZUhlYWRlciIsInRpdGxlRGVzY3JpcHRpb25HYXAiLCJhZnRlckdhcCIsInBhZ2UiLCJzZWN0aW9uQmVmb3JlIiwiZGlzcGxheSIsIldvcmtzcGFjZXNQYWdlIiwiX3MyIiwic2Vzc2lvbkVycm9yIiwic2hvcHMiLCJxdWVyeUtleSIsInVzZXIiLCJpZCIsInF1ZXJ5Rm4iLCJzaWduYWwiLCJlbmFibGVkIiwicmV0cnkiLCJpc0VtcHR5IiwiaXNFcnJvciIsImxlbmd0aCIsImNyZWF0ZVNob3BCdXR0b24iLCJzdGF0dXMiLCJwYWdlRmFsbGJhY2tJbnNldCIsIm14IiwieHMiLCJtZCIsIm1hcCIsInMiLCJzdXJmYWNlIiwiaW5zZXQiLCJsYXJnZSIsInNlbGVjdGVkIiwibmFtZSIsImN1cnJlbmN5IiwidGltZXpvbmUiLCJtZW1iZXJzaGlwcyIsImZpbmQiLCJtIiwic2hvcElkIiwicm9sZXMiLCJyb2xlIiwiam9pbiIsIk9uYm9hcmRpbmdQYWdlIiwiX3MzIiwibmF2aWdhdGUiLCJyZWZyZXNoIiwiY2FjaGUiLCJzZXROYW1lIiwic2V0Q3VycmVuY3kiLCJzZXRUaW1lem9uZSIsInRpbWV6b25lVG91Y2hlZCIsInNldFRpbWV6b25lVG91Y2hlZCIsInN1Ym1pdHRlZCIsInNldFN1Ym1pdHRlZCIsImZvcm1FbGVtZW50IiwiYmFzZWxpbmUiLCJtb3VudGVkIiwiY3VycmVudCIsImJpbmREcmFmdCIsInRpbWV6b25lRXJyb3IiLCJzYXZlIiwidHJpbSIsInIiLCJsb2NhbGUiLCJpbnZhbGlkYXRlUXVlcmllcyIsImVsZW1lbnQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJjIiwiU2hvcFNldHRpbmdzUGFnZSIsIl9zNCIsInNjb3BlIiwic2hvcCIsImNhbk1hbmFnZVNob3AiLCJ1cGRhdGUiLCJzZXRMb2NhbGUiLCJzYXZlZCIsInNldFNhdmVkIiwic2V0dGluZ3NTdWJtaXR0ZWQiLCJzZXRTZXR0aW5nc1N1Ym1pdHRlZCIsImxhdGVzdFNob3AiLCJjdXJyZW50U2hvcCIsInZlcnNpb24iLCJlZGl0b3IiLCJpZGVudGl0eSIsInNvdXJjZSIsInZhbHVlcyIsImRyYWZ0IiwiYXBwbHkiLCJyZWZldGNoIiwidGhyb3dPbkVycm9yIiwiZm9ybVJlZiIsImRpcnR5IiwicHJlcGFyZWQiLCJwcmVwYXJlIiwicmVzdWx0IiwiZXhlY3V0ZSIsInBhdGgiLCJwYXRjaCIsInNldFF1ZXJ5RGF0YSIsIm1lbWJlcnNoaXAiLCJwZXJtaXNzaW9uVmVyc2lvbiIsImNvbW1pdHRlZCIsImZhaWxlZCIsInNtIiwiZmxleCIsIm1pbldpZHRoIiwiY29tcGFjdENvbnRlbnRHYXAiLCJTZXR1cENoZWNrbGlzdEl0ZW0iLCJ0aXRsZSIsInRvIiwiYWN0aW9uIiwic3Ryb25nIiwiX2M2Iiwicm9sZUxhYmVscyIsIm93bmVyIiwibWFuYWdlciIsInNhbGVzIiwid2FyZWhvdXNlIiwiYWNjb3VudGFudCIsImJvdF9hZG1pbiIsInZpZXdlciIsIlRlYW1QYWdlIiwiX3M1IiwibGlzdCIsInF1ZXJ5IiwiaW52aXRlIiwicmV2b2tlIiwiZWRpdCIsInNldEVkaXQiLCJlbWFpbCIsInNldEVtYWlsIiwic2V0Um9sZXMiLCJyZW1vdmUiLCJzZXRSZW1vdmUiLCJzYXZlZE1lc3NhZ2UiLCJzZXRTYXZlZE1lc3NhZ2UiLCJvcGVuIiwibm90aWNlIiwia2V5IiwicmVuZGVyIiwidXNlcklkIiwiZGlzcGxheU5hbWUiLCJwZXJtaXNzaW9ucyIsInVuZGVmaW5lZCIsInRlc3QiLCJtZW1iZXJJZCIsIk9iamVjdCIsImtleXMiLCJyb2xlUHJlc2V0cyIsImluY2x1ZGVzIiwiY2hlY2tlZCIsImZpbHRlciIsIkF1ZGl0UGFnZSIsIl9zNiIsImEiLCJvY2N1cnJlZEF0IiwiYWN0b3JJZCIsInJlc291cmNlIiwidHlwZSIsInN1bW1hcnkiLCJyZXF1ZXN0SWQiLCJQcml2YWN5UGFnZSIsIl9zNyIsInBvbGljeSIsInJlcXVlc3RzIiwiY3JlYXRlIiwiZGF5cyIsInNldERheXMiLCJub3RlIiwic2V0Tm90ZSIsImN1c3RvbWVySWQiLCJzZXRDdXN0b21lciIsImtpbmQiLCJzZXRLaW5kIiwicmVhc29uIiwic2V0UmVhc29uIiwic2V0T3BlbiIsImRheXNUb3VjaGVkIiwic2V0RGF5c1RvdWNoZWQiLCJub3RlVG91Y2hlZCIsInNldE5vdGVUb3VjaGVkIiwicG9saWN5U3VibWl0dGVkIiwic2V0UG9saWN5U3VibWl0dGVkIiwicG9saWN5U2F2ZWQiLCJzZXRQb2xpY3lTYXZlZCIsImNhblJlYWRDdXN0b21lcnMiLCJjdXN0b21lclNlYXJjaElucHV0Iiwic2V0Q3VzdG9tZXJTZWFyY2hJbnB1dCIsImN1c3RvbWVyU2VhcmNoIiwic2V0Q3VzdG9tZXJTZWFyY2giLCJ0aW1lciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJjdXN0b21lcnMiLCJxIiwic2VsZWN0ZWRDdXN0b21lckRldGFpbCIsInNlbGVjdGVkQ3VzdG9tZXIiLCJjdXN0b21lciIsImNoYXRSZXRlbnRpb25EYXlzIiwidG9TdHJpbmciLCJqdXJpc2RpY3Rpb25Ob3RlIiwicG9saWN5Rm9ybSIsImRheXNFcnJvciIsIk51bWJlciIsIm5vdGVFcnJvciIsInNob3dEYXlzRXJyb3IiLCJzaG93Tm90ZUVycm9yIiwic2F2ZVBvbGljeSIsImNsZWFuIiwibGciLCJtaW4iLCJtYXgiLCJzdGVwIiwiaXNQZW5kaW5nIiwic29tZSIsImxvYWRlZENvdW50IiwiaGFzTW9yZSIsImlzTG9hZGluZ01vcmUiLCJsb2FkTW9yZSIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwiY29uc2VudENvcHlWZXJzaW9uIiwiY29uc2VudFJlY29uZmlybUNvcHkiLCJDb25zZW50TWFuYWdlbWVudCIsIl9zOCIsImNvbnNlbnRMaXN0IiwiY2hhbGxlbmdlTGlzdCIsImNyZWF0ZUNoYWxsZW5nZSIsInNlbGVjdGVkQ3VzdG9tZXJJZCIsInNldFNlbGVjdGVkQ3VzdG9tZXJJZCIsImNoYW5uZWwiLCJzZXRDaGFubmVsIiwiY3JlYXRlZCIsInNldENyZWF0ZWQiLCJjYW5kaWRhdGUiLCJyZWRhY3RlZCIsInJlZGFjdGVkRmllbGRzIiwiYXZhaWxhYmxlQ2hhbm5lbHMiLCJhdmFpbGFibGUiLCJCb29sZWFuIiwiZXh0ZXJuYWxJZGVudGl0eSIsInBob25lIiwiaXRlbSIsInNlbGVjdGVkQ2hhbm5lbCIsImNoYW5uZWxJc0F2YWlsYWJsZSIsInJlcXVlc3RSZWNvbmZpcm1hdGlvbiIsInB1cnBvc2UiLCJtZXNzYWdlIiwiY29udGVudFZlcnNpb24iLCJQcm9taXNlIiwiYWxsIiwicmVjb3JkIiwibGF0ZXN0IiwiaGlzdG9yeSIsImF0IiwiZXZpZGVuY2VUeXBlIiwiZXZpZGVuY2VSZWZlcmVuY2UiLCJjaGFsbGVuZ2UiLCJleHBpcmVzQXQiLCJhbGlnblNlbGYiLCJzYXZlZENvbnNlbnRDaGFsbGVuZ2UiLCJDb25zZW50Q29uZmlybWF0aW9uUGFnZSIsIl9zOSIsInRva2VuIiwic2V0Q2hhbGxlbmdlIiwic3RhdGUiLCJjb25zZW50Q2hhbGxlbmdlIiwiY29uZmlybWF0aW9uIiwic2V0Q29uZmlybWF0aW9uIiwic3VibWl0dGVkRGVjaXNpb24iLCJzZXRTdWJtaXR0ZWREZWNpc2lvbiIsImV4Y2hhbmdlSWQiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiY29uZmlybWF0aW9uSWQiLCJleGNoYW5nZSIsImlkZW1wb3RlbmN5S2V5IiwicmVwbGFjZSIsImNvbmZpcm0iLCJkZWNpc2lvbiIsImludGVudCIsImNoYWxsZW5nZVNlc3Npb25JZCIsIndpdGhkcmF3YWwiLCJjb25maXJtYXRpb25NZXNzYWdlIiwiY29uc2VudFN0YXR1cyIsIkpvYlBhZ2UiLCJfczAiLCJqb2JJZCIsImpvYiIsImRvd25sb2FkSHJlZiIsImRvd25sb2FkVXJsIiwiam9iU3RhdHVzIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwiY29tcGxldGVkIiwidG90YWwiLCJlcnJvckNvdW50IiwidXBkYXRlZEF0Iiwicm93RXJyb3JzIiwicm93IiwiZmllbGQiLCJjb2RlIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1IiwiX2M3IiwiX2M4IiwiX2M5IiwiX2MwIiwiX2MxIiwiX2MxMCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtsYWJlbCBhcyBidXNpbmVzc0xhYmVsfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9sYWJlbHMnO1xuaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZpZWxkR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQsIFN1cmZhY2VDb250ZW50IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayBhcyBSb3V0ZXJMaW5rLCBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5JztcbmltcG9ydCB7IEFsZXJ0LCBBdmF0YXIsIEJveCwgQnV0dG9uLCBDaGVja2JveCwgRm9ybUNvbnRyb2xMYWJlbCwgTWVudUl0ZW0sIFBhcGVyLCBTdGFjaywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgU21hcnRUb3lSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvU21hcnRUb3lSb3VuZGVkJztcbmltcG9ydCBBcnJvd0ZvcndhcmRSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvQXJyb3dGb3J3YXJkUm91bmRlZCc7XG5pbXBvcnQgdHlwZSB7IENvbnNlbnRDb25maXJtYXRpb24sIEN1c3RvbWVyLCBNZW1iZXJzaGlwLCBQdWJsaWNDb25zZW50Q2hhbGxlbmdlVmlldywgUm9sZSB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgcGVybWlzc2lvbkNhdGFsb2cgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IGNvbG9ycyB9IGZyb20gJ0Bib3RzYWxlcy90b2tlbnMnO1xuaW1wb3J0IHsgcmVxdWVzdCwgc2V0Q3NyZlRva2VuIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2NsaWVudCc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZVBhZ2VkQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2Vycm9ycyc7XG5pbXBvcnQgeyBhc3NlcnRTY2hlbWEgfSBmcm9tICdAL3NoYXJlZC9hcGkvdmFsaWRhdGlvbic7XG5pbXBvcnQgeyB1c2VDYW4sIHVzZVNjb3BlIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xuaW1wb3J0IHsgY29kZVBvaW50TGVuZ3RoLCBsaW1pdENvZGVQb2ludHMsIGRhdGVUaW1lLCBzYWZlSW50ZXJuYWxQYXRoLCBpc1ZhbGlkVGltZVpvbmUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgYXV0aG9yaXplZERvd25sb2FkSHJlZiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Rvd25sb2FkJztcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xuaW1wb3J0IHsgbWFya0RyYWZ0Q2xlYW4sIHVzZURyYWZ0Rm9ybSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XG5pbXBvcnQgeyB1c2VWZXJzaW9uZWREcmFmdCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XG5pbXBvcnQgeyBEcmFmdENvbmZsaWN0IH0gZnJvbSAnQC9zaGFyZWQvdWkvZHJhZnQtY29uZmxpY3QnO1xuaW1wb3J0IHsgbGF5b3V0U3ggfSBmcm9tICdAL3NoYXJlZC91aS9sYXlvdXQnO1xuaW1wb3J0IHsgUGFnZUhlYWRlciwgUGFuZWwsIFF1ZXJ5U3RhdGUsIERhdGFUYWJsZSwgVG9vbGJhciwgUGFnZXIsIFN0YXR1cywgTXV0YXRpb25CdXR0b24sIEVkaXREaWFsb2csIEVycm9yTm90aWNlLCBDb25maXJtRGlhbG9nLCBSb3V0ZUxpbmssIERldGFpbExpbmUsIExvb2t1cExvYWRNb3JlLCBFbXB0eSB9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgdXNlU2Vzc2lvbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2F1dGgnO1xuZnVuY3Rpb24gQXV0aENhcmQoeyBjaGlsZHJlbiB9OiB7XG4gICAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbn0pIHsgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwibWFpblwiIGlkPVwibWFpbi1jb250ZW50XCIgdGFiSW5kZXg9ey0xfSBzeD17W2xheW91dFN4LnNoZWxsLmNlbnRlcmVkRmFsbGJhY2ssIHsgYmdjb2xvcjogJ2JhY2tncm91bmQuZGVmYXVsdCcsIG91dGxpbmU6ICdub25lJyB9XX0+PFBhcGVyIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIHN4PXtbbGF5b3V0U3guYXV0aC5zdXJmYWNlSW5zZXQsIHsgd2lkdGg6ICcxMDAlJywgbWF4V2lkdGg6IDUyMCwgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuaGVybyB9XX0+PFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBzeD17bGF5b3V0U3guYXV0aC5icmFuZE1hcmtHYXB9PjxBdmF0YXIgc3g9e3sgYmdjb2xvcjogJ3ByaW1hcnkubWFpbicsIGNvbG9yOiBjb2xvcnMub25BY2NlbnQgfX0+PFNtYXJ0VG95Um91bmRlZCAvPjwvQXZhdGFyPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiIGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5leHRyYUJvbGR9PkJvdFNhbGVzIDxCb3ggY29tcG9uZW50PVwic3BhblwiIGNvbG9yPVwicHJpbWFyeS5tYWluXCI+QUk8L0JveD48L1R5cG9ncmFwaHk+PC9TdGFjaz57Y2hpbGRyZW59PC9QYXBlcj48L0JveD47IH1cbmV4cG9ydCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XG4gICAgY29uc3QgeyBzZXNzaW9uLCBsb2FkaW5nIH0gPSB1c2VTZXNzaW9uKCk7XG4gICAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBbcGVuZGluZywgc2V0UGVuZGluZ10gPSB1c2VTdGF0ZShmYWxzZSksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBsb2dpbiA9IGFzeW5jICgpID0+IHsgc2V0UGVuZGluZyh0cnVlKTsgc2V0RXJyb3IobnVsbCk7IHRyeSB7XG4gICAgICAgIGNvbnN0IGNzcmYgPSBhd2FpdCByZXF1ZXN0KCdnZXRDc3JmVG9rZW4nKTtcbiAgICAgICAgc2V0Q3NyZlRva2VuKGNzcmYuZGF0YS5jc3JmVG9rZW4pO1xuICAgICAgICBjb25zdCBhdXRoID0gYXdhaXQgcmVxdWVzdCgnYmVnaW5Mb2dpbicsIHsgYm9keTogeyByZXR1cm5Ubzogc2FmZUludGVybmFsUGF0aChwYXJhbXMuZ2V0KCdyZXR1cm5UbycpIHx8ICcvd29ya3NwYWNlcycpIH0gfSk7XG4gICAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoYXV0aC5kYXRhLmF1dGhvcml6YXRpb25VcmwpO1xuICAgICAgICBpZiAodXJsLnByb3RvY29sICE9PSAnaHR0cHM6JyAmJiAhKF9fTU9DS19fICYmIHVybC5vcmlnaW4gPT09IGxvY2F0aW9uLm9yaWdpbikpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ8SQ4buLYSBjaOG7iSDEkcSDbmcgbmjhuq1wIGtow7RuZyBhbiB0b8Ogbi4nKTtcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmFzc2lnbih1cmwuaHJlZik7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUgOiBuZXcgRXJyb3IoJ0tow7RuZyBi4bqvdCDEkeG6p3UgxJHGsOG7o2MgxJHEg25nIG5o4bqtcCcpKTtcbiAgICAgICAgc2V0UGVuZGluZyhmYWxzZSk7XG4gICAgfSB9O1xuICAgIHJldHVybiA8QXV0aENhcmQ+PFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDFcIiB2YXJpYW50PVwiaDRcIiBzeD17bGF5b3V0U3guYXV0aC5icmFuZFRpdGxlR2FwfT5DaMOgbyBt4burbmcgdHLhu58gbOG6oWk8L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtbbGF5b3V0U3gucGFnZUhlYWRlci50aXRsZURlc2NyaXB0aW9uR2FwLCBsYXlvdXRTeC5wYWdlSGVhZGVyLmFmdGVyR2FwXX0+TeG7mXQga2jDtG5nIGdpYW4gY2hvIGLDoW4gaMOgbmcsIGtobywga+G6vyB0b8OhbiB2w6AgxJHhu5lpIG5nxakgQUkgY+G7p2EgYuG6oW4uPC9UeXBvZ3JhcGh5PjxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3J9Lz57X19NT0NLX18gJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHN4PXtsYXlvdXRTeC5wYWdlSGVhZGVyLmFmdGVyR2FwfT5DaOG6vyDEkeG7mSB4ZW0gZnJvbnRlbmQ6IHTDoGkga2hv4bqjbiBnaeG6oyBs4bqtcCwga2jDtG5nIGPDsyBt4bqtdCBraOG6qXUgdGjhuq10LjwvQWxlcnQ+fXtzZXNzaW9uID8gPEJ1dHRvbiBmdWxsV2lkdGggY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz1cIi93b3Jrc3BhY2VzXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGVuZEljb249ezxBcnJvd0ZvcndhcmRSb3VuZGVkIC8+fT5UaeG6v3AgdOG7pWMgdsOgbyBj4butYSBow6BuZzwvQnV0dG9uPiA6IDxCdXR0b24gZnVsbFdpZHRoIHZhcmlhbnQ9XCJjb250YWluZWRcIiBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGxvZ2luKCl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IGxvYWRpbmd9PntwZW5kaW5nID8gJ8SQYW5nIGNodXnhu4NuIMSR4bq/biDEkcSDbmcgbmjhuq1w4oCmJyA6IF9fTU9DS19fID8gJ1bDoG8gdMOgaSBraG/huqNuIG3DtCBwaOG7j25nJyA6ICfEkMSDbmcgbmjhuq1wIGLhurFuZyB0w6BpIGtob+G6o24gY8O0bmcgdHknfTwvQnV0dG9uPn08VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17W2xheW91dFN4LnBhZ2Uuc2VjdGlvbkJlZm9yZSwgeyBkaXNwbGF5OiAnYmxvY2snIH1dfT5QaGnDqm4gxJHEg25nIG5o4bqtcCDEkcaw4bujYyBxdeG6o24gbMO9IOG7nyBtw6F5IGNo4bunLiBLaMO0bmcgbMawdSBhY2Nlc3MgdG9rZW4gdHJvbmcgbG9jYWxTdG9yYWdlLjwvVHlwb2dyYXBoeT48L0F1dGhDYXJkPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBXb3Jrc3BhY2VzUGFnZSgpIHtcbiAgICBjb25zdCB7IHNlc3Npb24sIGxvYWRpbmcsIGVycm9yOiBzZXNzaW9uRXJyb3IgfSA9IHVzZVNlc3Npb24oKTtcbiAgICBjb25zdCBzaG9wcyA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IFsnc2hvcHMnLCBzZXNzaW9uPy51c2VyLmlkXSwgcXVlcnlGbjogKHsgc2lnbmFsIH0pID0+IHJlcXVlc3QoJ2xpc3RTaG9wcycsIHsgc2lnbmFsIH0pLCBlbmFibGVkOiAhIXNlc3Npb24sIHJldHJ5OiBmYWxzZSB9KTtcbiAgICBjb25zdCBpc0VtcHR5ID0gIXNob3BzLmlzRXJyb3IgJiYgc2hvcHMuZGF0YT8uZGF0YS5sZW5ndGggPT09IDA7XG4gICAgY29uc3QgY3JlYXRlU2hvcEJ1dHRvbiA9IDxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz1cIi9vbmJvYXJkaW5nXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlThuqFvIGPhu61hIGjDoG5nPC9CdXR0b24+O1xuICAgIGlmICghbG9hZGluZyAmJiAhc2Vzc2lvbiAmJiBzZXNzaW9uRXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBzZXNzaW9uRXJyb3Iuc3RhdHVzID09PSA0MDEpXG4gICAgICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlLz47XG4gICAgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwibWFpblwiIGlkPVwibWFpbi1jb250ZW50XCIgdGFiSW5kZXg9ey0xfSBzeD17W2xheW91dFN4LnNoZWxsLnBhZ2VGYWxsYmFja0luc2V0LCB7IG1heFdpZHRoOiAxMTAwLCBteDogJ2F1dG8nLCBvdXRsaW5lOiAnbm9uZScgfV19PjxQYWdlSGVhZGVyIHRpdGxlPVwiQ2jhu41uIGPhu61hIGjDoG5nXCIgc3VidGl0bGU9XCJN4buXaSBj4butYSBow6BuZyBsw6AgbeG7mXQgdsO5bmcgZOG7ryBsaeG7h3UgdsOgIHF1eeG7gW4gxJHhu5ljIGzhuq1wLlwiIGFjdGlvbnM9eyFpc0VtcHR5ICYmIGNyZWF0ZVNob3BCdXR0b259Lz48RXJyb3JOb3RpY2UgZXJyb3I9e3Nlc3Npb25FcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtzaG9wc30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2lzRW1wdHkgPyA8RW1wdHkgdGV4dD1cIkNoxrBhIGPDsyBj4butYSBow6BuZy5cIiBhY3Rpb249e2NyZWF0ZVNob3BCdXR0b259Lz4gOiA8U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJ21pbm1heCgwLCAxZnIpJywgbWQ6IHNob3BzLmRhdGE/LmRhdGEubGVuZ3RoID09PSAxID8gJ21pbm1heCgwLCAxZnIpJyA6ICdyZXBlYXQoMiwgbWlubWF4KDAsIDFmcikpJyB9fT57c2hvcHMuZGF0YT8uZGF0YS5tYXAocyA9PiA8UGFwZXIgdmFyaWFudD1cIm91dGxpbmVkXCIga2V5PXtzLmlkfSBzeD17W2xheW91dFN4LnN1cmZhY2UuaW5zZXQsIHsgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMubGFyZ2UgfV19PjxBdmF0YXIgc3g9e3sgYmdjb2xvcjogY29sb3JzLnNlbGVjdGVkLCBjb2xvcjogJ3ByaW1hcnkubWFpbicgfX0+e3MubmFtZVswXX08L0F2YXRhcj48U3VyZmFjZUNvbnRlbnQgYmVmb3JlR2FwPVwic3VyZmFjZVwiPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiPntzLm5hbWV9PC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj57cy5jdXJyZW5jeX0gwrcge3MudGltZXpvbmV9PC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlF1eeG7gW46IHtzZXNzaW9uPy5tZW1iZXJzaGlwcy5maW5kKG0gPT4gbS5zaG9wSWQgPT09IHMuaWQpPy5yb2xlcy5tYXAocm9sZSA9PiBidXNpbmVzc0xhYmVsKHJvbGUpKS5qb2luKCcsICcpIHx8ICdDaMawYSBjw7MgcXV54buBbid9PC9UeXBvZ3JhcGh5PjwvU3VyZmFjZUNvbnRlbnQ+PEJ1dHRvbiBjb21wb25lbnQ9e1JvdXRlckxpbmt9IHRvPXtgL3MvJHtzLmlkfS9vdmVydmlld2B9IGZ1bGxXaWR0aCB2YXJpYW50PVwib3V0bGluZWRcIiBlbmRJY29uPXs8QXJyb3dGb3J3YXJkUm91bmRlZCAvPn0gc3g9e2xheW91dFN4LnBhZ2Uuc2VjdGlvbkJlZm9yZX0+TeG7nyBj4butYSBow6BuZzwvQnV0dG9uPjwvUGFwZXI+KX08L1NlY3Rpb25HcmlkPn08L1F1ZXJ5U3RhdGU+PC9Cb3g+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIE9uYm9hcmRpbmdQYWdlKCkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHJlZnJlc2ggfSA9IHVzZVNlc3Npb24oKTtcbiAgICBjb25zdCBjYWNoZSA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gICAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpLCBbY3VycmVuY3ksIHNldEN1cnJlbmN5XSA9IHVzZVN0YXRlKCdWTkQnKSwgW3RpbWV6b25lLCBzZXRUaW1lem9uZV0gPSB1c2VTdGF0ZSgnQXNpYS9WaWVudGlhbmUnKSwgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpLCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCksIFt0aW1lem9uZVRvdWNoZWQsIHNldFRpbWV6b25lVG91Y2hlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtzdWJtaXR0ZWQsIHNldFN1Ym1pdHRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgZm9ybUVsZW1lbnQgPSB1c2VSZWY8SFRNTEZvcm1FbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBiYXNlbGluZSA9IHVzZVJlZih7bmFtZTogJycsY3VycmVuY3k6ICdWTkQnLHRpbWV6b25lOiAnQXNpYS9WaWVudGlhbmUnfSk7XG4gICAgY29uc3QgbW91bnRlZCA9IHVzZVJlZih0cnVlKTtcbiAgICB1c2VFZmZlY3QoKCkgPT4geyBtb3VudGVkLmN1cnJlbnQ9dHJ1ZTsgcmV0dXJuICgpID0+IHsgbW91bnRlZC5jdXJyZW50PWZhbHNlOyB9OyB9LFtdKTtcbiAgICBjb25zdCBiaW5kRHJhZnQgPSB1c2VEcmFmdEZvcm0obmFtZSE9PWJhc2VsaW5lLmN1cnJlbnQubmFtZSB8fCBjdXJyZW5jeSE9PWJhc2VsaW5lLmN1cnJlbnQuY3VycmVuY3kgfHwgdGltZXpvbmUhPT1iYXNlbGluZS5jdXJyZW50LnRpbWV6b25lKTtcbiAgICBjb25zdCB0aW1lem9uZUVycm9yID0gIWlzVmFsaWRUaW1lWm9uZSh0aW1lem9uZSkgPyAnTmjhuq1wIG3DumkgZ2nhu50gaOG7o3AgbOG7hywgdsOtIGThu6UgQXNpYS9WaWVudGlhbmUuJyA6ICcnO1xuICAgIGNvbnN0IHNhdmUgPSBhc3luYyAoKSA9PiB7IHNldFN1Ym1pdHRlZCh0cnVlKTsgaWYgKHBlbmRpbmcgfHwgIW5hbWUudHJpbSgpIHx8IHRpbWV6b25lRXJyb3IpIHJldHVybjsgc2V0UGVuZGluZyh0cnVlKTsgc2V0RXJyb3IobnVsbCk7IHRyeSB7XG4gICAgICAgIGNvbnN0IHIgPSBhd2FpdCByZXF1ZXN0KCdjcmVhdGVTaG9wJywgeyBib2R5OiB7IG5hbWUsIGN1cnJlbmN5LCB0aW1lem9uZSwgbG9jYWxlOiAndmktVk4nIH0gfSk7XG4gICAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICAgICAgYXdhaXQgY2FjaGUuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydzaG9wcyddIH0pO1xuICAgICAgICBpZiAoIW1vdW50ZWQuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICBiYXNlbGluZS5jdXJyZW50PXtuYW1lLGN1cnJlbmN5LHRpbWV6b25lfTtcbiAgICAgICAgaWYgKGZvcm1FbGVtZW50LmN1cnJlbnQpIG1hcmtEcmFmdENsZWFuKGZvcm1FbGVtZW50LmN1cnJlbnQpO1xuICAgICAgICBuYXZpZ2F0ZShgL3MvJHtyLmRhdGEuaWR9L292ZXJ2aWV3YCk7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChtb3VudGVkLmN1cnJlbnQpIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUgOiBuZXcgRXJyb3IoJ0tow7RuZyB04bqhbyDEkcaw4bujYyBj4butYSBow6BuZycpKTtcbiAgICB9XG4gICAgZmluYWxseSB7XG4gICAgICAgIGlmIChtb3VudGVkLmN1cnJlbnQpIHNldFBlbmRpbmcoZmFsc2UpO1xuICAgIH0gfTtcbiAgICByZXR1cm4gPEF1dGhDYXJkPjxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgxXCIgdmFyaWFudD1cImg0XCIgc3g9e2xheW91dFN4LmF1dGguYnJhbmRUaXRsZUdhcH0+VOG6oW8gY+G7rWEgaMOgbmc8L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtbbGF5b3V0U3gucGFnZUhlYWRlci50aXRsZURlc2NyaXB0aW9uR2FwLCBsYXlvdXRTeC5wYWdlSGVhZGVyLmFmdGVyR2FwXX0+Q2jhu41uIHRp4buBbiB04buHIGPGoSBz4bufIHRyxrDhu5tjIGtoaSBnaGkgbmjhuq1uIGdpYW8gZOG7i2NoLjwvVHlwb2dyYXBoeT48RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yfS8+PEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIG5vVmFsaWRhdGUgcmVmPXtlbGVtZW50ID0+IHtmb3JtRWxlbWVudC5jdXJyZW50PWVsZW1lbnQ7YmluZERyYWZ0KGVsZW1lbnQpO319IG9uU3VibWl0PXtldmVudCA9PiB7ZXZlbnQucHJldmVudERlZmF1bHQoKTt2b2lkIHNhdmUoKTt9fT48VGV4dEZpZWxkIGRpc2FibGVkPXtwZW5kaW5nfSBsYWJlbD1cIlTDqm4gY+G7rWEgaMOgbmdcIiB2YWx1ZT17bmFtZX0gb25DaGFuZ2U9e2UgPT4gc2V0TmFtZShsaW1pdENvZGVQb2ludHMoZS50YXJnZXQudmFsdWUsIDE2MCkpfSAvPjxUZXh0RmllbGQgZGlzYWJsZWQ9e3BlbmRpbmd9IGxhYmVsPVwiVGnhu4FuIHThu4cgY8ahIHPhu59cIiBzZWxlY3QgdmFsdWU9e2N1cnJlbmN5fSBvbkNoYW5nZT17ZSA9PiBzZXRDdXJyZW5jeShlLnRhcmdldC52YWx1ZSl9PntbJ1ZORCcsICdMQUsnLCAnVEhCJywgJ1VTRCddLm1hcChjID0+IDxNZW51SXRlbSBrZXk9e2N9IHZhbHVlPXtjfT57Y308L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PFRleHRGaWVsZCBkaXNhYmxlZD17cGVuZGluZ30gbGFiZWw9XCJNw7ppIGdp4budXCIgdmFsdWU9e3RpbWV6b25lfSBvbkJsdXI9eygpID0+IHNldFRpbWV6b25lVG91Y2hlZCh0cnVlKX0gb25DaGFuZ2U9e2UgPT4gc2V0VGltZXpvbmUoZS50YXJnZXQudmFsdWUpfSBlcnJvcj17KHRpbWV6b25lVG91Y2hlZCB8fCBzdWJtaXR0ZWQpICYmICEhdGltZXpvbmVFcnJvcn0gaGVscGVyVGV4dD17KHRpbWV6b25lVG91Y2hlZCB8fCBzdWJtaXR0ZWQpICYmIHRpbWV6b25lRXJyb3IgPyB0aW1lem9uZUVycm9yIDogJ1bDrSBk4bulOiBBc2lhL1ZpZW50aWFuZSd9Lz48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+R2lhbyBkaeG7h24gR3JhcGhpdGUgR29sZCBkYXJrLW9ubHkgxJHDoyBjaOG7kXQuIE5o4buvbmcgY2jDrW5oIHPDoWNoIHRo4bqtdCB2w6Aga+G6v3QgbuG7kWkgbmdvw6BpIGNoxrBhIHThu7EgYuG6rXQga2hpIHThuqFvIHNob3AuPC9BbGVydD48QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFuYW1lLnRyaW0oKSB8fCBwZW5kaW5nfT5U4bqhbyBj4butYSBow6BuZzwvQnV0dG9uPjxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz1cIi93b3Jrc3BhY2VzXCI+UXVheSBs4bqhaTwvQnV0dG9uPjwvRm9ybUZpZWxkcz48L0F1dGhDYXJkPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBTaG9wU2V0dGluZ3NQYWdlKCkge1xuICAgIGNvbnN0IHNjb3BlID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCB7IHNob3AgfSA9IHNjb3BlO1xuICAgIGNvbnN0IGNhY2hlID0gdXNlUXVlcnlDbGllbnQoKTtcbiAgICBjb25zdCBjYW5NYW5hZ2VTaG9wID0gdXNlQ2FuKCdzaG9wLm1hbmFnZScpO1xuICAgIGNvbnN0IHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZVNob3AnLCBbJ2dldFNob3AnXSk7XG4gICAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoc2hvcC5uYW1lKSwgW3RpbWV6b25lLCBzZXRUaW1lem9uZV0gPSB1c2VTdGF0ZShzaG9wLnRpbWV6b25lKSwgW2xvY2FsZSwgc2V0TG9jYWxlXSA9IHVzZVN0YXRlKHNob3AubG9jYWxlKSwgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxFcnJvciB8IG51bGw+KG51bGwpLCBbc2F2ZWQsIHNldFNhdmVkXSA9IHVzZVN0YXRlKGZhbHNlKSwgW3RpbWV6b25lVG91Y2hlZCwgc2V0VGltZXpvbmVUb3VjaGVkXSA9IHVzZVN0YXRlKGZhbHNlKSwgW3NldHRpbmdzU3VibWl0dGVkLCBzZXRTZXR0aW5nc1N1Ym1pdHRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgbGF0ZXN0U2hvcCA9IHVzZUFwaSgnZ2V0U2hvcCcpO1xuICAgIGNvbnN0IGN1cnJlbnRTaG9wID0gbGF0ZXN0U2hvcC5kYXRhICYmIGxhdGVzdFNob3AuZGF0YS5kYXRhLnZlcnNpb24gPj0gc2hvcC52ZXJzaW9uID8gbGF0ZXN0U2hvcC5kYXRhLmRhdGEgOiBzaG9wO1xuICAgIGNvbnN0IGVkaXRvciA9IHVzZVZlcnNpb25lZERyYWZ0KHtcbiAgICAgICAgaWRlbnRpdHk6IGAke3Nob3AuaWR9OnNldHRpbmdzYCxcbiAgICAgICAgc291cmNlOiB7IHZlcnNpb246IGN1cnJlbnRTaG9wLnZlcnNpb24sIHZhbHVlczogeyBuYW1lOiBjdXJyZW50U2hvcC5uYW1lLCB0aW1lem9uZTogY3VycmVudFNob3AudGltZXpvbmUsIGxvY2FsZTogY3VycmVudFNob3AubG9jYWxlIH0gfSxcbiAgICAgICAgZHJhZnQ6IHsgbmFtZSwgdGltZXpvbmUsIGxvY2FsZSB9LFxuICAgICAgICBhcHBseTogdmFsdWVzID0+IHsgc2V0TmFtZSh2YWx1ZXMubmFtZSk7IHNldFRpbWV6b25lKHZhbHVlcy50aW1lem9uZSk7IHNldExvY2FsZSh2YWx1ZXMubG9jYWxlKTsgfSxcbiAgICAgICAgcmVmcmVzaDogKCkgPT4gbGF0ZXN0U2hvcC5yZWZldGNoKHsgdGhyb3dPbkVycm9yOiB0cnVlIH0pLFxuICAgIH0pO1xuICAgIGNvbnN0IGZvcm1SZWYgPSB1c2VEcmFmdEZvcm0oZWRpdG9yLmRpcnR5KTtcbiAgICBjb25zdCB0aW1lem9uZUVycm9yID0gIWlzVmFsaWRUaW1lWm9uZSh0aW1lem9uZSkgPyAnTmjhuq1wIG3DumkgZ2nhu50gaOG7o3AgbOG7hywgdsOtIGThu6UgQXNpYS9WaWVudGlhbmUuJyA6ICcnO1xuICAgIGNvbnN0IHNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHNldFNldHRpbmdzU3VibWl0dGVkKHRydWUpO1xuICAgICAgICBpZiAoIW5hbWUudHJpbSgpIHx8IHRpbWV6b25lRXJyb3IpIHJldHVybjtcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7IHNldFNhdmVkKGZhbHNlKTtcbiAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBlZGl0b3IucHJlcGFyZSgpO1xuICAgICAgICBpZiAoIXByZXBhcmVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgbmFtZSwgdGltZXpvbmUsIGxvY2FsZSB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IHNob3BJZDogc2hvcC5pZCB9LCB2ZXJzaW9uOiBwcmVwYXJlZC52ZXJzaW9uLCBib2R5OiBwcmVwYXJlZC5wYXRjaCB9KTtcbiAgICAgICAgICAgIGNhY2hlLnNldFF1ZXJ5RGF0YShbJ3Nob3AnLCBzY29wZS5zZXNzaW9uLnVzZXIuaWQsIHNob3AuaWQsIHNjb3BlLm1lbWJlcnNoaXAucGVybWlzc2lvblZlcnNpb25dLCByZXN1bHQpO1xuICAgICAgICAgICAgZWRpdG9yLmNvbW1pdHRlZCh7IHZlcnNpb246IHJlc3VsdC5kYXRhLnZlcnNpb24sIHZhbHVlczogeyBuYW1lOiByZXN1bHQuZGF0YS5uYW1lLCB0aW1lem9uZTogcmVzdWx0LmRhdGEudGltZXpvbmUsIGxvY2FsZTogcmVzdWx0LmRhdGEubG9jYWxlIH0gfSwgc3VibWl0dGVkKTtcbiAgICAgICAgICAgIHNldFNhdmVkKHRydWUpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikgeyBlZGl0b3IuZmFpbGVkKGVycm9yKTsgc2V0RXJyb3IoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yIDogbmV3IEVycm9yKCdLaMO0bmcgbMawdSDEkcaw4bujYyBj4bqldSBow6xuaCcpKTsgfVxuICAgIH07XG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiVGhp4bq/dCBs4bqtcCBj4butYSBow6BuZ1wiIHN1YnRpdGxlPVwiQ+G6pXUgaMOsbmggcmnDqm5nIGPhu6dhIHNob3Aga2jDtG5nIHRoYXkgxJHhu5VpIHF1eSB04bqvYyBBSSBs4bqtcCB0csOsbmggaG/hurdjIG3DoHUgxJHDoyBkdXnhu4d0LlwiIC8+XG4gICAgICAgIDxQYWdlU2VjdGlvbnMgPlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiVGjDtG5nIHRpbiBjxqEgc+G7n1wiIGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtmb3JtUmVmfSBub1ZhbGlkYXRlIG9uU3VibWl0PXtldmVudCA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHZvaWQgc2F2ZSgpOyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtlcnJvciB8fCB1cGRhdGUuZXJyb3J9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxEcmFmdENvbmZsaWN0IGVkaXRvcj17ZWRpdG9yfSBsYWJlbHM9e3sgbmFtZTogJ1TDqm4gY+G7rWEgaMOgbmcnLCB0aW1lem9uZTogJ03DumkgZ2nhu50nLCBsb2NhbGU6ICdOZ8O0biBuZ+G7rycgfX0gYnVzeT17dXBkYXRlLnBlbmRpbmd9Lz5cbiAgICAgICAgICAgICAgICAgICAge3NhdmVkICYmIDxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+xJDDoyBsxrB1IGPhuqV1IGjDrG5oIGPhu61hIGjDoG5nLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICA8RmllbGRHcm91cCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ3N0YXJ0JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJUw6puIGPhu61hIGjDoG5nXCIgdmFsdWU9e25hbWV9IGRpc2FibGVkPXshY2FuTWFuYWdlU2hvcH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0TmFtZShldmVudC50YXJnZXQudmFsdWUpOyBzZXRTYXZlZChmYWxzZSk7IH19IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVGnhu4FuIHThu4cgY8ahIHPhu59cIiB2YWx1ZT17c2hvcC5jdXJyZW5jeX0gZGlzYWJsZWQgaGVscGVyVGV4dD1cIktow7RuZyDEkeG7lWkgdGnhu4FuIHThu4cgYuG6sW5nIHPhu61hIGdpYW8gZGnhu4duLiBD4bqnbiBr4bq/IGhv4bqhY2ggY2h1eeG7g24gxJHhu5VpIGThu68gbGnhu4d1LlwiIHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvRmllbGRHcm91cD5cbiAgICAgICAgICAgICAgICAgICAgPEZpZWxkR3JvdXAgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdzdGFydCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTcO6aSBnaeG7nVwiIHZhbHVlPXt0aW1lem9uZX0gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VTaG9wfSBvbkJsdXI9eygpID0+IHNldFRpbWV6b25lVG91Y2hlZCh0cnVlKX0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0VGltZXpvbmUoZXZlbnQudGFyZ2V0LnZhbHVlKTsgc2V0U2F2ZWQoZmFsc2UpOyB9fSBlcnJvcj17KHRpbWV6b25lVG91Y2hlZCB8fCBzZXR0aW5nc1N1Ym1pdHRlZCkgJiYgISF0aW1lem9uZUVycm9yfSBoZWxwZXJUZXh0PXsodGltZXpvbmVUb3VjaGVkIHx8IHNldHRpbmdzU3VibWl0dGVkKSAmJiB0aW1lem9uZUVycm9yID8gdGltZXpvbmVFcnJvciA6ICfDgXAgZOG7pW5nIGNobyBuZ8OgeSBnaeG7nSB0aGVvIGPhu61hIGjDoG5nLid9IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTmfDtG4gbmfhu68gZ2lhbyBkaeG7h25cIiB2YWx1ZT1cIlRp4bq/bmcgVmnhu4d0XCIgZGlzYWJsZWQgaGVscGVyVGV4dD17YEdpYW8gZGnhu4duIGhp4buHbiBjaOG7iSBo4buXIHRy4bujIHRp4bq/bmcgVmnhu4d0LiBMb2NhbGUgbMawdSB0cm9uZyBBUEk6ICR7bG9jYWxlfS5gfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L0ZpZWxkR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJHaWFvIGRp4buHblwiIHZhbHVlPVwiR3JhcGhpdGUgR29sZCDCtyBEYXJrLW9ubHlcIiBkaXNhYmxlZCAvPlxuICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInNob3AubWFuYWdlXCIgdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXt1cGRhdGUucGVuZGluZ30gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VTaG9wIHx8ICFlZGl0b3IuZGlydHkgfHwgdXBkYXRlLnBlbmRpbmd9PkzGsHUgY+G6pXUgaMOsbmg8L011dGF0aW9uQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJDaGVja2xpc3QgdGhp4bq/dCBs4bqtcCB24bqtbiBow6BuaFwiIHN1YnRpdGxlPVwiQ8OhYyBt4bulYyBraMO0bmcgY8OzIHRyxrDhu51uZyBBUEkgxJHGsOG7o2MgZ2nhu68g4bufIHRy4bqhbmcgdGjDoWkgY2jGsGEgeMOhYyBtaW5oOyBraMO0bmcgc3V5IGRp4buFbiDEkcOjIHPhurVuIHPDoG5nLlwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgc3g9e2xheW91dFN4LnN1cmZhY2UuY29tcGFjdENvbnRlbnRHYXB9PlxuICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e19fTU9DS19fID8gJ0LhuqNuIHhlbSB0csaw4bubYyBtw7QgcGjhu49uZy4gQ2jhu4kgdMOqbiwgdGnhu4FuIHThu4csIG3DumkgZ2nhu50gdsOgIG5nw7RuIG5n4buvIMSRxrDhu6NjIGzGsHUgcXVhIEFQSSBoaeG7h24gdOG6oWkuJyA6ICdBUEkgaGnhu4duIGNo4buJIGNobyBwaMOpcCBz4butYSB0aMO0bmcgdGluIGPGoSBz4bufIMSRxrDhu6NjIGjhu5cgdHLhu6MuJ30gUXXhu5FjIGdpYSBraW5oIGRvYW5oIGtow7RuZyDEkcaw4bujYyBzdXkgcmEgdOG7qyBtw7ppIGdp4budLjwvQWxlcnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJRdeG7kWMgZ2lhIHbDoCBnaeG7nSBraW5oIGRvYW5oXCIgc3RhdHVzPVwiQ2jGsGEgY8OzIHRyxrDhu51uZyBj4bqldSBow6xuaCB0cm9uZyBjb250cmFjdFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCLEkOG7i2EgY2jhu4ksIHbDuW5nIGdpYW8gdsOgIHBow60gduG6rW4gY2h1eeG7g25cIiBzdGF0dXM9e19fTU9DS19fID8gJ0PDsyBwcmV2aWV3IG3DtCBwaOG7j25nLCBjaMawYSBsxrB1IGPhuqV1IGjDrG5oJyA6ICdDaMawYSBjw7Mgb3BlcmF0aW9uIGPhuqV1IGjDrG5oIHbDuW5nIGdpYW8nfSB0bz17YC9zLyR7c2hvcC5pZH0vc2hpcG1lbnRzYH0gYWN0aW9uPVwiWGVtIHByZXZpZXcgcGjDrSBnaWFvXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIk5nxrDhu51pIGR1eeG7h3QgdsOgIHRow6BuaCB2acOqblwiIHN0YXR1cz1cIlF1eeG7gW4gbOG6pXkgdOG7qyBtZW1iZXJzaGlwOyBjaMawYSBjw7MgQVBJIGfDoW4gY2jDrW5oIHPDoWNoIGR1eeG7h3RcIiB0bz17YC9zLyR7c2hvcC5pZH0vc2V0dGluZ3MvdGVhbWB9IGFjdGlvbj1cIlF14bqjbiBsw70gdGjDoG5oIHZpw6puXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNldHVwQ2hlY2tsaXN0SXRlbSB0aXRsZT1cIkvhur90IG7hu5FpIGvDqm5oIGLDoW4gaMOgbmdcIiBzdGF0dXM9e19fTU9DS19fID8gJ0vhur90IG7hu5FpIG3DtCBwaOG7j25nOyBraMO0bmcgY8OzIHF1eeG7gW4gcHJvdmlkZXIgdGjhuq10JyA6ICdLaeG7g20gdHJhIHRy4bqhbmcgdGjDoWkga+G6v3QgbuG7kWknfSB0bz17YC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2NoYW5uZWxzYH0gYWN0aW9uPVwiTeG7nyBr4bq/dCBu4buRaVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJL4bq/dCBu4buRaSBBSVwiIHN0YXR1cz17X19NT0NLX18gPyAnQ2F0YWxvZyBuaMOgIGN1bmcgY+G6pXAgbcO0IHBo4buPbmcnIDogJ0tp4buDbSB0cmEgY2F0YWxvZyBuaMOgIGN1bmcgY+G6pXAnfSB0bz17YC9zLyR7c2hvcC5pZH0vaW50ZWdyYXRpb25zL2FpYH0gYWN0aW9uPVwiTeG7nyBuaMOgIGN1bmcgY+G6pXAgQUlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8U2V0dXBDaGVja2xpc3RJdGVtIHRpdGxlPVwiTuG7mWkgZHVuZyBz4bqjbiBwaOG6qW0gdsOgIHBoacOqbiBi4bqjbiBraeG6v24gdGjhu6ljXCIgc3RhdHVzPVwiTmd14buTbiBu4buZaSBkdW5nLCBs4buLY2ggc+G7rSBwaGnDqm4gYuG6o24gdsOgIGR1eeG7h3QgbuG6sW0gdHJvbmcga2h1IHbhu7FjIGtp4bq/biB0aOG7qWMuXCIgdG89e2Avcy8ke3Nob3AuaWR9L2tub3dsZWRnZWB9IGFjdGlvbj1cIlF14bqjbiBsw70gbuG7mWkgZHVuZ1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJWw7JuZyBnw7NwIMO9IGPDsyBkdXnhu4d0XCIgc3RhdHVzPVwiR8OzcCDDvSB04bqhbyBi4bqjbiBuaMOhcDsga2jDtG5nIHThu7EgaHXhuqVuIGx1eeG7h24gaG/hurdjIHh14bqldCBi4bqjbi5cIiB0bz17YC9zLyR7c2hvcC5pZH0va25vd2xlZGdlL3Jldmlld2B9IGFjdGlvbj1cIkR1eeG7h3QgZ8OzcCDDvVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR1cENoZWNrbGlzdEl0ZW0gdGl0bGU9XCJDb25zZW50IHbDoCBuZ+G7q25nIGxpw6puIGjhu4cgbWFya2V0aW5nXCIgc3RhdHVzPVwiQ8OzIGLhuqNuIGdoaSBjb25zZW50LCBs4buLY2ggc+G7rSB2w6AgbHXhu5NuZyB4w6FjIG5o4bqtbiBjaGFsbGVuZ2U7IGfhu61pIHF1YSBuaMOgIGN1bmcgY+G6pXAgY2jGsGEga+G6v3QgbuG7kWkuXCIgdG89e2Avcy8ke3Nob3AuaWR9L3NldHRpbmdzL3ByaXZhY3lgfSBhY3Rpb249XCJRdeG6o24gbMO9IGNvbnNlbnRcIiAvPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8L1BhZ2VTZWN0aW9ucz5cbiAgICA8Lz47XG59XG5mdW5jdGlvbiBTZXR1cENoZWNrbGlzdEl0ZW0oeyB0aXRsZSwgc3RhdHVzLCB0bywgYWN0aW9uIH06IHsgdGl0bGU6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmc7IHRvPzogc3RyaW5nOyBhY3Rpb24/OiBzdHJpbmcgfSkge1xuICAgIHJldHVybiA8U3VyZmFjZUNvbnRlbnQgYm9keU1vZGU9XCJjb21wYWN0Q29udHJvbE91dGxpbmVkXCIgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz17eyB4czogJ2ZsZXgtc3RhcnQnLCBtZDogJ2NlbnRlcicgfX0ganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgZmxleFdyYXA9XCJ3cmFwXCI+XG4gICAgICAgIDxCb3g+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e3RpdGxlfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3N0YXR1c308L1R5cG9ncmFwaHk+PC9Cb3g+XG4gICAgICAgIHt0byAmJiBhY3Rpb24gJiYgPFJvdXRlTGluayB0bz17dG99PnthY3Rpb259PC9Sb3V0ZUxpbms+fVxuICAgIDwvU3VyZmFjZUNvbnRlbnQ+O1xufVxuY29uc3Qgcm9sZUxhYmVsczogUmVjb3JkPFJvbGUsIHN0cmluZz4gPSB7XG4gICAgb3duZXI6ICdDaOG7pyBj4butYSBow6BuZycsIG1hbmFnZXI6ICdRdeG6o24gbMO9Jywgc2FsZXM6ICdCw6FuIGjDoG5nJywgd2FyZWhvdXNlOiAnTmjDom4gdmnDqm4ga2hvJywgYWNjb3VudGFudDogJ0vhur8gdG/DoW4nLCBib3RfYWRtaW46ICdRdeG6o24gdHLhu4sgQUknLCB2aWV3ZXI6ICdDaOG7iSB4ZW0nXG59O1xuZXhwb3J0IGZ1bmN0aW9uIFRlYW1QYWdlKCkge1xuICAgIGNvbnN0IHsgc2Vzc2lvbiwgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0TWVtYmVycycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdE1lbWJlcnMnKSB9KTtcbiAgICBjb25zdCBpbnZpdGUgPSB1c2VDb21tYW5kKCdpbnZpdGVNZW1iZXInLCBbJ2xpc3RNZW1iZXJzJ10pO1xuICAgIGNvbnN0IHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZU1lbWJlclJvbGVzJywgWydsaXN0TWVtYmVycyddKTtcbiAgICBjb25zdCByZXZva2UgPSB1c2VDb21tYW5kKCdyZXZva2VNZW1iZXJzaGlwJywgWydsaXN0TWVtYmVycyddKTtcbiAgICBjb25zdCBbZWRpdCwgc2V0RWRpdF0gPSB1c2VTdGF0ZTxNZW1iZXJzaGlwIHwgbnVsbCB8IHVuZGVmaW5lZD4oKSwgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyksIFtyb2xlcywgc2V0Um9sZXNdID0gdXNlU3RhdGU8Um9sZVtdPihbJ3ZpZXdlciddKSwgW3JlbW92ZSwgc2V0UmVtb3ZlXSA9IHVzZVN0YXRlPE1lbWJlcnNoaXAgfCBudWxsPihudWxsKSwgW3NhdmVkTWVzc2FnZSwgc2V0U2F2ZWRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBvcGVuID0gKG06IE1lbWJlcnNoaXAgfCBudWxsKSA9PiB7IHNldFNhdmVkTWVzc2FnZSgnJyk7IHNldEVkaXQobSk7IHNldEVtYWlsKCcnKTsgc2V0Um9sZXMobT8ucm9sZXMgfHwgWyd2aWV3ZXInXSk7IH07XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaMOibiBz4buxICYgcGjDom4gcXV54buBblwiIHN1YnRpdGxlPVwiVmFpIHRyw7IgbMOgIGLhu5kgcXV54buBbiBt4bq3YyDEkeG7i25oOyBBUEkgcXV54bq/dCDEkeG7i25oIHF1eeG7gW4gaGnhu4d1IGzhu7FjIOG7nyB04burbmcgdGhhbyB0w6FjLlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwibWVtYmVycy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gb3BlbihudWxsKX0+TeG7nWkgbmjDom4gdmnDqm48L011dGF0aW9uQnV0dG9uPn0vPntzYXZlZE1lc3NhZ2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT57c2F2ZWRNZXNzYWdlfTwvQWxlcnQ+fTxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0TWVtYmVyc1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiTmjDom4gc+G7sSB2w6AgcXV54buBbiB0cnV5IGPhuq1wXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17bSA9PiBtLmlkfSBjb2x1bW5zPXtbXG4gICAgICAgIHsga2V5OiAndXNlcicsIGxhYmVsOiAnTmjDom4gdmnDqm4nLCByZW5kZXI6IG0gPT4gbS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/IHNlc3Npb24udXNlci5kaXNwbGF5TmFtZSA6IGBNw6MgbmjDom4gc+G7sTogJHttLnVzZXJJZH1gIH0sIHsga2V5OiAncm9sZXMnLCBsYWJlbDogJ1ZhaSB0csOyJywgcmVuZGVyOiBtID0+IG0ucm9sZXMubWFwKHIgPT4gcm9sZUxhYmVsc1tyXSkuam9pbignLCAnKSB9LCB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogbSA9PiA8U3RhdHVzIHZhbHVlPXttLnN0YXR1c30vPiB9LCB7IGtleTogJ3Blcm1zJywgbGFiZWw6ICdRdXnhu4FuIGhp4buHdSBs4buxYycsIHJlbmRlcjogbSA9PiBgJHttLnBlcm1pc3Npb25zLmxlbmd0aH0gcXV54buBbiDCtyB2JHttLnBlcm1pc3Npb25WZXJzaW9ufWAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAga2V5OiAnYWN0aW9ucycsIGxhYmVsOiAnJywgcmVuZGVyOiBtID0+IDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm1lbWJlcnMubWFuYWdlXCIgb25DbGljaz17KCkgPT4gb3BlbihtKX0+U+G7rWEgcXV54buBbjwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJtZW1iZXJzLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBkaXNhYmxlZD17bS51c2VySWQgPT09IHNlc3Npb24udXNlci5pZCB8fCBtLnN0YXR1cyA9PT0gJ3Jldm9rZWQnfSBvbkNsaWNrPXsoKSA9PiBzZXRSZW1vdmUobSl9PlRodSBo4buTaTwvTXV0YXRpb25CdXR0b24+PC9TdGFjaz5cbiAgICAgICAgfVxuICAgIF19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+XG4gPEVkaXREaWFsb2cgb3Blbj17ZWRpdCAhPT0gdW5kZWZpbmVkfSB0aXRsZT17ZWRpdCA/ICdD4bqtcCBuaOG6rXQgcXV54buBbicgOiAnTeG7nWkgbmjDom4gdmnDqm4nfSBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0KHVuZGVmaW5lZCl9IGJ1c3k9e2ludml0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IXJvbGVzLmxlbmd0aCB8fCAoIWVkaXQgJiYgIS9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QoZW1haWwpKSB8fCBpbnZpdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBpZiAoZWRpdCkge1xuICAgICAgICAgICAgYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IG1lbWJlcklkOiBlZGl0LmlkIH0sIHZlcnNpb246IGVkaXQucGVybWlzc2lvblZlcnNpb24sIGJvZHk6IHsgcm9sZXMgfSB9KTtcbiAgICAgICAgICAgIHNldFNhdmVkTWVzc2FnZShgxJDDoyBj4bqtcCBuaOG6rXQgcXV54buBbiB0cnV5IGPhuq1wIGPhu6dhICR7ZWRpdC51c2VySWR9LmApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgaW52aXRlLmV4ZWN1dGUoeyBib2R5OiB7IGVtYWlsLCByb2xlcyB9IH0pO1xuICAgICAgICAgICAgc2V0U2F2ZWRNZXNzYWdlKGDEkMOjIGfhu61pIGzhu51pIG3hu51pIMSR4bq/biAke2VtYWlsLnRyaW0oKX0uYCk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0RWRpdCh1bmRlZmluZWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5MxrB1PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2ludml0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+eyFlZGl0ICYmIDxUZXh0RmllbGQgbGFiZWw9XCJFbWFpbCBuaMOibiB2acOqblwiIHR5cGU9XCJlbWFpbFwiIHZhbHVlPXtlbWFpbH0gb25DaGFuZ2U9e2UgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfS8+fTxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIj5QaMOibiB2YWkgdHLDsjwvVHlwb2dyYXBoeT57KE9iamVjdC5rZXlzKHJvbGVMYWJlbHMpIGFzIFJvbGVbXSkubWFwKHJvbGUgPT4gPEZvcm1Db250cm9sTGFiZWwga2V5PXtyb2xlfSBsYWJlbD17YCR7cm9sZUxhYmVsc1tyb2xlXX0gwrcgJHtwZXJtaXNzaW9uQ2F0YWxvZy5yb2xlUHJlc2V0c1tyb2xlXT8ubGVuZ3RoIHx8IDB9IHF1eeG7gW5gfSBjb250cm9sPXs8Q2hlY2tib3ggY2hlY2tlZD17cm9sZXMuaW5jbHVkZXMocm9sZSl9IG9uQ2hhbmdlPXtlID0+IHNldFJvbGVzKGUudGFyZ2V0LmNoZWNrZWQgPyBbLi4ucm9sZXMsIHJvbGVdIDogcm9sZXMuZmlsdGVyKHIgPT4gciAhPT0gcm9sZSkpfS8+fS8+KX08QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+UXV54buBbiBt4bubaSBwaOG6o2kgxJHGsOG7o2MgbcOheSBjaOG7pyBraeG7g20gbOG6oWkuIFRodSBo4buTaSBxdXnhu4FuIGzDoG0gbeG6pXQgaGnhu4d1IGzhu7FjIGNhY2hlIHbDoCBwaGnDqm4gdHJ1eSBj4bqtcCBsacOqbiBxdWFuLjwvQWxlcnQ+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48Q29uZmlybURpYWxvZyBvcGVuPXshIXJlbW92ZX0gdGl0bGU9XCJUaHUgaOG7k2kgcXV54buBbiBuaMOibiB2acOqblwiIGNvbmZpcm1MYWJlbD1cIlRodSBo4buTaSBxdXnhu4FuXCIgZGVzY3JpcHRpb249e2BOaMOibiB2acOqbiAke3JlbW92ZT8udXNlcklkIHx8IFwiXCJ9IHRyb25nICR7c2hvcC5uYW1lfTogbmfGsOG7nWkgbsOgeSBraMO0bmcgxJHGsOG7o2MgdGnhur9wIHThu6VjIHRydXkgY+G6rXAgZOG7ryBsaeG7h3UgY+G7rWEgaMOgbmcgc2F1IGtoaSB0aHUgaOG7k2kuIEzhu4tjaCBz4butIGhv4bqhdCDEkeG7mW5nIMSRxrDhu6NjIGdp4buvLmB9IG9uQ2xvc2U9eygpID0+IHNldFJlbW92ZShudWxsKX0gYnVzeT17cmV2b2tlLnBlbmRpbmd9IGVycm9yPXtyZXZva2UuZXJyb3J9IG9uQ29uZmlybT17YXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXJlbW92ZSkgcmV0dXJuO1xuICAgICAgICBhd2FpdCByZXZva2UuZXhlY3V0ZSh7IHBhdGg6IHsgbWVtYmVySWQ6IHJlbW92ZS5pZCB9LCB2ZXJzaW9uOiByZW1vdmUucGVybWlzc2lvblZlcnNpb24gfSk7XG4gICAgfX0vPjwvPjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBBdWRpdFBhZ2UoKSB7IGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTsgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdEF1ZGl0RXZlbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0QXVkaXRFdmVudHMnKSB9KTsgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaOG6rXQga8O9IGhv4bqhdCDEkeG7mW5nXCIgc3VidGl0bGU9XCJBaSB0aOG7sWMgaGnhu4duLCB0aGFvIHTDoWMgbsOgbywgZOG7ryBsaeG7h3UgbsOgbyB2w6AgbcOjIHRydXkgduG6v3QuIEtow7RuZyBsxrB1IEFQSSBrZXkgaG/hurdjIHN1eSBsdeG6rW4gcmnDqm5nIGPhu6dhIEFJLlwiLz48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+QVBJIGhp4buHbiB0cuG6oyB24buBIG5nxrDhu51pIHRo4buxYyBoaeG7h24sIHRoYW8gdMOhYywgxJHhu5FpIHTGsOG7o25nLCB0aOG7nWkgZ2lhbiwgbcOjIHRydXkgduG6v3QgdsOgIHTDs20gdOG6r3QuIExv4bqhaSBhY3RvciwgcGhpw6puIGLhuqNuIHBvbGljeS9jb25maWcgdsOgIHNuYXBzaG90IGNoaSB0aeG6v3QgY2jGsGEgY8OzIHRyb25nIERUTyBuw6puIGtow7RuZyDEkcaw4bujYyBzdXkgxJFvw6FuLjwvQWxlcnQ+PFBhbmVsPjxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RBdWRpdEV2ZW50c1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiTmjhuq10IGvDvSBob+G6oXQgxJHhu5luZ1wiIHJvd3M9e2xpc3QuZGF0YS5kYXRhfSByb3dLZXk9e2EgPT4gYS5pZH0gY29sdW1ucz17W1xuICAgIHsga2V5OiAndGltZScsIGxhYmVsOiAnVGjhu51pIGdpYW4nLCByZW5kZXI6IGEgPT4gZGF0ZVRpbWUoYS5vY2N1cnJlZEF0LCBzaG9wLnRpbWV6b25lKSB9LCB7IGtleTogJ2FjdG9yJywgbGFiZWw6ICdOZ8aw4budaSB0aOG7sWMgaGnhu4duJywgcmVuZGVyOiBhID0+IGBNw6MgbmjDom4gc+G7sTogJHthLmFjdG9ySWR9YCB9LCB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnVGhhbyB0w6FjJywgcmVuZGVyOiBhID0+IGEuYWN0aW9uIH0sIHsga2V5OiAnc291cmNlJywgbGFiZWw6ICfEkOG7kWkgdMaw4bujbmcnLCByZW5kZXI6IGEgPT4gYCR7YS5yZXNvdXJjZS50eXBlfSDCtyBNw6MgxJHhu5FpIHTGsOG7o25nOiAke2EucmVzb3VyY2UuaWR9YCB9LCB7IGtleTogJ3N1bW1hcnknLCBsYWJlbDogJ0vhur90IHF14bqjJywgcmVuZGVyOiBhID0+IGEuc3VtbWFyeSB9LCB7IGtleTogJ3RyYWNlJywgbGFiZWw6ICdNw6MgdHJ1eSB24bq/dCcsIHJlbmRlcjogYSA9PiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPnthLnJlcXVlc3RJZH08L1R5cG9ncmFwaHk+IH1cbl19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PC8+OyB9XG5leHBvcnQgZnVuY3Rpb24gUHJpdmFjeVBhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IHBvbGljeSA9IHVzZUFwaSgnZ2V0UHJpdmFjeVBvbGljeScpO1xuICAgIGNvbnN0IHJlcXVlc3RzID0gdXNlQXBpKCdsaXN0UHJpdmFjeVJlcXVlc3RzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0UHJpdmFjeVJlcXVlc3RzJykgfSk7XG4gICAgY29uc3Qgc2F2ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZVByaXZhY3lQb2xpY3knLCBbJ2dldFByaXZhY3lQb2xpY3knXSk7XG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUHJpdmFjeVJlcXVlc3QnLCBbJ2xpc3RQcml2YWN5UmVxdWVzdHMnXSk7XG4gICAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoJycpLCBbbm90ZSwgc2V0Tm90ZV0gPSB1c2VTdGF0ZSgnJyksIFtjdXN0b21lcklkLCBzZXRDdXN0b21lcl0gPSB1c2VTdGF0ZSgnJyksIFtraW5kLCBzZXRLaW5kXSA9IHVzZVN0YXRlPCdleHBvcnQnIHwgJ2RlbGV0ZSc+KCdleHBvcnQnKSwgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKCcnKSwgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbZGF5c1RvdWNoZWQsIHNldERheXNUb3VjaGVkXSA9IHVzZVN0YXRlKGZhbHNlKSwgW25vdGVUb3VjaGVkLCBzZXROb3RlVG91Y2hlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtwb2xpY3lTdWJtaXR0ZWQsIHNldFBvbGljeVN1Ym1pdHRlZF0gPSB1c2VTdGF0ZShmYWxzZSksIFtwb2xpY3lTYXZlZCwgc2V0UG9saWN5U2F2ZWRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGNhblJlYWRDdXN0b21lcnMgPSB1c2VDYW4oJ2N1c3RvbWVycy5yZWFkJyk7XG4gICAgY29uc3QgW2N1c3RvbWVyU2VhcmNoSW5wdXQsIHNldEN1c3RvbWVyU2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoJycpLCBbY3VzdG9tZXJTZWFyY2gsIHNldEN1c3RvbWVyU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldEN1c3RvbWVyU2VhcmNoKGN1c3RvbWVyU2VhcmNoSW5wdXQudHJpbSgpKSwgMjUwKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xuICAgIH0sIFtjdXN0b21lclNlYXJjaElucHV0XSk7XG4gICAgY29uc3QgY3VzdG9tZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lcnMnLCB7IHF1ZXJ5OiB7IHE6IGN1c3RvbWVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0sIGNhblJlYWRDdXN0b21lcnMpO1xuICAgIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwgPSB1c2VBcGkoJ2dldEN1c3RvbWVyJywgeyBwYXRoOiB7IGN1c3RvbWVySWQgfSB9LCBjYW5SZWFkQ3VzdG9tZXJzICYmICEhY3VzdG9tZXJJZCk7XG4gICAgY29uc3Qgc2VsZWN0ZWRDdXN0b21lciA9IGN1c3RvbWVycy5kYXRhPy5kYXRhLmZpbmQoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IGN1c3RvbWVySWQpIHx8IHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwuZGF0YT8uZGF0YTtcbiAgICBjb25zdCBlZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XG4gICAgICAgIGlkZW50aXR5OiBgJHtzaG9wLmlkfTpwcml2YWN5YCxcbiAgICAgICAgc291cmNlOiBwb2xpY3kuZGF0YSA/IHsgdmVyc2lvbjogcG9saWN5LmRhdGEuZGF0YS52ZXJzaW9uLCB2YWx1ZXM6IHsgZGF5czogcG9saWN5LmRhdGEuZGF0YS5jaGF0UmV0ZW50aW9uRGF5cz8udG9TdHJpbmcoKSB8fCAnJywgbm90ZTogcG9saWN5LmRhdGEuZGF0YS5qdXJpc2RpY3Rpb25Ob3RlIH0gfSA6IHVuZGVmaW5lZCxcbiAgICAgICAgZHJhZnQ6IHsgZGF5cywgbm90ZSB9LFxuICAgICAgICBhcHBseTogdmFsdWVzID0+IHsgc2V0RGF5cyh2YWx1ZXMuZGF5cyk7IHNldE5vdGUodmFsdWVzLm5vdGUpOyB9LFxuICAgICAgICByZWZyZXNoOiAoKSA9PiBwb2xpY3kucmVmZXRjaCh7IHRocm93T25FcnJvcjogdHJ1ZSB9KSxcbiAgICB9KTtcbiAgICBjb25zdCBwb2xpY3lGb3JtID0gdXNlRHJhZnRGb3JtKGVkaXRvci5kaXJ0eSk7XG4gICAgY29uc3QgZGF5c0Vycm9yID0gIS9eXFxkKyQvLnRlc3QoZGF5cykgfHwgTnVtYmVyKGRheXMpIDwgMSB8fCBOdW1iZXIoZGF5cykgPiAzNjUwMCA/ICdOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gMzYuNTAwIG5nw6B5LicgOiAnJztcbiAgICBjb25zdCBub3RlRXJyb3IgPSBjb2RlUG9pbnRMZW5ndGgobm90ZS50cmltKCkpIDwgNSB8fCBjb2RlUG9pbnRMZW5ndGgobm90ZSkgPiAyMDAwID8gJ05o4bqtcCBjxINuIGPhu6kgdOG7qyA1IMSR4bq/biAyLjAwMCBrw70gdOG7sS4nIDogJyc7XG4gICAgY29uc3Qgc2hvd0RheXNFcnJvciA9IChkYXlzVG91Y2hlZCB8fCBwb2xpY3lTdWJtaXR0ZWQpICYmICEhZGF5c0Vycm9yO1xuICAgIGNvbnN0IHNob3dOb3RlRXJyb3IgPSAobm90ZVRvdWNoZWQgfHwgcG9saWN5U3VibWl0dGVkKSAmJiAhIW5vdGVFcnJvcjtcbiAgICBjb25zdCBzYXZlUG9saWN5ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRQb2xpY3lTdWJtaXR0ZWQodHJ1ZSk7XG4gICAgICAgIGlmIChkYXlzRXJyb3IgfHwgbm90ZUVycm9yIHx8ICFlZGl0b3IuZGlydHkpIHJldHVybjtcbiAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBlZGl0b3IucHJlcGFyZSgpOyBpZiAoIXByZXBhcmVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgZGF5cywgbm90ZSB9O1xuICAgICAgICBzZXRQb2xpY3lTYXZlZCgnJyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzYXZlLmV4ZWN1dGUoeyB2ZXJzaW9uOiBwcmVwYXJlZC52ZXJzaW9uLCBib2R5OiB7XG4gICAgICAgICAgICAgICAgLi4uKHByZXBhcmVkLnBhdGNoLmRheXMgIT09IHVuZGVmaW5lZCA/IHsgY2hhdFJldGVudGlvbkRheXM6IE51bWJlcihwcmVwYXJlZC5wYXRjaC5kYXlzKSB9IDoge30pLFxuICAgICAgICAgICAgICAgIC4uLihwcmVwYXJlZC5wYXRjaC5ub3RlICE9PSB1bmRlZmluZWQgPyB7IGp1cmlzZGljdGlvbk5vdGU6IHByZXBhcmVkLnBhdGNoLm5vdGUgfSA6IHt9KSxcbiAgICAgICAgICAgIH0gfSk7XG4gICAgICAgICAgICBjb25zdCBjbGVhbiA9IGVkaXRvci5jb21taXR0ZWQoeyB2ZXJzaW9uOiByZXN1bHQuZGF0YS52ZXJzaW9uLCB2YWx1ZXM6IHsgZGF5czogcmVzdWx0LmRhdGEuY2hhdFJldGVudGlvbkRheXM/LnRvU3RyaW5nKCkgfHwgJycsIG5vdGU6IHJlc3VsdC5kYXRhLmp1cmlzZGljdGlvbk5vdGUgfSB9LCBzdWJtaXR0ZWQpO1xuICAgICAgICAgICAgc2V0UG9saWN5U2F2ZWQoY2xlYW4gPyAnxJDDoyBsxrB1IGLhuqNuIG5ow6FwIGNow61uaCBzw6FjaCBsxrB1IHRy4buvLicgOiAnxJDDoyBsxrB1IHBo4bqnbiB0aGF5IMSR4buVaSDEkcOjIGfhu61pOyBjaOG7iW5oIHPhu61hIG3hu5tpIHbhuqtuIGNoxrBhIMSRxrDhu6NjIGzGsHUuJyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7IGVkaXRvci5mYWlsZWQoZXJyb3IpOyB9XG4gICAgfTtcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIlF1eeG7gW4gcmnDqm5nIHTGsCAmIHbDsm5nIMSR4budaSBk4buvIGxp4buHdVwiIHN1YnRpdGxlPVwiVMOhY2ggY+G6pXUgaMOsbmggbmjDoXAgduG7m2kgY2jDrW5oIHPDoWNoIMSRxrDhu6NjIGR1eeG7h3Q7IHnDqnUgY+G6p3UgeMOzYSBraMO0bmcgdOG7sSB2xrDhu6N0IMSRaeG7gXUga2nhu4duIGzGsHUgY2jhu6luZyB04burLlwiLz48U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMWZyIDEuNGZyJyB9fT48UGFuZWwgdGl0bGU9XCJDaMOtbmggc8OhY2ggbMawdSB0cuG7r1wiIGJvZHlNb2RlPVwiaW5zZXRcIj48UXVlcnlTdGF0ZSBxdWVyeT17cG9saWN5fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj48Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtwb2xpY3lGb3JtfSBvblN1Ym1pdD17ZXZlbnQgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyB2b2lkIHNhdmVQb2xpY3koKTsgfX0+PEVycm9yTm90aWNlIGVycm9yPXtzYXZlLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17eyBkYXlzOiAnU+G7kSBuZ8OgeSBsxrB1IGjhu5lpIHRob+G6oWknLCBub3RlOiAnQ8SDbiBj4bupIC8gdGjhu4sgdHLGsOG7nW5nIMOhcCBk4bulbmcnIH19IGJ1c3k9e3NhdmUucGVuZGluZ30vPntwb2xpY3lTYXZlZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPntwb2xpY3lTYXZlZH08L0FsZXJ0Pn17cG9saWN5LmRhdGEgJiYgPFN0YXR1cyB2YWx1ZT17cG9saWN5LmRhdGEuZGF0YS5zdGF0dXN9Lz59PFRleHRGaWVsZCBsYWJlbD1cIlPhu5EgbmfDoHkgbMawdSBo4buZaSB0aG/huqFpXCIgdmFsdWU9e2RheXN9IG9uQmx1cj17KCkgPT4gc2V0RGF5c1RvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtlID0+IHsgc2V0RGF5cyhlLnRhcmdldC52YWx1ZSk7IHNldERheXNUb3VjaGVkKHRydWUpOyBzZXRQb2xpY3lTYXZlZCgnJyk7IH19IHR5cGU9XCJudW1iZXJcIiBpbnB1dFByb3BzPXt7IG1pbjogMSwgbWF4OiAzNjUwMCwgc3RlcDogMSB9fSBlcnJvcj17c2hvd0RheXNFcnJvcn0gaGVscGVyVGV4dD17c2hvd0RheXNFcnJvciA/IGRheXNFcnJvciA6ICdOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gMzYuNTAwIG5nw6B5Lid9Lz48VGV4dEZpZWxkIGxhYmVsPVwiQ8SDbiBj4bupIC8gdGjhu4sgdHLGsOG7nW5nIMOhcCBk4bulbmdcIiBtdWx0aWxpbmUgbWluUm93cz17NH0gdmFsdWU9e25vdGV9IG9uQmx1cj17KCkgPT4gc2V0Tm90ZVRvdWNoZWQodHJ1ZSl9IG9uQ2hhbmdlPXtlID0+IHsgc2V0Tm90ZShlLnRhcmdldC52YWx1ZSk7IHNldE5vdGVUb3VjaGVkKHRydWUpOyBzZXRQb2xpY3lTYXZlZCgnJyk7IH19IGVycm9yPXtzaG93Tm90ZUVycm9yfSBoZWxwZXJUZXh0PXtzaG93Tm90ZUVycm9yID8gbm90ZUVycm9yIDogJ1Thu5FpIHRoaeG7g3UgNSB2w6AgdOG7kWkgxJFhIDIuMDAwIGvDvSB04buxLid9Lz48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByaXZhY3kubWFuYWdlXCIgdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtzYXZlLnBlbmRpbmd9IGRpc2FibGVkPXshcG9saWN5LmRhdGEgfHwgIWVkaXRvci5kaXJ0eSB8fCBzYXZlLnBlbmRpbmcgfHwgISFkYXlzRXJyb3IgfHwgISFub3RlRXJyb3J9PkzGsHUgYuG6o24gbmjDoXAgY2jDrW5oIHPDoWNoPC9NdXRhdGlvbkJ1dHRvbj48QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+S2jDtG5nIHThu7EgY2jhu6luZyBuaOG6rW4gdHXDom4gdGjhu6cgcGjDoXAgbHXhuq10LiBQaMOqIGR1eeG7h3QgecOqdSBj4bqndSB4w7NhIGPhuqduIHjDoWMgdGjhu7FjIG7Dom5nIGNhbyBj4bunYSBiYWNrZW5kOyBsdeG7k25nIE9JREMgc3RlcC11cCBjaMawYSDEkcaw4bujYyB4w6FjIG1pbmggdHJvbmcgZnJvbnRlbmQgbsOgeS48L0FsZXJ0PjwvRm9ybUZpZWxkcz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD48UGFuZWwgdGl0bGU9XCJZw6p1IGPhuqd1IGPhu6dhIGtow6FjaFwiIGFjdGlvbj17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcml2YWN5Lm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW4odHJ1ZSl9PlThuqFvIHnDqnUgY+G6p3U8L011dGF0aW9uQnV0dG9uPn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e3JlcXVlc3RzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57cmVxdWVzdHMuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJZw6p1IGPhuqd1IHF1eeG7gW4gcmnDqm5nIHTGsFwiIHJvd3M9e3JlcXVlc3RzLmRhdGEuZGF0YX0gcm93S2V5PXtyID0+IHIuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiByID0+IGBNw6Mga2jDoWNoIGjDoG5nOiAke3IuY3VzdG9tZXJJZH1gIH0sIHsga2V5OiAna2luZCcsIGxhYmVsOiAnWcOqdSBj4bqndScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLmtpbmR9Lz4gfSwgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLnN0YXR1c30vPiB9LCB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiByID0+IHIucmVhc29uIH1cbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e3JlcXVlc3RzLmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD48L1NlY3Rpb25HcmlkPjxDb25zZW50TWFuYWdlbWVudCBjdXN0b21lcnM9e2N1c3RvbWVycy5kYXRhPy5kYXRhIHx8IFtdfSBjYW5SZWFkQ3VzdG9tZXJzPXtjYW5SZWFkQ3VzdG9tZXJzfSBzaG9wSWQ9e3Nob3AuaWR9IC8+XG4gPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9XCJZw6p1IGPhuqd1IGThu68gbGnhu4d1IGPDoSBuaMOiblwiIG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfSBidXN5PXtjcmVhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjdXN0b21lcklkIHx8IGNvZGVQb2ludExlbmd0aChyZWFzb24udHJpbSgpKSA8IDUgfHwgY3JlYXRlLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IGtpbmQsIGN1c3RvbWVySWQsIHJlYXNvbiB9IH0pO1xuICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICB9XG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+VOG6oW8gecOqdSBj4bqndSBjaOG7nSBkdXnhu4d0PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvciB8fCBjdXN0b21lcnMuZXJyb3IgfHwgc2VsZWN0ZWRDdXN0b21lckRldGFpbC5lcnJvcn0vPjxGb3JtRmllbGRzID48VGV4dEZpZWxkIGxhYmVsPVwiVMOsbSBraMOhY2ggaMOgbmdcIiB2YWx1ZT17Y3VzdG9tZXJTZWFyY2hJbnB1dH0gb25DaGFuZ2U9e2UgPT4gc2V0Q3VzdG9tZXJTZWFyY2hJbnB1dChlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY2FuUmVhZEN1c3RvbWVyc30gaGVscGVyVGV4dD1cIlTDrG0gdGhlbyBtw6MgaG/hurdjIHTDqm4ga2jDoWNoOyBBUEkgaOG7lyB0cuG7oyB0w6xtIGtp4bq/bSB2w6AgY3Vyc29yLlwiLz48VGV4dEZpZWxkIGxhYmVsPVwiS2jDoWNoIGjDoG5nXCIgc2VsZWN0IHZhbHVlPXtjdXN0b21lcklkfSBvbkNoYW5nZT17ZSA9PiBzZXRDdXN0b21lcihlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY2FuUmVhZEN1c3RvbWVycyB8fCAoY3VzdG9tZXJzLmlzUGVuZGluZyAmJiAhY3VzdG9tZXJzLmRhdGEpfT57Y3VzdG9tZXJJZCAmJiAhY3VzdG9tZXJzLmRhdGE/LmRhdGEuc29tZShjdXN0b21lciA9PiBjdXN0b21lci5pZCA9PT0gY3VzdG9tZXJJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXtjdXN0b21lcklkfT57c2VsZWN0ZWRDdXN0b21lcj8uZGlzcGxheU5hbWUgfHwgKHNlbGVjdGVkQ3VzdG9tZXJEZXRhaWwuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIGtow6FjaCDEkcOjIGNo4buNbuKApicgOiBjdXN0b21lcklkKX08L01lbnVJdGVtPn17Y3VzdG9tZXJzLmRhdGE/LmRhdGEubWFwKGMgPT4gPE1lbnVJdGVtIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PntjLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJraMOhY2ggaMOgbmdcIiBsb2FkZWRDb3VudD17Y3VzdG9tZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtjdXN0b21lcnMuaGFzTW9yZX0gYnVzeT17Y3VzdG9tZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2N1c3RvbWVycy5sb2FkTW9yZX0vPntjdXN0b21lcnMuaXNFcnJvciAmJiA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAoY3VzdG9tZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gY3VzdG9tZXJzLmxvYWRNb3JlKCkgOiBjdXN0b21lcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCBraMOhY2g8L0J1dHRvbj59PFRleHRGaWVsZCBsYWJlbD1cIkxv4bqhaSB5w6p1IGPhuqd1XCIgc2VsZWN0IHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZSA9PiBzZXRLaW5kKGUudGFyZ2V0LnZhbHVlIGFzIHR5cGVvZiBraW5kKX0+PE1lbnVJdGVtIHZhbHVlPVwiZXhwb3J0XCI+WHXhuqV0IGThu68gbGnhu4d1IGPDoSBuaMOibjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiZGVsZXRlXCI+WMOzYSBk4buvIGxp4buHdSBjw6EgbmjDom48L01lbnVJdGVtPjwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gLyB4w6FjIG1pbmggecOqdSBj4bqndVwiIG11bHRpbGluZSBtaW5Sb3dzPXszfSB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfS8+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz48Lz47XG59XG50eXBlIENvbnNlbnRDdXN0b21lciA9IFBpY2s8Q3VzdG9tZXIsICdpZCcgfCAnZGlzcGxheU5hbWUnIHwgJ2VtYWlsJyB8ICdwaG9uZScgfCAnZXh0ZXJuYWxJZGVudGl0eScgfCAncmVkYWN0ZWRGaWVsZHMnPjtcbmNvbnN0IGNvbnNlbnRDb3B5VmVyc2lvbiA9IDE7XG5jb25zdCBjb25zZW50UmVjb25maXJtQ29weSA9ICdC4bqhbiBjw7MgxJHhu5NuZyDDvSBuaOG6rW4gbuG7mWkgZHVuZyB0aeG6v3AgdGjhu4sgdOG7qyBj4butYSBow6BuZyBxdWEga8OqbmggxJHDoyBjaOG7jW4ga2jDtG5nPyBC4bqhbiBjw7MgdGjhu4MgcsO6dCBs4bqhaSDEkeG7k25nIMO9IGLhuqV0IGPhu6kgbMO6YyBuw6BvLiBUaW4gbmjhuq9uIHBo4bulYyB24bulIMSRxqFuIGjDoG5nIGtow7RuZyB0aGF5IMSR4buVaS4nO1xuZnVuY3Rpb24gQ29uc2VudE1hbmFnZW1lbnQoeyBjdXN0b21lcnMsIGNhblJlYWRDdXN0b21lcnMsIHNob3BJZCB9OiB7IGN1c3RvbWVyczogQ29uc2VudEN1c3RvbWVyW107IGNhblJlYWRDdXN0b21lcnM6IGJvb2xlYW47IHNob3BJZDogc3RyaW5nIH0pIHtcbiAgICBjb25zdCBjb25zZW50TGlzdCA9IHVzZVBhZ2VkQXBpKCdsaXN0Q3VzdG9tZXJDb25zZW50cycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdEN1c3RvbWVyQ29uc2VudHMnKSB9KTtcbiAgICBjb25zdCBjaGFsbGVuZ2VMaXN0ID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lckNvbnNlbnRDaGFsbGVuZ2VzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0Q3VzdG9tZXJDb25zZW50Q2hhbGxlbmdlcycpIH0pO1xuICAgIGNvbnN0IGNyZWF0ZUNoYWxsZW5nZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUN1c3RvbWVyQ29uc2VudENoYWxsZW5nZScsIFsnbGlzdEN1c3RvbWVyQ29uc2VudENoYWxsZW5nZXMnXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJJZCwgc2V0U2VsZWN0ZWRDdXN0b21lcklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbY2hhbm5lbCwgc2V0Q2hhbm5lbF0gPSB1c2VTdGF0ZTwnbWVzc2VuZ2VyJyB8ICdlbWFpbCcgfCAnc21zJz4oJ21lc3NlbmdlcicpO1xuICAgIGNvbnN0IFtjcmVhdGVkLCBzZXRDcmVhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBjdXN0b21lcklkID0gY3VzdG9tZXJzLnNvbWUoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IHNlbGVjdGVkQ3VzdG9tZXJJZCkgPyBzZWxlY3RlZEN1c3RvbWVySWQgOiBjdXN0b21lcnNbMF0/LmlkIHx8ICcnO1xuICAgIGNvbnN0IGN1c3RvbWVyID0gY3VzdG9tZXJzLmZpbmQoY2FuZGlkYXRlID0+IGNhbmRpZGF0ZS5pZCA9PT0gY3VzdG9tZXJJZCk7XG4gICAgY29uc3QgcmVkYWN0ZWQgPSBjdXN0b21lcj8ucmVkYWN0ZWRGaWVsZHMgfHwgW107XG4gICAgY29uc3QgYXZhaWxhYmxlQ2hhbm5lbHMgPSBbXG4gICAgICAgIHsgdmFsdWU6ICdtZXNzZW5nZXInIGFzIGNvbnN0LCBsYWJlbDogJ01lc3NlbmdlcicsIGF2YWlsYWJsZTogQm9vbGVhbihjdXN0b21lcj8uZXh0ZXJuYWxJZGVudGl0eSkgfSxcbiAgICAgICAgeyB2YWx1ZTogJ3NtcycgYXMgY29uc3QsIGxhYmVsOiAnU01TJywgYXZhaWxhYmxlOiBCb29sZWFuKGN1c3RvbWVyPy5waG9uZSAmJiAhcmVkYWN0ZWQuaW5jbHVkZXMoJ3Bob25lJykpIH0sXG4gICAgICAgIHsgdmFsdWU6ICdlbWFpbCcgYXMgY29uc3QsIGxhYmVsOiAnRW1haWwnLCBhdmFpbGFibGU6IEJvb2xlYW4oY3VzdG9tZXI/LmVtYWlsICYmICFyZWRhY3RlZC5pbmNsdWRlcygnZW1haWwnKSkgfSxcbiAgICBdLmZpbHRlcihpdGVtID0+IGl0ZW0uYXZhaWxhYmxlKTtcbiAgICBjb25zdCBzZWxlY3RlZENoYW5uZWwgPSBhdmFpbGFibGVDaGFubmVscy5maW5kKGl0ZW0gPT4gaXRlbS52YWx1ZSA9PT0gY2hhbm5lbCk/LnZhbHVlIHx8IGF2YWlsYWJsZUNoYW5uZWxzWzBdPy52YWx1ZSB8fCBjaGFubmVsO1xuICAgIGNvbnN0IGNoYW5uZWxJc0F2YWlsYWJsZSA9IGF2YWlsYWJsZUNoYW5uZWxzLnNvbWUoaXRlbSA9PiBpdGVtLnZhbHVlID09PSBzZWxlY3RlZENoYW5uZWwpO1xuICAgIGNvbnN0IHJlcXVlc3RSZWNvbmZpcm1hdGlvbiA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFjdXN0b21lcklkIHx8ICFjYW5SZWFkQ3VzdG9tZXJzIHx8ICFjaGFubmVsSXNBdmFpbGFibGUpIHJldHVybjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZUNoYWxsZW5nZS5leGVjdXRlKHsgcGF0aDogeyBjdXN0b21lcklkIH0sIGJvZHk6IHsgcHVycG9zZTogJ21hcmtldGluZycsIGNoYW5uZWw6IHNlbGVjdGVkQ2hhbm5lbCwgbWVzc2FnZTogY29uc2VudFJlY29uZmlybUNvcHksIGNvbnRlbnRWZXJzaW9uOiBjb25zZW50Q29weVZlcnNpb24gfSB9KTtcbiAgICAgICAgICAgIHNldENyZWF0ZWQodHJ1ZSk7XG4gICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChbY2hhbGxlbmdlTGlzdC5yZWZldGNoKCksIGNvbnNlbnRMaXN0LnJlZmV0Y2goKV0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHsgLyogRXJyb3JOb3RpY2Uga2VlcHMgdGhlIEFQSSByZXN1bHQgdmlzaWJsZS4gKi8gfVxuICAgIH07XG4gICAgcmV0dXJuIDxQYW5lbCB0aXRsZT1cIkNvbnNlbnQgbWFya2V0aW5nIHbDoCB4w6FjIG5o4bqtbiBs4bqhaVwiIGJlZm9yZUdhcD1cInNlY3Rpb25cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgIDxGb3JtRmllbGRzPlxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkNvbnNlbnQgxJHGsOG7o2MgbMawdSB0aGVvIGtow6FjaCwgbeG7pWMgxJHDrWNoLCBrw6puaCwgcGhpw6puIGLhuqNuIHbDoCBs4buLY2ggc+G7rS4gVOG6oW8gecOqdSBj4bqndSBjaOG7iSB04bqhbyBjaGFsbGVuZ2UgxJFhbmcgY2jhu507IGtow7RuZyBi4bqtdCBjb25zZW50LiBNw7RpIHRyxrDhu51uZyBsb2NhbCBraMO0bmcgY8OzIG5ow6AgY3VuZyBj4bqlcCBn4butaSBlbWFpbC9TTVMvTWV0YSBuw6puIGtow7RuZyBraOG6s25nIMSR4buLbmggxJHDoyBn4butaSBsaW5rIHRo4bqtdC48L0FsZXJ0PlxuICAgICAgICAgICAge2NhblJlYWRDdXN0b21lcnMgPyA8PlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiS2jDoWNoIGjDoG5nXCIgdmFsdWU9e2N1c3RvbWVySWR9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldFNlbGVjdGVkQ3VzdG9tZXJJZChldmVudC50YXJnZXQudmFsdWUpOyBzZXRDcmVhdGVkKGZhbHNlKTsgfX0gZGlzYWJsZWQ9eyFjdXN0b21lcn0+XG4gICAgICAgICAgICAgICAgICAgIHtjdXN0b21lcnMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkvDqm5oIGPhuqduIHjDoWMgbmjhuq1uXCIgdmFsdWU9e3NlbGVjdGVkQ2hhbm5lbH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0Q2hhbm5lbChldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIGNoYW5uZWwpOyBzZXRDcmVhdGVkKGZhbHNlKTsgfX0gZGlzYWJsZWQ9eyFhdmFpbGFibGVDaGFubmVscy5sZW5ndGh9PlxuICAgICAgICAgICAgICAgICAgICB7YXZhaWxhYmxlQ2hhbm5lbHMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS52YWx1ZX0gdmFsdWU9e2l0ZW0udmFsdWV9PntpdGVtLmxhYmVsfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD17YE7hu5lpIGR1bmcgdiR7Y29uc2VudENvcHlWZXJzaW9ufWB9Pntjb25zZW50UmVjb25maXJtQ29weX08L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgeyFhdmFpbGFibGVDaGFubmVscy5sZW5ndGggJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPktow7RuZyBjw7Mga8OqbmggbGnDqm4gaOG7hyBjw7JuIHF1eeG7gW4geGVtIGNobyBraMOhY2ggxJHDoyBjaOG7jW4uPC9BbGVydD59XG4gICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcml2YWN5Lm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtjcmVhdGVDaGFsbGVuZ2UucGVuZGluZ30gZGlzYWJsZWQ9eyFjdXN0b21lcklkIHx8ICFjaGFubmVsSXNBdmFpbGFibGUgfHwgIWNhblJlYWRDdXN0b21lcnN9IG9uQ2xpY2s9eygpID0+IHZvaWQgcmVxdWVzdFJlY29uZmlybWF0aW9uKCl9PlThuqFvIHnDqnUgY+G6p3UgeMOhYyBuaOG6rW4gbOG6oWk8L011dGF0aW9uQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlQ2hhbGxlbmdlLmVycm9yIHx8IGNvbnNlbnRMaXN0LmVycm9yIHx8IGNoYWxsZW5nZUxpc3QuZXJyb3J9Lz5cbiAgICAgICAgICAgICAgICB7Y3JlYXRlZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPsSQw6MgdOG6oW8gY2hhbGxlbmdlIGNo4budIGtow6FjaCB4w6FjIG5o4bqtbi4gVHLhuqFuZyB0aMOhaSBuw6B5IGNoxrBhIHBo4bqjaSBjb25zZW50IMSRxrDhu6NjIGPhuqVwLjwvQWxlcnQ+fVxuICAgICAgICAgICAgPC8+IDogPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkPhuqduIHF1eeG7gW4gY3VzdG9tZXJzLnJlYWQgxJHhu4MgY2jhu41uIGtow6FjaC4gRGFuaCBzw6FjaCB2w6AgdGjDtG5nIHRpbiBuaOG6rW4gZOG6oW5nIMSRxrDhu6NjIOG6qW4uPC9BbGVydD59XG4gICAgICAgICAgICA8RmllbGRHcm91cCByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQuG6o24gZ2hpIGNvbnNlbnQgaGnhu4duIHThuqFpXCI+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIj5C4bqjbiBnaGkgY29uc2VudCBoaeG7h24gdOG6oWk8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2NvbnNlbnRMaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57Y29uc2VudExpc3QuZGF0YSAmJiA8PlxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiTOG7i2NoIHPhu60gY29uc2VudCBraMOhY2ggaMOgbmdcIiByb3dzPXtjb25zZW50TGlzdC5kYXRhLmRhdGF9IHJvd0tleT17cmVjb3JkID0+IHJlY29yZC5pZH0gY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiByZWNvcmQgPT4gYE3DoyBraMOhY2ggaMOgbmc6ICR7cmVjb3JkLmN1c3RvbWVySWR9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwdXJwb3NlJywgbGFiZWw6ICdN4bulYyDEkcOtY2gnLCByZW5kZXI6IHJlY29yZCA9PiBidXNpbmVzc0xhYmVsKHJlY29yZC5wdXJwb3NlKSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjaGFubmVsJywgbGFiZWw6ICdLw6puaCcsIHJlbmRlcjogcmVjb3JkID0+IGJ1c2luZXNzTGFiZWwocmVjb3JkLmNoYW5uZWwpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogcmVjb3JkID0+IDxTdGF0dXMgdmFsdWU9e3JlY29yZC5zdGF0dXN9IGRvbWFpbj1cImNvbnNlbnRcIi8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3ZlcnNpb24nLCBsYWJlbDogJ1BoacOqbiBi4bqjbicsIHJlbmRlcjogcmVjb3JkID0+IHJlY29yZC52ZXJzaW9uIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2V2aWRlbmNlJywgbGFiZWw6ICdC4bqxbmcgY2jhu6luZyBn4bqnbiBuaOG6pXQnLCByZW5kZXI6IHJlY29yZCA9PiB7IGNvbnN0IGxhdGVzdCA9IHJlY29yZC5oaXN0b3J5LmF0KC0xKTsgcmV0dXJuIGxhdGVzdCA/IGAke2J1c2luZXNzTGFiZWwobGF0ZXN0LmFjdGlvbiwgJ2NvbnNlbnQnKX0gwrcgJHtsYXRlc3QuZXZpZGVuY2VUeXBlfSDCtyAke2xhdGVzdC5ldmlkZW5jZVJlZmVyZW5jZSB8fCAn4oCUJ31gIDogJ0NoxrBhIGPDsyc7IH0gfSxcbiAgICAgICAgICAgICAgICAgICAgXX0vPlxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17Y29uc2VudExpc3QuZGF0YS5wYWdlfS8+XG4gICAgICAgICAgICAgICAgPC8+fTwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgIDwvRmllbGRHcm91cD5cbiAgICAgICAgICAgIDxGaWVsZEdyb3VwIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJZw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budXCI+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIj5Zw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtjaGFsbGVuZ2VMaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57Y2hhbGxlbmdlTGlzdC5kYXRhICYmIDw+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJZw6p1IGPhuqd1IHjDoWMgbmjhuq1uIMSRYW5nIGNo4budXCIgcm93cz17Y2hhbGxlbmdlTGlzdC5kYXRhLmRhdGF9IHJvd0tleT17Y2hhbGxlbmdlID0+IGNoYWxsZW5nZS5pZH0gY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjdXN0b21lcicsIGxhYmVsOiAnS2jDoWNoJywgcmVuZGVyOiBjaGFsbGVuZ2UgPT4gYE3DoyBraMOhY2ggaMOgbmc6ICR7Y2hhbGxlbmdlLmN1c3RvbWVySWR9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwdXJwb3NlJywgbGFiZWw6ICdN4bulYyDEkcOtY2gnLCByZW5kZXI6IGNoYWxsZW5nZSA9PiBidXNpbmVzc0xhYmVsKGNoYWxsZW5nZS5wdXJwb3NlKSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjaGFubmVsJywgbGFiZWw6ICdLw6puaCcsIHJlbmRlcjogY2hhbGxlbmdlID0+IGJ1c2luZXNzTGFiZWwoY2hhbGxlbmdlLmNoYW5uZWwpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnWcOqdSBj4bqndScsIHJlbmRlcjogY2hhbGxlbmdlID0+IGNoYWxsZW5nZS5hY3Rpb24gPT09ICd3aXRoZHJhdycgPyAnTmfhu6tuZyBtYXJrZXRpbmcnIDogJ1jDoWMgbmjhuq1uIG1hcmtldGluZycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnc3RhdHVzJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBjaGFsbGVuZ2UgPT4gPFN0YXR1cyB2YWx1ZT17Y2hhbGxlbmdlLnN0YXR1c30gZG9tYWluPVwiY29uc2VudFwiLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXhwaXJlcycsIGxhYmVsOiAnSOG6v3QgaOG6oW4nLCByZW5kZXI6IGNoYWxsZW5nZSA9PiBkYXRlVGltZShjaGFsbGVuZ2UuZXhwaXJlc0F0LCAnQXNpYS9Ib19DaGlfTWluaCcpIH0sXG4gICAgICAgICAgICAgICAgICAgIF19Lz5cbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VyIHBhZ2U9e2NoYWxsZW5nZUxpc3QuZGF0YS5wYWdlfS8+XG4gICAgICAgICAgICAgICAgPC8+fTwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgIDwvRmllbGRHcm91cD5cbiAgICAgICAgICAgIHtjYW5SZWFkQ3VzdG9tZXJzICYmIDxCdXR0b24gY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz17YC9zLyR7c2hvcElkfS9jdXN0b21lcnNgfSBzaXplPVwic21hbGxcIiBzeD17eyBhbGlnblNlbGY6ICdmbGV4LXN0YXJ0JyB9fT5N4bufIGRhbmggc8OhY2gga2jDoWNoPC9CdXR0b24+fVxuICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgPC9QYW5lbD47XG59XG5mdW5jdGlvbiBzYXZlZENvbnNlbnRDaGFsbGVuZ2UodmFsdWU6IHVua25vd24pOiBQdWJsaWNDb25zZW50Q2hhbGxlbmdlVmlldyB8IG51bGwge1xuICAgIHRyeSB7IGFzc2VydFNjaGVtYTxQdWJsaWNDb25zZW50Q2hhbGxlbmdlVmlldz4oJ1B1YmxpY0NvbnNlbnRDaGFsbGVuZ2VWaWV3JywgdmFsdWUpOyByZXR1cm4gdmFsdWU7IH1cbiAgICBjYXRjaCB7IHJldHVybiBudWxsOyB9XG59XG5leHBvcnQgZnVuY3Rpb24gQ29uc2VudENvbmZpcm1hdGlvblBhZ2UoKSB7XG4gICAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHRva2VuID0gcGFyYW1zLmdldCgndG9rZW4nKSB8fCAnJztcbiAgICBjb25zdCBbY2hhbGxlbmdlLCBzZXRDaGFsbGVuZ2VdID0gdXNlU3RhdGU8UHVibGljQ29uc2VudENoYWxsZW5nZVZpZXcgfCBudWxsPigoKSA9PiBzYXZlZENvbnNlbnRDaGFsbGVuZ2UoKGxvY2F0aW9uLnN0YXRlIGFzIHsgY29uc2VudENoYWxsZW5nZT86IHVua25vd24gfSB8IG51bGwpPy5jb25zZW50Q2hhbGxlbmdlKSk7XG4gICAgY29uc3QgW2NvbmZpcm1hdGlvbiwgc2V0Q29uZmlybWF0aW9uXSA9IHVzZVN0YXRlPENvbnNlbnRDb25maXJtYXRpb24gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPEVycm9yIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtzdWJtaXR0ZWREZWNpc2lvbiwgc2V0U3VibWl0dGVkRGVjaXNpb25dID0gdXNlU3RhdGU8J2FjY2VwdCcgfCAnZGVjbGluZScgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBleGNoYW5nZUlkID0gdXNlUmVmKGNyeXB0by5yYW5kb21VVUlEKCkpO1xuICAgIGNvbnN0IGNvbmZpcm1hdGlvbklkID0gdXNlUmVmPHsgZGVjaXNpb246ICdhY2NlcHQnIHwgJ2RlY2xpbmUnOyBrZXk6IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgZXhjaGFuZ2UgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghdG9rZW4gfHwgcGVuZGluZykgcmV0dXJuO1xuICAgICAgICBzZXRQZW5kaW5nKHRydWUpOyBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGNzcmYgPSBhd2FpdCByZXF1ZXN0KCdnZXRDc3JmVG9rZW4nKTtcbiAgICAgICAgICAgIHNldENzcmZUb2tlbihjc3JmLmRhdGEuY3NyZlRva2VuKTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlcXVlc3QoJ2V4Y2hhbmdlQ29uc2VudENoYWxsZW5nZScsIHsgYm9keTogeyB0b2tlbiB9LCBpZGVtcG90ZW5jeUtleTogZXhjaGFuZ2VJZC5jdXJyZW50IH0pO1xuICAgICAgICAgICAgc2V0Q2hhbGxlbmdlKHJlc3VsdC5kYXRhKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY29uc2VudC9jb25maXJtJywgeyByZXBsYWNlOiB0cnVlLCBzdGF0ZTogeyBjb25zZW50Q2hhbGxlbmdlOiByZXN1bHQuZGF0YSB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChyZWFzb24pIHsgc2V0RXJyb3IocmVhc29uIGluc3RhbmNlb2YgRXJyb3IgPyByZWFzb24gOiBuZXcgRXJyb3IoJ0tow7RuZyB4w6FjIG1pbmggxJHGsOG7o2MgbGnDqm4ga+G6v3QuJykpOyB9XG4gICAgICAgIGZpbmFsbHkgeyBzZXRQZW5kaW5nKGZhbHNlKTsgfVxuICAgIH07XG4gICAgY29uc3QgY29uZmlybSA9IGFzeW5jIChkZWNpc2lvbjogJ2FjY2VwdCcgfCAnZGVjbGluZScpID0+IHtcbiAgICAgICAgaWYgKCFjaGFsbGVuZ2UgfHwgcGVuZGluZyB8fCBjb25maXJtYXRpb24gfHwgKHN1Ym1pdHRlZERlY2lzaW9uICYmIHN1Ym1pdHRlZERlY2lzaW9uICE9PSBkZWNpc2lvbikpIHJldHVybjtcbiAgICAgICAgY29uc3QgaW50ZW50ID0gY29uZmlybWF0aW9uSWQuY3VycmVudD8uZGVjaXNpb24gPT09IGRlY2lzaW9uID8gY29uZmlybWF0aW9uSWQuY3VycmVudCA6IHsgZGVjaXNpb24sIGtleTogY3J5cHRvLnJhbmRvbVVVSUQoKSB9O1xuICAgICAgICBjb25maXJtYXRpb25JZC5jdXJyZW50ID0gaW50ZW50O1xuICAgICAgICBzZXRTdWJtaXR0ZWREZWNpc2lvbihkZWNpc2lvbik7IHNldFBlbmRpbmcodHJ1ZSk7IHNldEVycm9yKG51bGwpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVxdWVzdCgnY29uZmlybUNvbnNlbnRDaGFsbGVuZ2UnLCB7IGJvZHk6IHsgY2hhbGxlbmdlU2Vzc2lvbklkOiBjaGFsbGVuZ2UuY2hhbGxlbmdlU2Vzc2lvbklkLCBkZWNpc2lvbiwgY29udGVudFZlcnNpb246IGNoYWxsZW5nZS5jb250ZW50VmVyc2lvbiB9LCBpZGVtcG90ZW5jeUtleTogaW50ZW50LmtleSB9KTtcbiAgICAgICAgICAgIHNldENvbmZpcm1hdGlvbihyZXN1bHQuZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKHJlYXNvbikgeyBzZXRFcnJvcihyZWFzb24gaW5zdGFuY2VvZiBFcnJvciA/IHJlYXNvbiA6IG5ldyBFcnJvcignQ2jGsGEgeMOhYyBtaW5oIMSRxrDhu6NjIGvhur90IHF14bqjLiBIw6N5IHRo4butIGzhuqFpIGPDuW5nIGzhu7FhIGNo4buNbi4nKSk7IH1cbiAgICAgICAgZmluYWxseSB7IHNldFBlbmRpbmcoZmFsc2UpOyB9XG4gICAgfTtcbiAgICBjb25zdCB3aXRoZHJhd2FsID0gY2hhbGxlbmdlPy5hY3Rpb24gPT09ICd3aXRoZHJhdyc7XG4gICAgY29uc3QgY29uZmlybWF0aW9uTWVzc2FnZSA9IGNvbmZpcm1hdGlvblxuICAgICAgICA/IGNvbmZpcm1hdGlvbi5jb25zZW50U3RhdHVzID09PSAnd2l0aGRyYXduJ1xuICAgICAgICAgICAgPyAnxJDDoyBnaGkgbmjhuq1uIGtow7RuZyBuaOG6rW4gdGluIG1hcmtldGluZyBxdWEga8OqbmggbsOgeS4gVGluIG5o4bqvbiBwaOG7pWMgduG7pSDEkcahbiBow6BuZyBraMO0bmcgYuG7iyDhuqNuaCBoxrDhu59uZy4nXG4gICAgICAgICAgICA6IGNvbmZpcm1hdGlvbi5zdGF0dXMgPT09ICdkZWNsaW5lZCdcbiAgICAgICAgICAgICAgICA/ICdM4buxYSBjaOG7jW4gaGnhu4duIHThuqFpIMSRxrDhu6NjIGdp4buvIG5ndXnDqm47IGtow7RuZyBjw7MgcXV54buBbiBtYXJrZXRpbmcgbeG7m2kgbsOgbyDEkcaw4bujYyBj4bqlcC4nXG4gICAgICAgICAgICAgICAgOiAnxJDDoyBnaGkgbmjhuq1uIGzhu7FhIGNo4buNbiBj4bunYSBi4bqhbi4nXG4gICAgICAgIDogJyc7XG4gICAgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwibWFpblwiIGlkPVwibWFpbi1jb250ZW50XCIgdGFiSW5kZXg9ey0xfSBzeD17W2xheW91dFN4LnNoZWxsLnBhZ2VGYWxsYmFja0luc2V0LCB7IG1heFdpZHRoOiA5MDAsIG14OiAnYXV0bycsIG91dGxpbmU6ICdub25lJyB9XX0+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiWMOhYyBuaOG6rW4gbOG7sWEgY2jhu41uIG1hcmtldGluZ1wiIHN1YnRpdGxlPVwiTGnDqm4ga+G6v3Qgbmfhuq9uIGjhuqFuIGfhuq9uIHbhu5tpIMSRw7puZyBraMOhY2gsIGvDqm5oIHbDoCBu4buZaSBkdW5nIMSRw6MgZ+G7rWkuXCIvPlxuICAgICAgICA8UGFuZWwgdGl0bGU9e2NoYWxsZW5nZSA/IHdpdGhkcmF3YWwgPyAnTmfhu6tuZyBuaOG6rW4gdGluIG1hcmtldGluZycgOiAnWMOhYyBuaOG6rW4gbmjhuq1uIHRpbiBtYXJrZXRpbmcnIDogJ0tp4buDbSB0cmEgbGnDqm4ga+G6v3QnfSBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICA8Rm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+TOG7sWEgY2jhu41uIG7DoHkgY2jhu4kgw6FwIGThu6VuZyBjaG8gbuG7mWkgZHVuZyBtYXJrZXRpbmcuIFRyYW8gxJHhu5VpIHBo4bulYyB24bulIMSRxqFuIGjDoG5nIHbhuqtuIMSRxrDhu6NjIHjhu60gbMO9IHJpw6puZy48L0FsZXJ0PlxuICAgICAgICAgICAgICAgIHtlcnJvciAmJiA8RXJyb3JOb3RpY2UgZXJyb3I9e2Vycm9yfS8+fVxuICAgICAgICAgICAgICAgIHshY2hhbGxlbmdlICYmIHRva2VuICYmIDw+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5MacOqbiBr4bq/dCBraMO0bmcgY2jhu6lhIHRow7RuZyB0aW4gY8OhIG5ow6JuLiBUaeG6v3AgdOG7pWMgxJHhu4Mga2nhu4NtIHRyYSBt4bulYyDEkcOtY2gsIGvDqm5oIHbDoCBu4buZaSBkdW5nIHRyxrDhu5tjIGtoaSBn4butaSBs4buxYSBjaOG7jW4uPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGV4Y2hhbmdlKCl9IGRpc2FibGVkPXtwZW5kaW5nfT57cGVuZGluZyA/ICfEkGFuZyBraeG7g20gdHJh4oCmJyA6IGVycm9yID8gJ1Ro4butIHjDoWMgbWluaCBs4bqhaScgOiAnWGVtIG7hu5lpIGR1bmcgecOqdSBj4bqndSd9PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC8+fVxuICAgICAgICAgICAgICAgIHshY2hhbGxlbmdlICYmICF0b2tlbiAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VGhp4bq/dSBsacOqbiBr4bq/dCBjaGFsbGVuZ2UuIEjDo3kgbeG7nyBsacOqbiBr4bq/dCDEkeG6p3kgxJHhu6cgZG8gY+G7rWEgaMOgbmcgZ+G7rWkgY2hvIGLhuqFuLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgIHtjaGFsbGVuZ2UgJiYgPD5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJN4bulYyDEkcOtY2hcIj5NYXJrZXRpbmc8L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiS8OqbmhcIj57YnVzaW5lc3NMYWJlbChjaGFsbGVuZ2UuY2hhbm5lbCl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk7hu5lpIGR1bmcgxJHDoyB4ZW1cIj57Y2hhbGxlbmdlLm1lc3NhZ2V9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlBoacOqbiBi4bqjbiBu4buZaSBkdW5nXCI+dntjaGFsbGVuZ2UuY29udGVudFZlcnNpb259PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkjhur90IGjhuqFuXCI+e2RhdGVUaW1lKGNoYWxsZW5nZS5leHBpcmVzQXQsICdBc2lhL0hvX0NoaV9NaW5oJyl9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICB7Y29uZmlybWF0aW9uID8gPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIj57Y29uZmlybWF0aW9uTWVzc2FnZX08L0FsZXJ0PiA6IDxBY3Rpb25Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgY29uZmlybSgnYWNjZXB0Jyl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnZGVjbGluZSd9PntwZW5kaW5nICYmIHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0JyA/ICfEkGFuZyBnaGkgbmjhuq1u4oCmJyA6IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0JyA/ICdUaOG7rSBs4bqhaSBjw7luZyBs4buxYSBjaOG7jW4nIDogd2l0aGRyYXdhbCA/ICdYw6FjIG5o4bqtbiBuZ+G7q25nIG1hcmtldGluZycgOiAnxJDhu5NuZyDDvSBuaOG6rW4gbWFya2V0aW5nJ308L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVkXCIgb25DbGljaz17KCkgPT4gdm9pZCBjb25maXJtKCdkZWNsaW5lJyl9IGRpc2FibGVkPXtwZW5kaW5nIHx8IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnYWNjZXB0J30+e3BlbmRpbmcgJiYgc3VibWl0dGVkRGVjaXNpb24gPT09ICdkZWNsaW5lJyA/ICfEkGFuZyBnaGkgbmjhuq1u4oCmJyA6IHN1Ym1pdHRlZERlY2lzaW9uID09PSAnZGVjbGluZScgPyAnVGjhu60gbOG6oWkgY8O5bmcgbOG7sWEgY2jhu41uJyA6IHdpdGhkcmF3YWwgPyAnR2nhu68gbmd1ecOqbiBs4buxYSBjaOG7jW4nIDogJ0tow7RuZyDEkeG7k25nIMO9IG1hcmtldGluZyd9PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvQWN0aW9uR3JvdXA+fVxuICAgICAgICAgICAgICAgIDwvPn1cbiAgICAgICAgICAgICAgICB7X19NT0NLX18gJiYgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+TcO0aSB0csaw4budbmcgbG9jYWwgY2jhu4kgbcO0IHBo4buPbmcgaOG7o3AgxJHhu5NuZyB2w6AgZOG7ryBsaeG7h3U7IGtow7RuZyBn4butaSBlbWFpbC9TTVMvTWV0YSB2w6Aga2jDtG5nIGNo4bupbmcgbmjhuq1uIEJhY2tlbmQgaG/hurdjIG5ow6AgY3VuZyBj4bqlcCB0aOG6rXQuPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9QYW5lbD5cbiAgICA8L0JveD47XG59XG5leHBvcnQgZnVuY3Rpb24gSm9iUGFnZSgpIHtcbiAgICBjb25zdCB7IGpvYklkID0gJycgfSA9IHVzZVBhcmFtcygpO1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBnZXQgPSB1c2VBcGkoJ2dldEpvYicsIHsgcGF0aDogeyBqb2JJZCB9IH0pO1xuICAgIGNvbnN0IGpvYiA9IGdldC5kYXRhPy5kYXRhO1xuICAgIGNvbnN0IGRvd25sb2FkSHJlZiA9IGpvYj8uZG93bmxvYWRVcmwgPyBhdXRob3JpemVkRG93bmxvYWRIcmVmKGpvYi5kb3dubG9hZFVybCwgbG9jYXRpb24ub3JpZ2luLCBfX01PQ0tfXykgOiBudWxsO1xuICAgIGNvbnN0IGpvYlN0YXR1cyA9IGpvYj8uc3RhdHVzO1xuICAgIGNvbnN0IHsgcmVmZXRjaCB9ID0gZ2V0O1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7IGlmICgham9iU3RhdHVzIHx8ICFbJ3F1ZXVlZCcsICdydW5uaW5nJ10uaW5jbHVkZXMoam9iU3RhdHVzKSlcbiAgICAgICAgcmV0dXJuOyBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHZvaWQgcmVmZXRjaCgpLCAzMDAwKTsgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpOyB9LCBbam9iU3RhdHVzLCByZWZldGNoXSk7XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9e2BDw7RuZyB2aeG7h2MgJHtqb2JJZH1gfSBzdWJ0aXRsZT1cIlRoZW8gZMO1aSB0aeG6v24gxJHhu5kgdOG7qyBBUEkuIMSQxrDhu6NjIHRp4bq/cCBuaOG6rW4ga2jDtG5nIGPDsyBuZ2jEqWEgxJHDoyBob8OgbiB04bqldC5cIi8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2dldH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2pvYiAmJiA8UGFuZWwgdGl0bGU9XCJL4bq/dCBxdeG6oyB44butIGzDvVwiIGJvZHlNb2RlPVwiaW5zZXRcIj48Rm9ybUZpZWxkcyA+PFN0YXR1cyB2YWx1ZT17am9iLnN0YXR1c30vPjxEZXRhaWxMaW5lIGxhYmVsPVwiTG/huqFpXCI+e2J1c2luZXNzTGFiZWwoam9iLmtpbmQpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlRp4bq/biDEkeG7mVwiPntqb2IuY29tcGxldGVkfSAvIHtqb2IudG90YWwgPz8gJ0NoxrBhIGJp4bq/dCd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTOG7l2lcIj57am9iLmVycm9yQ291bnR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQ+G6rXAgbmjhuq10XCI+e2RhdGVUaW1lKGpvYi51cGRhdGVkQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT57am9iLnJvd0Vycm9ycy5sZW5ndGggPiAwICYmIDxEYXRhVGFibGUgbGFiZWw9XCJM4buXaSBjw7RuZyB2aeG7h2MgbuG7gW5cIiByb3dzPXtqb2Iucm93RXJyb3JzfSByb3dLZXk9e2UgPT4gYCR7ZS5yb3d9LSR7ZS5maWVsZH0tJHtlLmNvZGV9YH0gY29sdW1ucz17W3sga2V5OiAncm93JywgbGFiZWw6ICdEw7JuZycsIHJlbmRlcjogZSA9PiBlLnJvdyB9LCB7IGtleTogJ2ZpZWxkJywgbGFiZWw6ICdUcsaw4budbmcnLCByZW5kZXI6IGUgPT4gZS5maWVsZCB9LCB7IGtleTogJ21lc3NhZ2UnLCBsYWJlbDogJ0zhu5dpJywgcmVuZGVyOiBlID0+IGUubWVzc2FnZSB9XX0vPn08QnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgZ2V0LnJlZmV0Y2goKX0gdmFyaWFudD1cIm91dGxpbmVkXCI+S2nhu4NtIHRyYSBs4bqhaTwvQnV0dG9uPntqb2IuZG93bmxvYWRVcmwgJiYgWydzdWNjZWVkZWQnLCAncGFydGlhbCddLmluY2x1ZGVzKGpvYi5zdGF0dXMpICYmIGRvd25sb2FkSHJlZiAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cub3Blbihkb3dubG9hZEhyZWYsICdfYmxhbmsnLCAnbm9vcGVuZXIsbm9yZWZlcnJlcicpfT5N4bufIGvhur90IHF14bqjIHh14bqldDwvQnV0dG9uPn17am9iLmRvd25sb2FkVXJsICYmIFsnc3VjY2VlZGVkJywgJ3BhcnRpYWwnXS5pbmNsdWRlcyhqb2Iuc3RhdHVzKSAmJiAhZG93bmxvYWRIcmVmICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5VUkwgdOG6o2kga2jDtG5nIGFuIHRvw6BuIGhv4bq3YyBraMO0bmcgaOG7o3AgbOG7hyBuw6puIMSRw6MgYuG7iyBjaOG6t24uPC9BbGVydD59e2pvYi5zdGF0dXMgPT09ICdhd2FpdGluZ19jb25maXJtYXRpb24nICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ltcG9ydHMvJHtqb2IuaWR9YH0+WGVtIHbDoCB4w6FjIG5o4bqtbiBuaOG6rXA8L1JvdXRlTGluaz59PC9Gb3JtRmllbGRzPjwvUGFuZWw+fTwvUXVlcnlTdGF0ZT48Lz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy93b3Jrc3BhY2UvaW5kZXgudHN4In0=