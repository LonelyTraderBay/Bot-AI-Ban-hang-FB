import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/ui/draft-conflict.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-94804-13bed124-d83d-4455-91e1-9c3c7827ffe0-privacy-pending-save-probe/deps/react_jsx-dev-runtime.js?v=8c2febed"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-94804-13bed124-d83d-4455-91e1-9c3c7827ffe0-privacy-pending-save-probe/deps/react.js?v=8c2febed"; const useState = __vite__cjsImport3_react["useState"];
import { Alert, Button, MenuItem, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-94804-13bed124-d83d-4455-91e1-9c3c7827ffe0-privacy-pending-save-probe/deps/@mui_material.js?v=f7a0ae42";
import { draftFields, draftFingerprint } from "/src/shared/model/versioned-draft.ts";
import { EditDialog, ErrorNotice } from "/src/shared/ui/components.tsx";
import { FormFields, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
function display(value) {
  if (value === null || value === void 0 || value === "") return "—";
  if (typeof value === "boolean") return value ? "Có" : "Không";
  return typeof value === "object" ? JSON.stringify(value, null, 2) : String(value);
}
export function DraftConflict({
  editor,
  labels,
  busy = false
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    editor.conflict && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", action: /* @__PURE__ */ jsxDEV(Button, { disabled: busy, color: "inherit", onClick: () => void editor.compare(), children: "Đối chiếu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
      lineNumber: 38,
      columnNumber: 63
    }, this), children: "Dữ liệu đã thay đổi trên server. Bản nháp của bạn được giữ; đối chiếu trước khi lưu." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
      lineNumber: 38,
      columnNumber: 29
    }, this),
    editor.comparing && editor.baseline && editor.source && /* @__PURE__ */ jsxDEV(Comparison, { editor, labels, busy }, `${editor.source.version}:${draftFingerprint(editor.source.values)}`, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
      lineNumber: 39,
      columnNumber: 66
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
    lineNumber: 37,
    columnNumber: 10
  }, this);
}
_c = DraftConflict;
function Comparison({ editor, labels, busy }) {
  _s();
  const [choices, setChoices] = useState({});
  const base = editor.baseline, latest = editor.source;
  const fields = draftFields(base.values, editor.draft, latest.values, latest.hidden);
  const complete = !editor.refreshing && fields.every((field) => choices[field.key] || field.choice);
  return /* @__PURE__ */ jsxDEV(EditDialog, { density: "comfortable", open: true, title: "Đối chiếu thay đổi", description: `Bản gốc v${base.version} · server v${latest.version}. Danh sách được chọn nguyên bản. Áp dụng chỉ cập nhật bản nháp; bạn vẫn cần kiểm tra và lưu.`, onClose: editor.closeComparison, dirtyGuard: false, busy, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: busy || !complete || !!editor.refreshError, onClick: () => editor.reconcile(latest.version, draftFingerprint(latest.values), choices), children: "Áp dụng vào bản nháp" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
    lineNumber: 47,
    columnNumber: 311
  }, this), children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: editor.refreshError }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
      lineNumber: 49,
      columnNumber: 13
    }, this),
    fields.map((field) => /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactOutlined", children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h3", variant: "subtitle2", children: labels[field.key] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
        lineNumber: 51,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", sm: "repeat(3, minmax(0, 1fr))" }, rhythm: "content", shrinkChildren: true, children: [["Bản gốc", field.base], ["Bản nháp", field.mine], ["Server mới nhất", field.theirs]].map(([label, value]) => /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: label }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
          lineNumber: 53,
          columnNumber: 172
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", sx: { whiteSpace: "pre-wrap", overflowWrap: "anywhere" }, children: display(value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
          lineNumber: 53,
          columnNumber: 245
        }, this)
      ] }, label, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
        lineNumber: 53,
        columnNumber: 144
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
        lineNumber: 52,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Chọn dữ liệu: ${labels[field.key]}`, value: choices[field.key] || field.choice || "", onChange: (event) => setChoices((current) => ({ ...current, [field.key]: event.target.value })), error: !choices[field.key] && !field.choice, helperText: !choices[field.key] && !field.choice ? "Cả hai bên đã sửa trường này. Hãy chọn bản cần giữ." : "Bạn có thể đổi lựa chọn trước khi áp dụng.", children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "mine", children: "Giữ bản nháp" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
          lineNumber: 56,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "theirs", children: "Dùng bản server" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
          lineNumber: 56,
          columnNumber: 67
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
        lineNumber: 55,
        columnNumber: 17
      }, this)
    ] }, String(field.key), true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
      lineNumber: 50,
      columnNumber: 36
    }, this))
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
    lineNumber: 48,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
}
_s(Comparison, "Gc/H9ryDrqrSSRQOEumTbMdjinI=");
_c2 = Comparison;
var _c, _c2;
$RefreshReg$(_c, "DraftConflict");
$RefreshReg$(_c2, "Comparison");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/shared/ui/draft-conflict.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJXLG1CQUNtRCxjQURuRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqQlgsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLE9BQU9DLFFBQVFDLFVBQVVDLFdBQVdDLGtCQUFrQjtBQUUvRCxTQUFTQyxhQUFhQyx3QkFBd0I7QUFDOUMsU0FBU0MsWUFBWUMsbUJBQW1CO0FBQ3hDLFNBQVNDLFlBQVlDLGFBQWFDLHNCQUFzQjtBQUV4RCxTQUFTQyxRQUFRQyxPQUF3QjtBQUNyQyxNQUFJQSxVQUFVLFFBQVFBLFVBQVVDLFVBQWFELFVBQVUsR0FBSSxRQUFPO0FBQ2xFLE1BQUksT0FBT0EsVUFBVSxVQUFXLFFBQU9BLFFBQVEsT0FBTztBQUN0RCxTQUFPLE9BQU9BLFVBQVUsV0FBV0UsS0FBS0MsVUFBVUgsT0FBTyxNQUFNLENBQUMsSUFBSUksT0FBT0osS0FBSztBQUNwRjtBQUNPLGdCQUFTSyxjQUFnQztBQUFBLEVBQUVDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVFDLE9BQU87QUFJekUsR0FBRztBQUNDLFNBQU8sbUNBQ0ZGO0FBQUFBLFdBQU9HLFlBQVksdUJBQUMsU0FBTSxVQUFTLFdBQVUsUUFBUSx1QkFBQyxVQUFPLFVBQVVELE1BQU0sT0FBTSxXQUFVLFNBQVMsTUFBTSxLQUFLRixPQUFPSSxRQUFRLEdBQUcseUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUYsR0FBVyxvR0FBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3TjtBQUFBLElBQzNPSixPQUFPSyxhQUFhTCxPQUFPTSxZQUFZTixPQUFPTyxVQUFVLHVCQUFDLGNBQXNGLFFBQWdCLFFBQWdCLFFBQXRHLEdBQUdQLE9BQU9PLE9BQU9DLE9BQU8sSUFBSXJCLGlCQUFpQmEsT0FBT08sT0FBT0UsTUFBTSxDQUFDLElBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0k7QUFBQSxPQUZ4TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR1A7QUFDSjtBQUFDQyxLQVRlWDtBQVVoQixTQUFTWSxXQUE2QixFQUFFWCxRQUFRQyxRQUFRQyxLQUEwRyxHQUFHO0FBQUFVLEtBQUE7QUFDakssUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlsQyxTQUFnRCxDQUFDLENBQUM7QUFDaEYsUUFBTW1DLE9BQU9mLE9BQU9NLFVBQVdVLFNBQVNoQixPQUFPTztBQUMvQyxRQUFNVSxTQUFTL0IsWUFBWTZCLEtBQUtOLFFBQVFULE9BQU9rQixPQUFPRixPQUFPUCxRQUFRTyxPQUFPRyxNQUFNO0FBQ2xGLFFBQU1DLFdBQVcsQ0FBQ3BCLE9BQU9xQixjQUFjSixPQUFPSyxNQUFNLENBQUFDLFVBQVNWLFFBQVFVLE1BQU1DLEdBQUcsS0FBS0QsTUFBTUUsTUFBTTtBQUMvRixTQUFPLHVCQUFDLGNBQVcsU0FBUSxlQUFjLE1BQUksTUFBQyxPQUFNLHNCQUFxQixhQUFhLFlBQVlWLEtBQUtQLE9BQU8sY0FBY1EsT0FBT1IsT0FBTyxpR0FBaUcsU0FBU1IsT0FBTzBCLGlCQUFpQixZQUFZLE9BQU8sTUFBWSxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVV4QixRQUFRLENBQUNrQixZQUFZLENBQUMsQ0FBQ3BCLE9BQU8yQixjQUFjLFNBQVMsTUFBTTNCLE9BQU80QixVQUFVWixPQUFPUixTQUFTckIsaUJBQWlCNkIsT0FBT1AsTUFBTSxHQUFHSSxPQUFPLEdBQUcsb0NBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaU0sR0FDamYsaUNBQUMsY0FDRztBQUFBLDJCQUFDLGVBQVksT0FBT2IsT0FBTzJCLGdCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDO0FBQUEsSUFDdkNWLE9BQU9ZLElBQUksQ0FBQU4sVUFBUyx1QkFBQyxrQkFBdUMsVUFBUyxtQkFDbEU7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLGFBQWF0QixpQkFBT3NCLE1BQU1DLEdBQUcsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BQ2xFLHVCQUFDLGVBQVksU0FBUyxFQUFFTSxJQUFJLE9BQU9DLElBQUksNEJBQTRCLEdBQUcsUUFBTyxXQUFVLGdCQUFjLE1BQy9GLFdBQUMsQ0FBQyxXQUFXUixNQUFNUixJQUFJLEdBQUcsQ0FBQyxZQUFZUSxNQUFNUyxJQUFJLEdBQUcsQ0FBQyxtQkFBbUJULE1BQU1VLE1BQU0sQ0FBQyxFQUFZSixJQUFJLENBQUMsQ0FBQ0ssT0FBT3hDLEtBQUssTUFBTSx1QkFBQyxrQkFBMkI7QUFBQSwrQkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFrQndDLG1CQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsUUFBYSx1QkFBQyxjQUFXLFNBQVEsU0FBUSxJQUFJLEVBQUVDLFlBQVksWUFBWUMsY0FBYyxXQUFXLEdBQUkzQyxrQkFBUUMsS0FBSyxLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsV0FBdEx3QyxPQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdOLENBQWlCLEtBRHhXO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTyxpQkFBaUJqQyxPQUFPc0IsTUFBTUMsR0FBRyxDQUFDLElBQUksT0FBT1gsUUFBUVUsTUFBTUMsR0FBRyxLQUFLRCxNQUFNRSxVQUFVLElBQUksVUFBVSxDQUFBWSxVQUFTdkIsV0FBVyxDQUFBd0IsYUFBWSxFQUFFLEdBQUdBLFNBQVMsQ0FBQ2YsTUFBTUMsR0FBRyxHQUFHYSxNQUFNRSxPQUFPN0MsTUFBcUIsRUFBRSxHQUFHLE9BQU8sQ0FBQ21CLFFBQVFVLE1BQU1DLEdBQUcsS0FBSyxDQUFDRCxNQUFNRSxRQUFRLFlBQVksQ0FBQ1osUUFBUVUsTUFBTUMsR0FBRyxLQUFLLENBQUNELE1BQU1FLFNBQVMsd0RBQXdELDhDQUNoWDtBQUFBLCtCQUFDLFlBQVMsT0FBTSxRQUFPLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsUUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUywrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFdBRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUHNDM0IsT0FBT3lCLE1BQU1DLEdBQUcsR0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFyQixDQUFpQjtBQUFBLE9BVnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQSxLQVpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhUDtBQUNKO0FBQUNaLEdBbkJRRCxZQUFVO0FBQUEsTUFBVkE7QUFBVSxJQUFBRCxJQUFBOEI7QUFBQSxhQUFBOUIsSUFBQTtBQUFBLGFBQUE4QixLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJBbGVydCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsImRyYWZ0RmllbGRzIiwiZHJhZnRGaW5nZXJwcmludCIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkZvcm1GaWVsZHMiLCJTZWN0aW9uR3JpZCIsIlN1cmZhY2VDb250ZW50IiwiZGlzcGxheSIsInZhbHVlIiwidW5kZWZpbmVkIiwiSlNPTiIsInN0cmluZ2lmeSIsIlN0cmluZyIsIkRyYWZ0Q29uZmxpY3QiLCJlZGl0b3IiLCJsYWJlbHMiLCJidXN5IiwiY29uZmxpY3QiLCJjb21wYXJlIiwiY29tcGFyaW5nIiwiYmFzZWxpbmUiLCJzb3VyY2UiLCJ2ZXJzaW9uIiwidmFsdWVzIiwiX2MiLCJDb21wYXJpc29uIiwiX3MiLCJjaG9pY2VzIiwic2V0Q2hvaWNlcyIsImJhc2UiLCJsYXRlc3QiLCJmaWVsZHMiLCJkcmFmdCIsImhpZGRlbiIsImNvbXBsZXRlIiwicmVmcmVzaGluZyIsImV2ZXJ5IiwiZmllbGQiLCJrZXkiLCJjaG9pY2UiLCJjbG9zZUNvbXBhcmlzb24iLCJyZWZyZXNoRXJyb3IiLCJyZWNvbmNpbGUiLCJtYXAiLCJ4cyIsInNtIiwibWluZSIsInRoZWlycyIsImxhYmVsIiwid2hpdGVTcGFjZSIsIm92ZXJmbG93V3JhcCIsImV2ZW50IiwiY3VycmVudCIsInRhcmdldCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJkcmFmdC1jb25mbGljdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBbGVydCwgQnV0dG9uLCBNZW51SXRlbSwgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgdHlwZSB7IERyYWZ0Q2hvaWNlLCB1c2VWZXJzaW9uZWREcmFmdCB9IGZyb20gJy4uL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XG5pbXBvcnQgeyBkcmFmdEZpZWxkcywgZHJhZnRGaW5nZXJwcmludCB9IGZyb20gJy4uL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XG5pbXBvcnQgeyBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSB9IGZyb20gJy4vY29tcG9uZW50cyc7XG5pbXBvcnQgeyBGb3JtRmllbGRzLCBTZWN0aW9uR3JpZCwgU3VyZmFjZUNvbnRlbnQgfSBmcm9tICcuL2NvbXBvc2l0aW9uJztcblxuZnVuY3Rpb24gZGlzcGxheSh2YWx1ZTogdW5rbm93bik6IHN0cmluZyB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09ICcnKSByZXR1cm4gJ+KAlCc7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gdmFsdWUgPyAnQ8OzJyA6ICdLaMO0bmcnO1xuICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnID8gSlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpIDogU3RyaW5nKHZhbHVlKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBEcmFmdENvbmZsaWN0PFQgZXh0ZW5kcyBvYmplY3Q+KHsgZWRpdG9yLCBsYWJlbHMsIGJ1c3kgPSBmYWxzZSB9OiB7XG4gICAgZWRpdG9yOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VWZXJzaW9uZWREcmFmdDxUPj47XG4gICAgbGFiZWxzOiBSZWNvcmQ8a2V5b2YgVCwgc3RyaW5nPjtcbiAgICBidXN5PzogYm9vbGVhbjtcbn0pIHtcbiAgICByZXR1cm4gPD5cbiAgICAgICAge2VkaXRvci5jb25mbGljdCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgYWN0aW9uPXs8QnV0dG9uIGRpc2FibGVkPXtidXN5fSBjb2xvcj1cImluaGVyaXRcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGVkaXRvci5jb21wYXJlKCl9PsSQ4buRaSBjaGnhur91PC9CdXR0b24+fT5E4buvIGxp4buHdSDEkcOjIHRoYXkgxJHhu5VpIHRyw6puIHNlcnZlci4gQuG6o24gbmjDoXAgY+G7p2EgYuG6oW4gxJHGsOG7o2MgZ2nhu687IMSR4buRaSBjaGnhur91IHRyxrDhu5tjIGtoaSBsxrB1LjwvQWxlcnQ+fVxuICAgICAgICB7ZWRpdG9yLmNvbXBhcmluZyAmJiBlZGl0b3IuYmFzZWxpbmUgJiYgZWRpdG9yLnNvdXJjZSAmJiA8Q29tcGFyaXNvbiBrZXk9e2Ake2VkaXRvci5zb3VyY2UudmVyc2lvbn06JHtkcmFmdEZpbmdlcnByaW50KGVkaXRvci5zb3VyY2UudmFsdWVzKX1gfSBlZGl0b3I9e2VkaXRvcn0gbGFiZWxzPXtsYWJlbHN9IGJ1c3k9e2J1c3l9Lz59XG4gICAgPC8+O1xufVxuZnVuY3Rpb24gQ29tcGFyaXNvbjxUIGV4dGVuZHMgb2JqZWN0Pih7IGVkaXRvciwgbGFiZWxzLCBidXN5IH06IHsgZWRpdG9yOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VWZXJzaW9uZWREcmFmdDxUPj47IGxhYmVsczogUmVjb3JkPGtleW9mIFQsIHN0cmluZz47IGJ1c3k6IGJvb2xlYW4gfSkge1xuICAgIGNvbnN0IFtjaG9pY2VzLCBzZXRDaG9pY2VzXSA9IHVzZVN0YXRlPFBhcnRpYWw8UmVjb3JkPGtleW9mIFQsIERyYWZ0Q2hvaWNlPj4+KHt9KTtcbiAgICBjb25zdCBiYXNlID0gZWRpdG9yLmJhc2VsaW5lISwgbGF0ZXN0ID0gZWRpdG9yLnNvdXJjZSE7XG4gICAgY29uc3QgZmllbGRzID0gZHJhZnRGaWVsZHMoYmFzZS52YWx1ZXMsIGVkaXRvci5kcmFmdCwgbGF0ZXN0LnZhbHVlcywgbGF0ZXN0LmhpZGRlbik7XG4gICAgY29uc3QgY29tcGxldGUgPSAhZWRpdG9yLnJlZnJlc2hpbmcgJiYgZmllbGRzLmV2ZXJ5KGZpZWxkID0+IGNob2ljZXNbZmllbGQua2V5XSB8fCBmaWVsZC5jaG9pY2UpO1xuICAgIHJldHVybiA8RWRpdERpYWxvZyBkZW5zaXR5PVwiY29tZm9ydGFibGVcIiBvcGVuIHRpdGxlPVwixJDhu5FpIGNoaeG6v3UgdGhheSDEkeG7lWlcIiBkZXNjcmlwdGlvbj17YELhuqNuIGfhu5FjIHYke2Jhc2UudmVyc2lvbn0gwrcgc2VydmVyIHYke2xhdGVzdC52ZXJzaW9ufS4gRGFuaCBzw6FjaCDEkcaw4bujYyBjaOG7jW4gbmd1ecOqbiBi4bqjbi4gw4FwIGThu6VuZyBjaOG7iSBj4bqtcCBuaOG6rXQgYuG6o24gbmjDoXA7IGLhuqFuIHbhuqtuIGPhuqduIGtp4buDbSB0cmEgdsOgIGzGsHUuYH0gb25DbG9zZT17ZWRpdG9yLmNsb3NlQ29tcGFyaXNvbn0gZGlydHlHdWFyZD17ZmFsc2V9IGJ1c3k9e2J1c3l9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtidXN5IHx8ICFjb21wbGV0ZSB8fCAhIWVkaXRvci5yZWZyZXNoRXJyb3J9IG9uQ2xpY2s9eygpID0+IGVkaXRvci5yZWNvbmNpbGUobGF0ZXN0LnZlcnNpb24sIGRyYWZ0RmluZ2VycHJpbnQobGF0ZXN0LnZhbHVlcyksIGNob2ljZXMpfT7DgXAgZOG7pW5nIHbDoG8gYuG6o24gbmjDoXA8L0J1dHRvbj59PlxuICAgICAgICA8Rm9ybUZpZWxkcz5cbiAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17ZWRpdG9yLnJlZnJlc2hFcnJvcn0vPlxuICAgICAgICAgICAge2ZpZWxkcy5tYXAoZmllbGQgPT4gPFN1cmZhY2VDb250ZW50IGtleT17U3RyaW5nKGZpZWxkLmtleSl9IGJvZHlNb2RlPVwiY29tcGFjdE91dGxpbmVkXCI+XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDNcIiB2YXJpYW50PVwic3VidGl0bGUyXCI+e2xhYmVsc1tmaWVsZC5rZXldfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJzFmcicsIHNtOiAncmVwZWF0KDMsIG1pbm1heCgwLCAxZnIpKScgfX0gcmh5dGhtPVwiY29udGVudFwiIHNocmlua0NoaWxkcmVuPlxuICAgICAgICAgICAgICAgICAgICB7KFtbJ0LhuqNuIGfhu5FjJywgZmllbGQuYmFzZV0sIFsnQuG6o24gbmjDoXAnLCBmaWVsZC5taW5lXSwgWydTZXJ2ZXIgbeG7m2kgbmjhuqV0JywgZmllbGQudGhlaXJzXV0gYXMgY29uc3QpLm1hcCgoW2xhYmVsLCB2YWx1ZV0pID0+IDxTdXJmYWNlQ29udGVudCBrZXk9e2xhYmVsfT48VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj57bGFiZWx9PC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIHN4PXt7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcsIG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9fT57ZGlzcGxheSh2YWx1ZSl9PC9UeXBvZ3JhcGh5PjwvU3VyZmFjZUNvbnRlbnQ+KX1cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb25HcmlkPlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPXtgQ2jhu41uIGThu68gbGnhu4d1OiAke2xhYmVsc1tmaWVsZC5rZXldfWB9IHZhbHVlPXtjaG9pY2VzW2ZpZWxkLmtleV0gfHwgZmllbGQuY2hvaWNlIHx8ICcnfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0Q2hvaWNlcyhjdXJyZW50ID0+ICh7IC4uLmN1cnJlbnQsIFtmaWVsZC5rZXldOiBldmVudC50YXJnZXQudmFsdWUgYXMgRHJhZnRDaG9pY2UgfSkpfSBlcnJvcj17IWNob2ljZXNbZmllbGQua2V5XSAmJiAhZmllbGQuY2hvaWNlfSBoZWxwZXJUZXh0PXshY2hvaWNlc1tmaWVsZC5rZXldICYmICFmaWVsZC5jaG9pY2UgPyAnQ+G6oyBoYWkgYsOqbiDEkcOjIHPhu61hIHRyxrDhu51uZyBuw6B5LiBIw6N5IGNo4buNbiBi4bqjbiBj4bqnbiBnaeG7ry4nIDogJ0LhuqFuIGPDsyB0aOG7gyDEkeG7lWkgbOG7sWEgY2jhu41uIHRyxrDhu5tjIGtoaSDDoXAgZOG7pW5nLid9PlxuICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJtaW5lXCI+R2nhu68gYuG6o24gbmjDoXA8L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cInRoZWlyc1wiPkTDuW5nIGLhuqNuIHNlcnZlcjwvTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XG4gICAgICAgICAgICA8L1N1cmZhY2VDb250ZW50Pil9XG4gICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICA8L0VkaXREaWFsb2c+O1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL3NoYXJlZC91aS9kcmFmdC1jb25mbGljdC50c3gifQ==