import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/customers/addresses.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react_jsx-dev-runtime.js?v=867dcec9"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react.js?v=867dcec9"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Alert, Button, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@mui_material.js?v=aff9c5ca";
import { useForm, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react-hook-form.js?v=431cd782";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@hookform_resolvers_zod.js?v=0c6cc459";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/zod.js?v=000ccb25";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useVersionedDraft, draftEqual } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { codePointLength } from "/src/shared/model/format.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { FormFields, ActionGroup } from "/src/shared/ui/composition.tsx";
import { Panel, QueryState, DataTable, Status, MutationButton, EditDialog, ConfirmDialog, ErrorNotice, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { usePagedApi } from "/src/shared/api/hooks.ts";
const limits = { label: 120, recipient: 160, phone: 40, line1: 500, ward: 120, district: 120, province: 120, postalCode: 20, countryCode: 2 };
const labels = { label: "Tên địa chỉ", recipient: "Người nhận", phone: "Điện thoại giao hàng", line1: "Địa chỉ chi tiết", ward: "Phường / xã", district: "Quận / huyện", province: "Tỉnh / thành phố", postalCode: "Mã bưu chính", countryCode: "Mã quốc gia" };
const empty = { label: "", recipient: "", phone: "", line1: "", ward: "", district: "", province: "", postalCode: "", countryCode: "VN" };
function addressName(address) {
  return address.label || `Địa chỉ ${address.id}`;
}
function snapshot(address) {
  return { version: address.version, values: Object.fromEntries(Object.keys(limits).map((key) => [key, address[key] || ""])), hidden: address.redactedFields.filter((key) => key in limits) };
}
function addressBody(fields) {
  return { ...fields, phone: fields.phone || null, ward: fields.ward || null, district: fields.district || null, postalCode: fields.postalCode || null };
}
function schemaFor(hidden) {
  return z.object({ label: z.string(), recipient: z.string(), phone: z.string(), line1: z.string(), ward: z.string(), district: z.string(), province: z.string(), postalCode: z.string(), countryCode: z.string() }).superRefine((fields, ctx) => {
    for (const key of Object.keys(limits)) {
      if (hidden.includes(key)) continue;
      if (codePointLength(fields[key]) > limits[key]) ctx.addIssue({ code: "custom", path: [key], message: `${labels[key]} tối đa ${limits[key]} ký tự.` });
      if (["label", "recipient", "phone", "line1", "province", "countryCode"].includes(key) && !fields[key].trim()) ctx.addIssue({ code: "custom", path: [key], message: `Nhập ${labels[key].toLocaleLowerCase("vi")}.` });
    }
    if (!hidden.includes("countryCode") && !/^[A-Z]{2}$/.test(fields.countryCode)) ctx.addIssue({ code: "custom", path: ["countryCode"], message: "Dùng mã quốc gia 2 chữ in hoa, ví dụ VN." });
  });
}
export function AddressesPanel({ customer }) {
  _s();
  const { shop } = useScope(), canEdit = useCan("customers.write");
  const list = usePagedApi("listCustomerAddresses", { path: { customerId: customer.id }, query: { limit: 20 } });
  const [open, setOpen] = useState(false), [selected, setSelected] = useState(null), [archive, setArchive] = useState(null), [success, setSuccess] = useState("");
  const detail = useApi("getCustomerAddress", { path: { customerId: customer.id, addressId: selected?.id || "" } }, open && Boolean(selected));
  const hidden = useMemo(() => Object.keys(limits).filter((field) => customer.redactedFields.includes("addresses") || customer.redactedFields.includes("shippingAddress") || customer.redactedFields.includes(`address.${field}`) || field === "phone" && customer.redactedFields.includes("phone")), [customer.redactedFields]);
  const canCreate = !hidden.some((key) => ["label", "recipient", "line1", "province", "countryCode"].includes(key));
  const schema = useMemo(() => schemaFor(hidden), [hidden]);
  const form = useForm({ defaultValues: empty, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const create = useCommand("createCustomerAddress", ["listCustomerAddresses"]), update = useCommand("updateCustomerAddress", ["listCustomerAddresses", "getCustomerAddress"]), remove = useCommand("archiveCustomerAddress", ["listCustomerAddresses", "getCustomerAddress"]);
  const editor = useVersionedDraft({ identity: `${shop.id}:${customer.id}:address:${selected?.id || "new"}`, source: detail.data ? snapshot(detail.data.data) : selected ? snapshot(selected) : void 0, draft: form.getValues(), apply: (values) => form.reset(values), refresh: () => detail.refetch({ throwOnError: true }) });
  const dirty = open && (selected ? editor.dirty : !draftEqual(empty, form.getValues())), bindDraft = useDraftForm(dirty), formRef = useRef(null), busy = create.pending || update.pending;
  const blocked = Boolean(selected ? update.unresolved : create.unresolved);
  const submit = form.handleSubmit(async (values) => {
    if (!canEdit || blocked || !selected && !canCreate) return;
    try {
      if (selected) {
        const prepared = editor.prepare();
        if (!prepared) return;
        const converted = addressBody(values), patch = {};
        for (const key of Object.keys(prepared.patch)) if (!hidden.includes(key)) Object.assign(patch, { [key]: converted[key] });
        const response = await update.execute({ path: { customerId: customer.id, addressId: selected.id }, version: prepared.version, body: patch });
        if (!editor.committed(snapshot(response.data), values)) return;
      } else {
        const body = addressBody(values);
        if (hidden.includes("phone")) body.phone = null;
        await create.execute({ path: { customerId: customer.id }, body });
      }
      if (formRef.current) markDraftClean(formRef.current);
      setSuccess(`Đã lưu địa chỉ ${values.label}.`);
      setOpen(false);
      form.reset(empty);
    } catch (error) {
      editor.failed(error);
    }
  });
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Địa chỉ khách hàng", bodyMode: "inset", subtitle: "Địa chỉ sửa sau không làm đổi snapshot của đơn đã xác nhận.", action: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", disabled: !canCreate, onClick: () => {
    setSelected(null);
    form.reset(empty);
    setOpen(true);
  }, children: "Thêm địa chỉ" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
    lineNumber: 86,
    columnNumber: 140
  }, this), children: [
    !canCreate && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Quyền hiện tại che thông tin bắt buộc của địa chỉ; cần người có quyền phù hợp để tạo địa chỉ mới." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 87,
      columnNumber: 24
    }, this),
    success && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: success }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 88,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Địa chỉ trong hồ sơ khách", rows: list.data.data, rowKey: (address) => address.id, columns: [
        { key: "name", label: "Địa chỉ", render: (a) => addressName(a) },
        { key: "recipient", label: "Người nhận", render: (a) => a.recipient || "Đã che theo quyền" },
        { key: "line", label: "Địa điểm", render: (a) => a.line1 || "Đã che theo quyền" },
        { key: "status", label: "Trạng thái", render: (a) => /* @__PURE__ */ jsxDEV(Status, { value: a.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
          lineNumber: 91,
          columnNumber: 305
        }, this) },
        { key: "edit", label: "Thao tác", render: (a) => a.status === "active" ? /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", onClick: () => {
            setSelected(a);
            form.reset(snapshot(a).values);
            setOpen(true);
          }, children: [
            "Sửa địa chỉ ",
            addressName(a)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
            lineNumber: 92,
            columnNumber: 95
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", onClick: () => setArchive(a), children: [
            "Ngừng dùng ",
            addressName(a)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
            lineNumber: 92,
            columnNumber: 264
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
          lineNumber: 92,
          columnNumber: 82
        }, this) : "Lịch sử được giữ" }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 90,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "địa chỉ khách hàng", loadedCount: list.loadedCount, hasMore: list.hasMore, busy: list.isLoadingMore, onLoadMore: list.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 93,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 89,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: selected ? `Sửa địa chỉ ${addressName(selected)}` : "Thêm địa chỉ", busy, onClose: () => setOpen(false), actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "address-editor", variant: "contained", disabled: busy || blocked || !canEdit || !selected && !canCreate || Boolean(selected) && !editor.dirty, children: "Lưu địa chỉ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 95,
      columnNumber: 160
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || detail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 96,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels, busy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 96,
        columnNumber: 81
      }, this),
      hidden.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Một số trường địa chỉ đang bị che và không được ghi lại. Địa chỉ mới thiếu thông tin giao hàng sẽ chưa dùng để xác nhận đơn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 97,
        columnNumber: 35
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "address-editor", noValidate: true, ref: (node) => {
        formRef.current = node;
        bindDraft(node);
      }, onSubmit: submit, "data-draft-clean": !dirty ? "true" : void 0, children: Object.keys(limits).map((key) => /* @__PURE__ */ jsxDEV(TextField, { label: labels[key], ...form.register(key), disabled: busy || !canEdit || hidden.includes(key), error: Boolean(form.formState.errors[key]), helperText: form.formState.errors[key]?.message }, key, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 99,
        columnNumber: 73
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
        lineNumber: 98,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 95,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: Boolean(archive), title: "Ngừng dùng địa chỉ", confirmLabel: "Ngừng dùng địa chỉ", description: `Địa chỉ ${archive ? addressName(archive) : ""} của ${customer.displayName} không còn dùng cho đơn mới. Snapshot trong đơn đã xác nhận và lịch sử vẫn được giữ.`, requireReason: true, busy: remove.pending, error: remove.error, onClose: () => setArchive(null), onConfirm: async (reason) => {
      if (!archive) return;
      await remove.execute({ path: { customerId: customer.id, addressId: archive.id }, body: { expectedVersion: archive.version, reason } });
      setSuccess(`Đã ngừng dùng địa chỉ ${addressName(archive)}.`);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
      lineNumber: 102,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx",
    lineNumber: 86,
    columnNumber: 10
  }, this);
}
_s(AddressesPanel, "NXMjDR0dYpjQaFbiePjmgjgwZ+E=", false, function() {
  return [useScope, useCan, usePagedApi, useApi, useForm, useWatch, useCommand, useCommand, useCommand, useVersionedDraft, useDraftForm];
});
_c = AddressesPanel;
var _c;
$RefreshReg$(_c, "AddressesPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/addresses.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0U2SSxTQUd2RSxVQUh1RTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsRTdJLFNBQVNBLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUMxQyxTQUFTQyxPQUFPQyxRQUFRQyxpQkFBaUI7QUFDekMsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxTQUFTO0FBRWxCLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLG1CQUFtQkMsa0JBQWtCO0FBQzlDLFNBQVNDLGNBQWNDLHNCQUFzQjtBQUM3QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFlBQVlDLG1CQUFtQjtBQUN4QyxTQUFTQyxPQUFPQyxZQUFZQyxXQUFXQyxRQUFRQyxnQkFBZ0JDLFlBQVlDLGVBQWVDLGFBQWFDLHNCQUFzQjtBQUM3SCxTQUFTQyxtQkFBbUI7QUFFNUIsTUFBTUMsU0FBTyxFQUFDQyxPQUFNLEtBQUlDLFdBQVUsS0FBSUMsT0FBTSxJQUFHQyxPQUFNLEtBQUlDLE1BQUssS0FBSUMsVUFBUyxLQUFJQyxVQUFTLEtBQUlDLFlBQVcsSUFBR0MsYUFBWSxFQUFDO0FBQ3ZILE1BQU1DLFNBQU8sRUFBQ1QsT0FBTSxlQUFjQyxXQUFVLGNBQWFDLE9BQU0sd0JBQXVCQyxPQUFNLG9CQUFtQkMsTUFBSyxlQUFjQyxVQUFTLGdCQUFlQyxVQUFTLG9CQUFtQkMsWUFBVyxnQkFBZUMsYUFBWSxjQUFhO0FBRXpPLE1BQU1FLFFBQWEsRUFBQ1YsT0FBTSxJQUFHQyxXQUFVLElBQUdDLE9BQU0sSUFBR0MsT0FBTSxJQUFHQyxNQUFLLElBQUdDLFVBQVMsSUFBR0MsVUFBUyxJQUFHQyxZQUFXLElBQUdDLGFBQVksS0FBSTtBQUMxSCxTQUFTRyxZQUFZQyxTQUF5QjtBQUFDLFNBQU9BLFFBQVFaLFNBQVMsV0FBV1ksUUFBUUMsRUFBRTtBQUFHO0FBQy9GLFNBQVNDLFNBQVNGLFNBQXlCO0FBQ3ZDLFNBQU8sRUFBQ0csU0FBUUgsUUFBUUcsU0FBUUMsUUFBT0MsT0FBT0MsWUFBWUQsT0FBT0UsS0FBS3BCLE1BQU0sRUFBRXFCLElBQUksQ0FBQUMsUUFBSyxDQUFDQSxLQUFJVCxRQUFRUyxHQUFtQixLQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQVlDLFFBQU9WLFFBQVFXLGVBQWVDLE9BQU8sQ0FBQ0gsUUFBMEJBLE9BQU90QixNQUFNLEVBQUM7QUFDNU47QUFDQSxTQUFTMEIsWUFBWUMsUUFBb0M7QUFDckQsU0FBTyxFQUFDLEdBQUdBLFFBQU94QixPQUFNd0IsT0FBT3hCLFNBQU8sTUFBS0UsTUFBS3NCLE9BQU90QixRQUFNLE1BQUtDLFVBQVNxQixPQUFPckIsWUFBVSxNQUFLRSxZQUFXbUIsT0FBT25CLGNBQVksS0FBSTtBQUN2STtBQUNBLFNBQVNvQixVQUFVTCxRQUEwQjtBQUN6QyxTQUFPOUMsRUFBRW9ELE9BQU8sRUFBQzVCLE9BQU14QixFQUFFcUQsT0FBTyxHQUFFNUIsV0FBVXpCLEVBQUVxRCxPQUFPLEdBQUUzQixPQUFNMUIsRUFBRXFELE9BQU8sR0FBRTFCLE9BQU0zQixFQUFFcUQsT0FBTyxHQUFFekIsTUFBSzVCLEVBQUVxRCxPQUFPLEdBQUV4QixVQUFTN0IsRUFBRXFELE9BQU8sR0FBRXZCLFVBQVM5QixFQUFFcUQsT0FBTyxHQUFFdEIsWUFBVy9CLEVBQUVxRCxPQUFPLEdBQUVyQixhQUFZaEMsRUFBRXFELE9BQU8sRUFBQyxDQUFDLEVBQUVDLFlBQVksQ0FBQ0osUUFBT0ssUUFBTTtBQUN0TixlQUFVVixPQUFPSixPQUFPRSxLQUFLcEIsTUFBTSxHQUF1QjtBQUN0RCxVQUFHdUIsT0FBT1UsU0FBU1gsR0FBRyxFQUFFO0FBQ3hCLFVBQUdwQyxnQkFBZ0J5QyxPQUFPTCxHQUFHLENBQUMsSUFBRXRCLE9BQU9zQixHQUFHLEVBQUVVLEtBQUlFLFNBQVMsRUFBQ0MsTUFBSyxVQUFTQyxNQUFLLENBQUNkLEdBQUcsR0FBRWUsU0FBUSxHQUFHM0IsT0FBT1ksR0FBRyxDQUFDLFdBQVd0QixPQUFPc0IsR0FBRyxDQUFDLFVBQVMsQ0FBQztBQUN6SSxVQUFHLENBQUMsU0FBUSxhQUFZLFNBQVEsU0FBUSxZQUFXLGFBQWEsRUFBRVcsU0FBU1gsR0FBRyxLQUFHLENBQUNLLE9BQU9MLEdBQUcsRUFBRWdCLEtBQUssRUFBRU4sS0FBSUUsU0FBUyxFQUFDQyxNQUFLLFVBQVNDLE1BQUssQ0FBQ2QsR0FBRyxHQUFFZSxTQUFRLFFBQVEzQixPQUFPWSxHQUFHLEVBQUVpQixrQkFBa0IsSUFBSSxDQUFDLElBQUcsQ0FBQztBQUFBLElBQ3ZNO0FBQ0EsUUFBRyxDQUFDaEIsT0FBT1UsU0FBUyxhQUFhLEtBQUcsQ0FBQyxhQUFhTyxLQUFLYixPQUFPbEIsV0FBVyxFQUFFdUIsS0FBSUUsU0FBUyxFQUFDQyxNQUFLLFVBQVNDLE1BQUssQ0FBQyxhQUFhLEdBQUVDLFNBQVEsMkNBQTBDLENBQUM7QUFBQSxFQUNuTCxDQUFDO0FBQ0w7QUFFTyxnQkFBU0ksZUFBZSxFQUFDQyxTQUE0QixHQUFHO0FBQUFDLEtBQUE7QUFDM0QsUUFBTSxFQUFDQyxLQUFJLElBQUVoRSxTQUFTLEdBQUVpRSxVQUFRaEUsT0FBTyxpQkFBaUI7QUFDeEQsUUFBTWlFLE9BQUsvQyxZQUFZLHlCQUF3QixFQUFDcUMsTUFBSyxFQUFDVyxZQUFXTCxTQUFTNUIsR0FBRSxHQUFFa0MsT0FBTSxFQUFDQyxPQUFNLEdBQUUsRUFBQyxDQUFDO0FBQy9GLFFBQU0sQ0FBQ0MsTUFBS0MsT0FBTyxJQUFFakYsU0FBUyxLQUFLLEdBQUUsQ0FBQ2tGLFVBQVNDLFdBQVcsSUFBRW5GLFNBQStCLElBQUksR0FBRSxDQUFDb0YsU0FBUUMsVUFBVSxJQUFFckYsU0FBK0IsSUFBSSxHQUFFLENBQUNzRixTQUFRQyxVQUFVLElBQUV2RixTQUFTLEVBQUU7QUFDM0wsUUFBTXdGLFNBQU9oRixPQUFPLHNCQUFxQixFQUFDMEQsTUFBSyxFQUFDVyxZQUFXTCxTQUFTNUIsSUFBRzZDLFdBQVVQLFVBQVV0QyxNQUFJLEdBQUUsRUFBQyxHQUFFb0MsUUFBTVUsUUFBUVIsUUFBUSxDQUFDO0FBQzNILFFBQU03QixTQUFPdkQsUUFBUSxNQUFJa0QsT0FBT0UsS0FBS3BCLE1BQU0sRUFBRXlCLE9BQU8sQ0FBQW9DLFVBQU9uQixTQUFTbEIsZUFBZVMsU0FBUyxXQUFXLEtBQUdTLFNBQVNsQixlQUFlUyxTQUFTLGlCQUFpQixLQUFHUyxTQUFTbEIsZUFBZVMsU0FBUyxXQUFXNEIsS0FBSyxFQUFFLEtBQUlBLFVBQVEsV0FBU25CLFNBQVNsQixlQUFlUyxTQUFTLE9BQU8sQ0FBRSxHQUFFLENBQUNTLFNBQVNsQixjQUFjLENBQUM7QUFDNVMsUUFBTXNDLFlBQVUsQ0FBQ3ZDLE9BQU93QyxLQUFLLENBQUF6QyxRQUFLLENBQUMsU0FBUSxhQUFZLFNBQVEsWUFBVyxhQUFhLEVBQUVXLFNBQVNYLEdBQUcsQ0FBQztBQUN0RyxRQUFNMEMsU0FBT2hHLFFBQVEsTUFBSTRELFVBQVVMLE1BQU0sR0FBRSxDQUFDQSxNQUFNLENBQUM7QUFDbkQsUUFBTTBDLE9BQUszRixRQUFnQixFQUFDNEYsZUFBY3ZELE9BQU13RCxVQUFTM0YsWUFBWXdGLE1BQU0sRUFBQyxDQUFDO0FBQUV6RixXQUFTLEVBQUM2RixTQUFRSCxLQUFLRyxRQUFPLENBQUM7QUFDOUcsUUFBTUMsU0FBTzFGLFdBQVcseUJBQXdCLENBQUMsdUJBQXVCLENBQUMsR0FBRTJGLFNBQU8zRixXQUFXLHlCQUF3QixDQUFDLHlCQUF3QixvQkFBb0IsQ0FBQyxHQUFFNEYsU0FBTzVGLFdBQVcsMEJBQXlCLENBQUMseUJBQXdCLG9CQUFvQixDQUFDO0FBQzlQLFFBQU02RixTQUFPMUYsa0JBQWtCLEVBQUMyRixVQUFTLEdBQUc3QixLQUFLOUIsRUFBRSxJQUFJNEIsU0FBUzVCLEVBQUUsWUFBWXNDLFVBQVV0QyxNQUFJLEtBQUssSUFBRzRELFFBQU9oQixPQUFPaUIsT0FBSzVELFNBQVMyQyxPQUFPaUIsS0FBS0EsSUFBSSxJQUFFdkIsV0FBU3JDLFNBQVNxQyxRQUFRLElBQUV3QixRQUFVQyxPQUFNWixLQUFLYSxVQUFVLEdBQUVDLE9BQU1BLENBQUE5RCxXQUFRZ0QsS0FBS2UsTUFBTS9ELE1BQU0sR0FBRWdFLFNBQVFBLE1BQUl2QixPQUFPd0IsUUFBUSxFQUFDQyxjQUFhLEtBQUksQ0FBQyxFQUFDLENBQUM7QUFDaFMsUUFBTUMsUUFBTWxDLFNBQU9FLFdBQVNvQixPQUFPWSxRQUFNLENBQUNyRyxXQUFXNEIsT0FBTXNELEtBQUthLFVBQVUsQ0FBQyxJQUFHTyxZQUFVckcsYUFBYW9HLEtBQUssR0FBRUUsVUFBUXJILE9BQTZCLElBQUksR0FBRXNILE9BQUtsQixPQUFPbUIsV0FBU2xCLE9BQU9rQjtBQUNuTCxRQUFNQyxVQUFRN0IsUUFBUVIsV0FBU2tCLE9BQU9vQixhQUFXckIsT0FBT3FCLFVBQVU7QUFDbEUsUUFBTUMsU0FBTzFCLEtBQUsyQixhQUFhLE9BQU0zRSxXQUFRO0FBQ3pDLFFBQUcsQ0FBQzRCLFdBQVM0QyxXQUFVLENBQUNyQyxZQUFVLENBQUNVLFVBQVc7QUFDOUMsUUFBSTtBQUNBLFVBQUdWLFVBQVU7QUFDVCxjQUFNeUMsV0FBU3JCLE9BQU9zQixRQUFRO0FBQUUsWUFBRyxDQUFDRCxTQUFTO0FBQzdDLGNBQU1FLFlBQVVyRSxZQUFZVCxNQUFNLEdBQUUrRSxRQUFnQyxDQUFDO0FBQ3JFLG1CQUFVMUUsT0FBT0osT0FBT0UsS0FBS3lFLFNBQVNHLEtBQUssRUFBdUIsS0FBRyxDQUFDekUsT0FBT1UsU0FBU1gsR0FBRyxFQUFHSixRQUFPK0UsT0FBT0QsT0FBTSxFQUFDLENBQUMxRSxHQUFHLEdBQUV5RSxVQUFVekUsR0FBRyxFQUFDLENBQUM7QUFDdEksY0FBTTRFLFdBQVMsTUFBTTVCLE9BQU82QixRQUFRLEVBQUMvRCxNQUFLLEVBQUNXLFlBQVdMLFNBQVM1QixJQUFHNkMsV0FBVVAsU0FBU3RDLEdBQUUsR0FBRUUsU0FBUTZFLFNBQVM3RSxTQUFRb0YsTUFBS0osTUFBSyxDQUFDO0FBQUUsWUFBRyxDQUFDeEIsT0FBTzZCLFVBQVV0RixTQUFTbUYsU0FBU3ZCLElBQUksR0FBRTFELE1BQU0sRUFBRTtBQUFBLE1BQ3hMLE9BQU07QUFDRixjQUFNbUYsT0FBSzFFLFlBQVlULE1BQU07QUFBRSxZQUFHTSxPQUFPVSxTQUFTLE9BQU8sRUFBRW1FLE1BQUtqRyxRQUFNO0FBQ3RFLGNBQU1rRSxPQUFPOEIsUUFBUSxFQUFDL0QsTUFBSyxFQUFDVyxZQUFXTCxTQUFTNUIsR0FBRSxHQUFFc0YsS0FBSSxDQUFDO0FBQUEsTUFDN0Q7QUFDQSxVQUFHZCxRQUFRZ0IsUUFBUXJILGdCQUFlcUcsUUFBUWdCLE9BQU87QUFBRTdDLGlCQUFXLGtCQUFrQnhDLE9BQU9oQixLQUFLLEdBQUc7QUFBRWtELGNBQVEsS0FBSztBQUFFYyxXQUFLZSxNQUFNckUsS0FBSztBQUFBLElBQ3BJLFNBQU80RixPQUFNO0FBQUMvQixhQUFPZ0MsT0FBT0QsS0FBSztBQUFBLElBQUU7QUFBQSxFQUN2QyxDQUFDO0FBQ0QsU0FBTyx1QkFBQyxTQUFNLE9BQU0sc0JBQXFCLFVBQVMsU0FBUSxVQUFTLCtEQUE4RCxRQUFRLHVCQUFDLGtCQUFlLFlBQVcsbUJBQWtCLFVBQVUsQ0FBQ3pDLFdBQVcsU0FBUyxNQUFJO0FBQUNULGdCQUFZLElBQUk7QUFBRVksU0FBS2UsTUFBTXJFLEtBQUs7QUFBRXdDLFlBQVEsSUFBSTtBQUFBLEVBQUUsR0FBRyw0QkFBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrSixHQUN0UjtBQUFBLEtBQUNXLGFBQVcsdUJBQUMsU0FBTSxVQUFTLFFBQU8saUhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0g7QUFBQSxJQUNwSU4sV0FBUyx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVVBLHFCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDM0QsdUJBQUMsY0FBVyxPQUFPVixNQUFNLGdCQUFlLFdBQVdBLGVBQUs2QixRQUFNLG1DQUMxRDtBQUFBLDZCQUFDLGFBQVUsT0FBTSw2QkFBNEIsTUFBTTdCLEtBQUs2QixLQUFLQSxNQUFNLFFBQVEsQ0FBQTlELFlBQVNBLFFBQVFDLElBQUksU0FBUztBQUFBLFFBQ3JHLEVBQUNRLEtBQUksUUFBT3JCLE9BQU0sV0FBVXdHLFFBQU9BLENBQUFDLE1BQUc5RixZQUFZOEYsQ0FBQyxFQUFDO0FBQUEsUUFBRSxFQUFDcEYsS0FBSSxhQUFZckIsT0FBTSxjQUFhd0csUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRXhHLGFBQVcsb0JBQW1CO0FBQUEsUUFBRSxFQUFDb0IsS0FBSSxRQUFPckIsT0FBTSxZQUFXd0csUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRXRHLFNBQU8sb0JBQW1CO0FBQUEsUUFBRSxFQUFDa0IsS0FBSSxVQUFTckIsT0FBTSxjQUFhd0csUUFBT0EsQ0FBQUMsTUFBRyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVDLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0IsRUFBRTtBQUFBLFFBQ2hSLEVBQUNyRixLQUFJLFFBQU9yQixPQUFNLFlBQVd3RyxRQUFPQSxDQUFBQyxNQUFHQSxFQUFFQyxXQUFTLFdBQVMsdUJBQUMsZUFBWTtBQUFBLGlDQUFDLGtCQUFlLFlBQVcsbUJBQWtCLFNBQVMsTUFBSTtBQUFDdEQsd0JBQVlxRCxDQUFDO0FBQUV6QyxpQkFBS2UsTUFBTWpFLFNBQVMyRixDQUFDLEVBQUV6RixNQUFNO0FBQUVrQyxvQkFBUSxJQUFJO0FBQUEsVUFBRSxHQUFHO0FBQUE7QUFBQSxZQUFhdkMsWUFBWThGLENBQUM7QUFBQSxlQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSjtBQUFBLFVBQWlCLHVCQUFDLGtCQUFlLFlBQVcsbUJBQWtCLFNBQVMsTUFBSW5ELFdBQVdtRCxDQUFDLEdBQUc7QUFBQTtBQUFBLFlBQVk5RixZQUFZOEYsQ0FBQztBQUFBLGVBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsYUFBeFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5UyxJQUFlLG1CQUFrQjtBQUFBLE1BQUMsS0FGMVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdFO0FBQUEsTUFBRSx1QkFBQyxrQkFBZSxPQUFNLHNCQUFxQixhQUFhNUQsS0FBSzhELGFBQWEsU0FBUzlELEtBQUsrRCxTQUFTLE1BQU0vRCxLQUFLZ0UsZUFBZSxZQUFZaEUsS0FBS2lFLFlBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUo7QUFBQSxTQUovRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzlELEtBTEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtJO0FBQUEsSUFDSix1QkFBQyxjQUFXLE1BQVksT0FBTzNELFdBQVMsZUFBZXhDLFlBQVl3QyxRQUFRLENBQUMsS0FBRyxnQkFBZ0IsTUFBWSxTQUFTLE1BQUlELFFBQVEsS0FBSyxHQUFHLFNBQVMsdUJBQUMsVUFBTyxNQUFLLFVBQVMsTUFBSyxrQkFBaUIsU0FBUSxhQUFZLFVBQVVvQyxRQUFNRSxXQUFTLENBQUM1QyxXQUFVLENBQUNPLFlBQVUsQ0FBQ1UsYUFBYUYsUUFBUVIsUUFBUSxLQUFHLENBQUNvQixPQUFPWSxPQUFRLDJCQUFoSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJLLEdBQ3hUO0FBQUEsNkJBQUMsZUFBWSxPQUFPZixPQUFPa0MsU0FBT2pDLE9BQU9pQyxTQUFPN0MsT0FBTzZDLFNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUFFLHVCQUFDLGlCQUFjLFFBQWdCLFFBQWdCLFFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUN4SGhGLE9BQU95RixTQUFPLEtBQUcsdUJBQUMsU0FBTSxVQUFTLFFBQU8sNElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUo7QUFBQSxNQUNySyx1QkFBQyxjQUFXLFdBQVUsUUFBTyxJQUFHLGtCQUFpQixZQUFVLE1BQUMsS0FBSyxDQUFBQyxTQUFNO0FBQUMzQixnQkFBUWdCLFVBQVFXO0FBQUs1QixrQkFBVTRCLElBQUk7QUFBQSxNQUFFLEdBQUcsVUFBVXRCLFFBQVEsb0JBQWtCLENBQUNQLFFBQU0sU0FBT1IsUUFDNUoxRCxpQkFBT0UsS0FBS3BCLE1BQU0sRUFBdUJxQixJQUFJLENBQUFDLFFBQUssdUJBQUMsYUFBb0IsT0FBT1osT0FBT1ksR0FBRyxHQUFHLEdBQUkyQyxLQUFLaUQsU0FBUzVGLEdBQUcsR0FBRyxVQUFVaUUsUUFBTSxDQUFDMUMsV0FBU3RCLE9BQU9VLFNBQVNYLEdBQUcsR0FBRyxPQUFPc0MsUUFBUUssS0FBS2tELFVBQVVDLE9BQU85RixHQUFHLENBQUMsR0FBRyxZQUFZMkMsS0FBS2tELFVBQVVDLE9BQU85RixHQUFHLEdBQUdlLFdBQXJMZixLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZNLENBQUUsS0FEdlE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLE1BQU1zQyxRQUFRTixPQUFPLEdBQUcsT0FBTSxzQkFBcUIsY0FBYSxzQkFBcUIsYUFBYSxXQUFXQSxVQUFRMUMsWUFBWTBDLE9BQU8sSUFBRSxFQUFFLFFBQVFaLFNBQVMyRSxXQUFXLHdGQUF3RixlQUFhLE1BQUMsTUFBTTlDLE9BQU9pQixTQUFTLE9BQU9qQixPQUFPZ0MsT0FBTyxTQUFTLE1BQUloRCxXQUFXLElBQUksR0FBRyxXQUFXLE9BQU0rRCxXQUFRO0FBQUMsVUFBRyxDQUFDaEUsUUFBUTtBQUFPLFlBQU1pQixPQUFPNEIsUUFBUSxFQUFDL0QsTUFBSyxFQUFDVyxZQUFXTCxTQUFTNUIsSUFBRzZDLFdBQVVMLFFBQVF4QyxHQUFFLEdBQUVzRixNQUFLLEVBQUNtQixpQkFBZ0JqRSxRQUFRdEMsU0FBUXNHLE9BQU0sRUFBQyxDQUFDO0FBQUU3RCxpQkFBVyx5QkFBeUI3QyxZQUFZMEMsT0FBTyxDQUFDLEdBQUc7QUFBQSxJQUFFLEtBQTFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRrQjtBQUFBLE9BaEJ6a0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCUDtBQUNKO0FBQUNYLEdBOUNlRixnQkFBYztBQUFBLFVBQ2I3RCxVQUFtQkMsUUFDckJrQixhQUVFckIsUUFJRkosU0FBb0VDLFVBQ2xFSSxZQUFxRUEsWUFBMEZBLFlBQy9KRyxtQkFDMkVFLFlBQVk7QUFBQTtBQUFBLEtBWHhGeUQ7QUFBYyxJQUFBK0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwiQWxlcnQiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJ6b2RSZXNvbHZlciIsInoiLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJ1c2VWZXJzaW9uZWREcmFmdCIsImRyYWZ0RXF1YWwiLCJ1c2VEcmFmdEZvcm0iLCJtYXJrRHJhZnRDbGVhbiIsImNvZGVQb2ludExlbmd0aCIsIkRyYWZ0Q29uZmxpY3QiLCJGb3JtRmllbGRzIiwiQWN0aW9uR3JvdXAiLCJQYW5lbCIsIlF1ZXJ5U3RhdGUiLCJEYXRhVGFibGUiLCJTdGF0dXMiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJDb25maXJtRGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJMb29rdXBMb2FkTW9yZSIsInVzZVBhZ2VkQXBpIiwibGltaXRzIiwibGFiZWwiLCJyZWNpcGllbnQiLCJwaG9uZSIsImxpbmUxIiwid2FyZCIsImRpc3RyaWN0IiwicHJvdmluY2UiLCJwb3N0YWxDb2RlIiwiY291bnRyeUNvZGUiLCJsYWJlbHMiLCJlbXB0eSIsImFkZHJlc3NOYW1lIiwiYWRkcmVzcyIsImlkIiwic25hcHNob3QiLCJ2ZXJzaW9uIiwidmFsdWVzIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJrZXlzIiwibWFwIiwia2V5IiwiaGlkZGVuIiwicmVkYWN0ZWRGaWVsZHMiLCJmaWx0ZXIiLCJhZGRyZXNzQm9keSIsImZpZWxkcyIsInNjaGVtYUZvciIsIm9iamVjdCIsInN0cmluZyIsInN1cGVyUmVmaW5lIiwiY3R4IiwiaW5jbHVkZXMiLCJhZGRJc3N1ZSIsImNvZGUiLCJwYXRoIiwibWVzc2FnZSIsInRyaW0iLCJ0b0xvY2FsZUxvd2VyQ2FzZSIsInRlc3QiLCJBZGRyZXNzZXNQYW5lbCIsImN1c3RvbWVyIiwiX3MiLCJzaG9wIiwiY2FuRWRpdCIsImxpc3QiLCJjdXN0b21lcklkIiwicXVlcnkiLCJsaW1pdCIsIm9wZW4iLCJzZXRPcGVuIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImFyY2hpdmUiLCJzZXRBcmNoaXZlIiwic3VjY2VzcyIsInNldFN1Y2Nlc3MiLCJkZXRhaWwiLCJhZGRyZXNzSWQiLCJCb29sZWFuIiwiZmllbGQiLCJjYW5DcmVhdGUiLCJzb21lIiwic2NoZW1hIiwiZm9ybSIsImRlZmF1bHRWYWx1ZXMiLCJyZXNvbHZlciIsImNvbnRyb2wiLCJjcmVhdGUiLCJ1cGRhdGUiLCJyZW1vdmUiLCJlZGl0b3IiLCJpZGVudGl0eSIsInNvdXJjZSIsImRhdGEiLCJ1bmRlZmluZWQiLCJkcmFmdCIsImdldFZhbHVlcyIsImFwcGx5IiwicmVzZXQiLCJyZWZyZXNoIiwicmVmZXRjaCIsInRocm93T25FcnJvciIsImRpcnR5IiwiYmluZERyYWZ0IiwiZm9ybVJlZiIsImJ1c3kiLCJwZW5kaW5nIiwiYmxvY2tlZCIsInVucmVzb2x2ZWQiLCJzdWJtaXQiLCJoYW5kbGVTdWJtaXQiLCJwcmVwYXJlZCIsInByZXBhcmUiLCJjb252ZXJ0ZWQiLCJwYXRjaCIsImFzc2lnbiIsInJlc3BvbnNlIiwiZXhlY3V0ZSIsImJvZHkiLCJjb21taXR0ZWQiLCJjdXJyZW50IiwiZXJyb3IiLCJmYWlsZWQiLCJyZW5kZXIiLCJhIiwic3RhdHVzIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwibGVuZ3RoIiwibm9kZSIsInJlZ2lzdGVyIiwiZm9ybVN0YXRlIiwiZXJyb3JzIiwiZGlzcGxheU5hbWUiLCJyZWFzb24iLCJleHBlY3RlZFZlcnNpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhZGRyZXNzZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEFsZXJ0LCBCdXR0b24sIFRleHRGaWVsZCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyB1c2VGb3JtLCB1c2VXYXRjaCB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XHJcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnO1xyXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJztcclxuaW1wb3J0IHR5cGUgeyBDdXN0b21lciwgQ3VzdG9tZXJBZGRyZXNzLCBDdXN0b21lckFkZHJlc3NXcml0ZSwgQ3VzdG9tZXJBZGRyZXNzV3JpdGVQYXRjaCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xyXG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xyXG5pbXBvcnQgeyB1c2VTY29wZSwgdXNlQ2FuIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xyXG5pbXBvcnQgeyB1c2VWZXJzaW9uZWREcmFmdCwgZHJhZnRFcXVhbCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XHJcbmltcG9ydCB7IHVzZURyYWZ0Rm9ybSwgbWFya0RyYWZ0Q2xlYW4gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9kaXJ0eS1kcmFmdHMnO1xyXG5pbXBvcnQgeyBjb2RlUG9pbnRMZW5ndGggfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xyXG5pbXBvcnQgeyBEcmFmdENvbmZsaWN0IH0gZnJvbSAnQC9zaGFyZWQvdWkvZHJhZnQtY29uZmxpY3QnO1xyXG5pbXBvcnQgeyBGb3JtRmllbGRzLCBBY3Rpb25Hcm91cCB9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgUGFuZWwsIFF1ZXJ5U3RhdGUsIERhdGFUYWJsZSwgU3RhdHVzLCBNdXRhdGlvbkJ1dHRvbiwgRWRpdERpYWxvZywgQ29uZmlybURpYWxvZywgRXJyb3JOb3RpY2UsIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmltcG9ydCB7IHVzZVBhZ2VkQXBpIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcclxuXHJcbmNvbnN0IGxpbWl0cz17bGFiZWw6MTIwLHJlY2lwaWVudDoxNjAscGhvbmU6NDAsbGluZTE6NTAwLHdhcmQ6MTIwLGRpc3RyaWN0OjEyMCxwcm92aW5jZToxMjAscG9zdGFsQ29kZToyMCxjb3VudHJ5Q29kZToyfSBhcyBjb25zdDtcclxuY29uc3QgbGFiZWxzPXtsYWJlbDonVMOqbiDEkeG7i2EgY2jhu4knLHJlY2lwaWVudDonTmfGsOG7nWkgbmjhuq1uJyxwaG9uZTonxJBp4buHbiB0aG/huqFpIGdpYW8gaMOgbmcnLGxpbmUxOifEkOG7i2EgY2jhu4kgY2hpIHRp4bq/dCcsd2FyZDonUGjGsOG7nW5nIC8geMOjJyxkaXN0cmljdDonUXXhuq1uIC8gaHV54buHbicscHJvdmluY2U6J1Thu4luaCAvIHRow6BuaCBwaOG7kScscG9zdGFsQ29kZTonTcOjIGLGsHUgY2jDrW5oJyxjb3VudHJ5Q29kZTonTcOjIHF14buRYyBnaWEnfSBhcyBjb25zdDtcclxudHlwZSBGaWVsZHM9UmVjb3JkPGtleW9mIHR5cGVvZiBsaW1pdHMsc3RyaW5nPjtcclxuY29uc3QgZW1wdHk6RmllbGRzPXtsYWJlbDonJyxyZWNpcGllbnQ6JycscGhvbmU6JycsbGluZTE6Jycsd2FyZDonJyxkaXN0cmljdDonJyxwcm92aW5jZTonJyxwb3N0YWxDb2RlOicnLGNvdW50cnlDb2RlOidWTid9O1xyXG5mdW5jdGlvbiBhZGRyZXNzTmFtZShhZGRyZXNzOkN1c3RvbWVyQWRkcmVzcykge3JldHVybiBhZGRyZXNzLmxhYmVsIHx8IGDEkOG7i2EgY2jhu4kgJHthZGRyZXNzLmlkfWA7fVxyXG5mdW5jdGlvbiBzbmFwc2hvdChhZGRyZXNzOkN1c3RvbWVyQWRkcmVzcykge1xyXG4gICAgcmV0dXJuIHt2ZXJzaW9uOmFkZHJlc3MudmVyc2lvbix2YWx1ZXM6T2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5rZXlzKGxpbWl0cykubWFwKGtleT0+W2tleSxhZGRyZXNzW2tleSBhcyBrZXlvZiBGaWVsZHNdfHwnJ10pKSBhcyBGaWVsZHMsaGlkZGVuOmFkZHJlc3MucmVkYWN0ZWRGaWVsZHMuZmlsdGVyKChrZXkpOmtleSBpcyBrZXlvZiBGaWVsZHM9PmtleSBpbiBsaW1pdHMpfTtcclxufVxyXG5mdW5jdGlvbiBhZGRyZXNzQm9keShmaWVsZHM6RmllbGRzKTpDdXN0b21lckFkZHJlc3NXcml0ZSB7XHJcbiAgICByZXR1cm4gey4uLmZpZWxkcyxwaG9uZTpmaWVsZHMucGhvbmV8fG51bGwsd2FyZDpmaWVsZHMud2FyZHx8bnVsbCxkaXN0cmljdDpmaWVsZHMuZGlzdHJpY3R8fG51bGwscG9zdGFsQ29kZTpmaWVsZHMucG9zdGFsQ29kZXx8bnVsbH07XHJcbn1cclxuZnVuY3Rpb24gc2NoZW1hRm9yKGhpZGRlbjpyZWFkb25seSBzdHJpbmdbXSkge1xyXG4gICAgcmV0dXJuIHoub2JqZWN0KHtsYWJlbDp6LnN0cmluZygpLHJlY2lwaWVudDp6LnN0cmluZygpLHBob25lOnouc3RyaW5nKCksbGluZTE6ei5zdHJpbmcoKSx3YXJkOnouc3RyaW5nKCksZGlzdHJpY3Q6ei5zdHJpbmcoKSxwcm92aW5jZTp6LnN0cmluZygpLHBvc3RhbENvZGU6ei5zdHJpbmcoKSxjb3VudHJ5Q29kZTp6LnN0cmluZygpfSkuc3VwZXJSZWZpbmUoKGZpZWxkcyxjdHgpPT57XHJcbiAgICAgICAgZm9yKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhsaW1pdHMpIGFzIChrZXlvZiBGaWVsZHMpW10pIHtcclxuICAgICAgICAgICAgaWYoaGlkZGVuLmluY2x1ZGVzKGtleSkpY29udGludWU7XHJcbiAgICAgICAgICAgIGlmKGNvZGVQb2ludExlbmd0aChmaWVsZHNba2V5XSk+bGltaXRzW2tleV0pY3R4LmFkZElzc3VlKHtjb2RlOidjdXN0b20nLHBhdGg6W2tleV0sbWVzc2FnZTpgJHtsYWJlbHNba2V5XX0gdOG7kWkgxJFhICR7bGltaXRzW2tleV19IGvDvSB04buxLmB9KTtcclxuICAgICAgICAgICAgaWYoWydsYWJlbCcsJ3JlY2lwaWVudCcsJ3Bob25lJywnbGluZTEnLCdwcm92aW5jZScsJ2NvdW50cnlDb2RlJ10uaW5jbHVkZXMoa2V5KSYmIWZpZWxkc1trZXldLnRyaW0oKSljdHguYWRkSXNzdWUoe2NvZGU6J2N1c3RvbScscGF0aDpba2V5XSxtZXNzYWdlOmBOaOG6rXAgJHtsYWJlbHNba2V5XS50b0xvY2FsZUxvd2VyQ2FzZSgndmknKX0uYH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZighaGlkZGVuLmluY2x1ZGVzKCdjb3VudHJ5Q29kZScpJiYhL15bQS1aXXsyfSQvLnRlc3QoZmllbGRzLmNvdW50cnlDb2RlKSljdHguYWRkSXNzdWUoe2NvZGU6J2N1c3RvbScscGF0aDpbJ2NvdW50cnlDb2RlJ10sbWVzc2FnZTonRMO5bmcgbcOjIHF14buRYyBnaWEgMiBjaOG7ryBpbiBob2EsIHbDrSBk4bulIFZOLid9KTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQWRkcmVzc2VzUGFuZWwoe2N1c3RvbWVyfTp7Y3VzdG9tZXI6Q3VzdG9tZXJ9KSB7XHJcbiAgICBjb25zdCB7c2hvcH09dXNlU2NvcGUoKSxjYW5FZGl0PXVzZUNhbignY3VzdG9tZXJzLndyaXRlJyk7XHJcbiAgICBjb25zdCBsaXN0PXVzZVBhZ2VkQXBpKCdsaXN0Q3VzdG9tZXJBZGRyZXNzZXMnLHtwYXRoOntjdXN0b21lcklkOmN1c3RvbWVyLmlkfSxxdWVyeTp7bGltaXQ6MjB9fSk7XHJcbiAgICBjb25zdCBbb3BlbixzZXRPcGVuXT11c2VTdGF0ZShmYWxzZSksW3NlbGVjdGVkLHNldFNlbGVjdGVkXT11c2VTdGF0ZTxDdXN0b21lckFkZHJlc3N8bnVsbD4obnVsbCksW2FyY2hpdmUsc2V0QXJjaGl2ZV09dXNlU3RhdGU8Q3VzdG9tZXJBZGRyZXNzfG51bGw+KG51bGwpLFtzdWNjZXNzLHNldFN1Y2Nlc3NdPXVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IGRldGFpbD11c2VBcGkoJ2dldEN1c3RvbWVyQWRkcmVzcycse3BhdGg6e2N1c3RvbWVySWQ6Y3VzdG9tZXIuaWQsYWRkcmVzc0lkOnNlbGVjdGVkPy5pZHx8Jyd9fSxvcGVuJiZCb29sZWFuKHNlbGVjdGVkKSk7XHJcbiAgICBjb25zdCBoaWRkZW49dXNlTWVtbygoKT0+T2JqZWN0LmtleXMobGltaXRzKS5maWx0ZXIoZmllbGQ9PmN1c3RvbWVyLnJlZGFjdGVkRmllbGRzLmluY2x1ZGVzKCdhZGRyZXNzZXMnKXx8Y3VzdG9tZXIucmVkYWN0ZWRGaWVsZHMuaW5jbHVkZXMoJ3NoaXBwaW5nQWRkcmVzcycpfHxjdXN0b21lci5yZWRhY3RlZEZpZWxkcy5pbmNsdWRlcyhgYWRkcmVzcy4ke2ZpZWxkfWApfHwoZmllbGQ9PT0ncGhvbmUnJiZjdXN0b21lci5yZWRhY3RlZEZpZWxkcy5pbmNsdWRlcygncGhvbmUnKSkpLFtjdXN0b21lci5yZWRhY3RlZEZpZWxkc10pO1xyXG4gICAgY29uc3QgY2FuQ3JlYXRlPSFoaWRkZW4uc29tZShrZXk9PltcImxhYmVsXCIsXCJyZWNpcGllbnRcIixcImxpbmUxXCIsXCJwcm92aW5jZVwiLFwiY291bnRyeUNvZGVcIl0uaW5jbHVkZXMoa2V5KSk7XHJcbiAgICBjb25zdCBzY2hlbWE9dXNlTWVtbygoKT0+c2NoZW1hRm9yKGhpZGRlbiksW2hpZGRlbl0pO1xyXG4gICAgY29uc3QgZm9ybT11c2VGb3JtPEZpZWxkcz4oe2RlZmF1bHRWYWx1ZXM6ZW1wdHkscmVzb2x2ZXI6em9kUmVzb2x2ZXIoc2NoZW1hKX0pO3VzZVdhdGNoKHtjb250cm9sOmZvcm0uY29udHJvbH0pO1xyXG4gICAgY29uc3QgY3JlYXRlPXVzZUNvbW1hbmQoJ2NyZWF0ZUN1c3RvbWVyQWRkcmVzcycsWydsaXN0Q3VzdG9tZXJBZGRyZXNzZXMnXSksdXBkYXRlPXVzZUNvbW1hbmQoJ3VwZGF0ZUN1c3RvbWVyQWRkcmVzcycsWydsaXN0Q3VzdG9tZXJBZGRyZXNzZXMnLCdnZXRDdXN0b21lckFkZHJlc3MnXSkscmVtb3ZlPXVzZUNvbW1hbmQoJ2FyY2hpdmVDdXN0b21lckFkZHJlc3MnLFsnbGlzdEN1c3RvbWVyQWRkcmVzc2VzJywnZ2V0Q3VzdG9tZXJBZGRyZXNzJ10pO1xyXG4gICAgY29uc3QgZWRpdG9yPXVzZVZlcnNpb25lZERyYWZ0KHtpZGVudGl0eTpgJHtzaG9wLmlkfToke2N1c3RvbWVyLmlkfTphZGRyZXNzOiR7c2VsZWN0ZWQ/LmlkfHwnbmV3J31gLHNvdXJjZTpkZXRhaWwuZGF0YT9zbmFwc2hvdChkZXRhaWwuZGF0YS5kYXRhKTpzZWxlY3RlZD9zbmFwc2hvdChzZWxlY3RlZCk6dW5kZWZpbmVkLGRyYWZ0OmZvcm0uZ2V0VmFsdWVzKCksYXBwbHk6dmFsdWVzPT5mb3JtLnJlc2V0KHZhbHVlcykscmVmcmVzaDooKT0+ZGV0YWlsLnJlZmV0Y2goe3Rocm93T25FcnJvcjp0cnVlfSl9KTtcclxuICAgIGNvbnN0IGRpcnR5PW9wZW4mJihzZWxlY3RlZD9lZGl0b3IuZGlydHk6IWRyYWZ0RXF1YWwoZW1wdHksZm9ybS5nZXRWYWx1ZXMoKSkpLGJpbmREcmFmdD11c2VEcmFmdEZvcm0oZGlydHkpLGZvcm1SZWY9dXNlUmVmPEhUTUxGb3JtRWxlbWVudHxudWxsPihudWxsKSxidXN5PWNyZWF0ZS5wZW5kaW5nfHx1cGRhdGUucGVuZGluZztcclxuICAgIGNvbnN0IGJsb2NrZWQ9Qm9vbGVhbihzZWxlY3RlZD91cGRhdGUudW5yZXNvbHZlZDpjcmVhdGUudW5yZXNvbHZlZCk7XHJcbiAgICBjb25zdCBzdWJtaXQ9Zm9ybS5oYW5kbGVTdWJtaXQoYXN5bmMgdmFsdWVzPT57XHJcbiAgICAgICAgaWYoIWNhbkVkaXR8fGJsb2NrZWR8fCghc2VsZWN0ZWQmJiFjYW5DcmVhdGUpKXJldHVybjtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZihzZWxlY3RlZCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcHJlcGFyZWQ9ZWRpdG9yLnByZXBhcmUoKTtpZighcHJlcGFyZWQpcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY29udmVydGVkPWFkZHJlc3NCb2R5KHZhbHVlcykscGF0Y2g6Q3VzdG9tZXJBZGRyZXNzV3JpdGVQYXRjaD17fTtcclxuICAgICAgICAgICAgICAgIGZvcihjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMocHJlcGFyZWQucGF0Y2gpIGFzIChrZXlvZiBGaWVsZHMpW10pIGlmKCFoaWRkZW4uaW5jbHVkZXMoa2V5KSkgT2JqZWN0LmFzc2lnbihwYXRjaCx7W2tleV06Y29udmVydGVkW2tleV19KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlPWF3YWl0IHVwZGF0ZS5leGVjdXRlKHtwYXRoOntjdXN0b21lcklkOmN1c3RvbWVyLmlkLGFkZHJlc3NJZDpzZWxlY3RlZC5pZH0sdmVyc2lvbjpwcmVwYXJlZC52ZXJzaW9uLGJvZHk6cGF0Y2h9KTtpZighZWRpdG9yLmNvbW1pdHRlZChzbmFwc2hvdChyZXNwb25zZS5kYXRhKSx2YWx1ZXMpKXJldHVybjtcclxuICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgYm9keT1hZGRyZXNzQm9keSh2YWx1ZXMpO2lmKGhpZGRlbi5pbmNsdWRlcygncGhvbmUnKSlib2R5LnBob25lPW51bGw7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7cGF0aDp7Y3VzdG9tZXJJZDpjdXN0b21lci5pZH0sYm9keX0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKGZvcm1SZWYuY3VycmVudCltYXJrRHJhZnRDbGVhbihmb3JtUmVmLmN1cnJlbnQpO3NldFN1Y2Nlc3MoYMSQw6MgbMawdSDEkeG7i2EgY2jhu4kgJHt2YWx1ZXMubGFiZWx9LmApO3NldE9wZW4oZmFsc2UpO2Zvcm0ucmVzZXQoZW1wdHkpO1xyXG4gICAgICAgIH1jYXRjaChlcnJvcil7ZWRpdG9yLmZhaWxlZChlcnJvcik7fVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gPFBhbmVsIHRpdGxlPVwixJDhu4thIGNo4buJIGtow6FjaCBow6BuZ1wiIGJvZHlNb2RlPVwiaW5zZXRcIiBzdWJ0aXRsZT1cIsSQ4buLYSBjaOG7iSBz4butYSBzYXUga2jDtG5nIGzDoG0gxJHhu5VpIHNuYXBzaG90IGPhu6dhIMSRxqFuIMSRw6MgeMOhYyBuaOG6rW4uXCIgYWN0aW9uPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImN1c3RvbWVycy53cml0ZVwiIGRpc2FibGVkPXshY2FuQ3JlYXRlfSBvbkNsaWNrPXsoKT0+e3NldFNlbGVjdGVkKG51bGwpO2Zvcm0ucmVzZXQoZW1wdHkpO3NldE9wZW4odHJ1ZSk7fX0+VGjDqm0gxJHhu4thIGNo4buJPC9NdXRhdGlvbkJ1dHRvbj59PlxyXG4gICAgICAgIHshY2FuQ3JlYXRlJiY8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+UXV54buBbiBoaeG7h24gdOG6oWkgY2hlIHRow7RuZyB0aW4gYuG6r3QgYnXhu5ljIGPhu6dhIMSR4buLYSBjaOG7iTsgY+G6p24gbmfGsOG7nWkgY8OzIHF1eeG7gW4gcGjDuSBo4bujcCDEkeG7gyB04bqhbyDEkeG7i2EgY2jhu4kgbeG7m2kuPC9BbGVydD59XHJcbiAgICAgICAge3N1Y2Nlc3MmJjxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+e3N1Y2Nlc3N9PC9BbGVydD59XHJcbiAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEmJjw+XHJcbiAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCLEkOG7i2EgY2jhu4kgdHJvbmcgaOG7kyBzxqEga2jDoWNoXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17YWRkcmVzcz0+YWRkcmVzcy5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAge2tleTonbmFtZScsbGFiZWw6J8SQ4buLYSBjaOG7iScscmVuZGVyOmE9PmFkZHJlc3NOYW1lKGEpfSx7a2V5OidyZWNpcGllbnQnLGxhYmVsOidOZ8aw4budaSBuaOG6rW4nLHJlbmRlcjphPT5hLnJlY2lwaWVudHx8J8SQw6MgY2hlIHRoZW8gcXV54buBbid9LHtrZXk6J2xpbmUnLGxhYmVsOifEkOG7i2EgxJFp4buDbScscmVuZGVyOmE9PmEubGluZTF8fCfEkMOjIGNoZSB0aGVvIHF1eeG7gW4nfSx7a2V5OidzdGF0dXMnLGxhYmVsOidUcuG6oW5nIHRow6FpJyxyZW5kZXI6YT0+PFN0YXR1cyB2YWx1ZT17YS5zdGF0dXN9Lz59LFxyXG4gICAgICAgICAgICAgICAge2tleTonZWRpdCcsbGFiZWw6J1RoYW8gdMOhYycscmVuZGVyOmE9PmEuc3RhdHVzPT09J2FjdGl2ZSc/PEFjdGlvbkdyb3VwPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiY3VzdG9tZXJzLndyaXRlXCIgb25DbGljaz17KCk9PntzZXRTZWxlY3RlZChhKTtmb3JtLnJlc2V0KHNuYXBzaG90KGEpLnZhbHVlcyk7c2V0T3Blbih0cnVlKTt9fT5T4butYSDEkeG7i2EgY2jhu4kge2FkZHJlc3NOYW1lKGEpfTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJjdXN0b21lcnMud3JpdGVcIiBvbkNsaWNrPXsoKT0+c2V0QXJjaGl2ZShhKX0+Tmfhu6tuZyBkw7luZyB7YWRkcmVzc05hbWUoYSl9PC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPjonTOG7i2NoIHPhu60gxJHGsOG7o2MgZ2nhu68nfSxcclxuICAgICAgICAgICAgXX0vPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cIsSR4buLYSBjaOG7iSBraMOhY2ggaMOgbmdcIiBsb2FkZWRDb3VudD17bGlzdC5sb2FkZWRDb3VudH0gaGFzTW9yZT17bGlzdC5oYXNNb3JlfSBidXN5PXtsaXN0LmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2xpc3QubG9hZE1vcmV9Lz5cclxuICAgICAgICA8Lz59PC9RdWVyeVN0YXRlPlxyXG4gICAgICAgIDxFZGl0RGlhbG9nIG9wZW49e29wZW59IHRpdGxlPXtzZWxlY3RlZD9gU+G7rWEgxJHhu4thIGNo4buJICR7YWRkcmVzc05hbWUoc2VsZWN0ZWQpfWA6J1Row6ptIMSR4buLYSBjaOG7iSd9IGJ1c3k9e2J1c3l9IG9uQ2xvc2U9eygpPT5zZXRPcGVuKGZhbHNlKX0gYWN0aW9ucz17PEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZm9ybT1cImFkZHJlc3MtZWRpdG9yXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtidXN5fHxibG9ja2VkfHwhY2FuRWRpdHx8KCFzZWxlY3RlZCYmIWNhbkNyZWF0ZSl8fChCb29sZWFuKHNlbGVjdGVkKSYmIWVkaXRvci5kaXJ0eSl9PkzGsHUgxJHhu4thIGNo4buJPC9CdXR0b24+fT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3J8fHVwZGF0ZS5lcnJvcnx8ZGV0YWlsLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17bGFiZWxzfSBidXN5PXtidXN5fS8+XHJcbiAgICAgICAgICAgIHtoaWRkZW4ubGVuZ3RoPjAmJjxBbGVydCBzZXZlcml0eT1cImluZm9cIj5N4buZdCBz4buRIHRyxrDhu51uZyDEkeG7i2EgY2jhu4kgxJFhbmcgYuG7iyBjaGUgdsOgIGtow7RuZyDEkcaw4bujYyBnaGkgbOG6oWkuIMSQ4buLYSBjaOG7iSBt4bubaSB0aGnhur91IHRow7RuZyB0aW4gZ2lhbyBow6BuZyBz4bq9IGNoxrBhIGTDuW5nIMSR4buDIHjDoWMgbmjhuq1uIMSRxqFuLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgaWQ9XCJhZGRyZXNzLWVkaXRvclwiIG5vVmFsaWRhdGUgcmVmPXtub2RlPT57Zm9ybVJlZi5jdXJyZW50PW5vZGU7YmluZERyYWZ0KG5vZGUpO319IG9uU3VibWl0PXtzdWJtaXR9IGRhdGEtZHJhZnQtY2xlYW49eyFkaXJ0eT8ndHJ1ZSc6dW5kZWZpbmVkfT5cclxuICAgICAgICAgICAgICAgIHsoT2JqZWN0LmtleXMobGltaXRzKSBhcyAoa2V5b2YgRmllbGRzKVtdKS5tYXAoa2V5PT48VGV4dEZpZWxkIGtleT17a2V5fSBsYWJlbD17bGFiZWxzW2tleV19IHsuLi5mb3JtLnJlZ2lzdGVyKGtleSl9IGRpc2FibGVkPXtidXN5fHwhY2FuRWRpdHx8aGlkZGVuLmluY2x1ZGVzKGtleSl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9yc1trZXldKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzW2tleV0/Lm1lc3NhZ2V9Lz4pfVxyXG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgICAgIDxDb25maXJtRGlhbG9nIG9wZW49e0Jvb2xlYW4oYXJjaGl2ZSl9IHRpdGxlPVwiTmfhu6tuZyBkw7luZyDEkeG7i2EgY2jhu4lcIiBjb25maXJtTGFiZWw9XCJOZ+G7q25nIGTDuW5nIMSR4buLYSBjaOG7iVwiIGRlc2NyaXB0aW9uPXtgxJDhu4thIGNo4buJICR7YXJjaGl2ZT9hZGRyZXNzTmFtZShhcmNoaXZlKTonJ30gY+G7p2EgJHtjdXN0b21lci5kaXNwbGF5TmFtZX0ga2jDtG5nIGPDsm4gZMO5bmcgY2hvIMSRxqFuIG3hu5tpLiBTbmFwc2hvdCB0cm9uZyDEkcahbiDEkcOjIHjDoWMgbmjhuq1uIHbDoCBs4buLY2ggc+G7rSB24bqrbiDEkcaw4bujYyBnaeG7ry5gfSByZXF1aXJlUmVhc29uIGJ1c3k9e3JlbW92ZS5wZW5kaW5nfSBlcnJvcj17cmVtb3ZlLmVycm9yfSBvbkNsb3NlPXsoKT0+c2V0QXJjaGl2ZShudWxsKX0gb25Db25maXJtPXthc3luYyByZWFzb249PntpZighYXJjaGl2ZSlyZXR1cm47YXdhaXQgcmVtb3ZlLmV4ZWN1dGUoe3BhdGg6e2N1c3RvbWVySWQ6Y3VzdG9tZXIuaWQsYWRkcmVzc0lkOmFyY2hpdmUuaWR9LGJvZHk6e2V4cGVjdGVkVmVyc2lvbjphcmNoaXZlLnZlcnNpb24scmVhc29ufX0pO3NldFN1Y2Nlc3MoYMSQw6Mgbmfhu6tuZyBkw7luZyDEkeG7i2EgY2jhu4kgJHthZGRyZXNzTmFtZShhcmNoaXZlKX0uYCk7fX0vPlxyXG4gICAgPC9QYW5lbD47XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvY3VzdG9tZXJzL2FkZHJlc3Nlcy50c3gifQ==