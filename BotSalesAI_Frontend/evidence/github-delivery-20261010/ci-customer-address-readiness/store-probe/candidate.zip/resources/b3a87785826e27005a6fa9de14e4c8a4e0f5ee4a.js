import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/customers/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react_jsx-dev-runtime.js?v=867dcec9"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import { useListReturn } from "/src/shared/model/list-return.ts";
import { markDraftClean, useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { ActionGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport7_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react.js?v=867dcec9"; const useMemo = __vite__cjsImport7_react["useMemo"]; const useRef = __vite__cjsImport7_react["useRef"]; const useState = __vite__cjsImport7_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useNavigate, useParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react-router-dom.js?v=afee4a3d";
import { useForm, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react-hook-form.js?v=431cd782";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@hookform_resolvers_zod.js?v=0c6cc459";
import { useTranslation } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react-i18next.js?v=baf259d4";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/zod.js?v=000ccb25";
import { Alert, Box, Button, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@mui_material.js?v=aff9c5ca";
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, codePointLength, dateTime } from "/src/shared/model/format.ts";
import { Amount, PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, RouteLink, DetailLine, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { AddressesPanel } from "/src/modules/customers/addresses.tsx";
const customerFormFields = [
  { name: "displayName", labelKey: "customers.form.customerName", multiline: false },
  { name: "phone", labelKey: "customers.form.phone", multiline: false },
  { name: "email", labelKey: "customers.form.email", multiline: false },
  { name: "notes", labelKey: "customers.form.notes", multiline: true }
];
function createCustomerSchema(copy) {
  return z.object({
    displayName: z.string().trim().min(1, copy.nameRequired).refine((value) => codePointLength(value) <= 160, copy.nameMax),
    phone: z.string().refine((value) => codePointLength(value) <= 40, copy.phoneMax),
    email: z.string().email(copy.emailFormat).or(z.literal("")),
    notes: z.string().refine((value) => codePointLength(value) <= 4e3, copy.notesMax)
  });
}
function useCustomerCopy() {
  _s();
  const { t } = useTranslation();
  const schema = useMemo(() => createCustomerSchema({
    nameRequired: t("customers.validation.nameRequired"),
    nameMax: t("customers.validation.nameMax"),
    phoneMax: t("customers.validation.phoneMax"),
    emailFormat: t("customers.validation.emailFormat"),
    notesMax: t("customers.validation.notesMax")
  }), [t]);
  return { t, schema };
}
_s(useCustomerCopy, "Sx+75xvTZZgGtIjs2XYJkhccmdg=", false, function() {
  return [useTranslation];
});
export function CustomersPage() {
  _s2();
  const { t, schema } = useCustomerCopy();
  const { shop } = useScope();
  const navigate = useNavigate();
  const list = useApi("listCustomers", { query: useListQuery("listCustomers") });
  const create = useCommand("createCustomer", ["listCustomers"]);
  const [open, setOpen] = useState(false);
  const form = useForm({ defaultValues: { displayName: "", phone: "", email: "", notes: "" }, resolver: zodResolver(schema) });
  const createForm = useRef(null);
  const submit = form.handleSubmit(async (fields) => {
    try {
      const response = await create.execute({ body: { ...fields, phone: fields.phone || null, email: fields.email || null } });
      if (createForm.current) {
        markDraftClean(createForm.current);
        const dialog = createForm.current.closest('[role="dialog"]');
        if (dialog) {
          dialog.dataset.draftClean = "true";
          delete dialog.dataset.draftDirty;
        }
      }
      setOpen(false);
      form.reset();
      navigate(`/s/${shop.id}/customers/${response.data.id}`);
    } catch {
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: t("customers.list.title"), subtitle: t("customers.list.subtitle"), actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", variant: "contained", onClick: () => setOpen(true), children: t("customers.list.addAction") }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 95,
      columnNumber: 107
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 95,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listCustomers", placeholder: t("customers.list.searchPlaceholder"), cursorParam: "cursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 95,
        columnNumber: 261
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: t("customers.list.tableLabel"), empty: t("customers.list.empty"), rows: list.data.data, rowKey: (c) => c.id, columns: [
          { key: "name", label: t("customers.list.customerColumn"), render: (c) => /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: c.displayName }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 96,
            columnNumber: 84
          }, this) },
          { key: "phone", label: t("customers.list.contactColumn"), render: (c) => c.phone || t("customers.list.contactUnavailable") },
          { key: "email", label: t("customers.list.emailColumn"), render: (c) => c.email || "—" },
          { key: "note", label: t("customers.list.notesColumn"), render: (c) => c.notes || "—" },
          { key: "action", label: "", render: (c) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/customers/${c.id}`, children: t("customers.list.profileAction") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 96,
            columnNumber: 525
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 95,
          columnNumber: 437
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 97,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 95,
        columnNumber: 435
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 95,
        columnNumber: 371
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 95,
      columnNumber: 254
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: t("customers.form.createTitle"), onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "customer-create-form", variant: "contained", disabled: create.pending, children: t("customers.form.createAction") }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 97,
      columnNumber: 197
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 97,
        columnNumber: 338
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: createForm, id: "customer-create-form", onSubmit: submit, noValidate: true, children: customerFormFields.map((field) => /* @__PURE__ */ jsxDEV(TextField, { label: t(field.labelKey), disabled: create.pending, ...form.register(field.name), error: !!form.formState.errors[field.name], helperText: form.formState.errors[field.name]?.message, multiline: field.multiline }, field.name, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 97,
        columnNumber: 510
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 97,
        columnNumber: 374
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 97,
      columnNumber: 71
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
    lineNumber: 95,
    columnNumber: 10
  }, this);
}
_s2(CustomersPage, "yJ1KpzI+X/qvAs98WiSiGcY7HHE=", false, function() {
  return [useCustomerCopy, useScope, useNavigate, useApi, useListQuery, useCommand, useForm];
});
_c = CustomersPage;
export function CustomerPage() {
  _s3();
  const { t, schema } = useCustomerCopy();
  const { customerId = "" } = useParams();
  const { shop } = useScope();
  const listHref = useListReturn(`/s/${shop.id}/customers`);
  const canEdit = useCan("customers.write");
  const canReadOrders = useCan("orders.read");
  const canReadShipments = useCan("fulfillment.read");
  const customer = useApi("getCustomer", { path: { customerId } });
  const orders = useApi("listOrders", { query: { customerId, limit: 10 } }, canReadOrders);
  const shipments = useApi("listShipments", { query: { limit: 100 } }, canReadShipments && canReadOrders);
  const cases = useApi("listServiceCases", { query: { limit: 10 } });
  const customerCases = cases.data?.data.filter((item) => item.customerId === customerId) ?? [];
  const customerOrderIds = new Set((orders.data?.data ?? []).map((order) => order.id));
  const customerShipments = (shipments.data?.data ?? []).filter((shipment) => customerOrderIds.has(shipment.orderId));
  const update = useCommand("updateCustomer", ["getCustomer", "listCustomers"]);
  const form = useForm({ defaultValues: { displayName: "", phone: "", email: "", notes: "" }, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const editor = useVersionedDraft({
    identity: `${shop.id}:customer:${customerId}`,
    source: customer.data ? customerSnapshot(customer.data.data) : void 0,
    draft: form.getValues(),
    apply: (values, baseline) => {
      form.reset(baseline);
      for (const key of Object.keys(values)) form.setValue(key, values[key], { shouldDirty: true });
    },
    refresh: () => customer.refetch({ throwOnError: true })
  });
  const draftForm = useDraftForm(editor.dirty);
  const save = form.handleSubmit(async (values) => {
    const submitted = form.getValues();
    try {
      const prepared = editor.prepare();
      if (!prepared) return;
      const response = await update.execute({
        path: { customerId },
        version: prepared.version,
        body: customerPatch(Object.fromEntries(Object.keys(prepared.patch).map((key) => [key, values[key]])), customer.data?.data.redactedFields || [])
      });
      editor.committed(customerSnapshot(response.data), submitted);
    } catch (error) {
      editor.failed(error);
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: customer.data?.data.displayName || t("customers.detail.fallbackTitle"), subtitle: t("customers.detail.subtitle"), actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: listHref, children: t("customers.detail.listAction") }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 141,
      columnNumber: 151
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: customer, pendingProfile: "section", children: customer.data && /* @__PURE__ */ jsxDEV(SectionGrid, { shrinkChildren: true, columns: { xs: "1fr", lg: "1.2fr 1fr" }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: t("customers.detail.information"), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", ref: draftForm, "data-draft-clean": !editor.dirty ? "true" : void 0, onSubmit: save, children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: update.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 146,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { displayName: "Tên khách hàng", phone: "Điện thoại", email: "Email", notes: "Ghi chú" }, busy: update.pending }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 147,
          columnNumber: 25
        }, this),
        customer.data.data.redactedFields.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: t("customers.detail.redactedNotice") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 148,
          columnNumber: 74
        }, this),
        customerFormFields.map((field) => /* @__PURE__ */ jsxDEV(TextField, { label: t(field.labelKey), ...form.register(field.name), error: !!form.formState.errors[field.name], helperText: form.formState.errors[field.name]?.message, disabled: !canEdit || customer.data?.data.redactedFields.includes(field.name), multiline: field.multiline, minRows: field.multiline ? 3 : void 0 }, field.name, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 149,
          columnNumber: 60
        }, this)),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", type: "submit", variant: "contained", busy: update.pending, disabled: !editor.dirty, children: t("customers.form.saveAction") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 150,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 145,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 144,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(PageSections, { children: [
        /* @__PURE__ */ jsxDEV(AddressesPanel, { customer: customer.data.data }, customer.data.data.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 154,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: t("customers.detail.recentOrders"), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { children: canReadOrders ? /* @__PURE__ */ jsxDEV(QueryState, { query: orders, children: orders.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          orders.data.data.map((order) => /* @__PURE__ */ jsxDEV(DetailLine, { label: order.id, children: /* @__PURE__ */ jsxDEV(RouteLink, { to: "/s/" + shop.id + "/orders/" + order.id, children: [
            "Mã đơn: ",
            order.id,
            " · ",
            businessLabel(order.orderState)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 160,
            columnNumber: 118
          }, this) }, order.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 160,
            columnNumber: 74
          }, this)),
          orders.data.data.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: t("customers.detail.noOrders") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 161,
            columnNumber: 75
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: t("customers.detail.orderPreviewLimit") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 162,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV(RouteLink, { to: "/s/" + shop.id + "/orders", children: t("customers.detail.openOrders") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 163,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 159,
          columnNumber: 53
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 158,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: t("customers.detail.shipmentPermission") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 166,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 156,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 155,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: t("customers.detail.relatedShipments"), bodyMode: "inset", children: canReadOrders && canReadShipments ? /* @__PURE__ */ jsxDEV(QueryState, { query: shipments, children: shipments.data && /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.detail.relatedItemGap, children: [
          orders.isPending && !orders.data && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: t("customers.detail.ordersLoading") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 173,
            columnNumber: 74
          }, this),
          orders.isError && !orders.data && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: t("customers.detail.ordersUnavailable") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 174,
            columnNumber: 72
          }, this),
          orders.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            customerShipments.map((item) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.detail.relatedItemInset, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control }], children: [
              /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", justifyContent: "space-between", alignItems: "center", children: [
                /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: item.trackingCode || item.id }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                  lineNumber: 177,
                  columnNumber: 125
                }, this),
                /* @__PURE__ */ jsxDEV(Status, { value: item.state }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                  lineNumber: 177,
                  columnNumber: 231
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 177,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đơn hàng", children: /* @__PURE__ */ jsxDEV(RouteLink, { to: "/s/" + shop.id + "/orders/" + item.orderId, children: item.orderId }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 178,
                columnNumber: 74
              }, this) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 178,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phí dự kiến", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: item.shippingFeeQuote }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 179,
                columnNumber: 77
              }, this) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 179,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phí thực tế", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: item.shippingFeeActual }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 180,
                columnNumber: 77
              }, this) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 180,
                columnNumber: 45
              }, this),
              item.events.at(-1) && /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cập nhật gần nhất", children: [
                item.events.at(-1)?.type,
                " · ",
                dateTime(item.events.at(-1).occurredAt, shop.timezone)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
                lineNumber: 181,
                columnNumber: 68
              }, this)
            ] }, item.id, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
              lineNumber: 176,
              columnNumber: 74
            }, this)),
            customerShipments.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: t("customers.detail.noShipments") }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
              lineNumber: 183,
              columnNumber: 76
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: t("customers.detail.shipmentPreviewLimit") }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
              lineNumber: 184,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 175,
            columnNumber: 53
          }, this),
          /* @__PURE__ */ jsxDEV(RouteLink, { to: "/s/" + shop.id + "/shipments", children: t("customers.detail.openShipments") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 186,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 172,
          columnNumber: 52
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 171,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: t("customers.detail.shipmentPermission") }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 189,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 169,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: t("customers.detail.supportCases"), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: cases, children: cases.data && /* @__PURE__ */ jsxDEV(Stack, { children: [
          customerCases.map((item) => /* @__PURE__ */ jsxDEV(DetailLine, { label: item.summary, children: /* @__PURE__ */ jsxDEV(Status, { value: item.state }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 194,
            columnNumber: 109
          }, this) }, item.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 194,
            columnNumber: 62
          }, this)),
          customerCases.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: t("customers.detail.noSupportCases") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 195,
            columnNumber: 64
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: layoutSx.detail.relatedContentGap, children: t("customers.detail.supportCasesLimit") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 196,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(RouteLink, { to: "/s/" + shop.id + "/service-cases", children: t("customers.detail.openSupportCases") }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 197,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 193,
          columnNumber: 44
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 192,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 191,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 153,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 143,
      columnNumber: 31
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 142,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
    lineNumber: 140,
    columnNumber: 10
  }, this);
}
_s3(CustomerPage, "VUJlnuTY+OK9/AhHrc8pUEu8Cvk=", false, function() {
  return [useCustomerCopy, useParams, useScope, useListReturn, useCan, useCan, useCan, useApi, useApi, useApi, useApi, useCommand, useForm, useWatch, useVersionedDraft, useDraftForm];
});
_c2 = CustomerPage;
export function ServiceCasesPage() {
  _s4();
  const { shop } = useScope();
  const list = useApi("listServiceCases", { query: useListQuery("listServiceCases") });
  const customers = usePagedApi("listCustomers", { query: { limit: 20 } });
  const canReadOrders = useCan("orders.read");
  const create = useCommand("createServiceCase", ["listServiceCases"]);
  const change = useCommand("setServiceCaseStatus", ["listServiceCases"]);
  const [open, setOpen] = useState(false), [customerId, setCustomerId] = useState(""), [orderId, setOrderId] = useState(""), [kind, setKind] = useState("question"), [summary, setSummary] = useState("");
  const [selected, setSelected] = useState(null), [state, setState] = useState("assigned"), [reason, setReason] = useState("");
  const relatedOrders = usePagedApi("listOrders", { query: { customerId, limit: 50 } }, Boolean(customerId) && canReadOrders);
  const selectedOrderIsValid = !orderId || relatedOrders.data?.data.some((order) => order.id === orderId);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Chăm sóc sau bán", subtitle: "Nhận câu hỏi, khiếu nại và yêu cầu đổi trả; không tự hứa hoàn tiền.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", variant: "contained", onClick: () => setOpen(true), children: "Tạo yêu cầu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 219,
      columnNumber: 134
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 219,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listServiceCases" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 221,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu chăm sóc sau bán", rows: list.data.data, rowKey: (item) => item.id, columns: [
          { key: "summary", label: "Yêu cầu", render: (item) => /* @__PURE__ */ jsxDEV(Stack, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: item.summary }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
              lineNumber: 225,
              columnNumber: 72
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: item.id }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
              lineNumber: 225,
              columnNumber: 162
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 225,
            columnNumber: 65
          }, this) },
          { key: "customer", label: "Khách", render: (item) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/customers/${item.customerId}`, children: customers.data?.data.find((customer) => customer.id === item.customerId)?.displayName || item.customerId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 226,
            columnNumber: 64
          }, this) },
          { key: "order", label: "Đơn liên quan", render: (item) => item.orderId ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${item.orderId}`, children: item.orderId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 227,
            columnNumber: 84
          }, this) : "Chưa liên kết" },
          { key: "type", label: "Loại", render: (item) => /* @__PURE__ */ jsxDEV(Status, { value: item.kind }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 228,
            columnNumber: 59
          }, this) },
          { key: "state", label: "Trạng thái", render: (item) => /* @__PURE__ */ jsxDEV(Status, { value: item.state }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 229,
            columnNumber: 66
          }, this) },
          { key: "action", label: "", render: (item) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "customers.write", onClick: () => {
            setSelected(item);
            setState(item.state === "open" ? "assigned" : item.state);
            setReason("");
          }, children: "Xử lý" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 230,
            columnNumber: 57
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 224,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 232,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 223,
        columnNumber: 31
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 222,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 220,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Yêu cầu mới", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !customerId || codePointLength(summary.trim()) < 5 || !selectedOrderIsValid || create.pending, onClick: async () => {
      try {
        await create.execute({ body: { customerId, orderId: orderId || null, kind, summary: summary.trim() } });
        setOpen(false);
        setCustomerId("");
        setOrderId("");
        setSummary("");
      } catch {
      }
    }, children: "Tạo yêu cầu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 236,
      columnNumber: 115
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || customers.error || relatedOrders.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 246,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khách hàng", value: customerId, onChange: (event) => {
          setCustomerId(event.target.value);
          setOrderId("");
        }, children: customers.data?.data.map((customer) => /* @__PURE__ */ jsxDEV(MenuItem, { value: customer.id, children: customer.displayName }, customer.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 249,
          columnNumber: 61
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 248,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "khách hàng", loadedCount: customers.loadedCount, hasMore: customers.hasMore, busy: customers.isLoadingMore, onLoadMore: customers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 251,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Đơn hàng liên quan (không bắt buộc)", value: orderId, disabled: !customerId || !canReadOrders || relatedOrders.isPending, onChange: (event) => setOrderId(event.target.value), helperText: !canReadOrders ? "Vai trò này không có quyền xem đơn; có thể tạo yêu cầu không gắn đơn." : !customerId ? "Chọn khách hàng trước để lọc đúng đơn của họ." : relatedOrders.isPending ? "Đang tải đơn của khách đã chọn…" : relatedOrders.data?.data.length ? "Chỉ hiển thị đơn thuộc khách hàng đã chọn." : "Không có đơn phù hợp; có thể tạo yêu cầu không gắn đơn.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Không liên kết đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 253,
            columnNumber: 21
          }, this),
          relatedOrders.data?.data.map((order) => /* @__PURE__ */ jsxDEV(MenuItem, { value: order.id, children: [
            order.id,
            " · ",
            businessLabel(order.orderState)
          ] }, order.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 254,
            columnNumber: 62
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 252,
          columnNumber: 17
        }, this),
        customerId && canReadOrders && /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "đơn hàng của khách", loadedCount: relatedOrders.loadedCount, hasMore: relatedOrders.hasMore, busy: relatedOrders.isLoadingMore, onLoadMore: relatedOrders.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 256,
          columnNumber: 49
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Loại yêu cầu", value: kind, onChange: (event) => setKind(event.target.value), children: ["question", "complaint", "return_request", "delivery_issue"].map((value, index) => /* @__PURE__ */ jsxDEV(MenuItem, { value, children: ["Câu hỏi", "Khiếu nại", "Yêu cầu trả hàng", "Vấn đề giao hàng"][index] }, value, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 257,
          columnNumber: 219
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 257,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Nội dung", multiline: true, minRows: 3, value: summary, onChange: (event) => setSummary(limitCodePoints(event.target.value, 1e3)), helperText: `${codePointLength(summary)}/1000` }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 258,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Yêu cầu chỉ được liên kết với đơn đã tải từ hồ sơ khách đang chọn. Việc tạo case không xác nhận đổi trả hoặc hoàn tiền." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 259,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 247,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 236,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!selected, title: "Cập nhật yêu cầu", onClose: () => setSelected(null), busy: change.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !reason.trim() || change.pending, onClick: async () => {
      if (!selected) return;
      try {
        await change.execute({ path: { resourceId: selected.id }, body: { expectedVersion: selected.version, state, reason } });
        setSelected(null);
      } catch {
      }
    }, children: "Cập nhật" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 262,
      columnNumber: 129
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: change.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 270,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { children: selected?.summary }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 272,
          columnNumber: 17
        }, this),
        selected?.orderId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${selected.orderId}`, children: [
          "Mở đơn ",
          selected.orderId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 273,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Trạng thái mới", value: state, onChange: (event) => setState(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "assigned", children: "Đã phân công" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 274,
            columnNumber: 139
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "resolved", children: "Đã giải quyết" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 274,
            columnNumber: 189
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "closed", children: "Đóng yêu cầu" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
            lineNumber: 274,
            columnNumber: 240
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 274,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Kết quả / lý do", multiline: true, minRows: 3, value: reason, onChange: (event) => setReason(limitCodePoints(event.target.value, 1e3)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 275,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Cập nhật case không tạo giao dịch hoàn tiền. Nếu cần đổi/trả, xử lý qua quy trình đơn hàng được cấp quyền." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
          lineNumber: 276,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
        lineNumber: 271,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
      lineNumber: 262,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx",
    lineNumber: 218,
    columnNumber: 10
  }, this);
}
_s4(ServiceCasesPage, "etAOJ2ERL/W044oCnalByJhIJ0U=", false, function() {
  return [useScope, useApi, useListQuery, usePagedApi, useCan, useCommand, useCommand, usePagedApi];
});
_c3 = ServiceCasesPage;
function customerSnapshot(customer) {
  return { version: customer.version, values: { displayName: customer.displayName, phone: customer.phone || "", email: customer.email || "", notes: customer.notes || "" }, hidden: customer.redactedFields.filter((key) => ["displayName", "phone", "email", "notes"].includes(key)) };
}
function customerPatch(values, redacted) {
  const patch = {};
  if (values.displayName !== void 0 && !redacted.includes("displayName"))
    patch.displayName = values.displayName;
  if (values.phone !== void 0 && !redacted.includes("phone"))
    patch.phone = values.phone || null;
  if (values.email !== void 0 && !redacted.includes("email"))
    patch.email = values.email || null;
  if (values.notes !== void 0 && !redacted.includes("notes"))
    patch.notes = values.notes;
  return patch;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "CustomersPage");
$RefreshReg$(_c2, "CustomerPage");
$RefreshReg$(_c3, "ServiceCasesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/customers/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkU0RyxTQUFzVSxVQUF0VTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzRTVHLFNBQVFBLFNBQVNDLHFCQUFvQjtBQUNyQyxTQUFRQyxxQkFBb0I7QUFDNUIsU0FBU0MsZ0JBQWdCQyxvQkFBb0I7QUFDN0MsU0FBU0MsYUFBYUMsWUFBWUMsY0FBY0MsbUJBQW1CO0FBQ25FLFNBQVNDLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUMxQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLFNBQVM7QUFDbEIsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBRTNFLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsUUFBUUMsWUFBWUMsbUJBQW1CO0FBQ2hELFNBQVNDLFVBQVVDLGNBQWM7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQkMsaUJBQWlCQyxnQkFBZ0I7QUFDM0QsU0FBU0MsUUFBUUMsWUFBWUMsT0FBT0MsV0FBV0MsWUFBWUMsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxZQUFZQyxhQUFhQyxXQUFXQyxZQUFZQyxzQkFBc0I7QUFDekssU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQUMvQixNQUFNQyxxQkFBcUI7QUFBQSxFQUN2QixFQUFFQyxNQUFNLGVBQWVDLFVBQVUsK0JBQStCQyxXQUFXLE1BQU07QUFBQSxFQUNqRixFQUFFRixNQUFNLFNBQVNDLFVBQVUsd0JBQXdCQyxXQUFXLE1BQU07QUFBQSxFQUNwRSxFQUFFRixNQUFNLFNBQVNDLFVBQVUsd0JBQXdCQyxXQUFXLE1BQU07QUFBQSxFQUNwRSxFQUFFRixNQUFNLFNBQVNDLFVBQVUsd0JBQXdCQyxXQUFXLEtBQUs7QUFBQztBQUV4RSxTQUFTQyxxQkFBcUJDLE1BTTNCO0FBQ0MsU0FBT3hDLEVBQUV5QyxPQUFPO0FBQUEsSUFDWkMsYUFBYTFDLEVBQUUyQyxPQUFPLEVBQUVDLEtBQUssRUFBRUMsSUFBSSxHQUFHTCxLQUFLTSxZQUFZLEVBQUVDLE9BQU8sQ0FBQUMsVUFBUy9CLGdCQUFnQitCLEtBQUssS0FBSyxLQUFLUixLQUFLUyxPQUFPO0FBQUEsSUFDcEhDLE9BQU9sRCxFQUFFMkMsT0FBTyxFQUFFSSxPQUFPLENBQUFDLFVBQVMvQixnQkFBZ0IrQixLQUFLLEtBQUssSUFBSVIsS0FBS1csUUFBUTtBQUFBLElBQzdFQyxPQUFPcEQsRUFBRTJDLE9BQU8sRUFBRVMsTUFBTVosS0FBS2EsV0FBVyxFQUFFQyxHQUFHdEQsRUFBRXVELFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDMURDLE9BQU94RCxFQUFFMkMsT0FBTyxFQUFFSSxPQUFPLENBQUFDLFVBQVMvQixnQkFBZ0IrQixLQUFLLEtBQUssS0FBTVIsS0FBS2lCLFFBQVE7QUFBQSxFQUNuRixDQUFDO0FBQ0w7QUFFQSxTQUFTQyxrQkFBa0I7QUFBQUMsS0FBQTtBQUN2QixRQUFNLEVBQUVDLEVBQUUsSUFBSTdELGVBQWU7QUFDN0IsUUFBTThELFNBQVN2RSxRQUFRLE1BQU1pRCxxQkFBcUI7QUFBQSxJQUM5Q08sY0FBY2MsRUFBRSxtQ0FBbUM7QUFBQSxJQUNuRFgsU0FBU1csRUFBRSw4QkFBOEI7QUFBQSxJQUN6Q1QsVUFBVVMsRUFBRSwrQkFBK0I7QUFBQSxJQUMzQ1AsYUFBYU8sRUFBRSxrQ0FBa0M7QUFBQSxJQUNqREgsVUFBVUcsRUFBRSwrQkFBK0I7QUFBQSxFQUMvQyxDQUFDLEdBQUcsQ0FBQ0EsQ0FBQyxDQUFDO0FBQ1AsU0FBTyxFQUFFQSxHQUFHQyxPQUFPO0FBQ3ZCO0FBQUNGLEdBVlFELGlCQUFlO0FBQUEsVUFDTjNELGNBQWM7QUFBQTtBQVV6QixnQkFBUytELGdCQUFnQjtBQUFBQyxNQUFBO0FBQzVCLFFBQU0sRUFBRUgsR0FBR0MsT0FBTyxJQUFJSCxnQkFBZ0I7QUFDdEMsUUFBTSxFQUFFTSxLQUFLLElBQUluRCxTQUFTO0FBQzFCLFFBQU1vRCxXQUFXdkUsWUFBWTtBQUM3QixRQUFNd0UsT0FBT3hELE9BQU8saUJBQWlCLEVBQUV5RCxPQUFPcEQsYUFBYSxlQUFlLEVBQUUsQ0FBQztBQUM3RSxRQUFNcUQsU0FBU3pELFdBQVcsa0JBQWtCLENBQUMsZUFBZSxDQUFDO0FBQzdELFFBQU0sQ0FBQzBELE1BQU1DLE9BQU8sSUFBSTlFLFNBQVMsS0FBSztBQUN0QyxRQUFNK0UsT0FBTzNFLFFBQXdCLEVBQUU0RSxlQUFlLEVBQUU5QixhQUFhLElBQUlRLE9BQU8sSUFBSUUsT0FBTyxJQUFJSSxPQUFPLEdBQUcsR0FBR2lCLFVBQVUzRSxZQUFZK0QsTUFBTSxFQUFFLENBQUM7QUFDM0ksUUFBTWEsYUFBYW5GLE9BQXdCLElBQUk7QUFDL0MsUUFBTW9GLFNBQVNKLEtBQUtLLGFBQWEsT0FBT0MsV0FBVztBQUFFLFFBQUk7QUFDckQsWUFBTUMsV0FBVyxNQUFNVixPQUFPVyxRQUFRLEVBQUVDLE1BQU0sRUFBRSxHQUFHSCxRQUFRM0IsT0FBTzJCLE9BQU8zQixTQUFTLE1BQU1FLE9BQU95QixPQUFPekIsU0FBUyxLQUFLLEVBQUUsQ0FBQztBQUN2SCxVQUFJc0IsV0FBV08sU0FBUztBQUNwQmpHLHVCQUFlMEYsV0FBV08sT0FBTztBQUNqQyxjQUFNQyxTQUFTUixXQUFXTyxRQUFRRSxRQUFxQixpQkFBaUI7QUFDeEUsWUFBSUQsUUFBUTtBQUFFQSxpQkFBT0UsUUFBUUMsYUFBYTtBQUFRLGlCQUFPSCxPQUFPRSxRQUFRRTtBQUFBQSxRQUFZO0FBQUEsTUFDeEY7QUFDQWhCLGNBQVEsS0FBSztBQUNiQyxXQUFLZ0IsTUFBTTtBQUNYdEIsZUFBUyxNQUFNRCxLQUFLd0IsRUFBRSxjQUFjVixTQUFTVyxLQUFLRCxFQUFFLEVBQUU7QUFBQSxJQUMxRCxRQUNNO0FBQUEsSUFBRTtBQUFBLEVBQThCLENBQUM7QUFDdkMsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTzVCLEVBQUUsc0JBQXNCLEdBQUcsVUFBVUEsRUFBRSx5QkFBeUIsR0FBRyxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsbUJBQWtCLFNBQVEsYUFBWSxTQUFTLE1BQU1VLFFBQVEsSUFBSSxHQUFJVixZQUFFLDBCQUEwQixLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThILEtBQTdOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK087QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsaUJBQWdCLGFBQWFBLEVBQUUsa0NBQWtDLEdBQUcsYUFBWSxZQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJHO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU9NLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS3VCLFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU83QixFQUFFLDJCQUEyQixHQUFHLE9BQU9BLEVBQUUsc0JBQXNCLEdBQUcsTUFBTU0sS0FBS3VCLEtBQUtBLE1BQU0sUUFBUSxDQUFBQyxNQUFLQSxFQUFFRixJQUFJLFNBQVM7QUFBQSxVQUNsakIsRUFBRUcsS0FBSyxRQUFROUcsT0FBTytFLEVBQUUsK0JBQStCLEdBQUdnQyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLGNBQVcsWUFBWWpHLFNBQVNvRyxXQUFXQyxXQUFXQyxRQUFTTCxZQUFFaEQsZUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEUsRUFBYztBQUFBLFVBQUcsRUFBRWlELEtBQUssU0FBUzlHLE9BQU8rRSxFQUFFLDhCQUE4QixHQUFHZ0MsUUFBUUEsQ0FBQUYsTUFBS0EsRUFBRXhDLFNBQVNVLEVBQUUsbUNBQW1DLEVBQUU7QUFBQSxVQUFHLEVBQUUrQixLQUFLLFNBQVM5RyxPQUFPK0UsRUFBRSw0QkFBNEIsR0FBR2dDLFFBQVFBLENBQUFGLE1BQUtBLEVBQUV0QyxTQUFTLElBQUk7QUFBQSxVQUFHLEVBQUV1QyxLQUFLLFFBQVE5RyxPQUFPK0UsRUFBRSw0QkFBNEIsR0FBR2dDLFFBQVFBLENBQUFGLE1BQUtBLEVBQUVsQyxTQUFTLElBQUk7QUFBQSxVQUFHLEVBQUVtQyxLQUFLLFVBQVU5RyxPQUFPLElBQUkrRyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLGFBQVUsSUFBSSxNQUFNMUIsS0FBS3dCLEVBQUUsY0FBY0UsRUFBRUYsRUFBRSxJQUFLNUIsWUFBRSw4QkFBOEIsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUYsRUFBYTtBQUFBLFFBQUMsS0FEL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUU5YTtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNTSxLQUFLdUIsS0FBS08sUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBRjhZO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFNVksS0FGNFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUV4VTtBQUFBLFNBRm9OO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFdk07QUFBQSxJQUFRLHVCQUFDLGNBQVcsTUFBWSxPQUFPcEMsRUFBRSw0QkFBNEIsR0FBRyxTQUFTLE1BQU1VLFFBQVEsS0FBSyxHQUFHLE1BQU1GLE9BQU82QixTQUFTLFNBQVMsdUJBQUMsVUFBTyxNQUFLLFVBQVMsTUFBSyx3QkFBdUIsU0FBUSxhQUFZLFVBQVU3QixPQUFPNkIsU0FBVXJDLFlBQUUsNkJBQTZCLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0ksR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT1EsT0FBTzhCLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUFFLHVCQUFDLGNBQVcsV0FBVSxRQUFPLEtBQUt4QixZQUFZLElBQUcsd0JBQXVCLFVBQVVDLFFBQVEsWUFBVSxNQUFHeEMsNkJBQW1CZ0UsSUFBSSxDQUFBQyxVQUFTLHVCQUFDLGFBQTJCLE9BQU94QyxFQUFFd0MsTUFBTS9ELFFBQVEsR0FBRyxVQUFVK0IsT0FBTzZCLFNBQVMsR0FBSTFCLEtBQUs4QixTQUFTRCxNQUFNaEUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDbUMsS0FBSytCLFVBQVVDLE9BQU9ILE1BQU1oRSxJQUFJLEdBQUcsWUFBWW1DLEtBQUsrQixVQUFVQyxPQUFPSCxNQUFNaEUsSUFBSSxHQUFHb0UsU0FBUyxXQUFXSixNQUFNOUQsYUFBcE44RCxNQUFNaEUsTUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4TyxDQUFFLEtBQXZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeVg7QUFBQSxTQUF2cUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvckI7QUFBQSxPQUZ4dUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVxdkI7QUFDaHdCO0FBQUMyQixJQXhCZUQsZUFBYTtBQUFBLFVBQ0hKLGlCQUNMN0MsVUFDQW5CLGFBQ0pnQixRQUFpQ0ssY0FDL0JKLFlBRUZmLE9BQU87QUFBQTtBQUFBLEtBUFJrRTtBQXlCVCxnQkFBUzJDLGVBQWU7QUFBQUMsTUFBQTtBQUMzQixRQUFNLEVBQUU5QyxHQUFHQyxPQUFPLElBQUlILGdCQUFnQjtBQUN0QyxRQUFNLEVBQUVpRCxhQUFhLEdBQUcsSUFBSWhILFVBQVU7QUFDdEMsUUFBTSxFQUFFcUUsS0FBSyxJQUFJbkQsU0FBUztBQUMxQixRQUFNK0YsV0FBUzdILGNBQWMsTUFBTWlGLEtBQUt3QixFQUFFLFlBQVk7QUFDdEQsUUFBTXFCLFVBQVUvRixPQUFPLGlCQUFpQjtBQUN4QyxRQUFNZ0csZ0JBQWdCaEcsT0FBTyxhQUFhO0FBQzFDLFFBQU1pRyxtQkFBbUJqRyxPQUFPLGtCQUFrQjtBQUNsRCxRQUFNa0csV0FBV3RHLE9BQU8sZUFBZSxFQUFFdUcsTUFBTSxFQUFFTixXQUFXLEVBQUUsQ0FBQztBQUMvRCxRQUFNTyxTQUFTeEcsT0FBTyxjQUFjLEVBQUV5RCxPQUFPLEVBQUV3QyxZQUFZUSxPQUFPLEdBQUcsRUFBRSxHQUFHTCxhQUFhO0FBQ3ZGLFFBQU1NLFlBQVkxRyxPQUFPLGlCQUFpQixFQUFFeUQsT0FBTyxFQUFFZ0QsT0FBTyxJQUFJLEVBQUUsR0FBR0osb0JBQW9CRCxhQUFhO0FBQ3RHLFFBQU1PLFFBQVEzRyxPQUFPLG9CQUFvQixFQUFFeUQsT0FBTyxFQUFFZ0QsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUNqRSxRQUFNRyxnQkFBZ0JELE1BQU01QixNQUFNQSxLQUFLOEIsT0FBTyxDQUFBQyxTQUFRQSxLQUFLYixlQUFlQSxVQUFVLEtBQUs7QUFDekYsUUFBTWMsbUJBQW1CLElBQUlDLEtBQUtSLE9BQU96QixNQUFNQSxRQUFRLElBQUlVLElBQUksQ0FBQXdCLFVBQVNBLE1BQU1uQyxFQUFFLENBQUM7QUFDakYsUUFBTW9DLHFCQUFxQlIsVUFBVTNCLE1BQU1BLFFBQVEsSUFBSThCLE9BQU8sQ0FBQU0sYUFBWUosaUJBQWlCSyxJQUFJRCxTQUFTRSxPQUFPLENBQUM7QUFDaEgsUUFBTUMsU0FBU3JILFdBQVcsa0JBQWtCLENBQUMsZUFBZSxlQUFlLENBQUM7QUFDNUUsUUFBTTRELE9BQU8zRSxRQUF3QixFQUFFNEUsZUFBZSxFQUFFOUIsYUFBYSxJQUFJUSxPQUFPLElBQUlFLE9BQU8sSUFBSUksT0FBTyxHQUFHLEdBQUdpQixVQUFVM0UsWUFBWStELE1BQU0sRUFBRSxDQUFDO0FBQzNJaEUsV0FBUyxFQUFFb0ksU0FBUzFELEtBQUswRCxRQUFRLENBQUM7QUFDbEMsUUFBTUMsU0FBUzFILGtCQUFrQjtBQUFBLElBQzdCMkgsVUFBVSxHQUFHbkUsS0FBS3dCLEVBQUUsYUFBYW1CLFVBQVU7QUFBQSxJQUMzQ3lCLFFBQVFwQixTQUFTdkIsT0FBTzRDLGlCQUFpQnJCLFNBQVN2QixLQUFLQSxJQUFJLElBQUk2QztBQUFBQSxJQUMvREMsT0FBT2hFLEtBQUtpRSxVQUFVO0FBQUEsSUFDdEJDLE9BQU9BLENBQUNDLFFBQVFDLGFBQWE7QUFDekJwRSxXQUFLZ0IsTUFBTW9ELFFBQVE7QUFDbkIsaUJBQVdoRCxPQUFPaUQsT0FBT0MsS0FBS0gsTUFBTSxFQUErQm5FLE1BQUt1RSxTQUFTbkQsS0FBSytDLE9BQU8vQyxHQUFHLEdBQUcsRUFBRW9ELGFBQWEsS0FBSyxDQUFDO0FBQUEsSUFDNUg7QUFBQSxJQUNBQyxTQUFTQSxNQUFNaEMsU0FBU2lDLFFBQVEsRUFBRUMsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUMxRCxDQUFDO0FBQ0QsUUFBTUMsWUFBWWxLLGFBQWFpSixPQUFPa0IsS0FBSztBQUMzQyxRQUFNQyxPQUFPOUUsS0FBS0ssYUFBYSxPQUFPOEQsV0FBVztBQUM3QyxVQUFNWSxZQUFZL0UsS0FBS2lFLFVBQVU7QUFDakMsUUFBSTtBQUNBLFlBQU1lLFdBQVdyQixPQUFPc0IsUUFBUTtBQUNoQyxVQUFJLENBQUNELFNBQVU7QUFDZixZQUFNekUsV0FBVyxNQUFNa0QsT0FBT2pELFFBQVE7QUFBQSxRQUNsQ2tDLE1BQU0sRUFBRU4sV0FBVztBQUFBLFFBQUc4QyxTQUFTRixTQUFTRTtBQUFBQSxRQUFTekUsTUFBTTBFLGNBQWNkLE9BQU9lLFlBQVlmLE9BQU9DLEtBQUtVLFNBQVNLLEtBQUssRUFBRXpELElBQUksQ0FBQVIsUUFBTyxDQUFDQSxLQUFLK0MsT0FBTy9DLEdBQTJCLENBQUMsQ0FBQyxDQUFDLEdBQUdxQixTQUFTdkIsTUFBTUEsS0FBS29FLGtCQUFrQixFQUFFO0FBQUEsTUFDek4sQ0FBQztBQUNEM0IsYUFBTzRCLFVBQVV6QixpQkFBaUJ2RCxTQUFTVyxJQUFJLEdBQUc2RCxTQUFTO0FBQUEsSUFDL0QsU0FDT3BELE9BQU87QUFBRWdDLGFBQU82QixPQUFPN0QsS0FBSztBQUFBLElBQUc7QUFBQSxFQUMxQyxDQUFDO0FBQ0QsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBT2MsU0FBU3ZCLE1BQU1BLEtBQUsvQyxlQUFla0IsRUFBRSxnQ0FBZ0MsR0FBRyxVQUFVQSxFQUFFLDJCQUEyQixHQUFHLFNBQVMsdUJBQUMsYUFBVSxJQUFJZ0QsVUFBV2hELFlBQUUsNkJBQTZCLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQsS0FBek07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzTjtBQUFBLElBQ3ROLHVCQUFDLGNBQVcsT0FBT29ELFVBQVUsZ0JBQWUsV0FDdkNBLG1CQUFTdkIsUUFBUSx1QkFBQyxlQUFZLGdCQUFjLE1BQUMsU0FBUyxFQUFFdUUsSUFBSSxPQUFPQyxJQUFJLFlBQVksR0FDaEY7QUFBQSw2QkFBQyxTQUFNLE9BQU9yRyxFQUFFLDhCQUE4QixHQUFHLFVBQVMsU0FDdEQsaUNBQUMsY0FBVyxXQUFVLFFBQU8sS0FBS3VGLFdBQVcsb0JBQWtCLENBQUNqQixPQUFPa0IsUUFBUSxTQUFTZCxRQUFXLFVBQVVlLE1BQ3pHO0FBQUEsK0JBQUMsZUFBWSxPQUFPckIsT0FBTzlCLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUNqQyx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUV4RCxhQUFhLGtCQUFrQlEsT0FBTyxjQUFjRSxPQUFPLFNBQVNJLE9BQU8sVUFBVSxHQUFHLE1BQU13RSxPQUFPL0IsV0FBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSjtBQUFBLFFBQ3JKZSxTQUFTdkIsS0FBS0EsS0FBS29FLGVBQWVLLFNBQVMsS0FBSyx1QkFBQyxTQUFNLFVBQVMsUUFBUXRHLFlBQUUsaUNBQWlDLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxRQUM3R3pCLG1CQUFtQmdFLElBQUksQ0FBQUMsVUFBUyx1QkFBQyxhQUEyQixPQUFPeEMsRUFBRXdDLE1BQU0vRCxRQUFRLEdBQUcsR0FBSWtDLEtBQUs4QixTQUFTRCxNQUFNaEUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDbUMsS0FBSytCLFVBQVVDLE9BQU9ILE1BQU1oRSxJQUFJLEdBQUcsWUFBWW1DLEtBQUsrQixVQUFVQyxPQUFPSCxNQUFNaEUsSUFBSSxHQUFHb0UsU0FBUyxVQUFVLENBQUNLLFdBQVdHLFNBQVN2QixNQUFNQSxLQUFLb0UsZUFBZU0sU0FBUy9ELE1BQU1oRSxJQUFJLEdBQUcsV0FBV2dFLE1BQU05RCxXQUFXLFNBQVM4RCxNQUFNOUQsWUFBWSxJQUFJZ0csVUFBblRsQyxNQUFNaEUsTUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2VSxDQUFFO0FBQUEsUUFDaFgsdUJBQUMsa0JBQWUsWUFBVyxtQkFBa0IsTUFBSyxVQUFTLFNBQVEsYUFBWSxNQUFNNEYsT0FBTy9CLFNBQVMsVUFBVSxDQUFDaUMsT0FBT2tCLE9BQVF4RixZQUFFLDJCQUEyQixLQUE1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThKO0FBQUEsV0FMbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxnQkFDRztBQUFBLCtCQUFDLGtCQUEyQyxVQUFVb0QsU0FBU3ZCLEtBQUtBLFFBQS9DdUIsU0FBU3ZCLEtBQUtBLEtBQUtELElBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RSx1QkFBQyxTQUFNLE9BQU81QixFQUFFLCtCQUErQixHQUFHLFVBQVMsU0FDdkQsaUNBQUMsU0FDSWtELDBCQUNLLHVCQUFDLGNBQVcsT0FBT0ksUUFDaEJBLGlCQUFPekIsUUFBUSxtQ0FDWHlCO0FBQUFBLGlCQUFPekIsS0FBS0EsS0FBS1UsSUFBSSxDQUFBd0IsVUFBUyx1QkFBQyxjQUEwQixPQUFPQSxNQUFNbkMsSUFBSSxpQ0FBQyxhQUFVLElBQUksUUFBUXhCLEtBQUt3QixLQUFLLGFBQWFtQyxNQUFNbkMsSUFBSTtBQUFBO0FBQUEsWUFBU21DLE1BQU1uQztBQUFBQSxZQUFHO0FBQUEsWUFBSTFHLGNBQWM2SSxNQUFNeUMsVUFBVTtBQUFBLGVBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThHLEtBQXpJekMsTUFBTW5DLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNLLENBQWE7QUFBQSxVQUNqTjBCLE9BQU96QixLQUFLQSxLQUFLeUUsV0FBVyxLQUFLLHVCQUFDLGNBQVcsT0FBTSxrQkFBa0J0RyxZQUFFLDJCQUEyQixLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLFVBQ3JHLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWtCQSxZQUFFLG9DQUFvQyxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLFVBQzlGLHVCQUFDLGFBQVUsSUFBSSxRQUFRSSxLQUFLd0IsS0FBSyxXQUFZNUIsWUFBRSw2QkFBNkIsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxhQUpsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2hCLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9GLElBQ0UsdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFVQSxZQUFFLHFDQUFxQyxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFLEtBVnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQSxLQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxPQUFPQSxFQUFFLG1DQUFtQyxHQUFHLFVBQVMsU0FDMURrRCwyQkFBaUJDLG1CQUNaLHVCQUFDLGNBQVcsT0FBT0ssV0FDaEJBLG9CQUFVM0IsUUFBUSx1QkFBQyxTQUFNLElBQUl4RCxTQUFTb0ksT0FBT0MsZ0JBQ3pDcEQ7QUFBQUEsaUJBQU9xRCxhQUFhLENBQUNyRCxPQUFPekIsUUFBUSx1QkFBQyxjQUFXLE1BQUssVUFBVTdCLFlBQUUsZ0NBQWdDLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDbkdzRCxPQUFPc0QsV0FBVyxDQUFDdEQsT0FBT3pCLFFBQVEsdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFVN0IsWUFBRSxvQ0FBb0MsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUNoSHNELE9BQU96QixRQUFRLG1DQUNYbUM7QUFBQUEsOEJBQWtCekIsSUFBSSxDQUFBcUIsU0FBUSx1QkFBQyxPQUFrQixJQUFJLENBQUN2RixTQUFTb0ksT0FBT0ksa0JBQWtCLEVBQUVDLFFBQVEsR0FBR0MsYUFBYSxXQUFXQyxjQUFjbkwsU0FBU29MLE9BQU81QyxRQUFRLENBQUMsR0FDaks7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsT0FBTSxnQkFBZSxpQkFBZ0IsWUFBVyxVQUFVO0FBQUEsdUNBQUMsY0FBVyxZQUFZeEksU0FBU29HLFdBQVdDLFdBQVdDLFFBQVN5QixlQUFLc0QsZ0JBQWdCdEQsS0FBS2hDLE1BQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsZ0JBQWEsdUJBQUMsVUFBTyxPQUFPZ0MsS0FBS3VELFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUEsbUJBQXJOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVOO0FBQUEsY0FDdk4sdUJBQUMsY0FBVyxPQUFNLFlBQVcsaUNBQUMsYUFBVSxJQUFJLFFBQVEvRyxLQUFLd0IsS0FBSyxhQUFhZ0MsS0FBS08sU0FBVVAsZUFBS08sV0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEUsS0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUg7QUFBQSxjQUNuSCx1QkFBQyxjQUFXLE9BQU0sZUFBYyxpQ0FBQyxVQUFPLE1BQUksTUFBQyxPQUFPUCxLQUFLd0Qsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsY0FDNUUsdUJBQUMsY0FBVyxPQUFNLGVBQWMsaUNBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT3hELEtBQUt5RCxxQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkMsS0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkU7QUFBQSxjQUM1RXpELEtBQUswRCxPQUFPQyxHQUFHLEVBQUUsS0FBSyx1QkFBQyxjQUFXLE9BQU0scUJBQXFCM0Q7QUFBQUEscUJBQUswRCxPQUFPQyxHQUFHLEVBQUUsR0FBR0M7QUFBQUEsZ0JBQUs7QUFBQSxnQkFBSWxLLFNBQVNzRyxLQUFLMEQsT0FBT0MsR0FBRyxFQUFFLEVBQUdFLFlBQVlySCxLQUFLc0gsUUFBUTtBQUFBLG1CQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0SDtBQUFBLGlCQUw5RzlELEtBQUtoQyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTS9CLENBQU07QUFBQSxZQUNMb0Msa0JBQWtCc0MsV0FBVyxLQUFLLHVCQUFDLGNBQVcsT0FBTSxrQkFBa0J0RyxZQUFFLDhCQUE4QixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3pHLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWtCQSxZQUFFLHVDQUF1QyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLGVBVHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVWhCO0FBQUEsVUFDQSx1QkFBQyxhQUFVLElBQUksUUFBUUksS0FBS3dCLEtBQUssY0FBZTVCLFlBQUUsZ0NBQWdDLEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsYUFkckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVuQixLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJGLElBQ0UsdUJBQUMsU0FBTSxVQUFTLFFBQVFBLFlBQUUscUNBQXFDLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUUsS0FwQjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sT0FBT0EsRUFBRSwrQkFBK0IsR0FBRyxVQUFTLFNBQ3ZELGlDQUFDLGNBQVcsT0FBT3lELE9BQ2RBLGdCQUFNNUIsUUFBUSx1QkFBQyxTQUNYNkI7QUFBQUEsd0JBQWNuQixJQUFJLENBQUFxQixTQUFRLHVCQUFDLGNBQXlCLE9BQU9BLEtBQUsrRCxTQUFTLGlDQUFDLFVBQU8sT0FBTy9ELEtBQUt1RCxTQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQixLQUF4RHZELEtBQUtoQyxJQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRSxDQUFhO0FBQUEsVUFDbEg4QixjQUFjNEMsV0FBVyxLQUFLLHVCQUFDLGNBQVcsT0FBTSxrQkFBa0J0RyxZQUFFLGlDQUFpQyxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3hHLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCLElBQUkzQixTQUFTb0ksT0FBT21CLG1CQUFvQjVILFlBQUUsb0NBQW9DLEtBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFJO0FBQUEsVUFDckksdUJBQUMsYUFBVSxJQUFJLFFBQVFJLEtBQUt3QixLQUFLLGtCQUFtQjVCLFlBQUUsbUNBQW1DLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsYUFKaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtmLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0EvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdEQTtBQUFBLFNBMURjO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyRGxCLEtBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2REE7QUFBQSxPQS9ERztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0VQO0FBQ0o7QUFBQzhDLElBMUdlRCxjQUFZO0FBQUEsVUFDRi9DLGlCQUNNL0QsV0FDWGtCLFVBQ0Y5QixlQUNDK0IsUUFDTUEsUUFDR0EsUUFDUkosUUFDRkEsUUFDR0EsUUFDSkEsUUFJQ0MsWUFDRmYsU0FDYkMsVUFDZVcsbUJBVUd2QixZQUFZO0FBQUE7QUFBQSxNQTVCbEJ3SDtBQTJHVCxnQkFBU2dGLG1CQUFtQjtBQUFBQyxNQUFBO0FBQy9CLFFBQU0sRUFBRTFILEtBQUssSUFBSW5ELFNBQVM7QUFDMUIsUUFBTXFELE9BQU94RCxPQUFPLG9CQUFvQixFQUFFeUQsT0FBT3BELGFBQWEsa0JBQWtCLEVBQUUsQ0FBQztBQUNuRixRQUFNNEssWUFBWS9LLFlBQVksaUJBQWlCLEVBQUV1RCxPQUFPLEVBQUVnRCxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFLFFBQU1MLGdCQUFnQmhHLE9BQU8sYUFBYTtBQUMxQyxRQUFNc0QsU0FBU3pELFdBQVcscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDbkUsUUFBTWlMLFNBQVNqTCxXQUFXLHdCQUF3QixDQUFDLGtCQUFrQixDQUFDO0FBQ3RFLFFBQU0sQ0FBQzBELE1BQU1DLE9BQU8sSUFBSTlFLFNBQVMsS0FBSyxHQUFHLENBQUNtSCxZQUFZa0YsYUFBYSxJQUFJck0sU0FBUyxFQUFFLEdBQUcsQ0FBQ3VJLFNBQVMrRCxVQUFVLElBQUl0TSxTQUFTLEVBQUUsR0FBRyxDQUFDdU0sTUFBTUMsT0FBTyxJQUFJeE0sU0FBeUUsVUFBVSxHQUFHLENBQUMrTCxTQUFTVSxVQUFVLElBQUl6TSxTQUFTLEVBQUU7QUFDdFEsUUFBTSxDQUFDME0sVUFBVUMsV0FBVyxJQUFJM00sU0FBNkIsSUFBSSxHQUFHLENBQUN1TCxPQUFPcUIsUUFBUSxJQUFJNU0sU0FBNkMsVUFBVSxHQUFHLENBQUM2TSxRQUFRQyxTQUFTLElBQUk5TSxTQUFTLEVBQUU7QUFDbkwsUUFBTStNLGdCQUFnQjNMLFlBQVksY0FBYyxFQUFFdUQsT0FBTyxFQUFFd0MsWUFBWVEsT0FBTyxHQUFHLEVBQUUsR0FBR3FGLFFBQVE3RixVQUFVLEtBQUtHLGFBQWE7QUFDMUgsUUFBTTJGLHVCQUF1QixDQUFDMUUsV0FBV3dFLGNBQWM5RyxNQUFNQSxLQUFLaUgsS0FBSyxDQUFBL0UsVUFBU0EsTUFBTW5DLE9BQU91QyxPQUFPO0FBRXBHLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0sb0JBQW1CLFVBQVMsdUVBQXNFLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxtQkFBa0IsU0FBUSxhQUFZLFNBQVMsTUFBTXpELFFBQVEsSUFBSSxHQUFHLDJCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBHLEtBQXZPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeVA7QUFBQSxJQUN6UCx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsV0FBUSxXQUFVLHNCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsTUFDckMsdUJBQUMsY0FBVyxPQUFPSixNQUFNLGdCQUFlLFdBQ25DQSxlQUFLdUIsUUFBUSxtQ0FDVjtBQUFBLCtCQUFDLGFBQVUsT0FBTSw0QkFBMkIsTUFBTXZCLEtBQUt1QixLQUFLQSxNQUFNLFFBQVEsQ0FBQStCLFNBQVFBLEtBQUtoQyxJQUFJLFNBQVM7QUFBQSxVQUNoRyxFQUFFRyxLQUFLLFdBQVc5RyxPQUFPLFdBQVcrRyxRQUFRQSxDQUFBNEIsU0FBUSx1QkFBQyxTQUFNO0FBQUEsbUNBQUMsY0FBVyxZQUFZL0gsU0FBU29HLFdBQVdDLFdBQVdDLFFBQVN5QixlQUFLK0QsV0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFXL0QsZUFBS2hDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsZUFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUosRUFBUztBQUFBLFVBQ2xOLEVBQUVHLEtBQUssWUFBWTlHLE9BQU8sU0FBUytHLFFBQVFBLENBQUE0QixTQUFRLHVCQUFDLGFBQVUsSUFBSSxNQUFNeEQsS0FBS3dCLEVBQUUsY0FBY2dDLEtBQUtiLFVBQVUsSUFBS2dGLG9CQUFVbEcsTUFBTUEsS0FBS2tILEtBQUssQ0FBQTNGLGFBQVlBLFNBQVN4QixPQUFPZ0MsS0FBS2IsVUFBVSxHQUFHakUsZUFBZThFLEtBQUtiLGNBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFLLEVBQWE7QUFBQSxVQUNyTyxFQUFFaEIsS0FBSyxTQUFTOUcsT0FBTyxpQkFBaUIrRyxRQUFRQSxDQUFBNEIsU0FBUUEsS0FBS08sVUFBVSx1QkFBQyxhQUFVLElBQUksTUFBTS9ELEtBQUt3QixFQUFFLFdBQVdnQyxLQUFLTyxPQUFPLElBQUtQLGVBQUtPLFdBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFLElBQWUsZ0JBQWdCO0FBQUEsVUFDM0ssRUFBRXBDLEtBQUssUUFBUTlHLE9BQU8sUUFBUStHLFFBQVFBLENBQUE0QixTQUFRLHVCQUFDLFVBQU8sT0FBT0EsS0FBS3VFLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCLEVBQUk7QUFBQSxVQUMzRSxFQUFFcEcsS0FBSyxTQUFTOUcsT0FBTyxjQUFjK0csUUFBUUEsQ0FBQTRCLFNBQVEsdUJBQUMsVUFBTyxPQUFPQSxLQUFLdUQsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsRUFBSTtBQUFBLFVBQ25GLEVBQUVwRixLQUFLLFVBQVU5RyxPQUFPLElBQUkrRyxRQUFRQSxDQUFBNEIsU0FBUSx1QkFBQyxrQkFBZSxZQUFXLG1CQUFrQixTQUFTLE1BQU07QUFBRTJFLHdCQUFZM0UsSUFBSTtBQUFHNEUscUJBQVM1RSxLQUFLdUQsVUFBVSxTQUFTLGFBQWF2RCxLQUFLdUQsS0FBSztBQUFHdUIsc0JBQVUsRUFBRTtBQUFBLFVBQUcsR0FBRyxxQkFBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUssRUFBa0I7QUFBQSxRQUFDLEtBTnRPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPRTtBQUFBLFFBQ0YsdUJBQUMsU0FBTSxNQUFNcEksS0FBS3VCLEtBQUtPLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQVRsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVWQsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBQ0EsdUJBQUMsY0FBVyxNQUFZLE9BQU0sZUFBYyxTQUFTLE1BQU0xQixRQUFRLEtBQUssR0FBRyxNQUFNRixPQUFPNkIsU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQ1UsY0FBYzFGLGdCQUFnQnNLLFFBQVEzSSxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUM2Six3QkFBd0JySSxPQUFPNkIsU0FBUyxTQUFTLFlBQVk7QUFDaFEsVUFBSTtBQUNBLGNBQU03QixPQUFPVyxRQUFRLEVBQUVDLE1BQU0sRUFBRTJCLFlBQVlvQixTQUFTQSxXQUFXLE1BQU1nRSxNQUFNUixTQUFTQSxRQUFRM0ksS0FBSyxFQUFFLEVBQUUsQ0FBQztBQUN0RzBCLGdCQUFRLEtBQUs7QUFDYnVILHNCQUFjLEVBQUU7QUFDaEJDLG1CQUFXLEVBQUU7QUFDYkcsbUJBQVcsRUFBRTtBQUFBLE1BQ2pCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFDWixHQUFHLDJCQVR1RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUzVGLEdBQ1Y7QUFBQSw2QkFBQyxlQUFZLE9BQU83SCxPQUFPOEIsU0FBU3lGLFVBQVV6RixTQUFTcUcsY0FBY3JHLFNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkU7QUFBQSxNQUMzRSx1QkFBQyxjQUNHO0FBQUEsK0JBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxjQUFhLE9BQU9TLFlBQVksVUFBVSxDQUFBaUcsVUFBUztBQUFFZix3QkFBY2UsTUFBTUMsT0FBTzdKLEtBQUs7QUFBRzhJLHFCQUFXLEVBQUU7QUFBQSxRQUFHLEdBQzNISCxvQkFBVWxHLE1BQU1BLEtBQUtVLElBQUksQ0FBQWEsYUFBWSx1QkFBQyxZQUEyQixPQUFPQSxTQUFTeEIsSUFBS3dCLG1CQUFTdEUsZUFBM0NzRSxTQUFTeEIsSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRSxDQUFXLEtBRDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsa0JBQWUsT0FBTSxjQUFhLGFBQWFtRyxVQUFVbUIsYUFBYSxTQUFTbkIsVUFBVW9CLFNBQVMsTUFBTXBCLFVBQVVxQixlQUFlLFlBQVlyQixVQUFVc0IsWUFBeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSztBQUFBLFFBQ2pLLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sdUNBQXNDLE9BQU9sRixTQUFTLFVBQVUsQ0FBQ3BCLGNBQWMsQ0FBQ0csaUJBQWlCeUYsY0FBY2hDLFdBQVcsVUFBVSxDQUFBcUMsVUFBU2QsV0FBV2MsTUFBTUMsT0FBTzdKLEtBQUssR0FBRyxZQUFZLENBQUM4RCxnQkFBZ0IsMEVBQTBFLENBQUNILGFBQWEsa0RBQWtENEYsY0FBY2hDLFlBQVksb0NBQW9DZ0MsY0FBYzlHLE1BQU1BLEtBQUt5RSxTQUFTLCtDQUErQywyREFDdmY7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sSUFBRyxrQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxVQUNwQ3FDLGNBQWM5RyxNQUFNQSxLQUFLVSxJQUFJLENBQUF3QixVQUFTLHVCQUFDLFlBQXdCLE9BQU9BLE1BQU1uQyxJQUFLbUM7QUFBQUEsa0JBQU1uQztBQUFBQSxZQUFHO0FBQUEsWUFBSTFHLGNBQWM2SSxNQUFNeUMsVUFBVTtBQUFBLGVBQXZFekMsTUFBTW5DLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGLENBQVc7QUFBQSxhQUY5STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDbUIsY0FBY0csaUJBQWlCLHVCQUFDLGtCQUFlLE9BQU0sc0JBQXFCLGFBQWF5RixjQUFjTyxhQUFhLFNBQVNQLGNBQWNRLFNBQVMsTUFBTVIsY0FBY1MsZUFBZSxZQUFZVCxjQUFjVSxZQUFoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlMO0FBQUEsUUFDek4sdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxnQkFBZSxPQUFPbEIsTUFBTSxVQUFVLENBQUFhLFVBQVNaLFFBQVFZLE1BQU1DLE9BQU83SixLQUFvQixHQUFJLFdBQUMsWUFBWSxhQUFhLGtCQUFrQixnQkFBZ0IsRUFBRW1ELElBQUksQ0FBQ25ELE9BQU9rSyxVQUFVLHVCQUFDLFlBQXFCLE9BQWUsV0FBQyxXQUFXLGFBQWEsb0JBQW9CLGtCQUFrQixFQUFFQSxLQUFLLEtBQTVGbEssT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHLENBQVcsS0FBaFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrVTtBQUFBLFFBQ2xVLHVCQUFDLGFBQVUsT0FBTSxZQUFXLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBT3VJLFNBQVMsVUFBVSxDQUFBcUIsVUFBU1gsV0FBV2pMLGdCQUFnQjRMLE1BQU1DLE9BQU83SixPQUFPLEdBQUksQ0FBQyxHQUFJLFlBQVksR0FBRy9CLGdCQUFnQnNLLE9BQU8sQ0FBQyxXQUFwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRMO0FBQUEsUUFDNUwsdUJBQUMsU0FBTSxVQUFTLFFBQU8sdUlBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEk7QUFBQSxXQVpsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsSUFDQSx1QkFBQyxjQUFXLE1BQU0sQ0FBQyxDQUFDVyxVQUFVLE9BQU0sb0JBQW1CLFNBQVMsTUFBTUMsWUFBWSxJQUFJLEdBQUcsTUFBTVAsT0FBTzNGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNvRyxPQUFPekosS0FBSyxLQUFLZ0osT0FBTzNGLFNBQVMsU0FBUyxZQUFZO0FBQ2pOLFVBQUksQ0FBQ2lHLFNBQVU7QUFDZixVQUFJO0FBQ0EsY0FBTU4sT0FBTzdHLFFBQVEsRUFBRWtDLE1BQU0sRUFBRWtHLFlBQVlqQixTQUFTMUcsR0FBRyxHQUFHUixNQUFNLEVBQUVvSSxpQkFBaUJsQixTQUFTekMsU0FBU3NCLE9BQU9zQixPQUFPLEVBQUUsQ0FBQztBQUN0SEYsb0JBQVksSUFBSTtBQUFBLE1BQ3BCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFDWixHQUFHLHdCQVBxSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTzdHLEdBQ1A7QUFBQSw2QkFBQyxlQUFZLE9BQU9QLE9BQU8xRixTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsY0FDRztBQUFBLCtCQUFDLGNBQVlnRyxvQkFBVVgsV0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQzlCVyxVQUFVbkUsV0FBVyx1QkFBQyxhQUFVLElBQUksTUFBTS9ELEtBQUt3QixFQUFFLFdBQVcwRyxTQUFTbkUsT0FBTyxJQUFJO0FBQUE7QUFBQSxVQUFRbUUsU0FBU25FO0FBQUFBLGFBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxRQUMxRyx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGtCQUFpQixPQUFPZ0QsT0FBTyxVQUFVLENBQUE2QixVQUFTUixTQUFTUSxNQUFNQyxPQUFPN0osS0FBcUIsR0FBRztBQUFBLGlDQUFDLFlBQVMsT0FBTSxZQUFXLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQVcsdUJBQUMsWUFBUyxPQUFNLFlBQVcsNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUyw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxhQUFsUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZRO0FBQUEsUUFDN1EsdUJBQUMsYUFBVSxPQUFNLG1CQUFrQixXQUFTLE1BQUMsU0FBUyxHQUFHLE9BQU9xSixRQUFRLFVBQVUsQ0FBQU8sVUFBU04sVUFBVXRMLGdCQUFnQjRMLE1BQU1DLE9BQU83SixPQUFPLEdBQUksQ0FBQyxLQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdKO0FBQUEsUUFDaEosdUJBQUMsU0FBTSxVQUFTLFFBQU8sMEhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUk7QUFBQSxXQUxySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQTVERztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkRQO0FBQ0o7QUFBQzBJLElBMUVlRCxrQkFBZ0I7QUFBQSxVQUNYNUssVUFDSkgsUUFBb0NLLGNBQy9CSCxhQUNJRSxRQUNQSCxZQUNBQSxZQUdPQyxXQUFXO0FBQUE7QUFBQSxNQVRyQjZLO0FBMkVoQixTQUFTcEQsaUJBQWlCckIsVUFBb0I7QUFDMUMsU0FBTyxFQUFFeUMsU0FBU3pDLFNBQVN5QyxTQUFTZixRQUFRLEVBQUVoRyxhQUFhc0UsU0FBU3RFLGFBQWFRLE9BQU84RCxTQUFTOUQsU0FBUyxJQUFJRSxPQUFPNEQsU0FBUzVELFNBQVMsSUFBSUksT0FBT3dELFNBQVN4RCxTQUFTLEdBQUcsR0FBRzZKLFFBQVFyRyxTQUFTNkMsZUFBZXRDLE9BQU8sQ0FBQzVCLFFBQXFDLENBQUMsZUFBZSxTQUFTLFNBQVMsT0FBTyxFQUFFd0UsU0FBU3hFLEdBQUcsQ0FBQyxFQUFFO0FBQ3JUO0FBQ0EsU0FBUytELGNBQWNoQixRQUFpQzRFLFVBQWlEO0FBQUUsUUFBTTFELFFBQTRCLENBQUM7QUFBRyxNQUFJbEIsT0FBT2hHLGdCQUFnQjRGLFVBQWEsQ0FBQ2dGLFNBQVNuRCxTQUFTLGFBQWE7QUFDck5QLFVBQU1sSCxjQUFjZ0csT0FBT2hHO0FBQWEsTUFBSWdHLE9BQU94RixVQUFVb0YsVUFBYSxDQUFDZ0YsU0FBU25ELFNBQVMsT0FBTztBQUNwR1AsVUFBTTFHLFFBQVF3RixPQUFPeEYsU0FBUztBQUFNLE1BQUl3RixPQUFPdEYsVUFBVWtGLFVBQWEsQ0FBQ2dGLFNBQVNuRCxTQUFTLE9BQU87QUFDaEdQLFVBQU14RyxRQUFRc0YsT0FBT3RGLFNBQVM7QUFBTSxNQUFJc0YsT0FBT2xGLFVBQVU4RSxVQUFhLENBQUNnRixTQUFTbkQsU0FBUyxPQUFPO0FBQ2hHUCxVQUFNcEcsUUFBUWtGLE9BQU9sRjtBQUFPLFNBQU9vRztBQUFPO0FBQUMsSUFBQTJELElBQUFDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwidXNlTGlzdFJldHVybiIsIm1hcmtEcmFmdENsZWFuIiwidXNlRHJhZnRGb3JtIiwiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU2VjdGlvbkdyaWQiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidXNlRm9ybSIsInVzZVdhdGNoIiwiem9kUmVzb2x2ZXIiLCJ1c2VUcmFuc2xhdGlvbiIsInoiLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwidXNlVmVyc2lvbmVkRHJhZnQiLCJEcmFmdENvbmZsaWN0IiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVBhZ2VkQXBpIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJ1c2VMaXN0UXVlcnkiLCJsaW1pdENvZGVQb2ludHMiLCJjb2RlUG9pbnRMZW5ndGgiLCJkYXRlVGltZSIsIkFtb3VudCIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIkRhdGFUYWJsZSIsIlF1ZXJ5U3RhdGUiLCJUb29sYmFyIiwiUGFnZXIiLCJTdGF0dXMiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIlJvdXRlTGluayIsIkRldGFpbExpbmUiLCJMb29rdXBMb2FkTW9yZSIsImxheW91dFN4IiwiQWRkcmVzc2VzUGFuZWwiLCJjdXN0b21lckZvcm1GaWVsZHMiLCJuYW1lIiwibGFiZWxLZXkiLCJtdWx0aWxpbmUiLCJjcmVhdGVDdXN0b21lclNjaGVtYSIsImNvcHkiLCJvYmplY3QiLCJkaXNwbGF5TmFtZSIsInN0cmluZyIsInRyaW0iLCJtaW4iLCJuYW1lUmVxdWlyZWQiLCJyZWZpbmUiLCJ2YWx1ZSIsIm5hbWVNYXgiLCJwaG9uZSIsInBob25lTWF4IiwiZW1haWwiLCJlbWFpbEZvcm1hdCIsIm9yIiwibGl0ZXJhbCIsIm5vdGVzIiwibm90ZXNNYXgiLCJ1c2VDdXN0b21lckNvcHkiLCJfcyIsInQiLCJzY2hlbWEiLCJDdXN0b21lcnNQYWdlIiwiX3MyIiwic2hvcCIsIm5hdmlnYXRlIiwibGlzdCIsInF1ZXJ5IiwiY3JlYXRlIiwib3BlbiIsInNldE9wZW4iLCJmb3JtIiwiZGVmYXVsdFZhbHVlcyIsInJlc29sdmVyIiwiY3JlYXRlRm9ybSIsInN1Ym1pdCIsImhhbmRsZVN1Ym1pdCIsImZpZWxkcyIsInJlc3BvbnNlIiwiZXhlY3V0ZSIsImJvZHkiLCJjdXJyZW50IiwiZGlhbG9nIiwiY2xvc2VzdCIsImRhdGFzZXQiLCJkcmFmdENsZWFuIiwiZHJhZnREaXJ0eSIsInJlc2V0IiwiaWQiLCJkYXRhIiwiYyIsImtleSIsInJlbmRlciIsInR5cG9ncmFwaHkiLCJmb250V2VpZ2h0Iiwic3Ryb25nIiwicGFnZSIsInBlbmRpbmciLCJlcnJvciIsIm1hcCIsImZpZWxkIiwicmVnaXN0ZXIiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJtZXNzYWdlIiwiQ3VzdG9tZXJQYWdlIiwiX3MzIiwiY3VzdG9tZXJJZCIsImxpc3RIcmVmIiwiY2FuRWRpdCIsImNhblJlYWRPcmRlcnMiLCJjYW5SZWFkU2hpcG1lbnRzIiwiY3VzdG9tZXIiLCJwYXRoIiwib3JkZXJzIiwibGltaXQiLCJzaGlwbWVudHMiLCJjYXNlcyIsImN1c3RvbWVyQ2FzZXMiLCJmaWx0ZXIiLCJpdGVtIiwiY3VzdG9tZXJPcmRlcklkcyIsIlNldCIsIm9yZGVyIiwiY3VzdG9tZXJTaGlwbWVudHMiLCJzaGlwbWVudCIsImhhcyIsIm9yZGVySWQiLCJ1cGRhdGUiLCJjb250cm9sIiwiZWRpdG9yIiwiaWRlbnRpdHkiLCJzb3VyY2UiLCJjdXN0b21lclNuYXBzaG90IiwidW5kZWZpbmVkIiwiZHJhZnQiLCJnZXRWYWx1ZXMiLCJhcHBseSIsInZhbHVlcyIsImJhc2VsaW5lIiwiT2JqZWN0Iiwia2V5cyIsInNldFZhbHVlIiwic2hvdWxkRGlydHkiLCJyZWZyZXNoIiwicmVmZXRjaCIsInRocm93T25FcnJvciIsImRyYWZ0Rm9ybSIsImRpcnR5Iiwic2F2ZSIsInN1Ym1pdHRlZCIsInByZXBhcmVkIiwicHJlcGFyZSIsInZlcnNpb24iLCJjdXN0b21lclBhdGNoIiwiZnJvbUVudHJpZXMiLCJwYXRjaCIsInJlZGFjdGVkRmllbGRzIiwiY29tbWl0dGVkIiwiZmFpbGVkIiwieHMiLCJsZyIsImxlbmd0aCIsImluY2x1ZGVzIiwib3JkZXJTdGF0ZSIsImRldGFpbCIsInJlbGF0ZWRJdGVtR2FwIiwiaXNQZW5kaW5nIiwiaXNFcnJvciIsInJlbGF0ZWRJdGVtSW5zZXQiLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImJvcmRlclJhZGl1cyIsInJhZGl1cyIsInRyYWNraW5nQ29kZSIsInN0YXRlIiwic2hpcHBpbmdGZWVRdW90ZSIsInNoaXBwaW5nRmVlQWN0dWFsIiwiZXZlbnRzIiwiYXQiLCJ0eXBlIiwib2NjdXJyZWRBdCIsInRpbWV6b25lIiwic3VtbWFyeSIsInJlbGF0ZWRDb250ZW50R2FwIiwiU2VydmljZUNhc2VzUGFnZSIsIl9zNCIsImN1c3RvbWVycyIsImNoYW5nZSIsInNldEN1c3RvbWVySWQiLCJzZXRPcmRlcklkIiwia2luZCIsInNldEtpbmQiLCJzZXRTdW1tYXJ5Iiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInNldFN0YXRlIiwicmVhc29uIiwic2V0UmVhc29uIiwicmVsYXRlZE9yZGVycyIsIkJvb2xlYW4iLCJzZWxlY3RlZE9yZGVySXNWYWxpZCIsInNvbWUiLCJmaW5kIiwiZXZlbnQiLCJ0YXJnZXQiLCJsb2FkZWRDb3VudCIsImhhc01vcmUiLCJpc0xvYWRpbmdNb3JlIiwibG9hZE1vcmUiLCJpbmRleCIsInJlc291cmNlSWQiLCJleHBlY3RlZFZlcnNpb24iLCJoaWRkZW4iLCJyZWRhY3RlZCIsIl9jIiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2xhYmVsIGFzIGJ1c2luZXNzTGFiZWx9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2xhYmVscyc7XG5pbXBvcnQge3VzZUxpc3RSZXR1cm59IGZyb20gJ0Avc2hhcmVkL21vZGVsL2xpc3QtcmV0dXJuJztcbmltcG9ydCB7IG1hcmtEcmFmdENsZWFuLCB1c2VEcmFmdEZvcm0gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9kaXJ0eS1kcmFmdHMnO1xuaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUZvcm0sIHVzZVdhdGNoIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJztcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IHR5cGUgeyBDdXN0b21lciwgU2VydmljZUNhc2UsIEN1c3RvbWVyV3JpdGVQYXRjaCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgdXNlVmVyc2lvbmVkRHJhZnQgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC92ZXJzaW9uZWQtZHJhZnQnO1xuaW1wb3J0IHsgRHJhZnRDb25mbGljdCB9IGZyb20gJ0Avc2hhcmVkL3VpL2RyYWZ0LWNvbmZsaWN0JztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCwgdXNlUGFnZWRBcGkgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlU2NvcGUsIHVzZUNhbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xuaW1wb3J0IHsgbGltaXRDb2RlUG9pbnRzLCBjb2RlUG9pbnRMZW5ndGgsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcbmltcG9ydCB7IEFtb3VudCwgUGFnZUhlYWRlciwgUGFuZWwsIERhdGFUYWJsZSwgUXVlcnlTdGF0ZSwgVG9vbGJhciwgUGFnZXIsIFN0YXR1cywgTXV0YXRpb25CdXR0b24sIEVkaXREaWFsb2csIEVycm9yTm90aWNlLCBSb3V0ZUxpbmssIERldGFpbExpbmUsIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL2xheW91dCc7XG5pbXBvcnQgeyBBZGRyZXNzZXNQYW5lbCB9IGZyb20gJy4vYWRkcmVzc2VzJztcbmNvbnN0IGN1c3RvbWVyRm9ybUZpZWxkcyA9IFtcbiAgICB7IG5hbWU6ICdkaXNwbGF5TmFtZScsIGxhYmVsS2V5OiAnY3VzdG9tZXJzLmZvcm0uY3VzdG9tZXJOYW1lJywgbXVsdGlsaW5lOiBmYWxzZSB9LFxuICAgIHsgbmFtZTogJ3Bob25lJywgbGFiZWxLZXk6ICdjdXN0b21lcnMuZm9ybS5waG9uZScsIG11bHRpbGluZTogZmFsc2UgfSxcbiAgICB7IG5hbWU6ICdlbWFpbCcsIGxhYmVsS2V5OiAnY3VzdG9tZXJzLmZvcm0uZW1haWwnLCBtdWx0aWxpbmU6IGZhbHNlIH0sXG4gICAgeyBuYW1lOiAnbm90ZXMnLCBsYWJlbEtleTogJ2N1c3RvbWVycy5mb3JtLm5vdGVzJywgbXVsdGlsaW5lOiB0cnVlIH0sXG5dIGFzIGNvbnN0O1xuZnVuY3Rpb24gY3JlYXRlQ3VzdG9tZXJTY2hlbWEoY29weToge1xuICAgIG5hbWVSZXF1aXJlZDogc3RyaW5nO1xuICAgIG5hbWVNYXg6IHN0cmluZztcbiAgICBwaG9uZU1heDogc3RyaW5nO1xuICAgIGVtYWlsRm9ybWF0OiBzdHJpbmc7XG4gICAgbm90ZXNNYXg6IHN0cmluZztcbn0pIHtcbiAgICByZXR1cm4gei5vYmplY3Qoe1xuICAgICAgICBkaXNwbGF5TmFtZTogei5zdHJpbmcoKS50cmltKCkubWluKDEsIGNvcHkubmFtZVJlcXVpcmVkKS5yZWZpbmUodmFsdWUgPT4gY29kZVBvaW50TGVuZ3RoKHZhbHVlKSA8PSAxNjAsIGNvcHkubmFtZU1heCksXG4gICAgICAgIHBob25lOiB6LnN0cmluZygpLnJlZmluZSh2YWx1ZSA9PiBjb2RlUG9pbnRMZW5ndGgodmFsdWUpIDw9IDQwLCBjb3B5LnBob25lTWF4KSxcbiAgICAgICAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoY29weS5lbWFpbEZvcm1hdCkub3Ioei5saXRlcmFsKCcnKSksXG4gICAgICAgIG5vdGVzOiB6LnN0cmluZygpLnJlZmluZSh2YWx1ZSA9PiBjb2RlUG9pbnRMZW5ndGgodmFsdWUpIDw9IDQwMDAsIGNvcHkubm90ZXNNYXgpLFxuICAgIH0pO1xufVxudHlwZSBDdXN0b21lckZpZWxkcyA9IHouaW5mZXI8UmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlQ3VzdG9tZXJTY2hlbWE+PjtcbmZ1bmN0aW9uIHVzZUN1c3RvbWVyQ29weSgpIHtcbiAgICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gICAgY29uc3Qgc2NoZW1hID0gdXNlTWVtbygoKSA9PiBjcmVhdGVDdXN0b21lclNjaGVtYSh7XG4gICAgICAgIG5hbWVSZXF1aXJlZDogdCgnY3VzdG9tZXJzLnZhbGlkYXRpb24ubmFtZVJlcXVpcmVkJyksXG4gICAgICAgIG5hbWVNYXg6IHQoJ2N1c3RvbWVycy52YWxpZGF0aW9uLm5hbWVNYXgnKSxcbiAgICAgICAgcGhvbmVNYXg6IHQoJ2N1c3RvbWVycy52YWxpZGF0aW9uLnBob25lTWF4JyksXG4gICAgICAgIGVtYWlsRm9ybWF0OiB0KCdjdXN0b21lcnMudmFsaWRhdGlvbi5lbWFpbEZvcm1hdCcpLFxuICAgICAgICBub3Rlc01heDogdCgnY3VzdG9tZXJzLnZhbGlkYXRpb24ubm90ZXNNYXgnKSxcbiAgICB9KSwgW3RdKTtcbiAgICByZXR1cm4geyB0LCBzY2hlbWEgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21lcnNQYWdlKCkge1xuICAgIGNvbnN0IHsgdCwgc2NoZW1hIH0gPSB1c2VDdXN0b21lckNvcHkoKTtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RDdXN0b21lcnMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RDdXN0b21lcnMnKSB9KTtcbiAgICBjb25zdCBjcmVhdGUgPSB1c2VDb21tYW5kKCdjcmVhdGVDdXN0b21lcicsIFsnbGlzdEN1c3RvbWVycyddKTtcbiAgICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgZm9ybSA9IHVzZUZvcm08Q3VzdG9tZXJGaWVsZHM+KHsgZGVmYXVsdFZhbHVlczogeyBkaXNwbGF5TmFtZTogJycsIHBob25lOiAnJywgZW1haWw6ICcnLCBub3RlczogJycgfSwgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHNjaGVtYSkgfSk7XG4gICAgY29uc3QgY3JlYXRlRm9ybSA9IHVzZVJlZjxIVE1MRm9ybUVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IHN1Ym1pdCA9IGZvcm0uaGFuZGxlU3VibWl0KGFzeW5jIChmaWVsZHMpID0+IHsgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHk6IHsgLi4uZmllbGRzLCBwaG9uZTogZmllbGRzLnBob25lIHx8IG51bGwsIGVtYWlsOiBmaWVsZHMuZW1haWwgfHwgbnVsbCB9IH0pO1xuICAgICAgICBpZiAoY3JlYXRlRm9ybS5jdXJyZW50KSB7XG4gICAgICAgICAgICBtYXJrRHJhZnRDbGVhbihjcmVhdGVGb3JtLmN1cnJlbnQpO1xuICAgICAgICAgICAgY29uc3QgZGlhbG9nID0gY3JlYXRlRm9ybS5jdXJyZW50LmNsb3Nlc3Q8SFRNTEVsZW1lbnQ+KCdbcm9sZT1cImRpYWxvZ1wiXScpO1xuICAgICAgICAgICAgaWYgKGRpYWxvZykgeyBkaWFsb2cuZGF0YXNldC5kcmFmdENsZWFuID0gJ3RydWUnOyBkZWxldGUgZGlhbG9nLmRhdGFzZXQuZHJhZnREaXJ0eTsgfVxuICAgICAgICB9XG4gICAgICAgIHNldE9wZW4oZmFsc2UpO1xuICAgICAgICBmb3JtLnJlc2V0KCk7XG4gICAgICAgIG5hdmlnYXRlKGAvcy8ke3Nob3AuaWR9L2N1c3RvbWVycy8ke3Jlc3BvbnNlLmRhdGEuaWR9YCk7XG4gICAgfVxuICAgIGNhdGNoIHsgLyogZXJyb3Igc3RheXMgaW4gZGlhbG9nICovIH0gfSk7XG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9e3QoJ2N1c3RvbWVycy5saXN0LnRpdGxlJyl9IHN1YnRpdGxlPXt0KCdjdXN0b21lcnMubGlzdC5zdWJ0aXRsZScpfSBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImN1c3RvbWVycy53cml0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT57dCgnY3VzdG9tZXJzLmxpc3QuYWRkQWN0aW9uJyl9PC9NdXRhdGlvbkJ1dHRvbj59Lz48UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdEN1c3RvbWVyc1wiIHBsYWNlaG9sZGVyPXt0KCdjdXN0b21lcnMubGlzdC5zZWFyY2hQbGFjZWhvbGRlcicpfSBjdXJzb3JQYXJhbT1cImN1cnNvclwiLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9e3QoJ2N1c3RvbWVycy5saXN0LnRhYmxlTGFiZWwnKX0gZW1wdHk9e3QoJ2N1c3RvbWVycy5saXN0LmVtcHR5Jyl9IHJvd3M9e2xpc3QuZGF0YS5kYXRhfSByb3dLZXk9e2MgPT4gYy5pZH0gY29sdW1ucz17W1xuICAgICAgICB7IGtleTogJ25hbWUnLCBsYWJlbDogdCgnY3VzdG9tZXJzLmxpc3QuY3VzdG9tZXJDb2x1bW4nKSwgcmVuZGVyOiBjID0+IDxUeXBvZ3JhcGh5IGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmd9PntjLmRpc3BsYXlOYW1lfTwvVHlwb2dyYXBoeT4gfSwgeyBrZXk6ICdwaG9uZScsIGxhYmVsOiB0KCdjdXN0b21lcnMubGlzdC5jb250YWN0Q29sdW1uJyksIHJlbmRlcjogYyA9PiBjLnBob25lIHx8IHQoJ2N1c3RvbWVycy5saXN0LmNvbnRhY3RVbmF2YWlsYWJsZScpIH0sIHsga2V5OiAnZW1haWwnLCBsYWJlbDogdCgnY3VzdG9tZXJzLmxpc3QuZW1haWxDb2x1bW4nKSwgcmVuZGVyOiBjID0+IGMuZW1haWwgfHwgJ+KAlCcgfSwgeyBrZXk6ICdub3RlJywgbGFiZWw6IHQoJ2N1c3RvbWVycy5saXN0Lm5vdGVzQ29sdW1uJyksIHJlbmRlcjogYyA9PiBjLm5vdGVzIHx8ICfigJQnIH0sIHsga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IGMgPT4gPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vY3VzdG9tZXJzLyR7Yy5pZH1gfT57dCgnY3VzdG9tZXJzLmxpc3QucHJvZmlsZUFjdGlvbicpfTwvUm91dGVMaW5rPiB9XG4gICAgXX0vPjxQYWdlciBwYWdlPXtsaXN0LmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD48RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT17dCgnY3VzdG9tZXJzLmZvcm0uY3JlYXRlVGl0bGUnKX0gb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwiY3VzdG9tZXItY3JlYXRlLWZvcm1cIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e2NyZWF0ZS5wZW5kaW5nfT57dCgnY3VzdG9tZXJzLmZvcm0uY3JlYXRlQWN0aW9uJyl9PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0vPjxGb3JtRmllbGRzIGNvbXBvbmVudD1cImZvcm1cIiByZWY9e2NyZWF0ZUZvcm19IGlkPVwiY3VzdG9tZXItY3JlYXRlLWZvcm1cIiBvblN1Ym1pdD17c3VibWl0fSBub1ZhbGlkYXRlID57Y3VzdG9tZXJGb3JtRmllbGRzLm1hcChmaWVsZCA9PiA8VGV4dEZpZWxkIGtleT17ZmllbGQubmFtZX0gbGFiZWw9e3QoZmllbGQubGFiZWxLZXkpfSBkaXNhYmxlZD17Y3JlYXRlLnBlbmRpbmd9IHsuLi5mb3JtLnJlZ2lzdGVyKGZpZWxkLm5hbWUpfSBlcnJvcj17ISFmb3JtLmZvcm1TdGF0ZS5lcnJvcnNbZmllbGQubmFtZV19IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9yc1tmaWVsZC5uYW1lXT8ubWVzc2FnZX0gbXVsdGlsaW5lPXtmaWVsZC5tdWx0aWxpbmV9Lz4pfTwvRm9ybUZpZWxkcz48L0VkaXREaWFsb2c+PC8+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIEN1c3RvbWVyUGFnZSgpIHtcbiAgICBjb25zdCB7IHQsIHNjaGVtYSB9ID0gdXNlQ3VzdG9tZXJDb3B5KCk7XG4gICAgY29uc3QgeyBjdXN0b21lcklkID0gJycgfSA9IHVzZVBhcmFtcygpO1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBsaXN0SHJlZj11c2VMaXN0UmV0dXJuKGAvcy8ke3Nob3AuaWR9L2N1c3RvbWVyc2ApO1xuICAgIGNvbnN0IGNhbkVkaXQgPSB1c2VDYW4oJ2N1c3RvbWVycy53cml0ZScpO1xuICAgIGNvbnN0IGNhblJlYWRPcmRlcnMgPSB1c2VDYW4oJ29yZGVycy5yZWFkJyk7XG4gICAgY29uc3QgY2FuUmVhZFNoaXBtZW50cyA9IHVzZUNhbignZnVsZmlsbG1lbnQucmVhZCcpO1xuICAgIGNvbnN0IGN1c3RvbWVyID0gdXNlQXBpKCdnZXRDdXN0b21lcicsIHsgcGF0aDogeyBjdXN0b21lcklkIH0gfSk7XG4gICAgY29uc3Qgb3JkZXJzID0gdXNlQXBpKCdsaXN0T3JkZXJzJywgeyBxdWVyeTogeyBjdXN0b21lcklkLCBsaW1pdDogMTAgfSB9LCBjYW5SZWFkT3JkZXJzKTtcbiAgICBjb25zdCBzaGlwbWVudHMgPSB1c2VBcGkoJ2xpc3RTaGlwbWVudHMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAxMDAgfSB9LCBjYW5SZWFkU2hpcG1lbnRzICYmIGNhblJlYWRPcmRlcnMpO1xuICAgIGNvbnN0IGNhc2VzID0gdXNlQXBpKCdsaXN0U2VydmljZUNhc2VzJywgeyBxdWVyeTogeyBsaW1pdDogMTAgfSB9KTtcbiAgICBjb25zdCBjdXN0b21lckNhc2VzID0gY2FzZXMuZGF0YT8uZGF0YS5maWx0ZXIoaXRlbSA9PiBpdGVtLmN1c3RvbWVySWQgPT09IGN1c3RvbWVySWQpID8/IFtdO1xuICAgIGNvbnN0IGN1c3RvbWVyT3JkZXJJZHMgPSBuZXcgU2V0KChvcmRlcnMuZGF0YT8uZGF0YSA/PyBbXSkubWFwKG9yZGVyID0+IG9yZGVyLmlkKSk7XG4gICAgY29uc3QgY3VzdG9tZXJTaGlwbWVudHMgPSAoc2hpcG1lbnRzLmRhdGE/LmRhdGEgPz8gW10pLmZpbHRlcihzaGlwbWVudCA9PiBjdXN0b21lck9yZGVySWRzLmhhcyhzaGlwbWVudC5vcmRlcklkKSk7XG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlQ3VzdG9tZXInLCBbJ2dldEN1c3RvbWVyJywgJ2xpc3RDdXN0b21lcnMnXSk7XG4gICAgY29uc3QgZm9ybSA9IHVzZUZvcm08Q3VzdG9tZXJGaWVsZHM+KHsgZGVmYXVsdFZhbHVlczogeyBkaXNwbGF5TmFtZTogJycsIHBob25lOiAnJywgZW1haWw6ICcnLCBub3RlczogJycgfSwgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHNjaGVtYSkgfSk7XG4gICAgdXNlV2F0Y2goeyBjb250cm9sOiBmb3JtLmNvbnRyb2wgfSk7XG4gICAgY29uc3QgZWRpdG9yID0gdXNlVmVyc2lvbmVkRHJhZnQoe1xuICAgICAgICBpZGVudGl0eTogYCR7c2hvcC5pZH06Y3VzdG9tZXI6JHtjdXN0b21lcklkfWAsXG4gICAgICAgIHNvdXJjZTogY3VzdG9tZXIuZGF0YSA/IGN1c3RvbWVyU25hcHNob3QoY3VzdG9tZXIuZGF0YS5kYXRhKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgZHJhZnQ6IGZvcm0uZ2V0VmFsdWVzKCksXG4gICAgICAgIGFwcGx5OiAodmFsdWVzLCBiYXNlbGluZSkgPT4ge1xuICAgICAgICAgICAgZm9ybS5yZXNldChiYXNlbGluZSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyh2YWx1ZXMpIGFzIChrZXlvZiBDdXN0b21lckZpZWxkcylbXSkgZm9ybS5zZXRWYWx1ZShrZXksIHZhbHVlc1trZXldLCB7IHNob3VsZERpcnR5OiB0cnVlIH0pO1xuICAgICAgICB9LFxuICAgICAgICByZWZyZXNoOiAoKSA9PiBjdXN0b21lci5yZWZldGNoKHsgdGhyb3dPbkVycm9yOiB0cnVlIH0pLFxuICAgIH0pO1xuICAgIGNvbnN0IGRyYWZ0Rm9ybSA9IHVzZURyYWZ0Rm9ybShlZGl0b3IuZGlydHkpO1xuICAgIGNvbnN0IHNhdmUgPSBmb3JtLmhhbmRsZVN1Ym1pdChhc3luYyAodmFsdWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IGZvcm0uZ2V0VmFsdWVzKCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBwcmVwYXJlZCA9IGVkaXRvci5wcmVwYXJlKCk7XG4gICAgICAgICAgICBpZiAoIXByZXBhcmVkKSByZXR1cm47XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHVwZGF0ZS5leGVjdXRlKHtcbiAgICAgICAgICAgICAgICBwYXRoOiB7IGN1c3RvbWVySWQgfSwgdmVyc2lvbjogcHJlcGFyZWQudmVyc2lvbiwgYm9keTogY3VzdG9tZXJQYXRjaChPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmtleXMocHJlcGFyZWQucGF0Y2gpLm1hcChrZXkgPT4gW2tleSwgdmFsdWVzW2tleSBhcyBrZXlvZiBDdXN0b21lckZpZWxkc11dKSksIGN1c3RvbWVyLmRhdGE/LmRhdGEucmVkYWN0ZWRGaWVsZHMgfHwgW10pXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGVkaXRvci5jb21taXR0ZWQoY3VzdG9tZXJTbmFwc2hvdChyZXNwb25zZS5kYXRhKSwgc3VibWl0dGVkKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHsgZWRpdG9yLmZhaWxlZChlcnJvcik7IH1cbiAgICB9KTtcbiAgICByZXR1cm4gPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9e2N1c3RvbWVyLmRhdGE/LmRhdGEuZGlzcGxheU5hbWUgfHwgdCgnY3VzdG9tZXJzLmRldGFpbC5mYWxsYmFja1RpdGxlJyl9IHN1YnRpdGxlPXt0KCdjdXN0b21lcnMuZGV0YWlsLnN1YnRpdGxlJyl9IGFjdGlvbnM9ezxSb3V0ZUxpbmsgdG89e2xpc3RIcmVmfT57dCgnY3VzdG9tZXJzLmRldGFpbC5saXN0QWN0aW9uJyl9PC9Sb3V0ZUxpbms+fS8+XG4gICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtjdXN0b21lcn0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+XG4gICAgICAgICAgICB7Y3VzdG9tZXIuZGF0YSAmJiA8U2VjdGlvbkdyaWQgc2hyaW5rQ2hpbGRyZW4gY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMS4yZnIgMWZyJyB9fT5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9e3QoJ2N1c3RvbWVycy5kZXRhaWwuaW5mb3JtYXRpb24nKX0gYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtkcmFmdEZvcm19IGRhdGEtZHJhZnQtY2xlYW49eyFlZGl0b3IuZGlydHkgPyAndHJ1ZScgOiB1bmRlZmluZWR9IG9uU3VibWl0PXtzYXZlfSA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e3VwZGF0ZS5lcnJvcn0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17eyBkaXNwbGF5TmFtZTogJ1TDqm4ga2jDoWNoIGjDoG5nJywgcGhvbmU6ICfEkGnhu4duIHRob+G6oWknLCBlbWFpbDogJ0VtYWlsJywgbm90ZXM6ICdHaGkgY2jDuicgfX0gYnVzeT17dXBkYXRlLnBlbmRpbmd9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5kYXRhLmRhdGEucmVkYWN0ZWRGaWVsZHMubGVuZ3RoID4gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e3QoJ2N1c3RvbWVycy5kZXRhaWwucmVkYWN0ZWROb3RpY2UnKX08L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lckZvcm1GaWVsZHMubWFwKGZpZWxkID0+IDxUZXh0RmllbGQga2V5PXtmaWVsZC5uYW1lfSBsYWJlbD17dChmaWVsZC5sYWJlbEtleSl9IHsuLi5mb3JtLnJlZ2lzdGVyKGZpZWxkLm5hbWUpfSBlcnJvcj17ISFmb3JtLmZvcm1TdGF0ZS5lcnJvcnNbZmllbGQubmFtZV19IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9yc1tmaWVsZC5uYW1lXT8ubWVzc2FnZX0gZGlzYWJsZWQ9eyFjYW5FZGl0IHx8IGN1c3RvbWVyLmRhdGE/LmRhdGEucmVkYWN0ZWRGaWVsZHMuaW5jbHVkZXMoZmllbGQubmFtZSl9IG11bHRpbGluZT17ZmllbGQubXVsdGlsaW5lfSBtaW5Sb3dzPXtmaWVsZC5tdWx0aWxpbmUgPyAzIDogdW5kZWZpbmVkfS8+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiY3VzdG9tZXJzLndyaXRlXCIgdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXt1cGRhdGUucGVuZGluZ30gZGlzYWJsZWQ9eyFlZGl0b3IuZGlydHl9Pnt0KCdjdXN0b21lcnMuZm9ybS5zYXZlQWN0aW9uJyl9PC9NdXRhdGlvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICAgICAgPFBhZ2VTZWN0aW9ucyA+XG4gICAgICAgICAgICAgICAgICAgIDxBZGRyZXNzZXNQYW5lbCBrZXk9e2N1c3RvbWVyLmRhdGEuZGF0YS5pZH0gY3VzdG9tZXI9e2N1c3RvbWVyLmRhdGEuZGF0YX0vPlxuICAgICAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9e3QoJ2N1c3RvbWVycy5kZXRhaWwucmVjZW50T3JkZXJzJyl9IGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FuUmVhZE9yZGVyc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtvcmRlcnN9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVycy5kYXRhICYmIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVycy5kYXRhLmRhdGEubWFwKG9yZGVyID0+IDxEZXRhaWxMaW5lIGtleT17b3JkZXIuaWR9IGxhYmVsPXtvcmRlci5pZH0+PFJvdXRlTGluayB0bz17Jy9zLycgKyBzaG9wLmlkICsgJy9vcmRlcnMvJyArIG9yZGVyLmlkfT5Nw6MgxJHGoW46IHtvcmRlci5pZH0gwrcge2J1c2luZXNzTGFiZWwob3JkZXIub3JkZXJTdGF0ZSl9PC9Sb3V0ZUxpbms+PC9EZXRhaWxMaW5lPil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVycy5kYXRhLmRhdGEubGVuZ3RoID09PSAwICYmIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj57dCgnY3VzdG9tZXJzLmRldGFpbC5ub09yZGVycycpfTwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3QoJ2N1c3RvbWVycy5kZXRhaWwub3JkZXJQcmV2aWV3TGltaXQnKX08L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdXRlTGluayB0bz17Jy9zLycgKyBzaG9wLmlkICsgJy9vcmRlcnMnfT57dCgnY3VzdG9tZXJzLmRldGFpbC5vcGVuT3JkZXJzJyl9PC9Sb3V0ZUxpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgcm9sZT1cInN0YXR1c1wiPnt0KCdjdXN0b21lcnMuZGV0YWlsLnNoaXBtZW50UGVybWlzc2lvbicpfTwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgICAgICAgICAgPFBhbmVsIHRpdGxlPXt0KCdjdXN0b21lcnMuZGV0YWlsLnJlbGF0ZWRTaGlwbWVudHMnKX0gYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NhblJlYWRPcmRlcnMgJiYgY2FuUmVhZFNoaXBtZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e3NoaXBtZW50c30+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaGlwbWVudHMuZGF0YSAmJiA8U3RhY2sgc3g9e2xheW91dFN4LmRldGFpbC5yZWxhdGVkSXRlbUdhcH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXJzLmlzUGVuZGluZyAmJiAhb3JkZXJzLmRhdGEgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPnt0KCdjdXN0b21lcnMuZGV0YWlsLm9yZGVyc0xvYWRpbmcnKX08L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVycy5pc0Vycm9yICYmICFvcmRlcnMuZGF0YSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgcm9sZT1cInN0YXR1c1wiPnt0KCdjdXN0b21lcnMuZGV0YWlsLm9yZGVyc1VuYXZhaWxhYmxlJyl9PC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXJzLmRhdGEgJiYgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJTaGlwbWVudHMubWFwKGl0ZW0gPT4gPEJveCBrZXk9e2l0ZW0uaWR9IHN4PXtbbGF5b3V0U3guZGV0YWlsLnJlbGF0ZWRJdGVtSW5zZXQsIHsgYm9yZGVyOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInLCBib3JkZXJSYWRpdXM6IHZpc3VhbFN4LnJhZGl1cy5jb250cm9sIH1dfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiA+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e2l0ZW0udHJhY2tpbmdDb2RlIHx8IGl0ZW0uaWR9PC9UeXBvZ3JhcGh5PjxTdGF0dXMgdmFsdWU9e2l0ZW0uc3RhdGV9Lz48L0FjdGlvbkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIsSQxqFuIGjDoG5nXCI+PFJvdXRlTGluayB0bz17Jy9zLycgKyBzaG9wLmlkICsgJy9vcmRlcnMvJyArIGl0ZW0ub3JkZXJJZH0+e2l0ZW0ub3JkZXJJZH08L1JvdXRlTGluaz48L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiUGjDrSBk4buxIGtp4bq/blwiPjxBbW91bnQgd3JhcCB2YWx1ZT17aXRlbS5zaGlwcGluZ0ZlZVF1b3RlfS8+PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlBow60gdGjhu7FjIHThur9cIj48QW1vdW50IHdyYXAgdmFsdWU9e2l0ZW0uc2hpcHBpbmdGZWVBY3R1YWx9Lz48L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmV2ZW50cy5hdCgtMSkgJiYgPERldGFpbExpbmUgbGFiZWw9XCJD4bqtcCBuaOG6rXQgZ+G6p24gbmjhuqV0XCI+e2l0ZW0uZXZlbnRzLmF0KC0xKT8udHlwZX0gwrcge2RhdGVUaW1lKGl0ZW0uZXZlbnRzLmF0KC0xKSEub2NjdXJyZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclNoaXBtZW50cy5sZW5ndGggPT09IDAgJiYgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPnt0KCdjdXN0b21lcnMuZGV0YWlsLm5vU2hpcG1lbnRzJyl9PC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj57dCgnY3VzdG9tZXJzLmRldGFpbC5zaGlwbWVudFByZXZpZXdMaW1pdCcpfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89eycvcy8nICsgc2hvcC5pZCArICcvc2hpcG1lbnRzJ30+e3QoJ2N1c3RvbWVycy5kZXRhaWwub3BlblNoaXBtZW50cycpfTwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+e3QoJ2N1c3RvbWVycy5kZXRhaWwuc2hpcG1lbnRQZXJtaXNzaW9uJyl9PC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICAgICAgICAgIDxQYW5lbCB0aXRsZT17dCgnY3VzdG9tZXJzLmRldGFpbC5zdXBwb3J0Q2FzZXMnKX0gYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2Nhc2VzfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FzZXMuZGF0YSAmJiA8U3RhY2s+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lckNhc2VzLm1hcChpdGVtID0+IDxEZXRhaWxMaW5lIGtleT17aXRlbS5pZH0gbGFiZWw9e2l0ZW0uc3VtbWFyeX0+PFN0YXR1cyB2YWx1ZT17aXRlbS5zdGF0ZX0vPjwvRGV0YWlsTGluZT4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJDYXNlcy5sZW5ndGggPT09IDAgJiYgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPnt0KCdjdXN0b21lcnMuZGV0YWlsLm5vU3VwcG9ydENhc2VzJyl9PC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LmRldGFpbC5yZWxhdGVkQ29udGVudEdhcH0+e3QoJ2N1c3RvbWVycy5kZXRhaWwuc3VwcG9ydENhc2VzTGltaXQnKX08L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89eycvcy8nICsgc2hvcC5pZCArICcvc2VydmljZS1jYXNlcyd9Pnt0KCdjdXN0b21lcnMuZGV0YWlsLm9wZW5TdXBwb3J0Q2FzZXMnKX08L1JvdXRlTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgICAgICA8L1BhZ2VTZWN0aW9ucz5cbiAgICAgICAgICAgIDwvU2VjdGlvbkdyaWQ+fVxuICAgICAgICA8L1F1ZXJ5U3RhdGU+XG4gICAgPC8+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIFNlcnZpY2VDYXNlc1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RTZXJ2aWNlQ2FzZXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RTZXJ2aWNlQ2FzZXMnKSB9KTtcbiAgICBjb25zdCBjdXN0b21lcnMgPSB1c2VQYWdlZEFwaSgnbGlzdEN1c3RvbWVycycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwIH0gfSk7XG4gICAgY29uc3QgY2FuUmVhZE9yZGVycyA9IHVzZUNhbignb3JkZXJzLnJlYWQnKTtcbiAgICBjb25zdCBjcmVhdGUgPSB1c2VDb21tYW5kKCdjcmVhdGVTZXJ2aWNlQ2FzZScsIFsnbGlzdFNlcnZpY2VDYXNlcyddKTtcbiAgICBjb25zdCBjaGFuZ2UgPSB1c2VDb21tYW5kKCdzZXRTZXJ2aWNlQ2FzZVN0YXR1cycsIFsnbGlzdFNlcnZpY2VDYXNlcyddKTtcbiAgICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSksIFtjdXN0b21lcklkLCBzZXRDdXN0b21lcklkXSA9IHVzZVN0YXRlKCcnKSwgW29yZGVySWQsIHNldE9yZGVySWRdID0gdXNlU3RhdGUoJycpLCBba2luZCwgc2V0S2luZF0gPSB1c2VTdGF0ZTwncXVlc3Rpb24nIHwgJ2NvbXBsYWludCcgfCAncmV0dXJuX3JlcXVlc3QnIHwgJ2RlbGl2ZXJ5X2lzc3VlJz4oJ3F1ZXN0aW9uJyksIFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPFNlcnZpY2VDYXNlIHwgbnVsbD4obnVsbCksIFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGU8J2Fzc2lnbmVkJyB8ICdyZXNvbHZlZCcgfCAnY2xvc2VkJz4oJ2Fzc2lnbmVkJyksIFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgcmVsYXRlZE9yZGVycyA9IHVzZVBhZ2VkQXBpKCdsaXN0T3JkZXJzJywgeyBxdWVyeTogeyBjdXN0b21lcklkLCBsaW1pdDogNTAgfSB9LCBCb29sZWFuKGN1c3RvbWVySWQpICYmIGNhblJlYWRPcmRlcnMpO1xuICAgIGNvbnN0IHNlbGVjdGVkT3JkZXJJc1ZhbGlkID0gIW9yZGVySWQgfHwgcmVsYXRlZE9yZGVycy5kYXRhPy5kYXRhLnNvbWUob3JkZXIgPT4gb3JkZXIuaWQgPT09IG9yZGVySWQpO1xuXG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiQ2jEg20gc8OzYyBzYXUgYsOhblwiIHN1YnRpdGxlPVwiTmjhuq1uIGPDonUgaOG7j2ksIGtoaeG6v3UgbuG6oWkgdsOgIHnDqnUgY+G6p3UgxJHhu5VpIHRy4bqjOyBraMO0bmcgdOG7sSBo4bupYSBob8OgbiB0aeG7gW4uXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJjdXN0b21lcnMud3JpdGVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0+VOG6oW8gecOqdSBj4bqndTwvTXV0YXRpb25CdXR0b24+fSAvPlxuICAgICAgICA8UGFuZWw+XG4gICAgICAgICAgICA8VG9vbGJhciBvcGVyYXRpb249XCJsaXN0U2VydmljZUNhc2VzXCIgLz5cbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICB7bGlzdC5kYXRhICYmIDw+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJZw6p1IGPhuqd1IGNoxINtIHPDs2Mgc2F1IGLDoW5cIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtpdGVtID0+IGl0ZW0uaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnc3VtbWFyeScsIGxhYmVsOiAnWcOqdSBj4bqndScsIHJlbmRlcjogaXRlbSA9PiA8U3RhY2s+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e2l0ZW0uc3VtbWFyeX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57aXRlbS5pZH08L1R5cG9ncmFwaHk+PC9TdGFjaz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnY3VzdG9tZXInLCBsYWJlbDogJ0tow6FjaCcsIHJlbmRlcjogaXRlbSA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9jdXN0b21lcnMvJHtpdGVtLmN1c3RvbWVySWR9YH0+e2N1c3RvbWVycy5kYXRhPy5kYXRhLmZpbmQoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IGl0ZW0uY3VzdG9tZXJJZCk/LmRpc3BsYXlOYW1lIHx8IGl0ZW0uY3VzdG9tZXJJZH08L1JvdXRlTGluaz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnb3JkZXInLCBsYWJlbDogJ8SQxqFuIGxpw6puIHF1YW4nLCByZW5kZXI6IGl0ZW0gPT4gaXRlbS5vcmRlcklkID8gPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vb3JkZXJzLyR7aXRlbS5vcmRlcklkfWB9PntpdGVtLm9yZGVySWR9PC9Sb3V0ZUxpbms+IDogJ0NoxrBhIGxpw6puIGvhur90JyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICd0eXBlJywgbGFiZWw6ICdMb+G6oWknLCByZW5kZXI6IGl0ZW0gPT4gPFN0YXR1cyB2YWx1ZT17aXRlbS5raW5kfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogaXRlbSA9PiA8U3RhdHVzIHZhbHVlPXtpdGVtLnN0YXRlfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJycsIHJlbmRlcjogaXRlbSA9PiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImN1c3RvbWVycy53cml0ZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWQoaXRlbSk7IHNldFN0YXRlKGl0ZW0uc3RhdGUgPT09ICdvcGVuJyA/ICdhc3NpZ25lZCcgOiBpdGVtLnN0YXRlKTsgc2V0UmVhc29uKCcnKTsgfX0+WOG7rSBsw708L011dGF0aW9uQnV0dG9uPiB9LFxuICAgICAgICAgICAgICAgICAgICBdfSAvPlxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9IC8+XG4gICAgICAgICAgICAgICAgPC8+fVxuICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxuICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT1cIlnDqnUgY+G6p3UgbeG7m2lcIiBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gYnVzeT17Y3JlYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshY3VzdG9tZXJJZCB8fCBjb2RlUG9pbnRMZW5ndGgoc3VtbWFyeS50cmltKCkpIDwgNSB8fCAhc2VsZWN0ZWRPcmRlcklzVmFsaWQgfHwgY3JlYXRlLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IGN1c3RvbWVySWQsIG9yZGVySWQ6IG9yZGVySWQgfHwgbnVsbCwga2luZCwgc3VtbWFyeTogc3VtbWFyeS50cmltKCkgfSB9KTtcbiAgICAgICAgICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21lcklkKCcnKTtcbiAgICAgICAgICAgICAgICBzZXRPcmRlcklkKCcnKTtcbiAgICAgICAgICAgICAgICBzZXRTdW1tYXJ5KCcnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9XG4gICAgICAgIH19PlThuqFvIHnDqnUgY+G6p3U8L0J1dHRvbj59PlxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3IgfHwgY3VzdG9tZXJzLmVycm9yIHx8IHJlbGF0ZWRPcmRlcnMuZXJyb3J9IC8+XG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyA+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJLaMOhY2ggaMOgbmdcIiB2YWx1ZT17Y3VzdG9tZXJJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgc2V0Q3VzdG9tZXJJZChldmVudC50YXJnZXQudmFsdWUpOyBzZXRPcmRlcklkKCcnKTsgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtjdXN0b21lcnMuZGF0YT8uZGF0YS5tYXAoY3VzdG9tZXIgPT4gPE1lbnVJdGVtIGtleT17Y3VzdG9tZXIuaWR9IHZhbHVlPXtjdXN0b21lci5pZH0+e2N1c3RvbWVyLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICA8TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJraMOhY2ggaMOgbmdcIiBsb2FkZWRDb3VudD17Y3VzdG9tZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtjdXN0b21lcnMuaGFzTW9yZX0gYnVzeT17Y3VzdG9tZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2N1c3RvbWVycy5sb2FkTW9yZX0gLz5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIsSQxqFuIGjDoG5nIGxpw6puIHF1YW4gKGtow7RuZyBi4bqvdCBideG7mWMpXCIgdmFsdWU9e29yZGVySWR9IGRpc2FibGVkPXshY3VzdG9tZXJJZCB8fCAhY2FuUmVhZE9yZGVycyB8fCByZWxhdGVkT3JkZXJzLmlzUGVuZGluZ30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldE9yZGVySWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gaGVscGVyVGV4dD17IWNhblJlYWRPcmRlcnMgPyAnVmFpIHRyw7IgbsOgeSBraMO0bmcgY8OzIHF1eeG7gW4geGVtIMSRxqFuOyBjw7MgdGjhu4MgdOG6oW8gecOqdSBj4bqndSBraMO0bmcgZ+G6r24gxJHGoW4uJyA6ICFjdXN0b21lcklkID8gJ0No4buNbiBraMOhY2ggaMOgbmcgdHLGsOG7m2MgxJHhu4MgbOG7jWMgxJHDum5nIMSRxqFuIGPhu6dhIGjhu40uJyA6IHJlbGF0ZWRPcmRlcnMuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIMSRxqFuIGPhu6dhIGtow6FjaCDEkcOjIGNo4buNbuKApicgOiByZWxhdGVkT3JkZXJzLmRhdGE/LmRhdGEubGVuZ3RoID8gJ0No4buJIGhp4buDbiB0aOG7iyDEkcahbiB0aHXhu5ljIGtow6FjaCBow6BuZyDEkcOjIGNo4buNbi4nIDogJ0tow7RuZyBjw7MgxJHGoW4gcGjDuSBo4bujcDsgY8OzIHRo4buDIHThuqFvIHnDqnUgY+G6p3Uga2jDtG5nIGfhuq9uIMSRxqFuLid9PlxuICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJcIj5LaMO0bmcgbGnDqm4ga+G6v3QgxJHGoW48L01lbnVJdGVtPlxuICAgICAgICAgICAgICAgICAgICB7cmVsYXRlZE9yZGVycy5kYXRhPy5kYXRhLm1hcChvcmRlciA9PiA8TWVudUl0ZW0ga2V5PXtvcmRlci5pZH0gdmFsdWU9e29yZGVyLmlkfT57b3JkZXIuaWR9IMK3IHtidXNpbmVzc0xhYmVsKG9yZGVyLm9yZGVyU3RhdGUpfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICB7Y3VzdG9tZXJJZCAmJiBjYW5SZWFkT3JkZXJzICYmIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cIsSRxqFuIGjDoG5nIGPhu6dhIGtow6FjaFwiIGxvYWRlZENvdW50PXtyZWxhdGVkT3JkZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtyZWxhdGVkT3JkZXJzLmhhc01vcmV9IGJ1c3k9e3JlbGF0ZWRPcmRlcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17cmVsYXRlZE9yZGVycy5sb2FkTW9yZX0gLz59XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJMb+G6oWkgecOqdSBj4bqndVwiIHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0S2luZChldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIGtpbmQpfT57WydxdWVzdGlvbicsICdjb21wbGFpbnQnLCAncmV0dXJuX3JlcXVlc3QnLCAnZGVsaXZlcnlfaXNzdWUnXS5tYXAoKHZhbHVlLCBpbmRleCkgPT4gPE1lbnVJdGVtIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+e1snQ8OidSBo4buPaScsICdLaGnhur91IG7huqFpJywgJ1nDqnUgY+G6p3UgdHLhuqMgaMOgbmcnLCAnVuG6pW4gxJHhu4EgZ2lhbyBow6BuZyddW2luZGV4XX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk7hu5lpIGR1bmdcIiBtdWx0aWxpbmUgbWluUm93cz17M30gdmFsdWU9e3N1bW1hcnl9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRTdW1tYXJ5KGxpbWl0Q29kZVBvaW50cyhldmVudC50YXJnZXQudmFsdWUsIDEwMDApKX0gIGhlbHBlclRleHQ9e2Ake2NvZGVQb2ludExlbmd0aChzdW1tYXJ5KX0vMTAwMGB9IC8+XG4gICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlnDqnUgY+G6p3UgY2jhu4kgxJHGsOG7o2MgbGnDqm4ga+G6v3QgduG7m2kgxJHGoW4gxJHDoyB04bqjaSB04burIGjhu5Mgc8ahIGtow6FjaCDEkWFuZyBjaOG7jW4uIFZp4buHYyB04bqhbyBjYXNlIGtow7RuZyB4w6FjIG5o4bqtbiDEkeG7lWkgdHLhuqMgaG/hurdjIGhvw6BuIHRp4buBbi48L0FsZXJ0PlxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICA8L0VkaXREaWFsb2c+XG4gICAgICAgIDxFZGl0RGlhbG9nIG9wZW49eyEhc2VsZWN0ZWR9IHRpdGxlPVwiQ+G6rXAgbmjhuq10IHnDqnUgY+G6p3VcIiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17Y2hhbmdlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshcmVhc29uLnRyaW0oKSB8fCBjaGFuZ2UucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFzZWxlY3RlZCkgcmV0dXJuO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBjaGFuZ2UuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2VsZWN0ZWQuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkLnZlcnNpb24sIHN0YXRlLCByZWFzb24gfSB9KTtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZChudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9XG4gICAgICAgIH19PkPhuq1wIG5o4bqtdDwvQnV0dG9uPn0+XG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2NoYW5nZS5lcnJvcn0gLz5cbiAgICAgICAgICAgIDxGb3JtRmllbGRzID5cbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeT57c2VsZWN0ZWQ/LnN1bW1hcnl9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZD8ub3JkZXJJZCAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9vcmRlcnMvJHtzZWxlY3RlZC5vcmRlcklkfWB9Pk3hu58gxJHGoW4ge3NlbGVjdGVkLm9yZGVySWR9PC9Sb3V0ZUxpbms+fVxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiVHLhuqFuZyB0aMOhaSBt4bubaVwiIHZhbHVlPXtzdGF0ZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFN0YXRlKGV2ZW50LnRhcmdldC52YWx1ZSBhcyB0eXBlb2Ygc3RhdGUpfT48TWVudUl0ZW0gdmFsdWU9XCJhc3NpZ25lZFwiPsSQw6MgcGjDom4gY8O0bmc8L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cInJlc29sdmVkXCI+xJDDoyBnaeG6o2kgcXV54bq/dDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiY2xvc2VkXCI+xJDDs25nIHnDqnUgY+G6p3U8L01lbnVJdGVtPjwvVGV4dEZpZWxkPlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJL4bq/dCBxdeG6oyAvIGzDvSBkb1wiIG11bHRpbGluZSBtaW5Sb3dzPXszfSB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVhc29uKGxpbWl0Q29kZVBvaW50cyhldmVudC50YXJnZXQudmFsdWUsIDEwMDApKX0gIC8+XG4gICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkPhuq1wIG5o4bqtdCBjYXNlIGtow7RuZyB04bqhbyBnaWFvIGThu4tjaCBob8OgbiB0aeG7gW4uIE7hur91IGPhuqduIMSR4buVaS90cuG6oywgeOG7rSBsw70gcXVhIHF1eSB0csOsbmggxJHGoW4gaMOgbmcgxJHGsOG7o2MgY+G6pXAgcXV54buBbi48L0FsZXJ0PlxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICA8L0VkaXREaWFsb2c+XG4gICAgPC8+O1xufVxuZnVuY3Rpb24gY3VzdG9tZXJTbmFwc2hvdChjdXN0b21lcjogQ3VzdG9tZXIpIHtcbiAgICByZXR1cm4geyB2ZXJzaW9uOiBjdXN0b21lci52ZXJzaW9uLCB2YWx1ZXM6IHsgZGlzcGxheU5hbWU6IGN1c3RvbWVyLmRpc3BsYXlOYW1lLCBwaG9uZTogY3VzdG9tZXIucGhvbmUgfHwgJycsIGVtYWlsOiBjdXN0b21lci5lbWFpbCB8fCAnJywgbm90ZXM6IGN1c3RvbWVyLm5vdGVzIHx8ICcnIH0sIGhpZGRlbjogY3VzdG9tZXIucmVkYWN0ZWRGaWVsZHMuZmlsdGVyKChrZXkpOiBrZXkgaXMga2V5b2YgQ3VzdG9tZXJGaWVsZHMgPT4gWydkaXNwbGF5TmFtZScsICdwaG9uZScsICdlbWFpbCcsICdub3RlcyddLmluY2x1ZGVzKGtleSkpIH07XG59XG5mdW5jdGlvbiBjdXN0b21lclBhdGNoKHZhbHVlczogUGFydGlhbDxDdXN0b21lckZpZWxkcz4sIHJlZGFjdGVkOiByZWFkb25seSBzdHJpbmdbXSk6IEN1c3RvbWVyV3JpdGVQYXRjaCB7IGNvbnN0IHBhdGNoOiBDdXN0b21lcldyaXRlUGF0Y2ggPSB7fTsgaWYgKHZhbHVlcy5kaXNwbGF5TmFtZSAhPT0gdW5kZWZpbmVkICYmICFyZWRhY3RlZC5pbmNsdWRlcygnZGlzcGxheU5hbWUnKSlcbiAgICBwYXRjaC5kaXNwbGF5TmFtZSA9IHZhbHVlcy5kaXNwbGF5TmFtZTsgaWYgKHZhbHVlcy5waG9uZSAhPT0gdW5kZWZpbmVkICYmICFyZWRhY3RlZC5pbmNsdWRlcygncGhvbmUnKSlcbiAgICBwYXRjaC5waG9uZSA9IHZhbHVlcy5waG9uZSB8fCBudWxsOyBpZiAodmFsdWVzLmVtYWlsICE9PSB1bmRlZmluZWQgJiYgIXJlZGFjdGVkLmluY2x1ZGVzKCdlbWFpbCcpKVxuICAgIHBhdGNoLmVtYWlsID0gdmFsdWVzLmVtYWlsIHx8IG51bGw7IGlmICh2YWx1ZXMubm90ZXMgIT09IHVuZGVmaW5lZCAmJiAhcmVkYWN0ZWQuaW5jbHVkZXMoJ25vdGVzJykpXG4gICAgcGF0Y2gubm90ZXMgPSB2YWx1ZXMubm90ZXM7IHJldHVybiBwYXRjaDsgfVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvY3VzdG9tZXJzL2luZGV4LnRzeCJ9