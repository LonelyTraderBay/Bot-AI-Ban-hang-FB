import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/orders/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react_jsx-dev-runtime.js?v=867dcec9"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
import { useListReturn } from "/src/shared/model/list-return.ts";
import { draftEqual, useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { markDraftClean, useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { ActionGroup, FieldGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport8_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react.js?v=867dcec9"; const useEffect = __vite__cjsImport8_react["useEffect"]; const useRef = __vite__cjsImport8_react["useRef"]; const useState = __vite__cjsImport8_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useNavigate, useParams, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/react-router-dom.js?v=afee4a3d";
import { Alert, Box, Button, Divider, IconButton, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@mui_material.js?v=aff9c5ca";
import DeleteOutlineRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@mui_icons-material_DeleteOutlineRounded.js?v=49666f65";
import AddRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30464-9f11591b-18f4-4c56-9578-7deff45393cb-customer-address-store-probe/deps/@mui_icons-material_AddRounded.js?v=9857dae0";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { codePointLength, limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, Amount, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
export function OrdersPage() {
  _s();
  const { shop } = useScope();
  const navigate = useNavigate();
  const list = useApi("listOrders", { query: useListQuery("listOrders") });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đơn hàng", subtitle: "Tách riêng trạng thái đơn, giao hàng và thanh toán.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.write", variant: "contained", onClick: () => navigate(`/s/${shop.id}/orders/new`), children: "Tạo đơn hàng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 38,
      columnNumber: 278
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 38,
      columnNumber: 177
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listOrders", placeholder: "Tìm mã đơn hoặc khách hàng…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 38,
        columnNumber: 433
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh sách đơn hàng", rows: list.data.data, rowKey: (o) => o.id, columns: [
          {
            key: "id",
            label: "Đơn hàng",
            render: (o) => /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: o.id }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 40,
                columnNumber: 65
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: dateTime(o.createdAt, shop.timezone) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 40,
                columnNumber: 147
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 40,
              columnNumber: 58
            }, this)
          },
          { key: "customer", label: "Khách", render: (o) => `Mã khách hàng: ${o.customerId}` },
          { key: "total", label: "Tổng tiền", align: "right", render: (o) => /* @__PURE__ */ jsxDEV(Amount, { value: o.total }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 42,
            columnNumber: 164
          }, this) },
          { key: "order", label: "Đơn", render: (o) => /* @__PURE__ */ jsxDEV(Status, { value: o.orderState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 42,
            columnNumber: 239
          }, this) },
          { key: "shipping", label: "Giao hàng", render: (o) => /* @__PURE__ */ jsxDEV(Status, { value: o.fulfillmentState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 42,
            columnNumber: 328
          }, this) },
          { key: "payment", label: "Tiền", render: (o) => /* @__PURE__ */ jsxDEV(Status, { value: o.paymentState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 42,
            columnNumber: 417
          }, this) },
          { key: "action", label: "", render: (o) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${o.id}`, children: "Xem đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 42,
            columnNumber: 497
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 38,
          columnNumber: 575
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 43,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 38,
        columnNumber: 573
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 38,
        columnNumber: 509
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 38,
      columnNumber: 426
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 38,
    columnNumber: 175
  }, this);
}
_s(OrdersPage, "NDjzLhZEE7thwqcFyvnuIvMo5ow=", false, function() {
  return [useScope, useNavigate, useApi, useListQuery];
});
_c = OrdersPage;
function DraftForm({
  initial,
  onSaved,
  onBusyChange
}) {
  _s2();
  const { shop } = useScope();
  const [params] = useSearchParams();
  const [created, setCreated] = useState(null);
  const resource = initial || created;
  const canReadCustomers = useCan("customers.read");
  const canReadProducts = useCan("catalog.read");
  const canReadConversations = useCan("conversations.read");
  const canWriteOrders = useCan("orders.write");
  const [customerSearch, setCustomerSearch] = useState("");
  const [productSearch, setProductSearch] = useState("");
  const customers = usePagedApi("listCustomers", { query: { q: customerSearch.trim() || void 0, limit: 20 } }, canReadCustomers);
  const products = usePagedApi("listProducts", { query: { q: productSearch.trim() || void 0, limit: 20 } }, canReadProducts);
  const create = useCommand("createOrder", ["listOrders"]);
  const update = useCommand("updateOrderDraft", ["getOrder", "listOrders"]);
  useEffect(() => {
    onBusyChange?.(create.pending || update.pending);
  }, [create.pending, update.pending, onBusyChange]);
  const initialNotes = typeof initial?.notes === "string" ? initial.notes : "";
  const [customerId, setCustomer] = useState(initial?.customerId || params.get("customerId") || ""), [conversationId, setConversation] = useState(initial?.conversationId || params.get("conversationId") || ""), [warehouse, setWarehouse] = useState(initial?.warehouseId || shop.defaultWarehouseId), [addressId, setAddress] = useState(initial?.shippingAddressId || ""), [method, setMethod] = useState(initial?.paymentMethod || "cod"), [notes, setNotes] = useState(initialNotes);
  const warehouses = usePagedApi("listWarehouses", { query: { status: "active", limit: 20 } }, useCan("inventory.read"));
  const addresses = usePagedApi("listCustomerAddresses", { path: { customerId }, query: { status: "active", limit: 20 } }, !!customerId && canReadCustomers);
  const conv = usePagedApi("listConversations", { query: { customerId: customerId || void 0, limit: 20 } }, canReadConversations && !!customerId);
  const [lines, setLines] = useState(initial?.lines.map((l) => ({ key: l.id, variantId: l.variantId, variantLabel: `${l.name} · ${l.sku}`, quantity: String(l.quantity) })) || [{ key: crypto.randomUUID(), variantId: "", variantLabel: "", quantity: "1" }]);
  const variants = products.data?.data.filter((p) => p.status === "active").flatMap((p) => p.variants.filter((v) => v.active).map((v) => ({ ...v, productName: p.name }))) || [];
  const lineQuantityError = (value) => value.length > 0 && (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > 1e6);
  const duplicateVariants = new Set(lines.map((l) => l.variantId).filter(Boolean)).size !== lines.filter((l) => l.variantId).length;
  const valid = !!customerId && !!warehouse.trim() && lines.length > 0 && lines.length <= 100 && lines.every((l) => l.variantId && !lineQuantityError(l.quantity)) && !duplicateVariants && codePointLength(notes) <= 2e3 && (initial !== void 0 || canReadCustomers && canReadProducts);
  const chooseVariant = (key, variantId) => {
    const selected = variants.find((v) => v.id === variantId);
    setLines((current2) => current2.map((line) => line.key === key ? { ...line, variantId, variantLabel: selected ? `${selected.productName} · ${selected.name} · ${selected.sku}` : line.variantLabel } : line));
  };
  const fresh = useApi("getOrder", { path: { orderId: resource?.id || "" } }, !!resource);
  const current = fresh.data && (!resource || fresh.data.data.version >= resource.version) ? fresh.data.data : resource;
  const values = { customerId, conversationId, warehouse, addressId, notes, lines: lines.map((line) => ({ variantId: line.variantId, quantity: line.quantity })) };
  const editor = useVersionedDraft({
    identity: `${shop.id}:order:${resource?.id || "new"}`,
    source: current ? orderSnapshot(current) : void 0,
    draft: values,
    apply: (value) => {
      setCustomer(value.customerId);
      setConversation(value.conversationId);
      setWarehouse(value.warehouse);
      setAddress(value.addressId);
      setNotes(value.notes);
      setLines((existing) => value.lines.map((line) => ({ ...line, key: existing.find((item) => item.variantId === line.variantId)?.key || crypto.randomUUID(), variantLabel: existing.find((item) => item.variantId === line.variantId)?.variantLabel || "" })));
    },
    refresh: () => fresh.refetch({ throwOnError: true })
  });
  const [creationBaseline] = useState(() => ({ ...values, addressId, method }));
  const bindDraft = useDraftForm(resource ? editor.dirty : !draftEqual(creationBaseline, { ...values, addressId, method }));
  const formRef = useRef(null);
  const save = async () => {
    try {
      const body = { customerId, conversationId: conversationId || null, warehouseId: warehouse, lines: lines.map((line) => ({ variantId: line.variantId, quantity: Number(line.quantity) })), notes };
      let response;
      if (resource) {
        const prepared = editor.prepare();
        if (!prepared) return;
        response = await update.execute({ path: { orderId: resource.id }, version: prepared.version, body: {
          ...prepared.patch.customerId !== void 0 ? { customerId: body.customerId } : {},
          ...prepared.patch.conversationId !== void 0 ? { conversationId: body.conversationId } : {},
          ...prepared.patch.warehouse !== void 0 ? { warehouseId: body.warehouseId } : {},
          ...prepared.patch.addressId !== void 0 ? { shippingAddressId: addressId || null } : {},
          ...prepared.patch.lines !== void 0 ? { lines: body.lines } : {},
          ...prepared.patch.notes !== void 0 ? { notes: body.notes } : {}
        } });
      } else response = await create.execute({ body: { ...body, paymentMethod: method, shippingAddressId: addressId || null } });
      const clean = editor.committed(orderSnapshot(response.data), values, `${shop.id}:order:${response.data.id}`);
      if (clean) {
        if (formRef.current) markDraftClean(formRef.current);
        onSaved(response.data);
      } else
        setCreated(response.data);
    } catch (error) {
      editor.failed(error);
    }
  };
  const selectedCustomer = customers.data?.data.find((customer) => customer.id === customerId);
  return /* @__PURE__ */ jsxDEV(Box, { component: "form", ref: (form) => {
    const element = form;
    formRef.current = element;
    bindDraft(element);
  }, onSubmit: (event) => {
    event.preventDefault();
    if (valid) void save();
  }, children: /* @__PURE__ */ jsxDEV(PageSections, { children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 113,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { customerId: "Khách hàng", conversationId: "Hội thoại", warehouse: "Kho xuất", addressId: "Địa chỉ giao hàng", notes: "Ghi chú", lines: "Dòng đơn hàng" }, busy: create.pending || update.pending }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 113,
      columnNumber: 61
    }, this),
    !canReadCustomers && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Bạn cần quyền customers.read để tìm và tạo đơn với khách hàng. Đơn nháp hiện có vẫn giữ nguyên mã khách." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 114,
      columnNumber: 31
    }, this),
    !canReadProducts && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Bạn cần quyền catalog.read để tìm và chọn sản phẩm cho đơn hàng." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 115,
      columnNumber: 30
    }, this),
    customers.isError && /* @__PURE__ */ jsxDEV(ErrorNotice, { error: customers.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 116,
      columnNumber: 31
    }, this),
    products.isError && /* @__PURE__ */ jsxDEV(ErrorNotice, { error: products.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 117,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Người mua và giao hàng", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm khách hàng", value: customerSearch, onChange: (e) => setCustomerSearch(e.target.value), disabled: !canReadCustomers, helperText: "Tìm qua listCustomers với q; chỉ chọn mã do API trả về." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 119,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khách hàng", value: customerId, onChange: (e) => {
        setCustomer(e.target.value);
        setConversation("");
        setAddress("");
      }, disabled: !canReadCustomers && !resource, required: canReadCustomers, helperText: canReadCustomers ? customers.isPending ? "Đang tải khách hàng…" : customers.data?.data.length === 0 ? "Không tìm thấy khách phù hợp." : !customerId ? "Chọn khách hàng để lưu đơn nháp." : void 0 : void 0, children: [
        customerId && !selectedCustomer && /* @__PURE__ */ jsxDEV(MenuItem, { value: customerId, children: [
          "Đang giữ mã khách: ",
          customerId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 121,
          columnNumber: 53
        }, this),
        customers.data?.data.map((customer) => /* @__PURE__ */ jsxDEV(MenuItem, { value: customer.id, children: customer.displayName }, customer.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 122,
          columnNumber: 57
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 120,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "khách hàng", loadedCount: customers.loadedCount, hasMore: customers.hasMore, busy: customers.isLoadingMore, onLoadMore: customers.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 124,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Hội thoại liên quan", value: conversationId, onChange: (e) => setConversation(e.target.value), disabled: !canReadConversations || !customerId, helperText: !canReadConversations ? "Không có quyền đọc hội thoại; liên kết hội thoại là tùy chọn." : void 0, children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Không liên kết" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 126,
          columnNumber: 17
        }, this),
        conv.data?.data.filter((conversation) => conversation.customerId === customerId).map((conversation) => /* @__PURE__ */ jsxDEV(MenuItem, { value: conversation.id, children: [
          conversation.displayName,
          " · ",
          conversation.id
        ] }, conversation.id, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 126,
          columnNumber: 165
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 125,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "hội thoại", loadedCount: conv.loadedCount, hasMore: conv.hasMore, busy: conv.isLoadingMore, onLoadMore: conv.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 128,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "start" }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kho xuất", value: warehouse, onChange: (e) => setWarehouse(e.target.value), fullWidth: true, disabled: create.pending || update.pending, sx: { flex: 1, minWidth: 0 }, children: [
          warehouse && !warehouses.data?.data.some((w) => w.id === warehouse) && /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouse, children: [
            "Đang giữ kho ",
            warehouse
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 131,
            columnNumber: 93
          }, this),
          warehouses.data?.data.map((w) => /* @__PURE__ */ jsxDEV(MenuItem, { value: w.id, children: [
            w.code,
            " · ",
            w.name
          ] }, w.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 132,
            columnNumber: 55
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 130,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Địa chỉ giao hàng", value: addressId, onChange: (e) => setAddress(e.target.value), fullWidth: true, disabled: !customerId || create.pending || update.pending, sx: { flex: 1, minWidth: 0 }, helperText: "Chỉ dùng địa chỉ thuộc khách đã chọn do API trả về; trường bị che vẫn được bảo vệ.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chưa chọn địa chỉ" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 135,
            columnNumber: 21
          }, this),
          addressId && !addresses.data?.data.some((a) => a.id === addressId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: addressId, children: [
            "Đang giữ địa chỉ ",
            addressId
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 136,
            columnNumber: 92
          }, this),
          addresses.data?.data.map((a) => /* @__PURE__ */ jsxDEV(MenuItem, { value: a.id, children: [
            a.label || `Địa chỉ ${a.id}`,
            " · ",
            a.recipient || "Người nhận đã che"
          ] }, a.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 137,
            columnNumber: 54
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 134,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 129,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: warehouses.error || addresses.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 140,
        columnNumber: 13
      }, this),
      addressId && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Thông tin địa chỉ giao hàng", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Địa chỉ đang chọn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 142,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { sx: { overflowWrap: "anywhere" }, children: addresses.data?.data.find((address) => address.id === addressId)?.label || addressId }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 143,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 141,
        columnNumber: 27
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "kho xuất", loadedCount: warehouses.loadedCount, hasMore: warehouses.hasMore, busy: warehouses.isLoadingMore, onLoadMore: warehouses.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 145,
        columnNumber: 13
      }, this),
      customerId && /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "địa chỉ giao hàng", loadedCount: addresses.loadedCount, hasMore: addresses.hasMore, busy: addresses.isLoadingMore, onLoadMore: addresses.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 146,
        columnNumber: 28
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Đơn xác nhận giữ snapshot địa chỉ của báo giá. Khi địa chỉ đổi trước xác nhận, cần lấy báo giá và khách đồng ý lại." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 147,
        columnNumber: 13
      }, this),
      resource || create.pending ? /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Thanh toán", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Thanh toán" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 149,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { sx: { overflowWrap: "anywhere" }, children: method === "cod" ? "Thu khi giao (COD)" : "Trả trước, cần xác minh tiền" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 150,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 148,
        columnNumber: 43
      }, this) : /* @__PURE__ */ jsxDEV(TextField, { label: "Thanh toán", select: true, value: method, onChange: (e) => setMethod(e.target.value), children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "cod", children: "Thu khi giao (COD)" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 151,
          columnNumber: 142
        }, this),
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "prepay", children: "Trả trước, cần xác minh tiền" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 151,
          columnNumber: 193
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 151,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 118,
      columnNumber: 64
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 118,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Sản phẩm đặt mua", bodyMode: "inset", subtitle: "Bộ chọn tìm kiếm từ API; giá và tồn kho chỉ được chốt khi lấy báo giá.", action: /* @__PURE__ */ jsxDEV(Button, { startIcon: /* @__PURE__ */ jsxDEV(AddRounded, {}, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 153,
      columnNumber: 167
    }, this), disabled: lines.length >= 100, onClick: () => setLines((current2) => [...current2, { key: crypto.randomUUID(), variantId: "", variantLabel: "", quantity: "1" }]), children: "Thêm dòng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 153,
      columnNumber: 148
    }, this), children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm sản phẩm hoặc SKU", value: productSearch, onChange: (e) => setProductSearch(e.target.value), disabled: !canReadProducts, helperText: "Tìm từ listProducts với q; biến thể không hoạt động không được chọn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 155,
        columnNumber: 17
      }, this),
      lines.map((line, index) => {
        const selectedVariant = variants.find((variant) => variant.id === line.variantId);
        const quantityInvalid = lineQuantityError(line.quantity);
        return /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: `Sản phẩm ${index + 1}`, select: true, fullWidth: true, value: line.variantId, disabled: !canReadProducts && !resource, onChange: (event) => chooseVariant(line.key, event.target.value), error: duplicateVariants && !!line.variantId, helperText: duplicateVariants && line.variantId ? "Không thêm cùng một biến thể hai lần; hãy gộp số lượng vào một dòng." : void 0, children: [
            line.variantId && !selectedVariant && /* @__PURE__ */ jsxDEV(MenuItem, { value: line.variantId, children: line.variantLabel || `Đang giữ biến thể: ${line.variantId}` }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 161,
              columnNumber: 68
            }, this),
            variants.map((variant) => /* @__PURE__ */ jsxDEV(MenuItem, { value: variant.id, disabled: lines.some((other) => other.key !== line.key && other.variantId === variant.id), children: [
              variant.productName,
              " · ",
              variant.name,
              " · ",
              variant.sku
            ] }, variant.id, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 162,
              columnNumber: 56
            }, this)),
            canReadProducts && !products.isPending && variants.length === 0 && !line.variantId && /* @__PURE__ */ jsxDEV(MenuItem, { disabled: true, value: "", children: "Không tìm thấy sản phẩm/biến thể phù hợp" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 163,
              columnNumber: 116
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 160,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Số lượng", value: line.quantity, onChange: (event) => setLines((current2) => current2.map((item) => item.key === line.key ? { ...item, quantity: event.target.value } : item)), error: quantityInvalid, helperText: quantityInvalid ? "Nhập số nguyên từ 1 đến 1.000.000." : "Số lượng nguyên theo hợp đồng.", inputProps: { inputMode: "numeric", "aria-invalid": quantityInvalid }, sx: { minWidth: 100, maxWidth: { sm: 180 } } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 165,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(IconButton, { "aria-label": `Bỏ dòng ${index + 1}`, disabled: lines.length === 1, sx: { alignSelf: "start" }, onClick: () => setLines((current2) => current2.filter((item) => item.key !== line.key)), children: /* @__PURE__ */ jsxDEV(DeleteOutlineRounded, {}, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 166,
            columnNumber: 218
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 166,
            columnNumber: 25
          }, this)
        ] }, line.key, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 159,
          columnNumber: 20
        }, this);
      }),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "sản phẩm", loadedCount: products.loadedCount, hasMore: products.hasMore, busy: products.isLoadingMore, onLoadMore: products.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 169,
        columnNumber: 17
      }, this),
      lines.length >= 100 && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Đơn nháp đạt giới hạn 100 dòng theo hợp đồng." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 170,
        columnNumber: 41
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Tổng tiền và khả năng giữ hàng được tính lại bởi API khi lấy báo giá và xác nhận; không tin tổng do trình duyệt tự tính." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 171,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Ghi chú chuẩn bị", value: notes, onChange: (e) => setNotes(limitCodePoints(e.target.value, 2e3)), error: codePointLength(notes) > 2e3, helperText: `${codePointLength(notes)}/2.000 ký tự`, multiline: true, minRows: 2 }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 172,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 154,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 153,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.write", variant: "contained", busy: create.pending || update.pending, disabled: !valid || !canWriteOrders, type: "submit", children: "Lưu đơn nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 175,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 112,
    columnNumber: 214
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 112,
    columnNumber: 10
  }, this);
}
_s2(DraftForm, "czMBwC7qRnQ5hWcUgKnJGCk9aC0=", false, function() {
  return [useScope, useSearchParams, useCan, useCan, useCan, useCan, usePagedApi, usePagedApi, useCommand, useCommand, usePagedApi, useCan, usePagedApi, usePagedApi, useApi, useVersionedDraft, useDraftForm];
});
_c2 = DraftForm;
export function NewOrderPage() {
  _s3();
  const { shop } = useScope();
  const navigate = useNavigate();
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Tạo đơn hàng", subtitle: "Lưu nháp trước, sau đó báo giá và xác nhận khách.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders`, children: "Danh sách đơn" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 178,
      columnNumber: 210
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 178,
      columnNumber: 107
    }, this),
    /* @__PURE__ */ jsxDEV(DraftForm, { onSaved: (o) => navigate(`/s/${shop.id}/orders/${o.id}`) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 178,
      columnNumber: 278
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 178,
    columnNumber: 105
  }, this);
}
_s3(NewOrderPage, "hp3ZU8yOORiLpoTkzn9SYnIlGwc=", false, function() {
  return [useScope, useNavigate];
});
_c3 = NewOrderPage;
export function OrderDetailPage({
  simulateCustomerConfirmation
}) {
  _s4();
  const { orderId = "" } = useParams();
  const { shop } = useScope();
  const listHref = useListReturn(`/s/${shop.id}/orders`);
  const get = useApi("getOrder", { path: { orderId } });
  const order = get.data?.data;
  const quoteOp = useCommand("quoteOrder", ["getOrder"]);
  const record = useCommand("recordCustomerConfirmation", []);
  const confirm = useCommand("confirmOrder", ["getOrder", "listOrders", "listStockSnapshots", "getDashboard", "listWorkItems", "listNotifications", "listPrepJobs"]);
  const cancel = useCommand("cancelOrder", ["getOrder", "listOrders", "listStockSnapshots", "listWorkItems", "listPrepJobs"]);
  const pay = useCommand("payOrder", ["getOrder", "listOrders", "getCashflow", "listFinanceEntries"]);
  const refund = useCommand("refundOrder", ["getOrder", "listOrders", "getCashflow"]);
  const [quote, setQuote] = useState(null), [confirmation, setConfirmation] = useState(null), [editing, setEditing] = useState(false), [action, setAction] = useState(null), [error, setError] = useState(null);
  const [editBusy, setEditBusy] = useState(false);
  const [hash, setHash] = useState(""), [identity, setIdentity] = useState(""), [messageId, setMessage] = useState(""), [amount, setAmount] = useState(""), [reference, setReference] = useState(""), [evidenceRef, setEvidence] = useState(""), [reason, setReason] = useState("");
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [serverOffsetMs, setServerOffsetMs] = useState(0);
  const synchronizeApiTime = (asOf) => {
    const apiTime = Date.parse(asOf);
    if (Number.isFinite(apiTime))
      setServerOffsetMs(apiTime - nowMs);
  };
  useEffect(() => {
    if (!quote)
      return;
    const timer = window.setInterval(() => setNowMs(Date.now()), 1e3);
    return () => window.clearInterval(timer);
  }, [quote]);
  const effectiveNowMs = nowMs + serverOffsetMs;
  const quoteExpired = !!quote && Date.parse(quote.expiresAt) <= effectiveNowMs;
  const confirmationExpired = !!confirmation && (confirmation.status !== "valid" || Date.parse(confirmation.expiresAt) <= effectiveNowMs);
  useEffect(() => {
    if (order && quote && order.version !== quote.orderVersion) {
      setQuote(null);
      setConfirmation(null);
    }
  }, [order, quote]);
  const collect = async () => {
    if (!quote)
      return;
    try {
      const r = await record.execute({ path: { orderId }, body: { quoteId: quote.id, quoteHash: hash, quoteVersion: quote.orderVersion, customerIdentityId: identity, sourceMessageId: messageId } });
      synchronizeApiTime(r.meta.asOf);
      setConfirmation(r.data);
      setAction(null);
    } catch {
    }
  };
  const mockConfirm = async () => {
    if (!quote || !simulateCustomerConfirmation)
      return;
    try {
      const evidence = await simulateCustomerConfirmation(shop.id, quote.id);
      setHash(evidence.quoteHash);
      setIdentity(evidence.customerIdentityId);
      setMessage(evidence.sourceMessageId);
      const r = await record.execute({ path: { orderId }, body: evidence });
      synchronizeApiTime(r.meta.asOf);
      setConfirmation(r.data);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không tạo được bằng chứng mẫu"));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: `Đơn ${orderId}`, subtitle: "Mọi thay đổi quan trọng kiểm lại phiên bản và điều kiện nghiệp vụ.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: listHref, children: "Danh sách đơn" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 237,
      columnNumber: 136
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 237,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: get, pendingProfile: "section", children: order && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || quoteOp.error || record.error || confirm.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 238,
        columnNumber: 2
      }, this),
      editing ? /* @__PURE__ */ jsxDEV(EditDialog, { allowEditsWhileBusy: true, open: true, title: "Sửa đơn nháp", busy: editBusy, onClose: () => setEditing(false), actions: ({ requestClose, busy }) => /* @__PURE__ */ jsxDEV(Button, { disabled: busy, onClick: requestClose, children: "Đóng chỉnh sửa" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 238,
        columnNumber: 237
      }, this), children: /* @__PURE__ */ jsxDEV(DraftForm, { initial: order, onBusyChange: setEditBusy, onSaved: () => {
        setEditBusy(false);
        setEditing(false);
        setQuote(null);
        setConfirmation(null);
      } }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 238,
        columnNumber: 309
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 238,
        columnNumber: 92
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", afterGap: "section", children: [
          /* @__PURE__ */ jsxDEV(Status, { value: order.orderState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 239,
            columnNumber: 50
          }, this),
          /* @__PURE__ */ jsxDEV(Status, { value: order.fulfillmentState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 239,
            columnNumber: 85
          }, this),
          /* @__PURE__ */ jsxDEV(Status, { value: order.paymentState }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 239,
            columnNumber: 126
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { alignSelf: "center" }, children: [
            "Phiên bản ",
            order.version
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 239,
            columnNumber: 163
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 239,
          columnNumber: 2
        }, this),
        /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "2fr 1fr" }, children: [
          /* @__PURE__ */ jsxDEV(Panel, { title: "Sản phẩm trong đơn", children: [
            /* @__PURE__ */ jsxDEV(DataTable, { label: "Sản phẩm trong đơn", rows: order.lines, rowKey: (l) => l.id, columns: [
              {
                key: "name",
                label: "Sản phẩm / SKU",
                render: (l) => /* @__PURE__ */ jsxDEV(Stack, { children: [
                  /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: l.name }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                    lineNumber: 242,
                    columnNumber: 77
                  }, this),
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: l.sku }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                    lineNumber: 242,
                    columnNumber: 161
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                  lineNumber: 242,
                  columnNumber: 70
                }, this)
              },
              { key: "qty", label: "Số lượng", align: "right", render: (l) => l.quantity },
              { key: "price", label: "Đơn giá", align: "right", render: (l) => /* @__PURE__ */ jsxDEV(Amount, { value: l.unitPrice }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 244,
                columnNumber: 158
              }, this) },
              { key: "total", label: "Thành tiền", align: "right", render: (l) => /* @__PURE__ */ jsxDEV(Amount, { value: l.lineTotal }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 244,
                columnNumber: 260
              }, this) }
            ] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 240,
              columnNumber: 88
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.surface.inset, { textAlign: "right" }], children: [
              /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Tổng từ API" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 245,
                columnNumber: 78
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: order.total }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 245,
                columnNumber: 162
              }, this) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 245,
                columnNumber: 137
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 240,
            columnNumber: 54
          }, this),
          /* @__PURE__ */ jsxDEV(Panel, { title: "Thông tin xử lý", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khách", children: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/customers/${order.customerId}`, children: [
              "Mã khách hàng: ",
              order.customerId
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 303
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 277
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kho", children: [
              "Mã kho: ",
              order.warehouseId
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 423
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Địa chỉ", children: order.shippingAddressSnapshot ? [order.shippingAddressSnapshot.label, order.shippingAddressSnapshot.recipient, order.shippingAddressSnapshot.line1, order.shippingAddressSnapshot.province].filter(Boolean).join(" · ") : order.shippingAddressId ? `Mã địa chỉ: ${order.shippingAddressId}` : "Chưa có địa chỉ được xác minh" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 487
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Thanh toán", children: order.paymentMethod === "cod" ? "COD" : "Trả trước" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 848
            }, this),
            order.conversationId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/inbox/${order.conversationId}`, children: "Mở hội thoại" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 970
            }, this),
            order.prepTaskId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/fulfillment`, children: "Chuẩn bị đơn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 245,
              columnNumber: 1078
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 245,
            columnNumber: 272
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 245,
            columnNumber: 224
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 240,
          columnNumber: 2
        }, this),
        /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "form", children: [
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.write", allowedActions: order.allowedActions, action: "edit", onClick: () => setEditing(true), children: "Sửa đơn nháp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 246,
            columnNumber: 48
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.write", allowedActions: order.allowedActions, action: "quote", variant: "contained", busy: quoteOp.pending, onClick: async () => {
            try {
              const r = await quoteOp.execute({ path: { orderId }, version: order.version });
              synchronizeApiTime(r.meta.asOf);
              setQuote(r.data);
              setConfirmation(null);
              setHash(typeof r.data.quoteHash === "string" ? r.data.quoteHash : "");
            } catch {
            }
          }, children: "Lấy báo giá hiện tại" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 246,
            columnNumber: 204
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.write", allowedActions: order.allowedActions, action: "cancel", color: "error", onClick: () => setAction("cancel"), children: "Hủy đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 253,
            columnNumber: 83
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", allowedActions: order.allowedActions, action: "record_payment", onClick: () => {
            setAmount(order.total?.amount || "");
            setReason("");
            setReference("");
            setEvidence("");
            setAction("pay");
          }, children: "Ghi nhận tiền đã thu" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 253,
            columnNumber: 253
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.refund", allowedActions: order.allowedActions, action: "request_refund", onClick: () => {
            setAmount("");
            setReason("");
            setReference("");
            setEvidence("");
            setAction("refund");
          }, children: "Ghi nhận khoản đã hoàn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 253,
            columnNumber: 514
          }, this),
          order.allowedActions.includes("request_return") && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/returns?orderId=${order.id}`, children: "Tạo yêu cầu trả hàng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 253,
            columnNumber: 811
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 246,
          columnNumber: 2
        }, this),
        quote && /* @__PURE__ */ jsxDEV(Panel, { title: "Báo giá và xác nhận khách", subtitle: `Bản đơn ${quote.orderVersion} · Hết hạn ${dateTime(quote.expiresAt, shop.timezone)}`, bodyMode: "inset", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.query.stateGap, children: [
          /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: quote.total }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 248
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 223
          }, this),
          quote.warnings.map((w, i) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: w }, i, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 326
          }, this)),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
            "Mã báo giá: ",
            quote.id
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 370
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { overflowWrap: "anywhere" }, children: [
            "Hash do server cung cấp: ",
            hash || "Chưa có. Backend phải cung cấp hash và bằng chứng khách trước khi chốt."
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 433
          }, this),
          quoteExpired && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Báo giá đã hết hạn. Lấy báo giá mới và xác nhận lại với khách trước khi chốt." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 635
          }, this),
          confirmation ? /* @__PURE__ */ jsxDEV(Alert, { severity: confirmationExpired ? "warning" : "success", children: confirmationExpired ? "Bằng chứng khách đã hết hạn hoặc bị thay thế. Cần ghi nhận xác nhận cho báo giá hiện tại." : `Đã ghi nhận bằng chứng ${confirmation.id}. Xác nhận lại giá/tồn khi chốt đơn.` }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 763
          }, this) : /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setAction("evidence"), children: "Nhập bằng chứng xác nhận khách" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 254,
              columnNumber: 1062
            }, this),
            simulateCustomerConfirmation && /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", disabled: record.pending, onClick: () => void mockConfirm(), children: "Mô phỏng khách đồng ý báo giá" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 254,
              columnNumber: 1180
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 1033
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.confirm", allowedActions: order.allowedActions, action: "confirm", variant: "contained", disabled: !confirmation || quoteExpired || confirmationExpired, busy: confirm.pending, onClick: async () => {
            if (!confirmation || quoteExpired || confirmationExpired)
              return;
            try {
              await confirm.execute({
                path: { orderId },
                version: order.version,
                body: { expectedVersion: order.version, quoteId: quote.id, customerConfirmationId: confirmation.id }
              });
              setQuote(null);
              setConfirmation(null);
            } catch {
            }
          }, children: "Xác nhận đơn & giữ hàng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 254,
            columnNumber: 1322
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 254,
          columnNumber: 187
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 254,
          columnNumber: 12
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 238,
        columnNumber: 474
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 237,
      columnNumber: 249
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 237,
      columnNumber: 190
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: action === "cancel", title: "Hủy đơn hàng", confirmLabel: "Hủy đơn hàng", description: `Đơn ${orderId}: hủy xử lý mới và giải phóng lượng hàng giữ khi đủ điều kiện. Lịch sử và chứng từ đã ghi được giữ; tác động đã tiếp nhận phải được đối chiếu.`, requireReason: true, onClose: () => setAction(null), busy: cancel.pending, error: cancel.error, onConfirm: (reason2) => cancel.execute({ path: { orderId }, version: order?.version, body: { expectedVersion: order?.version || 1, reason: reason2 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 264,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: action === "evidence", title: "Bằng chứng xác nhận từ khách", onClose: () => setAction(null), busy: record.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !/^[a-f0-9]{64}$/.test(hash) || !identity || !messageId || record.pending, onClick: () => void collect(), children: "Ghi nhận bằng chứng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 265,
      columnNumber: 143
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: record.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 265,
        columnNumber: 317
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không dùng lời AI “khách đã đồng ý” để xác nhận. Cần định danh và tin nhắn khách thực sự xác nhận đúng báo giá." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 265,
          columnNumber: 365
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Hash báo giá từ backend", value: hash, onChange: (e) => setHash(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 265,
          columnNumber: 510
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Định danh khách", value: identity, onChange: (e) => setIdentity(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 265,
          columnNumber: 610
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã tin nhắn xác nhận", value: messageId, onChange: (e) => setMessage(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 265,
          columnNumber: 710
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 265,
        columnNumber: 353
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 265,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: action === "pay" || action === "refund", title: action === "pay" ? "Ghi nhận tiền đã thu" : "Ghi nhận tiền đã hoàn", onClose: () => setAction(null), busy: pay.pending || refund.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !/^\d+(\.\d{1,4})?$/.test(amount) || !evidenceRef || !reference || codePointLength(reason.trim()) < 5 || pay.pending || refund.pending, onClick: async () => {
      if (!order)
        return;
      try {
        if (action === "pay")
          await pay.execute({
            path: { orderId },
            version: order.version,
            body: {
              expectedVersion: order.version,
              amount: { amount, currency: shop.currency },
              method: "bank_transfer",
              reference,
              reason,
              evidenceRef
            }
          });
        else
          await refund.execute({
            path: { orderId },
            version: order.version,
            body: { expectedVersion: order.version, amount: { amount, currency: shop.currency }, reason, paymentReference: reference, evidenceRef }
          });
        setAction(null);
      } catch {
      }
    }, children: "Ghi nhận chứng từ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 266,
      columnNumber: 215
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: pay.error || refund.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 280,
        columnNumber: 59
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Chỉ ghi khoản đã được xác minh. Nút này không chuyển tiền. Ảnh chuyển khoản chưa xác thực không là bằng chứng thanh toán." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 280,
          columnNumber: 120
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Số tiền (${shop.currency})`, value: amount, onChange: (e) => setAmount(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 280,
          columnNumber: 275
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã tham chiếu giao dịch", value: reference, onChange: (e) => setReference(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 280,
          columnNumber: 384
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã chứng từ đã xác minh", value: evidenceRef, onChange: (e) => setEvidence(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 280,
          columnNumber: 494
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (e) => setReason(e.target.value), multiline: true, minRows: 2 }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 280,
          columnNumber: 605
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 280,
        columnNumber: 108
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 266,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 237,
    columnNumber: 10
  }, this);
}
_s4(OrderDetailPage, "IR8Y6R9Tlf0b70ybMJaWbSBgB1I=", false, function() {
  return [useParams, useScope, useListReturn, useApi, useCommand, useCommand, useCommand, useCommand, useCommand, useCommand];
});
_c4 = OrderDetailPage;
export function ReturnsPage() {
  _s5();
  const { shop } = useScope();
  const [params] = useSearchParams();
  const canReadOrders = useCan("orders.read");
  const canCreateReturn = useCan("orders.return");
  const canInspectReturn = useCan("inventory.adjust");
  const list = useApi("listReturnCases", { query: useListQuery("listReturnCases") });
  const [orderSearchInput, setOrderSearchInput] = useState("");
  const [orderSearch, setOrderSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setOrderSearch(orderSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [orderSearchInput]);
  const orders = usePagedApi("listOrders", { query: { q: orderSearch || void 0 } }, canReadOrders);
  const create = useCommand("createReturnCase", ["listReturnCases"]);
  const inspect = useCommand("inspectReturn", ["listReturnCases", "getReturnCase", "listStockSnapshots", "getProfitLoss"]);
  const [open, setOpen] = useState(false), [orderId, setOrder] = useState(params.get("orderId") || ""), [reason, setReason] = useState(""), [quantities, setQuantities] = useState({});
  const selectedOrderDetail = useApi("getOrder", { path: { orderId } }, canReadOrders && !!orderId);
  const selectedOrder = orders.data?.data.find((order) => order.id === orderId) || selectedOrderDetail.data?.data;
  const [selected, setSelected] = useState(null), [inspections, setInspections] = useState([]);
  const selectedReturn = useApi("getReturnCase", { path: { resourceId: selected?.id || "" } }, !!selected && canReadOrders);
  const inspectionCase = selectedReturn.data?.data;
  const inspectionEditor = useVersionedDraft({
    identity: `${shop.id}:return:${selected?.id || "none"}`,
    source: selected && inspectionCase?.id === selected.id ? returnInspectionSnapshot(inspectionCase) : void 0,
    draft: { lines: inspections },
    apply: (values) => setInspections(values.lines),
    refresh: () => selectedReturn.refetch({ throwOnError: true })
  });
  const detailsReady = !!selected && !!inspectionCase && inspectionCase.id === selected.id && inspectionEditor.baseline?.identity === `${shop.id}:return:${selected.id}`;
  const editInspection = (r) => {
    setSelected(r);
    setInspections([]);
  };
  const requestedLines = selectedOrder?.lines.map((line) => {
    const quantity = quantities[line.id] ?? "0";
    return {
      orderLineId: line.id,
      quantity,
      invalid: quantity !== "0" && (!/^\d+$/.test(quantity) || Number(quantity) < 1 || Number(quantity) > line.quantity)
    };
  }).filter((line) => line.quantity !== "0") || [];
  const createInvalid = !selectedOrder || !["delivered", "part_returned"].includes(selectedOrder.fulfillmentState) || !reason.trim() || codePointLength(reason) > 1e3 || requestedLines.length === 0 || requestedLines.some((line) => line.invalid);
  const inspectionInvalid = !detailsReady || !inspectionCase || inspections.length === 0 || inspections.some((line) => {
    const returned = inspectionCase.lines.find((item) => item.orderLineId === line.orderLineId)?.quantity ?? 0;
    return !Number.isInteger(line.acceptedQuantity) || line.acceptedQuantity < 0 || line.acceptedQuantity > returned || !line.reason.trim() || codePointLength(line.reason) > 1e3;
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đổi và trả hàng", subtitle: "Nhận lại, kiểm tình trạng, xác định nghĩa vụ hoàn. Không tự cộng hàng chưa kiểm vào tồn bán.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "orders.return", variant: "contained", disabled: !canReadOrders, onClick: () => setOpen(true), children: "Tạo yêu cầu trả" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 326,
      columnNumber: 158
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 326,
      columnNumber: 9
    }, this),
    !canReadOrders && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Cần quyền orders.read để chọn đơn gốc và xử lý yêu cầu trả." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 327,
      columnNumber: 28
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listReturnCases" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 328,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu đổi trả", rows: list.data.data, rowKey: (r) => r.id, columns: [
          { key: "id", label: "Yêu cầu", render: (r) => r.id },
          { key: "order", label: "Đơn gốc", render: (r) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${r.orderId}`, children: r.orderId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 330,
            columnNumber: 60
          }, this) },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.state, domain: "return" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 331,
            columnNumber: 63
          }, this) },
          { key: "refund", label: "Nghĩa vụ hoàn", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.refundObligation }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 332,
            columnNumber: 67
          }, this) },
          { key: "action", label: "", render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "inventory.adjust", disabled: !canInspectReturn || ["inspected", "closed", "rejected"].includes(r.state), onClick: () => editInspection(r), children: "Kiểm nhận" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 333,
            columnNumber: 54
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 328,
          columnNumber: 121
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 334,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 328,
        columnNumber: 119
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 328,
        columnNumber: 55
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 328,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Yêu cầu trả hàng", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: createInvalid || !canReadOrders || !canCreateReturn || create.pending, onClick: async () => {
      try {
        await create.execute({ body: { orderId, reason: reason.trim(), lines: requestedLines.map((line) => ({ orderLineId: line.orderLineId, quantity: Number(line.quantity) })) } });
        setOpen(false);
        setQuantities({});
      } catch {
      }
    }, children: "Tạo yêu cầu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 335,
      columnNumber: 120
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 343,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        !canReadOrders && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không có quyền đọc danh sách đơn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 345,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm đơn hàng", value: orderSearchInput, onChange: (event) => setOrderSearchInput(event.target.value), disabled: !canReadOrders, helperText: "Tìm theo mã đơn hoặc khách hàng; truy vấn tìm kiếm do API hỗ trợ." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 347,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Đơn hàng đã giao", select: true, value: orderId, onChange: (event) => {
          setOrder(event.target.value);
          setQuantities({});
        }, disabled: !canReadOrders || orders.isPending && !orders.data, helperText: "Chỉ đơn đã giao hoặc đang trả một phần. API kiểm tra tổng số lượng còn được trả.", children: [
          orderId && !orders.data?.data.some((order) => order.id === orderId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: orderId, children: selectedOrder?.id || (selectedOrderDetail.isPending ? "Đang tải đơn đã chọn…" : orderId) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 349,
            columnNumber: 93
          }, this),
          orders.data?.data.filter((order) => ["delivered", "part_returned"].includes(order.fulfillmentState)).map((order) => /* @__PURE__ */ jsxDEV(MenuItem, { value: order.id, children: order.id }, order.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 350,
            columnNumber: 138
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 348,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "đơn hàng", loadedCount: orders.loadedCount, hasMore: orders.hasMore, busy: orders.isLoadingMore, onLoadMore: orders.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 352,
          columnNumber: 17
        }, this),
        orders.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: orders.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 353,
            columnNumber: 48
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (orders.isFetchNextPageError ? orders.loadMore() : orders.refetch());
          }, children: "Thử lại danh sách đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 353,
            columnNumber: 84
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 353,
          columnNumber: 36
        }, this),
        selectedOrderDetail.isError && /* @__PURE__ */ jsxDEV(ErrorNotice, { error: selectedOrderDetail.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 354,
          columnNumber: 49
        }, this),
        selectedOrder?.lines.map((line) => {
          const field = requestedLines.find((item) => item.orderLineId === line.id);
          return /* @__PURE__ */ jsxDEV(TextField, { label: `${line.name} (tối đa ${line.quantity})`, type: "number", inputProps: { min: 0, max: line.quantity, step: 1 }, value: quantities[line.id] ?? "0", error: !!field?.invalid, helperText: field?.invalid ? `Nhập số nguyên từ 1 đến ${line.quantity}; API kiểm tra các yêu cầu trả trước đó.` : `Số lượng gốc ${line.quantity}; giới hạn còn lại do API quyết định.`, onChange: (event) => setQuantities((current) => ({ ...current, [line.id]: event.target.value })) }, line.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 357,
            columnNumber: 18
          }, this);
        }),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do trả", multiline: true, value: reason, onChange: (event) => setReason(event.target.value), error: !reason.trim() || codePointLength(reason) > 1e3, helperText: `${codePointLength(reason)}/1.000 ký tự` }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 359,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 344,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 335,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { allowEditsWhileBusy: true, open: !!selected, title: "Kiểm nhận hàng trả", onClose: () => {
      setSelected(null);
      setInspections([]);
    }, busy: inspect.pending, actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "inventory.adjust", variant: "contained", disabled: inspectionInvalid || !canInspectReturn, busy: inspect.pending, onClick: async () => {
      if (!selected || !inspectionCase || inspectionInvalid)
        return;
      try {
        const prepared = inspectionEditor.prepare();
        if (!prepared) return;
        const submitted = { lines: inspections };
        const result = await inspect.execute({ path: { resourceId: inspectionCase.id }, body: { expectedVersion: prepared.version, lines: inspections } });
        const persisted = { version: result.data.version, values: submitted };
        if (inspectionEditor.committed(persisted, submitted)) {
          setSelected(null);
          setInspections([]);
        }
      } catch (error) {
        inspectionEditor.failed(error);
      }
    }, children: "Xác nhận kiểm nhận" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 362,
      columnNumber: 174
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: inspect.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 374,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor: inspectionEditor, labels: { lines: "Phương án kiểm nhận từ hồ sơ trả hàng" }, busy: inspect.pending }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 375,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Người thật xác nhận đã nhận và kiểm hàng. Chỉ “Bán lại được” mới được bổ sung tồn khả dụng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 377,
          columnNumber: 17
        }, this),
        selectedReturn.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải hồ sơ trả hàng mới nhất…" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 378,
          columnNumber: 46
        }, this),
        selectedReturn.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: selectedReturn.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 379,
            columnNumber: 56
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => {
            void selectedReturn.refetch();
          }, children: "Tải lại hồ sơ" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 379,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
          lineNumber: 379,
          columnNumber: 44
        }, this),
        detailsReady && inspections.map((line, index) => {
          const returnedQuantity = inspectionCase.lines.find((item) => item.orderLineId === line.orderLineId)?.quantity ?? 0;
          const invalidQuantity = !Number.isInteger(line.acceptedQuantity) || line.acceptedQuantity < 0 || line.acceptedQuantity > returnedQuantity;
          return /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { children: line.orderLineId }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 384,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Số lượng nhận", type: "number", inputProps: { min: 0, max: returnedQuantity, step: 1 }, value: Number.isNaN(line.acceptedQuantity) ? "" : line.acceptedQuantity, error: invalidQuantity, helperText: invalidQuantity ? `Nhập số nguyên từ 0 đến ${returnedQuantity}.` : `Tối đa ${returnedQuantity} theo yêu cầu trả.`, onChange: (event) => setInspections((current) => current.map((item, row) => index === row ? { ...item, acceptedQuantity: event.target.value === "" ? Number.NaN : Number(event.target.value) } : item)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 385,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Tình trạng", value: line.disposition, onChange: (event) => setInspections((current) => current.map((item, row) => index === row ? { ...item, disposition: event.target.value } : item)), children: [
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "quarantined", children: "Cách ly / chờ xác minh" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 386,
                columnNumber: 261
              }, this),
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "sellable", children: "Bán lại được" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 386,
                columnNumber: 324
              }, this),
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "damaged", children: "Hư hỏng" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
                lineNumber: 386,
                columnNumber: 374
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 386,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Ghi nhận kiểm tra", value: line.reason, error: !line.reason.trim() || codePointLength(line.reason) > 1e3, helperText: `${codePointLength(line.reason)}/1.000 ký tự`, onChange: (event) => setInspections((current) => current.map((item, row) => index === row ? { ...item, reason: event.target.value } : item)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 387,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Divider, {}, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
              lineNumber: 388,
              columnNumber: 25
            }, this)
          ] }, line.orderLineId, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
            lineNumber: 383,
            columnNumber: 18
          }, this);
        })
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
        lineNumber: 376,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
      lineNumber: 362,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx",
    lineNumber: 325,
    columnNumber: 10
  }, this);
}
_s5(ReturnsPage, "tQSAeycNEPHM/Zd27URy5KzgL3w=", false, function() {
  return [useScope, useSearchParams, useCan, useCan, useCan, useApi, useListQuery, usePagedApi, useCommand, useCommand, useApi, useApi, useVersionedDraft];
});
_c5 = ReturnsPage;
function orderSnapshot(order) {
  return { version: order.version, values: { customerId: order.customerId, conversationId: order.conversationId || "", warehouse: order.warehouseId, addressId: order.shippingAddressId || "", notes: typeof order.notes === "string" ? order.notes : "", lines: order.lines.map((line) => ({ variantId: line.variantId, quantity: String(line.quantity) })) } };
}
function returnInspectionSnapshot(item) {
  const lines = item.lines.map((line) => ({
    orderLineId: line.orderLineId,
    acceptedQuantity: line.quantity,
    disposition: line.disposition === "pending" ? "quarantined" : line.disposition,
    reason: line.disposition === "pending" ? "Chờ kiểm tra tình trạng hàng nhận lại" : line.reason
  }));
  return { version: item.version, values: { lines } };
}
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "OrdersPage");
$RefreshReg$(_c2, "DraftForm");
$RefreshReg$(_c3, "NewOrderPage");
$RefreshReg$(_c4, "OrderDetailPage");
$RefreshReg$(_c5, "ReturnsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/orders/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JvUixTQUFxUyxVQUFyUzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsQnBSLFNBQVFBLHFCQUFvQjtBQUM1QixTQUFTQyxZQUFZQyx5QkFBeUI7QUFDOUMsU0FBU0MsZ0JBQWdCQyxvQkFBb0I7QUFDN0MsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGFBQWFDLFlBQVlDLFlBQVlDLGNBQWNDLG1CQUFtQjtBQUMvRSxTQUFTQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWFDLFdBQVdDLHVCQUF1QjtBQUN4RCxTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxTQUFTQyxZQUFZQyxVQUFVQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFDaEcsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLGdCQUFnQjtBQUV2QixTQUFTQyxRQUFRQyxZQUFZQyxtQkFBbUI7QUFDaEQsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxpQkFBaUJDLGdCQUFnQjtBQUMzRCxTQUFTQyxZQUFZQyxPQUFPQyxXQUFXQyxZQUFZQyxTQUFTQyxPQUFPQyxRQUFRQyxRQUFRQyxnQkFBZ0JDLFlBQVlDLGFBQWFDLGVBQWVDLFdBQVdDLFlBQVlDLHNCQUFzQjtBQUN4TCxTQUFTQyxnQkFBZ0I7QUFDbEIsZ0JBQVNDLGFBQWE7QUFBQUMsS0FBQTtBQUFFLFFBQU0sRUFBRUMsS0FBSyxJQUFJeEIsU0FBUztBQUFHLFFBQU15QixXQUFXMUMsWUFBWTtBQUFHLFFBQU0yQyxPQUFPN0IsT0FBTyxjQUFjLEVBQUU4QixPQUFPekIsYUFBYSxZQUFZLEVBQUUsQ0FBQztBQUFHLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sWUFBVyxVQUFTLHVEQUFzRCxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUSxhQUFZLFNBQVMsTUFBTXVCLFNBQVMsTUFBTUQsS0FBS0ksRUFBRSxhQUFhLEdBQUcsNEJBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0gsS0FBcE87QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzUDtBQUFBLElBQUUsdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxjQUFhLGFBQVksaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBT0YsTUFBTSxnQkFBZSxXQUFXQSxlQUFLRyxRQUFRLG1DQUFFO0FBQUEsK0JBQUMsYUFBVSxPQUFNLHNCQUFxQixNQUFNSCxLQUFLRyxLQUFLQSxNQUFNLFFBQVEsQ0FBQUMsTUFBS0EsRUFBRUYsSUFBSSxTQUFTO0FBQUEsVUFDL29CO0FBQUEsWUFDSUcsS0FBSztBQUFBLFlBQU1DLE9BQU87QUFBQSxZQUFZQyxRQUFRQSxDQUFBSCxNQUFLLHVCQUFDLFNBQU07QUFBQSxxQ0FBQyxjQUFXLFlBQVloRCxTQUFTb0QsV0FBV0MsV0FBV0MsUUFBU04sWUFBRUYsTUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWtCdkIsbUJBQVN5QixFQUFFTyxXQUFXYixLQUFLYyxRQUFRLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJGO0FBQUEsaUJBQXBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlNO0FBQUEsVUFDaFA7QUFBQSxVQUNBLEVBQUVQLEtBQUssWUFBWUMsT0FBTyxTQUFTQyxRQUFRQSxDQUFBSCxNQUFLLGtCQUFrQkEsRUFBRVMsVUFBVSxHQUFHO0FBQUEsVUFBRyxFQUFFUixLQUFLLFNBQVNDLE9BQU8sYUFBYVEsT0FBTyxTQUFTUCxRQUFRQSxDQUFBSCxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRVcsU0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUIsRUFBRztBQUFBLFVBQUcsRUFBRVYsS0FBSyxTQUFTQyxPQUFPLE9BQU9DLFFBQVFBLENBQUFILE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFWSxjQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QixFQUFHO0FBQUEsVUFBRyxFQUFFWCxLQUFLLFlBQVlDLE9BQU8sYUFBYUMsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVhLG9CQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQyxFQUFHO0FBQUEsVUFBRyxFQUFFWixLQUFLLFdBQVdDLE9BQU8sUUFBUUMsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVjLGdCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QixFQUFHO0FBQUEsVUFBRyxFQUFFYixLQUFLLFVBQVVDLE9BQU8sSUFBSUMsUUFBUUEsQ0FBQUgsTUFBSyx1QkFBQyxhQUFVLElBQUksTUFBTU4sS0FBS0ksRUFBRSxXQUFXRSxFQUFFRixFQUFFLElBQUksdUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNELEVBQWE7QUFBQSxRQUFDLEtBSjZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLempCO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1GLEtBQUtHLEtBQUtnQixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FMeWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLdmhCLEtBTHVkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLbmQ7QUFBQSxTQUxpWTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3BYO0FBQUEsT0FMMEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtsSDtBQUFLO0FBQUN0QixHQUxqREQsWUFBVTtBQUFBLFVBQXNCdEIsVUFBNkJqQixhQUE0QmMsUUFBOEJLLFlBQVk7QUFBQTtBQUFBLEtBQW5Jb0I7QUFNaEIsU0FBU3dCLFVBQVU7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFBQSxFQUFTQztBQUl2QyxHQUFHO0FBQUFDLE1BQUE7QUFDQyxRQUFNLEVBQUUxQixLQUFLLElBQUl4QixTQUFTO0FBQzFCLFFBQU0sQ0FBQ21ELE1BQU0sSUFBSWxFLGdCQUFnQjtBQUNqQyxRQUFNLENBQUNtRSxTQUFTQyxVQUFVLElBQUl4RSxTQUF1QixJQUFJO0FBQ3pELFFBQU15RSxXQUFXUCxXQUFXSztBQUM1QixRQUFNRyxtQkFBbUJ0RCxPQUFPLGdCQUFnQjtBQUNoRCxRQUFNdUQsa0JBQWtCdkQsT0FBTyxjQUFjO0FBQzdDLFFBQU13RCx1QkFBdUJ4RCxPQUFPLG9CQUFvQjtBQUN4RCxRQUFNeUQsaUJBQWlCekQsT0FBTyxjQUFjO0FBQzVDLFFBQU0sQ0FBQzBELGdCQUFnQkMsaUJBQWlCLElBQUkvRSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDZ0YsZUFBZUMsZ0JBQWdCLElBQUlqRixTQUFTLEVBQUU7QUFDckQsUUFBTWtGLFlBQVloRSxZQUFZLGlCQUFpQixFQUFFNEIsT0FBTyxFQUFFcUMsR0FBR0wsZUFBZU0sS0FBSyxLQUFLQyxRQUFXQyxPQUFPLEdBQUcsRUFBRSxHQUFHWixnQkFBZ0I7QUFDaEksUUFBTWEsV0FBV3JFLFlBQVksZ0JBQWdCLEVBQUU0QixPQUFPLEVBQUVxQyxHQUFHSCxjQUFjSSxLQUFLLEtBQUtDLFFBQVdDLE9BQU8sR0FBRyxFQUFFLEdBQUdYLGVBQWU7QUFDNUgsUUFBTWEsU0FBU3ZFLFdBQVcsZUFBZSxDQUFDLFlBQVksQ0FBQztBQUN2RCxRQUFNd0UsU0FBU3hFLFdBQVcsb0JBQW9CLENBQUMsWUFBWSxZQUFZLENBQUM7QUFDeEVuQixZQUFVLE1BQU07QUFBRXNFLG1CQUFlb0IsT0FBT0UsV0FBV0QsT0FBT0MsT0FBTztBQUFBLEVBQUcsR0FBRyxDQUFDRixPQUFPRSxTQUFTRCxPQUFPQyxTQUFTdEIsWUFBWSxDQUFDO0FBQ3JILFFBQU11QixlQUFlLE9BQU96QixTQUFTMEIsVUFBVSxXQUFXMUIsUUFBUTBCLFFBQVE7QUFDMUUsUUFBTSxDQUFDbEMsWUFBWW1DLFdBQVcsSUFBSTdGLFNBQVNrRSxTQUFTUixjQUFjWSxPQUFPd0IsSUFBSSxZQUFZLEtBQUssRUFBRSxHQUFHLENBQUNDLGdCQUFnQkMsZUFBZSxJQUFJaEcsU0FBU2tFLFNBQVM2QixrQkFBa0J6QixPQUFPd0IsSUFBSSxnQkFBZ0IsS0FBSyxFQUFFLEdBQUcsQ0FBQ0csV0FBV0MsWUFBWSxJQUFJbEcsU0FBU2tFLFNBQVNpQyxlQUFleEQsS0FBS3lELGtCQUFrQixHQUFHLENBQUNDLFdBQVdDLFVBQVUsSUFBSXRHLFNBQVNrRSxTQUFTcUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDQyxRQUFRQyxTQUFTLElBQUl6RyxTQUEyQmtFLFNBQVN3QyxpQkFBaUIsS0FBSyxHQUFHLENBQUNkLE9BQU9lLFFBQVEsSUFBSTNHLFNBQVMyRixZQUFZO0FBQ3plLFFBQU1pQixhQUFhMUYsWUFBWSxrQkFBa0IsRUFBRTRCLE9BQU8sRUFBRStELFFBQVEsVUFBVXZCLE9BQU8sR0FBRyxFQUFFLEdBQUdsRSxPQUFPLGdCQUFnQixDQUFDO0FBQ3JILFFBQU0wRixZQUFZNUYsWUFBWSx5QkFBeUIsRUFBRTZGLE1BQU0sRUFBRXJELFdBQVcsR0FBR1osT0FBTyxFQUFFK0QsUUFBUSxVQUFVdkIsT0FBTyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM1QixjQUFjZ0IsZ0JBQWdCO0FBQ3pKLFFBQU1zQyxPQUFPOUYsWUFBWSxxQkFBcUIsRUFBRTRCLE9BQU8sRUFBRVksWUFBWUEsY0FBYzJCLFFBQVdDLE9BQU8sR0FBRyxFQUFFLEdBQUdWLHdCQUF3QixDQUFDLENBQUNsQixVQUFVO0FBQ2pKLFFBQU0sQ0FBQ3VELE9BQU9DLFFBQVEsSUFBSWxILFNBQVNrRSxTQUFTK0MsTUFBTUUsSUFBSSxDQUFBQyxPQUFNLEVBQUVsRSxLQUFLa0UsRUFBRXJFLElBQUlzRSxXQUFXRCxFQUFFQyxXQUFXQyxjQUFjLEdBQUdGLEVBQUVHLElBQUksTUFBTUgsRUFBRUksR0FBRyxJQUFJQyxVQUFVQyxPQUFPTixFQUFFSyxRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRXZFLEtBQUt5RSxPQUFPQyxXQUFXLEdBQUdQLFdBQVcsSUFBSUMsY0FBYyxJQUFJRyxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQ3pQLFFBQU1JLFdBQVd0QyxTQUFTdkMsTUFBTUEsS0FBSzhFLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRWxCLFdBQVcsUUFBUSxFQUFFbUIsUUFBUSxDQUFBRCxNQUFLQSxFQUFFRixTQUFTQyxPQUFPLENBQUFHLE1BQUtBLEVBQUVDLE1BQU0sRUFBRWYsSUFBSSxDQUFBYyxPQUFNLEVBQUUsR0FBR0EsR0FBR0UsYUFBYUosRUFBRVIsS0FBSyxFQUFFLENBQUMsS0FBSztBQUNwSyxRQUFNYSxvQkFBb0JBLENBQUNDLFVBQWtCQSxNQUFNQyxTQUFTLE1BQU0sQ0FBQyxRQUFRQyxLQUFLRixLQUFLLEtBQUtHLE9BQU9ILEtBQUssSUFBSSxLQUFLRyxPQUFPSCxLQUFLLElBQUk7QUFDL0gsUUFBTUksb0JBQW9CLElBQUlDLElBQUl6QixNQUFNRSxJQUFJLENBQUFDLE1BQUtBLEVBQUVDLFNBQVMsRUFBRVMsT0FBT2EsT0FBTyxDQUFDLEVBQUVDLFNBQVMzQixNQUFNYSxPQUFPLENBQUFWLE1BQUtBLEVBQUVDLFNBQVMsRUFBRWlCO0FBQ3ZILFFBQU1PLFFBQVEsQ0FBQyxDQUFDbkYsY0FBYyxDQUFDLENBQUN1QyxVQUFVYixLQUFLLEtBQUs2QixNQUFNcUIsU0FBUyxLQUFLckIsTUFBTXFCLFVBQVUsT0FBT3JCLE1BQU02QixNQUFNLENBQUExQixNQUFLQSxFQUFFQyxhQUFhLENBQUNlLGtCQUFrQmhCLEVBQUVLLFFBQVEsQ0FBQyxLQUFLLENBQUNnQixxQkFBcUJuSCxnQkFBZ0JzRSxLQUFLLEtBQUssUUFBVTFCLFlBQVltQixVQUFjWCxvQkFBb0JDO0FBQzFRLFFBQU1vRSxnQkFBZ0JBLENBQUM3RixLQUFhbUUsY0FBc0I7QUFDdEQsVUFBTTJCLFdBQVduQixTQUFTb0IsS0FBSyxDQUFBaEIsTUFBS0EsRUFBRWxGLE9BQU9zRSxTQUFTO0FBQ3RESCxhQUFTLENBQUFnQyxhQUFXQSxTQUFRL0IsSUFBSSxDQUFBZ0MsU0FBUUEsS0FBS2pHLFFBQVFBLE1BQU0sRUFBRSxHQUFHaUcsTUFBTTlCLFdBQVdDLGNBQWMwQixXQUFXLEdBQUdBLFNBQVNiLFdBQVcsTUFBTWEsU0FBU3pCLElBQUksTUFBTXlCLFNBQVN4QixHQUFHLEtBQUsyQixLQUFLN0IsYUFBYSxJQUFJNkIsSUFBSSxDQUFDO0FBQUEsRUFDMU07QUFDQSxRQUFNQyxRQUFRcEksT0FBTyxZQUFZLEVBQUUrRixNQUFNLEVBQUVzQyxTQUFTNUUsVUFBVTFCLE1BQU0sR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDMEIsUUFBUTtBQUN0RixRQUFNeUUsVUFBVUUsTUFBTXBHLFNBQVMsQ0FBQ3lCLFlBQVkyRSxNQUFNcEcsS0FBS0EsS0FBS3NHLFdBQVc3RSxTQUFTNkUsV0FBV0YsTUFBTXBHLEtBQUtBLE9BQU95QjtBQUM3RyxRQUFNOEUsU0FBUyxFQUFFN0YsWUFBWXFDLGdCQUFnQkUsV0FBV0ksV0FBV1QsT0FBT3FCLE9BQU9BLE1BQU1FLElBQUksQ0FBQWdDLFVBQVMsRUFBRTlCLFdBQVc4QixLQUFLOUIsV0FBV0ksVUFBVTBCLEtBQUsxQixTQUFTLEVBQUUsRUFBRTtBQUM3SixRQUFNK0IsU0FBU25LLGtCQUFrQjtBQUFBLElBQzdCb0ssVUFBVSxHQUFHOUcsS0FBS0ksRUFBRSxVQUFVMEIsVUFBVTFCLE1BQU0sS0FBSztBQUFBLElBQ25EMkcsUUFBUVIsVUFBVVMsY0FBY1QsT0FBTyxJQUFJN0Q7QUFBQUEsSUFDM0N1RSxPQUFPTDtBQUFBQSxJQUNQTSxPQUFPQSxDQUFBeEIsVUFBUztBQUNaeEMsa0JBQVl3QyxNQUFNM0UsVUFBVTtBQUFHc0Msc0JBQWdCcUMsTUFBTXRDLGNBQWM7QUFBR0csbUJBQWFtQyxNQUFNcEMsU0FBUztBQUFHSyxpQkFBVytCLE1BQU1oQyxTQUFTO0FBQUdNLGVBQVMwQixNQUFNekMsS0FBSztBQUN0SnNCLGVBQVMsQ0FBQTRDLGFBQVl6QixNQUFNcEIsTUFBTUUsSUFBSSxDQUFBZ0MsVUFBUyxFQUFFLEdBQUdBLE1BQU1qRyxLQUFLNEcsU0FBU2IsS0FBSyxDQUFBYyxTQUFRQSxLQUFLMUMsY0FBYzhCLEtBQUs5QixTQUFTLEdBQUduRSxPQUFPeUUsT0FBT0MsV0FBVyxHQUFHTixjQUFjd0MsU0FBU2IsS0FBSyxDQUFBYyxTQUFRQSxLQUFLMUMsY0FBYzhCLEtBQUs5QixTQUFTLEdBQUdDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztBQUFBLElBQ3RQO0FBQUEsSUFBRzBDLFNBQVNBLE1BQU1aLE1BQU1hLFFBQVEsRUFBRUMsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUMxRCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0IsSUFBSW5LLFNBQVMsT0FBTyxFQUFFLEdBQUd1SixRQUFRbEQsV0FBV0csT0FBTyxFQUFFO0FBQzVFLFFBQU00RCxZQUFZN0ssYUFBYWtGLFdBQVcrRSxPQUFPYSxRQUFRLENBQUNqTCxXQUFXK0ssa0JBQWtCLEVBQUUsR0FBR1osUUFBUWxELFdBQVdHLE9BQU8sQ0FBQyxDQUFDO0FBQ3hILFFBQU04RCxVQUFVdkssT0FBd0IsSUFBSTtBQUM1QyxRQUFNd0ssT0FBTyxZQUFZO0FBQUUsUUFBSTtBQUMzQixZQUFNQyxPQUFPLEVBQUU5RyxZQUFZcUMsZ0JBQWdCQSxrQkFBa0IsTUFBTUksYUFBYUYsV0FBV2dCLE9BQU9BLE1BQU1FLElBQUksQ0FBQWdDLFVBQVMsRUFBRTlCLFdBQVc4QixLQUFLOUIsV0FBV0ksVUFBVWUsT0FBT1csS0FBSzFCLFFBQVEsRUFBRSxFQUFFLEdBQUc3QixNQUFNO0FBQzdMLFVBQUk2RTtBQUNKLFVBQUloRyxVQUFVO0FBQ1YsY0FBTWlHLFdBQVdsQixPQUFPbUIsUUFBUTtBQUFHLFlBQUksQ0FBQ0QsU0FBVTtBQUNsREQsbUJBQVcsTUFBTWhGLE9BQU9tRixRQUFRLEVBQUU3RCxNQUFNLEVBQUVzQyxTQUFTNUUsU0FBUzFCLEdBQUcsR0FBR3VHLFNBQVNvQixTQUFTcEIsU0FBU2tCLE1BQU07QUFBQSxVQUMvRixHQUFJRSxTQUFTRyxNQUFNbkgsZUFBZTJCLFNBQVksRUFBRTNCLFlBQVk4RyxLQUFLOUcsV0FBVyxJQUFJLENBQUM7QUFBQSxVQUNqRixHQUFJZ0gsU0FBU0csTUFBTTlFLG1CQUFtQlYsU0FBWSxFQUFFVSxnQkFBZ0J5RSxLQUFLekUsZUFBZSxJQUFJLENBQUM7QUFBQSxVQUM3RixHQUFJMkUsU0FBU0csTUFBTTVFLGNBQWNaLFNBQVksRUFBRWMsYUFBYXFFLEtBQUtyRSxZQUFZLElBQUksQ0FBQztBQUFBLFVBQ2xGLEdBQUl1RSxTQUFTRyxNQUFNeEUsY0FBY2hCLFNBQVksRUFBRWtCLG1CQUFtQkYsYUFBYSxLQUFLLElBQUksQ0FBQztBQUFBLFVBQ3pGLEdBQUlxRSxTQUFTRyxNQUFNNUQsVUFBVTVCLFNBQVksRUFBRTRCLE9BQU91RCxLQUFLdkQsTUFBTSxJQUFJLENBQUM7QUFBQSxVQUNsRSxHQUFJeUQsU0FBU0csTUFBTWpGLFVBQVVQLFNBQVksRUFBRU8sT0FBTzRFLEtBQUs1RSxNQUFNLElBQUksQ0FBQztBQUFBLFFBQ3RFLEVBQUUsQ0FBQztBQUFBLE1BQ1AsTUFBTzZFLFlBQVcsTUFBTWpGLE9BQU9vRixRQUFRLEVBQUVKLE1BQU0sRUFBRSxHQUFHQSxNQUFNOUQsZUFBZUYsUUFBUUQsbUJBQW1CRixhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ3pILFlBQU15RSxRQUFRdEIsT0FBT3VCLFVBQVVwQixjQUFjYyxTQUFTekgsSUFBSSxHQUFHdUcsUUFBUSxHQUFHNUcsS0FBS0ksRUFBRSxVQUFVMEgsU0FBU3pILEtBQUtELEVBQUUsRUFBRTtBQUMzRyxVQUFJK0gsT0FBTztBQUFFLFlBQUlSLFFBQVFwQixRQUFTNUosZ0JBQWVnTCxRQUFRcEIsT0FBTztBQUFHL0UsZ0JBQVFzRyxTQUFTekgsSUFBSTtBQUFBLE1BQUc7QUFDdEZ3QixtQkFBV2lHLFNBQVN6SCxJQUFJO0FBQUEsSUFDakMsU0FBU2dJLE9BQU87QUFBRXhCLGFBQU95QixPQUFPRCxLQUFLO0FBQUEsSUFBRztBQUFBLEVBQUU7QUFDMUMsUUFBTUUsbUJBQW1CaEcsVUFBVWxDLE1BQU1BLEtBQUtpRyxLQUFLLENBQUFrQyxhQUFZQSxTQUFTcEksT0FBT1csVUFBVTtBQUN6RixTQUFPLHVCQUFDLE9BQUksV0FBVSxRQUFPLEtBQUssQ0FBQTBILFNBQVE7QUFBRSxVQUFNQyxVQUFVRDtBQUFnQ2QsWUFBUXBCLFVBQVVtQztBQUFTakIsY0FBVWlCLE9BQU87QUFBQSxFQUFHLEdBQUcsVUFBVSxDQUFBQyxVQUFTO0FBQUVBLFVBQU1DLGVBQWU7QUFBRyxRQUFJMUMsTUFBTyxNQUFLMEIsS0FBSztBQUFBLEVBQUcsR0FBRyxpQ0FBQyxnQkFDbk47QUFBQSwyQkFBQyxlQUFZLE9BQU8vRSxPQUFPd0YsU0FBU3ZGLE9BQU91RixTQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUV0SCxZQUFZLGNBQWNxQyxnQkFBZ0IsYUFBYUUsV0FBVyxZQUFZSSxXQUFXLHFCQUFxQlQsT0FBTyxXQUFXcUIsT0FBTyxnQkFBZ0IsR0FBRyxNQUFNekIsT0FBT0UsV0FBV0QsT0FBT0MsV0FBbE87QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwTztBQUFBLElBQzVSLENBQUNoQixvQkFBb0IsdUJBQUMsU0FBTSxVQUFTLFdBQVUsd0hBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0k7QUFBQSxJQUN2SixDQUFDQyxtQkFBbUIsdUJBQUMsU0FBTSxVQUFTLFdBQVUsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEY7QUFBQSxJQUM5R08sVUFBVXNHLFdBQVcsdUJBQUMsZUFBWSxPQUFPdEcsVUFBVThGLFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUN6RHpGLFNBQVNpRyxXQUFXLHVCQUFDLGVBQVksT0FBT2pHLFNBQVN5RixTQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DO0FBQUEsSUFDeEQsdUJBQUMsU0FBTSxPQUFNLDBCQUF5QixVQUFTLFNBQVEsaUNBQUMsY0FDcEQ7QUFBQSw2QkFBQyxhQUFVLE9BQU0sa0JBQWlCLE9BQU9sRyxnQkFBZ0IsVUFBVSxDQUFBMkcsTUFBSzFHLGtCQUFrQjBHLEVBQUVDLE9BQU9yRCxLQUFLLEdBQUcsVUFBVSxDQUFDM0Qsa0JBQWtCLFlBQVcsNkRBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNE07QUFBQSxNQUM1TSx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGNBQWEsT0FBT2hCLFlBQVksVUFBVSxDQUFBK0gsTUFBSztBQUFFNUYsb0JBQVk0RixFQUFFQyxPQUFPckQsS0FBSztBQUFHckMsd0JBQWdCLEVBQUU7QUFBR00sbUJBQVcsRUFBRTtBQUFBLE1BQUcsR0FBRyxVQUFVLENBQUM1QixvQkFBb0IsQ0FBQ0QsVUFBVSxVQUFVQyxrQkFBa0IsWUFBWUEsbUJBQW9CUSxVQUFVeUcsWUFBWSx5QkFBeUJ6RyxVQUFVbEMsTUFBTUEsS0FBS3NGLFdBQVcsSUFBSSxrQ0FBa0MsQ0FBQzVFLGFBQWEscUNBQXFDMkIsU0FBYUEsUUFDcGEzQjtBQUFBQSxzQkFBYyxDQUFDd0gsb0JBQW9CLHVCQUFDLFlBQVMsT0FBT3hILFlBQVk7QUFBQTtBQUFBLFVBQW9CQTtBQUFBQSxhQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsUUFDL0Z3QixVQUFVbEMsTUFBTUEsS0FBS21FLElBQUksQ0FBQWdFLGFBQVksdUJBQUMsWUFBMkIsT0FBT0EsU0FBU3BJLElBQUtvSSxtQkFBU1MsZUFBM0NULFNBQVNwSSxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFLENBQVc7QUFBQSxXQUYzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGtCQUFlLE9BQU0sY0FBYSxhQUFhbUMsVUFBVTJHLGFBQWEsU0FBUzNHLFVBQVU0RyxTQUFTLE1BQU01RyxVQUFVNkcsZUFBZSxZQUFZN0csVUFBVThHLFlBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUs7QUFBQSxNQUNqSyx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLHVCQUFzQixPQUFPakcsZ0JBQWdCLFVBQVUsQ0FBQTBGLE1BQUt6RixnQkFBZ0J5RixFQUFFQyxPQUFPckQsS0FBSyxHQUFHLFVBQVUsQ0FBQ3pELHdCQUF3QixDQUFDbEIsWUFBWSxZQUFZLENBQUNrQix1QkFBdUIsa0VBQWtFUyxRQUN2UTtBQUFBLCtCQUFDLFlBQVMsT0FBTSxJQUFHLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsUUFBWTJCLEtBQUtoRSxNQUFNQSxLQUFLOEUsT0FBTyxDQUFBbUUsaUJBQWdCQSxhQUFhdkksZUFBZUEsVUFBVSxFQUFFeUQsSUFBSSxDQUFBOEUsaUJBQWdCLHVCQUFDLFlBQStCLE9BQU9BLGFBQWFsSixJQUFLa0o7QUFBQUEsdUJBQWFMO0FBQUFBLFVBQVk7QUFBQSxVQUFJSyxhQUFhbEo7QUFBQUEsYUFBcEZrSixhQUFhbEosSUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRyxDQUFXO0FBQUEsV0FEclE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxrQkFBZSxPQUFNLGFBQVksYUFBYWlFLEtBQUs2RSxhQUFhLFNBQVM3RSxLQUFLOEUsU0FBUyxNQUFNOUUsS0FBSytFLGVBQWUsWUFBWS9FLEtBQUtnRixZQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRJO0FBQUEsTUFDNUksdUJBQUMsY0FBVyxXQUFXLEVBQUVFLElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFRCxJQUFJLFdBQVdDLElBQUksUUFBUSxHQUN6RjtBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sWUFBVyxPQUFPbEcsV0FBVyxVQUFVLENBQUF3RixNQUFLdkYsYUFBYXVGLEVBQUVDLE9BQU9yRCxLQUFLLEdBQUcsV0FBUyxNQUFDLFVBQVU3QyxPQUFPRSxXQUFXRCxPQUFPQyxTQUFTLElBQUksRUFBRTBHLE1BQU0sR0FBR0MsVUFBVSxFQUFFLEdBQzlLcEc7QUFBQUEsdUJBQWEsQ0FBQ1csV0FBVzVELE1BQU1BLEtBQUtzSixLQUFLLENBQUFDLE1BQUtBLEVBQUV4SixPQUFPa0QsU0FBUyxLQUFLLHVCQUFDLFlBQVMsT0FBT0EsV0FBVztBQUFBO0FBQUEsWUFBY0E7QUFBQUEsZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUN6SFcsV0FBVzVELE1BQU1BLEtBQUttRSxJQUFJLENBQUFvRixNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUV4SixJQUFLd0o7QUFBQUEsY0FBRUM7QUFBQUEsWUFBSztBQUFBLFlBQUlELEVBQUVoRjtBQUFBQSxlQUFqQ2dGLEVBQUV4SixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRCxDQUFXO0FBQUEsYUFGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLHFCQUFvQixPQUFPc0QsV0FBVyxVQUFVLENBQUFvRixNQUFLbkYsV0FBV21GLEVBQUVDLE9BQU9yRCxLQUFLLEdBQUcsV0FBUyxNQUFDLFVBQVUsQ0FBQzNFLGNBQWM4QixPQUFPRSxXQUFXRCxPQUFPQyxTQUFTLElBQUksRUFBRTBHLE1BQU0sR0FBR0MsVUFBVSxFQUFFLEdBQUcsWUFBVyxzRkFDbk47QUFBQSxpQ0FBQyxZQUFTLE9BQU0sSUFBRyxpQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxVQUNuQ2hHLGFBQWEsQ0FBQ1MsVUFBVTlELE1BQU1BLEtBQUtzSixLQUFLLENBQUFHLE1BQUtBLEVBQUUxSixPQUFPc0QsU0FBUyxLQUFLLHVCQUFDLFlBQVMsT0FBT0EsV0FBVztBQUFBO0FBQUEsWUFBa0JBO0FBQUFBLGVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDNUhTLFVBQVU5RCxNQUFNQSxLQUFLbUUsSUFBSSxDQUFBc0YsTUFBSyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFMUosSUFBSzBKO0FBQUFBLGNBQUV0SixTQUFTLFdBQVdzSixFQUFFMUosRUFBRTtBQUFBLFlBQUc7QUFBQSxZQUFJMEosRUFBRUMsYUFBYTtBQUFBLGVBQXBFRCxFQUFFMUosSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUcsQ0FBVztBQUFBLGFBSHJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxlQUFZLE9BQU82RCxXQUFXb0UsU0FBU2xFLFVBQVVrRSxTQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDdkQzRSxhQUFhLHVCQUFDLGNBQVcsTUFBSyxTQUFRLGNBQVcsK0JBQzlDO0FBQUEsK0JBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsaUNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxjQUFXLElBQUksRUFBQ3NHLGNBQWEsV0FBVSxHQUFJN0Ysb0JBQVU5RCxNQUFNQSxLQUFLaUcsS0FBSyxDQUFBMkQsWUFBU0EsUUFBUTdKLE9BQUtzRCxTQUFTLEdBQUdsRCxTQUFTa0QsYUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEySDtBQUFBLFdBRmpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHZDtBQUFBLE1BQ0EsdUJBQUMsa0JBQWUsT0FBTSxZQUFXLGFBQWFPLFdBQVdpRixhQUFhLFNBQVNqRixXQUFXa0YsU0FBUyxNQUFNbEYsV0FBV21GLGVBQWUsWUFBWW5GLFdBQVdvRixZQUExSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1LO0FBQUEsTUFDbEt0SSxjQUFjLHVCQUFDLGtCQUFlLE9BQU0scUJBQW9CLGFBQWFvRCxVQUFVK0UsYUFBYSxTQUFTL0UsVUFBVWdGLFNBQVMsTUFBTWhGLFVBQVVpRixlQUFlLFlBQVlqRixVQUFVa0YsWUFBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SztBQUFBLE1BQ3ZMLHVCQUFDLFNBQU0sVUFBUyxRQUFPLG1JQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBJO0FBQUEsTUFDekl2SCxZQUFZZSxPQUFPRSxVQUFVLHVCQUFDLGNBQVcsTUFBSyxTQUFRLGNBQVcsY0FDOUQ7QUFBQSwrQkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQiwwQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLGNBQVcsSUFBSSxFQUFFaUgsY0FBYyxXQUFXLEdBQUluRyxxQkFBVyxRQUFRLHVCQUF1QixrQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3SDtBQUFBLFdBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHOUIsSUFBZ0IsdUJBQUMsYUFBVSxPQUFNLGNBQWEsUUFBTSxNQUFDLE9BQU9BLFFBQVEsVUFBVSxDQUFBaUYsTUFBS2hGLFVBQVVnRixFQUFFQyxPQUFPckQsS0FBc0IsR0FBRztBQUFBLCtCQUFDLFlBQVMsT0FBTSxPQUFNLGtDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUyw0Q0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFdBQXZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa087QUFBQSxTQWpDL0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDdkQsS0FsQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDYTtBQUFBLElBQ2IsdUJBQUMsU0FBTSxPQUFNLG9CQUFtQixVQUFTLFNBQVEsVUFBUywwRUFBeUUsUUFBUSx1QkFBQyxVQUFPLFdBQVcsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXLEdBQUssVUFBVXBCLE1BQU1xQixVQUFVLEtBQUssU0FBUyxNQUFNcEIsU0FBUyxDQUFBZ0MsYUFBVyxDQUFDLEdBQUdBLFVBQVMsRUFBRWhHLEtBQUt5RSxPQUFPQyxXQUFXLEdBQUdQLFdBQVcsSUFBSUMsY0FBYyxJQUFJRyxVQUFVLElBQUksQ0FBQyxDQUFDLEdBQUcseUJBQWxNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMk0sR0FDbFYsaUNBQUMsY0FDRztBQUFBLDZCQUFDLGFBQVUsT0FBTSx5QkFBd0IsT0FBT3pDLGVBQWUsVUFBVSxDQUFBeUcsTUFBS3hHLGlCQUFpQndHLEVBQUVDLE9BQU9yRCxLQUFLLEdBQUcsVUFBVSxDQUFDMUQsaUJBQWlCLFlBQVcsMEVBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNk47QUFBQSxNQUM1TnNDLE1BQU1FLElBQUksQ0FBQ2dDLE1BQU0wRCxVQUFVO0FBQ3hCLGNBQU1DLGtCQUFrQmpGLFNBQVNvQixLQUFLLENBQUE4RCxZQUFXQSxRQUFRaEssT0FBT29HLEtBQUs5QixTQUFTO0FBQzlFLGNBQU0yRixrQkFBa0I1RSxrQkFBa0JlLEtBQUsxQixRQUFRO0FBQ3ZELGVBQU8sdUJBQUMsY0FBMEIsV0FBVyxFQUFFeUUsSUFBSSxVQUFVZSxJQUFJLE1BQU0sR0FBRyxZQUFZLEVBQUVmLElBQUksV0FBV2UsSUFBSSxRQUFRLEdBQy9HO0FBQUEsaUNBQUMsYUFBVSxPQUFPLFlBQVlKLFFBQVEsQ0FBQyxJQUFJLFFBQU0sTUFBQyxXQUFTLE1BQUMsT0FBTzFELEtBQUs5QixXQUFXLFVBQVUsQ0FBQzFDLG1CQUFtQixDQUFDRixVQUFVLFVBQVUsQ0FBQTZHLFVBQVN2QyxjQUFjSSxLQUFLakcsS0FBS29JLE1BQU1JLE9BQU9yRCxLQUFLLEdBQUcsT0FBT0kscUJBQXFCLENBQUMsQ0FBQ1UsS0FBSzlCLFdBQVcsWUFBWW9CLHFCQUFxQlUsS0FBSzlCLFlBQVkseUVBQXlFaEMsUUFDaFc4RDtBQUFBQSxpQkFBSzlCLGFBQWEsQ0FBQ3lGLG1CQUFtQix1QkFBQyxZQUFTLE9BQU8zRCxLQUFLOUIsV0FBWThCLGVBQUs3QixnQkFBZ0Isc0JBQXNCNkIsS0FBSzlCLFNBQVMsTUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUNwSVEsU0FBU1YsSUFBSSxDQUFBNEYsWUFBVyx1QkFBQyxZQUEwQixPQUFPQSxRQUFRaEssSUFBSSxVQUFVa0UsTUFBTXFGLEtBQUssQ0FBQVksVUFBU0EsTUFBTWhLLFFBQVFpRyxLQUFLakcsT0FBT2dLLE1BQU03RixjQUFjMEYsUUFBUWhLLEVBQUUsR0FBSWdLO0FBQUFBLHNCQUFRNUU7QUFBQUEsY0FBWTtBQUFBLGNBQUk0RSxRQUFReEY7QUFBQUEsY0FBSztBQUFBLGNBQUl3RixRQUFRdkY7QUFBQUEsaUJBQTFLdUYsUUFBUWhLLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZMLENBQVc7QUFBQSxZQUNoTzRCLG1CQUFtQixDQUFDWSxTQUFTb0csYUFBYTlELFNBQVNTLFdBQVcsS0FBSyxDQUFDYSxLQUFLOUIsYUFBYSx1QkFBQyxZQUFTLFVBQVEsTUFBQyxPQUFNLElBQUcsd0RBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsZUFIL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxPQUFNLFlBQVcsT0FBTzhCLEtBQUsxQixVQUFVLFVBQVUsQ0FBQTZELFVBQVNwRSxTQUFTLENBQUFnQyxhQUFXQSxTQUFRL0IsSUFBSSxDQUFBNEMsU0FBUUEsS0FBSzdHLFFBQVFpRyxLQUFLakcsTUFBTSxFQUFFLEdBQUc2RyxNQUFNdEMsVUFBVTZELE1BQU1JLE9BQU9yRCxNQUFNLElBQUkwQixJQUFJLENBQUMsR0FBRyxPQUFPaUQsaUJBQWlCLFlBQVlBLGtCQUFrQix1Q0FBdUMsa0NBQWtDLFlBQVksRUFBRUcsV0FBVyxXQUFXLGdCQUFnQkgsZ0JBQWdCLEdBQUcsSUFBSSxFQUFFWCxVQUFVLEtBQUtlLFVBQVUsRUFBRUgsSUFBSSxJQUFJLEVBQUUsS0FBMWE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNGE7QUFBQSxVQUM1YSx1QkFBQyxjQUFXLGNBQVksV0FBV0osUUFBUSxDQUFDLElBQUksVUFBVTVGLE1BQU1xQixXQUFXLEdBQUcsSUFBSSxFQUFFK0UsV0FBVyxRQUFRLEdBQUcsU0FBUyxNQUFNbkcsU0FBUyxDQUFBZ0MsYUFBV0EsU0FBUXBCLE9BQU8sQ0FBQWlDLFNBQVFBLEtBQUs3RyxRQUFRaUcsS0FBS2pHLEdBQUcsQ0FBQyxHQUFHLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCLEtBQWxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFOO0FBQUEsYUFQak1pRyxLQUFLakcsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFQO0FBQUEsTUFDSixDQUFDO0FBQUEsTUFDRCx1QkFBQyxrQkFBZSxPQUFNLFlBQVcsYUFBYXFDLFNBQVNzRyxhQUFhLFNBQVN0RyxTQUFTdUcsU0FBUyxNQUFNdkcsU0FBU3dHLGVBQWUsWUFBWXhHLFNBQVN5RyxZQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJKO0FBQUEsTUFDMUovRSxNQUFNcUIsVUFBVSxPQUFPLHVCQUFDLFNBQU0sVUFBUyxXQUFVLDZEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFDL0YsdUJBQUMsU0FBTSxVQUFTLFFBQU8sd0lBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0k7QUFBQSxNQUMvSSx1QkFBQyxhQUFVLE9BQU0sb0JBQW1CLE9BQU8xQyxPQUFPLFVBQVUsQ0FBQTZGLE1BQUs5RSxTQUFTcEYsZ0JBQWdCa0ssRUFBRUMsT0FBT3JELE9BQU8sR0FBSSxDQUFDLEdBQUcsT0FBTy9HLGdCQUFnQnNFLEtBQUssSUFBSSxLQUFPLFlBQVksR0FBR3RFLGdCQUFnQnNFLEtBQUssQ0FBQyxnQkFBZ0IsV0FBUyxNQUFDLFNBQVMsS0FBak87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtTztBQUFBLFNBbEJ2TztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUNBLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUSxhQUFZLE1BQU1KLE9BQU9FLFdBQVdELE9BQU9DLFNBQVMsVUFBVSxDQUFDbUQsU0FBUyxDQUFDaEUsZ0JBQWdCLE1BQUssVUFBUyw0QkFBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSztBQUFBLE9BL0Q2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0V0TixLQWhFTztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0VRO0FBQ25CO0FBQUNSLElBcklRSixXQUFTO0FBQUEsVUFLRzlDLFVBQ0FmLGlCQUdRZ0IsUUFDREEsUUFDS0EsUUFDTkEsUUFHTEYsYUFDREEsYUFDRkQsWUFDQUEsWUFJSUMsYUFBMEVFLFFBQzNFRixhQUNMQSxhQVVDRixRQUdDM0IsbUJBVUdFLFlBQVk7QUFBQTtBQUFBLE1BL0N6QjBFO0FBc0lGLGdCQUFTcUosZUFBZTtBQUFBQyxNQUFBO0FBQUUsUUFBTSxFQUFFNUssS0FBSyxJQUFJeEIsU0FBUztBQUFHLFFBQU15QixXQUFXMUMsWUFBWTtBQUFHLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sZ0JBQWUsVUFBUyxxREFBb0QsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTXlDLEtBQUtJLEVBQUUsV0FBVyw2QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxLQUEzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdLO0FBQUEsSUFBRSx1QkFBQyxhQUFVLFNBQVMsQ0FBQUUsTUFBS0wsU0FBUyxNQUFNRCxLQUFLSSxFQUFFLFdBQVdFLEVBQUVGLEVBQUUsRUFBRSxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtFO0FBQUEsT0FBOU87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnUDtBQUFLO0FBQUN3SyxJQUEzVUQsY0FBWTtBQUFBLFVBQXNCbk0sVUFBNkJqQixXQUFXO0FBQUE7QUFBQSxNQUExRW9OO0FBQ1QsZ0JBQVNFLGdCQUFnQjtBQUFBLEVBQUVDO0FBRWxDLEdBQUc7QUFBQUMsTUFBQTtBQUNDLFFBQU0sRUFBRXJFLFVBQVUsR0FBRyxJQUFJbEosVUFBVTtBQUNuQyxRQUFNLEVBQUV3QyxLQUFLLElBQUl4QixTQUFTO0FBQzFCLFFBQU13TSxXQUFTeE8sY0FBYyxNQUFNd0QsS0FBS0ksRUFBRSxTQUFTO0FBQ25ELFFBQU0rQyxNQUFNOUUsT0FBTyxZQUFZLEVBQUUrRixNQUFNLEVBQUVzQyxRQUFRLEVBQUUsQ0FBQztBQUNwRCxRQUFNdUUsUUFBUTlILElBQUk5QyxNQUFNQTtBQUN4QixRQUFNNkssVUFBVTVNLFdBQVcsY0FBYyxDQUFDLFVBQVUsQ0FBQztBQUNyRCxRQUFNNk0sU0FBUzdNLFdBQVcsOEJBQThCLEVBQUU7QUFDMUQsUUFBTThNLFVBQVU5TSxXQUFXLGdCQUFnQixDQUFDLFlBQVksY0FBYyxzQkFBc0IsZ0JBQWdCLGlCQUFpQixxQkFBcUIsY0FBYyxDQUFDO0FBQ2pLLFFBQU0rTSxTQUFTL00sV0FBVyxlQUFlLENBQUMsWUFBWSxjQUFjLHNCQUFzQixpQkFBaUIsY0FBYyxDQUFDO0FBQzFILFFBQU1nTixNQUFNaE4sV0FBVyxZQUFZLENBQUMsWUFBWSxjQUFjLGVBQWUsb0JBQW9CLENBQUM7QUFDbEcsUUFBTWlOLFNBQVNqTixXQUFXLGVBQWUsQ0FBQyxZQUFZLGNBQWMsYUFBYSxDQUFDO0FBQ2xGLFFBQU0sQ0FBQ2tOLE9BQU9DLFFBQVEsSUFBSXBPLFNBQTRCLElBQUksR0FBRyxDQUFDcU8sY0FBY0MsZUFBZSxJQUFJdE8sU0FBc0MsSUFBSSxHQUFHLENBQUN1TyxTQUFTQyxVQUFVLElBQUl4TyxTQUFTLEtBQUssR0FBRyxDQUFDeU8sUUFBUUMsU0FBUyxJQUFJMU8sU0FBMEQsSUFBSSxHQUFHLENBQUNnTCxPQUFPMkQsUUFBUSxJQUFJM08sU0FBdUIsSUFBSTtBQUMzVCxRQUFNLENBQUM0TyxVQUFVQyxXQUFXLElBQUk3TyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDOE8sTUFBTUMsT0FBTyxJQUFJL08sU0FBUyxFQUFFLEdBQUcsQ0FBQ3lKLFVBQVV1RixXQUFXLElBQUloUCxTQUFTLEVBQUUsR0FBRyxDQUFDaVAsV0FBV0MsVUFBVSxJQUFJbFAsU0FBUyxFQUFFLEdBQUcsQ0FBQ21QLFFBQVFDLFNBQVMsSUFBSXBQLFNBQVMsRUFBRSxHQUFHLENBQUNxUCxXQUFXQyxZQUFZLElBQUl0UCxTQUFTLEVBQUUsR0FBRyxDQUFDdVAsYUFBYUMsV0FBVyxJQUFJeFAsU0FBUyxFQUFFLEdBQUcsQ0FBQ3lQLFFBQVFDLFNBQVMsSUFBSTFQLFNBQVMsRUFBRTtBQUNoUixRQUFNLENBQUMyUCxPQUFPQyxRQUFRLElBQUk1UCxTQUFTLE1BQU02UCxLQUFLQyxJQUFJLENBQUM7QUFDbkQsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJaFEsU0FBUyxDQUFDO0FBQ3RELFFBQU1pUSxxQkFBcUJBLENBQUNDLFNBQWlCO0FBQ3pDLFVBQU1DLFVBQVVOLEtBQUtPLE1BQU1GLElBQUk7QUFDL0IsUUFBSTFILE9BQU82SCxTQUFTRixPQUFPO0FBQ3ZCSCx3QkFBa0JHLFVBQVVSLEtBQUs7QUFBQSxFQUN6QztBQUNBN1AsWUFBVSxNQUFNO0FBQ1osUUFBSSxDQUFDcU87QUFDRDtBQUNKLFVBQU1tQyxRQUFRQyxPQUFPQyxZQUFZLE1BQU1aLFNBQVNDLEtBQUtDLElBQUksQ0FBQyxHQUFHLEdBQUs7QUFDbEUsV0FBTyxNQUFNUyxPQUFPRSxjQUFjSCxLQUFLO0FBQUEsRUFDM0MsR0FBRyxDQUFDbkMsS0FBSyxDQUFDO0FBQ1YsUUFBTXVDLGlCQUFpQmYsUUFBUUk7QUFDL0IsUUFBTVksZUFBZSxDQUFDLENBQUN4QyxTQUFTMEIsS0FBS08sTUFBTWpDLE1BQU15QyxTQUFTLEtBQUtGO0FBQy9ELFFBQU1HLHNCQUFzQixDQUFDLENBQUN4QyxpQkFBaUJBLGFBQWF4SCxXQUFXLFdBQVdnSixLQUFLTyxNQUFNL0IsYUFBYXVDLFNBQVMsS0FBS0Y7QUFDeEg1USxZQUFVLE1BQU07QUFBRSxRQUFJOE4sU0FBU08sU0FBU1AsTUFBTXRFLFlBQVk2RSxNQUFNMkMsY0FBYztBQUMxRTFDLGVBQVMsSUFBSTtBQUNiRSxzQkFBZ0IsSUFBSTtBQUFBLElBQ3hCO0FBQUEsRUFBRSxHQUFHLENBQUNWLE9BQU9PLEtBQUssQ0FBQztBQUNuQixRQUFNNEMsVUFBVSxZQUFZO0FBQUUsUUFBSSxDQUFDNUM7QUFDL0I7QUFBUSxRQUFJO0FBQ1osWUFBTTZDLElBQUksTUFBTWxELE9BQU9sRCxRQUFRLEVBQUU3RCxNQUFNLEVBQUVzQyxRQUFRLEdBQUdtQixNQUFNLEVBQUV5RyxTQUFTOUMsTUFBTXBMLElBQUltTyxXQUFXcEMsTUFBTXFDLGNBQWNoRCxNQUFNMkMsY0FBY00sb0JBQW9CM0gsVUFBVTRILGlCQUFpQnBDLFVBQVUsRUFBRSxDQUFDO0FBQzlMZ0IseUJBQW1CZSxFQUFFTSxLQUFLcEIsSUFBSTtBQUM5QjVCLHNCQUFnQjBDLEVBQUVoTyxJQUFJO0FBQ3RCMEwsZ0JBQVUsSUFBSTtBQUFBLElBQ2xCLFFBQ007QUFBQSxJQUFFO0FBQUEsRUFBa0I7QUFDMUIsUUFBTTZDLGNBQWMsWUFBWTtBQUFFLFFBQUksQ0FBQ3BELFNBQVMsQ0FBQ1Y7QUFDN0M7QUFBUSxRQUFJO0FBQ1osWUFBTStELFdBQVcsTUFBTS9ELDZCQUE2QjlLLEtBQUtJLElBQUlvTCxNQUFNcEwsRUFBRTtBQUNyRWdNLGNBQVF5QyxTQUFTTixTQUFTO0FBQzFCbEMsa0JBQVl3QyxTQUFTSixrQkFBa0I7QUFDdkNsQyxpQkFBV3NDLFNBQVNILGVBQWU7QUFDbkMsWUFBTUwsSUFBSSxNQUFNbEQsT0FBT2xELFFBQVEsRUFBRTdELE1BQU0sRUFBRXNDLFFBQVEsR0FBR21CLE1BQU1nSCxTQUFTLENBQUM7QUFDcEV2Qix5QkFBbUJlLEVBQUVNLEtBQUtwQixJQUFJO0FBQzlCNUIsc0JBQWdCMEMsRUFBRWhPLElBQUk7QUFBQSxJQUMxQixTQUNPeUksR0FBRztBQUNOa0QsZUFBU2xELGFBQWFnRyxRQUFRaEcsSUFBSSxJQUFJZ0csTUFBTSwrQkFBK0IsQ0FBQztBQUFBLElBQ2hGO0FBQUEsRUFBRTtBQUNGLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU8sT0FBT3BJLE9BQU8sSUFBSSxVQUFTLHNFQUFxRSxTQUFTLHVCQUFDLGFBQVUsSUFBSXNFLFVBQVUsNkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0MsS0FBbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErSztBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPN0gsS0FBSyxnQkFBZSxXQUFXOEgsbUJBQVMsbUNBQ3hQO0FBQUEsNkJBQUMsZUFBWSxPQUFPNUMsU0FBUzZDLFFBQVE3QyxTQUFTOEMsT0FBTzlDLFNBQVMrQyxRQUFRL0MsU0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQUd1RCxVQUFVLHVCQUFDLGNBQVcscUJBQW1CLE1BQUMsTUFBSSxNQUFDLE9BQU0sZ0JBQWUsTUFBTUssVUFBVSxTQUFTLE1BQU1KLFdBQVcsS0FBSyxHQUFHLFNBQVMsQ0FBQyxFQUFFa0QsY0FBY0MsS0FBSyxNQUFNLHVCQUFDLFVBQU8sVUFBVUEsTUFBTSxTQUFTRCxjQUFjLDhCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZELEdBQVcsaUNBQUMsYUFBVSxTQUFTOUQsT0FBTyxjQUFjaUIsYUFBYSxTQUFTLE1BQU07QUFBRUEsb0JBQVksS0FBSztBQUFHTCxtQkFBVyxLQUFLO0FBQUdKLGlCQUFTLElBQUk7QUFBR0Usd0JBQWdCLElBQUk7QUFBQSxNQUFHLEtBQXJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUosS0FBaFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrWCxJQUFnQixtQ0FDM2Q7QUFBQSwrQkFBQyxlQUFZLFdBQVUsT0FBTSxVQUFTLFdBQVU7QUFBQSxpQ0FBQyxVQUFPLE9BQU9WLE1BQU0vSixjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUUsdUJBQUMsVUFBTyxPQUFPK0osTUFBTTlKLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQUUsdUJBQUMsVUFBTyxPQUFPOEosTUFBTTdKLGdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQUUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsSUFBSSxFQUFFc0osV0FBVyxTQUFTLEdBQUc7QUFBQTtBQUFBLFlBQVdPLE1BQU10RTtBQUFBQSxlQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLGFBQWxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK1A7QUFBQSxRQUMvUCx1QkFBQyxlQUFZLFNBQVMsRUFBRTRDLElBQUksT0FBTzBGLElBQUksVUFBVSxHQUFHO0FBQUEsaUNBQUMsU0FBTSxPQUFNLHNCQUFxQjtBQUFBLG1DQUFDLGFBQVUsT0FBTSxzQkFBcUIsTUFBTWhFLE1BQU0zRyxPQUFPLFFBQVEsQ0FBQUcsTUFBS0EsRUFBRXJFLElBQUksU0FBUztBQUFBLGNBQzVKO0FBQUEsZ0JBQ0lHLEtBQUs7QUFBQSxnQkFBUUMsT0FBTztBQUFBLGdCQUFrQkMsUUFBUUEsQ0FBQWdFLE1BQUssdUJBQUMsU0FBTTtBQUFBLHlDQUFDLGNBQVcsWUFBWW5ILFNBQVNvRCxXQUFXQyxXQUFXQyxRQUFTNkQsWUFBRUcsUUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxrQkFBYSx1QkFBQyxjQUFXLFNBQVEsV0FBV0gsWUFBRUksT0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUM7QUFBQSxxQkFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkk7QUFBQSxjQUNwTTtBQUFBLGNBQ0EsRUFBRXRFLEtBQUssT0FBT0MsT0FBTyxZQUFZUSxPQUFPLFNBQVNQLFFBQVFBLENBQUFnRSxNQUFLQSxFQUFFSyxTQUFTO0FBQUEsY0FBRyxFQUFFdkUsS0FBSyxTQUFTQyxPQUFPLFdBQVdRLE9BQU8sU0FBU1AsUUFBUUEsQ0FBQWdFLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFeUssYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkIsRUFBRztBQUFBLGNBQUcsRUFBRTNPLEtBQUssU0FBU0MsT0FBTyxjQUFjUSxPQUFPLFNBQVNQLFFBQVFBLENBQUFnRSxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRTBLLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCLEVBQUc7QUFBQSxZQUFDLEtBSnRNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS3pFO0FBQUEsWUFBRSx1QkFBQyxPQUFJLElBQUksQ0FBQ3RQLFNBQVN1UCxRQUFRQyxPQUFPLEVBQUVDLFdBQVcsUUFBUSxDQUFDLEdBQUc7QUFBQSxxQ0FBQyxjQUFXLE9BQU0sa0JBQWlCLDJCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQWEsdUJBQUMsY0FBVyxTQUFRLE1BQUssaUNBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT3JFLE1BQU1oSyxTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQyxLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGlCQUFqTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4TDtBQUFBLGVBTHpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSytKO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU0sbUJBQWtCLFVBQVMsU0FBUSxpQ0FBQyxPQUFJO0FBQUEsbUNBQUMsY0FBVyxPQUFNLFNBQVEsaUNBQUMsYUFBVSxJQUFJLE1BQU1qQixLQUFLSSxFQUFFLGNBQWM2SyxNQUFNbEssVUFBVSxJQUFJO0FBQUE7QUFBQSxjQUFnQmtLLE1BQU1sSztBQUFBQSxpQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0YsS0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUk7QUFBQSxZQUFhLHVCQUFDLGNBQVcsT0FBTSxPQUFNO0FBQUE7QUFBQSxjQUFTa0ssTUFBTXpIO0FBQUFBLGlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQWEsdUJBQUMsY0FBVyxPQUFNLFdBQVd5SCxnQkFBTXNFLDBCQUEwQixDQUFDdEUsTUFBTXNFLHdCQUF3Qi9PLE9BQU95SyxNQUFNc0Usd0JBQXdCeEYsV0FBV2tCLE1BQU1zRSx3QkFBd0JDLE9BQU92RSxNQUFNc0Usd0JBQXdCRSxRQUFRLEVBQUV0SyxPQUFPYSxPQUFPLEVBQUUwSixLQUFLLEtBQUssSUFBS3pFLE1BQU1ySCxvQkFBb0IsZUFBZXFILE1BQU1ySCxpQkFBaUIsS0FBSyxtQ0FBN1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOFY7QUFBQSxZQUFhLHVCQUFDLGNBQVcsT0FBTSxjQUFjcUgsZ0JBQU1sSCxrQkFBa0IsUUFBUSxRQUFRLGVBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFBY2tILE1BQU03SCxrQkFBa0IsdUJBQUMsYUFBVSxJQUFJLE1BQU1wRCxLQUFLSSxFQUFFLFVBQVU2SyxNQUFNN0gsY0FBYyxJQUFJLDRCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQWM2SCxNQUFNMEUsY0FBYyx1QkFBQyxhQUFVLElBQUksTUFBTTNQLEtBQUtJLEVBQUUsZ0JBQWdCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLGVBQWgyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2MkIsS0FBNzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW02QjtBQUFBLGFBTDluQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3NvQztBQUFBLFFBQ3RvQyx1QkFBQyxlQUFZLFdBQVUsT0FBTSxXQUFVLFFBQU87QUFBQSxpQ0FBQyxrQkFBZSxZQUFXLGdCQUFlLGdCQUFnQjZLLE1BQU0yRSxnQkFBZ0IsUUFBTyxRQUFPLFNBQVMsTUFBTS9ELFdBQVcsSUFBSSxHQUFHLDRCQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySTtBQUFBLFVBQWlCLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsZ0JBQWdCWixNQUFNMkUsZ0JBQWdCLFFBQU8sU0FBUSxTQUFRLGFBQVksTUFBTTFFLFFBQVFuSSxTQUFTLFNBQVMsWUFBWTtBQUFFLGdCQUFJO0FBQ2hXLG9CQUFNc0wsSUFBSSxNQUFNbkQsUUFBUWpELFFBQVEsRUFBRTdELE1BQU0sRUFBRXNDLFFBQVEsR0FBR0MsU0FBU3NFLE1BQU10RSxRQUFRLENBQUM7QUFDN0UyRyxpQ0FBbUJlLEVBQUVNLEtBQUtwQixJQUFJO0FBQzlCOUIsdUJBQVM0QyxFQUFFaE8sSUFBSTtBQUNmc0wsOEJBQWdCLElBQUk7QUFDcEJTLHNCQUFRLE9BQU9pQyxFQUFFaE8sS0FBS2tPLGNBQWMsV0FBV0YsRUFBRWhPLEtBQUtrTyxZQUFZLEVBQUU7QUFBQSxZQUN4RSxRQUNNO0FBQUEsWUFBRTtBQUFBLFVBQXVCLEdBQUcsb0NBUDZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT3pJO0FBQUEsVUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxnQkFBZSxnQkFBZ0J0RCxNQUFNMkUsZ0JBQWdCLFFBQU8sVUFBUyxPQUFNLFNBQVEsU0FBUyxNQUFNN0QsVUFBVSxRQUFRLEdBQUcsdUJBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlKO0FBQUEsVUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxnQkFBZSxnQkFBZ0JkLE1BQU0yRSxnQkFBZ0IsUUFBTyxrQkFBaUIsU0FBUyxNQUFNO0FBQUVuRCxzQkFBVXhCLE1BQU1oSyxPQUFPdUwsVUFBVSxFQUFFO0FBQUdPLHNCQUFVLEVBQUU7QUFBR0oseUJBQWEsRUFBRTtBQUFHRSx3QkFBWSxFQUFFO0FBQUdkLHNCQUFVLEtBQUs7QUFBQSxVQUFHLEdBQUcsb0NBQXRPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBQO0FBQUEsVUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxrQkFBaUIsZ0JBQWdCZCxNQUFNMkUsZ0JBQWdCLFFBQU8sa0JBQWlCLFNBQVMsTUFBTTtBQUFFbkQsc0JBQVUsRUFBRTtBQUFHTSxzQkFBVSxFQUFFO0FBQUdKLHlCQUFhLEVBQUU7QUFBR0Usd0JBQVksRUFBRTtBQUFHZCxzQkFBVSxRQUFRO0FBQUEsVUFBRyxHQUFHLHNDQUFwTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwTztBQUFBLFVBQWtCZCxNQUFNMkUsZUFBZUMsU0FBUyxnQkFBZ0IsS0FBSyx1QkFBQyxhQUFVLElBQUksTUFBTTdQLEtBQUtJLEVBQUUsb0JBQW9CNkssTUFBTTdLLEVBQUUsSUFBSSxvQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxhQVB0NEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9tNUI7QUFBQSxRQUNsNUJvTCxTQUFTLHVCQUFDLFNBQU0sT0FBTSw2QkFBNEIsVUFBVSxXQUFXQSxNQUFNMkMsWUFBWSxjQUFjdFAsU0FBUzJNLE1BQU15QyxXQUFXak8sS0FBS2MsUUFBUSxDQUFDLElBQUksVUFBUyxTQUFRLFdBQVUsV0FBVSxpQ0FBQyxTQUFNLElBQUlqQixTQUFTTSxNQUFNMlAsVUFBVTtBQUFBLGlDQUFDLGNBQVcsU0FBUSxNQUFLLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU90RSxNQUFNdkssU0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxVQUFjdUssTUFBTXVFLFNBQVN2TCxJQUFJLENBQUNvRixHQUFHb0csTUFBTSx1QkFBQyxTQUFjLFVBQVMsUUFBUXBHLGVBQXBCb0csR0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQyxDQUFRO0FBQUEsVUFBRSx1QkFBQyxjQUFXLFNBQVEsU0FBUTtBQUFBO0FBQUEsWUFBYXhFLE1BQU1wTDtBQUFBQSxlQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQWEsdUJBQUMsY0FBVyxTQUFRLFdBQVUsSUFBSSxFQUFFNEosY0FBYyxXQUFXLEdBQUc7QUFBQTtBQUFBLFlBQTBCbUMsUUFBUTtBQUFBLGVBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRLO0FBQUEsVUFBYzZCLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSw2RkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUc7QUFBQSxVQUFVdEMsZUFBZSx1QkFBQyxTQUFNLFVBQVV3QyxzQkFBc0IsWUFBWSxXQUFZQSxnQ0FBc0IsOEZBQThGLDBCQUEwQnhDLGFBQWF0TCxFQUFFLDBDQUE1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtUSxJQUFXLHVCQUFDLGVBQVksV0FBVSxPQUFPO0FBQUEsbUNBQUMsVUFBTyxTQUFTLE1BQU0yTCxVQUFVLFVBQVUsR0FBRyw4Q0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUFVakIsZ0NBQWdDLHVCQUFDLFVBQU8sU0FBUSxZQUFXLFVBQVVLLE9BQU9wSSxTQUFTLFNBQVMsTUFBTSxLQUFLNkwsWUFBWSxHQUFHLDZDQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSDtBQUFBLGVBQXpRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1SO0FBQUEsVUFBZSx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixnQkFBZ0IzRCxNQUFNMkUsZ0JBQWdCLFFBQU8sV0FBVSxTQUFRLGFBQVksVUFBVSxDQUFDbEUsZ0JBQWdCc0MsZ0JBQWdCRSxxQkFBcUIsTUFBTTlDLFFBQVFySSxTQUFTLFNBQVMsWUFBWTtBQUFFLGdCQUFJLENBQUMySSxnQkFBZ0JzQyxnQkFBZ0JFO0FBQ25pRDtBQUFRLGdCQUFJO0FBQ1osb0JBQU05QyxRQUFRbkQsUUFBUTtBQUFBLGdCQUNsQjdELE1BQU0sRUFBRXNDLFFBQVE7QUFBQSxnQkFBR0MsU0FBU3NFLE1BQU10RTtBQUFBQSxnQkFBU2tCLE1BQU0sRUFBRW9JLGlCQUFpQmhGLE1BQU10RSxTQUFTMkgsU0FBUzlDLE1BQU1wTCxJQUFJOFAsd0JBQXdCeEUsYUFBYXRMLEdBQUc7QUFBQSxjQUNsSixDQUFDO0FBQ0RxTCx1QkFBUyxJQUFJO0FBQ2JFLDhCQUFnQixJQUFJO0FBQUEsWUFDeEIsUUFDTTtBQUFBLFlBQUU7QUFBQSxVQUFnQixHQUFHLHVDQVJrd0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRM3VDO0FBQUEsYUFSNEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVEzRyxLQVJwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUTRFO0FBQUEsV0F4QnFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QjNkO0FBQUEsU0ExQndQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQnBQLEtBMUJ5TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJyTDtBQUFBLElBQ1IsdUJBQUMsaUJBQWMsTUFBTUcsV0FBVyxVQUFVLE9BQU0sZ0JBQWUsY0FBYSxnQkFBZSxhQUFhLE9BQU9wRixPQUFPLGtKQUFrSixlQUFhLE1BQUMsU0FBUyxNQUFNcUYsVUFBVSxJQUFJLEdBQUcsTUFBTVYsT0FBT3RJLFNBQVMsT0FBT3NJLE9BQU9oRCxPQUFPLFdBQVcsQ0FBQXlFLFlBQVV6QixPQUFPcEQsUUFBUSxFQUFFN0QsTUFBTSxFQUFFc0MsUUFBUSxHQUFHQyxTQUFTc0UsT0FBT3RFLFNBQVNrQixNQUFNLEVBQUVvSSxpQkFBaUJoRixPQUFPdEUsV0FBVyxHQUFHbUcsZ0JBQU8sRUFBRSxDQUFDLEtBQTNlO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNmU7QUFBQSxJQUM3ZSx1QkFBQyxjQUFXLE1BQU1oQixXQUFXLFlBQVksT0FBTSxnQ0FBK0IsU0FBUyxNQUFNQyxVQUFVLElBQUksR0FBRyxNQUFNWixPQUFPcEksU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQyxpQkFBaUI2QyxLQUFLdUcsSUFBSSxLQUFLLENBQUNyRixZQUFZLENBQUN3RixhQUFhbkIsT0FBT3BJLFNBQVMsU0FBUyxNQUFNLEtBQUtxTCxRQUFRLEdBQUcsbUNBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUssR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT2pELE9BQU85QyxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFBRSx1QkFBQyxjQUFZO0FBQUEsK0JBQUMsU0FBTSxVQUFTLFdBQVUsK0hBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUk7QUFBQSxRQUFRLHVCQUFDLGFBQVUsT0FBTSwyQkFBMEIsT0FBTzhELE1BQU0sVUFBVSxDQUFBckQsTUFBS3NELFFBQVF0RCxFQUFFQyxPQUFPckQsS0FBSyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStGO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE9BQU9vQixVQUFVLFVBQVUsQ0FBQWdDLE1BQUt1RCxZQUFZdkQsRUFBRUMsT0FBT3JELEtBQUssS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLHdCQUF1QixPQUFPNEcsV0FBVyxVQUFVLENBQUF4RCxNQUFLeUQsV0FBV3pELEVBQUVDLE9BQU9yRCxLQUFLLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxXQUFwYztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNjO0FBQUEsU0FBcHlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaXpCO0FBQUEsSUFDanpCLHVCQUFDLGNBQVcsTUFBTW9HLFdBQVcsU0FBU0EsV0FBVyxVQUFVLE9BQU9BLFdBQVcsUUFBUSx5QkFBeUIseUJBQXlCLFNBQVMsTUFBTUMsVUFBVSxJQUFJLEdBQUcsTUFBTVQsSUFBSXZJLFdBQVd3SSxPQUFPeEksU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQyxvQkFBb0I2QyxLQUFLNEcsTUFBTSxLQUFLLENBQUNJLGVBQWUsQ0FBQ0YsYUFBYS9OLGdCQUFnQm1PLE9BQU9ySyxLQUFLLENBQUMsSUFBSSxLQUFLNkksSUFBSXZJLFdBQVd3SSxPQUFPeEksU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJLENBQUNrSTtBQUN4WjtBQUFRLFVBQUk7QUFDWixZQUFJYSxXQUFXO0FBQ1gsZ0JBQU1SLElBQUlyRCxRQUFRO0FBQUEsWUFDZDdELE1BQU0sRUFBRXNDLFFBQVE7QUFBQSxZQUFHQyxTQUFTc0UsTUFBTXRFO0FBQUFBLFlBQVNrQixNQUFNO0FBQUEsY0FDN0NvSSxpQkFBaUJoRixNQUFNdEU7QUFBQUEsY0FBUzZGLFFBQVEsRUFBRUEsUUFBUTJELFVBQVVuUSxLQUFLbVEsU0FBUztBQUFBLGNBQUd0TSxRQUFRO0FBQUEsY0FBaUI2STtBQUFBQSxjQUFXSTtBQUFBQSxjQUFRRjtBQUFBQSxZQUM3SDtBQUFBLFVBQ0osQ0FBQztBQUFBO0FBRUQsZ0JBQU1yQixPQUFPdEQsUUFBUTtBQUFBLFlBQ2pCN0QsTUFBTSxFQUFFc0MsUUFBUTtBQUFBLFlBQUdDLFNBQVNzRSxNQUFNdEU7QUFBQUEsWUFBU2tCLE1BQU0sRUFBRW9JLGlCQUFpQmhGLE1BQU10RSxTQUFTNkYsUUFBUSxFQUFFQSxRQUFRMkQsVUFBVW5RLEtBQUttUSxTQUFTLEdBQUdyRCxRQUFRc0Qsa0JBQWtCMUQsV0FBV0UsWUFBWTtBQUFBLFVBQ3JMLENBQUM7QUFDTGIsa0JBQVUsSUFBSTtBQUFBLE1BQ2xCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyxpQ0FkdUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWN0SyxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPVCxJQUFJakQsU0FBU2tELE9BQU9sRCxTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsTUFBRSx1QkFBQyxjQUFZO0FBQUEsK0JBQUMsU0FBTSxVQUFTLFdBQVUseUlBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUo7QUFBQSxRQUFRLHVCQUFDLGFBQVUsT0FBTyxZQUFZckksS0FBS21RLFFBQVEsS0FBSyxPQUFPM0QsUUFBUSxVQUFVLENBQUExRCxNQUFLMkQsVUFBVTNELEVBQUVDLE9BQU9yRCxLQUFLLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSwyQkFBMEIsT0FBT2dILFdBQVcsVUFBVSxDQUFBNUQsTUFBSzZELGFBQWE3RCxFQUFFQyxPQUFPckQsS0FBSyxLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sMkJBQTBCLE9BQU9rSCxhQUFhLFVBQVUsQ0FBQTlELE1BQUsrRCxZQUFZL0QsRUFBRUMsT0FBT3JELEtBQUssS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBT29ILFFBQVEsVUFBVSxDQUFBaEUsTUFBS2lFLFVBQVVqRSxFQUFFQyxPQUFPckQsS0FBSyxHQUFHLFdBQVMsTUFBQyxTQUFTLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUFobEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrbEI7QUFBQSxTQWQ1ckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWN5c0I7QUFBQSxPQTNDL3JCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQzRzQjtBQUN2dEI7QUFBQ3FGLElBdEdlRixpQkFBZTtBQUFBLFVBR0ZyTixXQUNSZ0IsVUFDRmhDLGVBQ0g2QixRQUVJQyxZQUNEQSxZQUNDQSxZQUNEQSxZQUNIQSxZQUNHQSxVQUFVO0FBQUE7QUFBQSxNQWJidU07QUF1R1QsZ0JBQVN3RixjQUFjO0FBQUFDLE1BQUE7QUFDMUIsUUFBTSxFQUFFdFEsS0FBSyxJQUFJeEIsU0FBUztBQUMxQixRQUFNLENBQUNtRCxNQUFNLElBQUlsRSxnQkFBZ0I7QUFDakMsUUFBTThTLGdCQUFnQjlSLE9BQU8sYUFBYTtBQUMxQyxRQUFNK1Isa0JBQWtCL1IsT0FBTyxlQUFlO0FBQzlDLFFBQU1nUyxtQkFBbUJoUyxPQUFPLGtCQUFrQjtBQUNsRCxRQUFNeUIsT0FBTzdCLE9BQU8sbUJBQW1CLEVBQUU4QixPQUFPekIsYUFBYSxpQkFBaUIsRUFBRSxDQUFDO0FBQ2pGLFFBQU0sQ0FBQ2dTLGtCQUFrQkMsbUJBQW1CLElBQUl0VCxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDdVQsYUFBYUMsY0FBYyxJQUFJeFQsU0FBUyxFQUFFO0FBQ2pERixZQUFVLE1BQU07QUFDWixVQUFNd1EsUUFBUUMsT0FBT2tELFdBQVcsTUFBTUQsZUFBZUgsaUJBQWlCak8sS0FBSyxDQUFDLEdBQUcsR0FBRztBQUNsRixXQUFPLE1BQU1tTCxPQUFPbUQsYUFBYXBELEtBQUs7QUFBQSxFQUMxQyxHQUFHLENBQUMrQyxnQkFBZ0IsQ0FBQztBQUNyQixRQUFNTSxTQUFTelMsWUFBWSxjQUFjLEVBQUU0QixPQUFPLEVBQUVxQyxHQUFHb08sZUFBZWxPLE9BQVUsRUFBRSxHQUFHNk4sYUFBYTtBQUNsRyxRQUFNMU4sU0FBU3ZFLFdBQVcsb0JBQW9CLENBQUMsaUJBQWlCLENBQUM7QUFDakUsUUFBTTJTLFVBQVUzUyxXQUFXLGlCQUFpQixDQUFDLG1CQUFtQixpQkFBaUIsc0JBQXNCLGVBQWUsQ0FBQztBQUN2SCxRQUFNLENBQUM0UyxNQUFNQyxPQUFPLElBQUk5VCxTQUFTLEtBQUssR0FBRyxDQUFDcUosU0FBUzBLLFFBQVEsSUFBSS9ULFNBQVNzRSxPQUFPd0IsSUFBSSxTQUFTLEtBQUssRUFBRSxHQUFHLENBQUMySixRQUFRQyxTQUFTLElBQUkxUCxTQUFTLEVBQUUsR0FBRyxDQUFDZ1UsWUFBWUMsYUFBYSxJQUFJalUsU0FBaUMsQ0FBQyxDQUFDO0FBQzNNLFFBQU1rVSxzQkFBc0JsVCxPQUFPLFlBQVksRUFBRStGLE1BQU0sRUFBRXNDLFFBQVEsRUFBRSxHQUFHNkosaUJBQWlCLENBQUMsQ0FBQzdKLE9BQU87QUFDaEcsUUFBTThLLGdCQUFnQlIsT0FBTzNRLE1BQU1BLEtBQUtpRyxLQUFLLENBQUEyRSxVQUFTQSxNQUFNN0ssT0FBT3NHLE9BQU8sS0FBSzZLLG9CQUFvQmxSLE1BQU1BO0FBQ3pHLFFBQU0sQ0FBQ2dHLFVBQVVvTCxXQUFXLElBQUlwVSxTQUE0QixJQUFJLEdBQUcsQ0FBQ3FVLGFBQWFDLGNBQWMsSUFBSXRVLFNBQW9DLEVBQUU7QUFDekksUUFBTXVVLGlCQUFpQnZULE9BQU8saUJBQWlCLEVBQUUrRixNQUFNLEVBQUV5TixZQUFZeEwsVUFBVWpHLE1BQU0sR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDaUcsWUFBWWtLLGFBQWE7QUFDeEgsUUFBTXVCLGlCQUFpQkYsZUFBZXZSLE1BQU1BO0FBQzVDLFFBQU0wUixtQkFBbUJyVixrQkFBa0I7QUFBQSxJQUN2Q29LLFVBQVUsR0FBRzlHLEtBQUtJLEVBQUUsV0FBV2lHLFVBQVVqRyxNQUFNLE1BQU07QUFBQSxJQUNyRDJHLFFBQVFWLFlBQVl5TCxnQkFBZ0IxUixPQUFPaUcsU0FBU2pHLEtBQUs0Uix5QkFBeUJGLGNBQWMsSUFBSXBQO0FBQUFBLElBQ3BHdUUsT0FBTyxFQUFFM0MsT0FBT29OLFlBQVk7QUFBQSxJQUFHeEssT0FBT0EsQ0FBQU4sV0FBVStLLGVBQWUvSyxPQUFPdEMsS0FBSztBQUFBLElBQzNFK0MsU0FBU0EsTUFBTXVLLGVBQWV0SyxRQUFRLEVBQUVDLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDaEUsQ0FBQztBQUNELFFBQU0wSyxlQUFlLENBQUMsQ0FBQzVMLFlBQVksQ0FBQyxDQUFDeUwsa0JBQWtCQSxlQUFlMVIsT0FBT2lHLFNBQVNqRyxNQUFNMlIsaUJBQWlCRyxVQUFVcEwsYUFBYSxHQUFHOUcsS0FBS0ksRUFBRSxXQUFXaUcsU0FBU2pHLEVBQUU7QUFDcEssUUFBTStSLGlCQUFpQkEsQ0FBQzlELE1BQWtCO0FBQUVvRCxnQkFBWXBELENBQUM7QUFBR3NELG1CQUFlLEVBQUU7QUFBQSxFQUFHO0FBQ2hGLFFBQU1TLGlCQUFpQlosZUFBZWxOLE1BQU1FLElBQUksQ0FBQWdDLFNBQVE7QUFDcEQsVUFBTTFCLFdBQVd1TSxXQUFXN0ssS0FBS3BHLEVBQUUsS0FBSztBQUN4QyxXQUFPO0FBQUEsTUFDSGlTLGFBQWE3TCxLQUFLcEc7QUFBQUEsTUFDbEIwRTtBQUFBQSxNQUNBd04sU0FBU3hOLGFBQWEsUUFBUSxDQUFDLFFBQVFjLEtBQUtkLFFBQVEsS0FBS2UsT0FBT2YsUUFBUSxJQUFJLEtBQUtlLE9BQU9mLFFBQVEsSUFBSTBCLEtBQUsxQjtBQUFBQSxJQUM3RztBQUFBLEVBQ0osQ0FBQyxFQUFFSyxPQUFPLENBQUFxQixTQUFRQSxLQUFLMUIsYUFBYSxHQUFHLEtBQUs7QUFDNUMsUUFBTXlOLGdCQUFnQixDQUFDZixpQkFBaUIsQ0FBQyxDQUFDLGFBQWEsZUFBZSxFQUFFM0IsU0FBUzJCLGNBQWNyUSxnQkFBZ0IsS0FBSyxDQUFDMkwsT0FBT3JLLEtBQUssS0FBSzlELGdCQUFnQm1PLE1BQU0sSUFBSSxPQUFTc0YsZUFBZXpNLFdBQVcsS0FBS3lNLGVBQWV6SSxLQUFLLENBQUFuRCxTQUFRQSxLQUFLOEwsT0FBTztBQUNoUCxRQUFNRSxvQkFBb0IsQ0FBQ1AsZ0JBQWdCLENBQUNILGtCQUFrQkosWUFBWS9MLFdBQVcsS0FBSytMLFlBQVkvSCxLQUFLLENBQUFuRCxTQUFRO0FBQy9HLFVBQU1pTSxXQUFXWCxlQUFleE4sTUFBTWdDLEtBQUssQ0FBQWMsU0FBUUEsS0FBS2lMLGdCQUFnQjdMLEtBQUs2TCxXQUFXLEdBQUd2TixZQUFZO0FBQ3ZHLFdBQU8sQ0FBQ2UsT0FBTzZNLFVBQVVsTSxLQUFLbU0sZ0JBQWdCLEtBQUtuTSxLQUFLbU0sbUJBQW1CLEtBQUtuTSxLQUFLbU0sbUJBQW1CRixZQUFZLENBQUNqTSxLQUFLc0csT0FBT3JLLEtBQUssS0FBSzlELGdCQUFnQjZILEtBQUtzRyxNQUFNLElBQUk7QUFBQSxFQUM5SyxDQUFDO0FBQ0QsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxtQkFBa0IsVUFBUyxnR0FBK0YsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGlCQUFnQixTQUFRLGFBQVksVUFBVSxDQUFDeUQsZUFBZSxTQUFTLE1BQU1ZLFFBQVEsSUFBSSxHQUFHLCtCQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNJLEtBQTNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNlM7QUFBQSxJQUM1UyxDQUFDWixpQkFBaUIsdUJBQUMsU0FBTSxVQUFTLFdBQVUsSUFBSTFRLFNBQVMrUyxPQUFPQyxVQUFVLDJFQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1IO0FBQUEsSUFDdEksdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxxQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQUcsdUJBQUMsY0FBVyxPQUFPM1MsTUFBTSxnQkFBZSxXQUFXQSxlQUFLRyxRQUFRLG1DQUFFO0FBQUEsK0JBQUMsYUFBVSxPQUFNLG1CQUFrQixNQUFNSCxLQUFLRyxLQUFLQSxNQUFNLFFBQVEsQ0FBQWdPLE1BQUtBLEVBQUVqTyxJQUFJLFNBQVM7QUFBQSxVQUNqTSxFQUFFRyxLQUFLLE1BQU1DLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQTROLE1BQUtBLEVBQUVqTyxHQUFHO0FBQUEsVUFDakQsRUFBRUcsS0FBSyxTQUFTQyxPQUFPLFdBQVdDLFFBQVFBLENBQUE0TixNQUFLLHVCQUFDLGFBQVUsSUFBSSxNQUFNck8sS0FBS0ksRUFBRSxXQUFXaU8sRUFBRTNILE9BQU8sSUFBSzJILFlBQUUzSCxXQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRCxFQUFhO0FBQUEsVUFDM0gsRUFBRW5HLEtBQUssU0FBU0MsT0FBTyxjQUFjQyxRQUFRQSxDQUFBNE4sTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUV5RSxPQUFPLFFBQU8sWUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUMsRUFBRztBQUFBLFVBQzVGLEVBQUV2UyxLQUFLLFVBQVVDLE9BQU8saUJBQWlCQyxRQUFRQSxDQUFBNE4sTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUUwRSxvQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0MsRUFBRztBQUFBLFVBQzNGLEVBQUV4UyxLQUFLLFVBQVVDLE9BQU8sSUFBSUMsUUFBUUEsQ0FBQTROLE1BQUssdUJBQUMsa0JBQWUsWUFBVyxvQkFBbUIsVUFBVSxDQUFDb0Msb0JBQW9CLENBQUMsYUFBYSxVQUFVLFVBQVUsRUFBRVosU0FBU3hCLEVBQUV5RSxLQUFLLEdBQUcsU0FBUyxNQUFNWCxlQUFlOUQsQ0FBQyxHQUFHLHlCQUF0SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErSyxFQUFrQjtBQUFBLFFBQUMsS0FML0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU05RztBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNbk8sS0FBS0csS0FBS2dCLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQU44RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTTVFLEtBTlk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1SO0FBQUEsU0FOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1tRDtBQUFBLElBQ25ELHVCQUFDLGNBQVcsTUFBWSxPQUFNLG9CQUFtQixTQUFTLE1BQU04UCxRQUFRLEtBQUssR0FBRyxNQUFNdE8sT0FBT0UsU0FBUyxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVV3UCxpQkFBaUIsQ0FBQ2hDLGlCQUFpQixDQUFDQyxtQkFBbUIzTixPQUFPRSxTQUFTLFNBQVMsWUFBWTtBQUM3TyxVQUFJO0FBQ0EsY0FBTUYsT0FBT29GLFFBQVEsRUFBRUosTUFBTSxFQUFFbkIsU0FBU29HLFFBQVFBLE9BQU9ySyxLQUFLLEdBQUc2QixPQUFPOE4sZUFBZTVOLElBQUksQ0FBQWdDLFVBQVMsRUFBRTZMLGFBQWE3TCxLQUFLNkwsYUFBYXZOLFVBQVVlLE9BQU9XLEtBQUsxQixRQUFRLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztBQUMxS3FNLGdCQUFRLEtBQUs7QUFDYkcsc0JBQWMsQ0FBQyxDQUFDO0FBQUEsTUFDcEIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUNaLEdBQUcsMkJBUDRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPakcsR0FDVjtBQUFBLDZCQUFDLGVBQVksT0FBT3pPLE9BQU93RixTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsY0FDSTtBQUFBLFNBQUNrSSxpQkFBaUIsdUJBQUMsU0FBTSxVQUFTLFdBQVUsaURBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUU5RSx1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsT0FBT0csa0JBQWtCLFVBQVUsQ0FBQS9ILFVBQVNnSSxvQkFBb0JoSSxNQUFNSSxPQUFPckQsS0FBSyxHQUFHLFVBQVUsQ0FBQzZLLGVBQWUsWUFBVyx1RUFBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TjtBQUFBLFFBQzdOLHVCQUFDLGFBQVUsT0FBTSxvQkFBbUIsUUFBTSxNQUFDLE9BQU83SixTQUFTLFVBQVUsQ0FBQWlDLFVBQVM7QUFBRXlJLG1CQUFTekksTUFBTUksT0FBT3JELEtBQUs7QUFBRzRMLHdCQUFjLENBQUMsQ0FBQztBQUFBLFFBQUcsR0FBRyxVQUFVLENBQUNmLGlCQUFrQlMsT0FBT2hJLGFBQWEsQ0FBQ2dJLE9BQU8zUSxNQUFPLFlBQVcsb0ZBQzFNcUc7QUFBQUEscUJBQVcsQ0FBQ3NLLE9BQU8zUSxNQUFNQSxLQUFLc0osS0FBSyxDQUFBc0IsVUFBU0EsTUFBTTdLLE9BQU9zRyxPQUFPLEtBQUssdUJBQUMsWUFBUyxPQUFPQSxTQUFVOEsseUJBQWVwUixPQUFPbVIsb0JBQW9CdkksWUFBWSwwQkFBMEJ0QyxZQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSDtBQUFBLFVBQ3pMc0ssT0FBTzNRLE1BQU1BLEtBQUs4RSxPQUFPLENBQUE4RixVQUFTLENBQUMsYUFBYSxlQUFlLEVBQUU0RSxTQUFTNUUsTUFBTTlKLGdCQUFnQixDQUFDLEVBQUVxRCxJQUFJLENBQUF5RyxVQUFTLHVCQUFDLFlBQXdCLE9BQU9BLE1BQU03SyxJQUFLNkssZ0JBQU03SyxNQUFsQzZLLE1BQU03SyxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRCxDQUFXO0FBQUEsYUFGcEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxrQkFBZSxPQUFNLFlBQVcsYUFBYTRRLE9BQU85SCxhQUFhLFNBQVM4SCxPQUFPN0gsU0FBUyxNQUFNNkgsT0FBTzVILGVBQWUsWUFBWTRILE9BQU8zSCxZQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1KO0FBQUEsUUFDbEoySCxPQUFPbkksV0FBVyx1QkFBQyxjQUFZO0FBQUEsaUNBQUMsZUFBWSxPQUFPbUksT0FBTzNJLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFBRSx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU07QUFBRSxrQkFBTTJJLE9BQU9nQyx1QkFBdUJoQyxPQUFPM0gsU0FBUyxJQUFJMkgsT0FBTzFKLFFBQVE7QUFBQSxVQUFJLEdBQUcscUNBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlJO0FBQUEsYUFBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrTTtBQUFBLFFBQ3BOaUssb0JBQW9CMUksV0FBVyx1QkFBQyxlQUFZLE9BQU8wSSxvQkFBb0JsSixTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDN0VtSixlQUFlbE4sTUFBTUUsSUFBSSxDQUFBZ0MsU0FBUTtBQUM5QixnQkFBTXlNLFFBQVFiLGVBQWU5TCxLQUFLLENBQUFjLFNBQVFBLEtBQUtpTCxnQkFBZ0I3TCxLQUFLcEcsRUFBRTtBQUN0RSxpQkFBTyx1QkFBQyxhQUF3QixPQUFPLEdBQUdvRyxLQUFLNUIsSUFBSSxZQUFZNEIsS0FBSzFCLFFBQVEsS0FBSyxNQUFLLFVBQVMsWUFBWSxFQUFFb08sS0FBSyxHQUFHQyxLQUFLM00sS0FBSzFCLFVBQVVzTyxNQUFNLEVBQUUsR0FBRyxPQUFPL0IsV0FBVzdLLEtBQUtwRyxFQUFFLEtBQUssS0FBSyxPQUFPLENBQUMsQ0FBQzZTLE9BQU9YLFNBQVMsWUFBWVcsT0FBT1gsVUFBVSwyQkFBMkI5TCxLQUFLMUIsUUFBUSw2Q0FBNkMsZ0JBQWdCMEIsS0FBSzFCLFFBQVEseUNBQXlDLFVBQVUsQ0FBQTZELFVBQVMySSxjQUFjLENBQUEvSyxhQUFZLEVBQUUsR0FBR0EsU0FBUyxDQUFDQyxLQUFLcEcsRUFBRSxHQUFHdUksTUFBTUksT0FBT3JELE1BQU0sRUFBRSxLQUE1Y2MsS0FBS3BHLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThkO0FBQUEsUUFDemUsQ0FBQztBQUFBLFFBQ0QsdUJBQUMsYUFBVSxPQUFNLGFBQVksV0FBUyxNQUFDLE9BQU8wTSxRQUFRLFVBQVUsQ0FBQW5FLFVBQVNvRSxVQUFVcEUsTUFBTUksT0FBT3JELEtBQUssR0FBRyxPQUFPLENBQUNvSCxPQUFPckssS0FBSyxLQUFLOUQsZ0JBQWdCbU8sTUFBTSxJQUFJLEtBQU8sWUFBWSxHQUFHbk8sZ0JBQWdCbU8sTUFBTSxDQUFDLGtCQUF4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVOO0FBQUEsV0FmM047QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUNBLHVCQUFDLGNBQVcscUJBQW1CLE1BQUMsTUFBTSxDQUFDLENBQUN6RyxVQUFVLE9BQU0sc0JBQXFCLFNBQVMsTUFBTTtBQUFFb0wsa0JBQVksSUFBSTtBQUFHRSxxQkFBZSxFQUFFO0FBQUEsSUFBRyxHQUFHLE1BQU1WLFFBQVFsTyxTQUFTLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxvQkFBbUIsU0FBUSxhQUFZLFVBQVV5UCxxQkFBcUIsQ0FBQy9CLGtCQUFrQixNQUFNUSxRQUFRbE8sU0FBUyxTQUFTLFlBQVk7QUFDcFUsVUFBSSxDQUFDc0QsWUFBWSxDQUFDeUwsa0JBQWtCVTtBQUNoQztBQUNKLFVBQUk7QUFDQSxjQUFNekssV0FBV2dLLGlCQUFpQi9KLFFBQVE7QUFBRyxZQUFJLENBQUNELFNBQVU7QUFDNUQsY0FBTXNMLFlBQVksRUFBRS9PLE9BQU9vTixZQUFZO0FBQ3ZDLGNBQU00QixTQUFTLE1BQU1yQyxRQUFRaEosUUFBUSxFQUFFN0QsTUFBTSxFQUFFeU4sWUFBWUMsZUFBZTFSLEdBQUcsR0FBR3lILE1BQU0sRUFBRW9JLGlCQUFpQmxJLFNBQVNwQixTQUFTckMsT0FBT29OLFlBQVksRUFBRSxDQUFDO0FBQ2pKLGNBQU02QixZQUFZLEVBQUU1TSxTQUFTMk0sT0FBT2pULEtBQUtzRyxTQUFTQyxRQUFReU0sVUFBVTtBQUNwRSxZQUFJdEIsaUJBQWlCM0osVUFBVW1MLFdBQVdGLFNBQVMsR0FBRztBQUFFNUIsc0JBQVksSUFBSTtBQUFHRSx5QkFBZSxFQUFFO0FBQUEsUUFBRztBQUFBLE1BQ25HLFNBQ090SixPQUFPO0FBQUUwSix5QkFBaUJ6SixPQUFPRCxLQUFLO0FBQUEsTUFBRztBQUFBLElBQ3BELEdBQUcsa0NBWHFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXbkosR0FDakI7QUFBQSw2QkFBQyxlQUFZLE9BQU80SSxRQUFRNUksU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLGlCQUFjLFFBQVEwSixrQkFBa0IsUUFBUSxFQUFFek4sT0FBTyx3Q0FBd0MsR0FBRyxNQUFNMk0sUUFBUWxPLFdBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkg7QUFBQSxNQUMzSCx1QkFBQyxjQUNHO0FBQUEsK0JBQUMsU0FBTSxVQUFTLFdBQVUsMkdBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUg7QUFBQSxRQUNwSDZPLGVBQWU1SSxhQUFhLHVCQUFDLGNBQVcsTUFBSyxVQUFTLGlEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDdkY0SSxlQUFlL0ksV0FBVyx1QkFBQyxjQUFZO0FBQUEsaUNBQUMsZUFBWSxPQUFPK0ksZUFBZXZKLFNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFBRSx1QkFBQyxVQUFPLFNBQVMsTUFBTTtBQUFFLGlCQUFLdUosZUFBZXRLLFFBQVE7QUFBQSxVQUFHLEdBQUcsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsYUFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5STtBQUFBLFFBQ25LMkssZ0JBQWdCUCxZQUFZbE4sSUFBSSxDQUFDZ0MsTUFBTTBELFVBQVU7QUFDOUMsZ0JBQU1zSixtQkFBbUIxQixlQUFleE4sTUFBTWdDLEtBQUssQ0FBQWMsU0FBUUEsS0FBS2lMLGdCQUFnQjdMLEtBQUs2TCxXQUFXLEdBQUd2TixZQUFZO0FBQy9HLGdCQUFNMk8sa0JBQWtCLENBQUM1TixPQUFPNk0sVUFBVWxNLEtBQUttTSxnQkFBZ0IsS0FBS25NLEtBQUttTSxtQkFBbUIsS0FBS25NLEtBQUttTSxtQkFBbUJhO0FBQ3pILGlCQUFPLHVCQUFDLGNBQ0o7QUFBQSxtQ0FBQyxjQUFZaE4sZUFBSzZMLGVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThCO0FBQUEsWUFDOUIsdUJBQUMsYUFBVSxPQUFNLGlCQUFnQixNQUFLLFVBQVMsWUFBWSxFQUFFYSxLQUFLLEdBQUdDLEtBQUtLLGtCQUFrQkosTUFBTSxFQUFFLEdBQUcsT0FBT3ZOLE9BQU82TixNQUFNbE4sS0FBS21NLGdCQUFnQixJQUFJLEtBQUtuTSxLQUFLbU0sa0JBQWtCLE9BQU9jLGlCQUFpQixZQUFZQSxrQkFBa0IsMkJBQTJCRCxnQkFBZ0IsTUFBTSxVQUFVQSxnQkFBZ0Isc0JBQXNCLFVBQVUsQ0FBQTdLLFVBQVNnSixlQUFlLENBQUFwTCxZQUFXQSxRQUFRL0IsSUFBSSxDQUFDNEMsTUFBTXVNLFFBQVF6SixVQUFVeUosTUFBTSxFQUFFLEdBQUd2TSxNQUFNdUwsa0JBQWtCaEssTUFBTUksT0FBT3JELFVBQVUsS0FBS0csT0FBTytOLE1BQU0vTixPQUFPOEMsTUFBTUksT0FBT3JELEtBQUssRUFBRSxJQUFJMEIsSUFBSSxDQUFDLEtBQXpnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyZ0I7QUFBQSxZQUMzZ0IsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxjQUFhLE9BQU9aLEtBQUtxTixhQUFhLFVBQVUsQ0FBQWxMLFVBQVNnSixlQUFlLENBQUFwTCxZQUFXQSxRQUFRL0IsSUFBSSxDQUFDNEMsTUFBTXVNLFFBQVF6SixVQUFVeUosTUFBTSxFQUFFLEdBQUd2TSxNQUFNeU0sYUFBYWxMLE1BQU1JLE9BQU9yRCxNQUFpQyxJQUFJMEIsSUFBSSxDQUFDLEdBQUc7QUFBQSxxQ0FBQyxZQUFTLE9BQU0sZUFBYyxzQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUFXLHVCQUFDLFlBQVMsT0FBTSxZQUFXLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQVcsdUJBQUMsWUFBUyxPQUFNLFdBQVUsdUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsaUJBQTFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFZO0FBQUEsWUFDclksdUJBQUMsYUFBVSxPQUFNLHFCQUFvQixPQUFPWixLQUFLc0csUUFBUSxPQUFPLENBQUN0RyxLQUFLc0csT0FBT3JLLEtBQUssS0FBSzlELGdCQUFnQjZILEtBQUtzRyxNQUFNLElBQUksS0FBTyxZQUFZLEdBQUduTyxnQkFBZ0I2SCxLQUFLc0csTUFBTSxDQUFDLGdCQUFnQixVQUFVLENBQUFuRSxVQUFTZ0osZUFBZSxDQUFBcEwsWUFBV0EsUUFBUS9CLElBQUksQ0FBQzRDLE1BQU11TSxRQUFRekosVUFBVXlKLE1BQU0sRUFBRSxHQUFHdk0sTUFBTTBGLFFBQVFuRSxNQUFNSSxPQUFPckQsTUFBTSxJQUFJMEIsSUFBSSxDQUFDLEtBQS9UO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlVO0FBQUEsWUFDalUsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFRO0FBQUEsZUFMWVosS0FBSzZMLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTVA7QUFBQSxRQUNKLENBQUM7QUFBQSxXQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQW5FRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0VQO0FBQ0o7QUFBQy9CLElBaEhlRCxhQUFXO0FBQUEsVUFDTjdSLFVBQ0FmLGlCQUNLZ0IsUUFDRUEsUUFDQ0EsUUFDWkosUUFBbUNLLGNBT2pDSCxhQUNBRCxZQUNDQSxZQUVZRCxRQUdMQSxRQUVFM0IsaUJBQWlCO0FBQUE7QUFBQSxNQXRCOUIyVDtBQWtIaEIsU0FBU3JKLGNBQWNpRSxPQUFjO0FBQ2pDLFNBQU8sRUFBRXRFLFNBQVNzRSxNQUFNdEUsU0FBU0MsUUFBUSxFQUFFN0YsWUFBWWtLLE1BQU1sSyxZQUFZcUMsZ0JBQWdCNkgsTUFBTTdILGtCQUFrQixJQUFJRSxXQUFXMkgsTUFBTXpILGFBQWFFLFdBQVd1SCxNQUFNckgscUJBQXFCLElBQUlYLE9BQU8sT0FBT2dJLE1BQU1oSSxVQUFVLFdBQVdnSSxNQUFNaEksUUFBUSxJQUFJcUIsT0FBTzJHLE1BQU0zRyxNQUFNRSxJQUFJLENBQUFnQyxVQUFTLEVBQUU5QixXQUFXOEIsS0FBSzlCLFdBQVdJLFVBQVVDLE9BQU95QixLQUFLMUIsUUFBUSxFQUFFLEVBQUUsRUFBRSxFQUFFO0FBQy9WO0FBRUEsU0FBU2tOLHlCQUF5QjVLLE1BQWtCO0FBQ2hELFFBQU05QyxRQUFtQzhDLEtBQUs5QyxNQUFNRSxJQUFJLENBQUFnQyxVQUFTO0FBQUEsSUFDN0Q2TCxhQUFhN0wsS0FBSzZMO0FBQUFBLElBQWFNLGtCQUFrQm5NLEtBQUsxQjtBQUFBQSxJQUN0RCtPLGFBQWFyTixLQUFLcU4sZ0JBQWdCLFlBQVksZ0JBQWdCck4sS0FBS3FOO0FBQUFBLElBQ25FL0csUUFBUXRHLEtBQUtxTixnQkFBZ0IsWUFBWSwwQ0FBMENyTixLQUFLc0c7QUFBQUEsRUFDNUYsRUFBRTtBQUNGLFNBQU8sRUFBRW5HLFNBQVNTLEtBQUtULFNBQVNDLFFBQVEsRUFBRXRDLE1BQU0sRUFBRTtBQUN0RDtBQUFDLElBQUF3UCxJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFKLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlTGlzdFJldHVybiIsImRyYWZ0RXF1YWwiLCJ1c2VWZXJzaW9uZWREcmFmdCIsIm1hcmtEcmFmdENsZWFuIiwidXNlRHJhZnRGb3JtIiwiRHJhZnRDb25mbGljdCIsIkFjdGlvbkdyb3VwIiwiRmllbGRHcm91cCIsIkZvcm1GaWVsZHMiLCJQYWdlU2VjdGlvbnMiLCJTZWN0aW9uR3JpZCIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiRGl2aWRlciIsIkljb25CdXR0b24iLCJNZW51SXRlbSIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsIkRlbGV0ZU91dGxpbmVSb3VuZGVkIiwiQWRkUm91bmRlZCIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VQYWdlZEFwaSIsInVzZVNjb3BlIiwidXNlQ2FuIiwidXNlTGlzdFF1ZXJ5IiwiY29kZVBvaW50TGVuZ3RoIiwibGltaXRDb2RlUG9pbnRzIiwiZGF0ZVRpbWUiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJEYXRhVGFibGUiLCJRdWVyeVN0YXRlIiwiVG9vbGJhciIsIlBhZ2VyIiwiU3RhdHVzIiwiQW1vdW50IiwiTXV0YXRpb25CdXR0b24iLCJFZGl0RGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJDb25maXJtRGlhbG9nIiwiUm91dGVMaW5rIiwiRGV0YWlsTGluZSIsIkxvb2t1cExvYWRNb3JlIiwibGF5b3V0U3giLCJPcmRlcnNQYWdlIiwiX3MiLCJzaG9wIiwibmF2aWdhdGUiLCJsaXN0IiwicXVlcnkiLCJpZCIsImRhdGEiLCJvIiwia2V5IiwibGFiZWwiLCJyZW5kZXIiLCJ0eXBvZ3JhcGh5IiwiZm9udFdlaWdodCIsInN0cm9uZyIsImNyZWF0ZWRBdCIsInRpbWV6b25lIiwiY3VzdG9tZXJJZCIsImFsaWduIiwidG90YWwiLCJvcmRlclN0YXRlIiwiZnVsZmlsbG1lbnRTdGF0ZSIsInBheW1lbnRTdGF0ZSIsInBhZ2UiLCJEcmFmdEZvcm0iLCJpbml0aWFsIiwib25TYXZlZCIsIm9uQnVzeUNoYW5nZSIsIl9zMiIsInBhcmFtcyIsImNyZWF0ZWQiLCJzZXRDcmVhdGVkIiwicmVzb3VyY2UiLCJjYW5SZWFkQ3VzdG9tZXJzIiwiY2FuUmVhZFByb2R1Y3RzIiwiY2FuUmVhZENvbnZlcnNhdGlvbnMiLCJjYW5Xcml0ZU9yZGVycyIsImN1c3RvbWVyU2VhcmNoIiwic2V0Q3VzdG9tZXJTZWFyY2giLCJwcm9kdWN0U2VhcmNoIiwic2V0UHJvZHVjdFNlYXJjaCIsImN1c3RvbWVycyIsInEiLCJ0cmltIiwidW5kZWZpbmVkIiwibGltaXQiLCJwcm9kdWN0cyIsImNyZWF0ZSIsInVwZGF0ZSIsInBlbmRpbmciLCJpbml0aWFsTm90ZXMiLCJub3RlcyIsInNldEN1c3RvbWVyIiwiZ2V0IiwiY29udmVyc2F0aW9uSWQiLCJzZXRDb252ZXJzYXRpb24iLCJ3YXJlaG91c2UiLCJzZXRXYXJlaG91c2UiLCJ3YXJlaG91c2VJZCIsImRlZmF1bHRXYXJlaG91c2VJZCIsImFkZHJlc3NJZCIsInNldEFkZHJlc3MiLCJzaGlwcGluZ0FkZHJlc3NJZCIsIm1ldGhvZCIsInNldE1ldGhvZCIsInBheW1lbnRNZXRob2QiLCJzZXROb3RlcyIsIndhcmVob3VzZXMiLCJzdGF0dXMiLCJhZGRyZXNzZXMiLCJwYXRoIiwiY29udiIsImxpbmVzIiwic2V0TGluZXMiLCJtYXAiLCJsIiwidmFyaWFudElkIiwidmFyaWFudExhYmVsIiwibmFtZSIsInNrdSIsInF1YW50aXR5IiwiU3RyaW5nIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInZhcmlhbnRzIiwiZmlsdGVyIiwicCIsImZsYXRNYXAiLCJ2IiwiYWN0aXZlIiwicHJvZHVjdE5hbWUiLCJsaW5lUXVhbnRpdHlFcnJvciIsInZhbHVlIiwibGVuZ3RoIiwidGVzdCIsIk51bWJlciIsImR1cGxpY2F0ZVZhcmlhbnRzIiwiU2V0IiwiQm9vbGVhbiIsInNpemUiLCJ2YWxpZCIsImV2ZXJ5IiwiY2hvb3NlVmFyaWFudCIsInNlbGVjdGVkIiwiZmluZCIsImN1cnJlbnQiLCJsaW5lIiwiZnJlc2giLCJvcmRlcklkIiwidmVyc2lvbiIsInZhbHVlcyIsImVkaXRvciIsImlkZW50aXR5Iiwic291cmNlIiwib3JkZXJTbmFwc2hvdCIsImRyYWZ0IiwiYXBwbHkiLCJleGlzdGluZyIsIml0ZW0iLCJyZWZyZXNoIiwicmVmZXRjaCIsInRocm93T25FcnJvciIsImNyZWF0aW9uQmFzZWxpbmUiLCJiaW5kRHJhZnQiLCJkaXJ0eSIsImZvcm1SZWYiLCJzYXZlIiwiYm9keSIsInJlc3BvbnNlIiwicHJlcGFyZWQiLCJwcmVwYXJlIiwiZXhlY3V0ZSIsInBhdGNoIiwiY2xlYW4iLCJjb21taXR0ZWQiLCJlcnJvciIsImZhaWxlZCIsInNlbGVjdGVkQ3VzdG9tZXIiLCJjdXN0b21lciIsImZvcm0iLCJlbGVtZW50IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImlzRXJyb3IiLCJlIiwidGFyZ2V0IiwiaXNQZW5kaW5nIiwiZGlzcGxheU5hbWUiLCJsb2FkZWRDb3VudCIsImhhc01vcmUiLCJpc0xvYWRpbmdNb3JlIiwibG9hZE1vcmUiLCJjb252ZXJzYXRpb24iLCJ4cyIsIm1kIiwiZmxleCIsIm1pbldpZHRoIiwic29tZSIsInciLCJjb2RlIiwiYSIsInJlY2lwaWVudCIsIm92ZXJmbG93V3JhcCIsImFkZHJlc3MiLCJpbmRleCIsInNlbGVjdGVkVmFyaWFudCIsInZhcmlhbnQiLCJxdWFudGl0eUludmFsaWQiLCJzbSIsIm90aGVyIiwiaW5wdXRNb2RlIiwibWF4V2lkdGgiLCJhbGlnblNlbGYiLCJOZXdPcmRlclBhZ2UiLCJfczMiLCJPcmRlckRldGFpbFBhZ2UiLCJzaW11bGF0ZUN1c3RvbWVyQ29uZmlybWF0aW9uIiwiX3M0IiwibGlzdEhyZWYiLCJvcmRlciIsInF1b3RlT3AiLCJyZWNvcmQiLCJjb25maXJtIiwiY2FuY2VsIiwicGF5IiwicmVmdW5kIiwicXVvdGUiLCJzZXRRdW90ZSIsImNvbmZpcm1hdGlvbiIsInNldENvbmZpcm1hdGlvbiIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwiYWN0aW9uIiwic2V0QWN0aW9uIiwic2V0RXJyb3IiLCJlZGl0QnVzeSIsInNldEVkaXRCdXN5IiwiaGFzaCIsInNldEhhc2giLCJzZXRJZGVudGl0eSIsIm1lc3NhZ2VJZCIsInNldE1lc3NhZ2UiLCJhbW91bnQiLCJzZXRBbW91bnQiLCJyZWZlcmVuY2UiLCJzZXRSZWZlcmVuY2UiLCJldmlkZW5jZVJlZiIsInNldEV2aWRlbmNlIiwicmVhc29uIiwic2V0UmVhc29uIiwibm93TXMiLCJzZXROb3dNcyIsIkRhdGUiLCJub3ciLCJzZXJ2ZXJPZmZzZXRNcyIsInNldFNlcnZlck9mZnNldE1zIiwic3luY2hyb25pemVBcGlUaW1lIiwiYXNPZiIsImFwaVRpbWUiLCJwYXJzZSIsImlzRmluaXRlIiwidGltZXIiLCJ3aW5kb3ciLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJlZmZlY3RpdmVOb3dNcyIsInF1b3RlRXhwaXJlZCIsImV4cGlyZXNBdCIsImNvbmZpcm1hdGlvbkV4cGlyZWQiLCJvcmRlclZlcnNpb24iLCJjb2xsZWN0IiwiciIsInF1b3RlSWQiLCJxdW90ZUhhc2giLCJxdW90ZVZlcnNpb24iLCJjdXN0b21lcklkZW50aXR5SWQiLCJzb3VyY2VNZXNzYWdlSWQiLCJtZXRhIiwibW9ja0NvbmZpcm0iLCJldmlkZW5jZSIsIkVycm9yIiwicmVxdWVzdENsb3NlIiwiYnVzeSIsImxnIiwidW5pdFByaWNlIiwibGluZVRvdGFsIiwic3VyZmFjZSIsImluc2V0IiwidGV4dEFsaWduIiwic2hpcHBpbmdBZGRyZXNzU25hcHNob3QiLCJsaW5lMSIsInByb3ZpbmNlIiwiam9pbiIsInByZXBUYXNrSWQiLCJhbGxvd2VkQWN0aW9ucyIsImluY2x1ZGVzIiwic3RhdGVHYXAiLCJ3YXJuaW5ncyIsImkiLCJleHBlY3RlZFZlcnNpb24iLCJjdXN0b21lckNvbmZpcm1hdGlvbklkIiwiY3VycmVuY3kiLCJwYXltZW50UmVmZXJlbmNlIiwiUmV0dXJuc1BhZ2UiLCJfczUiLCJjYW5SZWFkT3JkZXJzIiwiY2FuQ3JlYXRlUmV0dXJuIiwiY2FuSW5zcGVjdFJldHVybiIsIm9yZGVyU2VhcmNoSW5wdXQiLCJzZXRPcmRlclNlYXJjaElucHV0Iiwib3JkZXJTZWFyY2giLCJzZXRPcmRlclNlYXJjaCIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJvcmRlcnMiLCJpbnNwZWN0Iiwib3BlbiIsInNldE9wZW4iLCJzZXRPcmRlciIsInF1YW50aXRpZXMiLCJzZXRRdWFudGl0aWVzIiwic2VsZWN0ZWRPcmRlckRldGFpbCIsInNlbGVjdGVkT3JkZXIiLCJzZXRTZWxlY3RlZCIsImluc3BlY3Rpb25zIiwic2V0SW5zcGVjdGlvbnMiLCJzZWxlY3RlZFJldHVybiIsInJlc291cmNlSWQiLCJpbnNwZWN0aW9uQ2FzZSIsImluc3BlY3Rpb25FZGl0b3IiLCJyZXR1cm5JbnNwZWN0aW9uU25hcHNob3QiLCJkZXRhaWxzUmVhZHkiLCJiYXNlbGluZSIsImVkaXRJbnNwZWN0aW9uIiwicmVxdWVzdGVkTGluZXMiLCJvcmRlckxpbmVJZCIsImludmFsaWQiLCJjcmVhdGVJbnZhbGlkIiwiaW5zcGVjdGlvbkludmFsaWQiLCJyZXR1cm5lZCIsImlzSW50ZWdlciIsImFjY2VwdGVkUXVhbnRpdHkiLCJub3RpY2UiLCJhZnRlckdhcCIsInN0YXRlIiwicmVmdW5kT2JsaWdhdGlvbiIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwiZmllbGQiLCJtaW4iLCJtYXgiLCJzdGVwIiwic3VibWl0dGVkIiwicmVzdWx0IiwicGVyc2lzdGVkIiwicmV0dXJuZWRRdWFudGl0eSIsImludmFsaWRRdWFudGl0eSIsImlzTmFOIiwicm93IiwiTmFOIiwiZGlzcG9zaXRpb24iLCJfYyIsIl9jMiIsIl9jMyIsIl9jNCIsIl9jNSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VMaXN0UmV0dXJufSBmcm9tICdAL3NoYXJlZC9tb2RlbC9saXN0LXJldHVybic7XHJcbmltcG9ydCB7IGRyYWZ0RXF1YWwsIHVzZVZlcnNpb25lZERyYWZ0IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvdmVyc2lvbmVkLWRyYWZ0JztcclxuaW1wb3J0IHsgbWFya0RyYWZ0Q2xlYW4sIHVzZURyYWZ0Rm9ybSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XHJcbmltcG9ydCB7IERyYWZ0Q29uZmxpY3QgfSBmcm9tICdAL3NoYXJlZC91aS9kcmFmdC1jb25mbGljdCc7XHJcbmltcG9ydCB7IEFjdGlvbkdyb3VwLCBGaWVsZEdyb3VwLCBGb3JtRmllbGRzLCBQYWdlU2VjdGlvbnMsIFNlY3Rpb25HcmlkIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB2aXN1YWxTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL3Zpc3VhbCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIERpdmlkZXIsIEljb25CdXR0b24sIE1lbnVJdGVtLCBTdGFjaywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCBEZWxldGVPdXRsaW5lUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL0RlbGV0ZU91dGxpbmVSb3VuZGVkJztcclxuaW1wb3J0IEFkZFJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BZGRSb3VuZGVkJztcclxuaW1wb3J0IHR5cGUgeyBPcmRlciwgT3JkZXJRdW90ZSwgQ3VzdG9tZXJDb25maXJtYXRpb25SZXF1ZXN0LCBDdXN0b21lckNvbmZpcm1hdGlvbiwgUmV0dXJuQ2FzZSwgUmV0dXJuSW5zcGVjdGlvbiB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xyXG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQsIHVzZVBhZ2VkQXBpIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcclxuaW1wb3J0IHsgdXNlU2NvcGUsIHVzZUNhbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcclxuaW1wb3J0IHsgdXNlTGlzdFF1ZXJ5IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZmlsdGVycyc7XHJcbmltcG9ydCB7IGNvZGVQb2ludExlbmd0aCwgbGltaXRDb2RlUG9pbnRzLCBkYXRlVGltZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIsIFBhbmVsLCBEYXRhVGFibGUsIFF1ZXJ5U3RhdGUsIFRvb2xiYXIsIFBhZ2VyLCBTdGF0dXMsIEFtb3VudCwgTXV0YXRpb25CdXR0b24sIEVkaXREaWFsb2csIEVycm9yTm90aWNlLCBDb25maXJtRGlhbG9nLCBSb3V0ZUxpbmssIERldGFpbExpbmUsIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyc1BhZ2UoKSB7IGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTsgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpOyBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0T3JkZXJzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0T3JkZXJzJykgfSk7IHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwixJDGoW4gaMOgbmdcIiBzdWJ0aXRsZT1cIlTDoWNoIHJpw6puZyB0cuG6oW5nIHRow6FpIMSRxqFuLCBnaWFvIGjDoG5nIHbDoCB0aGFuaCB0b8Ohbi5cIiBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9yZGVycy53cml0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3MvJHtzaG9wLmlkfS9vcmRlcnMvbmV3YCl9PlThuqFvIMSRxqFuIGjDoG5nPC9NdXRhdGlvbkJ1dHRvbj59Lz48UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdE9yZGVyc1wiIHBsYWNlaG9sZGVyPVwiVMOsbSBtw6MgxJHGoW4gaG/hurdjIGtow6FjaCBow6BuZ+KAplwiLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJEYW5oIHPDoWNoIMSRxqFuIGjDoG5nXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17byA9PiBvLmlkfSBjb2x1bW5zPXtbXHJcbiAgICB7XHJcbiAgICAgICAga2V5OiAnaWQnLCBsYWJlbDogJ8SQxqFuIGjDoG5nJywgcmVuZGVyOiBvID0+IDxTdGFjaz48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT57by5pZH08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e2RhdGVUaW1lKG8uY3JlYXRlZEF0LCBzaG9wLnRpbWV6b25lKX08L1R5cG9ncmFwaHk+PC9TdGFjaz5cclxuICAgIH0sXHJcbiAgICB7IGtleTogJ2N1c3RvbWVyJywgbGFiZWw6ICdLaMOhY2gnLCByZW5kZXI6IG8gPT4gYE3DoyBraMOhY2ggaMOgbmc6ICR7by5jdXN0b21lcklkfWAgfSwgeyBrZXk6ICd0b3RhbCcsIGxhYmVsOiAnVOG7lW5nIHRp4buBbicsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IG8gPT4gPEFtb3VudCB2YWx1ZT17by50b3RhbH0vPiB9LCB7IGtleTogJ29yZGVyJywgbGFiZWw6ICfEkMahbicsIHJlbmRlcjogbyA9PiA8U3RhdHVzIHZhbHVlPXtvLm9yZGVyU3RhdGV9Lz4gfSwgeyBrZXk6ICdzaGlwcGluZycsIGxhYmVsOiAnR2lhbyBow6BuZycsIHJlbmRlcjogbyA9PiA8U3RhdHVzIHZhbHVlPXtvLmZ1bGZpbGxtZW50U3RhdGV9Lz4gfSwgeyBrZXk6ICdwYXltZW50JywgbGFiZWw6ICdUaeG7gW4nLCByZW5kZXI6IG8gPT4gPFN0YXR1cyB2YWx1ZT17by5wYXltZW50U3RhdGV9Lz4gfSwgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJycsIHJlbmRlcjogbyA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9vcmRlcnMvJHtvLmlkfWB9PlhlbSDEkcahbjwvUm91dGVMaW5rPiB9XHJcbl19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PC8+OyB9XHJcbmZ1bmN0aW9uIERyYWZ0Rm9ybSh7IGluaXRpYWwsIG9uU2F2ZWQsIG9uQnVzeUNoYW5nZSB9OiB7XHJcbiAgICBpbml0aWFsPzogT3JkZXI7XHJcbiAgICBvblNhdmVkOiAob3JkZXI6IE9yZGVyKSA9PiB2b2lkO1xyXG4gICAgb25CdXN5Q2hhbmdlPzogKGJ1c3k6IGJvb2xlYW4pID0+IHZvaWQ7XHJcbn0pIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IFtwYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XHJcbiAgICBjb25zdCBbY3JlYXRlZCwgc2V0Q3JlYXRlZF0gPSB1c2VTdGF0ZTxPcmRlciB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgcmVzb3VyY2UgPSBpbml0aWFsIHx8IGNyZWF0ZWQ7XHJcbiAgICBjb25zdCBjYW5SZWFkQ3VzdG9tZXJzID0gdXNlQ2FuKCdjdXN0b21lcnMucmVhZCcpO1xyXG4gICAgY29uc3QgY2FuUmVhZFByb2R1Y3RzID0gdXNlQ2FuKCdjYXRhbG9nLnJlYWQnKTtcclxuICAgIGNvbnN0IGNhblJlYWRDb252ZXJzYXRpb25zID0gdXNlQ2FuKCdjb252ZXJzYXRpb25zLnJlYWQnKTtcclxuICAgIGNvbnN0IGNhbldyaXRlT3JkZXJzID0gdXNlQ2FuKCdvcmRlcnMud3JpdGUnKTtcclxuICAgIGNvbnN0IFtjdXN0b21lclNlYXJjaCwgc2V0Q3VzdG9tZXJTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW3Byb2R1Y3RTZWFyY2gsIHNldFByb2R1Y3RTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgY3VzdG9tZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lcnMnLCB7IHF1ZXJ5OiB7IHE6IGN1c3RvbWVyU2VhcmNoLnRyaW0oKSB8fCB1bmRlZmluZWQsIGxpbWl0OiAyMCB9IH0sIGNhblJlYWRDdXN0b21lcnMpO1xyXG4gICAgY29uc3QgcHJvZHVjdHMgPSB1c2VQYWdlZEFwaSgnbGlzdFByb2R1Y3RzJywgeyBxdWVyeTogeyBxOiBwcm9kdWN0U2VhcmNoLnRyaW0oKSB8fCB1bmRlZmluZWQsIGxpbWl0OiAyMCB9IH0sIGNhblJlYWRQcm9kdWN0cyk7XHJcbiAgICBjb25zdCBjcmVhdGUgPSB1c2VDb21tYW5kKCdjcmVhdGVPcmRlcicsIFsnbGlzdE9yZGVycyddKTtcclxuICAgIGNvbnN0IHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZU9yZGVyRHJhZnQnLCBbJ2dldE9yZGVyJywgJ2xpc3RPcmRlcnMnXSk7XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4geyBvbkJ1c3lDaGFuZ2U/LihjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZyk7IH0sIFtjcmVhdGUucGVuZGluZywgdXBkYXRlLnBlbmRpbmcsIG9uQnVzeUNoYW5nZV0pO1xyXG4gICAgY29uc3QgaW5pdGlhbE5vdGVzID0gdHlwZW9mIGluaXRpYWw/Lm5vdGVzID09PSAnc3RyaW5nJyA/IGluaXRpYWwubm90ZXMgOiAnJztcclxuICAgIGNvbnN0IFtjdXN0b21lcklkLCBzZXRDdXN0b21lcl0gPSB1c2VTdGF0ZShpbml0aWFsPy5jdXN0b21lcklkIHx8IHBhcmFtcy5nZXQoJ2N1c3RvbWVySWQnKSB8fCAnJyksIFtjb252ZXJzYXRpb25JZCwgc2V0Q29udmVyc2F0aW9uXSA9IHVzZVN0YXRlKGluaXRpYWw/LmNvbnZlcnNhdGlvbklkIHx8IHBhcmFtcy5nZXQoJ2NvbnZlcnNhdGlvbklkJykgfHwgJycpLCBbd2FyZWhvdXNlLCBzZXRXYXJlaG91c2VdID0gdXNlU3RhdGUoaW5pdGlhbD8ud2FyZWhvdXNlSWQgfHwgc2hvcC5kZWZhdWx0V2FyZWhvdXNlSWQpLCBbYWRkcmVzc0lkLCBzZXRBZGRyZXNzXSA9IHVzZVN0YXRlKGluaXRpYWw/LnNoaXBwaW5nQWRkcmVzc0lkIHx8ICcnKSwgW21ldGhvZCwgc2V0TWV0aG9kXSA9IHVzZVN0YXRlPCdjb2QnIHwgJ3ByZXBheSc+KGluaXRpYWw/LnBheW1lbnRNZXRob2QgfHwgJ2NvZCcpLCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKGluaXRpYWxOb3Rlcyk7XHJcbiAgICBjb25zdCB3YXJlaG91c2VzID0gdXNlUGFnZWRBcGkoJ2xpc3RXYXJlaG91c2VzJywgeyBxdWVyeTogeyBzdGF0dXM6ICdhY3RpdmUnLCBsaW1pdDogMjAgfSB9LCB1c2VDYW4oJ2ludmVudG9yeS5yZWFkJykpO1xyXG4gICAgY29uc3QgYWRkcmVzc2VzID0gdXNlUGFnZWRBcGkoJ2xpc3RDdXN0b21lckFkZHJlc3NlcycsIHsgcGF0aDogeyBjdXN0b21lcklkIH0sIHF1ZXJ5OiB7IHN0YXR1czogJ2FjdGl2ZScsIGxpbWl0OiAyMCB9IH0sICEhY3VzdG9tZXJJZCAmJiBjYW5SZWFkQ3VzdG9tZXJzKTtcclxuICAgIGNvbnN0IGNvbnYgPSB1c2VQYWdlZEFwaSgnbGlzdENvbnZlcnNhdGlvbnMnLCB7IHF1ZXJ5OiB7IGN1c3RvbWVySWQ6IGN1c3RvbWVySWQgfHwgdW5kZWZpbmVkLCBsaW1pdDogMjAgfSB9LCBjYW5SZWFkQ29udmVyc2F0aW9ucyAmJiAhIWN1c3RvbWVySWQpO1xyXG4gICAgY29uc3QgW2xpbmVzLCBzZXRMaW5lc10gPSB1c2VTdGF0ZShpbml0aWFsPy5saW5lcy5tYXAobCA9PiAoeyBrZXk6IGwuaWQsIHZhcmlhbnRJZDogbC52YXJpYW50SWQsIHZhcmlhbnRMYWJlbDogYCR7bC5uYW1lfSDCtyAke2wuc2t1fWAsIHF1YW50aXR5OiBTdHJpbmcobC5xdWFudGl0eSkgfSkpIHx8IFt7IGtleTogY3J5cHRvLnJhbmRvbVVVSUQoKSwgdmFyaWFudElkOiAnJywgdmFyaWFudExhYmVsOiAnJywgcXVhbnRpdHk6ICcxJyB9XSk7XHJcbiAgICBjb25zdCB2YXJpYW50cyA9IHByb2R1Y3RzLmRhdGE/LmRhdGEuZmlsdGVyKHAgPT4gcC5zdGF0dXMgPT09ICdhY3RpdmUnKS5mbGF0TWFwKHAgPT4gcC52YXJpYW50cy5maWx0ZXIodiA9PiB2LmFjdGl2ZSkubWFwKHYgPT4gKHsgLi4udiwgcHJvZHVjdE5hbWU6IHAubmFtZSB9KSkpIHx8IFtdO1xyXG4gICAgY29uc3QgbGluZVF1YW50aXR5RXJyb3IgPSAodmFsdWU6IHN0cmluZykgPT4gdmFsdWUubGVuZ3RoID4gMCAmJiAoIS9eXFxkKyQvLnRlc3QodmFsdWUpIHx8IE51bWJlcih2YWx1ZSkgPCAxIHx8IE51bWJlcih2YWx1ZSkgPiAxXzAwMF8wMDApO1xyXG4gICAgY29uc3QgZHVwbGljYXRlVmFyaWFudHMgPSBuZXcgU2V0KGxpbmVzLm1hcChsID0+IGwudmFyaWFudElkKS5maWx0ZXIoQm9vbGVhbikpLnNpemUgIT09IGxpbmVzLmZpbHRlcihsID0+IGwudmFyaWFudElkKS5sZW5ndGg7XHJcbiAgICBjb25zdCB2YWxpZCA9ICEhY3VzdG9tZXJJZCAmJiAhIXdhcmVob3VzZS50cmltKCkgJiYgbGluZXMubGVuZ3RoID4gMCAmJiBsaW5lcy5sZW5ndGggPD0gMTAwICYmIGxpbmVzLmV2ZXJ5KGwgPT4gbC52YXJpYW50SWQgJiYgIWxpbmVRdWFudGl0eUVycm9yKGwucXVhbnRpdHkpKSAmJiAhZHVwbGljYXRlVmFyaWFudHMgJiYgY29kZVBvaW50TGVuZ3RoKG5vdGVzKSA8PSAyXzAwMCAmJiAoaW5pdGlhbCAhPT0gdW5kZWZpbmVkIHx8IChjYW5SZWFkQ3VzdG9tZXJzICYmIGNhblJlYWRQcm9kdWN0cykpO1xyXG4gICAgY29uc3QgY2hvb3NlVmFyaWFudCA9IChrZXk6IHN0cmluZywgdmFyaWFudElkOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBjb25zdCBzZWxlY3RlZCA9IHZhcmlhbnRzLmZpbmQodiA9PiB2LmlkID09PSB2YXJpYW50SWQpO1xyXG4gICAgICAgIHNldExpbmVzKGN1cnJlbnQgPT4gY3VycmVudC5tYXAobGluZSA9PiBsaW5lLmtleSA9PT0ga2V5ID8geyAuLi5saW5lLCB2YXJpYW50SWQsIHZhcmlhbnRMYWJlbDogc2VsZWN0ZWQgPyBgJHtzZWxlY3RlZC5wcm9kdWN0TmFtZX0gwrcgJHtzZWxlY3RlZC5uYW1lfSDCtyAke3NlbGVjdGVkLnNrdX1gIDogbGluZS52YXJpYW50TGFiZWwgfSA6IGxpbmUpKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBmcmVzaCA9IHVzZUFwaSgnZ2V0T3JkZXInLCB7IHBhdGg6IHsgb3JkZXJJZDogcmVzb3VyY2U/LmlkIHx8ICcnIH0gfSwgISFyZXNvdXJjZSk7XHJcbiAgICBjb25zdCBjdXJyZW50ID0gZnJlc2guZGF0YSAmJiAoIXJlc291cmNlIHx8IGZyZXNoLmRhdGEuZGF0YS52ZXJzaW9uID49IHJlc291cmNlLnZlcnNpb24pID8gZnJlc2guZGF0YS5kYXRhIDogcmVzb3VyY2U7XHJcbiAgICBjb25zdCB2YWx1ZXMgPSB7IGN1c3RvbWVySWQsIGNvbnZlcnNhdGlvbklkLCB3YXJlaG91c2UsIGFkZHJlc3NJZCwgbm90ZXMsIGxpbmVzOiBsaW5lcy5tYXAobGluZSA9PiAoeyB2YXJpYW50SWQ6IGxpbmUudmFyaWFudElkLCBxdWFudGl0eTogbGluZS5xdWFudGl0eSB9KSkgfTtcclxuICAgIGNvbnN0IGVkaXRvciA9IHVzZVZlcnNpb25lZERyYWZ0KHtcclxuICAgICAgICBpZGVudGl0eTogYCR7c2hvcC5pZH06b3JkZXI6JHtyZXNvdXJjZT8uaWQgfHwgJ25ldyd9YCxcclxuICAgICAgICBzb3VyY2U6IGN1cnJlbnQgPyBvcmRlclNuYXBzaG90KGN1cnJlbnQpIDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGRyYWZ0OiB2YWx1ZXMsXHJcbiAgICAgICAgYXBwbHk6IHZhbHVlID0+IHtcclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXIodmFsdWUuY3VzdG9tZXJJZCk7IHNldENvbnZlcnNhdGlvbih2YWx1ZS5jb252ZXJzYXRpb25JZCk7IHNldFdhcmVob3VzZSh2YWx1ZS53YXJlaG91c2UpOyBzZXRBZGRyZXNzKHZhbHVlLmFkZHJlc3NJZCk7IHNldE5vdGVzKHZhbHVlLm5vdGVzKTtcclxuICAgICAgICAgICAgc2V0TGluZXMoZXhpc3RpbmcgPT4gdmFsdWUubGluZXMubWFwKGxpbmUgPT4gKHsgLi4ubGluZSwga2V5OiBleGlzdGluZy5maW5kKGl0ZW0gPT4gaXRlbS52YXJpYW50SWQgPT09IGxpbmUudmFyaWFudElkKT8ua2V5IHx8IGNyeXB0by5yYW5kb21VVUlEKCksIHZhcmlhbnRMYWJlbDogZXhpc3RpbmcuZmluZChpdGVtID0+IGl0ZW0udmFyaWFudElkID09PSBsaW5lLnZhcmlhbnRJZCk/LnZhcmlhbnRMYWJlbCB8fCAnJyB9KSkpO1xyXG4gICAgICAgIH0sIHJlZnJlc2g6ICgpID0+IGZyZXNoLnJlZmV0Y2goeyB0aHJvd09uRXJyb3I6IHRydWUgfSksXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IFtjcmVhdGlvbkJhc2VsaW5lXSA9IHVzZVN0YXRlKCgpID0+ICh7IC4uLnZhbHVlcywgYWRkcmVzc0lkLCBtZXRob2QgfSkpO1xyXG4gICAgY29uc3QgYmluZERyYWZ0ID0gdXNlRHJhZnRGb3JtKHJlc291cmNlID8gZWRpdG9yLmRpcnR5IDogIWRyYWZ0RXF1YWwoY3JlYXRpb25CYXNlbGluZSwgeyAuLi52YWx1ZXMsIGFkZHJlc3NJZCwgbWV0aG9kIH0pKTtcclxuICAgIGNvbnN0IGZvcm1SZWYgPSB1c2VSZWY8SFRNTEZvcm1FbGVtZW50PihudWxsKTtcclxuICAgIGNvbnN0IHNhdmUgPSBhc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHsgY3VzdG9tZXJJZCwgY29udmVyc2F0aW9uSWQ6IGNvbnZlcnNhdGlvbklkIHx8IG51bGwsIHdhcmVob3VzZUlkOiB3YXJlaG91c2UsIGxpbmVzOiBsaW5lcy5tYXAobGluZSA9PiAoeyB2YXJpYW50SWQ6IGxpbmUudmFyaWFudElkLCBxdWFudGl0eTogTnVtYmVyKGxpbmUucXVhbnRpdHkpIH0pKSwgbm90ZXMgfTtcclxuICAgICAgICBsZXQgcmVzcG9uc2U6IEF3YWl0ZWQ8UmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlLmV4ZWN1dGU+PjtcclxuICAgICAgICBpZiAocmVzb3VyY2UpIHtcclxuICAgICAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBlZGl0b3IucHJlcGFyZSgpOyBpZiAoIXByZXBhcmVkKSByZXR1cm47XHJcbiAgICAgICAgICAgIHJlc3BvbnNlID0gYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IG9yZGVySWQ6IHJlc291cmNlLmlkIH0sIHZlcnNpb246IHByZXBhcmVkLnZlcnNpb24sIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgIC4uLihwcmVwYXJlZC5wYXRjaC5jdXN0b21lcklkICE9PSB1bmRlZmluZWQgPyB7IGN1c3RvbWVySWQ6IGJvZHkuY3VzdG9tZXJJZCB9IDoge30pLFxyXG4gICAgICAgICAgICAgICAgLi4uKHByZXBhcmVkLnBhdGNoLmNvbnZlcnNhdGlvbklkICE9PSB1bmRlZmluZWQgPyB7IGNvbnZlcnNhdGlvbklkOiBib2R5LmNvbnZlcnNhdGlvbklkIH0gOiB7fSksXHJcbiAgICAgICAgICAgICAgICAuLi4ocHJlcGFyZWQucGF0Y2gud2FyZWhvdXNlICE9PSB1bmRlZmluZWQgPyB7IHdhcmVob3VzZUlkOiBib2R5LndhcmVob3VzZUlkIH0gOiB7fSksXHJcbiAgICAgICAgICAgICAgICAuLi4ocHJlcGFyZWQucGF0Y2guYWRkcmVzc0lkICE9PSB1bmRlZmluZWQgPyB7IHNoaXBwaW5nQWRkcmVzc0lkOiBhZGRyZXNzSWQgfHwgbnVsbCB9IDoge30pLFxyXG4gICAgICAgICAgICAgICAgLi4uKHByZXBhcmVkLnBhdGNoLmxpbmVzICE9PSB1bmRlZmluZWQgPyB7IGxpbmVzOiBib2R5LmxpbmVzIH0gOiB7fSksXHJcbiAgICAgICAgICAgICAgICAuLi4ocHJlcGFyZWQucGF0Y2gubm90ZXMgIT09IHVuZGVmaW5lZCA/IHsgbm90ZXM6IGJvZHkubm90ZXMgfSA6IHt9KSxcclxuICAgICAgICAgICAgfSB9KTtcclxuICAgICAgICB9IGVsc2UgcmVzcG9uc2UgPSBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHk6IHsgLi4uYm9keSwgcGF5bWVudE1ldGhvZDogbWV0aG9kLCBzaGlwcGluZ0FkZHJlc3NJZDogYWRkcmVzc0lkIHx8IG51bGwgfSB9KTtcclxuICAgICAgICBjb25zdCBjbGVhbiA9IGVkaXRvci5jb21taXR0ZWQob3JkZXJTbmFwc2hvdChyZXNwb25zZS5kYXRhKSwgdmFsdWVzLCBgJHtzaG9wLmlkfTpvcmRlcjoke3Jlc3BvbnNlLmRhdGEuaWR9YCk7XHJcbiAgICAgICAgaWYgKGNsZWFuKSB7IGlmIChmb3JtUmVmLmN1cnJlbnQpIG1hcmtEcmFmdENsZWFuKGZvcm1SZWYuY3VycmVudCk7IG9uU2F2ZWQocmVzcG9uc2UuZGF0YSk7IH1cclxuICAgICAgICBlbHNlIHNldENyZWF0ZWQocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikgeyBlZGl0b3IuZmFpbGVkKGVycm9yKTsgfSB9O1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRDdXN0b21lciA9IGN1c3RvbWVycy5kYXRhPy5kYXRhLmZpbmQoY3VzdG9tZXIgPT4gY3VzdG9tZXIuaWQgPT09IGN1c3RvbWVySWQpO1xyXG4gICAgcmV0dXJuIDxCb3ggY29tcG9uZW50PVwiZm9ybVwiIHJlZj17Zm9ybSA9PiB7IGNvbnN0IGVsZW1lbnQgPSBmb3JtIGFzIEhUTUxGb3JtRWxlbWVudCB8IG51bGw7IGZvcm1SZWYuY3VycmVudCA9IGVsZW1lbnQ7IGJpbmREcmFmdChlbGVtZW50KTsgfX0gb25TdWJtaXQ9e2V2ZW50ID0+IHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgaWYgKHZhbGlkKSB2b2lkIHNhdmUoKTsgfX0+PFBhZ2VTZWN0aW9ucyA+XHJcbiAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3IgfHwgdXBkYXRlLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17eyBjdXN0b21lcklkOiAnS2jDoWNoIGjDoG5nJywgY29udmVyc2F0aW9uSWQ6ICdI4buZaSB0aG/huqFpJywgd2FyZWhvdXNlOiAnS2hvIHh14bqldCcsIGFkZHJlc3NJZDogJ8SQ4buLYSBjaOG7iSBnaWFvIGjDoG5nJywgbm90ZXM6ICdHaGkgY2jDuicsIGxpbmVzOiAnRMOybmcgxJHGoW4gaMOgbmcnIH19IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfS8+XHJcbiAgICAgICAgeyFjYW5SZWFkQ3VzdG9tZXJzICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5C4bqhbiBj4bqnbiBxdXnhu4FuIGN1c3RvbWVycy5yZWFkIMSR4buDIHTDrG0gdsOgIHThuqFvIMSRxqFuIHbhu5tpIGtow6FjaCBow6BuZy4gxJDGoW4gbmjDoXAgaGnhu4duIGPDsyB24bqrbiBnaeG7ryBuZ3V5w6puIG3DoyBraMOhY2guPC9BbGVydD59XHJcbiAgICAgICAgeyFjYW5SZWFkUHJvZHVjdHMgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkLhuqFuIGPhuqduIHF1eeG7gW4gY2F0YWxvZy5yZWFkIMSR4buDIHTDrG0gdsOgIGNo4buNbiBz4bqjbiBwaOG6qW0gY2hvIMSRxqFuIGjDoG5nLjwvQWxlcnQ+fVxyXG4gICAgICAgIHtjdXN0b21lcnMuaXNFcnJvciAmJiA8RXJyb3JOb3RpY2UgZXJyb3I9e2N1c3RvbWVycy5lcnJvcn0vPn1cclxuICAgICAgICB7cHJvZHVjdHMuaXNFcnJvciAmJiA8RXJyb3JOb3RpY2UgZXJyb3I9e3Byb2R1Y3RzLmVycm9yfS8+fVxyXG4gICAgICAgIDxQYW5lbCB0aXRsZT1cIk5nxrDhu51pIG11YSB2w6AgZ2lhbyBow6BuZ1wiIGJvZHlNb2RlPVwiaW5zZXRcIj48Rm9ybUZpZWxkcyA+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJUw6xtIGtow6FjaCBow6BuZ1wiIHZhbHVlPXtjdXN0b21lclNlYXJjaH0gb25DaGFuZ2U9e2UgPT4gc2V0Q3VzdG9tZXJTZWFyY2goZS50YXJnZXQudmFsdWUpfSBkaXNhYmxlZD17IWNhblJlYWRDdXN0b21lcnN9IGhlbHBlclRleHQ9XCJUw6xtIHF1YSBsaXN0Q3VzdG9tZXJzIHbhu5tpIHE7IGNo4buJIGNo4buNbiBtw6MgZG8gQVBJIHRy4bqjIHbhu4EuXCIvPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIktow6FjaCBow6BuZ1wiIHZhbHVlPXtjdXN0b21lcklkfSBvbkNoYW5nZT17ZSA9PiB7IHNldEN1c3RvbWVyKGUudGFyZ2V0LnZhbHVlKTsgc2V0Q29udmVyc2F0aW9uKCcnKTsgc2V0QWRkcmVzcygnJyk7IH19IGRpc2FibGVkPXshY2FuUmVhZEN1c3RvbWVycyAmJiAhcmVzb3VyY2V9IHJlcXVpcmVkPXtjYW5SZWFkQ3VzdG9tZXJzfSBoZWxwZXJUZXh0PXtjYW5SZWFkQ3VzdG9tZXJzID8gKGN1c3RvbWVycy5pc1BlbmRpbmcgPyAnxJBhbmcgdOG6o2kga2jDoWNoIGjDoG5n4oCmJyA6IGN1c3RvbWVycy5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCA/ICdLaMO0bmcgdMOsbSB0aOG6pXkga2jDoWNoIHBow7kgaOG7o3AuJyA6ICFjdXN0b21lcklkID8gJ0No4buNbiBraMOhY2ggaMOgbmcgxJHhu4MgbMawdSDEkcahbiBuaMOhcC4nIDogdW5kZWZpbmVkKSA6IHVuZGVmaW5lZH0+XHJcbiAgICAgICAgICAgICAgICB7Y3VzdG9tZXJJZCAmJiAhc2VsZWN0ZWRDdXN0b21lciAmJiA8TWVudUl0ZW0gdmFsdWU9e2N1c3RvbWVySWR9PsSQYW5nIGdp4buvIG3DoyBraMOhY2g6IHtjdXN0b21lcklkfTwvTWVudUl0ZW0+fVxyXG4gICAgICAgICAgICAgICAge2N1c3RvbWVycy5kYXRhPy5kYXRhLm1hcChjdXN0b21lciA9PiA8TWVudUl0ZW0ga2V5PXtjdXN0b21lci5pZH0gdmFsdWU9e2N1c3RvbWVyLmlkfT57Y3VzdG9tZXIuZGlzcGxheU5hbWV9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwia2jDoWNoIGjDoG5nXCIgbG9hZGVkQ291bnQ9e2N1c3RvbWVycy5sb2FkZWRDb3VudH0gaGFzTW9yZT17Y3VzdG9tZXJzLmhhc01vcmV9IGJ1c3k9e2N1c3RvbWVycy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtjdXN0b21lcnMubG9hZE1vcmV9Lz5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJI4buZaSB0aG/huqFpIGxpw6puIHF1YW5cIiB2YWx1ZT17Y29udmVyc2F0aW9uSWR9IG9uQ2hhbmdlPXtlID0+IHNldENvbnZlcnNhdGlvbihlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXshY2FuUmVhZENvbnZlcnNhdGlvbnMgfHwgIWN1c3RvbWVySWR9IGhlbHBlclRleHQ9eyFjYW5SZWFkQ29udmVyc2F0aW9ucyA/ICdLaMO0bmcgY8OzIHF1eeG7gW4gxJHhu41jIGjhu5lpIHRob+G6oWk7IGxpw6puIGvhur90IGjhu5lpIHRob+G6oWkgbMOgIHTDuXkgY2jhu41uLicgOiB1bmRlZmluZWR9PlxyXG4gICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwiXCI+S2jDtG5nIGxpw6puIGvhur90PC9NZW51SXRlbT57Y29udi5kYXRhPy5kYXRhLmZpbHRlcihjb252ZXJzYXRpb24gPT4gY29udmVyc2F0aW9uLmN1c3RvbWVySWQgPT09IGN1c3RvbWVySWQpLm1hcChjb252ZXJzYXRpb24gPT4gPE1lbnVJdGVtIGtleT17Y29udmVyc2F0aW9uLmlkfSB2YWx1ZT17Y29udmVyc2F0aW9uLmlkfT57Y29udmVyc2F0aW9uLmRpc3BsYXlOYW1lfSDCtyB7Y29udmVyc2F0aW9uLmlkfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImjhu5lpIHRob+G6oWlcIiBsb2FkZWRDb3VudD17Y29udi5sb2FkZWRDb3VudH0gaGFzTW9yZT17Y29udi5oYXNNb3JlfSBidXN5PXtjb252LmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2NvbnYubG9hZE1vcmV9Lz5cclxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgbWQ6ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgbWQ6ICdzdGFydCcgfX0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIktobyB4deG6pXRcIiB2YWx1ZT17d2FyZWhvdXNlfSBvbkNoYW5nZT17ZSA9PiBzZXRXYXJlaG91c2UoZS50YXJnZXQudmFsdWUpfSBmdWxsV2lkdGggZGlzYWJsZWQ9e2NyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7d2FyZWhvdXNlICYmICF3YXJlaG91c2VzLmRhdGE/LmRhdGEuc29tZSh3ID0+IHcuaWQgPT09IHdhcmVob3VzZSkgJiYgPE1lbnVJdGVtIHZhbHVlPXt3YXJlaG91c2V9PsSQYW5nIGdp4buvIGtobyB7d2FyZWhvdXNlfTwvTWVudUl0ZW0+fVxyXG4gICAgICAgICAgICAgICAgICAgIHt3YXJlaG91c2VzLmRhdGE/LmRhdGEubWFwKHcgPT4gPE1lbnVJdGVtIGtleT17dy5pZH0gdmFsdWU9e3cuaWR9Pnt3LmNvZGV9IMK3IHt3Lm5hbWV9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIsSQ4buLYSBjaOG7iSBnaWFvIGjDoG5nXCIgdmFsdWU9e2FkZHJlc3NJZH0gb25DaGFuZ2U9e2UgPT4gc2V0QWRkcmVzcyhlLnRhcmdldC52YWx1ZSl9IGZ1bGxXaWR0aCBkaXNhYmxlZD17IWN1c3RvbWVySWQgfHwgY3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19IGhlbHBlclRleHQ9XCJDaOG7iSBkw7luZyDEkeG7i2EgY2jhu4kgdGh14buZYyBraMOhY2ggxJHDoyBjaOG7jW4gZG8gQVBJIHRy4bqjIHbhu4E7IHRyxrDhu51uZyBi4buLIGNoZSB24bqrbiDEkcaw4bujYyBi4bqjbyB24buHLlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPkNoxrBhIGNo4buNbiDEkeG7i2EgY2jhu4k8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIHthZGRyZXNzSWQgJiYgIWFkZHJlc3Nlcy5kYXRhPy5kYXRhLnNvbWUoYSA9PiBhLmlkID09PSBhZGRyZXNzSWQpICYmIDxNZW51SXRlbSB2YWx1ZT17YWRkcmVzc0lkfT7EkGFuZyBnaeG7ryDEkeG7i2EgY2jhu4kge2FkZHJlc3NJZH08L01lbnVJdGVtPn1cclxuICAgICAgICAgICAgICAgICAgICB7YWRkcmVzc2VzLmRhdGE/LmRhdGEubWFwKGEgPT4gPE1lbnVJdGVtIGtleT17YS5pZH0gdmFsdWU9e2EuaWR9PnthLmxhYmVsIHx8IGDEkOG7i2EgY2jhu4kgJHthLmlkfWB9IMK3IHthLnJlY2lwaWVudCB8fCAnTmfGsOG7nWkgbmjhuq1uIMSRw6MgY2hlJ308L01lbnVJdGVtPil9XHJcbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e3dhcmVob3VzZXMuZXJyb3IgfHwgYWRkcmVzc2VzLmVycm9yfS8+XHJcbiAgICAgICAgICAgIHthZGRyZXNzSWQgJiYgPEZpZWxkR3JvdXAgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlRow7RuZyB0aW4gxJHhu4thIGNo4buJIGdpYW8gaMOgbmdcIj5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPsSQ4buLYSBjaOG7iSDEkWFuZyBjaOG7jW48L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBzeD17e292ZXJmbG93V3JhcDonYW55d2hlcmUnfX0+e2FkZHJlc3Nlcy5kYXRhPy5kYXRhLmZpbmQoYWRkcmVzcz0+YWRkcmVzcy5pZD09PWFkZHJlc3NJZCk/LmxhYmVsIHx8IGFkZHJlc3NJZH08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvRmllbGRHcm91cD59XHJcbiAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImtobyB4deG6pXRcIiBsb2FkZWRDb3VudD17d2FyZWhvdXNlcy5sb2FkZWRDb3VudH0gaGFzTW9yZT17d2FyZWhvdXNlcy5oYXNNb3JlfSBidXN5PXt3YXJlaG91c2VzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e3dhcmVob3VzZXMubG9hZE1vcmV9Lz5cclxuICAgICAgICAgICAge2N1c3RvbWVySWQgJiYgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwixJHhu4thIGNo4buJIGdpYW8gaMOgbmdcIiBsb2FkZWRDb3VudD17YWRkcmVzc2VzLmxvYWRlZENvdW50fSBoYXNNb3JlPXthZGRyZXNzZXMuaGFzTW9yZX0gYnVzeT17YWRkcmVzc2VzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2FkZHJlc3Nlcy5sb2FkTW9yZX0vPn1cclxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPsSQxqFuIHjDoWMgbmjhuq1uIGdp4buvIHNuYXBzaG90IMSR4buLYSBjaOG7iSBj4bunYSBiw6FvIGdpw6EuIEtoaSDEkeG7i2EgY2jhu4kgxJHhu5VpIHRyxrDhu5tjIHjDoWMgbmjhuq1uLCBj4bqnbiBs4bqleSBiw6FvIGdpw6EgdsOgIGtow6FjaCDEkeG7k25nIMO9IGzhuqFpLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgIHtyZXNvdXJjZSB8fCBjcmVhdGUucGVuZGluZyA/IDxGaWVsZEdyb3VwIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJUaGFuaCB0b8OhblwiPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+VGhhbmggdG/DoW48L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBzeD17eyBvdmVyZmxvd1dyYXA6ICdhbnl3aGVyZScgfX0+e21ldGhvZCA9PT0gJ2NvZCcgPyAnVGh1IGtoaSBnaWFvIChDT0QpJyA6ICdUcuG6oyB0csaw4bubYywgY+G6p24geMOhYyBtaW5oIHRp4buBbid9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8L0ZpZWxkR3JvdXA+IDogPFRleHRGaWVsZCBsYWJlbD1cIlRoYW5oIHRvw6FuXCIgc2VsZWN0IHZhbHVlPXttZXRob2R9IG9uQ2hhbmdlPXtlID0+IHNldE1ldGhvZChlLnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgbWV0aG9kKX0+PE1lbnVJdGVtIHZhbHVlPVwiY29kXCI+VGh1IGtoaSBnaWFvIChDT0QpPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJwcmVwYXlcIj5UcuG6oyB0csaw4bubYywgY+G6p24geMOhYyBtaW5oIHRp4buBbjwvTWVudUl0ZW0+PC9UZXh0RmllbGQ+fVxyXG4gICAgICAgIDwvRm9ybUZpZWxkcz48L1BhbmVsPlxyXG4gICAgICAgIDxQYW5lbCB0aXRsZT1cIlPhuqNuIHBo4bqpbSDEkeG6t3QgbXVhXCIgYm9keU1vZGU9XCJpbnNldFwiIHN1YnRpdGxlPVwiQuG7mSBjaOG7jW4gdMOsbSBraeG6v20gdOG7qyBBUEk7IGdpw6EgdsOgIHThu5NuIGtobyBjaOG7iSDEkcaw4bujYyBjaOG7kXQga2hpIGzhuqV5IGLDoW8gZ2nDoS5cIiBhY3Rpb249ezxCdXR0b24gc3RhcnRJY29uPXs8QWRkUm91bmRlZCAvPn0gZGlzYWJsZWQ9e2xpbmVzLmxlbmd0aCA+PSAxMDB9IG9uQ2xpY2s9eygpID0+IHNldExpbmVzKGN1cnJlbnQgPT4gWy4uLmN1cnJlbnQsIHsga2V5OiBjcnlwdG8ucmFuZG9tVVVJRCgpLCB2YXJpYW50SWQ6ICcnLCB2YXJpYW50TGFiZWw6ICcnLCBxdWFudGl0eTogJzEnIH1dKX0+VGjDqm0gZMOybmc8L0J1dHRvbj59PlxyXG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyA+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVMOsbSBz4bqjbiBwaOG6qW0gaG/hurdjIFNLVVwiIHZhbHVlPXtwcm9kdWN0U2VhcmNofSBvbkNoYW5nZT17ZSA9PiBzZXRQcm9kdWN0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5SZWFkUHJvZHVjdHN9IGhlbHBlclRleHQ9XCJUw6xtIHThu6sgbGlzdFByb2R1Y3RzIHbhu5tpIHE7IGJp4bq/biB0aOG7gyBraMO0bmcgaG/huqF0IMSR4buZbmcga2jDtG5nIMSRxrDhu6NjIGNo4buNbi5cIi8+XHJcbiAgICAgICAgICAgICAgICB7bGluZXMubWFwKChsaW5lLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkVmFyaWFudCA9IHZhcmlhbnRzLmZpbmQodmFyaWFudCA9PiB2YXJpYW50LmlkID09PSBsaW5lLnZhcmlhbnRJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVhbnRpdHlJbnZhbGlkID0gbGluZVF1YW50aXR5RXJyb3IobGluZS5xdWFudGl0eSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxGb3JtRmllbGRzIGtleT17bGluZS5rZXl9IGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBhbGlnbkl0ZW1zPXt7IHhzOiAnc3RyZXRjaCcsIHNtOiAnc3RhcnQnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPXtgU+G6o24gcGjhuqltICR7aW5kZXggKyAxfWB9IHNlbGVjdCBmdWxsV2lkdGggdmFsdWU9e2xpbmUudmFyaWFudElkfSBkaXNhYmxlZD17IWNhblJlYWRQcm9kdWN0cyAmJiAhcmVzb3VyY2V9IG9uQ2hhbmdlPXtldmVudCA9PiBjaG9vc2VWYXJpYW50KGxpbmUua2V5LCBldmVudC50YXJnZXQudmFsdWUpfSBlcnJvcj17ZHVwbGljYXRlVmFyaWFudHMgJiYgISFsaW5lLnZhcmlhbnRJZH0gaGVscGVyVGV4dD17ZHVwbGljYXRlVmFyaWFudHMgJiYgbGluZS52YXJpYW50SWQgPyAnS2jDtG5nIHRow6ptIGPDuW5nIG3hu5l0IGJp4bq/biB0aOG7gyBoYWkgbOG6p247IGjDo3kgZ+G7mXAgc+G7kSBsxrDhu6NuZyB2w6BvIG3hu5l0IGTDsm5nLicgOiB1bmRlZmluZWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xpbmUudmFyaWFudElkICYmICFzZWxlY3RlZFZhcmlhbnQgJiYgPE1lbnVJdGVtIHZhbHVlPXtsaW5lLnZhcmlhbnRJZH0+e2xpbmUudmFyaWFudExhYmVsIHx8IGDEkGFuZyBnaeG7ryBiaeG6v24gdGjhu4M6ICR7bGluZS52YXJpYW50SWR9YH08L01lbnVJdGVtPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2YXJpYW50cy5tYXAodmFyaWFudCA9PiA8TWVudUl0ZW0ga2V5PXt2YXJpYW50LmlkfSB2YWx1ZT17dmFyaWFudC5pZH0gZGlzYWJsZWQ9e2xpbmVzLnNvbWUob3RoZXIgPT4gb3RoZXIua2V5ICE9PSBsaW5lLmtleSAmJiBvdGhlci52YXJpYW50SWQgPT09IHZhcmlhbnQuaWQpfT57dmFyaWFudC5wcm9kdWN0TmFtZX0gwrcge3ZhcmlhbnQubmFtZX0gwrcge3ZhcmlhbnQuc2t1fTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5SZWFkUHJvZHVjdHMgJiYgIXByb2R1Y3RzLmlzUGVuZGluZyAmJiB2YXJpYW50cy5sZW5ndGggPT09IDAgJiYgIWxpbmUudmFyaWFudElkICYmIDxNZW51SXRlbSBkaXNhYmxlZCB2YWx1ZT1cIlwiPktow7RuZyB0w6xtIHRo4bqleSBz4bqjbiBwaOG6qW0vYmnhur9uIHRo4buDIHBow7kgaOG7o3A8L01lbnVJdGVtPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJT4buRIGzGsOG7o25nXCIgdmFsdWU9e2xpbmUucXVhbnRpdHl9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRMaW5lcyhjdXJyZW50ID0+IGN1cnJlbnQubWFwKGl0ZW0gPT4gaXRlbS5rZXkgPT09IGxpbmUua2V5ID8geyAuLi5pdGVtLCBxdWFudGl0eTogZXZlbnQudGFyZ2V0LnZhbHVlIH0gOiBpdGVtKSl9IGVycm9yPXtxdWFudGl0eUludmFsaWR9IGhlbHBlclRleHQ9e3F1YW50aXR5SW52YWxpZCA/ICdOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gMS4wMDAuMDAwLicgOiAnU+G7kSBsxrDhu6NuZyBuZ3V5w6puIHRoZW8gaOG7o3AgxJHhu5NuZy4nfSBpbnB1dFByb3BzPXt7IGlucHV0TW9kZTogJ251bWVyaWMnLCAnYXJpYS1pbnZhbGlkJzogcXVhbnRpdHlJbnZhbGlkIH19IHN4PXt7IG1pbldpZHRoOiAxMDAsIG1heFdpZHRoOiB7IHNtOiAxODAgfSB9fS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGFyaWEtbGFiZWw9e2BC4buPIGTDsm5nICR7aW5kZXggKyAxfWB9IGRpc2FibGVkPXtsaW5lcy5sZW5ndGggPT09IDF9IHN4PXt7IGFsaWduU2VsZjogJ3N0YXJ0JyB9fSBvbkNsaWNrPXsoKSA9PiBzZXRMaW5lcyhjdXJyZW50ID0+IGN1cnJlbnQuZmlsdGVyKGl0ZW0gPT4gaXRlbS5rZXkgIT09IGxpbmUua2V5KSl9PjxEZWxldGVPdXRsaW5lUm91bmRlZCAvPjwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+O1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICA8TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJz4bqjbiBwaOG6qW1cIiBsb2FkZWRDb3VudD17cHJvZHVjdHMubG9hZGVkQ291bnR9IGhhc01vcmU9e3Byb2R1Y3RzLmhhc01vcmV9IGJ1c3k9e3Byb2R1Y3RzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e3Byb2R1Y3RzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgICAgICB7bGluZXMubGVuZ3RoID49IDEwMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+xJDGoW4gbmjDoXAgxJHhuqF0IGdp4bubaSBo4bqhbiAxMDAgZMOybmcgdGhlbyBo4bujcCDEkeG7k25nLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlThu5VuZyB0aeG7gW4gdsOgIGto4bqjIG7Eg25nIGdp4buvIGjDoG5nIMSRxrDhu6NjIHTDrW5oIGzhuqFpIGLhu59pIEFQSSBraGkgbOG6pXkgYsOhbyBnacOhIHbDoCB4w6FjIG5o4bqtbjsga2jDtG5nIHRpbiB04buVbmcgZG8gdHLDrG5oIGR1eeG7h3QgdOG7sSB0w61uaC48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkdoaSBjaMO6IGNodeG6qW4gYuG7i1wiIHZhbHVlPXtub3Rlc30gb25DaGFuZ2U9e2UgPT4gc2V0Tm90ZXMobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAyMDAwKSl9IGVycm9yPXtjb2RlUG9pbnRMZW5ndGgobm90ZXMpID4gMl8wMDB9IGhlbHBlclRleHQ9e2Ake2NvZGVQb2ludExlbmd0aChub3Rlcyl9LzIuMDAwIGvDvSB04buxYH0gbXVsdGlsaW5lIG1pblJvd3M9ezJ9IC8+XHJcbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwib3JkZXJzLndyaXRlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e2NyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBkaXNhYmxlZD17IXZhbGlkIHx8ICFjYW5Xcml0ZU9yZGVyc30gdHlwZT1cInN1Ym1pdFwiPkzGsHUgxJHGoW4gbmjDoXA8L011dGF0aW9uQnV0dG9uPlxyXG4gICAgPC9QYWdlU2VjdGlvbnM+PC9Cb3g+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBOZXdPcmRlclBhZ2UoKSB7IGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTsgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpOyByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIlThuqFvIMSRxqFuIGjDoG5nXCIgc3VidGl0bGU9XCJMxrB1IG5ow6FwIHRyxrDhu5tjLCBzYXUgxJHDsyBiw6FvIGdpw6EgdsOgIHjDoWMgbmjhuq1uIGtow6FjaC5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9vcmRlcnNgfT5EYW5oIHPDoWNoIMSRxqFuPC9Sb3V0ZUxpbms+fS8+PERyYWZ0Rm9ybSBvblNhdmVkPXtvID0+IG5hdmlnYXRlKGAvcy8ke3Nob3AuaWR9L29yZGVycy8ke28uaWR9YCl9Lz48Lz47IH1cclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyRGV0YWlsUGFnZSh7IHNpbXVsYXRlQ3VzdG9tZXJDb25maXJtYXRpb24gfToge1xyXG4gICAgc2ltdWxhdGVDdXN0b21lckNvbmZpcm1hdGlvbj86IChzaG9wSWQ6IHN0cmluZywgcXVvdGVJZDogc3RyaW5nKSA9PiBQcm9taXNlPEN1c3RvbWVyQ29uZmlybWF0aW9uUmVxdWVzdD47XHJcbn0pIHtcclxuICAgIGNvbnN0IHsgb3JkZXJJZCA9ICcnIH0gPSB1c2VQYXJhbXMoKTtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGxpc3RIcmVmPXVzZUxpc3RSZXR1cm4oYC9zLyR7c2hvcC5pZH0vb3JkZXJzYCk7XHJcbiAgICBjb25zdCBnZXQgPSB1c2VBcGkoJ2dldE9yZGVyJywgeyBwYXRoOiB7IG9yZGVySWQgfSB9KTtcclxuICAgIGNvbnN0IG9yZGVyID0gZ2V0LmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBxdW90ZU9wID0gdXNlQ29tbWFuZCgncXVvdGVPcmRlcicsIFsnZ2V0T3JkZXInXSk7XHJcbiAgICBjb25zdCByZWNvcmQgPSB1c2VDb21tYW5kKCdyZWNvcmRDdXN0b21lckNvbmZpcm1hdGlvbicsIFtdKTtcclxuICAgIGNvbnN0IGNvbmZpcm0gPSB1c2VDb21tYW5kKCdjb25maXJtT3JkZXInLCBbJ2dldE9yZGVyJywgJ2xpc3RPcmRlcnMnLCAnbGlzdFN0b2NrU25hcHNob3RzJywgJ2dldERhc2hib2FyZCcsICdsaXN0V29ya0l0ZW1zJywgJ2xpc3ROb3RpZmljYXRpb25zJywgJ2xpc3RQcmVwSm9icyddKTtcclxuICAgIGNvbnN0IGNhbmNlbCA9IHVzZUNvbW1hbmQoJ2NhbmNlbE9yZGVyJywgWydnZXRPcmRlcicsICdsaXN0T3JkZXJzJywgJ2xpc3RTdG9ja1NuYXBzaG90cycsICdsaXN0V29ya0l0ZW1zJywgJ2xpc3RQcmVwSm9icyddKTtcclxuICAgIGNvbnN0IHBheSA9IHVzZUNvbW1hbmQoJ3BheU9yZGVyJywgWydnZXRPcmRlcicsICdsaXN0T3JkZXJzJywgJ2dldENhc2hmbG93JywgJ2xpc3RGaW5hbmNlRW50cmllcyddKTtcclxuICAgIGNvbnN0IHJlZnVuZCA9IHVzZUNvbW1hbmQoJ3JlZnVuZE9yZGVyJywgWydnZXRPcmRlcicsICdsaXN0T3JkZXJzJywgJ2dldENhc2hmbG93J10pO1xyXG4gICAgY29uc3QgW3F1b3RlLCBzZXRRdW90ZV0gPSB1c2VTdGF0ZTxPcmRlclF1b3RlIHwgbnVsbD4obnVsbCksIFtjb25maXJtYXRpb24sIHNldENvbmZpcm1hdGlvbl0gPSB1c2VTdGF0ZTxDdXN0b21lckNvbmZpcm1hdGlvbiB8IG51bGw+KG51bGwpLCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSksIFthY3Rpb24sIHNldEFjdGlvbl0gPSB1c2VTdGF0ZTwnY2FuY2VsJyB8ICdwYXknIHwgJ3JlZnVuZCcgfCAnZXZpZGVuY2UnIHwgbnVsbD4obnVsbCksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtlZGl0QnVzeSwgc2V0RWRpdEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2hhc2gsIHNldEhhc2hdID0gdXNlU3RhdGUoJycpLCBbaWRlbnRpdHksIHNldElkZW50aXR5XSA9IHVzZVN0YXRlKCcnKSwgW21lc3NhZ2VJZCwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyksIFthbW91bnQsIHNldEFtb3VudF0gPSB1c2VTdGF0ZSgnJyksIFtyZWZlcmVuY2UsIHNldFJlZmVyZW5jZV0gPSB1c2VTdGF0ZSgnJyksIFtldmlkZW5jZVJlZiwgc2V0RXZpZGVuY2VdID0gdXNlU3RhdGUoJycpLCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW25vd01zLCBzZXROb3dNc10gPSB1c2VTdGF0ZSgoKSA9PiBEYXRlLm5vdygpKTtcclxuICAgIGNvbnN0IFtzZXJ2ZXJPZmZzZXRNcywgc2V0U2VydmVyT2Zmc2V0TXNdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBzeW5jaHJvbml6ZUFwaVRpbWUgPSAoYXNPZjogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYXBpVGltZSA9IERhdGUucGFyc2UoYXNPZik7XHJcbiAgICAgICAgaWYgKE51bWJlci5pc0Zpbml0ZShhcGlUaW1lKSlcclxuICAgICAgICAgICAgc2V0U2VydmVyT2Zmc2V0TXMoYXBpVGltZSAtIG5vd01zKTtcclxuICAgIH07XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICghcXVvdGUpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiBzZXROb3dNcyhEYXRlLm5vdygpKSwgMV8wMDApO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcik7XHJcbiAgICB9LCBbcXVvdGVdKTtcclxuICAgIGNvbnN0IGVmZmVjdGl2ZU5vd01zID0gbm93TXMgKyBzZXJ2ZXJPZmZzZXRNcztcclxuICAgIGNvbnN0IHF1b3RlRXhwaXJlZCA9ICEhcXVvdGUgJiYgRGF0ZS5wYXJzZShxdW90ZS5leHBpcmVzQXQpIDw9IGVmZmVjdGl2ZU5vd01zO1xyXG4gICAgY29uc3QgY29uZmlybWF0aW9uRXhwaXJlZCA9ICEhY29uZmlybWF0aW9uICYmIChjb25maXJtYXRpb24uc3RhdHVzICE9PSAndmFsaWQnIHx8IERhdGUucGFyc2UoY29uZmlybWF0aW9uLmV4cGlyZXNBdCkgPD0gZWZmZWN0aXZlTm93TXMpO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHsgaWYgKG9yZGVyICYmIHF1b3RlICYmIG9yZGVyLnZlcnNpb24gIT09IHF1b3RlLm9yZGVyVmVyc2lvbikge1xyXG4gICAgICAgIHNldFF1b3RlKG51bGwpO1xyXG4gICAgICAgIHNldENvbmZpcm1hdGlvbihudWxsKTtcclxuICAgIH0gfSwgW29yZGVyLCBxdW90ZV0pO1xyXG4gICAgY29uc3QgY29sbGVjdCA9IGFzeW5jICgpID0+IHsgaWYgKCFxdW90ZSlcclxuICAgICAgICByZXR1cm47IHRyeSB7XHJcbiAgICAgICAgY29uc3QgciA9IGF3YWl0IHJlY29yZC5leGVjdXRlKHsgcGF0aDogeyBvcmRlcklkIH0sIGJvZHk6IHsgcXVvdGVJZDogcXVvdGUuaWQsIHF1b3RlSGFzaDogaGFzaCwgcXVvdGVWZXJzaW9uOiBxdW90ZS5vcmRlclZlcnNpb24sIGN1c3RvbWVySWRlbnRpdHlJZDogaWRlbnRpdHksIHNvdXJjZU1lc3NhZ2VJZDogbWVzc2FnZUlkIH0gfSk7XHJcbiAgICAgICAgc3luY2hyb25pemVBcGlUaW1lKHIubWV0YS5hc09mKTtcclxuICAgICAgICBzZXRDb25maXJtYXRpb24oci5kYXRhKTtcclxuICAgICAgICBzZXRBY3Rpb24obnVsbCk7XHJcbiAgICB9XHJcbiAgICBjYXRjaCB7IC8qIGtlZXAgZm9ybSAqLyB9IH07XHJcbiAgICBjb25zdCBtb2NrQ29uZmlybSA9IGFzeW5jICgpID0+IHsgaWYgKCFxdW90ZSB8fCAhc2ltdWxhdGVDdXN0b21lckNvbmZpcm1hdGlvbilcclxuICAgICAgICByZXR1cm47IHRyeSB7XHJcbiAgICAgICAgY29uc3QgZXZpZGVuY2UgPSBhd2FpdCBzaW11bGF0ZUN1c3RvbWVyQ29uZmlybWF0aW9uKHNob3AuaWQsIHF1b3RlLmlkKTtcclxuICAgICAgICBzZXRIYXNoKGV2aWRlbmNlLnF1b3RlSGFzaCk7XHJcbiAgICAgICAgc2V0SWRlbnRpdHkoZXZpZGVuY2UuY3VzdG9tZXJJZGVudGl0eUlkKTtcclxuICAgICAgICBzZXRNZXNzYWdlKGV2aWRlbmNlLnNvdXJjZU1lc3NhZ2VJZCk7XHJcbiAgICAgICAgY29uc3QgciA9IGF3YWl0IHJlY29yZC5leGVjdXRlKHsgcGF0aDogeyBvcmRlcklkIH0sIGJvZHk6IGV2aWRlbmNlIH0pO1xyXG4gICAgICAgIHN5bmNocm9uaXplQXBpVGltZShyLm1ldGEuYXNPZik7XHJcbiAgICAgICAgc2V0Q29uZmlybWF0aW9uKHIuZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUgOiBuZXcgRXJyb3IoJ0tow7RuZyB04bqhbyDEkcaw4bujYyBi4bqxbmcgY2jhu6luZyBt4bqrdScpKTtcclxuICAgIH0gfTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPXtgxJDGoW4gJHtvcmRlcklkfWB9IHN1YnRpdGxlPVwiTeG7jWkgdGhheSDEkeG7lWkgcXVhbiB0cuG7jW5nIGtp4buDbSBs4bqhaSBwaGnDqm4gYuG6o24gdsOgIMSRaeG7gXUga2nhu4duIG5naGnhu4dwIHbhu6UuXCIgYWN0aW9ucz17PFJvdXRlTGluayB0bz17bGlzdEhyZWZ9PkRhbmggc8OhY2ggxJHGoW48L1JvdXRlTGluaz59Lz48UXVlcnlTdGF0ZSBxdWVyeT17Z2V0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57b3JkZXIgJiYgPD5cclxuIDxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3IgfHwgcXVvdGVPcC5lcnJvciB8fCByZWNvcmQuZXJyb3IgfHwgY29uZmlybS5lcnJvcn0vPntlZGl0aW5nID8gPEVkaXREaWFsb2cgYWxsb3dFZGl0c1doaWxlQnVzeSBvcGVuIHRpdGxlPVwiU+G7rWEgxJHGoW4gbmjDoXBcIiBidXN5PXtlZGl0QnVzeX0gb25DbG9zZT17KCkgPT4gc2V0RWRpdGluZyhmYWxzZSl9IGFjdGlvbnM9eyh7IHJlcXVlc3RDbG9zZSwgYnVzeSB9KSA9PiA8QnV0dG9uIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXtyZXF1ZXN0Q2xvc2V9PsSQw7NuZyBjaOG7iW5oIHPhu61hPC9CdXR0b24+fT48RHJhZnRGb3JtIGluaXRpYWw9e29yZGVyfSBvbkJ1c3lDaGFuZ2U9e3NldEVkaXRCdXN5fSBvblNhdmVkPXsoKSA9PiB7IHNldEVkaXRCdXN5KGZhbHNlKTsgc2V0RWRpdGluZyhmYWxzZSk7IHNldFF1b3RlKG51bGwpOyBzZXRDb25maXJtYXRpb24obnVsbCk7IH19Lz48L0VkaXREaWFsb2c+IDogPD5cclxuIDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiBhZnRlckdhcD1cInNlY3Rpb25cIj48U3RhdHVzIHZhbHVlPXtvcmRlci5vcmRlclN0YXRlfS8+PFN0YXR1cyB2YWx1ZT17b3JkZXIuZnVsZmlsbG1lbnRTdGF0ZX0vPjxTdGF0dXMgdmFsdWU9e29yZGVyLnBheW1lbnRTdGF0ZX0vPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgc3g9e3sgYWxpZ25TZWxmOiAnY2VudGVyJyB9fT5QaGnDqm4gYuG6o24ge29yZGVyLnZlcnNpb259PC9UeXBvZ3JhcGh5PjwvQWN0aW9uR3JvdXA+XHJcbiA8U2VjdGlvbkdyaWQgY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMmZyIDFmcicgfX0+PFBhbmVsIHRpdGxlPVwiU+G6o24gcGjhuqltIHRyb25nIMSRxqFuXCI+PERhdGFUYWJsZSBsYWJlbD1cIlPhuqNuIHBo4bqpbSB0cm9uZyDEkcahblwiIHJvd3M9e29yZGVyLmxpbmVzfSByb3dLZXk9e2wgPT4gbC5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogJ25hbWUnLCBsYWJlbDogJ1PhuqNuIHBo4bqpbSAvIFNLVScsIHJlbmRlcjogbCA9PiA8U3RhY2s+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e2wubmFtZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57bC5za3V9PC9UeXBvZ3JhcGh5PjwvU3RhY2s+XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdxdHknLCBsYWJlbDogJ1Phu5EgbMaw4bujbmcnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBsID0+IGwucXVhbnRpdHkgfSwgeyBrZXk6ICdwcmljZScsIGxhYmVsOiAnxJDGoW4gZ2nDoScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGwgPT4gPEFtb3VudCB2YWx1ZT17bC51bml0UHJpY2V9Lz4gfSwgeyBrZXk6ICd0b3RhbCcsIGxhYmVsOiAnVGjDoG5oIHRp4buBbicsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGwgPT4gPEFtb3VudCB2YWx1ZT17bC5saW5lVG90YWx9Lz4gfVxyXG4gICAgICAgICAgICBdfS8+PEJveCBzeD17W2xheW91dFN4LnN1cmZhY2UuaW5zZXQsIHsgdGV4dEFsaWduOiAncmlnaHQnIH1dfT48VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+VOG7lW5nIHThu6sgQVBJPC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNFwiPjxBbW91bnQgd3JhcCB2YWx1ZT17b3JkZXIudG90YWx9Lz48L1R5cG9ncmFwaHk+PC9Cb3g+PC9QYW5lbD48UGFuZWwgdGl0bGU9XCJUaMO0bmcgdGluIHjhu60gbMO9XCIgYm9keU1vZGU9XCJpbnNldFwiPjxCb3g+PERldGFpbExpbmUgbGFiZWw9XCJLaMOhY2hcIj48Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9jdXN0b21lcnMvJHtvcmRlci5jdXN0b21lcklkfWB9Pk3DoyBraMOhY2ggaMOgbmc6IHtvcmRlci5jdXN0b21lcklkfTwvUm91dGVMaW5rPjwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIktob1wiPk3DoyBraG86IHtvcmRlci53YXJlaG91c2VJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCLEkOG7i2EgY2jhu4lcIj57b3JkZXIuc2hpcHBpbmdBZGRyZXNzU25hcHNob3QgPyBbb3JkZXIuc2hpcHBpbmdBZGRyZXNzU25hcHNob3QubGFiZWwsIG9yZGVyLnNoaXBwaW5nQWRkcmVzc1NuYXBzaG90LnJlY2lwaWVudCwgb3JkZXIuc2hpcHBpbmdBZGRyZXNzU25hcHNob3QubGluZTEsIG9yZGVyLnNoaXBwaW5nQWRkcmVzc1NuYXBzaG90LnByb3ZpbmNlXS5maWx0ZXIoQm9vbGVhbikuam9pbignIMK3ICcpIDogKG9yZGVyLnNoaXBwaW5nQWRkcmVzc0lkID8gYE3DoyDEkeG7i2EgY2jhu4k6ICR7b3JkZXIuc2hpcHBpbmdBZGRyZXNzSWR9YCA6ICdDaMawYSBjw7MgxJHhu4thIGNo4buJIMSRxrDhu6NjIHjDoWMgbWluaCcpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlRoYW5oIHRvw6FuXCI+e29yZGVyLnBheW1lbnRNZXRob2QgPT09ICdjb2QnID8gJ0NPRCcgOiAnVHLhuqMgdHLGsOG7m2MnfTwvRGV0YWlsTGluZT57b3JkZXIuY29udmVyc2F0aW9uSWQgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vaW5ib3gvJHtvcmRlci5jb252ZXJzYXRpb25JZH1gfT5N4bufIGjhu5lpIHRob+G6oWk8L1JvdXRlTGluaz59e29yZGVyLnByZXBUYXNrSWQgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vZnVsZmlsbG1lbnRgfT5DaHXhuqluIGLhu4sgxJHGoW48L1JvdXRlTGluaz59PC9Cb3g+PC9QYW5lbD48L1NlY3Rpb25HcmlkPlxyXG4gPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiIGJlZm9yZUdhcD1cImZvcm1cIj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9yZGVycy53cml0ZVwiIGFsbG93ZWRBY3Rpb25zPXtvcmRlci5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwiZWRpdFwiIG9uQ2xpY2s9eygpID0+IHNldEVkaXRpbmcodHJ1ZSl9PlPhu61hIMSRxqFuIG5ow6FwPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9yZGVycy53cml0ZVwiIGFsbG93ZWRBY3Rpb25zPXtvcmRlci5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwicXVvdGVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17cXVvdGVPcC5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByID0gYXdhaXQgcXVvdGVPcC5leGVjdXRlKHsgcGF0aDogeyBvcmRlcklkIH0sIHZlcnNpb246IG9yZGVyLnZlcnNpb24gfSk7XHJcbiAgICAgICAgICAgICAgICBzeW5jaHJvbml6ZUFwaVRpbWUoci5tZXRhLmFzT2YpO1xyXG4gICAgICAgICAgICAgICAgc2V0UXVvdGUoci5kYXRhKTtcclxuICAgICAgICAgICAgICAgIHNldENvbmZpcm1hdGlvbihudWxsKTtcclxuICAgICAgICAgICAgICAgIHNldEhhc2godHlwZW9mIHIuZGF0YS5xdW90ZUhhc2ggPT09ICdzdHJpbmcnID8gci5kYXRhLnF1b3RlSGFzaCA6ICcnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXRjaCB7IC8qIGVycm9ycyB2aXNpYmxlICovIH0gfX0+TOG6pXkgYsOhbyBnacOhIGhp4buHbiB04bqhaTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJvcmRlcnMud3JpdGVcIiBhbGxvd2VkQWN0aW9ucz17b3JkZXIuYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cImNhbmNlbFwiIGNvbG9yPVwiZXJyb3JcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ2NhbmNlbCcpfT5I4buneSDEkcahbjwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBhbGxvd2VkQWN0aW9ucz17b3JkZXIuYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cInJlY29yZF9wYXltZW50XCIgb25DbGljaz17KCkgPT4geyBzZXRBbW91bnQob3JkZXIudG90YWw/LmFtb3VudCB8fCAnJyk7IHNldFJlYXNvbignJyk7IHNldFJlZmVyZW5jZSgnJyk7IHNldEV2aWRlbmNlKCcnKTsgc2V0QWN0aW9uKCdwYXknKTsgfX0+R2hpIG5o4bqtbiB0aeG7gW4gxJHDoyB0aHU8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5yZWZ1bmRcIiBhbGxvd2VkQWN0aW9ucz17b3JkZXIuYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cInJlcXVlc3RfcmVmdW5kXCIgb25DbGljaz17KCkgPT4geyBzZXRBbW91bnQoJycpOyBzZXRSZWFzb24oJycpOyBzZXRSZWZlcmVuY2UoJycpOyBzZXRFdmlkZW5jZSgnJyk7IHNldEFjdGlvbigncmVmdW5kJyk7IH19PkdoaSBuaOG6rW4ga2hv4bqjbiDEkcOjIGhvw6BuPC9NdXRhdGlvbkJ1dHRvbj57b3JkZXIuYWxsb3dlZEFjdGlvbnMuaW5jbHVkZXMoJ3JlcXVlc3RfcmV0dXJuJykgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vcmV0dXJucz9vcmRlcklkPSR7b3JkZXIuaWR9YH0+VOG6oW8gecOqdSBj4bqndSB0cuG6oyBow6BuZzwvUm91dGVMaW5rPn08L0FjdGlvbkdyb3VwPlxyXG4ge3F1b3RlICYmIDxQYW5lbCB0aXRsZT1cIkLDoW8gZ2nDoSB2w6AgeMOhYyBuaOG6rW4ga2jDoWNoXCIgc3VidGl0bGU9e2BC4bqjbiDEkcahbiAke3F1b3RlLm9yZGVyVmVyc2lvbn0gwrcgSOG6v3QgaOG6oW4gJHtkYXRlVGltZShxdW90ZS5leHBpcmVzQXQsIHNob3AudGltZXpvbmUpfWB9IGJvZHlNb2RlPVwiaW5zZXRcIiBiZWZvcmVHYXA9XCJzZWN0aW9uXCI+PFN0YWNrIHN4PXtsYXlvdXRTeC5xdWVyeS5zdGF0ZUdhcH0+PFR5cG9ncmFwaHkgdmFyaWFudD1cImg1XCI+PEFtb3VudCB3cmFwIHZhbHVlPXtxdW90ZS50b3RhbH0vPjwvVHlwb2dyYXBoeT57cXVvdGUud2FybmluZ3MubWFwKCh3LCBpKSA9PiA8QWxlcnQga2V5PXtpfSBzZXZlcml0eT1cImluZm9cIj57d308L0FsZXJ0Pil9PFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+TcOjIGLDoW8gZ2nDoToge3F1b3RlLmlkfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIHN4PXt7IG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9fT5IYXNoIGRvIHNlcnZlciBjdW5nIGPhuqVwOiB7aGFzaCB8fCAnQ2jGsGEgY8OzLiBCYWNrZW5kIHBo4bqjaSBjdW5nIGPhuqVwIGhhc2ggdsOgIGLhurFuZyBjaOG7qW5nIGtow6FjaCB0csaw4bubYyBraGkgY2jhu5F0Lid9PC9UeXBvZ3JhcGh5PntxdW90ZUV4cGlyZWQgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkLDoW8gZ2nDoSDEkcOjIGjhur90IGjhuqFuLiBM4bqleSBiw6FvIGdpw6EgbeG7m2kgdsOgIHjDoWMgbmjhuq1uIGzhuqFpIHbhu5tpIGtow6FjaCB0csaw4bubYyBraGkgY2jhu5F0LjwvQWxlcnQ+fXtjb25maXJtYXRpb24gPyA8QWxlcnQgc2V2ZXJpdHk9e2NvbmZpcm1hdGlvbkV4cGlyZWQgPyAnd2FybmluZycgOiAnc3VjY2Vzcyd9Pntjb25maXJtYXRpb25FeHBpcmVkID8gJ0LhurFuZyBjaOG7qW5nIGtow6FjaCDEkcOjIGjhur90IGjhuqFuIGhv4bq3YyBi4buLIHRoYXkgdGjhur8uIEPhuqduIGdoaSBuaOG6rW4geMOhYyBuaOG6rW4gY2hvIGLDoW8gZ2nDoSBoaeG7h24gdOG6oWkuJyA6IGDEkMOjIGdoaSBuaOG6rW4gYuG6sW5nIGNo4bupbmcgJHtjb25maXJtYXRpb24uaWR9LiBYw6FjIG5o4bqtbiBs4bqhaSBnacOhL3Thu5NuIGtoaSBjaOG7kXQgxJHGoW4uYH08L0FsZXJ0PiA6IDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiA+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ2V2aWRlbmNlJyl9Pk5o4bqtcCBi4bqxbmcgY2jhu6luZyB4w6FjIG5o4bqtbiBraMOhY2g8L0J1dHRvbj57c2ltdWxhdGVDdXN0b21lckNvbmZpcm1hdGlvbiAmJiA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGRpc2FibGVkPXtyZWNvcmQucGVuZGluZ30gb25DbGljaz17KCkgPT4gdm9pZCBtb2NrQ29uZmlybSgpfT5Nw7QgcGjhu49uZyBraMOhY2ggxJHhu5NuZyDDvSBiw6FvIGdpw6E8L0J1dHRvbj59PC9BY3Rpb25Hcm91cD59PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJvcmRlcnMuY29uZmlybVwiIGFsbG93ZWRBY3Rpb25zPXtvcmRlci5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwiY29uZmlybVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IWNvbmZpcm1hdGlvbiB8fCBxdW90ZUV4cGlyZWQgfHwgY29uZmlybWF0aW9uRXhwaXJlZH0gYnVzeT17Y29uZmlybS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGlmICghY29uZmlybWF0aW9uIHx8IHF1b3RlRXhwaXJlZCB8fCBjb25maXJtYXRpb25FeHBpcmVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuOyB0cnkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgY29uZmlybS5leGVjdXRlKHtcclxuICAgICAgICAgICAgICAgICAgICBwYXRoOiB7IG9yZGVySWQgfSwgdmVyc2lvbjogb3JkZXIudmVyc2lvbiwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IG9yZGVyLnZlcnNpb24sIHF1b3RlSWQ6IHF1b3RlLmlkLCBjdXN0b21lckNvbmZpcm1hdGlvbklkOiBjb25maXJtYXRpb24uaWQgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBzZXRRdW90ZShudWxsKTtcclxuICAgICAgICAgICAgICAgIHNldENvbmZpcm1hdGlvbihudWxsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5Yw6FjIG5o4bqtbiDEkcahbiAmIGdp4buvIGjDoG5nPC9NdXRhdGlvbkJ1dHRvbj48L1N0YWNrPjwvUGFuZWw+fVxyXG4gPC8+fTwvPn08L1F1ZXJ5U3RhdGU+XHJcbiA8Q29uZmlybURpYWxvZyBvcGVuPXthY3Rpb24gPT09ICdjYW5jZWwnfSB0aXRsZT1cIkjhu6d5IMSRxqFuIGjDoG5nXCIgY29uZmlybUxhYmVsPVwiSOG7p3kgxJHGoW4gaMOgbmdcIiBkZXNjcmlwdGlvbj17YMSQxqFuICR7b3JkZXJJZH06IGjhu6d5IHjhu60gbMO9IG3hu5tpIHbDoCBnaeG6o2kgcGjDs25nIGzGsOG7o25nIGjDoG5nIGdp4buvIGtoaSDEkeG7pyDEkWnhu4F1IGtp4buHbi4gTOG7i2NoIHPhu60gdsOgIGNo4bupbmcgdOG7qyDEkcOjIGdoaSDEkcaw4bujYyBnaeG7rzsgdMOhYyDEkeG7mW5nIMSRw6MgdGnhur9wIG5o4bqtbiBwaOG6o2kgxJHGsOG7o2MgxJHhu5FpIGNoaeG6v3UuYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRBY3Rpb24obnVsbCl9IGJ1c3k9e2NhbmNlbC5wZW5kaW5nfSBlcnJvcj17Y2FuY2VsLmVycm9yfSBvbkNvbmZpcm09e3JlYXNvbiA9PiBjYW5jZWwuZXhlY3V0ZSh7IHBhdGg6IHsgb3JkZXJJZCB9LCB2ZXJzaW9uOiBvcmRlcj8udmVyc2lvbiwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IG9yZGVyPy52ZXJzaW9uIHx8IDEsIHJlYXNvbiB9IH0pfS8+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXthY3Rpb24gPT09ICdldmlkZW5jZSd9IHRpdGxlPVwiQuG6sW5nIGNo4bupbmcgeMOhYyBuaOG6rW4gdOG7qyBraMOhY2hcIiBvbkNsb3NlPXsoKSA9PiBzZXRBY3Rpb24obnVsbCl9IGJ1c3k9e3JlY29yZC5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IS9eW2EtZjAtOV17NjR9JC8udGVzdChoYXNoKSB8fCAhaWRlbnRpdHkgfHwgIW1lc3NhZ2VJZCB8fCByZWNvcmQucGVuZGluZ30gb25DbGljaz17KCkgPT4gdm9pZCBjb2xsZWN0KCl9PkdoaSBuaOG6rW4gYuG6sW5nIGNo4bupbmc8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17cmVjb3JkLmVycm9yfS8+PEZvcm1GaWVsZHMgPjxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5LaMO0bmcgZMO5bmcgbOG7nWkgQUkg4oCca2jDoWNoIMSRw6MgxJHhu5NuZyDDveKAnSDEkeG7gyB4w6FjIG5o4bqtbi4gQ+G6p24gxJHhu4tuaCBkYW5oIHbDoCB0aW4gbmjhuq9uIGtow6FjaCB0aOG7sWMgc+G7sSB4w6FjIG5o4bqtbiDEkcO6bmcgYsOhbyBnacOhLjwvQWxlcnQ+PFRleHRGaWVsZCBsYWJlbD1cIkhhc2ggYsOhbyBnacOhIHThu6sgYmFja2VuZFwiIHZhbHVlPXtoYXNofSBvbkNoYW5nZT17ZSA9PiBzZXRIYXNoKGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCLEkOG7i25oIGRhbmgga2jDoWNoXCIgdmFsdWU9e2lkZW50aXR5fSBvbkNoYW5nZT17ZSA9PiBzZXRJZGVudGl0eShlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHRpbiBuaOG6r24geMOhYyBuaOG6rW5cIiB2YWx1ZT17bWVzc2FnZUlkfSBvbkNoYW5nZT17ZSA9PiBzZXRNZXNzYWdlKGUudGFyZ2V0LnZhbHVlKX0vPjwvRm9ybUZpZWxkcz48L0VkaXREaWFsb2c+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXthY3Rpb24gPT09ICdwYXknIHx8IGFjdGlvbiA9PT0gJ3JlZnVuZCd9IHRpdGxlPXthY3Rpb24gPT09ICdwYXknID8gJ0doaSBuaOG6rW4gdGnhu4FuIMSRw6MgdGh1JyA6ICdHaGkgbmjhuq1uIHRp4buBbiDEkcOjIGhvw6BuJ30gb25DbG9zZT17KCkgPT4gc2V0QWN0aW9uKG51bGwpfSBidXN5PXtwYXkucGVuZGluZyB8fCByZWZ1bmQucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyEvXlxcZCsoXFwuXFxkezEsNH0pPyQvLnRlc3QoYW1vdW50KSB8fCAhZXZpZGVuY2VSZWYgfHwgIXJlZmVyZW5jZSB8fCBjb2RlUG9pbnRMZW5ndGgocmVhc29uLnRyaW0oKSkgPCA1IHx8IHBheS5wZW5kaW5nIHx8IHJlZnVuZC5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGlmICghb3JkZXIpXHJcbiAgICAgICAgcmV0dXJuOyB0cnkge1xyXG4gICAgICAgIGlmIChhY3Rpb24gPT09ICdwYXknKVxyXG4gICAgICAgICAgICBhd2FpdCBwYXkuZXhlY3V0ZSh7XHJcbiAgICAgICAgICAgICAgICBwYXRoOiB7IG9yZGVySWQgfSwgdmVyc2lvbjogb3JkZXIudmVyc2lvbiwgYm9keToge1xyXG4gICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkVmVyc2lvbjogb3JkZXIudmVyc2lvbiwgYW1vdW50OiB7IGFtb3VudCwgY3VycmVuY3k6IHNob3AuY3VycmVuY3kgfSwgbWV0aG9kOiAnYmFua190cmFuc2ZlcicsIHJlZmVyZW5jZSwgcmVhc29uLCBldmlkZW5jZVJlZlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGF3YWl0IHJlZnVuZC5leGVjdXRlKHtcclxuICAgICAgICAgICAgICAgIHBhdGg6IHsgb3JkZXJJZCB9LCB2ZXJzaW9uOiBvcmRlci52ZXJzaW9uLCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogb3JkZXIudmVyc2lvbiwgYW1vdW50OiB7IGFtb3VudCwgY3VycmVuY3k6IHNob3AuY3VycmVuY3kgfSwgcmVhc29uLCBwYXltZW50UmVmZXJlbmNlOiByZWZlcmVuY2UsIGV2aWRlbmNlUmVmIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0QWN0aW9uKG51bGwpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+R2hpIG5o4bqtbiBjaOG7qW5nIHThu6s8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17cGF5LmVycm9yIHx8IHJlZnVuZC5lcnJvcn0vPjxGb3JtRmllbGRzID48QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+Q2jhu4kgZ2hpIGtob+G6o24gxJHDoyDEkcaw4bujYyB4w6FjIG1pbmguIE7DunQgbsOgeSBraMO0bmcgY2h1eeG7g24gdGnhu4FuLiDhuqJuaCBjaHV54buDbiBraG/huqNuIGNoxrBhIHjDoWMgdGjhu7FjIGtow7RuZyBsw6AgYuG6sW5nIGNo4bupbmcgdGhhbmggdG/DoW4uPC9BbGVydD48VGV4dEZpZWxkIGxhYmVsPXtgU+G7kSB0aeG7gW4gKCR7c2hvcC5jdXJyZW5jeX0pYH0gdmFsdWU9e2Ftb3VudH0gb25DaGFuZ2U9e2UgPT4gc2V0QW1vdW50KGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJNw6MgdGhhbSBjaGnhur91IGdpYW8gZOG7i2NoXCIgdmFsdWU9e3JlZmVyZW5jZX0gb25DaGFuZ2U9e2UgPT4gc2V0UmVmZXJlbmNlKGUudGFyZ2V0LnZhbHVlKX0vPjxUZXh0RmllbGQgbGFiZWw9XCJNw6MgY2jhu6luZyB04burIMSRw6MgeMOhYyBtaW5oXCIgdmFsdWU9e2V2aWRlbmNlUmVmfSBvbkNoYW5nZT17ZSA9PiBzZXRFdmlkZW5jZShlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTMO9IGRvXCIgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9e2UgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX0gbXVsdGlsaW5lIG1pblJvd3M9ezJ9Lz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gUmV0dXJuc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBbcGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3QgY2FuUmVhZE9yZGVycyA9IHVzZUNhbignb3JkZXJzLnJlYWQnKTtcclxuICAgIGNvbnN0IGNhbkNyZWF0ZVJldHVybiA9IHVzZUNhbignb3JkZXJzLnJldHVybicpO1xyXG4gICAgY29uc3QgY2FuSW5zcGVjdFJldHVybiA9IHVzZUNhbignaW52ZW50b3J5LmFkanVzdCcpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdFJldHVybkNhc2VzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0UmV0dXJuQ2FzZXMnKSB9KTtcclxuICAgIGNvbnN0IFtvcmRlclNlYXJjaElucHV0LCBzZXRPcmRlclNlYXJjaElucHV0XSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtvcmRlclNlYXJjaCwgc2V0T3JkZXJTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldE9yZGVyU2VhcmNoKG9yZGVyU2VhcmNoSW5wdXQudHJpbSgpKSwgMjUwKTtcclxuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9LCBbb3JkZXJTZWFyY2hJbnB1dF0pO1xyXG4gICAgY29uc3Qgb3JkZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RPcmRlcnMnLCB7IHF1ZXJ5OiB7IHE6IG9yZGVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0sIGNhblJlYWRPcmRlcnMpO1xyXG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUmV0dXJuQ2FzZScsIFsnbGlzdFJldHVybkNhc2VzJ10pO1xyXG4gICAgY29uc3QgaW5zcGVjdCA9IHVzZUNvbW1hbmQoJ2luc3BlY3RSZXR1cm4nLCBbJ2xpc3RSZXR1cm5DYXNlcycsICdnZXRSZXR1cm5DYXNlJywgJ2xpc3RTdG9ja1NuYXBzaG90cycsICdnZXRQcm9maXRMb3NzJ10pO1xyXG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbb3JkZXJJZCwgc2V0T3JkZXJdID0gdXNlU3RhdGUocGFyYW1zLmdldCgnb3JkZXJJZCcpIHx8ICcnKSwgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKCcnKSwgW3F1YW50aXRpZXMsIHNldFF1YW50aXRpZXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRPcmRlckRldGFpbCA9IHVzZUFwaSgnZ2V0T3JkZXInLCB7IHBhdGg6IHsgb3JkZXJJZCB9IH0sIGNhblJlYWRPcmRlcnMgJiYgISFvcmRlcklkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkT3JkZXIgPSBvcmRlcnMuZGF0YT8uZGF0YS5maW5kKG9yZGVyID0+IG9yZGVyLmlkID09PSBvcmRlcklkKSB8fCBzZWxlY3RlZE9yZGVyRGV0YWlsLmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPFJldHVybkNhc2UgfCBudWxsPihudWxsKSwgW2luc3BlY3Rpb25zLCBzZXRJbnNwZWN0aW9uc10gPSB1c2VTdGF0ZTxSZXR1cm5JbnNwZWN0aW9uWydsaW5lcyddPihbXSk7XHJcbiAgICBjb25zdCBzZWxlY3RlZFJldHVybiA9IHVzZUFwaSgnZ2V0UmV0dXJuQ2FzZScsIHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZD8uaWQgfHwgJycgfSB9LCAhIXNlbGVjdGVkICYmIGNhblJlYWRPcmRlcnMpO1xyXG4gICAgY29uc3QgaW5zcGVjdGlvbkNhc2UgPSBzZWxlY3RlZFJldHVybi5kYXRhPy5kYXRhO1xyXG4gICAgY29uc3QgaW5zcGVjdGlvbkVkaXRvciA9IHVzZVZlcnNpb25lZERyYWZ0KHtcclxuICAgICAgICBpZGVudGl0eTogYCR7c2hvcC5pZH06cmV0dXJuOiR7c2VsZWN0ZWQ/LmlkIHx8ICdub25lJ31gLFxyXG4gICAgICAgIHNvdXJjZTogc2VsZWN0ZWQgJiYgaW5zcGVjdGlvbkNhc2U/LmlkID09PSBzZWxlY3RlZC5pZCA/IHJldHVybkluc3BlY3Rpb25TbmFwc2hvdChpbnNwZWN0aW9uQ2FzZSkgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgZHJhZnQ6IHsgbGluZXM6IGluc3BlY3Rpb25zIH0sIGFwcGx5OiB2YWx1ZXMgPT4gc2V0SW5zcGVjdGlvbnModmFsdWVzLmxpbmVzKSxcclxuICAgICAgICByZWZyZXNoOiAoKSA9PiBzZWxlY3RlZFJldHVybi5yZWZldGNoKHsgdGhyb3dPbkVycm9yOiB0cnVlIH0pLFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBkZXRhaWxzUmVhZHkgPSAhIXNlbGVjdGVkICYmICEhaW5zcGVjdGlvbkNhc2UgJiYgaW5zcGVjdGlvbkNhc2UuaWQgPT09IHNlbGVjdGVkLmlkICYmIGluc3BlY3Rpb25FZGl0b3IuYmFzZWxpbmU/LmlkZW50aXR5ID09PSBgJHtzaG9wLmlkfTpyZXR1cm46JHtzZWxlY3RlZC5pZH1gO1xyXG4gICAgY29uc3QgZWRpdEluc3BlY3Rpb24gPSAocjogUmV0dXJuQ2FzZSkgPT4geyBzZXRTZWxlY3RlZChyKTsgc2V0SW5zcGVjdGlvbnMoW10pOyB9O1xyXG4gICAgY29uc3QgcmVxdWVzdGVkTGluZXMgPSBzZWxlY3RlZE9yZGVyPy5saW5lcy5tYXAobGluZSA9PiB7XHJcbiAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBxdWFudGl0aWVzW2xpbmUuaWRdID8/ICcwJztcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBvcmRlckxpbmVJZDogbGluZS5pZCxcclxuICAgICAgICAgICAgcXVhbnRpdHksXHJcbiAgICAgICAgICAgIGludmFsaWQ6IHF1YW50aXR5ICE9PSAnMCcgJiYgKCEvXlxcZCskLy50ZXN0KHF1YW50aXR5KSB8fCBOdW1iZXIocXVhbnRpdHkpIDwgMSB8fCBOdW1iZXIocXVhbnRpdHkpID4gbGluZS5xdWFudGl0eSlcclxuICAgICAgICB9O1xyXG4gICAgfSkuZmlsdGVyKGxpbmUgPT4gbGluZS5xdWFudGl0eSAhPT0gJzAnKSB8fCBbXTtcclxuICAgIGNvbnN0IGNyZWF0ZUludmFsaWQgPSAhc2VsZWN0ZWRPcmRlciB8fCAhWydkZWxpdmVyZWQnLCAncGFydF9yZXR1cm5lZCddLmluY2x1ZGVzKHNlbGVjdGVkT3JkZXIuZnVsZmlsbG1lbnRTdGF0ZSkgfHwgIXJlYXNvbi50cmltKCkgfHwgY29kZVBvaW50TGVuZ3RoKHJlYXNvbikgPiAxXzAwMCB8fCByZXF1ZXN0ZWRMaW5lcy5sZW5ndGggPT09IDAgfHwgcmVxdWVzdGVkTGluZXMuc29tZShsaW5lID0+IGxpbmUuaW52YWxpZCk7XHJcbiAgICBjb25zdCBpbnNwZWN0aW9uSW52YWxpZCA9ICFkZXRhaWxzUmVhZHkgfHwgIWluc3BlY3Rpb25DYXNlIHx8IGluc3BlY3Rpb25zLmxlbmd0aCA9PT0gMCB8fCBpbnNwZWN0aW9ucy5zb21lKGxpbmUgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJldHVybmVkID0gaW5zcGVjdGlvbkNhc2UubGluZXMuZmluZChpdGVtID0+IGl0ZW0ub3JkZXJMaW5lSWQgPT09IGxpbmUub3JkZXJMaW5lSWQpPy5xdWFudGl0eSA/PyAwO1xyXG4gICAgICAgIHJldHVybiAhTnVtYmVyLmlzSW50ZWdlcihsaW5lLmFjY2VwdGVkUXVhbnRpdHkpIHx8IGxpbmUuYWNjZXB0ZWRRdWFudGl0eSA8IDAgfHwgbGluZS5hY2NlcHRlZFF1YW50aXR5ID4gcmV0dXJuZWQgfHwgIWxpbmUucmVhc29uLnRyaW0oKSB8fCBjb2RlUG9pbnRMZW5ndGgobGluZS5yZWFzb24pID4gMV8wMDA7XHJcbiAgICB9KTtcclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwixJDhu5VpIHbDoCB0cuG6oyBow6BuZ1wiIHN1YnRpdGxlPVwiTmjhuq1uIGzhuqFpLCBraeG7g20gdMOsbmggdHLhuqFuZywgeMOhYyDEkeG7i25oIG5naMSpYSB24bulIGhvw6BuLiBLaMO0bmcgdOG7sSBj4buZbmcgaMOgbmcgY2jGsGEga2nhu4NtIHbDoG8gdOG7k24gYsOhbi5cIiBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9yZGVycy5yZXR1cm5cIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjYW5SZWFkT3JkZXJzfSBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5U4bqhbyB5w6p1IGPhuqd1IHRy4bqjPC9NdXRhdGlvbkJ1dHRvbj59Lz5cclxuICAgICAgICB7IWNhblJlYWRPcmRlcnMgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIHN4PXtsYXlvdXRTeC5ub3RpY2UuYWZ0ZXJHYXB9PkPhuqduIHF1eeG7gW4gb3JkZXJzLnJlYWQgxJHhu4MgY2jhu41uIMSRxqFuIGfhu5FjIHbDoCB44butIGzDvSB5w6p1IGPhuqd1IHRy4bqjLjwvQWxlcnQ+fVxyXG4gICAgICAgIDxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0UmV0dXJuQ2FzZXNcIiAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIlnDqnUgY+G6p3UgxJHhu5VpIHRy4bqjXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17ciA9PiByLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ1nDqnUgY+G6p3UnLCByZW5kZXI6IHIgPT4gci5pZCB9LFxyXG4gICAgICAgICAgICB7IGtleTogJ29yZGVyJywgbGFiZWw6ICfEkMahbiBn4buRYycsIHJlbmRlcjogciA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9vcmRlcnMvJHtyLm9yZGVySWR9YH0+e3Iub3JkZXJJZH08L1JvdXRlTGluaz4gfSxcclxuICAgICAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLnN0YXRlfSBkb21haW49XCJyZXR1cm5cIi8+IH0sXHJcbiAgICAgICAgICAgIHsga2V5OiAncmVmdW5kJywgbGFiZWw6ICdOZ2jEqWEgduG7pSBob8OgbicsIHJlbmRlcjogciA9PiA8QW1vdW50IHZhbHVlPXtyLnJlZnVuZE9ibGlnYXRpb259Lz4gfSxcclxuICAgICAgICAgICAgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJycsIHJlbmRlcjogciA9PiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludmVudG9yeS5hZGp1c3RcIiBkaXNhYmxlZD17IWNhbkluc3BlY3RSZXR1cm4gfHwgWydpbnNwZWN0ZWQnLCAnY2xvc2VkJywgJ3JlamVjdGVkJ10uaW5jbHVkZXMoci5zdGF0ZSl9IG9uQ2xpY2s9eygpID0+IGVkaXRJbnNwZWN0aW9uKHIpfT5LaeG7g20gbmjhuq1uPC9NdXRhdGlvbkJ1dHRvbj4gfVxyXG4gICAgICAgIF19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+XHJcbiAgICAgICAgPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9XCJZw6p1IGPhuqd1IHRy4bqjIGjDoG5nXCIgb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17Y3JlYXRlSW52YWxpZCB8fCAhY2FuUmVhZE9yZGVycyB8fCAhY2FuQ3JlYXRlUmV0dXJuIHx8IGNyZWF0ZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHk6IHsgb3JkZXJJZCwgcmVhc29uOiByZWFzb24udHJpbSgpLCBsaW5lczogcmVxdWVzdGVkTGluZXMubWFwKGxpbmUgPT4gKHsgb3JkZXJMaW5lSWQ6IGxpbmUub3JkZXJMaW5lSWQsIHF1YW50aXR5OiBOdW1iZXIobGluZS5xdWFudGl0eSkgfSkpIH0gfSk7XHJcbiAgICAgICAgICAgICAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldFF1YW50aXRpZXMoe30pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhdGNoIHsgLyoga2VlcCB1c2VyIGlucHV0cyBhbmQgc2hvdyB0aGUgQVBJIGVycm9yICovIH1cclxuICAgICAgICB9fT5U4bqhbyB5w6p1IGPhuqd1PC9CdXR0b24+fT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3J9Lz5cclxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICAgICAgeyFjYW5SZWFkT3JkZXJzICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5LaMO0bmcgY8OzIHF1eeG7gW4gxJHhu41jIGRhbmggc8OhY2ggxJHGoW4uPC9BbGVydD59XHJcblxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlTDrG0gxJHGoW4gaMOgbmdcIiB2YWx1ZT17b3JkZXJTZWFyY2hJbnB1dH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldE9yZGVyU2VhcmNoSW5wdXQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5SZWFkT3JkZXJzfSBoZWxwZXJUZXh0PVwiVMOsbSB0aGVvIG3DoyDEkcahbiBob+G6t2Mga2jDoWNoIGjDoG5nOyB0cnV5IHbhuqVuIHTDrG0ga2nhur9tIGRvIEFQSSBo4buXIHRy4bujLlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwixJDGoW4gaMOgbmcgxJHDoyBnaWFvXCIgc2VsZWN0IHZhbHVlPXtvcmRlcklkfSBvbkNoYW5nZT17ZXZlbnQgPT4geyBzZXRPcmRlcihldmVudC50YXJnZXQudmFsdWUpOyBzZXRRdWFudGl0aWVzKHt9KTsgfX0gZGlzYWJsZWQ9eyFjYW5SZWFkT3JkZXJzIHx8IChvcmRlcnMuaXNQZW5kaW5nICYmICFvcmRlcnMuZGF0YSl9IGhlbHBlclRleHQ9XCJDaOG7iSDEkcahbiDEkcOjIGdpYW8gaG/hurdjIMSRYW5nIHRy4bqjIG3hu5l0IHBo4bqnbi4gQVBJIGtp4buDbSB0cmEgdOG7lW5nIHPhu5EgbMaw4bujbmcgY8OybiDEkcaw4bujYyB0cuG6oy5cIj5cclxuICAgICAgICAgICAgICAgICAgICB7b3JkZXJJZCAmJiAhb3JkZXJzLmRhdGE/LmRhdGEuc29tZShvcmRlciA9PiBvcmRlci5pZCA9PT0gb3JkZXJJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXtvcmRlcklkfT57c2VsZWN0ZWRPcmRlcj8uaWQgfHwgKHNlbGVjdGVkT3JkZXJEZXRhaWwuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIMSRxqFuIMSRw6MgY2jhu41u4oCmJyA6IG9yZGVySWQpfTwvTWVudUl0ZW0+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtvcmRlcnMuZGF0YT8uZGF0YS5maWx0ZXIob3JkZXIgPT4gWydkZWxpdmVyZWQnLCAncGFydF9yZXR1cm5lZCddLmluY2x1ZGVzKG9yZGVyLmZ1bGZpbGxtZW50U3RhdGUpKS5tYXAob3JkZXIgPT4gPE1lbnVJdGVtIGtleT17b3JkZXIuaWR9IHZhbHVlPXtvcmRlci5pZH0+e29yZGVyLmlkfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwixJHGoW4gaMOgbmdcIiBsb2FkZWRDb3VudD17b3JkZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtvcmRlcnMuaGFzTW9yZX0gYnVzeT17b3JkZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e29yZGVycy5sb2FkTW9yZX0vPlxyXG4gICAgICAgICAgICAgICAge29yZGVycy5pc0Vycm9yICYmIDxGaWVsZEdyb3VwID48RXJyb3JOb3RpY2UgZXJyb3I9e29yZGVycy5lcnJvcn0vPjxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChvcmRlcnMuaXNGZXRjaE5leHRQYWdlRXJyb3IgPyBvcmRlcnMubG9hZE1vcmUoKSA6IG9yZGVycy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIHPDoWNoIMSRxqFuPC9CdXR0b24+PC9GaWVsZEdyb3VwPn1cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZE9yZGVyRGV0YWlsLmlzRXJyb3IgJiYgPEVycm9yTm90aWNlIGVycm9yPXtzZWxlY3RlZE9yZGVyRGV0YWlsLmVycm9yfS8+fVxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkT3JkZXI/LmxpbmVzLm1hcChsaW5lID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IHJlcXVlc3RlZExpbmVzLmZpbmQoaXRlbSA9PiBpdGVtLm9yZGVyTGluZUlkID09PSBsaW5lLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gPFRleHRGaWVsZCBrZXk9e2xpbmUuaWR9IGxhYmVsPXtgJHtsaW5lLm5hbWV9ICh04buRaSDEkWEgJHtsaW5lLnF1YW50aXR5fSlgfSB0eXBlPVwibnVtYmVyXCIgaW5wdXRQcm9wcz17eyBtaW46IDAsIG1heDogbGluZS5xdWFudGl0eSwgc3RlcDogMSB9fSB2YWx1ZT17cXVhbnRpdGllc1tsaW5lLmlkXSA/PyAnMCd9IGVycm9yPXshIWZpZWxkPy5pbnZhbGlkfSBoZWxwZXJUZXh0PXtmaWVsZD8uaW52YWxpZCA/IGBOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMSDEkeG6v24gJHtsaW5lLnF1YW50aXR5fTsgQVBJIGtp4buDbSB0cmEgY8OhYyB5w6p1IGPhuqd1IHRy4bqjIHRyxrDhu5tjIMSRw7MuYCA6IGBT4buRIGzGsOG7o25nIGfhu5FjICR7bGluZS5xdWFudGl0eX07IGdp4bubaSBo4bqhbiBjw7JuIGzhuqFpIGRvIEFQSSBxdXnhur90IMSR4buLbmguYH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFF1YW50aXRpZXMoY3VycmVudCA9PiAoeyAuLi5jdXJyZW50LCBbbGluZS5pZF06IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9Lz47XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gdHLhuqNcIiBtdWx0aWxpbmUgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJlYXNvbihldmVudC50YXJnZXQudmFsdWUpfSBlcnJvcj17IXJlYXNvbi50cmltKCkgfHwgY29kZVBvaW50TGVuZ3RoKHJlYXNvbikgPiAxXzAwMH0gaGVscGVyVGV4dD17YCR7Y29kZVBvaW50TGVuZ3RoKHJlYXNvbil9LzEuMDAwIGvDvSB04buxYH0vPlxyXG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgICAgIDxFZGl0RGlhbG9nIGFsbG93RWRpdHNXaGlsZUJ1c3kgb3Blbj17ISFzZWxlY3RlZH0gdGl0bGU9XCJLaeG7g20gbmjhuq1uIGjDoG5nIHRy4bqjXCIgb25DbG9zZT17KCkgPT4geyBzZXRTZWxlY3RlZChudWxsKTsgc2V0SW5zcGVjdGlvbnMoW10pOyB9fSBidXN5PXtpbnNwZWN0LnBlbmRpbmd9IGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW52ZW50b3J5LmFkanVzdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17aW5zcGVjdGlvbkludmFsaWQgfHwgIWNhbkluc3BlY3RSZXR1cm59IGJ1c3k9e2luc3BlY3QucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXNlbGVjdGVkIHx8ICFpbnNwZWN0aW9uQ2FzZSB8fCBpbnNwZWN0aW9uSW52YWxpZClcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXBhcmVkID0gaW5zcGVjdGlvbkVkaXRvci5wcmVwYXJlKCk7IGlmICghcHJlcGFyZWQpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgbGluZXM6IGluc3BlY3Rpb25zIH07XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBpbnNwZWN0LmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IGluc3BlY3Rpb25DYXNlLmlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBwcmVwYXJlZC52ZXJzaW9uLCBsaW5lczogaW5zcGVjdGlvbnMgfSB9KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBlcnNpc3RlZCA9IHsgdmVyc2lvbjogcmVzdWx0LmRhdGEudmVyc2lvbiwgdmFsdWVzOiBzdWJtaXR0ZWQgfTtcclxuICAgICAgICAgICAgICAgIGlmIChpbnNwZWN0aW9uRWRpdG9yLmNvbW1pdHRlZChwZXJzaXN0ZWQsIHN1Ym1pdHRlZCkpIHsgc2V0U2VsZWN0ZWQobnVsbCk7IHNldEluc3BlY3Rpb25zKFtdKTsgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikgeyBpbnNwZWN0aW9uRWRpdG9yLmZhaWxlZChlcnJvcik7IH1cclxuICAgICAgICB9fT5Yw6FjIG5o4bqtbiBraeG7g20gbmjhuq1uPC9NdXRhdGlvbkJ1dHRvbj59PlxyXG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2luc3BlY3QuZXJyb3J9Lz5cclxuICAgICAgICAgICAgPERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtpbnNwZWN0aW9uRWRpdG9yfSBsYWJlbHM9e3sgbGluZXM6ICdQaMawxqFuZyDDoW4ga2nhu4NtIG5o4bqtbiB04burIGjhu5Mgc8ahIHRy4bqjIGjDoG5nJyB9fSBidXN5PXtpbnNwZWN0LnBlbmRpbmd9Lz5cclxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPk5nxrDhu51pIHRo4bqtdCB4w6FjIG5o4bqtbiDEkcOjIG5o4bqtbiB2w6Aga2nhu4NtIGjDoG5nLiBDaOG7iSDigJxCw6FuIGzhuqFpIMSRxrDhu6Nj4oCdIG3hu5tpIMSRxrDhu6NjIGLhu5Ugc3VuZyB04buTbiBraOG6oyBk4bulbmcuPC9BbGVydD5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJldHVybi5pc1BlbmRpbmcgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPsSQYW5nIHThuqNpIGjhu5Mgc8ahIHRy4bqjIGjDoG5nIG3hu5tpIG5o4bqldOKApjwvVHlwb2dyYXBoeT59XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSZXR1cm4uaXNFcnJvciAmJiA8RmllbGRHcm91cCA+PEVycm9yTm90aWNlIGVycm9yPXtzZWxlY3RlZFJldHVybi5lcnJvcn0vPjxCdXR0b24gb25DbGljaz17KCkgPT4geyB2b2lkIHNlbGVjdGVkUmV0dXJuLnJlZmV0Y2goKTsgfX0+VOG6o2kgbOG6oWkgaOG7kyBzxqE8L0J1dHRvbj48L0ZpZWxkR3JvdXA+fVxyXG4gICAgICAgICAgICAgICAge2RldGFpbHNSZWFkeSAmJiBpbnNwZWN0aW9ucy5tYXAoKGxpbmUsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmV0dXJuZWRRdWFudGl0eSA9IGluc3BlY3Rpb25DYXNlLmxpbmVzLmZpbmQoaXRlbSA9PiBpdGVtLm9yZGVyTGluZUlkID09PSBsaW5lLm9yZGVyTGluZUlkKT8ucXVhbnRpdHkgPz8gMDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpbnZhbGlkUXVhbnRpdHkgPSAhTnVtYmVyLmlzSW50ZWdlcihsaW5lLmFjY2VwdGVkUXVhbnRpdHkpIHx8IGxpbmUuYWNjZXB0ZWRRdWFudGl0eSA8IDAgfHwgbGluZS5hY2NlcHRlZFF1YW50aXR5ID4gcmV0dXJuZWRRdWFudGl0eTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gPEZpZWxkR3JvdXAga2V5PXtsaW5lLm9yZGVyTGluZUlkfSA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5PntsaW5lLm9yZGVyTGluZUlkfTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlPhu5EgbMaw4bujbmcgbmjhuq1uXCIgdHlwZT1cIm51bWJlclwiIGlucHV0UHJvcHM9e3sgbWluOiAwLCBtYXg6IHJldHVybmVkUXVhbnRpdHksIHN0ZXA6IDEgfX0gdmFsdWU9e051bWJlci5pc05hTihsaW5lLmFjY2VwdGVkUXVhbnRpdHkpID8gJycgOiBsaW5lLmFjY2VwdGVkUXVhbnRpdHl9IGVycm9yPXtpbnZhbGlkUXVhbnRpdHl9IGhlbHBlclRleHQ9e2ludmFsaWRRdWFudGl0eSA/IGBOaOG6rXAgc+G7kSBuZ3V5w6puIHThu6sgMCDEkeG6v24gJHtyZXR1cm5lZFF1YW50aXR5fS5gIDogYFThu5FpIMSRYSAke3JldHVybmVkUXVhbnRpdHl9IHRoZW8gecOqdSBj4bqndSB0cuG6oy5gfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0SW5zcGVjdGlvbnMoY3VycmVudCA9PiBjdXJyZW50Lm1hcCgoaXRlbSwgcm93KSA9PiBpbmRleCA9PT0gcm93ID8geyAuLi5pdGVtLCBhY2NlcHRlZFF1YW50aXR5OiBldmVudC50YXJnZXQudmFsdWUgPT09ICcnID8gTnVtYmVyLk5hTiA6IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpIH0gOiBpdGVtKSl9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJUw6xuaCB0cuG6oW5nXCIgdmFsdWU9e2xpbmUuZGlzcG9zaXRpb259IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRJbnNwZWN0aW9ucyhjdXJyZW50ID0+IGN1cnJlbnQubWFwKChpdGVtLCByb3cpID0+IGluZGV4ID09PSByb3cgPyB7IC4uLml0ZW0sIGRpc3Bvc2l0aW9uOiBldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIGxpbmUuZGlzcG9zaXRpb24gfSA6IGl0ZW0pKX0+PE1lbnVJdGVtIHZhbHVlPVwicXVhcmFudGluZWRcIj5Dw6FjaCBseSAvIGNo4budIHjDoWMgbWluaDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwic2VsbGFibGVcIj5Cw6FuIGzhuqFpIMSRxrDhu6NjPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJkYW1hZ2VkXCI+SMawIGjhu49uZzwvTWVudUl0ZW0+PC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJHaGkgbmjhuq1uIGtp4buDbSB0cmFcIiB2YWx1ZT17bGluZS5yZWFzb259IGVycm9yPXshbGluZS5yZWFzb24udHJpbSgpIHx8IGNvZGVQb2ludExlbmd0aChsaW5lLnJlYXNvbikgPiAxXzAwMH0gaGVscGVyVGV4dD17YCR7Y29kZVBvaW50TGVuZ3RoKGxpbmUucmVhc29uKX0vMS4wMDAga8O9IHThu7FgfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0SW5zcGVjdGlvbnMoY3VycmVudCA9PiBjdXJyZW50Lm1hcCgoaXRlbSwgcm93KSA9PiBpbmRleCA9PT0gcm93ID8geyAuLi5pdGVtLCByZWFzb246IGV2ZW50LnRhcmdldC52YWx1ZSB9IDogaXRlbSkpfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEaXZpZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPjtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgPC8+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBvcmRlclNuYXBzaG90KG9yZGVyOiBPcmRlcikge1xyXG4gICAgcmV0dXJuIHsgdmVyc2lvbjogb3JkZXIudmVyc2lvbiwgdmFsdWVzOiB7IGN1c3RvbWVySWQ6IG9yZGVyLmN1c3RvbWVySWQsIGNvbnZlcnNhdGlvbklkOiBvcmRlci5jb252ZXJzYXRpb25JZCB8fCAnJywgd2FyZWhvdXNlOiBvcmRlci53YXJlaG91c2VJZCwgYWRkcmVzc0lkOiBvcmRlci5zaGlwcGluZ0FkZHJlc3NJZCB8fCAnJywgbm90ZXM6IHR5cGVvZiBvcmRlci5ub3RlcyA9PT0gJ3N0cmluZycgPyBvcmRlci5ub3RlcyA6ICcnLCBsaW5lczogb3JkZXIubGluZXMubWFwKGxpbmUgPT4gKHsgdmFyaWFudElkOiBsaW5lLnZhcmlhbnRJZCwgcXVhbnRpdHk6IFN0cmluZyhsaW5lLnF1YW50aXR5KSB9KSkgfSB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiByZXR1cm5JbnNwZWN0aW9uU25hcHNob3QoaXRlbTogUmV0dXJuQ2FzZSkge1xyXG4gICAgY29uc3QgbGluZXM6IFJldHVybkluc3BlY3Rpb25bJ2xpbmVzJ10gPSBpdGVtLmxpbmVzLm1hcChsaW5lID0+ICh7XHJcbiAgICAgICAgb3JkZXJMaW5lSWQ6IGxpbmUub3JkZXJMaW5lSWQsIGFjY2VwdGVkUXVhbnRpdHk6IGxpbmUucXVhbnRpdHksXHJcbiAgICAgICAgZGlzcG9zaXRpb246IGxpbmUuZGlzcG9zaXRpb24gPT09ICdwZW5kaW5nJyA/ICdxdWFyYW50aW5lZCcgOiBsaW5lLmRpc3Bvc2l0aW9uLFxyXG4gICAgICAgIHJlYXNvbjogbGluZS5kaXNwb3NpdGlvbiA9PT0gJ3BlbmRpbmcnID8gJ0No4budIGtp4buDbSB0cmEgdMOsbmggdHLhuqFuZyBow6BuZyBuaOG6rW4gbOG6oWknIDogbGluZS5yZWFzb24sXHJcbiAgICB9KSk7XHJcbiAgICByZXR1cm4geyB2ZXJzaW9uOiBpdGVtLnZlcnNpb24sIHZhbHVlczogeyBsaW5lcyB9IH07XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvb3JkZXJzL2luZGV4LnRzeCJ9