import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/procurement/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32956-7005b97b-d6c2-47b8-a213-822d66e7484c-procurement-lazy-probe/deps/react_jsx-dev-runtime.js?v=50d8a56f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
import { useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { FieldGroup, FormFields } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport6_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32956-7005b97b-d6c2-47b8-a213-822d66e7484c-procurement-lazy-probe/deps/react.js?v=50d8a56f"; const useState = __vite__cjsImport6_react["useState"]; const useSyncExternalStore = __vite__cjsImport6_react["useSyncExternalStore"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useNavigate, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32956-7005b97b-d6c2-47b8-a213-822d66e7484c-procurement-lazy-probe/deps/react-router-dom.js?v=9f82f347";
import { Alert, Button, Checkbox, FormControlLabel, MenuItem, Stack, Tab, Tabs, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32956-7005b97b-d6c2-47b8-a213-822d66e7484c-procurement-lazy-probe/deps/@mui_material.js?v=170b510c";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { ApiError, UnknownResultError } from "/src/shared/api/errors.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, codePointLength, dateTime } from "/src/shared/model/format.ts";
import { intentSnapshot, subscribeIntents } from "/src/shared/api/intents.ts";
import { PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, Amount, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
export function SuppliersPage() {
  _s();
  const { shop } = useScope();
  const [params] = useSearchParams();
  const list = useApi("listSuppliers", { query: { limit: 20, cursor: params.get("supplierCursor") || void 0 } });
  const offers = useApi("listSupplierOffers", { query: { limit: 20, cursor: params.get("offerCursor") || void 0 } });
  const products = usePagedApi("listProducts");
  const create = useCommand("createSupplier", ["listSuppliers"]);
  const update = useCommand("updateSupplier", ["listSuppliers"]);
  const status = useCommand("setSupplierStatus", ["listSuppliers"]);
  const addOffer = useCommand("createSupplierOffer", ["listSupplierOffers"]);
  const [edit, setEdit] = useState(), [name, setName] = useState(""), [contact, setContact] = useState(""), [lead, setLead] = useState("3"), [terms, setTerms] = useState(""), [method, setMethod] = useState("manual"), [adapter, setAdapter] = useState("");
  const [statusItem, setStatusItem] = useState(null), [statusValue, setStatusValue] = useState("approved"), [reason, setReason] = useState("");
  const [offerSupplier, setOfferSupplier] = useState(null), [variant, setVariant] = useState(""), [cost, setCost] = useState(""), [minimum, setMinimum] = useState("1"), [pack, setPack] = useState("1");
  const supplierDetailId = edit?.id || statusItem?.id || "";
  const supplierDetail = useApi("getSupplier", { path: { resourceId: supplierDetailId } }, !!supplierDetailId);
  const supplierSource = edit?.id && supplierDetail.data?.data.id === edit.id ? supplierDetail.data.data : edit;
  const supplierEditor = useVersionedDraft({
    identity: `${shop.id}:supplier:${edit?.id || "new"}`,
    source: supplierSource ? supplierSnapshot(supplierSource) : void 0,
    draft: { name, contact, lead, terms, method, adapter },
    apply: (values) => {
      setName(values.name);
      setContact(values.contact);
      setLead(values.lead);
      setTerms(values.terms);
      setMethod(values.method);
      setAdapter(values.adapter);
    },
    refresh: () => supplierDetail.refetch({ throwOnError: true })
  });
  const supplierFormValid = !!name.trim() && codePointLength(name.trim()) <= 160 && !!contact.trim() && codePointLength(contact.trim()) <= 200 && Number.isInteger(Number(lead)) && Number(lead) >= 0 && codePointLength(terms) <= 500 && (method === "manual" || !!adapter.trim());
  const offerFormValid = !!variant && /^(0|[1-9]\d*)(\.\d{1,4})?$/.test(cost) && Number.isInteger(Number(minimum)) && Number(minimum) >= 1 && Number.isInteger(Number(pack)) && Number(pack) >= 1 && Number.isInteger(Number(lead)) && Number(lead) >= 0;
  const open = (s) => {
    setEdit(s);
    setName(s?.name || "");
    setContact(s?.contactLabel || "");
    setLead(String(s?.leadTimeDays ?? 3));
    setTerms(s?.paymentTerms || "");
    setMethod(s?.sendMethod || "manual");
    setAdapter(s?.approvedAdapterId || "");
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhà cung cấp hàng hóa", subtitle: "Tách biệt với nhà cung cấp AI. Mua hàng chỉ trong điều kiện và quyền đã duyệt.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", variant: "contained", onClick: () => open(null), children: "Thêm nhà cung cấp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 62,
      columnNumber: 153
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 62,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Nhà cung cấp", rows: list.data.data, rowKey: (s) => s.id, columns: [
        {
          key: "name",
          label: "Nhà cung cấp",
          render: (s) => /* @__PURE__ */ jsxDEV(Stack, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: s.name }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 64,
              columnNumber: 71
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: s.contactLabel }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 64,
              columnNumber: 155
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 64,
            columnNumber: 64
          }, this)
        },
        { key: "lead", label: "Thời gian giao", render: (s) => `${s.leadTimeDays} ngày` },
        { key: "terms", label: "Thanh toán", render: (s) => s.paymentTerms },
        { key: "state", label: "Trạng thái", render: (s) => /* @__PURE__ */ jsxDEV(Status, { value: s.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 66,
          columnNumber: 216
        }, this) },
        {
          key: "actions",
          label: "",
          render: (s) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", flexWrap: "wrap", children: [
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", onClick: () => open(s), children: "Sửa" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 68,
              columnNumber: 94
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", onClick: () => {
              setOfferSupplier(s);
              setVariant("");
              setCost("");
              setMinimum("1");
              setPack("1");
              setLead(String(s.leadTimeDays));
            }, children: "Thêm báo giá" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 68,
              columnNumber: 185
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.manage", onClick: () => {
              setStatusItem(s);
              setReason("");
              setStatusValue(s.status === "approved" ? "suspended" : "approved");
            }, children: "Duyệt / tạm dừng" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 68,
              columnNumber: 388
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 68,
            columnNumber: 55
          }, this)
        }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 62,
        columnNumber: 358
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page, cursorParam: "supplierCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 70,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 62,
      columnNumber: 356
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 62,
      columnNumber: 292
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 62,
      columnNumber: 285
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Báo giá sản phẩm", subtitle: "Giá vốn, lượng tối thiểu, quy cách và hiệu lực được quản lý riêng.", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: offers, pendingProfile: "section", children: offers.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Báo giá sản phẩm", rows: offers.data.data, rowKey: (o) => o.id, columns: [
        { key: "supplier", label: "Nhà cung cấp", render: (o) => list.data?.data.find((s) => s.id === o.supplierId)?.name || `Mã nhà cung cấp: ${o.supplierId}` },
        {
          key: "sku",
          label: "Biến thể",
          render: (o) => products.data?.data.flatMap((p) => p.variants).find((v) => v.id === o.variantId)?.sku || `Mã biến thể: ${o.variantId}`
        },
        { key: "cost", label: "Đơn giá", render: (o) => /* @__PURE__ */ jsxDEV(Amount, { value: o.unitCost }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 76,
          columnNumber: 59
        }, this) },
        { key: "moq", label: "Tối thiểu / Quy cách", render: (o) => `${o.minimumQuantity} / ${o.packSize}` },
        { key: "date", label: "Hiệu lực tới", render: (o) => o.validUntil ? dateTime(o.validUntil, shop.timezone) : "Chưa quy định" }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 71,
        columnNumber: 204
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: offers.data.page, cursorParam: "offerCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 77,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 71,
      columnNumber: 202
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 71,
      columnNumber: 134
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 71,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { allowEditsWhileBusy: true, open: edit !== void 0, title: edit ? "Cập nhật nhà cung cấp" : "Nhà cung cấp mới", onClose: () => setEdit(void 0), busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !supplierFormValid || create.pending || update.pending || !!edit?.id && (!supplierDetail.data || supplierDetail.isLoading), onClick: async () => {
      try {
        const body = {
          name: name.trim(),
          contactLabel: contact.trim(),
          currency: edit?.currency || shop.currency,
          leadTimeDays: Number(lead),
          paymentTerms: terms.trim(),
          sendMethod: method,
          approvedAdapterId: method === "approved_adapter" ? adapter.trim() : null
        };
        const submitted = { name, contact, lead, terms, method, adapter };
        let result;
        if (edit) {
          const prepared = supplierEditor.prepare();
          if (!prepared) return;
          const changed = prepared.patch;
          result = await update.execute({ path: { resourceId: edit.id }, version: prepared.version, body: {
            expectedVersion: prepared.version,
            ...changed.name !== void 0 ? { name: body.name } : {},
            ...changed.contact !== void 0 ? { contactLabel: body.contactLabel } : {},
            ...changed.lead !== void 0 ? { leadTimeDays: body.leadTimeDays } : {},
            ...changed.terms !== void 0 ? { paymentTerms: body.paymentTerms } : {},
            ...changed.method !== void 0 ? { sendMethod: body.sendMethod } : {},
            ...changed.adapter !== void 0 || changed.method !== void 0 ? { approvedAdapterId: body.approvedAdapterId } : {}
          } });
        } else result = await create.execute({ body });
        const clean = supplierEditor.committed(supplierSnapshot(result.data), submitted, `${shop.id}:supplier:${result.data.id}`);
        setEdit(clean ? void 0 : result.data);
      } catch (error) {
        supplierEditor.failed(error);
      }
    }, children: "Lưu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 78,
      columnNumber: 204
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || supplierDetail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 100,
        columnNumber: 69
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor: supplierEditor, labels: { name: "Tên nhà cung cấp", contact: "Đầu mối liên hệ", lead: "Thời gian giao", terms: "Điều kiện thanh toán", method: "Cách gửi đơn", adapter: "Adapter" }, busy: create.pending || update.pending }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 100,
        columnNumber: 145
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên nhà cung cấp", value: name, onChange: (e) => setName(limitCodePoints(e.target.value, 160)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 403
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Đầu mối liên hệ", value: contact, onChange: (e) => setContact(limitCodePoints(e.target.value, 200)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 518
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Thời gian giao (ngày)", type: "number", value: lead, onChange: (e) => setLead(e.target.value), inputProps: { min: 0, step: 1 } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 638
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Điều kiện thanh toán", value: terms, onChange: (e) => setTerms(limitCodePoints(e.target.value, 500)), multiline: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 783
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Cách gửi đơn", select: true, value: method, onChange: (e) => setMethod(e.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "manual", children: "Thủ công, có xác nhận" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 100,
            columnNumber: 1029
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "approved_adapter", children: "Adapter đã được duyệt" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 100,
            columnNumber: 1086
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 914
        }, this),
        method === "approved_adapter" && /* @__PURE__ */ jsxDEV(TextField, { label: "Mã adapter đã được duyệt", value: adapter, onChange: (e) => setAdapter(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 1199
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Tạo hồ sơ không tự cấp quyền mua hoặc thanh toán." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 100,
          columnNumber: 1307
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 100,
        columnNumber: 391
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 78,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!statusItem, title: "Đổi trạng thái nhà cung cấp", onClose: () => setStatusItem(null), busy: status.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: codePointLength(reason.trim()) < 5 || status.pending || !supplierDetail.data || supplierDetail.isLoading, onClick: async () => {
      const current = supplierDetail.data?.data;
      if (!current)
        return;
      try {
        await status.execute({ path: { resourceId: current.id }, version: current.version, body: { expectedVersion: current.version, status: statusValue, reason: reason.trim() } });
        setStatusItem(null);
      } catch {
      }
    }, children: "Xác nhận" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 101,
      columnNumber: 137
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: status.error || supplierDetail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 106,
        columnNumber: 50
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { children: supplierDetail.data?.data.name || statusItem?.name }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 106,
          columnNumber: 122
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Trạng thái", select: true, value: statusValue, onChange: (e) => setStatusValue(e.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "approved", children: "Duyệt nhà cung cấp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 106,
            columnNumber: 327
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "suspended", children: "Tạm dừng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 106,
            columnNumber: 383
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "archived", children: "Ngừng sử dụng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 106,
            columnNumber: 430
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 106,
          columnNumber: 199
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (e) => setReason(limitCodePoints(e.target.value, 1e3)), multiline: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 106,
          columnNumber: 493
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 106,
        columnNumber: 110
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 101,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!offerSupplier, title: `Báo giá — ${offerSupplier?.name || ""}`, onClose: () => setOfferSupplier(null), busy: addOffer.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !offerFormValid || addOffer.pending, onClick: async () => {
      if (!offerSupplier)
        return;
      try {
        await addOffer.execute({ body: {
          supplierId: offerSupplier.id,
          variantId: variant,
          unitCost: { amount: cost, currency: offerSupplier.currency },
          minimumQuantity: Number(minimum),
          packSize: Number(pack),
          leadTimeDays: Number(lead),
          validUntil: null
        } });
        setOfferSupplier(null);
      } catch {
      }
    }, children: "Lưu báo giá mới" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 107,
      columnNumber: 158
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: addOffer.error || products.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 114,
        columnNumber: 57
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Biến thể", select: true, value: variant, onChange: (e) => setVariant(e.target.value), children: [
          variant && !products.data?.data.some((product) => product.variants.some((item) => item.id === variant)) && /* @__PURE__ */ jsxDEV(MenuItem, { value: variant, children: variant }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 114,
            columnNumber: 329
          }, this),
          products.data?.data.flatMap((p) => p.variants.map((v) => /* @__PURE__ */ jsxDEV(MenuItem, { value: v.id, children: [
            p.name,
            " · ",
            v.name,
            " · ",
            v.sku
          ] }, v.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 114,
            columnNumber: 434
          }, this)))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 125
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "sản phẩm", loadedCount: products.loadedCount, hasMore: products.hasMore, busy: products.isLoadingMore, onLoadMore: products.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 523
        }, this),
        products.isError && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void (products.isFetchNextPageError ? products.loadMore() : products.refetch());
        }, children: "Thử lại danh sách sản phẩm" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 702
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giá nhập đơn vị", value: cost, onChange: (e) => setCost(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 858
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: "row", children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Lượng tối thiểu", type: "number", value: minimum, onChange: (e) => setMinimum(e.target.value), inputProps: { min: 1, step: 1 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 114,
            columnNumber: 978
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Bội số đóng gói", type: "number", value: pack, onChange: (e) => setPack(e.target.value), inputProps: { min: 1, step: 1 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 114,
            columnNumber: 1123
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 950
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Thời gian giao (ngày)", type: "number", value: lead, onChange: (e) => setLead(e.target.value), inputProps: { min: 0, step: 1 } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 114,
          columnNumber: 1275
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 114,
        columnNumber: 113
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 107,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
}
_s(SuppliersPage, "uJaCTK2L/KcssQx1xhp5G8hCak0=", false, function() {
  return [useScope, useSearchParams, useApi, useApi, usePagedApi, useCommand, useCommand, useCommand, useCommand, useApi, useVersionedDraft];
});
_c = SuppliersPage;
export function ReplenishmentPage() {
  _s2();
  const { shop } = useScope();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const suggestions = useApi("listPurchaseSuggestions", { query: { limit: 20, cursor: params.get("suggestionCursor") || void 0 } });
  const rules = useApi("listReorderRules", { query: { limit: 20, cursor: params.get("ruleCursor") || void 0 } });
  const offers = usePagedApi("listSupplierOffers");
  const suppliers = usePagedApi("listSuppliers");
  const warehouses = usePagedApi("listWarehouses", { query: { status: "active", limit: 20 } });
  const [warehouseId, setWarehouseId] = useState(shop.defaultWarehouseId);
  const canReadBudgetPolicies = useCan("operations.read");
  const evaluate = useCommand("evaluateReorder", ["listPurchaseSuggestions", "listPurchaseOrders", "listPurchaseDelegationReservations", "listBudgetPolicies"]);
  const purchase = useCommand("createPurchaseOrder", ["listPurchaseOrders", "listPurchaseSuggestions"]);
  const create = useCommand("createReorderRule", ["listReorderRules"]);
  const update = useCommand("updateReorderRule", ["listReorderRules"]);
  const [tab, setTab] = useState(0), [edit, setEdit] = useState(), [offerId, setOffer] = useState(""), [reorder, setReorder] = useState("5"), [target, setTarget] = useState("20"), [safety, setSafety] = useState("3"), [mode, setMode] = useState("draft_for_approval"), [enabled, setEnabled] = useState(true), [budget, setBudget] = useState(""), [delegationId, setDelegationId] = useState(""), [autoAck, setAutoAck] = useState(false);
  const canReadApprovals = useCan("approvals.read");
  const budgetLookupsEnabled = canReadBudgetPolicies && canReadApprovals && edit !== void 0 && mode === "auto_send";
  const budgets = useApi("listBudgetPolicies", {}, budgetLookupsEnabled);
  const budgetApprovals = useApi("listApprovals", { query: { limit: 100 } }, budgetLookupsEnabled);
  const delegations = useApi("listPurchaseDelegations", {}, canReadBudgetPolicies && edit !== void 0 && mode === "auto_send");
  const approvedSupplierIds = new Set(suppliers.data?.data.filter((supplier) => supplier.status === "approved").map((supplier) => supplier.id) || []);
  const eligibleOffers = offers.data?.data.filter((offer) => approvedSupplierIds.has(offer.supplierId) && offerIsCurrent(offer)) || [];
  const selectedOfferFromList = offers.data?.data.find((offer) => offer.id === offerId);
  const selectedOfferDetail = useApi("getSupplierOffer", { path: { resourceId: offerId } }, !!offerId && !selectedOfferFromList);
  const selectedOffer = selectedOfferFromList || selectedOfferDetail.data?.data;
  const selectedSupplierFromList = suppliers.data?.data.find((supplier) => supplier.id === selectedOffer?.supplierId);
  const selectedSupplierDetail = useApi("getSupplier", { path: { resourceId: selectedOffer?.supplierId || "" } }, !!selectedOffer?.supplierId && !selectedSupplierFromList);
  const selectedSupplier = selectedSupplierFromList || selectedSupplierDetail.data?.data;
  const selectedOfferEligible = !!selectedOffer && selectedSupplier?.status === "approved" && offerIsCurrent(selectedOffer);
  const approvedBudgets = budgets.data?.data.filter((item) => item.kind === "procurement" && item.enabled && !!item.limitAmount && !!item.approvalId && !!budgetApprovals.data?.meta.asOf && budgetApprovals.data.data.some((approval) => approval.id === item.approvalId && approval.status === "approved" && approval.resource.type === "budget_policy" && approval.resource.id === item.id && approval.resourceVersion === item.version && Date.parse(approval.expiresAt) > Date.parse(budgetApprovals.data?.meta.asOf || ""))) || [];
  const eligibleDelegations = delegations.data?.data?.filter((grant) => grant.status === "active" && Date.parse(grant.expiresAt) > Date.now() && grant.supplierId === selectedOffer?.supplierId && grant.warehouseId === warehouseId && grant.budgetPolicyId === budget && grant.offerSnapshots.some((snapshot) => snapshot.supplierOfferId === offerId && snapshot.offerVersion === selectedOffer?.version && snapshot.unitCost.amount === selectedOffer?.unitCost.amount && snapshot.unitCost.currency === selectedOffer?.unitCost.currency && snapshot.minimumQuantity === selectedOffer?.minimumQuantity && snapshot.packSize === selectedOffer?.packSize)) || [];
  const budgetVerified = mode !== "auto_send" || budgetLookupsEnabled && !budgets.isPending && !budgets.isError && !budgetApprovals.isPending && !budgetApprovals.isError && approvedBudgets.some((item) => item.id === budget);
  const delegationVerified = mode !== "auto_send" || canReadBudgetPolicies && !delegations.isPending && !delegations.isError && eligibleDelegations.some((item) => item.id === delegationId);
  const ruleFormValid = selectedOfferEligible && warehouses.data?.data.some((warehouse) => warehouse.id === warehouseId) && Number.isInteger(Number(reorder)) && Number(reorder) >= 0 && Number.isInteger(Number(target)) && Number(target) >= Number(reorder) && Number.isInteger(Number(safety)) && Number(safety) >= 0 && (mode !== "auto_send" || budgetVerified && delegationVerified && autoAck);
  const open = (r) => {
    setEdit(r);
    setWarehouseId(r?.warehouseId || shop.defaultWarehouseId);
    setOffer(r?.supplierOfferId || "");
    setReorder(String(r?.reorderPoint ?? 5));
    setTarget(String(r?.targetQuantity ?? 20));
    setSafety(String(r?.safetyStock ?? 3));
    setMode(r?.mode || "draft_for_approval");
    setEnabled(r?.enabled ?? true);
    setBudget(r?.budgetPolicyId || "");
    setDelegationId(r?.purchaseDelegationId || "");
    setAutoAck(false);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhập lại hàng", subtitle: "Trừ hàng đã đặt trước khi đề xuất mua thêm. Tự gửi đơn chỉ khi được bật và đủ hạn mức.", actions: /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.manage", onClick: () => open(null), children: "Thêm quy tắc" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 155
      }, this),
      /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", variant: "contained", busy: evaluate.pending, onClick: () => void evaluate.execute().catch(() => void 0), children: "Đánh giá nhu cầu nhập" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 259
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 152,
      columnNumber: 153
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 152,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: evaluate.error || purchase.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 152,
      columnNumber: 458
    }, this),
    /* @__PURE__ */ jsxDEV(Tabs, { value: tab, onChange: (_, v) => setTab(v), sx: layoutSx.page.sectionAfter, children: [
      /* @__PURE__ */ jsxDEV(Tab, { label: "Đề nghị nhập" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 603
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { label: "Quy tắc theo SKU" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 631
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 152,
      columnNumber: 514
    }, this),
    tab === 0 ? /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(FieldGroup, { bodyMode: "toolbar", children: [
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, children: [
          /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "báo giá", loadedCount: offers.loadedCount, hasMore: offers.hasMore, busy: offers.isLoadingMore, onLoadMore: offers.loadMore }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 773
          }, this),
          /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "nhà cung cấp", loadedCount: suppliers.loadedCount, hasMore: suppliers.hasMore, busy: suppliers.isLoadingMore, onLoadMore: suppliers.loadMore }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 922
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 721
        }, this),
        (offers.hasMore || suppliers.hasMore) && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Đang tải từng phần báo giá/nhà cung cấp. Hãy tải thêm trước khi xác nhận các đề xuất nằm ngoài phần đã tải." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1143
        }, this),
        offers.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải danh sách báo giá…" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1303
        }, this),
        offers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái danh sách báo giá", children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: offers.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 1456
          }, this),
          canRetryLookup(offers.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (offers.isFetchNextPageError ? offers.loadMore() : offers.refetch());
          }, children: "Thử lại danh sách báo giá" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 1525
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1389
        }, this),
        !offers.isPending && !offers.isError && offers.loadedCount === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Chưa có báo giá trong danh sách đã tải." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1757
        }, this),
        suppliers.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải danh sách nhà cung cấp…" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1860
        }, this),
        suppliers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái danh sách nhà cung cấp", children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: suppliers.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 2026
          }, this),
          canRetryLookup(suppliers.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (suppliers.isFetchNextPageError ? suppliers.loadMore() : suppliers.refetch());
          }, children: "Thử lại danh sách nhà cung cấp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 152,
            columnNumber: 2101
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 1954
        }, this),
        !suppliers.isPending && !suppliers.isError && suppliers.loadedCount === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Chưa có nhà cung cấp trong danh sách đã tải." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 2356
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 690
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: suggestions, pendingProfile: "section", children: suggestions.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Đề nghị nhập hàng", rows: suggestions.data.data, rowKey: (r) => r.id, columns: [
          { key: "sku", label: "Biến thể", render: (r) => `Mã biến thể: ${r.variantId}` },
          { key: "supplier", label: "Nhà cung cấp", render: (r) => {
            const offer = offers.data?.data.find((item) => item.id === r.supplierOfferId);
            if (!offer) return offers.isPending ? "Đang tải báo giá…" : offers.isError ? "Không xác minh được báo giá" : offers.hasMore ? "Tải thêm báo giá để xác minh" : "Không tìm thấy báo giá trong danh sách đã tải";
            const supplier = suppliers.data?.data.find((item) => item.id === offer.supplierId);
            if (!supplier) return suppliers.isPending ? "Đang tải nhà cung cấp…" : suppliers.isError ? "Không xác minh được nhà cung cấp" : suppliers.hasMore ? "Tải thêm nhà cung cấp để xác minh" : "Không tìm thấy nhà cung cấp trong danh sách đã tải";
            if (supplier.status !== "approved") return supplier.name + " · chưa được duyệt";
            return supplier.name;
          } },
          { key: "available", label: "Có thể bán", align: "right", render: (r) => r.available },
          { key: "incoming", label: "Đang về", align: "right", render: (r) => r.confirmedInbound },
          { key: "proposed", label: "Đã đề xuất", align: "right", render: (r) => r.openProposalQuantity },
          {
            key: "qty",
            label: "Nên nhập",
            align: "right",
            render: (r) => /* @__PURE__ */ jsxDEV(Typography, { color: "primary.main", fontWeight: visualSx.typography.fontWeight.bold, children: r.suggestedQuantity }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 162,
              columnNumber: 75
            }, this)
          },
          { key: "reason", label: "Căn cứ", render: (r) => /* @__PURE__ */ jsxDEV(Stack, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { children: r.reason }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 164,
              columnNumber: 67
            }, this),
            r.autoSendStatus && r.autoSendStatus !== "not_attempted" && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
              "Tự gửi: ",
              r.autoSendStatus,
              r.autoSendReason ? ` · ${r.autoSendReason}` : ""
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 164,
              columnNumber: 163
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 164,
            columnNumber: 60
          }, this) },
          {
            key: "action",
            label: "",
            render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", disabled: !!r.activePurchaseOrderId || r.suggestedQuantity <= 0 || !eligibleOffers.some((offer) => offer.id === r.supplierOfferId), busy: purchase.pending, onClick: async () => {
              const o = eligibleOffers.find((o2) => o2.id === r.supplierOfferId);
              if (!o)
                return;
              try {
                await purchase.execute({ body: {
                  supplierId: o.supplierId,
                  warehouseId: r.warehouseId,
                  suggestionId: r.id,
                  lines: [{ variantId: r.variantId, supplierOfferId: o.id, quantity: r.suggestedQuantity }]
                } });
                navigate(`/s/${shop.id}/purchases`);
              } catch {
              }
            }, children: "Lập đơn nháp" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 166,
              columnNumber: 54
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 152,
          columnNumber: 2533
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: suggestions.data.page, cursorParam: "suggestionCursor" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 175,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 2531
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 152,
        columnNumber: 2453
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 152,
      columnNumber: 683
    }, this) : /* @__PURE__ */ jsxDEV(Panel, { children: /* @__PURE__ */ jsxDEV(QueryState, { query: rules, pendingProfile: "section", children: rules.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Chính sách bổ sung hàng", rows: rules.data.data, rowKey: (r) => r.id, columns: [
        { key: "sku", label: "Biến thể", render: (r) => `Mã biến thể: ${r.variantId}` },
        { key: "threshold", label: "Ngưỡng / Mục tiêu", render: (r) => `${r.reorderPoint} / ${r.targetQuantity}` },
        { key: "safety", label: "Tồn an toàn", render: (r) => r.safetyStock },
        { key: "mode", label: "Mức tự động", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.mode }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 176,
          columnNumber: 323
        }, this) },
        { key: "enabled", label: "Bật", render: (r) => r.enabled ? "Có" : "Chưa bật" },
        {
          key: "edit",
          label: "",
          render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.manage", onClick: () => open(r), children: "Chỉnh quy tắc" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 178,
            columnNumber: 52
          }, this)
        }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 175,
        columnNumber: 187
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: rules.data.page, cursorParam: "ruleCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 180,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 175,
      columnNumber: 185
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 175,
      columnNumber: 119
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 175,
      columnNumber: 112
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { allowEditsWhileBusy: true, open: edit !== void 0, title: "Quy tắc nhập lại", onClose: () => setEdit(void 0), busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !ruleFormValid || create.pending || update.pending, onClick: async () => {
      const o = selectedOfferEligible ? selectedOffer : void 0;
      if (!o)
        return;
      const body = {
        variantId: o.variantId,
        warehouseId,
        supplierOfferId: offerId,
        reorderPoint: Number(reorder),
        targetQuantity: Number(target),
        safetyStock: Number(safety),
        mode,
        enabled,
        budgetPolicyId: budget || null,
        purchaseDelegationId: mode === "auto_send" ? delegationId : null
      };
      try {
        if (edit)
          await update.execute({ path: { resourceId: edit.id }, body: { ...body, expectedVersion: edit.version } });
        else
          await create.execute({ body });
        setEdit(void 0);
      } catch {
      }
    }, children: "Lưu quy tắc" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 181,
      columnNumber: 169
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 53
      }, this),
      offerId && selectedOfferDetail.isPending && !selectedOffer && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải báo giá đã chọn…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 168
      }, this),
      selectedOfferDetail.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái báo giá đã chọn", children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: selectedOfferDetail.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 330
        }, this),
        canRetryLookup(selectedOfferDetail.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void selectedOfferDetail.refetch();
        }, children: "Thử lại báo giá đã chọn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 425
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 265
      }, this),
      selectedOffer?.supplierId && selectedSupplierDetail.isPending && !selectedSupplier && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải nhà cung cấp đã chọn…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 634
      }, this),
      selectedSupplierDetail.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái nhà cung cấp đã chọn", children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: selectedSupplierDetail.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 809
        }, this),
        canRetryLookup(selectedSupplierDetail.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void selectedSupplierDetail.refetch();
        }, children: "Thử lại nhà cung cấp đã chọn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 910
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 739
      }, this),
      offers.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải danh sách báo giá…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 1061
      }, this),
      offers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái danh sách báo giá trong quy tắc", children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: offers.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 1228
        }, this),
        canRetryLookup(offers.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void (offers.isFetchNextPageError ? offers.loadMore() : offers.refetch());
        }, children: "Thử lại danh sách báo giá" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 1297
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 1147
      }, this),
      suppliers.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải danh sách nhà cung cấp…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 1484
      }, this),
      suppliers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái danh sách nhà cung cấp trong quy tắc", children: [
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: suppliers.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 1664
        }, this),
        canRetryLookup(suppliers.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
          void (suppliers.isFetchNextPageError ? suppliers.loadMore() : suppliers.refetch());
        }, children: "Thử lại danh sách nhà cung cấp" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 1739
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 1578
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kho nhập lại", value: warehouseId, onChange: (event) => setWarehouseId(event.target.value), disabled: create.pending || update.pending, children: [
          warehouseId && !warehouses.data?.data.some((warehouse) => warehouse.id === warehouseId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouseId, children: [
            "Đang giữ kho ",
            warehouseId,
            "; tải danh mục để kiểm tra"
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 2180
          }, this),
          warehouses.data?.data.map((warehouse) => /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouse.id, children: [
            warehouse.code,
            " · ",
            warehouse.name
          ] }, warehouse.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 2316
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 1928
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "kho nhập lại", loadedCount: warehouses.loadedCount, hasMore: warehouses.hasMore, busy: warehouses.isLoadingMore, onLoadMore: warehouses.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 2426
        }, this),
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: warehouses.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 2596
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Báo giá / SKU", select: true, value: offerId, onChange: (e) => setOffer(e.target.value), children: [
          offerId && !offers.data?.data.some((offer) => offer.id === offerId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: offerId, children: selectedOfferDetail.isPending ? "Đang tải báo giá đã chọn…" : selectedOfferDetail.isError ? "Không thể tải báo giá đã chọn" : selectedOffer?.variantId || selectedOffer?.id || "Không tìm thấy báo giá đã chọn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 2807
          }, this),
          eligibleOffers.map((o) => /* @__PURE__ */ jsxDEV(MenuItem, { value: o.id, children: [
            o.variantId,
            " · ",
            o.supplierId,
            " · ",
            o.unitCost.amount,
            " ",
            o.unitCost.currency,
            " · MOQ ",
            o.minimumQuantity,
            " / quy cách ",
            o.packSize
          ] }, o.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 3081
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 2636
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "báo giá", loadedCount: offers.loadedCount, hasMore: offers.hasMore, busy: offers.isLoadingMore, onLoadMore: offers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 3264
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: "row", children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Ngưỡng nhập", type: "number", value: reorder, onChange: (e) => setReorder(e.target.value), inputProps: { min: 0, step: 1 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 3441
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Nhập tới", type: "number", value: target, onChange: (e) => setTarget(e.target.value), inputProps: { min: Math.max(0, Number(reorder) || 0), step: 1 }, error: Number.isFinite(Number(target)) && Number(target) < Number(reorder) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 3582
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tồn an toàn", type: "number", value: safety, onChange: (e) => setSafety(e.target.value), inputProps: { min: 0, step: 1 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 3826
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 3413
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mức tự động", select: true, value: mode, onChange: (e) => {
          setMode(e.target.value);
          setDelegationId("");
        }, children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "notify_only", children: "1 · Chỉ cảnh báo" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4109
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "draft_for_approval", children: "2 · Lập nháp chờ duyệt" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4166
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "auto_send", children: "3 · Tự gửi trong hạn mức" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4236
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 3978
        }, this),
        mode === "auto_send" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Worker MSW local ghi nhận kết quả xác định; không gọi AI, nhà cung cấp hoặc dịch vụ thanh toán." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4338
          }, this),
          !canReadBudgetPolicies && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có quyền xem ngân sách/ủy quyền; không thể lưu chế độ tự gửi." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4494
          }, this),
          canReadBudgetPolicies && budgets.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải chính sách ngân sách mua hàng…" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4657
          }, this),
          canReadBudgetPolicies && budgets.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái chính sách ngân sách mua hàng", children: [
            /* @__PURE__ */ jsxDEV(ErrorNotice, { error: budgets.error }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 191,
              columnNumber: 4860
            }, this),
            canRetryLookup(budgets.error) && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
              void budgets.refetch();
            }, children: "Thử lại chính sách ngân sách" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 191,
              columnNumber: 4931
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 4781
          }, this),
          canReadBudgetPolicies && !budgets.isPending && !budgets.isError && approvedBudgets.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Không có chính sách ngân sách mua hàng đang bật và có hạn mức." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 5146
          }, this),
          canReadBudgetPolicies && approvedBudgets.length > 0 && /* @__PURE__ */ jsxDEV(TextField, { label: "Ngân sách mua hàng đã duyệt", select: true, value: budget, onChange: (e) => {
            setBudget(e.target.value);
            setDelegationId("");
          }, children: approvedBudgets.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: [
            item.id,
            " · ",
            item.limitAmount?.amount,
            " ",
            item.limitAmount?.currency
          ] }, item.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 5471
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 5304
          }, this),
          canReadBudgetPolicies && delegations.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang tải ủy quyền phù hợp…" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 5655
          }, this),
          canReadBudgetPolicies && delegations.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { role: "group", "aria-label": "Trạng thái ủy quyền mua hàng", children: [
            /* @__PURE__ */ jsxDEV(ErrorNotice, { error: delegations.error }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 191,
              columnNumber: 5837
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
              void delegations.refetch();
            }, children: "Thử lại ủy quyền" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 191,
              columnNumber: 5878
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 5770
          }, this),
          canReadBudgetPolicies && !delegations.isPending && !delegations.isError && eligibleDelegations.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Không có ủy quyền đang hiệu lực khớp nhà cung cấp, kho, báo giá snapshot và ngân sách." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 6096
          }, this),
          eligibleDelegations.length > 0 && /* @__PURE__ */ jsxDEV(TextField, { label: "Ủy quyền purchase.send", select: true, value: delegationId, onChange: (e) => setDelegationId(e.target.value), children: eligibleDelegations.map((grant) => /* @__PURE__ */ jsxDEV(MenuItem, { value: grant.id, children: [
            grant.id,
            " · tối đa ",
            grant.maxPerOrder.amount,
            " ",
            grant.maxPerOrder.currency,
            "/đơn · đến ",
            dateTime(grant.expiresAt, shop.timezone)
          ] }, grant.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 6413
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 6257
          }, this),
          /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Tôi đã kiểm giới hạn, snapshot và phạm vi tự gửi", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: autoAck, onChange: (e) => setAutoAck(e.target.checked) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 6693
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 191,
            columnNumber: 6609
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 4336
        }, this),
        /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Bật quy tắc", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: enabled, onChange: (e) => setEnabled(e.target.checked) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 6825
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 191,
          columnNumber: 6778
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 191,
        columnNumber: 1916
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 181,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
    lineNumber: 152,
    columnNumber: 10
  }, this);
}
_s2(ReplenishmentPage, "VGoibprHk3p1qTcmf2caeoEmyas=", false, function() {
  return [useScope, useNavigate, useSearchParams, useApi, useApi, usePagedApi, usePagedApi, usePagedApi, useCan, useCommand, useCommand, useCommand, useCommand, useCan, useApi, useApi, useApi, useApi, useApi];
});
_c2 = ReplenishmentPage;
function canRetryLookup(error) {
  return !(error instanceof ApiError) || error.status !== 403 && error.status !== 404;
}
function quantityMatchesOffer(quantity, offer) {
  const value = Number(quantity);
  return !!offer && Number.isInteger(value) && value >= offer.minimumQuantity && value % offer.packSize === 0;
}
function offerIsCurrent(offer) {
  return !offer.validUntil || Date.parse(offer.validUntil) > Date.now();
}
export function PurchasesPage() {
  _s3();
  const { shop } = useScope();
  const [params] = useSearchParams();
  const list = useApi("listPurchaseOrders", { query: { limit: 20, cursor: params.get("cursor") || void 0 } });
  const suppliers = usePagedApi("listSuppliers");
  const offers = usePagedApi("listSupplierOffers");
  const warehouses = usePagedApi("listWarehouses", { query: { status: "active", limit: 20 } });
  const [warehouseId, setWarehouseId] = useState(shop.defaultWarehouseId);
  const create = useCommand("createPurchaseOrder", ["listPurchaseOrders"]);
  const [open, setOpen] = useState(false), [supplierId, setSupplierId] = useState(""), [poLines, setPoLines] = useState([{ key: 1, supplierOfferId: "", quantity: "1" }]), [nextLineKey, setNextLineKey] = useState(2), [selected, setSelected] = useState(null), [draftCommit, setDraftCommit] = useState();
  const selectedSupplier = suppliers.data?.data.find((supplier) => supplier.id === supplierId);
  const availableOffers = offers.data?.data.filter((offer) => offer.supplierId === supplierId && offer.unitCost.currency === selectedSupplier?.currency && offerIsCurrent(offer)) || [];
  const canCreate = warehouses.data?.data.some((warehouse) => warehouse.id === warehouseId) && !!selectedSupplier && selectedSupplier.status === "approved" && poLines.length > 0 && poLines.every((line) => quantityMatchesOffer(line.quantity, availableOffers.find((offer) => offer.id === line.supplierOfferId))) && new Set(poLines.map((line) => line.supplierOfferId)).size === poLines.length && !create.pending;
  const startPurchase = () => {
    setSupplierId("");
    setWarehouseId(shop.defaultWarehouseId);
    setPoLines([{ key: 1, supplierOfferId: "", quantity: "1" }]);
    setNextLineKey(2);
    setOpen(true);
  };
  const selectSupplier = (nextSupplierId) => {
    setSupplierId(nextSupplierId);
    setPoLines([{ key: 1, supplierOfferId: "", quantity: "1" }]);
    setNextLineKey(2);
  };
  const selectOffer = (key, supplierOfferId) => {
    const offer = availableOffers.find((item) => item.id === supplierOfferId);
    const quantity = offer ? String(Math.ceil(offer.minimumQuantity / offer.packSize) * offer.packSize) : "1";
    setPoLines((lines) => lines.map((line) => line.key === key ? { ...line, supplierOfferId, quantity } : line));
  };
  const submit = async () => {
    if (!canCreate || !selectedSupplier) return;
    const lines = poLines.map((line) => {
      const offer = availableOffers.find((item) => item.id === line.supplierOfferId);
      if (!offer) throw new Error("Báo giá không còn khả dụng. Tải lại danh sách trước khi lập đơn.");
      return { variantId: offer.variantId, supplierOfferId: offer.id, quantity: Number(line.quantity) };
    });
    try {
      const result = await create.execute({ body: { supplierId: selectedSupplier.id, warehouseId, suggestionId: null, lines } });
      setDraftCommit((previous) => ({ scope: null, sequence: (previous?.sequence || 0) + 1 }));
      setOpen(false);
      setSelected(result.data.id);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đơn mua hàng", subtitle: "Duyệt đúng nội dung trước khi gửi. Kết quả gửi chưa rõ phải đối chiếu, không gửi lại mù quáng.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", variant: "contained", onClick: startPurchase, children: "Tạo đơn mua" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 252,
      columnNumber: 160
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 252,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Đơn mua hàng", rows: list.data.data, rowKey: (p) => p.id, columns: [
        { key: "id", label: "Đơn mua", render: (p) => /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: p.id }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 253,
          columnNumber: 57
        }, this) },
        { key: "supplier", label: "Nhà cung cấp", render: (p) => suppliers.data?.data.find((s) => s.id === p.supplierId)?.name || `Mã nhà cung cấp: ${p.supplierId}` },
        { key: "total", label: "Tổng cam kết", render: (p) => /* @__PURE__ */ jsxDEV(Amount, { value: p.total }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 253,
          columnNumber: 357
        }, this) },
        { key: "status", label: "Trạng thái", render: (p) => /* @__PURE__ */ jsxDEV(Status, { value: p.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 253,
          columnNumber: 440
        }, this) },
        { key: "ref", label: "Tham chiếu", render: (p) => p.externalReference || "Chưa gửi" },
        { key: "action", label: "", render: (p) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setSelected(p.id), children: "Xem chi tiết" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 253,
          columnNumber: 601
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 252,
        columnNumber: 356
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 254,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 252,
      columnNumber: 354
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 252,
      columnNumber: 290
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 252,
      columnNumber: 283
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Đơn mua mới", onClose: () => setOpen(false), busy: create.pending, draftCommit, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !canCreate, onClick: () => void submit(), children: "Lưu đơn nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 255,
      columnNumber: 137
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || warehouses.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 256,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kho nhận hàng", value: warehouseId, onChange: (event) => setWarehouseId(event.target.value), disabled: create.pending, children: [
          warehouseId && !warehouses.data?.data.some((warehouse) => warehouse.id === warehouseId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouseId, children: [
            "Đang giữ kho ",
            warehouseId,
            "; tải danh mục để kiểm tra"
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 256,
            columnNumber: 312
          }, this),
          warehouses.data?.data.map((warehouse) => /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouse.id, children: [
            warehouse.code,
            " · ",
            warehouse.name
          ] }, warehouse.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 256,
            columnNumber: 448
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 256,
          columnNumber: 77
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "kho nhận hàng", loadedCount: warehouses.loadedCount, hasMore: warehouses.hasMore, busy: warehouses.isLoadingMore, onLoadMore: warehouses.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 256,
          columnNumber: 558
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Nhà cung cấp đã duyệt", select: true, value: supplierId, onChange: (event) => selectSupplier(event.target.value), children: [
          supplierId && !suppliers.data?.data.some((supplier) => supplier.id === supplierId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: supplierId, children: supplierId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 257,
            columnNumber: 224
          }, this),
          suppliers.data?.data.filter((supplier) => supplier.status === "approved").map((supplier) => /* @__PURE__ */ jsxDEV(MenuItem, { value: supplier.id, children: supplier.name }, supplier.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 257,
            columnNumber: 370
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 257,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "nhà cung cấp", loadedCount: suppliers.loadedCount, hasMore: suppliers.hasMore, busy: suppliers.isLoadingMore, onLoadMore: suppliers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 258,
          columnNumber: 13
        }, this),
        suppliers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: suppliers.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 259,
            columnNumber: 47
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (suppliers.isFetchNextPageError ? suppliers.loadMore() : suppliers.refetch());
          }, children: "Thử lại danh sách nhà cung cấp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 259,
            columnNumber: 86
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 259,
          columnNumber: 35
        }, this),
        !suppliers.data?.data.some((supplier) => supplier.status === "approved") && /* @__PURE__ */ jsxDEV(Alert, { severity: suppliers.hasMore ? "info" : "warning", children: suppliers.hasMore ? "Chưa tải hết nhà cung cấp; tải thêm trước khi kết luận không có nhà cung cấp được duyệt." : "Chưa có nhà cung cấp được duyệt để lập đơn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 260,
          columnNumber: 90
        }, this),
        poLines.map((line, index) => {
          const lineOffer = availableOffers.find((offer) => offer.id === line.supplierOfferId);
          const choices = availableOffers.filter((offer) => !poLines.some((other) => other.key !== line.key && other.supplierOfferId === offer.id));
          return /* @__PURE__ */ jsxDEV(FormFields, { bodyMode: "outlined", children: [
            /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { sm: "center" }, justifyContent: "space-between", children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: [
                "Dòng hàng ",
                index + 1
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 266,
                columnNumber: 25
              }, this),
              poLines.length > 1 && /* @__PURE__ */ jsxDEV(Button, { color: "inherit", onClick: () => setPoLines((lines) => lines.filter((item) => item.key !== line.key)), children: [
                "Xóa dòng ",
                index + 1
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 267,
                columnNumber: 48
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 265,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, children: [
              /* @__PURE__ */ jsxDEV(TextField, { fullWidth: true, label: `Báo giá dòng ${index + 1}`, select: true, value: line.supplierOfferId, onChange: (event) => selectOffer(line.key, event.target.value), children: choices.map((offer) => /* @__PURE__ */ jsxDEV(MenuItem, { value: offer.id, children: [
                offer.variantId,
                " · ",
                offer.unitCost.amount,
                " ",
                offer.unitCost.currency,
                " · MOQ ",
                offer.minimumQuantity,
                " / quy cách ",
                offer.packSize
              ] }, offer.id, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 271,
                columnNumber: 53
              }, this)) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 270,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: `Số lượng dòng ${index + 1}`, type: "number", value: line.quantity, onChange: (event) => setPoLines((lines) => lines.map((item) => item.key === line.key ? { ...item, quantity: event.target.value } : item)), inputProps: { min: lineOffer?.minimumQuantity || 1, step: lineOffer?.packSize || 1 }, error: !!lineOffer && !!line.quantity && !quantityMatchesOffer(line.quantity, lineOffer), helperText: lineOffer ? `Số nguyên, tối thiểu ${lineOffer.minimumQuantity} và bội số ${lineOffer.packSize}.` : "Chọn báo giá cùng nhà cung cấp." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 273,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 269,
              columnNumber: 21
            }, this)
          ] }, line.key, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 264,
            columnNumber: 18
          }, this);
        }),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "báo giá", loadedCount: offers.loadedCount, hasMore: offers.hasMore, busy: offers.isLoadingMore, onLoadMore: offers.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 277,
          columnNumber: 13
        }, this),
        offers.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: offers.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 278,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (offers.isFetchNextPageError ? offers.loadMore() : offers.refetch());
          }, children: "Thử lại danh sách báo giá" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 278,
            columnNumber: 80
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 278,
          columnNumber: 32
        }, this),
        offers.hasMore && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          "Bộ chọn chỉ lọc trong ",
          offers.loadedCount,
          " báo giá đã tải. Tải thêm để tìm offer của nhà cung cấp đã chọn."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 279,
          columnNumber: 32
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { disabled: !supplierId || !availableOffers.some((offer) => !poLines.some((line) => line.supplierOfferId === offer.id)), onClick: () => {
          setPoLines((lines) => [...lines, { key: nextLineKey, supplierOfferId: "", quantity: "1" }]);
          setNextLineKey((key) => key + 1);
        }, children: "Thêm dòng hàng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 280,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giá theo từng báo giá đã chọn; tổng cam kết chính thức do API trả về và được gắn vào nội dung xin duyệt." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 281,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 256,
        columnNumber: 65
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 255,
      columnNumber: 5
    }, this),
    selected && /* @__PURE__ */ jsxDEV(PurchaseDialog, { resourceId: selected, onClose: () => setSelected(null) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 283,
      columnNumber: 31
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
    lineNumber: 252,
    columnNumber: 10
  }, this);
}
_s3(PurchasesPage, "pGm53qhWM6yGA5du8LKGsVhjCE0=", false, function() {
  return [useScope, useSearchParams, useApi, usePagedApi, usePagedApi, usePagedApi, useCommand];
});
_c3 = PurchasesPage;
function PurchaseDialog({
  resourceId,
  onClose
}) {
  _s4();
  const { shop } = useScope();
  const get = useApi("getPurchaseOrder", { path: { resourceId } });
  const p = get.data?.data;
  const approval = useCommand("requestPurchaseApproval", ["getPurchaseOrder", "listPurchaseOrders", "listApprovals"]);
  const send = useCommand("sendPurchaseOrder", ["getPurchaseOrder", "listPurchaseOrders", "listApprovals"]);
  const confirm = useCommand("confirmPurchaseOrder", ["getPurchaseOrder", "listPurchaseOrders"]);
  const cancel = useCommand("cancelPurchaseOrder", ["getPurchaseOrder", "listPurchaseOrders", "listPurchaseSuggestions"]);
  const [action, setAction] = useState(null), [external, setExternal] = useState(""), [proof, setProof] = useState(""), [draftCommit, setDraftCommit] = useState();
  const unresolvedSend = useSyncExternalStore(subscribeIntents, intentSnapshot, intentSnapshot).some((intent) => intent.shopId === shop.id && intent.operation === "sendPurchaseOrder");
  const sendPurchase = async () => {
    try {
      return await send.execute({ path: { resourceId }, body: { expectedVersion: p?.version || 1, approvalId: p?.approvalId || "", intentHash: p?.intentHash || "" } });
    } catch (error) {
      if (error instanceof UnknownResultError) setAction(null);
      throw error;
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: `Đơn mua ${resourceId}`, onClose, actions: /* @__PURE__ */ jsxDEV(Button, { onClick: onClose, children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 307,
      columnNumber: 88
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: approval.error || send.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 307,
        columnNumber: 129
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: get, children: p && /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Status, { value: p.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 307,
          columnNumber: 223
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nhà cung cấp", children: [
          "Mã nhà cung cấp: ",
          p.supplierId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 307,
          columnNumber: 250
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Tổng cam kết", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: p.total }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 307,
          columnNumber: 360
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 307,
          columnNumber: 327
        }, this),
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Sản phẩm trong đơn mua", rows: p.lines, rowKey: (l) => l.id, columns: [
          { key: "sku", label: "Biến thể", render: (l) => l.variantId },
          { key: "qty", label: "Đặt", render: (l) => l.quantity },
          { key: "received", label: "Đã nhận", render: (l) => l.receivedQuantity },
          { key: "cost", label: "Đơn giá", render: (l) => /* @__PURE__ */ jsxDEV(Amount, { value: l.unitCost }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 308,
            columnNumber: 253
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 307,
          columnNumber: 404
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { overflowWrap: "anywhere" }, children: [
          "Hash nội dung: ",
          p.intentHash
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 309,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: "row", flexWrap: "wrap", children: [
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", allowedActions: p.allowedActions, action: "request_approval", busy: approval.pending, onClick: () => void approval.execute({ path: { resourceId }, body: { expectedVersion: p.version } }).catch(() => void 0), children: "Xin phê duyệt" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 309,
            columnNumber: 165
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.send", allowedActions: p.allowedActions, action: "send", variant: "contained", disabled: unresolvedSend, onClick: () => setAction("send"), children: "Gửi đơn mua" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 309,
            columnNumber: 451
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", allowedActions: p.allowedActions, action: "confirm", onClick: () => setAction("confirm"), children: "Nhà cung cấp đã xác nhận" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 309,
            columnNumber: 653
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", allowedActions: p.allowedActions, action: "cancel", color: "error", onClick: () => setAction("cancel"), children: "Hủy đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 309,
            columnNumber: 829
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 309,
          columnNumber: 121
        }, this),
        p.approvalId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/approvals`, children: [
          "Xem phê duyệt ",
          p.approvalId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 309,
          columnNumber: 1030
        }, this),
        ["confirmed", "part_received"].includes(p.status) && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/receipts?purchaseOrderId=${p.id}`, children: "Nhận hàng theo đơn này" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 309,
          columnNumber: 1167
        }, this),
        (p.status === "unknown" || unresolvedSend) && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Chưa xác minh kết quả gửi. Không gửi lại; hãy kiểm tra trạng thái lệnh trước khi tiếp tục." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 309,
          columnNumber: 1314
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 307,
        columnNumber: 211
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 307,
        columnNumber: 181
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 307,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: action === "send" && !unresolvedSend, title: "Gửi đơn mua đã duyệt", confirmLabel: "Gửi đơn mua", description: `Đơn mua ${p?.id || resourceId} · ${p?.total.amount || ""} ${p?.total.currency || ""}: gửi đúng nội dung đã được duyệt cho nhà cung cấp ${p?.supplierId || ""}. Không chuyển tiền; kết quả chưa rõ phải được kiểm tra trước khi gửi lại.`, onClose: () => setAction(null), error: send.error, busy: send.pending, onConfirm: sendPurchase }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 310,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: action === "cancel", title: "Hủy đơn mua", confirmLabel: "Hủy đơn mua", description: `Đơn mua ${p?.id || resourceId}: hủy tác vụ chưa được tiếp nhận khi đủ điều kiện. Không coi việc hủy UI là thu hồi tác động nhà cung cấp đã nhận.`, requireReason: true, onClose: () => setAction(null), error: cancel.error, busy: cancel.pending, onConfirm: (reason) => cancel.execute({ path: { resourceId }, body: { expectedVersion: p?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 310,
      columnNumber: 463
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: action === "confirm", title: "Ghi nhận xác nhận của nhà cung cấp", onClose: () => setAction(null), busy: confirm.pending, draftCommit, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !external || !proof || confirm.pending, onClick: async () => {
      try {
        await confirm.execute({ path: { resourceId }, body: { expectedVersion: p?.version || 1, externalReference: external, supplierConfirmationRef: proof } });
        setDraftCommit((previous) => ({ scope: null, sequence: (previous?.sequence || 0) + 1 }));
        setAction(null);
      } catch {
      }
    }, children: "Ghi xác nhận" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 311,
      columnNumber: 175
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: confirm.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 316,
        columnNumber: 54
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tham chiếu đơn phía nhà cung cấp", value: external, onChange: (e) => setExternal(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 316,
          columnNumber: 103
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã bằng chứng xác nhận", value: proof, onChange: (e) => setProof(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 316,
          columnNumber: 220
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 316,
        columnNumber: 91
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 311,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
    lineNumber: 307,
    columnNumber: 10
  }, this);
}
_s4(PurchaseDialog, "xZbqRtujhVgSEU4sdo+SYok0hes=", false, function() {
  return [useScope, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c4 = PurchaseDialog;
export function ReceiptsPage() {
  _s5();
  const [searchParams] = useSearchParams();
  const list = useApi("listGoodsReceipts", { query: useListQuery("listGoodsReceipts") });
  const orders = usePagedApi("listPurchaseOrders");
  const [open, setOpen] = useState(false), [orderId, setOrderId] = useState(() => searchParams.get("purchaseOrderId") || ""), [document, setDocument] = useState(""), [quantities, setQuantities] = useState({}), [selectedId, setSelectedId] = useState(null), [confirmPost, setConfirmPost] = useState(false);
  const purchaseOrder = useApi("getPurchaseOrder", { path: { resourceId: orderId } }, !!orderId);
  const order = purchaseOrder.data?.data;
  const receiptDetail = useApi("getGoodsReceipt", { path: { resourceId: selectedId || "" } }, !!selectedId);
  const receipt = receiptDetail.data?.data;
  const create = useCommand("createGoodsReceipt", ["listGoodsReceipts"]);
  const post = useCommand("postGoodsReceipt", ["getGoodsReceipt", "getPurchaseOrder", "listGoodsReceipts", "listPurchaseOrders", "listStockSnapshots", "listDebtItems", "listJournals"]);
  const receiptLines = order?.lines.flatMap((line) => {
    const input = quantities[line.id] || { accepted: "0", rejected: "0", reason: "" };
    const accepted = Number(input.accepted || 0), rejected = Number(input.rejected || 0);
    return accepted + rejected > 0 ? [{ purchaseLineId: line.id, acceptedQuantity: accepted, rejectedQuantity: rejected, reason: input.reason.trim() }] : [];
  }) || [];
  const receiptLinesValid = !!order && receiptLines.length > 0 && receiptLines.every((input) => {
    const original = order.lines.find((line) => line.id === input.purchaseLineId);
    const remaining = original ? original.quantity - original.receivedQuantity - original.rejectedQuantity : 0;
    return Number.isInteger(input.acceptedQuantity) && input.acceptedQuantity >= 0 && Number.isInteger(input.rejectedQuantity) && input.rejectedQuantity >= 0 && input.acceptedQuantity + input.rejectedQuantity <= remaining && (input.rejectedQuantity === 0 || !!input.reason) && codePointLength(input.reason) <= 1e3;
  });
  const createValid = !!order && ["confirmed", "part_received"].includes(order.status) && document.trim().length > 0 && codePointLength(document.trim()) <= 160 && receiptLinesValid && !create.pending;
  const createReceipt = async () => {
    if (!createValid || !order) return;
    try {
      await create.execute({ body: { purchaseOrderId: order.id, expectedPurchaseVersion: order.version, sourceDocumentRef: document.trim(), lines: receiptLines } });
      setOpen(false);
      setOrderId("");
      setDocument("");
      setQuantities({});
    } catch {
    }
  };
  const postReceipt = async () => {
    if (!receipt || receipt.status !== "draft") return;
    try {
      await post.execute({ path: { resourceId: receipt.id }, body: { expectedVersion: receipt.version } });
      setConfirmPost(false);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhận hàng", subtitle: "Nhận từng phần, ghi hàng đạt/hỏng; chỉ hàng đạt làm tăng tồn và công nợ mô phỏng.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.write", variant: "contained", onClick: () => {
      setOrderId(searchParams.get("purchaseOrderId") || "");
      setDocument("");
      setQuantities({});
      setOpen(true);
    }, children: "Tạo phiếu nhận" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 359,
      columnNumber: 144
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 359,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listGoodsReceipts" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 359,
        columnNumber: 374
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Phiếu nhận hàng", rows: list.data.data, rowKey: (r) => r.id, columns: [
          { key: "id", label: "Phiếu nhận", render: (r) => r.id },
          { key: "po", label: "Đơn mua", render: (r) => r.purchaseOrderId },
          { key: "source", label: "Chứng từ nguồn", render: (r) => r.sourceDocumentRef },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 360,
            columnNumber: 267
          }, this) },
          {
            key: "action",
            label: "",
            render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.receive", disabled: r.status !== "draft", onClick: () => {
              setConfirmPost(false);
              setSelectedId(r.id);
            }, children: "Xem / ghi nhận phiếu" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 362,
              columnNumber: 54
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 359,
          columnNumber: 481
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 364,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 359,
        columnNumber: 479
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 359,
        columnNumber: 415
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 359,
      columnNumber: 367
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: "Phiếu nhận hàng mới", onClose: () => setOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !createValid, onClick: () => void createReceipt(), children: "Tạo phiếu nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 365,
      columnNumber: 119
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 366,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Đơn mua đã xác nhận", select: true, value: orderId, onChange: (event) => {
          setOrderId(event.target.value);
          setQuantities({});
        }, disabled: orders.isPending && !orders.data, children: [
          orderId && !orders.data?.data.some((item) => item.id === orderId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: orderId, children: order?.id || (purchaseOrder.isPending ? "Đang tải đơn đã chọn…" : orderId) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 368,
            columnNumber: 87
          }, this),
          orders.data?.data.filter((item) => ["confirmed", "part_received"].includes(item.status)).map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.id }, item.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 369,
            columnNumber: 121
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 367,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "đơn mua", loadedCount: orders.loadedCount, hasMore: orders.hasMore, busy: orders.isLoadingMore, onLoadMore: orders.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 371,
          columnNumber: 13
        }, this),
        orders.isError && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: orders.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 372,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
            void (orders.isFetchNextPageError ? orders.loadMore() : orders.refetch());
          }, children: "Thử lại danh sách đơn mua" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 372,
            columnNumber: 80
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 372,
          columnNumber: 32
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã phiếu giao / chứng từ nguồn", value: document, onChange: (event) => setDocument(limitCodePoints(event.target.value, 160)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 373,
          columnNumber: 13
        }, this),
        orderId && /* @__PURE__ */ jsxDEV(QueryState, { query: purchaseOrder, children: order && /* @__PURE__ */ jsxDEV(FormFields, { children: order.lines.map((line) => {
          const input = quantities[line.id] || { accepted: "0", rejected: "0", reason: "" };
          const remaining = line.quantity - line.receivedQuantity - line.rejectedQuantity;
          const invalid = !!input.accepted && !Number.isInteger(Number(input.accepted)) || !!input.rejected && !Number.isInteger(Number(input.rejected)) || Number(input.accepted || 0) + Number(input.rejected || 0) > remaining || Number(input.rejected || 0) > 0 && !input.reason.trim();
          return /* @__PURE__ */ jsxDEV(FormFields, { bodyMode: "outlined", children: [
            /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: [
              "Mã biến thể: ",
              line.variantId
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 380,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
              "Đặt ",
              line.quantity,
              " · đã nhận ",
              line.receivedQuantity,
              " · bị từ chối ",
              line.rejectedQuantity,
              " · còn ",
              remaining
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 381,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, children: [
              /* @__PURE__ */ jsxDEV(TextField, { label: `Nhận đạt mã biến thể ${line.variantId}`, type: "number", value: input.accepted, onChange: (event) => setQuantities((previous) => ({ ...previous, [line.id]: { ...input, accepted: event.target.value } })), inputProps: { min: 0, max: remaining, step: 1 }, error: invalid }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 383,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: `Từ chối / hỏng mã biến thể ${line.variantId}`, type: "number", value: input.rejected, onChange: (event) => setQuantities((previous) => ({ ...previous, [line.id]: { ...input, rejected: event.target.value } })), inputProps: { min: 0, max: remaining, step: 1 }, error: invalid }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
                lineNumber: 384,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 382,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: `Ghi chú kiểm hàng mã biến thể ${line.variantId}`, fullWidth: true, value: input.reason, onChange: (event) => setQuantities((previous) => ({ ...previous, [line.id]: { ...input, reason: limitCodePoints(event.target.value, 1e3) } })), error: invalid && Number(input.rejected || 0) > 0, helperText: Number(input.rejected || 0) > 0 && !input.reason.trim() ? "Cần ghi rõ lý do hàng bị từ chối." : void 0 }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
              lineNumber: 386,
              columnNumber: 25
            }, this)
          ] }, line.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
            lineNumber: 379,
            columnNumber: 22
          }, this);
        }) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 374,
          columnNumber: 69
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 374,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 366,
        columnNumber: 45
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 365,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!selectedId, title: `Phiếu nhận ${selectedId || ""}`, onClose: () => {
      setConfirmPost(false);
      setSelectedId(null);
    }, busy: post.pending, actions: /* @__PURE__ */ jsxDEV(FieldGroup, { direction: "row", children: [
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => {
        setConfirmPost(false);
        setSelectedId(null);
      }, children: "Đóng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 393,
        columnNumber: 9
      }, this),
      receipt?.status === "draft" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.receive", variant: "contained", busy: post.pending, disabled: receiptDetail.isLoading, onClick: () => setConfirmPost(true), children: "Kiểm & ghi nhận vào kho" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 394,
        columnNumber: 41
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 392,
      columnNumber: 168
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: receiptDetail.error || post.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 396,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: receiptDetail, children: receipt && /* @__PURE__ */ jsxDEV(FieldGroup, { children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đơn mua", children: receipt.purchaseOrderId }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 397,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chứng từ nguồn", children: receipt.sourceDocumentRef }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 398,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: receipt.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 399,
          columnNumber: 44
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 399,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Các dòng kiểm nhận", rows: receipt.lines, rowKey: (line) => line.purchaseLineId, columns: [
          { key: "line", label: "Dòng đơn mua", render: (line) => line.purchaseLineId },
          { key: "accepted", label: "Nhận đạt", align: "right", render: (line) => line.acceptedQuantity },
          { key: "rejected", label: "Từ chối", align: "right", render: (line) => line.rejectedQuantity },
          { key: "reason", label: "Lý do", render: (line) => line.reason || "—" }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 400,
          columnNumber: 13
        }, this),
        receipt.status === "posted" && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", children: "Phiếu đã được ghi nhận. Ghi sổ kho/công nợ không thể gửi lại từ trạng thái này." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
          lineNumber: 406,
          columnNumber: 45
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 396,
        columnNumber: 112
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
        lineNumber: 396,
        columnNumber: 66
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 392,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: confirmPost && !!selectedId && receipt?.status === "draft", title: "Ghi nhận hàng đã kiểm vào kho", confirmLabel: "Ghi nhận vào kho", description: `Phiếu ${receipt?.id || ""}: ${receipt?.lines.map((line) => `${line.acceptedQuantity} nhận đạt, ${line.rejectedQuantity} từ chối`).join("; ") || ""}. Chỉ lượng đạt tăng tồn và công nợ mô phỏng; API kiểm lại version và chống ghi trùng.`, onClose: () => setConfirmPost(false), busy: post.pending, error: post.error, onConfirm: postReceipt }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
      lineNumber: 409,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx",
    lineNumber: 359,
    columnNumber: 10
  }, this);
}
_s5(ReceiptsPage, "iJ5/YLMzQE2QkmXehWVrkRyiJMk=", false, function() {
  return [useSearchParams, useApi, useListQuery, usePagedApi, useApi, useApi, useCommand, useCommand];
});
_c5 = ReceiptsPage;
function supplierSnapshot(supplier) {
  return { version: supplier.version, values: { name: supplier.name, contact: supplier.contactLabel, lead: String(supplier.leadTimeDays), terms: supplier.paymentTerms, method: supplier.sendMethod, adapter: supplier.approvedAdapterId || "" } };
}
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "SuppliersPage");
$RefreshReg$(_c2, "ReplenishmentPage");
$RefreshReg$(_c3, "PurchasesPage");
$RefreshReg$(_c4, "PurchaseDialog");
$RefreshReg$(_c5, "ReceiptsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/procurement/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEMwSixTQUEwTSxVQUExTTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQzFKLFNBQVNBLHlCQUF5QjtBQUNsQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsWUFBWUMsa0JBQWtCO0FBQ3ZDLFNBQVNDLFVBQVVDLDRCQUE0QjtBQUMvQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsdUJBQXVCO0FBQzdDLFNBQVNDLE9BQU9DLFFBQVFDLFVBQVVDLGtCQUFrQkMsVUFBVUMsT0FBT0MsS0FBS0MsTUFBTUMsV0FBV0Msa0JBQWtCO0FBRTdHLFNBQVNDLFFBQVFDLGFBQWFDLGtCQUFrQjtBQUNoRCxTQUFTQyxVQUFVQywwQkFBMEI7QUFDN0MsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxpQkFBaUJDLGdCQUFnQjtBQUMzRCxTQUFTQyxnQkFBZ0JDLHdCQUF3QjtBQUNqRCxTQUFTQyxZQUFZQyxPQUFPQyxXQUFXQyxZQUFZQyxTQUFTQyxPQUFPQyxRQUFRQyxRQUFRQyxnQkFBZ0JDLFlBQVlDLGFBQWFDLGVBQWVDLFdBQVdDLFlBQVlDLHNCQUFzQjtBQUN4TCxTQUFTQyxnQkFBZ0I7QUFDbEIsZ0JBQVNDLGdCQUFnQjtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sRUFBRUMsS0FBSyxJQUFJMUIsU0FBUztBQUMxQixRQUFNLENBQUMyQixNQUFNLElBQUkzQyxnQkFBZ0I7QUFDakMsUUFBTTRDLE9BQU9qQyxPQUFPLGlCQUFpQixFQUFFa0MsT0FBTyxFQUFFQyxPQUFPLElBQUlDLFFBQVFKLE9BQU9LLElBQUksZ0JBQWdCLEtBQUtDLE9BQVUsRUFBRSxDQUFDO0FBQ2hILFFBQU1DLFNBQVN2QyxPQUFPLHNCQUFzQixFQUFFa0MsT0FBTyxFQUFFQyxPQUFPLElBQUlDLFFBQVFKLE9BQU9LLElBQUksYUFBYSxLQUFLQyxPQUFVLEVBQUUsQ0FBQztBQUNwSCxRQUFNRSxXQUFXdkMsWUFBWSxjQUFjO0FBQzNDLFFBQU13QyxTQUFTdkMsV0FBVyxrQkFBa0IsQ0FBQyxlQUFlLENBQUM7QUFDN0QsUUFBTXdDLFNBQVN4QyxXQUFXLGtCQUFrQixDQUFDLGVBQWUsQ0FBQztBQUM3RCxRQUFNeUMsU0FBU3pDLFdBQVcscUJBQXFCLENBQUMsZUFBZSxDQUFDO0FBQ2hFLFFBQU0wQyxXQUFXMUMsV0FBVyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQztBQUN6RSxRQUFNLENBQUMyQyxNQUFNQyxPQUFPLElBQUk3RCxTQUFzQyxHQUFHLENBQUM4RCxNQUFNQyxPQUFPLElBQUkvRCxTQUFTLEVBQUUsR0FBRyxDQUFDZ0UsU0FBU0MsVUFBVSxJQUFJakUsU0FBUyxFQUFFLEdBQUcsQ0FBQ2tFLE1BQU1DLE9BQU8sSUFBSW5FLFNBQVMsR0FBRyxHQUFHLENBQUNvRSxPQUFPQyxRQUFRLElBQUlyRSxTQUFTLEVBQUUsR0FBRyxDQUFDc0UsUUFBUUMsU0FBUyxJQUFJdkUsU0FBd0MsUUFBUSxHQUFHLENBQUN3RSxTQUFTQyxVQUFVLElBQUl6RSxTQUFTLEVBQUU7QUFDdFQsUUFBTSxDQUFDMEUsWUFBWUMsYUFBYSxJQUFJM0UsU0FBMEIsSUFBSSxHQUFHLENBQUM0RSxhQUFhQyxjQUFjLElBQUk3RSxTQUFnRCxVQUFVLEdBQUcsQ0FBQzhFLFFBQVFDLFNBQVMsSUFBSS9FLFNBQVMsRUFBRTtBQUNuTSxRQUFNLENBQUNnRixlQUFlQyxnQkFBZ0IsSUFBSWpGLFNBQTBCLElBQUksR0FBRyxDQUFDa0YsU0FBU0MsVUFBVSxJQUFJbkYsU0FBUyxFQUFFLEdBQUcsQ0FBQ29GLE1BQU1DLE9BQU8sSUFBSXJGLFNBQVMsRUFBRSxHQUFHLENBQUNzRixTQUFTQyxVQUFVLElBQUl2RixTQUFTLEdBQUcsR0FBRyxDQUFDd0YsTUFBTUMsT0FBTyxJQUFJekYsU0FBUyxHQUFHO0FBQ3ROLFFBQU0wRixtQkFBbUI5QixNQUFNK0IsTUFBTWpCLFlBQVlpQixNQUFNO0FBQ3ZELFFBQU1DLGlCQUFpQjdFLE9BQU8sZUFBZSxFQUFFOEUsTUFBTSxFQUFFQyxZQUFZSixpQkFBaUIsRUFBRSxHQUFHLENBQUMsQ0FBQ0EsZ0JBQWdCO0FBQzNHLFFBQU1LLGlCQUFpQm5DLE1BQU0rQixNQUFNQyxlQUFlSSxNQUFNQSxLQUFLTCxPQUFPL0IsS0FBSytCLEtBQUtDLGVBQWVJLEtBQUtBLE9BQU9wQztBQUN6RyxRQUFNcUMsaUJBQWlCckcsa0JBQWtCO0FBQUEsSUFDckNzRyxVQUFVLEdBQUdwRCxLQUFLNkMsRUFBRSxhQUFhL0IsTUFBTStCLE1BQU0sS0FBSztBQUFBLElBQ2xEUSxRQUFRSixpQkFBaUJLLGlCQUFpQkwsY0FBYyxJQUFJMUM7QUFBQUEsSUFDNURnRCxPQUFPLEVBQUV2QyxNQUFNRSxTQUFTRSxNQUFNRSxPQUFPRSxRQUFRRSxRQUFRO0FBQUEsSUFDckQ4QixPQUFPQSxDQUFBQyxXQUFVO0FBQUV4QyxjQUFRd0MsT0FBT3pDLElBQUk7QUFBR0csaUJBQVdzQyxPQUFPdkMsT0FBTztBQUFHRyxjQUFRb0MsT0FBT3JDLElBQUk7QUFBR0csZUFBU2tDLE9BQU9uQyxLQUFLO0FBQUdHLGdCQUFVZ0MsT0FBT2pDLE1BQU07QUFBR0csaUJBQVc4QixPQUFPL0IsT0FBTztBQUFBLElBQUc7QUFBQSxJQUN6S2dDLFNBQVNBLE1BQU1aLGVBQWVhLFFBQVEsRUFBRUMsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUNoRSxDQUFDO0FBQ0QsUUFBTUMsb0JBQW9CLENBQUMsQ0FBQzdDLEtBQUs4QyxLQUFLLEtBQUtwRixnQkFBZ0JzQyxLQUFLOEMsS0FBSyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUM1QyxRQUFRNEMsS0FBSyxLQUFLcEYsZ0JBQWdCd0MsUUFBUTRDLEtBQUssQ0FBQyxLQUFLLE9BQU9DLE9BQU9DLFVBQVVELE9BQU8zQyxJQUFJLENBQUMsS0FBSzJDLE9BQU8zQyxJQUFJLEtBQUssS0FBSzFDLGdCQUFnQjRDLEtBQUssS0FBSyxRQUFRRSxXQUFXLFlBQVksQ0FBQyxDQUFDRSxRQUFRb0MsS0FBSztBQUMvUSxRQUFNRyxpQkFBaUIsQ0FBQyxDQUFDN0IsV0FBVyw2QkFBNkI4QixLQUFLNUIsSUFBSSxLQUFLeUIsT0FBT0MsVUFBVUQsT0FBT3ZCLE9BQU8sQ0FBQyxLQUFLdUIsT0FBT3ZCLE9BQU8sS0FBSyxLQUFLdUIsT0FBT0MsVUFBVUQsT0FBT3JCLElBQUksQ0FBQyxLQUFLcUIsT0FBT3JCLElBQUksS0FBSyxLQUFLcUIsT0FBT0MsVUFBVUQsT0FBTzNDLElBQUksQ0FBQyxLQUFLMkMsT0FBTzNDLElBQUksS0FBSztBQUNyUCxRQUFNK0MsT0FBT0EsQ0FBQ0MsTUFBdUI7QUFBRXJELFlBQVFxRCxDQUFDO0FBQUduRCxZQUFRbUQsR0FBR3BELFFBQVEsRUFBRTtBQUFHRyxlQUFXaUQsR0FBR0MsZ0JBQWdCLEVBQUU7QUFBR2hELFlBQVFpRCxPQUFPRixHQUFHRyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQUdoRCxhQUFTNkMsR0FBR0ksZ0JBQWdCLEVBQUU7QUFBRy9DLGNBQVUyQyxHQUFHSyxjQUFjLFFBQVE7QUFBRzlDLGVBQVd5QyxHQUFHTSxxQkFBcUIsRUFBRTtBQUFBLEVBQUc7QUFDcFEsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSx5QkFBd0IsVUFBUyxrRkFBaUYsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLHFCQUFvQixTQUFRLGFBQVksU0FBUyxNQUFNUCxLQUFLLElBQUksR0FBRyxpQ0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRyxLQUE1UDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThRO0FBQUEsSUFBRSx1QkFBQyxTQUFNLGlDQUFDLGNBQVcsT0FBT2pFLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2dELFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE9BQU0sZ0JBQWUsTUFBTWhELEtBQUtnRCxLQUFLQSxNQUFNLFFBQVEsQ0FBQWtCLE1BQUtBLEVBQUV2QixJQUFJLFNBQVM7QUFBQSxRQUNoYjtBQUFBLFVBQ0k4QixLQUFLO0FBQUEsVUFBUUMsT0FBTztBQUFBLFVBQWdCQyxRQUFRQSxDQUFBVCxNQUFLLHVCQUFDLFNBQU07QUFBQSxtQ0FBQyxjQUFXLFlBQVloSCxTQUFTMEgsV0FBV0MsV0FBV0MsUUFBU1osWUFBRXBELFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFBYSx1QkFBQyxjQUFXLFNBQVEsV0FBV29ELFlBQUVDLGdCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLGVBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNKO0FBQUEsUUFDM007QUFBQSxRQUNBLEVBQUVNLEtBQUssUUFBUUMsT0FBTyxrQkFBa0JDLFFBQVFBLENBQUFULE1BQUssR0FBR0EsRUFBRUcsWUFBWSxRQUFRO0FBQUEsUUFBRyxFQUFFSSxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQVQsTUFBS0EsRUFBRUksYUFBYTtBQUFBLFFBQUcsRUFBRUcsS0FBSyxTQUFTQyxPQUFPLGNBQWNDLFFBQVFBLENBQUFULE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFeEQsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QixFQUFHO0FBQUEsUUFDbE87QUFBQSxVQUNJK0QsS0FBSztBQUFBLFVBQVdDLE9BQU87QUFBQSxVQUFJQyxRQUFRQSxDQUFBVCxNQUFLLHVCQUFDLFNBQU0sV0FBVSxPQUFNLFVBQVMsUUFBTztBQUFBLG1DQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVMsTUFBTUQsS0FBS0MsQ0FBQyxHQUFHLG1CQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQWlCLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVMsTUFBTTtBQUFFakMsK0JBQWlCaUMsQ0FBQztBQUFHL0IseUJBQVcsRUFBRTtBQUFHRSxzQkFBUSxFQUFFO0FBQUdFLHlCQUFXLEdBQUc7QUFBR0Usc0JBQVEsR0FBRztBQUFHdEIsc0JBQVFpRCxPQUFPRixFQUFFRyxZQUFZLENBQUM7QUFBQSxZQUFHLEdBQUcsNEJBQXJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlNO0FBQUEsWUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxzQkFBcUIsU0FBUyxNQUFNO0FBQUUxQyw0QkFBY3VDLENBQUM7QUFBR25DLHdCQUFVLEVBQUU7QUFBR0YsNkJBQWVxQyxFQUFFeEQsV0FBVyxhQUFhLGNBQWMsVUFBVTtBQUFBLFlBQUcsR0FBRyxnQ0FBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUw7QUFBQSxlQUE3Z0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOGhCO0FBQUEsUUFDMWtCO0FBQUEsTUFBQyxLQVA2VjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUWhXO0FBQUEsTUFBRSx1QkFBQyxTQUFNLE1BQU1WLEtBQUtnRCxLQUFLK0IsTUFBTSxhQUFZLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsU0FSbVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFqUyxLQVJpTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUTdOLEtBUnNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRek07QUFBQSxJQUNuRix1QkFBQyxTQUFNLE9BQU0sb0JBQW1CLFVBQVMsc0VBQXFFLFdBQVcsV0FBVyxpQ0FBQyxjQUFXLE9BQU96RSxRQUFRLGdCQUFlLFdBQVdBLGlCQUFPMEMsUUFBUSxtQ0FBRTtBQUFBLDZCQUFDLGFBQVUsT0FBTSxvQkFBbUIsTUFBTTFDLE9BQU8wQyxLQUFLQSxNQUFNLFFBQVEsQ0FBQWdDLE1BQUtBLEVBQUVyQyxJQUFJLFNBQVM7QUFBQSxRQUMzUixFQUFFOEIsS0FBSyxZQUFZQyxPQUFPLGdCQUFnQkMsUUFBUUEsQ0FBQUssTUFBS2hGLEtBQUtnRCxNQUFNQSxLQUFLaUMsS0FBSyxDQUFBZixNQUFLQSxFQUFFdkIsT0FBT3FDLEVBQUVFLFVBQVUsR0FBR3BFLFFBQVEsb0JBQW9Ca0UsRUFBRUUsVUFBVSxHQUFHO0FBQUEsUUFDcEo7QUFBQSxVQUNJVCxLQUFLO0FBQUEsVUFBT0MsT0FBTztBQUFBLFVBQVlDLFFBQVFBLENBQUFLLE1BQUt6RSxTQUFTeUMsTUFBTUEsS0FBS21DLFFBQVEsQ0FBQUMsTUFBS0EsRUFBRUMsUUFBUSxFQUFFSixLQUFLLENBQUFLLE1BQUtBLEVBQUUzQyxPQUFPcUMsRUFBRU8sU0FBUyxHQUFHQyxPQUFPLGdCQUFnQlIsRUFBRU8sU0FBUztBQUFBLFFBQ2hLO0FBQUEsUUFDQSxFQUFFZCxLQUFLLFFBQVFDLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQUssTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVTLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEIsRUFBRztBQUFBLFFBQUcsRUFBRWhCLEtBQUssT0FBT0MsT0FBTyx3QkFBd0JDLFFBQVFBLENBQUFLLE1BQUssR0FBR0EsRUFBRVUsZUFBZSxNQUFNVixFQUFFVyxRQUFRLEdBQUc7QUFBQSxRQUFHLEVBQUVsQixLQUFLLFFBQVFDLE9BQU8sZ0JBQWdCQyxRQUFRQSxDQUFBSyxNQUFLQSxFQUFFWSxhQUFhbkgsU0FBU3VHLEVBQUVZLFlBQVk5RixLQUFLK0YsUUFBUSxJQUFJLGdCQUFnQjtBQUFBLE1BQUMsS0FMMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1yTTtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNdkYsT0FBTzBDLEtBQUsrQixNQUFNLGFBQVksaUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxTQU55STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTXZJLEtBTm1FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNL0QsS0FOckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1rRjtBQUFBLElBQ2xGLHVCQUFDLGNBQVcscUJBQW1CLE1BQUMsTUFBTW5FLFNBQVNQLFFBQVcsT0FBT08sT0FBTywwQkFBMEIsb0JBQW9CLFNBQVMsTUFBTUMsUUFBUVIsTUFBUyxHQUFHLE1BQU1HLE9BQU9zRixXQUFXckYsT0FBT3FGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNuQyxxQkFBcUJuRCxPQUFPc0YsV0FBV3JGLE9BQU9xRixXQUFZLENBQUMsQ0FBQ2xGLE1BQU0rQixPQUFPLENBQUNDLGVBQWVJLFFBQVFKLGVBQWVtRCxZQUFhLFNBQVMsWUFBWTtBQUFFLFVBQUk7QUFDbFksY0FBTUMsT0FBTztBQUFBLFVBQ1RsRixNQUFNQSxLQUFLOEMsS0FBSztBQUFBLFVBQUdPLGNBQWNuRCxRQUFRNEMsS0FBSztBQUFBLFVBQUdxQyxVQUFVckYsTUFBTXFGLFlBQVluRyxLQUFLbUc7QUFBQUEsVUFBVTVCLGNBQWNSLE9BQU8zQyxJQUFJO0FBQUEsVUFBR29ELGNBQWNsRCxNQUFNd0MsS0FBSztBQUFBLFVBQUdXLFlBQVlqRDtBQUFBQSxVQUFRa0QsbUJBQW1CbEQsV0FBVyxxQkFBcUJFLFFBQVFvQyxLQUFLLElBQUk7QUFBQSxRQUNoUDtBQUNBLGNBQU1zQyxZQUFZLEVBQUVwRixNQUFNRSxTQUFTRSxNQUFNRSxPQUFPRSxRQUFRRSxRQUFRO0FBQ2hFLFlBQUkyRTtBQUNKLFlBQUl2RixNQUFNO0FBQ04sZ0JBQU13RixXQUFXbkQsZUFBZW9ELFFBQVE7QUFBRyxjQUFJLENBQUNELFNBQVU7QUFDMUQsZ0JBQU1FLFVBQVVGLFNBQVNHO0FBQ3pCSixtQkFBUyxNQUFNMUYsT0FBTytGLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsWUFBWWxDLEtBQUsrQixHQUFHLEdBQUc4RCxTQUFTTCxTQUFTSyxTQUFTVCxNQUFNO0FBQUEsWUFDNUZVLGlCQUFpQk4sU0FBU0s7QUFBQUEsWUFDMUIsR0FBSUgsUUFBUXhGLFNBQVNULFNBQVksRUFBRVMsTUFBTWtGLEtBQUtsRixLQUFLLElBQUksQ0FBQztBQUFBLFlBQ3hELEdBQUl3RixRQUFRdEYsWUFBWVgsU0FBWSxFQUFFOEQsY0FBYzZCLEtBQUs3QixhQUFhLElBQUksQ0FBQztBQUFBLFlBQzNFLEdBQUltQyxRQUFRcEYsU0FBU2IsU0FBWSxFQUFFZ0UsY0FBYzJCLEtBQUszQixhQUFhLElBQUksQ0FBQztBQUFBLFlBQ3hFLEdBQUlpQyxRQUFRbEYsVUFBVWYsU0FBWSxFQUFFaUUsY0FBYzBCLEtBQUsxQixhQUFhLElBQUksQ0FBQztBQUFBLFlBQ3pFLEdBQUlnQyxRQUFRaEYsV0FBV2pCLFNBQVksRUFBRWtFLFlBQVl5QixLQUFLekIsV0FBVyxJQUFJLENBQUM7QUFBQSxZQUN0RSxHQUFJK0IsUUFBUTlFLFlBQVluQixVQUFhaUcsUUFBUWhGLFdBQVdqQixTQUFZLEVBQUVtRSxtQkFBbUJ3QixLQUFLeEIsa0JBQWtCLElBQUksQ0FBQztBQUFBLFVBQ3pILEVBQUUsQ0FBQztBQUFBLFFBQ1AsTUFBTzJCLFVBQVMsTUFBTTNGLE9BQU9nRyxRQUFRLEVBQUVSLEtBQUssQ0FBQztBQUM3QyxjQUFNVyxRQUFRMUQsZUFBZTJELFVBQVV4RCxpQkFBaUIrQyxPQUFPbkQsSUFBSSxHQUFHa0QsV0FBVyxHQUFHcEcsS0FBSzZDLEVBQUUsYUFBYXdELE9BQU9uRCxLQUFLTCxFQUFFLEVBQUU7QUFDeEg5QixnQkFBUThGLFFBQVF0RyxTQUFZOEYsT0FBT25ELElBQUk7QUFBQSxNQUMzQyxTQUNPNkQsT0FBTztBQUFFNUQsdUJBQWU2RCxPQUFPRCxLQUFLO0FBQUEsTUFBRztBQUFBLElBQUUsR0FBRyxtQkF0Qm9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQmpKLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9yRyxPQUFPcUcsU0FBU3BHLE9BQU9vRyxTQUFTakUsZUFBZWlFLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUFFLHVCQUFDLGlCQUFjLFFBQVE1RCxnQkFBZ0IsUUFBUSxFQUFFbkMsTUFBTSxvQkFBb0JFLFNBQVMsbUJBQW1CRSxNQUFNLGtCQUFrQkUsT0FBTyx3QkFBd0JFLFFBQVEsZ0JBQWdCRSxTQUFTLFVBQVUsR0FBRyxNQUFNaEIsT0FBT3NGLFdBQVdyRixPQUFPcUYsV0FBM087QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtUDtBQUFBLE1BQUUsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxvQkFBbUIsT0FBT2hGLE1BQU0sVUFBVSxDQUFBaUcsTUFBS2hHLFFBQVF4QyxnQkFBZ0J3SSxFQUFFQyxPQUFPQyxPQUFPLEdBQUcsQ0FBQyxLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThHO0FBQUEsUUFBRyx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE9BQU9qRyxTQUFTLFVBQVUsQ0FBQStGLE1BQUs5RixXQUFXMUMsZ0JBQWdCd0ksRUFBRUMsT0FBT0MsT0FBTyxHQUFHLENBQUMsS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSDtBQUFBLFFBQUcsdUJBQUMsYUFBVSxPQUFNLHlCQUF3QixNQUFLLFVBQVMsT0FBTy9GLE1BQU0sVUFBVSxDQUFBNkYsTUFBSzVGLFFBQVE0RixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsWUFBWSxFQUFFQyxLQUFLLEdBQUdDLE1BQU0sRUFBRSxLQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRJO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sd0JBQXVCLE9BQU8vRixPQUFPLFVBQVUsQ0FBQTJGLE1BQUsxRixTQUFTOUMsZ0JBQWdCd0ksRUFBRUMsT0FBT0MsT0FBTyxHQUFHLENBQUMsR0FBRyxXQUFTLFFBQTlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEg7QUFBQSxRQUFHLHVCQUFDLGFBQVUsT0FBTSxnQkFBZSxRQUFNLE1BQUMsT0FBTzNGLFFBQVEsVUFBVSxDQUFBeUYsTUFBS3hGLFVBQVV3RixFQUFFQyxPQUFPQyxLQUFzQixHQUFHO0FBQUEsaUNBQUMsWUFBUyxPQUFNLFVBQVMscUNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sb0JBQW1CLHFDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBQWxPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNk87QUFBQSxRQUFhM0YsV0FBVyxzQkFBc0IsdUJBQUMsYUFBVSxPQUFNLDRCQUEyQixPQUFPRSxTQUFTLFVBQVUsQ0FBQXVGLE1BQUt0RixXQUFXc0YsRUFBRUMsT0FBT0MsS0FBSyxLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNHO0FBQUEsUUFBRyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxpRUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFdBQS84QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXU5QjtBQUFBLFNBdEIzMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCdzJDO0FBQUEsSUFDeDJDLHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUN2RixZQUFZLE9BQU0sK0JBQThCLFNBQVMsTUFBTUMsY0FBYyxJQUFJLEdBQUcsTUFBTWpCLE9BQU9vRixTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVXRILGdCQUFnQnNELE9BQU84QixLQUFLLENBQUMsSUFBSSxLQUFLbEQsT0FBT29GLFdBQVcsQ0FBQ2xELGVBQWVJLFFBQVFKLGVBQWVtRCxXQUFXLFNBQVMsWUFBWTtBQUFFLFlBQU1xQixVQUFVeEUsZUFBZUksTUFBTUE7QUFBTSxVQUFJLENBQUNvRTtBQUN2VjtBQUFRLFVBQUk7QUFDWixjQUFNMUcsT0FBTzhGLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsWUFBWXNFLFFBQVF6RSxHQUFHLEdBQUc4RCxTQUFTVyxRQUFRWCxTQUFTVCxNQUFNLEVBQUVVLGlCQUFpQlUsUUFBUVgsU0FBUy9GLFFBQVFrQixhQUFhRSxRQUFRQSxPQUFPOEIsS0FBSyxFQUFFLEVBQUUsQ0FBQztBQUMzS2pDLHNCQUFjLElBQUk7QUFBQSxNQUN0QixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsd0JBTHlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLakcsR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT2pCLE9BQU9tRyxTQUFTakUsZUFBZWlFLFNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxjQUFZakUseUJBQWVJLE1BQU1BLEtBQUtsQyxRQUFRWSxZQUFZWixRQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFBYSx1QkFBQyxhQUFVLE9BQU0sY0FBYSxRQUFNLE1BQUMsT0FBT2MsYUFBYSxVQUFVLENBQUFtRixNQUFLbEYsZUFBZWtGLEVBQUVDLE9BQU9DLEtBQTJCLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sWUFBVyxrQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxhQUFZLHdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQVcsdUJBQUMsWUFBUyxPQUFNLFlBQVcsNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFBN1E7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3UjtBQUFBLFFBQVksdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBT25GLFFBQVEsVUFBVSxDQUFBaUYsTUFBS2hGLFVBQVV4RCxnQkFBZ0J3SSxFQUFFQyxPQUFPQyxPQUFPLEdBQUksQ0FBQyxHQUFHLFdBQVMsUUFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSDtBQUFBLFdBQWhmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbWY7QUFBQSxTQUwvbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUs0bUI7QUFBQSxJQUM1bUIsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQ2pGLGVBQWUsT0FBTyxhQUFhQSxlQUFlbEIsUUFBUSxFQUFFLElBQUksU0FBUyxNQUFNbUIsaUJBQWlCLElBQUksR0FBRyxNQUFNdEIsU0FBU21GLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUMvQixrQkFBa0JwRCxTQUFTbUYsU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJLENBQUM5RDtBQUM1UDtBQUFRLFVBQUk7QUFDWixjQUFNckIsU0FBUzZGLFFBQVEsRUFBRVIsTUFBTTtBQUFBLFVBQ3ZCZCxZQUFZbEQsY0FBY1c7QUFBQUEsVUFBSTRDLFdBQVdyRDtBQUFBQSxVQUFTdUQsVUFBVSxFQUFFNEIsUUFBUWpGLE1BQU02RCxVQUFVakUsY0FBY2lFLFNBQVM7QUFBQSxVQUFHUCxpQkFBaUI3QixPQUFPdkIsT0FBTztBQUFBLFVBQUdxRCxVQUFVOUIsT0FBT3JCLElBQUk7QUFBQSxVQUFHNkIsY0FBY1IsT0FBTzNDLElBQUk7QUFBQSxVQUFHMEUsWUFBWTtBQUFBLFFBQ3ROLEVBQUUsQ0FBQztBQUNQM0QseUJBQWlCLElBQUk7QUFBQSxNQUN6QixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsK0JBUDhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPL0csR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT3RCLFNBQVNrRyxTQUFTdEcsU0FBU3NHLFNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU0sWUFBVyxRQUFNLE1BQUMsT0FBTzNFLFNBQVMsVUFBVSxDQUFBNkUsTUFBSzVFLFdBQVc0RSxFQUFFQyxPQUFPQyxLQUFLLEdBQUkvRTtBQUFBQSxxQkFBVyxDQUFDM0IsU0FBU3lDLE1BQU1BLEtBQUtzRSxLQUFLLENBQUFDLFlBQVdBLFFBQVFsQyxTQUFTaUMsS0FBSyxDQUFBRSxTQUFRQSxLQUFLN0UsT0FBT1QsT0FBTyxDQUFDLEtBQUssdUJBQUMsWUFBUyxPQUFPQSxTQUFVQSxxQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxVQUFhM0IsU0FBU3lDLE1BQU1BLEtBQUttQyxRQUFRLENBQUFDLE1BQUtBLEVBQUVDLFNBQVNvQyxJQUFJLENBQUFuQyxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUUzQyxJQUFLeUM7QUFBQUEsY0FBRXRFO0FBQUFBLFlBQUs7QUFBQSxZQUFJd0UsRUFBRXhFO0FBQUFBLFlBQUs7QUFBQSxZQUFJd0UsRUFBRUU7QUFBQUEsZUFBNUNGLEVBQUUzQyxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRCxDQUFXLENBQUM7QUFBQSxhQUF0WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdYO0FBQUEsUUFBWSx1QkFBQyxrQkFBZSxPQUFNLFlBQVcsYUFBYXBDLFNBQVNtSCxhQUFhLFNBQVNuSCxTQUFTb0gsU0FBUyxNQUFNcEgsU0FBU3FILGVBQWUsWUFBWXJILFNBQVNzSCxZQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJKO0FBQUEsUUFBR3RILFNBQVN1SCxXQUFXLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLGdCQUFNdkgsU0FBU3dILHVCQUF1QnhILFNBQVNzSCxTQUFTLElBQUl0SCxTQUFTa0QsUUFBUTtBQUFBLFFBQUksR0FBRywwQ0FBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSjtBQUFBLFFBQVUsdUJBQUMsYUFBVSxPQUFNLG1CQUFrQixPQUFPckIsTUFBTSxVQUFVLENBQUEyRSxNQUFLMUUsUUFBUTBFLEVBQUVDLE9BQU9DLEtBQUssS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQUUsdUJBQUMsY0FBVyxXQUFVLE9BQU87QUFBQSxpQ0FBQyxhQUFVLE9BQU0sbUJBQWtCLE1BQUssVUFBUyxPQUFPM0UsU0FBUyxVQUFVLENBQUF5RSxNQUFLeEUsV0FBV3dFLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxZQUFZLEVBQUVDLEtBQUssR0FBR0MsTUFBTSxFQUFFLEtBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRJO0FBQUEsVUFBRSx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE1BQUssVUFBUyxPQUFPM0UsTUFBTSxVQUFVLENBQUF1RSxNQUFLdEUsUUFBUXNFLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxZQUFZLEVBQUVDLEtBQUssR0FBR0MsTUFBTSxFQUFFLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNJO0FBQUEsYUFBalQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtVDtBQUFBLFFBQWEsdUJBQUMsYUFBVSxPQUFNLHlCQUF3QixNQUFLLFVBQVMsT0FBT2pHLE1BQU0sVUFBVSxDQUFBNkYsTUFBSzVGLFFBQVE0RixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsWUFBWSxFQUFFQyxLQUFLLEdBQUdDLE1BQU0sRUFBRSxLQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRJO0FBQUEsV0FBdHdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd3dDO0FBQUEsU0FQdjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPbzRDO0FBQUEsT0FwRDEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0R1NEM7QUFDbDVDO0FBQUN0SCxHQS9FZUQsZUFBYTtBQUFBLFVBQ1J4QixVQUNBaEIsaUJBQ0pXLFFBQ0VBLFFBQ0VDLGFBQ0ZDLFlBQ0FBLFlBQ0FBLFlBQ0VBLFlBS01GLFFBRUFuQixpQkFBaUI7QUFBQTtBQUFBLEtBaEI1QmdEO0FBZ0ZULGdCQUFTb0ksb0JBQW9CO0FBQUFDLE1BQUE7QUFDaEMsUUFBTSxFQUFFbkksS0FBSyxJQUFJMUIsU0FBUztBQUMxQixRQUFNOEosV0FBVy9LLFlBQVk7QUFDN0IsUUFBTSxDQUFDNEMsTUFBTSxJQUFJM0MsZ0JBQWdCO0FBQ2pDLFFBQU0rSyxjQUFjcEssT0FBTywyQkFBMkIsRUFBRWtDLE9BQU8sRUFBRUMsT0FBTyxJQUFJQyxRQUFRSixPQUFPSyxJQUFJLGtCQUFrQixLQUFLQyxPQUFVLEVBQUUsQ0FBQztBQUNuSSxRQUFNK0gsUUFBUXJLLE9BQU8sb0JBQW9CLEVBQUVrQyxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsUUFBUUosT0FBT0ssSUFBSSxZQUFZLEtBQUtDLE9BQVUsRUFBRSxDQUFDO0FBQ2hILFFBQU1DLFNBQVN0QyxZQUFZLG9CQUFvQjtBQUMvQyxRQUFNcUssWUFBWXJLLFlBQVksZUFBZTtBQUM3QyxRQUFNc0ssYUFBYXRLLFlBQVksa0JBQWtCLEVBQUVpQyxPQUFPLEVBQUVTLFFBQVEsVUFBVVIsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUMzRixRQUFNLENBQUNxSSxhQUFhQyxjQUFjLElBQUl4TCxTQUFTOEMsS0FBSzJJLGtCQUFrQjtBQUN0RSxRQUFNQyx3QkFBd0JySyxPQUFPLGlCQUFpQjtBQUN0RCxRQUFNc0ssV0FBVzFLLFdBQVcsbUJBQW1CLENBQUMsMkJBQTJCLHNCQUFzQixzQ0FBc0Msb0JBQW9CLENBQUM7QUFDNUosUUFBTTJLLFdBQVczSyxXQUFXLHVCQUF1QixDQUFDLHNCQUFzQix5QkFBeUIsQ0FBQztBQUNwRyxRQUFNdUMsU0FBU3ZDLFdBQVcscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDbkUsUUFBTXdDLFNBQVN4QyxXQUFXLHFCQUFxQixDQUFDLGtCQUFrQixDQUFDO0FBQ25FLFFBQU0sQ0FBQzRLLEtBQUtDLE1BQU0sSUFBSTlMLFNBQVMsQ0FBQyxHQUFHLENBQUM0RCxNQUFNQyxPQUFPLElBQUk3RCxTQUF5QyxHQUFHLENBQUMrTCxTQUFTQyxRQUFRLElBQUloTSxTQUFTLEVBQUUsR0FBRyxDQUFDaU0sU0FBU0MsVUFBVSxJQUFJbE0sU0FBUyxHQUFHLEdBQUcsQ0FBQ2dLLFFBQVFtQyxTQUFTLElBQUluTSxTQUFTLElBQUksR0FBRyxDQUFDb00sUUFBUUMsU0FBUyxJQUFJck0sU0FBUyxHQUFHLEdBQUcsQ0FBQ3NNLE1BQU1DLE9BQU8sSUFBSXZNLFNBQThCLG9CQUFvQixHQUFHLENBQUN3TSxTQUFTQyxVQUFVLElBQUl6TSxTQUFTLElBQUksR0FBRyxDQUFDME0sUUFBUUMsU0FBUyxJQUFJM00sU0FBUyxFQUFFLEdBQUcsQ0FBQzRNLGNBQWNDLGVBQWUsSUFBSTdNLFNBQVMsRUFBRSxHQUFHLENBQUM4TSxTQUFTQyxVQUFVLElBQUkvTSxTQUFTLEtBQUs7QUFDaGUsUUFBTWdOLG1CQUFtQjNMLE9BQU8sZ0JBQWdCO0FBQ2hELFFBQU00TCx1QkFBdUJ2Qix5QkFBeUJzQixvQkFBb0JwSixTQUFTUCxVQUFhaUosU0FBUztBQUN6RyxRQUFNWSxVQUFVbk0sT0FBTyxzQkFBc0IsQ0FBQyxHQUFHa00sb0JBQW9CO0FBQ3JFLFFBQU1FLGtCQUFrQnBNLE9BQU8saUJBQWlCLEVBQUVrQyxPQUFPLEVBQUVDLE9BQU8sSUFBSSxFQUFFLEdBQUcrSixvQkFBb0I7QUFDL0YsUUFBTUcsY0FBY3JNLE9BQU8sMkJBQTJCLENBQUMsR0FBRzJLLHlCQUF5QjlILFNBQVNQLFVBQWFpSixTQUFTLFdBQVc7QUFDN0gsUUFBTWUsc0JBQXNCLElBQUlDLElBQUlqQyxVQUFVckYsTUFBTUEsS0FBS3VILE9BQU8sQ0FBQUMsYUFBWUEsU0FBUzlKLFdBQVcsVUFBVSxFQUFFK0csSUFBSSxDQUFBK0MsYUFBWUEsU0FBUzdILEVBQUUsS0FBSyxFQUFFO0FBQzlJLFFBQU04SCxpQkFBaUJuSyxPQUFPMEMsTUFBTUEsS0FBS3VILE9BQU8sQ0FBQUcsVUFBU0wsb0JBQW9CTSxJQUFJRCxNQUFNeEYsVUFBVSxLQUFLMEYsZUFBZUYsS0FBSyxDQUFDLEtBQUs7QUFDaEksUUFBTUcsd0JBQXdCdkssT0FBTzBDLE1BQU1BLEtBQUtpQyxLQUFLLENBQUF5RixVQUFTQSxNQUFNL0gsT0FBT29HLE9BQU87QUFDbEYsUUFBTStCLHNCQUFzQi9NLE9BQU8sb0JBQW9CLEVBQUU4RSxNQUFNLEVBQUVDLFlBQVlpRyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUNBLFdBQVcsQ0FBQzhCLHFCQUFxQjtBQUM3SCxRQUFNRSxnQkFBZ0JGLHlCQUF5QkMsb0JBQW9COUgsTUFBTUE7QUFDekUsUUFBTWdJLDJCQUEyQjNDLFVBQVVyRixNQUFNQSxLQUFLaUMsS0FBSyxDQUFBdUYsYUFBWUEsU0FBUzdILE9BQU9vSSxlQUFlN0YsVUFBVTtBQUNoSCxRQUFNK0YseUJBQXlCbE4sT0FBTyxlQUFlLEVBQUU4RSxNQUFNLEVBQUVDLFlBQVlpSSxlQUFlN0YsY0FBYyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM2RixlQUFlN0YsY0FBYyxDQUFDOEYsd0JBQXdCO0FBQ3hLLFFBQU1FLG1CQUFtQkYsNEJBQTRCQyx1QkFBdUJqSSxNQUFNQTtBQUNsRixRQUFNbUksd0JBQXdCLENBQUMsQ0FBQ0osaUJBQWlCRyxrQkFBa0J4SyxXQUFXLGNBQWNrSyxlQUFlRyxhQUFhO0FBQ3hILFFBQU1LLGtCQUFrQmxCLFFBQVFsSCxNQUFNQSxLQUFLdUgsT0FBTyxDQUFBL0MsU0FBUUEsS0FBSzZELFNBQVMsaUJBQWlCN0QsS0FBS2dDLFdBQVcsQ0FBQyxDQUFDaEMsS0FBSzhELGVBQWUsQ0FBQyxDQUFDOUQsS0FBSytELGNBQWMsQ0FBQyxDQUFDcEIsZ0JBQWdCbkgsTUFBTXdJLEtBQUtDLFFBQVF0QixnQkFBZ0JuSCxLQUFLQSxLQUFLc0UsS0FBSyxDQUFBb0UsYUFBWUEsU0FBUy9JLE9BQU82RSxLQUFLK0QsY0FBY0csU0FBU2hMLFdBQVcsY0FBY2dMLFNBQVNDLFNBQVNDLFNBQVMsbUJBQW1CRixTQUFTQyxTQUFTaEosT0FBTzZFLEtBQUs3RSxNQUFNK0ksU0FBU0csb0JBQW9CckUsS0FBS2YsV0FBV3FGLEtBQUtDLE1BQU1MLFNBQVNNLFNBQVMsSUFBSUYsS0FBS0MsTUFBTTVCLGdCQUFnQm5ILE1BQU13SSxLQUFLQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEtBQUs7QUFDaGdCLFFBQU1RLHNCQUF1QjdCLFlBQVlwSCxNQUFNQSxNQUEyQ3VILE9BQU8sQ0FBQTJCLFVBQVNBLE1BQU14TCxXQUFXLFlBQVlvTCxLQUFLQyxNQUFNRyxNQUFNRixTQUFTLElBQUlGLEtBQUtLLElBQUksS0FBS0QsTUFBTWhILGVBQWU2RixlQUFlN0YsY0FBY2dILE1BQU0zRCxnQkFBZ0JBLGVBQWUyRCxNQUFNRSxtQkFBbUIxQyxVQUFVd0MsTUFBTUcsZUFBZS9FLEtBQUssQ0FBQWdGLGFBQVlBLFNBQVNDLG9CQUFvQnhELFdBQVd1RCxTQUFTRSxpQkFBaUJ6QixlQUFldEUsV0FBVzZGLFNBQVM3RyxTQUFTNEIsV0FBVzBELGVBQWV0RixTQUFTNEIsVUFBVWlGLFNBQVM3RyxTQUFTUSxhQUFhOEUsZUFBZXRGLFNBQVNRLFlBQVlxRyxTQUFTNUcsb0JBQW9CcUYsZUFBZXJGLG1CQUFtQjRHLFNBQVMzRyxhQUFhb0YsZUFBZXBGLFFBQVEsQ0FBQyxLQUFLO0FBQ25xQixRQUFNOEcsaUJBQWlCbkQsU0FBUyxlQUFnQlcsd0JBQXdCLENBQUNDLFFBQVF3QyxhQUFhLENBQUN4QyxRQUFRcEMsV0FBVyxDQUFDcUMsZ0JBQWdCdUMsYUFBYSxDQUFDdkMsZ0JBQWdCckMsV0FBV3NELGdCQUFnQjlELEtBQUssQ0FBQUUsU0FBUUEsS0FBSzdFLE9BQU8rRyxNQUFNO0FBQzNOLFFBQU1pRCxxQkFBcUJyRCxTQUFTLGVBQWdCWix5QkFBeUIsQ0FBQzBCLFlBQVlzQyxhQUFhLENBQUN0QyxZQUFZdEMsV0FBV21FLG9CQUFvQjNFLEtBQUssQ0FBQUUsU0FBUUEsS0FBSzdFLE9BQU9pSCxZQUFZO0FBQ3hMLFFBQU1nRCxnQkFBZ0J6Qix5QkFBeUI3QyxXQUFXdEYsTUFBTUEsS0FBS3NFLEtBQUssQ0FBQXVGLGNBQWFBLFVBQVVsSyxPQUFPNEYsV0FBVyxLQUFLMUUsT0FBT0MsVUFBVUQsT0FBT29GLE9BQU8sQ0FBQyxLQUFLcEYsT0FBT29GLE9BQU8sS0FBSyxLQUFLcEYsT0FBT0MsVUFBVUQsT0FBT21ELE1BQU0sQ0FBQyxLQUFLbkQsT0FBT21ELE1BQU0sS0FBS25ELE9BQU9vRixPQUFPLEtBQUtwRixPQUFPQyxVQUFVRCxPQUFPdUYsTUFBTSxDQUFDLEtBQUt2RixPQUFPdUYsTUFBTSxLQUFLLE1BQU1FLFNBQVMsZUFBZ0JtRCxrQkFBa0JFLHNCQUFzQjdDO0FBQzNYLFFBQU03RixPQUFPQSxDQUFDNkksTUFBMEI7QUFBRWpNLFlBQVFpTSxDQUFDO0FBQUd0RSxtQkFBZXNFLEdBQUd2RSxlQUFlekksS0FBSzJJLGtCQUFrQjtBQUFHTyxhQUFTOEQsR0FBR1AsbUJBQW1CLEVBQUU7QUFBR3JELGVBQVc5RSxPQUFPMEksR0FBR0MsZ0JBQWdCLENBQUMsQ0FBQztBQUFHNUQsY0FBVS9FLE9BQU8wSSxHQUFHRSxrQkFBa0IsRUFBRSxDQUFDO0FBQUczRCxjQUFVakYsT0FBTzBJLEdBQUdHLGVBQWUsQ0FBQyxDQUFDO0FBQUcxRCxZQUFRdUQsR0FBR3hELFFBQVEsb0JBQW9CO0FBQUdHLGVBQVdxRCxHQUFHdEQsV0FBVyxJQUFJO0FBQUdHLGNBQVVtRCxHQUFHVixrQkFBa0IsRUFBRTtBQUFHdkMsb0JBQWdCaUQsR0FBR0ksd0JBQXdCLEVBQUU7QUFBR25ELGVBQVcsS0FBSztBQUFBLEVBQUc7QUFDcGMsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxpQkFBZ0IsVUFBUywwRkFBeUYsU0FBUyxtQ0FBRTtBQUFBLDZCQUFDLGtCQUFlLFlBQVcsc0JBQXFCLFNBQVMsTUFBTTlGLEtBQUssSUFBSSxHQUFHLDRCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUEsTUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUSxhQUFZLE1BQU0wRSxTQUFTN0MsU0FBUyxTQUFTLE1BQU0sS0FBSzZDLFNBQVNuQyxRQUFRLEVBQUUyRyxNQUFNLE1BQU05TSxNQUFTLEdBQUcscUNBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0s7QUFBQSxTQUF6UjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBTLEtBQXZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMmI7QUFBQSxJQUFFLHVCQUFDLGVBQVksT0FBT3NJLFNBQVM5QixTQUFTK0IsU0FBUy9CLFNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQ7QUFBQSxJQUFFLHVCQUFDLFFBQUssT0FBT2dDLEtBQUssVUFBVSxDQUFDdUUsR0FBRzlILE1BQWN3RCxPQUFPeEQsQ0FBQyxHQUFHLElBQUkzRixTQUFTb0YsS0FBS3NJLGNBQWM7QUFBQSw2QkFBQyxPQUFJLE9BQU0sa0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQUUsdUJBQUMsT0FBSSxPQUFNLHNCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxTQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1KO0FBQUEsSUFBUXhFLFFBQVEsSUFBSSx1QkFBQyxTQUFNO0FBQUEsNkJBQUMsY0FBVyxVQUFTLFdBQVU7QUFBQSwrQkFBQyxjQUFXLFdBQVcsRUFBRXlFLElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQUk7QUFBQSxpQ0FBQyxrQkFBZSxPQUFNLFdBQVUsYUFBYWpOLE9BQU9vSCxhQUFhLFNBQVNwSCxPQUFPcUgsU0FBUyxNQUFNckgsT0FBT3NILGVBQWUsWUFBWXRILE9BQU91SCxZQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSjtBQUFBLFVBQUUsdUJBQUMsa0JBQWUsT0FBTSxnQkFBZSxhQUFhUSxVQUFVWCxhQUFhLFNBQVNXLFVBQVVWLFNBQVMsTUFBTVUsVUFBVVQsZUFBZSxZQUFZUyxVQUFVUixZQUExSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSztBQUFBLGFBQTVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOFc7QUFBQSxTQUFldkgsT0FBT3FILFdBQVdVLFVBQVVWLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sMkhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0k7QUFBQSxRQUFVckgsT0FBT29NLGFBQWEsdUJBQUMsY0FBVyxNQUFLLFVBQVMsMkNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUFlcE0sT0FBT3dILFdBQVcsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyxnQ0FBZ0M7QUFBQSxpQ0FBQyxlQUFZLE9BQU94SCxPQUFPdUcsU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUM7QUFBQSxVQUFHMkcsZUFBZWxOLE9BQU91RyxLQUFLLEtBQUssdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsa0JBQU12RyxPQUFPeUgsdUJBQXVCekgsT0FBT3VILFNBQVMsSUFBSXZILE9BQU9tRCxRQUFRO0FBQUEsVUFBSSxHQUFHLHlDQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2STtBQUFBLGFBQXJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK1I7QUFBQSxRQUFlLENBQUNuRCxPQUFPb00sYUFBYSxDQUFDcE0sT0FBT3dILFdBQVd4SCxPQUFPb0gsZ0JBQWdCLEtBQUssdUJBQUMsY0FBVyxNQUFLLFVBQVMsdURBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUFlVyxVQUFVcUUsYUFBYSx1QkFBQyxjQUFXLE1BQUssVUFBUyxnREFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFFBQWVyRSxVQUFVUCxXQUFXLHVCQUFDLGNBQVcsTUFBSyxTQUFRLGNBQVcscUNBQXFDO0FBQUEsaUNBQUMsZUFBWSxPQUFPTyxVQUFVeEIsU0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxVQUFHMkcsZUFBZW5GLFVBQVV4QixLQUFLLEtBQUssdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsa0JBQU13QixVQUFVTix1QkFBdUJNLFVBQVVSLFNBQVMsSUFBSVEsVUFBVTVFLFFBQVE7QUFBQSxVQUFJLEdBQUcsOENBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJKO0FBQUEsYUFBOVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3VDtBQUFBLFFBQWUsQ0FBQzRFLFVBQVVxRSxhQUFhLENBQUNyRSxVQUFVUCxXQUFXTyxVQUFVWCxnQkFBZ0IsS0FBSyx1QkFBQyxjQUFXLE1BQUssVUFBUyw0REFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFdBQTNzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXl0RDtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFPUyxhQUFhLGdCQUFlLFdBQVdBLHNCQUFZbkYsUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxxQkFBb0IsTUFBTW1GLFlBQVluRixLQUFLQSxNQUFNLFFBQVEsQ0FBQThKLE1BQUtBLEVBQUVuSyxJQUFJLFNBQVM7QUFBQSxVQUMzakYsRUFBRThCLEtBQUssT0FBT0MsT0FBTyxZQUFZQyxRQUFRQSxDQUFBbUksTUFBSyxnQkFBZ0JBLEVBQUV2SCxTQUFTLEdBQUc7QUFBQSxVQUFHLEVBQUVkLEtBQUssWUFBWUMsT0FBTyxnQkFBZ0JDLFFBQVFBLENBQUFtSSxNQUFLO0FBQ2xJLGtCQUFNcEMsUUFBUXBLLE9BQU8wQyxNQUFNQSxLQUFLaUMsS0FBSyxDQUFBdUMsU0FBUUEsS0FBSzdFLE9BQU9tSyxFQUFFUCxlQUFlO0FBQzFFLGdCQUFJLENBQUM3QixNQUFPLFFBQU9wSyxPQUFPb00sWUFBWSxzQkFBc0JwTSxPQUFPd0gsVUFBVSxnQ0FBZ0N4SCxPQUFPcUgsVUFBVSxpQ0FBaUM7QUFDL0osa0JBQU02QyxXQUFXbkMsVUFBVXJGLE1BQU1BLEtBQUtpQyxLQUFLLENBQUF1QyxTQUFRQSxLQUFLN0UsT0FBTytILE1BQU14RixVQUFVO0FBQy9FLGdCQUFJLENBQUNzRixTQUFVLFFBQU9uQyxVQUFVcUUsWUFBWSwyQkFBMkJyRSxVQUFVUCxVQUFVLHFDQUFxQ08sVUFBVVYsVUFBVSxzQ0FBc0M7QUFDMUwsZ0JBQUk2QyxTQUFTOUosV0FBVyxXQUFZLFFBQU84SixTQUFTMUosT0FBTztBQUMzRCxtQkFBTzBKLFNBQVMxSjtBQUFBQSxVQUNwQixFQUFFO0FBQUEsVUFBRyxFQUFFMkQsS0FBSyxhQUFhQyxPQUFPLGNBQWMrSSxPQUFPLFNBQVM5SSxRQUFRQSxDQUFBbUksTUFBS0EsRUFBRVksVUFBVTtBQUFBLFVBQUcsRUFBRWpKLEtBQUssWUFBWUMsT0FBTyxXQUFXK0ksT0FBTyxTQUFTOUksUUFBUUEsQ0FBQW1JLE1BQUtBLEVBQUVhLGlCQUFpQjtBQUFBLFVBQUcsRUFBRWxKLEtBQUssWUFBWUMsT0FBTyxjQUFjK0ksT0FBTyxTQUFTOUksUUFBUUEsQ0FBQW1JLE1BQUtBLEVBQUVjLHFCQUFxQjtBQUFBLFVBQzlRO0FBQUEsWUFDSW5KLEtBQUs7QUFBQSxZQUFPQyxPQUFPO0FBQUEsWUFBWStJLE9BQU87QUFBQSxZQUFTOUksUUFBUUEsQ0FBQW1JLE1BQUssdUJBQUMsY0FBVyxPQUFNLGdCQUFlLFlBQVk1UCxTQUFTMEgsV0FBV0MsV0FBV2dKLE1BQU9mLFlBQUVnQixxQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUc7QUFBQSxVQUN2SztBQUFBLFVBQ0EsRUFBRXJKLEtBQUssVUFBVUMsT0FBTyxVQUFVQyxRQUFRQSxDQUFBbUksTUFBSyx1QkFBQyxTQUFNO0FBQUEsbUNBQUMsY0FBWUEsWUFBRWhMLFVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUFjZ0wsRUFBRWlCLGtCQUFrQmpCLEVBQUVpQixtQkFBbUIsbUJBQW1CLHVCQUFDLGNBQVcsU0FBUSxXQUFVO0FBQUE7QUFBQSxjQUFTakIsRUFBRWlCO0FBQUFBLGNBQWdCakIsRUFBRWtCLGlCQUFpQixNQUFNbEIsRUFBRWtCLGNBQWMsS0FBSztBQUFBLGlCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRztBQUFBLGVBQWpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStOLEVBQVM7QUFBQSxVQUN2UjtBQUFBLFlBQ0l2SixLQUFLO0FBQUEsWUFBVUMsT0FBTztBQUFBLFlBQUlDLFFBQVFBLENBQUFtSSxNQUFLLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFVBQVUsQ0FBQyxDQUFDQSxFQUFFbUIseUJBQXlCbkIsRUFBRWdCLHFCQUFxQixLQUFLLENBQUNyRCxlQUFlbkQsS0FBSyxDQUFBb0QsVUFBU0EsTUFBTS9ILE9BQU9tSyxFQUFFUCxlQUFlLEdBQUcsTUFBTTNELFNBQVM5QyxTQUFTLFNBQVMsWUFBWTtBQUFFLG9CQUFNZCxJQUFJeUYsZUFBZXhGLEtBQUssQ0FBQUQsT0FBS0EsR0FBRXJDLE9BQU9tSyxFQUFFUCxlQUFlO0FBQUcsa0JBQUksQ0FBQ3ZIO0FBQ3hVO0FBQVEsa0JBQUk7QUFDWixzQkFBTTRELFNBQVNwQyxRQUFRLEVBQUVSLE1BQU07QUFBQSxrQkFDdkJkLFlBQVlGLEVBQUVFO0FBQUFBLGtCQUFZcUQsYUFBYXVFLEVBQUV2RTtBQUFBQSxrQkFBYTJGLGNBQWNwQixFQUFFbks7QUFBQUEsa0JBQUl3TCxPQUFPLENBQUMsRUFBRTVJLFdBQVd1SCxFQUFFdkgsV0FBV2dILGlCQUFpQnZILEVBQUVyQyxJQUFJeUwsVUFBVXRCLEVBQUVnQixrQkFBa0IsQ0FBQztBQUFBLGdCQUN0SyxFQUFFLENBQUM7QUFDUDVGLHlCQUFTLE1BQU1wSSxLQUFLNkMsRUFBRSxZQUFZO0FBQUEsY0FDdEMsUUFDTTtBQUFBLGNBQUU7QUFBQSxZQUFnQixHQUFHLDRCQVBZO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxVQUMzQztBQUFBLFFBQUMsS0F0QjQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUIvOUU7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTXdGLFlBQVluRixLQUFLK0IsTUFBTSxhQUFZLHNCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsV0F2Qnk1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJ2NUUsS0F2QnkwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJyMEU7QUFBQSxTQXZCd2xCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QjNrQixJQUFXLHVCQUFDLFNBQU0saUNBQUMsY0FBVyxPQUFPcUQsT0FBTyxnQkFBZSxXQUFXQSxnQkFBTXBGLFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE9BQU0sMkJBQTBCLE1BQU1vRixNQUFNcEYsS0FBS0EsTUFBTSxRQUFRLENBQUE4SixNQUFLQSxFQUFFbkssSUFBSSxTQUFTO0FBQUEsUUFDelEsRUFBRThCLEtBQUssT0FBT0MsT0FBTyxZQUFZQyxRQUFRQSxDQUFBbUksTUFBSyxnQkFBZ0JBLEVBQUV2SCxTQUFTLEdBQUc7QUFBQSxRQUFHLEVBQUVkLEtBQUssYUFBYUMsT0FBTyxxQkFBcUJDLFFBQVFBLENBQUFtSSxNQUFLLEdBQUdBLEVBQUVDLFlBQVksTUFBTUQsRUFBRUUsY0FBYyxHQUFHO0FBQUEsUUFBRyxFQUFFdkksS0FBSyxVQUFVQyxPQUFPLGVBQWVDLFFBQVFBLENBQUFtSSxNQUFLQSxFQUFFRyxZQUFZO0FBQUEsUUFBRyxFQUFFeEksS0FBSyxRQUFRQyxPQUFPLGVBQWVDLFFBQVFBLENBQUFtSSxNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRXhELFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0IsRUFBRztBQUFBLFFBQUcsRUFBRTdFLEtBQUssV0FBV0MsT0FBTyxPQUFPQyxRQUFRQSxDQUFBbUksTUFBS0EsRUFBRXRELFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDdlo7QUFBQSxVQUNJL0UsS0FBSztBQUFBLFVBQVFDLE9BQU87QUFBQSxVQUFJQyxRQUFRQSxDQUFBbUksTUFBSyx1QkFBQyxrQkFBZSxZQUFXLHNCQUFxQixTQUFTLE1BQU03SSxLQUFLNkksQ0FBQyxHQUFHLDZCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFFBQzlIO0FBQUEsTUFBQyxLQUowSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzdLO0FBQUEsTUFBRSx1QkFBQyxTQUFNLE1BQU0xRSxNQUFNcEYsS0FBSytCLE1BQU0sYUFBWSxnQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLFNBTG1IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLakgsS0FMK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUszQyxLQUxvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3ZCO0FBQUEsSUFDaEYsdUJBQUMsY0FBVyxxQkFBbUIsTUFBQyxNQUFNbkUsU0FBU1AsUUFBVyxPQUFNLG9CQUFtQixTQUFTLE1BQU1RLFFBQVFSLE1BQVMsR0FBRyxNQUFNRyxPQUFPc0YsV0FBV3JGLE9BQU9xRixTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDOEcsaUJBQWlCcE0sT0FBT3NGLFdBQVdyRixPQUFPcUYsU0FBUyxTQUFTLFlBQVk7QUFBRSxZQUFNZCxJQUFJbUcsd0JBQXdCSixnQkFBZ0IxSztBQUFXLFVBQUksQ0FBQzJFO0FBQ25WO0FBQVEsWUFBTWdCLE9BQU87QUFBQSxRQUNyQlQsV0FBV1AsRUFBRU87QUFBQUEsUUFBV2dEO0FBQUFBLFFBQWFnRSxpQkFBaUJ4RDtBQUFBQSxRQUFTZ0UsY0FBY2xKLE9BQU9vRixPQUFPO0FBQUEsUUFBRytELGdCQUFnQm5KLE9BQU9tRCxNQUFNO0FBQUEsUUFBR2lHLGFBQWFwSixPQUFPdUYsTUFBTTtBQUFBLFFBQUdFO0FBQUFBLFFBQU1FO0FBQUFBLFFBQVM0QyxnQkFBZ0IxQyxVQUFVO0FBQUEsUUFBTXdELHNCQUFzQjVELFNBQVMsY0FBY00sZUFBZTtBQUFBLE1BQzFRO0FBQUcsVUFBSTtBQUNILFlBQUloSjtBQUNBLGdCQUFNSCxPQUFPK0YsUUFBUSxFQUFFM0QsTUFBTSxFQUFFQyxZQUFZbEMsS0FBSytCLEdBQUcsR0FBR3FELE1BQU0sRUFBRSxHQUFHQSxNQUFNVSxpQkFBaUI5RixLQUFLNkYsUUFBUSxFQUFFLENBQUM7QUFBQTtBQUV4RyxnQkFBTWpHLE9BQU9nRyxRQUFRLEVBQUVSLEtBQUssQ0FBQztBQUNqQ25GLGdCQUFRUixNQUFTO0FBQUEsTUFDckIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUFnQixHQUFHLDJCQVZ5STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVTlILEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9HLE9BQU9xRyxTQUFTcEcsT0FBT29HLFNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxNQUFHa0MsV0FBVytCLG9CQUFvQjRCLGFBQWEsQ0FBQzNCLGlCQUFpQix1QkFBQyxjQUFXLE1BQUssVUFBUyx5Q0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQWVELG9CQUFvQmhELFdBQVcsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyw4QkFBOEI7QUFBQSwrQkFBQyxlQUFZLE9BQU9nRCxvQkFBb0JqRSxTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFBRzJHLGVBQWUxQyxvQkFBb0JqRSxLQUFLLEtBQUssdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsZUFBS2lFLG9CQUFvQnJILFFBQVE7QUFBQSxRQUFHLEdBQUcsdUNBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxXQUFwUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThRO0FBQUEsTUFBZXNILGVBQWU3RixjQUFjK0YsdUJBQXVCeUIsYUFBYSxDQUFDeEIsb0JBQW9CLHVCQUFDLGNBQVcsTUFBSyxVQUFTLDhDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFBZUQsdUJBQXVCbkQsV0FBVyx1QkFBQyxjQUFXLE1BQUssU0FBUSxjQUFXLG1DQUFtQztBQUFBLCtCQUFDLGVBQVksT0FBT21ELHVCQUF1QnBFLFNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUFHMkcsZUFBZXZDLHVCQUF1QnBFLEtBQUssS0FBSyx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU07QUFBRSxlQUFLb0UsdUJBQXVCeEgsUUFBUTtBQUFBLFFBQUcsR0FBRyw0Q0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFdBQXZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaVM7QUFBQSxNQUFlbkQsT0FBT29NLGFBQWEsdUJBQUMsY0FBVyxNQUFLLFVBQVMsMkNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxNQUFlcE0sT0FBT3dILFdBQVcsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyw4Q0FBOEM7QUFBQSwrQkFBQyxlQUFZLE9BQU94SCxPQUFPdUcsU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQUcyRyxlQUFlbE4sT0FBT3VHLEtBQUssS0FBSyx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU07QUFBRSxnQkFBTXZHLE9BQU95SCx1QkFBdUJ6SCxPQUFPdUgsU0FBUyxJQUFJdkgsT0FBT21ELFFBQVE7QUFBQSxRQUFJLEdBQUcseUNBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkk7QUFBQSxXQUFuUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZTO0FBQUEsTUFBZTRFLFVBQVVxRSxhQUFhLHVCQUFDLGNBQVcsTUFBSyxVQUFTLGdEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFBZXJFLFVBQVVQLFdBQVcsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyxtREFBbUQ7QUFBQSwrQkFBQyxlQUFZLE9BQU9PLFVBQVV4QixTQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFBRzJHLGVBQWVuRixVQUFVeEIsS0FBSyxLQUFLLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLGdCQUFNd0IsVUFBVU4sdUJBQXVCTSxVQUFVUixTQUFTLElBQUlRLFVBQVU1RSxRQUFRO0FBQUEsUUFBSSxHQUFHLDhDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJKO0FBQUEsV0FBNVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzVTtBQUFBLE1BQWMsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sZ0JBQWUsT0FBTzhFLGFBQWEsVUFBVSxDQUFBOEYsVUFBUzdGLGVBQWU2RixNQUFNckgsT0FBT0MsS0FBSyxHQUFHLFVBQVV6RyxPQUFPc0YsV0FBV3JGLE9BQU9xRixTQUFVeUM7QUFBQUEseUJBQWUsQ0FBQ0QsV0FBV3RGLE1BQU1BLEtBQUtzRSxLQUFLLENBQUF1RixjQUFhQSxVQUFVbEssT0FBTzRGLFdBQVcsS0FBSyx1QkFBQyxZQUFTLE9BQU9BLGFBQWE7QUFBQTtBQUFBLFlBQWNBO0FBQUFBLFlBQVk7QUFBQSxlQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQWFELFdBQVd0RixNQUFNQSxLQUFLeUUsSUFBSSxDQUFBb0YsY0FBYSx1QkFBQyxZQUE0QixPQUFPQSxVQUFVbEssSUFBS2tLO0FBQUFBLHNCQUFVeUI7QUFBQUEsWUFBSztBQUFBLFlBQUl6QixVQUFVL0w7QUFBQUEsZUFBakUrTCxVQUFVbEssSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUYsQ0FBVztBQUFBLGFBQTlkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ2U7QUFBQSxRQUFZLHVCQUFDLGtCQUFlLE9BQU0sZ0JBQWUsYUFBYTJGLFdBQVdaLGFBQWEsU0FBU1ksV0FBV1gsU0FBUyxNQUFNVyxXQUFXVixlQUFlLFlBQVlVLFdBQVdULFlBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUs7QUFBQSxRQUFFLHVCQUFDLGVBQVksT0FBT1MsV0FBV3pCLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTSxpQkFBZ0IsUUFBTSxNQUFDLE9BQU9rQyxTQUFTLFVBQVUsQ0FBQWhDLE1BQUtpQyxTQUFTakMsRUFBRUMsT0FBT0MsS0FBSyxHQUFJOEI7QUFBQUEscUJBQVcsQ0FBQ3pJLE9BQU8wQyxNQUFNQSxLQUFLc0UsS0FBSyxDQUFBb0QsVUFBU0EsTUFBTS9ILE9BQU9vRyxPQUFPLEtBQUssdUJBQUMsWUFBUyxPQUFPQSxTQUFVK0IsOEJBQW9CNEIsWUFBWSw4QkFBOEI1QixvQkFBb0JoRCxVQUFVLGtDQUFrQ2lELGVBQWV4RixhQUFhd0YsZUFBZXBJLE1BQU0sb0NBQTFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJPO0FBQUEsVUFBYThILGVBQWVoRCxJQUFJLENBQUF6QyxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVyQyxJQUFLcUM7QUFBQUEsY0FBRU87QUFBQUEsWUFBVTtBQUFBLFlBQUlQLEVBQUVFO0FBQUFBLFlBQVc7QUFBQSxZQUFJRixFQUFFUyxTQUFTNEI7QUFBQUEsWUFBTztBQUFBLFlBQUVyQyxFQUFFUyxTQUFTUTtBQUFBQSxZQUFTO0FBQUEsWUFBUWpCLEVBQUVVO0FBQUFBLFlBQWdCO0FBQUEsWUFBYVYsRUFBRVc7QUFBQUEsZUFBdElYLEVBQUVyQyxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SixDQUFXO0FBQUEsYUFBaG1CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa21CO0FBQUEsUUFBWSx1QkFBQyxrQkFBZSxPQUFNLFdBQVUsYUFBYXJDLE9BQU9vSCxhQUFhLFNBQVNwSCxPQUFPcUgsU0FBUyxNQUFNckgsT0FBT3NILGVBQWUsWUFBWXRILE9BQU91SCxZQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtKO0FBQUEsUUFBRSx1QkFBQyxjQUFXLFdBQVUsT0FBTztBQUFBLGlDQUFDLGFBQVUsT0FBTSxlQUFjLE1BQUssVUFBUyxPQUFPb0IsU0FBUyxVQUFVLENBQUFsQyxNQUFLbUMsV0FBV25DLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxZQUFZLEVBQUVDLEtBQUssR0FBR0MsTUFBTSxFQUFFLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdJO0FBQUEsVUFBRSx1QkFBQyxhQUFVLE9BQU0sWUFBVyxNQUFLLFVBQVMsT0FBT0gsUUFBUSxVQUFVLENBQUFELE1BQUtvQyxVQUFVcEMsRUFBRUMsT0FBT0MsS0FBSyxHQUFHLFlBQVksRUFBRUMsS0FBS3FILEtBQUtDLElBQUksR0FBRzNLLE9BQU9vRixPQUFPLEtBQUssQ0FBQyxHQUFHOUIsTUFBTSxFQUFFLEdBQUcsT0FBT3RELE9BQU80SyxTQUFTNUssT0FBT21ELE1BQU0sQ0FBQyxLQUFLbkQsT0FBT21ELE1BQU0sSUFBSW5ELE9BQU9vRixPQUFPLEtBQTdPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStPO0FBQUEsVUFBRSx1QkFBQyxhQUFVLE9BQU0sZUFBYyxNQUFLLFVBQVMsT0FBT0csUUFBUSxVQUFVLENBQUFyQyxNQUFLc0MsVUFBVXRDLEVBQUVDLE9BQU9DLEtBQUssR0FBRyxZQUFZLEVBQUVDLEtBQUssR0FBR0MsTUFBTSxFQUFFLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNJO0FBQUEsYUFBOWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ2lCO0FBQUEsUUFBYSx1QkFBQyxhQUFVLE9BQU0sZUFBYyxRQUFNLE1BQUMsT0FBT21DLE1BQU0sVUFBVSxDQUFBdkMsTUFBSztBQUFFd0Msa0JBQVF4QyxFQUFFQyxPQUFPQyxLQUFvQjtBQUFHNEMsMEJBQWdCLEVBQUU7QUFBQSxRQUFHLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sZUFBYyxnQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxzQkFBcUIsc0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sYUFBWSx3Q0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxhQUF2VDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtVO0FBQUEsUUFBYVAsU0FBUyxlQUFlLG1DQUFFO0FBQUEsaUNBQUMsU0FBTSxVQUFTLFdBQVUsK0dBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlIO0FBQUEsVUFBUyxDQUFDWix5QkFBeUIsdUJBQUMsU0FBTSxVQUFTLFFBQU8sb0dBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJHO0FBQUEsVUFBVUEseUJBQXlCd0IsUUFBUXdDLGFBQWEsdUJBQUMsY0FBVyxNQUFLLFVBQVMsdURBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFBZWhFLHlCQUF5QndCLFFBQVFwQyxXQUFXLHVCQUFDLGNBQVcsTUFBSyxTQUFRLGNBQVcsNENBQTJDO0FBQUEsbUNBQUMsZUFBWSxPQUFPb0MsUUFBUXJELFNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFBRzJHLGVBQWV0RCxRQUFRckQsS0FBSyxLQUFLLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLG1CQUFLcUQsUUFBUXpHLFFBQVE7QUFBQSxZQUFHLEdBQUcsNENBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsZUFBbFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNFA7QUFBQSxVQUFlaUYseUJBQXlCLENBQUN3QixRQUFRd0MsYUFBYSxDQUFDeEMsUUFBUXBDLFdBQVdzRCxnQkFBZ0JzRCxXQUFXLEtBQUssdUJBQUMsY0FBVyxNQUFLLFVBQVMsOEVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFBZWhHLHlCQUF5QjBDLGdCQUFnQnNELFNBQVMsS0FBSyx1QkFBQyxhQUFVLE9BQU0sK0JBQThCLFFBQU0sTUFBQyxPQUFPaEYsUUFBUSxVQUFVLENBQUEzQyxNQUFLO0FBQUU0QyxzQkFBVTVDLEVBQUVDLE9BQU9DLEtBQUs7QUFBRzRDLDRCQUFnQixFQUFFO0FBQUEsVUFBRyxHQUFJdUIsMEJBQWdCM0QsSUFBSSxDQUFBRCxTQUFRLHVCQUFDLFlBQXVCLE9BQU9BLEtBQUs3RSxJQUFLNkU7QUFBQUEsaUJBQUs3RTtBQUFBQSxZQUFHO0FBQUEsWUFBSTZFLEtBQUs4RCxhQUFhakU7QUFBQUEsWUFBTztBQUFBLFlBQUVHLEtBQUs4RCxhQUFhckY7QUFBQUEsZUFBbkZ1QixLQUFLN0UsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkcsQ0FBVyxLQUE1UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4UjtBQUFBLFVBQWMrRix5QkFBeUIwQixZQUFZc0MsYUFBYSx1QkFBQyxjQUFXLE1BQUssVUFBUywwQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUFlaEUseUJBQXlCMEIsWUFBWXRDLFdBQVcsdUJBQUMsY0FBVyxNQUFLLFNBQVEsY0FBVyxnQ0FBK0I7QUFBQSxtQ0FBQyxlQUFZLE9BQU9zQyxZQUFZdkQsU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUFFLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLG1CQUFLdUQsWUFBWTNHLFFBQVE7QUFBQSxZQUFHLEdBQUcsZ0NBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsZUFBaE07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeU07QUFBQSxVQUFlaUYseUJBQXlCLENBQUMwQixZQUFZc0MsYUFBYSxDQUFDdEMsWUFBWXRDLFdBQVdtRSxvQkFBb0J5QyxXQUFXLEtBQUssdUJBQUMsY0FBVyxNQUFLLFVBQVMsc0dBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdIO0FBQUEsVUFBZXpDLG9CQUFvQnlDLFNBQVMsS0FBSyx1QkFBQyxhQUFVLE9BQU0sMEJBQXlCLFFBQU0sTUFBQyxPQUFPOUUsY0FBYyxVQUFVLENBQUE3QyxNQUFLOEMsZ0JBQWdCOUMsRUFBRUMsT0FBT0MsS0FBSyxHQUFJZ0YsOEJBQW9CeEUsSUFBSSxDQUFBeUUsVUFBUyx1QkFBQyxZQUF3QixPQUFPQSxNQUFNdkosSUFBS3VKO0FBQUFBLGtCQUFNdko7QUFBQUEsWUFBRztBQUFBLFlBQVd1SixNQUFNeUMsWUFBWXRIO0FBQUFBLFlBQU87QUFBQSxZQUFFNkUsTUFBTXlDLFlBQVkxSTtBQUFBQSxZQUFTO0FBQUEsWUFBWXhILFNBQVN5TixNQUFNRixXQUFXbE0sS0FBSytGLFFBQVE7QUFBQSxlQUF6SnFHLE1BQU12SixJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwSyxDQUFXLEtBQTdVO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStVO0FBQUEsVUFBYSx1QkFBQyxvQkFBaUIsT0FBTSxvREFBbUQsU0FBUyx1QkFBQyxZQUFTLFNBQVNtSCxTQUFTLFVBQVUsQ0FBQS9DLE1BQUtnRCxXQUFXaEQsRUFBRUMsT0FBTzRILE9BQU8sS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0UsS0FBNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0o7QUFBQSxhQUE3M0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnNEU7QUFBQSxRQUFJLHVCQUFDLG9CQUFpQixPQUFNLGVBQWMsU0FBUyx1QkFBQyxZQUFTLFNBQVNwRixTQUFTLFVBQVUsQ0FBQXpDLE1BQUswQyxXQUFXMUMsRUFBRUMsT0FBTzRILE9BQU8sS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RSxLQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsV0FBNzFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZzJKO0FBQUEsU0FWbHVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVK3VOO0FBQUEsT0F2Q3J1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNrdk47QUFDN3ZOO0FBQUMzRyxJQTVFZUQsbUJBQWlCO0FBQUEsVUFDWjVKLFVBQ0FqQixhQUNBQyxpQkFDR1csUUFDTkEsUUFDQ0MsYUFDR0EsYUFDQ0EsYUFFV0ssUUFDYkosWUFDQUEsWUFDRkEsWUFDQUEsWUFFVUksUUFFVE4sUUFDUUEsUUFDSkEsUUFJUUEsUUFHR0EsTUFBTTtBQUFBO0FBQUEsTUEzQnpCaUs7QUE2RWhCLFNBQVN3RixlQUFlM0csT0FBZ0I7QUFDcEMsU0FBTyxFQUFFQSxpQkFBaUIzSSxhQUFjMkksTUFBTW5HLFdBQVcsT0FBT21HLE1BQU1uRyxXQUFXO0FBQ3JGO0FBR0EsU0FBU21PLHFCQUFxQlQsVUFBa0IxRCxPQUFrQztBQUM5RSxRQUFNekQsUUFBUXBELE9BQU91SyxRQUFRO0FBQzdCLFNBQU8sQ0FBQyxDQUFDMUQsU0FBUzdHLE9BQU9DLFVBQVVtRCxLQUFLLEtBQUtBLFNBQVN5RCxNQUFNaEYsbUJBQW1CdUIsUUFBUXlELE1BQU0vRSxhQUFhO0FBQzlHO0FBRUEsU0FBU2lGLGVBQWVGLE9BQXNCO0FBQzFDLFNBQU8sQ0FBQ0EsTUFBTTlFLGNBQWNrRyxLQUFLQyxNQUFNckIsTUFBTTlFLFVBQVUsSUFBSWtHLEtBQUtLLElBQUk7QUFDeEU7QUFFTyxnQkFBUzJDLGdCQUFnQjtBQUFBQyxNQUFBO0FBQzVCLFFBQU0sRUFBRWpQLEtBQUssSUFBSTFCLFNBQVM7QUFDMUIsUUFBTSxDQUFDMkIsTUFBTSxJQUFJM0MsZ0JBQWdCO0FBQ2pDLFFBQU00QyxPQUFPakMsT0FBTyxzQkFBc0IsRUFBRWtDLE9BQU8sRUFBRUMsT0FBTyxJQUFJQyxRQUFRSixPQUFPSyxJQUFJLFFBQVEsS0FBS0MsT0FBVSxFQUFFLENBQUM7QUFDN0csUUFBTWdJLFlBQVlySyxZQUFZLGVBQWU7QUFDN0MsUUFBTXNDLFNBQVN0QyxZQUFZLG9CQUFvQjtBQUMvQyxRQUFNc0ssYUFBYXRLLFlBQVksa0JBQWtCLEVBQUVpQyxPQUFPLEVBQUVTLFFBQVEsVUFBVVIsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUMzRixRQUFNLENBQUNxSSxhQUFhQyxjQUFjLElBQUl4TCxTQUFTOEMsS0FBSzJJLGtCQUFrQjtBQUN0RSxRQUFNakksU0FBU3ZDLFdBQVcsdUJBQXVCLENBQUMsb0JBQW9CLENBQUM7QUFDdkUsUUFBTSxDQUFDZ0csTUFBTStLLE9BQU8sSUFBSWhTLFNBQVMsS0FBSyxHQUFHLENBQUNrSSxZQUFZK0osYUFBYSxJQUFJalMsU0FBUyxFQUFFLEdBQUcsQ0FBQ2tTLFNBQVNDLFVBQVUsSUFBSW5TLFNBQThCLENBQUMsRUFBRXlILEtBQUssR0FBRzhILGlCQUFpQixJQUFJNkIsVUFBVSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUNnQixhQUFhQyxjQUFjLElBQUlyUyxTQUFTLENBQUMsR0FBRyxDQUFDc1MsVUFBVUMsV0FBVyxJQUFJdlMsU0FBd0IsSUFBSSxHQUFHLENBQUN3UyxhQUFhQyxjQUFjLElBQUl6UyxTQUFxRDtBQUN6WCxRQUFNa08sbUJBQW1CN0MsVUFBVXJGLE1BQU1BLEtBQUtpQyxLQUFLLENBQUF1RixhQUFZQSxTQUFTN0gsT0FBT3VDLFVBQVU7QUFDekYsUUFBTXdLLGtCQUFrQnBQLE9BQU8wQyxNQUFNQSxLQUFLdUgsT0FBTyxDQUFBRyxVQUFTQSxNQUFNeEYsZUFBZUEsY0FBY3dGLE1BQU1qRixTQUFTUSxhQUFhaUYsa0JBQWtCakYsWUFBWTJFLGVBQWVGLEtBQUssQ0FBQyxLQUFLO0FBQ2pMLFFBQU1pRixZQUFZckgsV0FBV3RGLE1BQU1BLEtBQUtzRSxLQUFLLENBQUF1RixjQUFhQSxVQUFVbEssT0FBTzRGLFdBQVcsS0FBSyxDQUFDLENBQUMyQyxvQkFBb0JBLGlCQUFpQnhLLFdBQVcsY0FBY3dPLFFBQVFSLFNBQVMsS0FBS1EsUUFBUVUsTUFBTSxDQUFBQyxTQUFRaEIscUJBQXFCZ0IsS0FBS3pCLFVBQVVzQixnQkFBZ0J6SyxLQUFLLENBQUF5RixVQUFTQSxNQUFNL0gsT0FBT2tOLEtBQUt0RCxlQUFlLENBQUMsQ0FBQyxLQUFLLElBQUlqQyxJQUFJNEUsUUFBUXpILElBQUksQ0FBQW9JLFNBQVFBLEtBQUt0RCxlQUFlLENBQUMsRUFBRXVELFNBQVNaLFFBQVFSLFVBQVUsQ0FBQ2xPLE9BQU9zRjtBQUN2WSxRQUFNaUssZ0JBQWdCQSxNQUFNO0FBQ3hCZCxrQkFBYyxFQUFFO0FBQ2hCekcsbUJBQWUxSSxLQUFLMkksa0JBQWtCO0FBQ3RDMEcsZUFBVyxDQUFDLEVBQUUxSyxLQUFLLEdBQUc4SCxpQkFBaUIsSUFBSTZCLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDM0RpQixtQkFBZSxDQUFDO0FBQ2hCTCxZQUFRLElBQUk7QUFBQSxFQUNoQjtBQUNBLFFBQU1nQixpQkFBaUJBLENBQUNDLG1CQUEyQjtBQUMvQ2hCLGtCQUFjZ0IsY0FBYztBQUM1QmQsZUFBVyxDQUFDLEVBQUUxSyxLQUFLLEdBQUc4SCxpQkFBaUIsSUFBSTZCLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDM0RpQixtQkFBZSxDQUFDO0FBQUEsRUFDcEI7QUFDQSxRQUFNYSxjQUFjQSxDQUFDekwsS0FBYThILG9CQUE0QjtBQUMxRCxVQUFNN0IsUUFBUWdGLGdCQUFnQnpLLEtBQUssQ0FBQXVDLFNBQVFBLEtBQUs3RSxPQUFPNEosZUFBZTtBQUN0RSxVQUFNNkIsV0FBVzFELFFBQVF0RyxPQUFPbUssS0FBSzRCLEtBQUt6RixNQUFNaEYsa0JBQWtCZ0YsTUFBTS9FLFFBQVEsSUFBSStFLE1BQU0vRSxRQUFRLElBQUk7QUFDdEd3SixlQUFXLENBQUFoQixVQUFTQSxNQUFNMUcsSUFBSSxDQUFBb0ksU0FBUUEsS0FBS3BMLFFBQVFBLE1BQU0sRUFBRSxHQUFHb0wsTUFBTXRELGlCQUFpQjZCLFNBQVMsSUFBSXlCLElBQUksQ0FBQztBQUFBLEVBQzNHO0FBQ0EsUUFBTU8sU0FBUyxZQUFZO0FBQ3ZCLFFBQUksQ0FBQ1QsYUFBYSxDQUFDekUsaUJBQWtCO0FBQ3JDLFVBQU1pRCxRQUFRZSxRQUFRekgsSUFBSSxDQUFBb0ksU0FBUTtBQUM5QixZQUFNbkYsUUFBUWdGLGdCQUFnQnpLLEtBQUssQ0FBQXVDLFNBQVFBLEtBQUs3RSxPQUFPa04sS0FBS3RELGVBQWU7QUFDM0UsVUFBSSxDQUFDN0IsTUFBTyxPQUFNLElBQUkyRixNQUFNLGtFQUFrRTtBQUM5RixhQUFPLEVBQUU5SyxXQUFXbUYsTUFBTW5GLFdBQVdnSCxpQkFBaUI3QixNQUFNL0gsSUFBSXlMLFVBQVV2SyxPQUFPZ00sS0FBS3pCLFFBQVEsRUFBRTtBQUFBLElBQ3BHLENBQUM7QUFDRCxRQUFJO0FBQ0EsWUFBTWpJLFNBQVMsTUFBTTNGLE9BQU9nRyxRQUFRLEVBQUVSLE1BQU0sRUFBRWQsWUFBWWdHLGlCQUFpQnZJLElBQUk0RixhQUFhMkYsY0FBYyxNQUFNQyxNQUFNLEVBQUUsQ0FBQztBQUN6SHNCLHFCQUFlLENBQUFhLGNBQWEsRUFBRUMsT0FBTyxNQUFNQyxXQUFXRixVQUFVRSxZQUFZLEtBQUssRUFBRSxFQUFFO0FBQ3JGeEIsY0FBUSxLQUFLO0FBQ2JPLGtCQUFZcEosT0FBT25ELEtBQUtMLEVBQUU7QUFBQSxJQUM5QixRQUNNO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGdCQUFlLFVBQVMsa0dBQWlHLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUSxhQUFZLFNBQVNvTixlQUFlLDJCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNHLEtBQTFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNFE7QUFBQSxJQUFFLHVCQUFDLFNBQU0saUNBQUMsY0FBVyxPQUFPL1AsTUFBTSxnQkFBZSxXQUFXQSxlQUFLZ0QsUUFBUSxtQ0FBRTtBQUFBLDZCQUFDLGFBQVUsT0FBTSxnQkFBZSxNQUFNaEQsS0FBS2dELEtBQUtBLE1BQU0sUUFBUSxDQUFBb0MsTUFBS0EsRUFBRXpDLElBQUksU0FBUztBQUFBLFFBQzlhLEVBQUU4QixLQUFLLE1BQU1DLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQVMsTUFBSyx1QkFBQyxjQUFXLFlBQVlsSSxTQUFTMEgsV0FBV0MsV0FBV0MsUUFBU00sWUFBRXpDLE1BQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUUsRUFBYztBQUFBLFFBQUcsRUFBRThCLEtBQUssWUFBWUMsT0FBTyxnQkFBZ0JDLFFBQVFBLENBQUFTLE1BQUtpRCxVQUFVckYsTUFBTUEsS0FBS2lDLEtBQUssQ0FBQWYsTUFBS0EsRUFBRXZCLE9BQU95QyxFQUFFRixVQUFVLEdBQUdwRSxRQUFRLG9CQUFvQnNFLEVBQUVGLFVBQVUsR0FBRztBQUFBLFFBQUcsRUFBRVQsS0FBSyxTQUFTQyxPQUFPLGdCQUFnQkMsUUFBUUEsQ0FBQVMsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVxTCxTQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCLEVBQUc7QUFBQSxRQUFHLEVBQUVoTSxLQUFLLFVBQVVDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQVMsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUUxRSxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCLEVBQUc7QUFBQSxRQUFHLEVBQUUrRCxLQUFLLE9BQU9DLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQVMsTUFBS0EsRUFBRXNMLHFCQUFxQixXQUFXO0FBQUEsUUFBRyxFQUFFak0sS0FBSyxVQUFVQyxPQUFPLElBQUlDLFFBQVFBLENBQUFTLE1BQUssdUJBQUMsVUFBTyxTQUFTLE1BQU1tSyxZQUFZbkssRUFBRXpDLEVBQUUsR0FBRyw0QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRCxFQUFVO0FBQUEsTUFBQyxLQURuUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTlWO0FBQUEsTUFBRSx1QkFBQyxTQUFNLE1BQU0zQyxLQUFLZ0QsS0FBSytCLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQUY4VDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRTVULEtBRjRQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFeFAsS0FGaVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVwTztBQUFBLElBQ25ELHVCQUFDLGNBQVcsTUFBWSxPQUFNLGVBQWMsU0FBUyxNQUFNaUssUUFBUSxLQUFLLEdBQUcsTUFBTXhPLE9BQU9zRixTQUFTLGFBQTBCLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDNkosV0FBVyxTQUFTLE1BQU0sS0FBS1MsT0FBTyxHQUFHLDRCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRGLEdBQzVOO0FBQUEsNkJBQUMsZUFBWSxPQUFPNVAsT0FBT3FHLFNBQVN5QixXQUFXekIsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQUUsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0saUJBQWdCLE9BQU8wQixhQUFhLFVBQVUsQ0FBQThGLFVBQVM3RixlQUFlNkYsTUFBTXJILE9BQU9DLEtBQUssR0FBRyxVQUFVekcsT0FBT3NGLFNBQVV5QztBQUFBQSx5QkFBZSxDQUFDRCxXQUFXdEYsTUFBTUEsS0FBS3NFLEtBQUssQ0FBQXVGLGNBQWFBLFVBQVVsSyxPQUFPNEYsV0FBVyxLQUFLLHVCQUFDLFlBQVMsT0FBT0EsYUFBYTtBQUFBO0FBQUEsWUFBY0E7QUFBQUEsWUFBWTtBQUFBLGVBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsVUFBYUQsV0FBV3RGLE1BQU1BLEtBQUt5RSxJQUFJLENBQUFvRixjQUFhLHVCQUFDLFlBQTRCLE9BQU9BLFVBQVVsSyxJQUFLa0s7QUFBQUEsc0JBQVV5QjtBQUFBQSxZQUFLO0FBQUEsWUFBSXpCLFVBQVUvTDtBQUFBQSxlQUFqRStMLFVBQVVsSyxJQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRixDQUFXO0FBQUEsYUFBN2M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErYztBQUFBLFFBQVksdUJBQUMsa0JBQWUsT0FBTSxpQkFBZ0IsYUFBYTJGLFdBQVdaLGFBQWEsU0FBU1ksV0FBV1gsU0FBUyxNQUFNVyxXQUFXVixlQUFlLFlBQVlVLFdBQVdULFlBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0s7QUFBQSxRQUNuc0IsdUJBQUMsYUFBVSxPQUFNLHlCQUF3QixRQUFNLE1BQUMsT0FBTzNDLFlBQVksVUFBVSxDQUFBbUosVUFBUzJCLGVBQWUzQixNQUFNckgsT0FBT0MsS0FBSyxHQUFJL0I7QUFBQUEsd0JBQWMsQ0FBQ21ELFVBQVVyRixNQUFNQSxLQUFLc0UsS0FBSyxDQUFBa0QsYUFBWUEsU0FBUzdILE9BQU91QyxVQUFVLEtBQUssdUJBQUMsWUFBUyxPQUFPQSxZQUFhQSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUFhbUQsVUFBVXJGLE1BQU1BLEtBQUt1SCxPQUFPLENBQUFDLGFBQVlBLFNBQVM5SixXQUFXLFVBQVUsRUFBRStHLElBQUksQ0FBQStDLGFBQVksdUJBQUMsWUFBMkIsT0FBT0EsU0FBUzdILElBQUs2SCxtQkFBUzFKLFFBQTNDMEosU0FBUzdILElBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStELENBQVc7QUFBQSxhQUF2YTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlhO0FBQUEsUUFDemEsdUJBQUMsa0JBQWUsT0FBTSxnQkFBZSxhQUFhMEYsVUFBVVgsYUFBYSxTQUFTVyxVQUFVVixTQUFTLE1BQU1VLFVBQVVULGVBQWUsWUFBWVMsVUFBVVIsWUFBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSztBQUFBLFFBQ2xLUSxVQUFVUCxXQUFXLHVCQUFDLGNBQVk7QUFBQSxpQ0FBQyxlQUFZLE9BQU9PLFVBQVV4QixTQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQUUsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsa0JBQU13QixVQUFVTix1QkFBdUJNLFVBQVVSLFNBQVMsSUFBSVEsVUFBVTVFLFFBQVE7QUFBQSxVQUFJLEdBQUcsOENBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJKO0FBQUEsYUFBOU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TjtBQUFBLFFBQzVPLENBQUM0RSxVQUFVckYsTUFBTUEsS0FBS3NFLEtBQUssQ0FBQWtELGFBQVlBLFNBQVM5SixXQUFXLFVBQVUsS0FBSyx1QkFBQyxTQUFNLFVBQVUySCxVQUFVVixVQUFVLFNBQVMsV0FBWVUsb0JBQVVWLFVBQVUsNkZBQTZGLGlEQUEzSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlOO0FBQUEsUUFDblN1SCxRQUFRekgsSUFBSSxDQUFDb0ksTUFBTWMsVUFBVTtBQUMxQixnQkFBTUMsWUFBWWxCLGdCQUFnQnpLLEtBQUssQ0FBQXlGLFVBQVNBLE1BQU0vSCxPQUFPa04sS0FBS3RELGVBQWU7QUFDakYsZ0JBQU1zRSxVQUFVbkIsZ0JBQWdCbkYsT0FBTyxDQUFBRyxVQUFTLENBQUN3RSxRQUFRNUgsS0FBSyxDQUFBd0osVUFBU0EsTUFBTXJNLFFBQVFvTCxLQUFLcEwsT0FBT3FNLE1BQU12RSxvQkFBb0I3QixNQUFNL0gsRUFBRSxDQUFDO0FBQ3BJLGlCQUFPLHVCQUFDLGNBQTBCLFVBQVMsWUFDdkM7QUFBQSxtQ0FBQyxjQUFXLFdBQVcsRUFBRTJLLElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFQSxJQUFJLFNBQVMsR0FBRyxnQkFBZSxpQkFDN0Y7QUFBQSxxQ0FBQyxjQUFXLFlBQVlyUSxTQUFTMEgsV0FBV0MsV0FBV0MsUUFBUTtBQUFBO0FBQUEsZ0JBQVc2TCxRQUFRO0FBQUEsbUJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsY0FDbkZ6QixRQUFRUixTQUFTLEtBQUssdUJBQUMsVUFBTyxPQUFNLFdBQVUsU0FBUyxNQUFNUyxXQUFXLENBQUFoQixVQUFTQSxNQUFNNUQsT0FBTyxDQUFBL0MsU0FBUUEsS0FBSy9DLFFBQVFvTCxLQUFLcEwsR0FBRyxDQUFDLEdBQUc7QUFBQTtBQUFBLGdCQUFVa00sUUFBUTtBQUFBLG1CQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2SDtBQUFBLGlCQUZ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxjQUFXLFdBQVcsRUFBRXJELElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQzdDO0FBQUEscUNBQUMsYUFBVSxXQUFTLE1BQUMsT0FBTyxnQkFBZ0JvRCxRQUFRLENBQUMsSUFBSSxRQUFNLE1BQUMsT0FBT2QsS0FBS3RELGlCQUFpQixVQUFVLENBQUE4QixVQUFTNkIsWUFBWUwsS0FBS3BMLEtBQUs0SixNQUFNckgsT0FBT0MsS0FBSyxHQUNuSjRKLGtCQUFRcEosSUFBSSxDQUFBaUQsVUFBUyx1QkFBQyxZQUF3QixPQUFPQSxNQUFNL0gsSUFBSytIO0FBQUFBLHNCQUFNbkY7QUFBQUEsZ0JBQVU7QUFBQSxnQkFBSW1GLE1BQU1qRixTQUFTNEI7QUFBQUEsZ0JBQU87QUFBQSxnQkFBRXFELE1BQU1qRixTQUFTUTtBQUFBQSxnQkFBUztBQUFBLGdCQUFReUUsTUFBTWhGO0FBQUFBLGdCQUFnQjtBQUFBLGdCQUFhZ0YsTUFBTS9FO0FBQUFBLG1CQUFqSitFLE1BQU0vSCxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5SyxDQUFXLEtBRDlNO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLGFBQVUsT0FBTyxpQkFBaUJnTyxRQUFRLENBQUMsSUFBSSxNQUFLLFVBQVMsT0FBT2QsS0FBS3pCLFVBQVUsVUFBVSxDQUFBQyxVQUFTYyxXQUFXLENBQUFoQixVQUFTQSxNQUFNMUcsSUFBSSxDQUFBRCxTQUFRQSxLQUFLL0MsUUFBUW9MLEtBQUtwTCxNQUFNLEVBQUUsR0FBRytDLE1BQU00RyxVQUFVQyxNQUFNckgsT0FBT0MsTUFBTSxJQUFJTyxJQUFJLENBQUMsR0FBRyxZQUFZLEVBQUVOLEtBQUswSixXQUFXbEwsbUJBQW1CLEdBQUd5QixNQUFNeUosV0FBV2pMLFlBQVksRUFBRSxHQUFHLE9BQU8sQ0FBQyxDQUFDaUwsYUFBYSxDQUFDLENBQUNmLEtBQUt6QixZQUFZLENBQUNTLHFCQUFxQmdCLEtBQUt6QixVQUFVd0MsU0FBUyxHQUFHLFlBQVlBLFlBQVksd0JBQXdCQSxVQUFVbEwsZUFBZSxjQUFja0wsVUFBVWpMLFFBQVEsTUFBTSxxQ0FBeGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMGhCO0FBQUEsaUJBSjloQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFWb0JrSyxLQUFLcEwsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXUDtBQUFBLFFBQ0osQ0FBQztBQUFBLFFBQ0QsdUJBQUMsa0JBQWUsT0FBTSxXQUFVLGFBQWFuRSxPQUFPb0gsYUFBYSxTQUFTcEgsT0FBT3FILFNBQVMsTUFBTXJILE9BQU9zSCxlQUFlLFlBQVl0SCxPQUFPdUgsWUFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSjtBQUFBLFFBQ2pKdkgsT0FBT3dILFdBQVcsdUJBQUMsY0FBWTtBQUFBLGlDQUFDLGVBQVksT0FBT3hILE9BQU91RyxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLFVBQUUsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsa0JBQU12RyxPQUFPeUgsdUJBQXVCekgsT0FBT3VILFNBQVMsSUFBSXZILE9BQU9tRCxRQUFRO0FBQUEsVUFBSSxHQUFHLHlDQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2STtBQUFBLGFBQTdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc007QUFBQSxRQUN4Tm5ELE9BQU9xSCxXQUFXLHVCQUFDLFNBQU0sVUFBUyxRQUFPO0FBQUE7QUFBQSxVQUF1QnJILE9BQU9vSDtBQUFBQSxVQUFZO0FBQUEsYUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSTtBQUFBLFFBQ3BKLHVCQUFDLFVBQU8sVUFBVSxDQUFDeEMsY0FBYyxDQUFDd0ssZ0JBQWdCcEksS0FBSyxDQUFBb0QsVUFBUyxDQUFDd0UsUUFBUTVILEtBQUssQ0FBQXVJLFNBQVFBLEtBQUt0RCxvQkFBb0I3QixNQUFNL0gsRUFBRSxDQUFDLEdBQUcsU0FBUyxNQUFNO0FBQUV3TSxxQkFBVyxDQUFBaEIsVUFBUyxDQUFDLEdBQUdBLE9BQU8sRUFBRTFKLEtBQUsySyxhQUFhN0MsaUJBQWlCLElBQUk2QixVQUFVLElBQUksQ0FBQyxDQUFDO0FBQUdpQix5QkFBZSxDQUFBNUssUUFBT0EsTUFBTSxDQUFDO0FBQUEsUUFBRyxHQUFHLDhCQUExUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdSO0FBQUEsUUFDeFIsdUJBQUMsU0FBTSxVQUFTLFFBQU8sd0hBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0g7QUFBQSxXQXpCNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCdkQ7QUFBQSxTQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFBYzZLLFlBQVksdUJBQUMsa0JBQWUsWUFBWUEsVUFBVSxTQUFTLE1BQU1DLFlBQVksSUFBSSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVFO0FBQUEsT0EvQjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQjZGO0FBQ3hHO0FBQUNSLElBN0VlRCxlQUFhO0FBQUEsVUFDUjFRLFVBQ0FoQixpQkFDSlcsUUFDS0MsYUFDSEEsYUFDSUEsYUFFSkMsVUFBVTtBQUFBO0FBQUEsTUFSYjZRO0FBOEVoQixTQUFTaUMsZUFBZTtBQUFBLEVBQUVqTztBQUFBQSxFQUFZa087QUFHdEMsR0FBRztBQUFBQyxNQUFBO0FBQ0MsUUFBTSxFQUFFblIsS0FBSyxJQUFJMUIsU0FBUztBQUMxQixRQUFNZ0MsTUFBTXJDLE9BQU8sb0JBQW9CLEVBQUU4RSxNQUFNLEVBQUVDLFdBQVcsRUFBRSxDQUFDO0FBQy9ELFFBQU1zQyxJQUFJaEYsSUFBSTRDLE1BQU1BO0FBQ3BCLFFBQU0wSSxXQUFXek4sV0FBVywyQkFBMkIsQ0FBQyxvQkFBb0Isc0JBQXNCLGVBQWUsQ0FBQztBQUNsSCxRQUFNaVQsT0FBT2pULFdBQVcscUJBQXFCLENBQUMsb0JBQW9CLHNCQUFzQixlQUFlLENBQUM7QUFDeEcsUUFBTWtULFVBQVVsVCxXQUFXLHdCQUF3QixDQUFDLG9CQUFvQixvQkFBb0IsQ0FBQztBQUM3RixRQUFNbVQsU0FBU25ULFdBQVcsdUJBQXVCLENBQUMsb0JBQW9CLHNCQUFzQix5QkFBeUIsQ0FBQztBQUN0SCxRQUFNLENBQUNvVCxRQUFRQyxTQUFTLElBQUl0VSxTQUErQyxJQUFJLEdBQUcsQ0FBQ3VVLFVBQVVDLFdBQVcsSUFBSXhVLFNBQVMsRUFBRSxHQUFHLENBQUN5VSxPQUFPQyxRQUFRLElBQUkxVSxTQUFTLEVBQUUsR0FBRyxDQUFDd1MsYUFBYUMsY0FBYyxJQUFJelMsU0FBcUQ7QUFDalAsUUFBTTJVLGlCQUFpQjFVLHFCQUFxQjBCLGtCQUFrQkQsZ0JBQWdCQSxjQUFjLEVBQUU0SSxLQUFLLENBQUFzSyxXQUFVQSxPQUFPQyxXQUFXL1IsS0FBSzZDLE1BQU1pUCxPQUFPRSxjQUFjLG1CQUFtQjtBQUNsTCxRQUFNQyxlQUFlLFlBQVk7QUFDN0IsUUFBSTtBQUNBLGFBQU8sTUFBTWIsS0FBSzFLLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsV0FBVyxHQUFHa0QsTUFBTSxFQUFFVSxpQkFBaUJ0QixHQUFHcUIsV0FBVyxHQUFHOEUsWUFBWW5HLEdBQUdtRyxjQUFjLElBQUl5RyxZQUFZNU0sR0FBRzRNLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxJQUNwSyxTQUNPbkwsT0FBTztBQUNWLFVBQUlBLGlCQUFpQjFJLG1CQUFvQm1ULFdBQVUsSUFBSTtBQUN2RCxZQUFNeks7QUFBQUEsSUFDVjtBQUFBLEVBQ0o7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxNQUFJLE1BQUMsT0FBTyxXQUFXL0QsVUFBVSxJQUFJLFNBQWtCLFNBQVMsdUJBQUMsVUFBTyxTQUFTa08sU0FBUyxvQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QixHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPdEYsU0FBUzdFLFNBQVNxSyxLQUFLckssU0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPekcsS0FBTWdGLGVBQUssdUJBQUMsY0FBWTtBQUFBLCtCQUFDLFVBQU8sT0FBT0EsRUFBRTFFLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUFFLHVCQUFDLGNBQVcsT0FBTSxnQkFBZTtBQUFBO0FBQUEsVUFBa0IwRSxFQUFFRjtBQUFBQSxhQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFBYSx1QkFBQyxjQUFXLE9BQU0sZ0JBQWUsaUNBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT0UsRUFBRXFMLFNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQWEsdUJBQUMsYUFBVSxPQUFNLDBCQUF5QixNQUFNckwsRUFBRStJLE9BQU8sUUFBUSxDQUFBOEQsTUFBS0EsRUFBRXRQLElBQUksU0FBUztBQUFBLFVBQ2hlLEVBQUU4QixLQUFLLE9BQU9DLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQXNOLE1BQUtBLEVBQUUxTSxVQUFVO0FBQUEsVUFBRyxFQUFFZCxLQUFLLE9BQU9DLE9BQU8sT0FBT0MsUUFBUUEsQ0FBQXNOLE1BQUtBLEVBQUU3RCxTQUFTO0FBQUEsVUFBRyxFQUFFM0osS0FBSyxZQUFZQyxPQUFPLFdBQVdDLFFBQVFBLENBQUFzTixNQUFLQSxFQUFFQyxpQkFBaUI7QUFBQSxVQUFHLEVBQUV6TixLQUFLLFFBQVFDLE9BQU8sV0FBV0MsUUFBUUEsQ0FBQXNOLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFeE0sWUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsRUFBRztBQUFBLFFBQUMsS0FEbUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUU3WTtBQUFBLFFBQUUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsSUFBSSxFQUFFME0sY0FBYyxXQUFXLEdBQUc7QUFBQTtBQUFBLFVBQWdCL00sRUFBRTRNO0FBQUFBLGFBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUFhLHVCQUFDLGNBQVcsV0FBVSxPQUFPLFVBQVMsUUFBTztBQUFBLGlDQUFDLGtCQUFlLFlBQVcscUJBQW9CLGdCQUFnQjVNLEVBQUVnTixnQkFBZ0IsUUFBTyxvQkFBbUIsTUFBTTFHLFNBQVM1RixTQUFTLFNBQVMsTUFBTSxLQUFLNEYsU0FBU2xGLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsV0FBVyxHQUFHa0QsTUFBTSxFQUFFVSxpQkFBaUJ0QixFQUFFcUIsUUFBUSxFQUFFLENBQUMsRUFBRTBHLE1BQU0sTUFBTTlNLE1BQVMsR0FBRyw2QkFBaFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlE7QUFBQSxVQUFpQix1QkFBQyxrQkFBZSxZQUFXLG9CQUFtQixnQkFBZ0IrRSxFQUFFZ04sZ0JBQWdCLFFBQU8sUUFBTyxTQUFRLGFBQVksVUFBVVQsZ0JBQWdCLFNBQVMsTUFBTUwsVUFBVSxNQUFNLEdBQUcsMkJBQTlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlMO0FBQUEsVUFBaUIsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsZ0JBQWdCbE0sRUFBRWdOLGdCQUFnQixRQUFPLFdBQVUsU0FBUyxNQUFNZCxVQUFVLFNBQVMsR0FBRyx3Q0FBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0o7QUFBQSxVQUFpQix1QkFBQyxrQkFBZSxZQUFXLHFCQUFvQixnQkFBZ0JsTSxFQUFFZ04sZ0JBQWdCLFFBQU8sVUFBUyxPQUFNLFNBQVEsU0FBUyxNQUFNZCxVQUFVLFFBQVEsR0FBRyx1QkFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEo7QUFBQSxhQUEvMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnM0I7QUFBQSxRQUFjbE0sRUFBRW1HLGNBQWMsdUJBQUMsYUFBVSxJQUFJLE1BQU16TCxLQUFLNkMsRUFBRSxjQUFjO0FBQUE7QUFBQSxVQUFleUMsRUFBRW1HO0FBQUFBLGFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUFjLENBQUMsYUFBYSxlQUFlLEVBQUU4RyxTQUFTak4sRUFBRTFFLE1BQU0sS0FBSyx1QkFBQyxhQUFVLElBQUksTUFBTVosS0FBSzZDLEVBQUUsNkJBQTZCeUMsRUFBRXpDLEVBQUUsSUFBSSxzQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFNBQWV5QyxFQUFFMUUsV0FBVyxhQUFhaVIsbUJBQW1CLHVCQUFDLFNBQU0sVUFBUyxXQUFVLDBHQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9IO0FBQUEsV0FGN3JDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFc3NDLEtBRnB1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWt2QztBQUFBLFNBRjE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXU2QztBQUFBLElBQ243Qyx1QkFBQyxpQkFBYyxNQUFNTixXQUFXLFVBQVUsQ0FBQ00sZ0JBQWdCLE9BQU0sd0JBQXVCLGNBQWEsZUFBYyxhQUFhLFdBQVd2TSxHQUFHekMsTUFBTUcsVUFBVSxNQUFNc0MsR0FBR3FMLE1BQU1wSixVQUFVLEVBQUUsSUFBSWpDLEdBQUdxTCxNQUFNeEssWUFBWSxFQUFFLHNEQUFzRGIsR0FBR0YsY0FBYyxFQUFFLDhFQUE4RSxTQUFTLE1BQU1vTSxVQUFVLElBQUksR0FBRyxPQUFPSixLQUFLckssT0FBTyxNQUFNcUssS0FBS3BMLFNBQVMsV0FBV2lNLGdCQUE3YjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBjO0FBQUEsSUFBRSx1QkFBQyxpQkFBYyxNQUFNVixXQUFXLFVBQVUsT0FBTSxlQUFjLGNBQWEsZUFBYyxhQUFhLFdBQVdqTSxHQUFHekMsTUFBTUcsVUFBVSxzSEFBc0gsZUFBYSxNQUFDLFNBQVMsTUFBTXdPLFVBQVUsSUFBSSxHQUFHLE9BQU9GLE9BQU92SyxPQUFPLE1BQU11SyxPQUFPdEwsU0FBUyxXQUFXLENBQUFoRSxXQUFVc1AsT0FBTzVLLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsV0FBVyxHQUFHa0QsTUFBTSxFQUFFVSxpQkFBaUJ0QixHQUFHcUIsV0FBVyxHQUFHM0UsT0FBTyxFQUFFLENBQUMsS0FBbmM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxYztBQUFBLElBQ2o1Qix1QkFBQyxjQUFXLE1BQU11UCxXQUFXLFdBQVcsT0FBTSxzQ0FBcUMsU0FBUyxNQUFNQyxVQUFVLElBQUksR0FBRyxNQUFNSCxRQUFRckwsU0FBUyxhQUEwQixTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQ3lMLFlBQVksQ0FBQ0UsU0FBU04sUUFBUXJMLFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUMvUSxjQUFNcUwsUUFBUTNLLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsV0FBVyxHQUFHa0QsTUFBTSxFQUFFVSxpQkFBaUJ0QixHQUFHcUIsV0FBVyxHQUFHaUssbUJBQW1CYSxVQUFVZSx5QkFBeUJiLE1BQU0sRUFBRSxDQUFDO0FBQ3ZKaEMsdUJBQWUsQ0FBQWEsY0FBYSxFQUFFQyxPQUFPLE1BQU1DLFdBQVdGLFVBQVVFLFlBQVksS0FBSyxFQUFFLEVBQUU7QUFDckZjLGtCQUFVLElBQUk7QUFBQSxNQUNsQixRQUNNO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsNEJBTCtJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLbkksR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT0gsUUFBUXRLLFNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUFFLHVCQUFDLGNBQVk7QUFBQSwrQkFBQyxhQUFVLE9BQU0sb0NBQW1DLE9BQU8wSyxVQUFVLFVBQVUsQ0FBQXhLLE1BQUt5SyxZQUFZekssRUFBRUMsT0FBT0MsS0FBSyxLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdIO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sMEJBQXlCLE9BQU93SyxPQUFPLFVBQVUsQ0FBQTFLLE1BQUsySyxTQUFTM0ssRUFBRUMsT0FBT0MsS0FBSyxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdHO0FBQUEsV0FBL047QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpTztBQUFBLFNBTDFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLdVU7QUFBQSxPQVQ3VDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUzBVO0FBQ3JWO0FBQUNnSyxJQWhDUUYsZ0JBQWM7QUFBQSxVQUlGM1MsVUFDTEwsUUFFS0UsWUFDSkEsWUFDR0EsWUFDREEsVUFBVTtBQUFBO0FBQUEsTUFWcEI4UztBQWlDRixnQkFBU3dCLGVBQWU7QUFBQUMsTUFBQTtBQUMzQixRQUFNLENBQUNDLFlBQVksSUFBSXJWLGdCQUFnQjtBQUN2QyxRQUFNNEMsT0FBT2pDLE9BQU8scUJBQXFCLEVBQUVrQyxPQUFPM0IsYUFBYSxtQkFBbUIsRUFBRSxDQUFDO0FBQ3JGLFFBQU1vVSxTQUFTMVUsWUFBWSxvQkFBb0I7QUFDL0MsUUFBTSxDQUFDaUcsTUFBTStLLE9BQU8sSUFBSWhTLFNBQVMsS0FBSyxHQUFHLENBQUMyVixTQUFTQyxVQUFVLElBQUk1VixTQUFTLE1BQU15VixhQUFhclMsSUFBSSxpQkFBaUIsS0FBSyxFQUFFLEdBQUcsQ0FBQ3lTLFVBQVVDLFdBQVcsSUFBSTlWLFNBQVMsRUFBRSxHQUFHLENBQUMrVixZQUFZQyxhQUFhLElBQUloVyxTQUFpRixDQUFDLENBQUMsR0FBRyxDQUFDaVcsWUFBWUMsYUFBYSxJQUFJbFcsU0FBd0IsSUFBSSxHQUFHLENBQUNtVyxhQUFhQyxjQUFjLElBQUlwVyxTQUFTLEtBQUs7QUFDblksUUFBTXFXLGdCQUFnQnRWLE9BQU8sb0JBQW9CLEVBQUU4RSxNQUFNLEVBQUVDLFlBQVk2UCxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU87QUFDN0YsUUFBTVcsUUFBUUQsY0FBY3JRLE1BQU1BO0FBQ2xDLFFBQU11USxnQkFBZ0J4VixPQUFPLG1CQUFtQixFQUFFOEUsTUFBTSxFQUFFQyxZQUFZbVEsY0FBYyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUNBLFVBQVU7QUFDeEcsUUFBTU8sVUFBb0NELGNBQWN2USxNQUFNQTtBQUM5RCxRQUFNeEMsU0FBU3ZDLFdBQVcsc0JBQXNCLENBQUMsbUJBQW1CLENBQUM7QUFDckUsUUFBTXdWLE9BQU94VixXQUFXLG9CQUFvQixDQUFDLG1CQUFtQixvQkFBb0IscUJBQXFCLHNCQUFzQixzQkFBc0IsaUJBQWlCLGNBQWMsQ0FBQztBQUNyTCxRQUFNeVYsZUFBZUosT0FBT25GLE1BQU1oSixRQUFRLENBQUEwSyxTQUFRO0FBQzlDLFVBQU04RCxRQUFRWixXQUFXbEQsS0FBS2xOLEVBQUUsS0FBSyxFQUFFaVIsVUFBVSxLQUFLQyxVQUFVLEtBQUsvUixRQUFRLEdBQUc7QUFDaEYsVUFBTThSLFdBQVcvUCxPQUFPOFAsTUFBTUMsWUFBWSxDQUFDLEdBQUdDLFdBQVdoUSxPQUFPOFAsTUFBTUUsWUFBWSxDQUFDO0FBQ25GLFdBQU9ELFdBQVdDLFdBQVcsSUFBSSxDQUFDLEVBQUVDLGdCQUFnQmpFLEtBQUtsTixJQUFJb1Isa0JBQWtCSCxVQUFVSSxrQkFBa0JILFVBQVUvUixRQUFRNlIsTUFBTTdSLE9BQU84QixLQUFLLEVBQUUsQ0FBQyxJQUFJO0FBQUEsRUFDMUosQ0FBQyxLQUFLO0FBQ04sUUFBTXFRLG9CQUFvQixDQUFDLENBQUNYLFNBQVNJLGFBQWFoRixTQUFTLEtBQUtnRixhQUFhOUQsTUFBTSxDQUFBK0QsVUFBUztBQUN4RixVQUFNTyxXQUFXWixNQUFNbkYsTUFBTWxKLEtBQUssQ0FBQTRLLFNBQVFBLEtBQUtsTixPQUFPZ1IsTUFBTUcsY0FBYztBQUMxRSxVQUFNSyxZQUFZRCxXQUFXQSxTQUFTOUYsV0FBVzhGLFNBQVNoQyxtQkFBbUJnQyxTQUFTRixtQkFBbUI7QUFDekcsV0FBT25RLE9BQU9DLFVBQVU2UCxNQUFNSSxnQkFBZ0IsS0FBS0osTUFBTUksb0JBQW9CLEtBQUtsUSxPQUFPQyxVQUFVNlAsTUFBTUssZ0JBQWdCLEtBQUtMLE1BQU1LLG9CQUFvQixLQUFLTCxNQUFNSSxtQkFBbUJKLE1BQU1LLG9CQUFvQkcsY0FBY1IsTUFBTUsscUJBQXFCLEtBQUssQ0FBQyxDQUFDTCxNQUFNN1IsV0FBV3RELGdCQUFnQm1WLE1BQU03UixNQUFNLEtBQUs7QUFBQSxFQUN0VCxDQUFDO0FBQ0QsUUFBTXNTLGNBQWMsQ0FBQyxDQUFDZCxTQUFTLENBQUMsYUFBYSxlQUFlLEVBQUVqQixTQUFTaUIsTUFBTTVTLE1BQU0sS0FBS21TLFNBQVNqUCxLQUFLLEVBQUU4SyxTQUFTLEtBQUtsUSxnQkFBZ0JxVSxTQUFTalAsS0FBSyxDQUFDLEtBQUssT0FBT3FRLHFCQUFxQixDQUFDelQsT0FBT3NGO0FBQzlMLFFBQU11TyxnQkFBZ0IsWUFBWTtBQUM5QixRQUFJLENBQUNELGVBQWUsQ0FBQ2QsTUFBTztBQUM1QixRQUFJO0FBQ0EsWUFBTTlTLE9BQU9nRyxRQUFRLEVBQUVSLE1BQU0sRUFBRXNPLGlCQUFpQmhCLE1BQU0zUSxJQUFJNFIseUJBQXlCakIsTUFBTTdNLFNBQVMrTixtQkFBbUIzQixTQUFTalAsS0FBSyxHQUFHdUssT0FBT3VGLGFBQWEsRUFBRSxDQUFDO0FBQzdKMUUsY0FBUSxLQUFLO0FBQ2I0RCxpQkFBVyxFQUFFO0FBQ2JFLGtCQUFZLEVBQUU7QUFDZEUsb0JBQWMsQ0FBQyxDQUFDO0FBQUEsSUFDcEIsUUFDTTtBQUFBLElBQUU7QUFBQSxFQUNaO0FBQ0EsUUFBTXlCLGNBQWMsWUFBWTtBQUM1QixRQUFJLENBQUNqQixXQUFXQSxRQUFROVMsV0FBVyxRQUFTO0FBQzVDLFFBQUk7QUFDQSxZQUFNK1MsS0FBS2pOLFFBQVEsRUFBRTNELE1BQU0sRUFBRUMsWUFBWTBRLFFBQVE3USxHQUFHLEdBQUdxRCxNQUFNLEVBQUVVLGlCQUFpQjhNLFFBQVEvTSxRQUFRLEVBQUUsQ0FBQztBQUNuRzJNLHFCQUFlLEtBQUs7QUFBQSxJQUN4QixRQUNNO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGFBQVksVUFBUyxxRkFBb0YsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLHFCQUFvQixTQUFRLGFBQVksU0FBUyxNQUFNO0FBQUVSLGlCQUFXSCxhQUFhclMsSUFBSSxpQkFBaUIsS0FBSyxFQUFFO0FBQUcwUyxrQkFBWSxFQUFFO0FBQUdFLG9CQUFjLENBQUMsQ0FBQztBQUFHaEUsY0FBUSxJQUFJO0FBQUEsSUFBRyxHQUFHLDhCQUFqTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStNLEtBQW5WO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcVc7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBT2hQLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2dELFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sbUJBQWtCLE1BQU1oRCxLQUFLZ0QsS0FBS0EsTUFBTSxRQUFRLENBQUE4SixNQUFLQSxFQUFFbkssSUFBSSxTQUFTO0FBQUEsVUFDbmpCLEVBQUU4QixLQUFLLE1BQU1DLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQW1JLE1BQUtBLEVBQUVuSyxHQUFHO0FBQUEsVUFBRyxFQUFFOEIsS0FBSyxNQUFNQyxPQUFPLFdBQVdDLFFBQVFBLENBQUFtSSxNQUFLQSxFQUFFd0gsZ0JBQWdCO0FBQUEsVUFBRyxFQUFFN1AsS0FBSyxVQUFVQyxPQUFPLGtCQUFrQkMsUUFBUUEsQ0FBQW1JLE1BQUtBLEVBQUUwSCxrQkFBa0I7QUFBQSxVQUFHLEVBQUUvUCxLQUFLLFNBQVNDLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQW1JLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFcE0sVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsRUFBRztBQUFBLFVBQ25SO0FBQUEsWUFDSStELEtBQUs7QUFBQSxZQUFVQyxPQUFPO0FBQUEsWUFBSUMsUUFBUUEsQ0FBQW1JLE1BQUssdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsVUFBVUEsRUFBRXBNLFdBQVcsU0FBUyxTQUFTLE1BQU07QUFBRTBTLDZCQUFlLEtBQUs7QUFBR0YsNEJBQWNwRyxFQUFFbkssRUFBRTtBQUFBLFlBQUcsR0FBRyxvQ0FBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUs7QUFBQSxVQUNoTjtBQUFBLFFBQUMsS0FKNmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtoZTtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNM0MsS0FBS2dELEtBQUsrQixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FMZ2M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUs5YixLQUw4WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzFYO0FBQUEsU0FMMFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUs3VDtBQUFBLElBQ25ELHVCQUFDLGNBQVcsTUFBWSxPQUFNLHVCQUFzQixTQUFTLE1BQU1pSyxRQUFRLEtBQUssR0FBRyxNQUFNeE8sT0FBT3NGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNzTyxhQUFhLFNBQVMsTUFBTSxLQUFLQyxjQUFjLEdBQUcsOEJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUcsR0FDck47QUFBQSw2QkFBQyxlQUFZLE9BQU83VCxPQUFPcUcsU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQUUsdUJBQUMsY0FDaEM7QUFBQSwrQkFBQyxhQUFVLE9BQU0sdUJBQXNCLFFBQU0sTUFBQyxPQUFPOEwsU0FBUyxVQUFVLENBQUF0RSxVQUFTO0FBQUV1RSxxQkFBV3ZFLE1BQU1ySCxPQUFPQyxLQUFLO0FBQUcrTCx3QkFBYyxDQUFDLENBQUM7QUFBQSxRQUFHLEdBQUcsVUFBVU4sT0FBT2hHLGFBQWEsQ0FBQ2dHLE9BQU8xUCxNQUMxSzJQO0FBQUFBLHFCQUFXLENBQUNELE9BQU8xUCxNQUFNQSxLQUFLc0UsS0FBSyxDQUFBRSxTQUFRQSxLQUFLN0UsT0FBT2dRLE9BQU8sS0FBSyx1QkFBQyxZQUFTLE9BQU9BLFNBQVVXLGlCQUFPM1EsT0FBTzBRLGNBQWMzRyxZQUFZLDBCQUEwQmlHLFlBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDektELE9BQU8xUCxNQUFNQSxLQUFLdUgsT0FBTyxDQUFBL0MsU0FBUSxDQUFDLGFBQWEsZUFBZSxFQUFFNkssU0FBUzdLLEtBQUs5RyxNQUFNLENBQUMsRUFBRStHLElBQUksQ0FBQUQsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLN0UsSUFBSzZFLGVBQUs3RSxNQUEvQjZFLEtBQUs3RSxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRCxDQUFXO0FBQUEsYUFGcEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxrQkFBZSxPQUFNLFdBQVUsYUFBYStQLE9BQU9oTCxhQUFhLFNBQVNnTCxPQUFPL0ssU0FBUyxNQUFNK0ssT0FBTzlLLGVBQWUsWUFBWThLLE9BQU83SyxZQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtKO0FBQUEsUUFDako2SyxPQUFPNUssV0FBVyx1QkFBQyxjQUFZO0FBQUEsaUNBQUMsZUFBWSxPQUFPNEssT0FBTzdMLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFBRSx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU07QUFBRSxrQkFBTTZMLE9BQU8zSyx1QkFBdUIySyxPQUFPN0ssU0FBUyxJQUFJNkssT0FBT2pQLFFBQVE7QUFBQSxVQUFJLEdBQUcseUNBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZJO0FBQUEsYUFBN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzTTtBQUFBLFFBQ3pOLHVCQUFDLGFBQVUsT0FBTSxrQ0FBaUMsT0FBT29QLFVBQVUsVUFBVSxDQUFBeEUsVUFBU3lFLFlBQVl2VSxnQkFBZ0I4UCxNQUFNckgsT0FBT0MsT0FBTyxHQUFHLENBQUMsS0FBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0STtBQUFBLFFBQzNJMEwsV0FBVyx1QkFBQyxjQUFXLE9BQU9VLGVBQWdCQyxtQkFBUyx1QkFBQyxjQUNwREEsZ0JBQU1uRixNQUFNMUcsSUFBSSxDQUFBb0ksU0FBUTtBQUNyQixnQkFBTThELFFBQVFaLFdBQVdsRCxLQUFLbE4sRUFBRSxLQUFLLEVBQUVpUixVQUFVLEtBQUtDLFVBQVUsS0FBSy9SLFFBQVEsR0FBRztBQUNoRixnQkFBTXFTLFlBQVl0RSxLQUFLekIsV0FBV3lCLEtBQUtxQyxtQkFBbUJyQyxLQUFLbUU7QUFDL0QsZ0JBQU1VLFVBQVUsQ0FBQyxDQUFDZixNQUFNQyxZQUFZLENBQUMvUCxPQUFPQyxVQUFVRCxPQUFPOFAsTUFBTUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDRCxNQUFNRSxZQUFZLENBQUNoUSxPQUFPQyxVQUFVRCxPQUFPOFAsTUFBTUUsUUFBUSxDQUFDLEtBQUtoUSxPQUFPOFAsTUFBTUMsWUFBWSxDQUFDLElBQUkvUCxPQUFPOFAsTUFBTUUsWUFBWSxDQUFDLElBQUlNLGFBQWN0USxPQUFPOFAsTUFBTUUsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDRixNQUFNN1IsT0FBTzhCLEtBQUs7QUFDbFIsaUJBQU8sdUJBQUMsY0FBeUIsVUFBUyxZQUN0QztBQUFBLG1DQUFDLGNBQVcsWUFBWTFHLFNBQVMwSCxXQUFXQyxXQUFXQyxRQUFRO0FBQUE7QUFBQSxjQUFjK0ssS0FBS3RLO0FBQUFBLGlCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RjtBQUFBLFlBQzVGLHVCQUFDLGNBQVcsU0FBUSxXQUFVO0FBQUE7QUFBQSxjQUFLc0ssS0FBS3pCO0FBQUFBLGNBQVM7QUFBQSxjQUFZeUIsS0FBS3FDO0FBQUFBLGNBQWlCO0FBQUEsY0FBZXJDLEtBQUttRTtBQUFBQSxjQUFpQjtBQUFBLGNBQVFHO0FBQUFBLGlCQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSTtBQUFBLFlBQzFJLHVCQUFDLGNBQVcsV0FBVyxFQUFFN0csSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FDN0M7QUFBQSxxQ0FBQyxhQUFVLE9BQU8sd0JBQXdCc0MsS0FBS3RLLFNBQVMsSUFBSSxNQUFLLFVBQVMsT0FBT29PLE1BQU1DLFVBQVUsVUFBVSxDQUFBdkYsVUFBUzJFLGNBQWMsQ0FBQTFDLGNBQWEsRUFBRSxHQUFHQSxVQUFVLENBQUNULEtBQUtsTixFQUFFLEdBQUcsRUFBRSxHQUFHZ1IsT0FBT0MsVUFBVXZGLE1BQU1ySCxPQUFPQyxNQUFNLEVBQUUsRUFBRSxHQUFHLFlBQVksRUFBRUMsS0FBSyxHQUFHc0gsS0FBSzJGLFdBQVdoTixNQUFNLEVBQUUsR0FBRyxPQUFPdU4sV0FBalI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeVI7QUFBQSxjQUN6Uix1QkFBQyxhQUFVLE9BQU8sOEJBQThCN0UsS0FBS3RLLFNBQVMsSUFBSSxNQUFLLFVBQVMsT0FBT29PLE1BQU1FLFVBQVUsVUFBVSxDQUFBeEYsVUFBUzJFLGNBQWMsQ0FBQTFDLGNBQWEsRUFBRSxHQUFHQSxVQUFVLENBQUNULEtBQUtsTixFQUFFLEdBQUcsRUFBRSxHQUFHZ1IsT0FBT0UsVUFBVXhGLE1BQU1ySCxPQUFPQyxNQUFNLEVBQUUsRUFBRSxHQUFHLFlBQVksRUFBRUMsS0FBSyxHQUFHc0gsS0FBSzJGLFdBQVdoTixNQUFNLEVBQUUsR0FBRyxPQUFPdU4sV0FBdlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK1I7QUFBQSxpQkFGblM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxPQUFPLGlDQUFpQzdFLEtBQUt0SyxTQUFTLElBQUksV0FBUyxNQUFDLE9BQU9vTyxNQUFNN1IsUUFBUSxVQUFVLENBQUF1TSxVQUFTMkUsY0FBYyxDQUFBMUMsY0FBYSxFQUFFLEdBQUdBLFVBQVUsQ0FBQ1QsS0FBS2xOLEVBQUUsR0FBRyxFQUFFLEdBQUdnUixPQUFPN1IsUUFBUXZELGdCQUFnQjhQLE1BQU1ySCxPQUFPQyxPQUFPLEdBQUksRUFBRSxFQUFFLEVBQUUsR0FBSSxPQUFPeU4sV0FBVzdRLE9BQU84UCxNQUFNRSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVloUSxPQUFPOFAsTUFBTUUsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDRixNQUFNN1IsT0FBTzhCLEtBQUssSUFBSSxzQ0FBc0N2RCxVQUFqWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyWjtBQUFBLGVBUHZZd1AsS0FBS2xOLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUVA7QUFBQSxRQUNKLENBQUMsS0FkbUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWV4RCxLQWZZO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlRTtBQUFBLFdBdkJpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JuQztBQUFBLFNBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUNzUSxZQUFZLE9BQU8sY0FBY0EsY0FBYyxFQUFFLElBQUksU0FBUyxNQUFNO0FBQUVHLHFCQUFlLEtBQUs7QUFBR0Ysb0JBQWMsSUFBSTtBQUFBLElBQUcsR0FBRyxNQUFNTyxLQUFLM04sU0FBUyxTQUFTLHVCQUFDLGNBQVcsV0FBVSxPQUN4TDtBQUFBLDZCQUFDLFVBQU8sU0FBUyxNQUFNO0FBQUVzTix1QkFBZSxLQUFLO0FBQUdGLHNCQUFjLElBQUk7QUFBQSxNQUFHLEdBQUcsb0JBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUMzRU0sU0FBUzlTLFdBQVcsV0FBVyx1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFRLGFBQVksTUFBTStTLEtBQUszTixTQUFTLFVBQVV5TixjQUFjeE4sV0FBVyxTQUFTLE1BQU1xTixlQUFlLElBQUksR0FBRyx1Q0FBaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3TDtBQUFBLFNBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHdEssR0FDSTtBQUFBLDZCQUFDLGVBQVksT0FBT0csY0FBYzFNLFNBQVM0TSxLQUFLNU0sU0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPME0sZUFBZ0JDLHFCQUFXLHVCQUFDLGNBQ25HO0FBQUEsK0JBQUMsY0FBVyxPQUFNLFdBQVdBLGtCQUFRYyxtQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLGNBQVcsT0FBTSxrQkFBa0JkLGtCQUFRZ0IscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUM5RCx1QkFBQyxjQUFXLE9BQU0sY0FBYSxpQ0FBQyxVQUFPLE9BQU9oQixRQUFROVMsVUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0QsdUJBQUMsYUFBVSxPQUFNLHNCQUFxQixNQUFNOFMsUUFBUXJGLE9BQU8sUUFBUSxDQUFBMEIsU0FBUUEsS0FBS2lFLGdCQUFnQixTQUFTO0FBQUEsVUFDckcsRUFBRXJQLEtBQUssUUFBUUMsT0FBTyxnQkFBZ0JDLFFBQVFBLENBQUFrTCxTQUFRQSxLQUFLaUUsZUFBZTtBQUFBLFVBQzFFLEVBQUVyUCxLQUFLLFlBQVlDLE9BQU8sWUFBWStJLE9BQU8sU0FBUzlJLFFBQVFBLENBQUFrTCxTQUFRQSxLQUFLa0UsaUJBQWlCO0FBQUEsVUFDNUYsRUFBRXRQLEtBQUssWUFBWUMsT0FBTyxXQUFXK0ksT0FBTyxTQUFTOUksUUFBUUEsQ0FBQWtMLFNBQVFBLEtBQUttRSxpQkFBaUI7QUFBQSxVQUMzRixFQUFFdlAsS0FBSyxVQUFVQyxPQUFPLFNBQVNDLFFBQVFBLENBQUFrTCxTQUFRQSxLQUFLL04sVUFBVSxJQUFJO0FBQUEsUUFBQyxLQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0U7QUFBQSxRQUNEMFIsUUFBUTlTLFdBQVcsWUFBWSx1QkFBQyxTQUFNLFVBQVMsV0FBVSwrRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFdBVnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXdEcsS0FYd0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVcxQztBQUFBLFNBZmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLE1BQU15UyxlQUFlLENBQUMsQ0FBQ0YsY0FBY08sU0FBUzlTLFdBQVcsU0FBUyxPQUFNLGlDQUFnQyxjQUFhLG9CQUFtQixhQUFhLFNBQVM4UyxTQUFTN1EsTUFBTSxFQUFFLEtBQUs2USxTQUFTckYsTUFBTTFHLElBQUksQ0FBQW9JLFNBQVEsR0FBR0EsS0FBS2tFLGdCQUFnQixjQUFjbEUsS0FBS21FLGdCQUFnQixVQUFVLEVBQUVXLEtBQUssSUFBSSxLQUFLLEVBQUUsMEZBQTBGLFNBQVMsTUFBTXZCLGVBQWUsS0FBSyxHQUFHLE1BQU1LLEtBQUszTixTQUFTLE9BQU8yTixLQUFLNU0sT0FBTyxXQUFXNE4sZUFBdmU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtZjtBQUFBLE9BbEQ1ZTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0Q4ZTtBQUN6ZjtBQUFDakMsSUE1RmVELGNBQVk7QUFBQSxVQUNEblYsaUJBQ1ZXLFFBQXFDTyxjQUNuQ04sYUFFT0QsUUFFQUEsUUFFUEUsWUFDRkEsVUFBVTtBQUFBO0FBQUEsTUFWWHNVO0FBOEZoQixTQUFTblAsaUJBQWlCb0gsVUFBb0I7QUFDMUMsU0FBTyxFQUFFL0QsU0FBUytELFNBQVMvRCxTQUFTbEQsUUFBUSxFQUFFekMsTUFBTTBKLFNBQVMxSixNQUFNRSxTQUFTd0osU0FBU3JHLGNBQWNqRCxNQUFNa0QsT0FBT29HLFNBQVNuRyxZQUFZLEdBQUdqRCxPQUFPb0osU0FBU2xHLGNBQWNoRCxRQUFRa0osU0FBU2pHLFlBQVkvQyxTQUFTZ0osU0FBU2hHLHFCQUFxQixHQUFHLEVBQUU7QUFDblA7QUFBQyxJQUFBb1EsSUFBQUMsS0FBQUMsS0FBQUMsS0FBQUM7QUFBQSxhQUFBSixJQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVZlcnNpb25lZERyYWZ0IiwiRHJhZnRDb25mbGljdCIsIkZpZWxkR3JvdXAiLCJGb3JtRmllbGRzIiwidXNlU3RhdGUiLCJ1c2VTeW5jRXh0ZXJuYWxTdG9yZSIsInZpc3VhbFN4IiwidXNlTmF2aWdhdGUiLCJ1c2VTZWFyY2hQYXJhbXMiLCJBbGVydCIsIkJ1dHRvbiIsIkNoZWNrYm94IiwiRm9ybUNvbnRyb2xMYWJlbCIsIk1lbnVJdGVtIiwiU3RhY2siLCJUYWIiLCJUYWJzIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsInVzZUFwaSIsInVzZVBhZ2VkQXBpIiwidXNlQ29tbWFuZCIsIkFwaUVycm9yIiwiVW5rbm93blJlc3VsdEVycm9yIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJ1c2VMaXN0UXVlcnkiLCJsaW1pdENvZGVQb2ludHMiLCJjb2RlUG9pbnRMZW5ndGgiLCJkYXRlVGltZSIsImludGVudFNuYXBzaG90Iiwic3Vic2NyaWJlSW50ZW50cyIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIkRhdGFUYWJsZSIsIlF1ZXJ5U3RhdGUiLCJUb29sYmFyIiwiUGFnZXIiLCJTdGF0dXMiLCJBbW91bnQiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkNvbmZpcm1EaWFsb2ciLCJSb3V0ZUxpbmsiLCJEZXRhaWxMaW5lIiwiTG9va3VwTG9hZE1vcmUiLCJsYXlvdXRTeCIsIlN1cHBsaWVyc1BhZ2UiLCJfcyIsInNob3AiLCJwYXJhbXMiLCJsaXN0IiwicXVlcnkiLCJsaW1pdCIsImN1cnNvciIsImdldCIsInVuZGVmaW5lZCIsIm9mZmVycyIsInByb2R1Y3RzIiwiY3JlYXRlIiwidXBkYXRlIiwic3RhdHVzIiwiYWRkT2ZmZXIiLCJlZGl0Iiwic2V0RWRpdCIsIm5hbWUiLCJzZXROYW1lIiwiY29udGFjdCIsInNldENvbnRhY3QiLCJsZWFkIiwic2V0TGVhZCIsInRlcm1zIiwic2V0VGVybXMiLCJtZXRob2QiLCJzZXRNZXRob2QiLCJhZGFwdGVyIiwic2V0QWRhcHRlciIsInN0YXR1c0l0ZW0iLCJzZXRTdGF0dXNJdGVtIiwic3RhdHVzVmFsdWUiLCJzZXRTdGF0dXNWYWx1ZSIsInJlYXNvbiIsInNldFJlYXNvbiIsIm9mZmVyU3VwcGxpZXIiLCJzZXRPZmZlclN1cHBsaWVyIiwidmFyaWFudCIsInNldFZhcmlhbnQiLCJjb3N0Iiwic2V0Q29zdCIsIm1pbmltdW0iLCJzZXRNaW5pbXVtIiwicGFjayIsInNldFBhY2siLCJzdXBwbGllckRldGFpbElkIiwiaWQiLCJzdXBwbGllckRldGFpbCIsInBhdGgiLCJyZXNvdXJjZUlkIiwic3VwcGxpZXJTb3VyY2UiLCJkYXRhIiwic3VwcGxpZXJFZGl0b3IiLCJpZGVudGl0eSIsInNvdXJjZSIsInN1cHBsaWVyU25hcHNob3QiLCJkcmFmdCIsImFwcGx5IiwidmFsdWVzIiwicmVmcmVzaCIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJzdXBwbGllckZvcm1WYWxpZCIsInRyaW0iLCJOdW1iZXIiLCJpc0ludGVnZXIiLCJvZmZlckZvcm1WYWxpZCIsInRlc3QiLCJvcGVuIiwicyIsImNvbnRhY3RMYWJlbCIsIlN0cmluZyIsImxlYWRUaW1lRGF5cyIsInBheW1lbnRUZXJtcyIsInNlbmRNZXRob2QiLCJhcHByb3ZlZEFkYXB0ZXJJZCIsImtleSIsImxhYmVsIiwicmVuZGVyIiwidHlwb2dyYXBoeSIsImZvbnRXZWlnaHQiLCJzdHJvbmciLCJwYWdlIiwibyIsImZpbmQiLCJzdXBwbGllcklkIiwiZmxhdE1hcCIsInAiLCJ2YXJpYW50cyIsInYiLCJ2YXJpYW50SWQiLCJza3UiLCJ1bml0Q29zdCIsIm1pbmltdW1RdWFudGl0eSIsInBhY2tTaXplIiwidmFsaWRVbnRpbCIsInRpbWV6b25lIiwicGVuZGluZyIsImlzTG9hZGluZyIsImJvZHkiLCJjdXJyZW5jeSIsInN1Ym1pdHRlZCIsInJlc3VsdCIsInByZXBhcmVkIiwicHJlcGFyZSIsImNoYW5nZWQiLCJwYXRjaCIsImV4ZWN1dGUiLCJ2ZXJzaW9uIiwiZXhwZWN0ZWRWZXJzaW9uIiwiY2xlYW4iLCJjb21taXR0ZWQiLCJlcnJvciIsImZhaWxlZCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1pbiIsInN0ZXAiLCJjdXJyZW50IiwiYW1vdW50Iiwic29tZSIsInByb2R1Y3QiLCJpdGVtIiwibWFwIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaXNFcnJvciIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwiUmVwbGVuaXNobWVudFBhZ2UiLCJfczIiLCJuYXZpZ2F0ZSIsInN1Z2dlc3Rpb25zIiwicnVsZXMiLCJzdXBwbGllcnMiLCJ3YXJlaG91c2VzIiwid2FyZWhvdXNlSWQiLCJzZXRXYXJlaG91c2VJZCIsImRlZmF1bHRXYXJlaG91c2VJZCIsImNhblJlYWRCdWRnZXRQb2xpY2llcyIsImV2YWx1YXRlIiwicHVyY2hhc2UiLCJ0YWIiLCJzZXRUYWIiLCJvZmZlcklkIiwic2V0T2ZmZXIiLCJyZW9yZGVyIiwic2V0UmVvcmRlciIsInNldFRhcmdldCIsInNhZmV0eSIsInNldFNhZmV0eSIsIm1vZGUiLCJzZXRNb2RlIiwiZW5hYmxlZCIsInNldEVuYWJsZWQiLCJidWRnZXQiLCJzZXRCdWRnZXQiLCJkZWxlZ2F0aW9uSWQiLCJzZXREZWxlZ2F0aW9uSWQiLCJhdXRvQWNrIiwic2V0QXV0b0FjayIsImNhblJlYWRBcHByb3ZhbHMiLCJidWRnZXRMb29rdXBzRW5hYmxlZCIsImJ1ZGdldHMiLCJidWRnZXRBcHByb3ZhbHMiLCJkZWxlZ2F0aW9ucyIsImFwcHJvdmVkU3VwcGxpZXJJZHMiLCJTZXQiLCJmaWx0ZXIiLCJzdXBwbGllciIsImVsaWdpYmxlT2ZmZXJzIiwib2ZmZXIiLCJoYXMiLCJvZmZlcklzQ3VycmVudCIsInNlbGVjdGVkT2ZmZXJGcm9tTGlzdCIsInNlbGVjdGVkT2ZmZXJEZXRhaWwiLCJzZWxlY3RlZE9mZmVyIiwic2VsZWN0ZWRTdXBwbGllckZyb21MaXN0Iiwic2VsZWN0ZWRTdXBwbGllckRldGFpbCIsInNlbGVjdGVkU3VwcGxpZXIiLCJzZWxlY3RlZE9mZmVyRWxpZ2libGUiLCJhcHByb3ZlZEJ1ZGdldHMiLCJraW5kIiwibGltaXRBbW91bnQiLCJhcHByb3ZhbElkIiwibWV0YSIsImFzT2YiLCJhcHByb3ZhbCIsInJlc291cmNlIiwidHlwZSIsInJlc291cmNlVmVyc2lvbiIsIkRhdGUiLCJwYXJzZSIsImV4cGlyZXNBdCIsImVsaWdpYmxlRGVsZWdhdGlvbnMiLCJncmFudCIsIm5vdyIsImJ1ZGdldFBvbGljeUlkIiwib2ZmZXJTbmFwc2hvdHMiLCJzbmFwc2hvdCIsInN1cHBsaWVyT2ZmZXJJZCIsIm9mZmVyVmVyc2lvbiIsImJ1ZGdldFZlcmlmaWVkIiwiaXNQZW5kaW5nIiwiZGVsZWdhdGlvblZlcmlmaWVkIiwicnVsZUZvcm1WYWxpZCIsIndhcmVob3VzZSIsInIiLCJyZW9yZGVyUG9pbnQiLCJ0YXJnZXRRdWFudGl0eSIsInNhZmV0eVN0b2NrIiwicHVyY2hhc2VEZWxlZ2F0aW9uSWQiLCJjYXRjaCIsIl8iLCJzZWN0aW9uQWZ0ZXIiLCJ4cyIsInNtIiwiY2FuUmV0cnlMb29rdXAiLCJhbGlnbiIsImF2YWlsYWJsZSIsImNvbmZpcm1lZEluYm91bmQiLCJvcGVuUHJvcG9zYWxRdWFudGl0eSIsImJvbGQiLCJzdWdnZXN0ZWRRdWFudGl0eSIsImF1dG9TZW5kU3RhdHVzIiwiYXV0b1NlbmRSZWFzb24iLCJhY3RpdmVQdXJjaGFzZU9yZGVySWQiLCJzdWdnZXN0aW9uSWQiLCJsaW5lcyIsInF1YW50aXR5IiwiZXZlbnQiLCJjb2RlIiwiTWF0aCIsIm1heCIsImlzRmluaXRlIiwibGVuZ3RoIiwibWF4UGVyT3JkZXIiLCJjaGVja2VkIiwicXVhbnRpdHlNYXRjaGVzT2ZmZXIiLCJQdXJjaGFzZXNQYWdlIiwiX3MzIiwic2V0T3BlbiIsInNldFN1cHBsaWVySWQiLCJwb0xpbmVzIiwic2V0UG9MaW5lcyIsIm5leHRMaW5lS2V5Iiwic2V0TmV4dExpbmVLZXkiLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiZHJhZnRDb21taXQiLCJzZXREcmFmdENvbW1pdCIsImF2YWlsYWJsZU9mZmVycyIsImNhbkNyZWF0ZSIsImV2ZXJ5IiwibGluZSIsInNpemUiLCJzdGFydFB1cmNoYXNlIiwic2VsZWN0U3VwcGxpZXIiLCJuZXh0U3VwcGxpZXJJZCIsInNlbGVjdE9mZmVyIiwiY2VpbCIsInN1Ym1pdCIsIkVycm9yIiwicHJldmlvdXMiLCJzY29wZSIsInNlcXVlbmNlIiwidG90YWwiLCJleHRlcm5hbFJlZmVyZW5jZSIsImluZGV4IiwibGluZU9mZmVyIiwiY2hvaWNlcyIsIm90aGVyIiwiUHVyY2hhc2VEaWFsb2ciLCJvbkNsb3NlIiwiX3M0Iiwic2VuZCIsImNvbmZpcm0iLCJjYW5jZWwiLCJhY3Rpb24iLCJzZXRBY3Rpb24iLCJleHRlcm5hbCIsInNldEV4dGVybmFsIiwicHJvb2YiLCJzZXRQcm9vZiIsInVucmVzb2x2ZWRTZW5kIiwiaW50ZW50Iiwic2hvcElkIiwib3BlcmF0aW9uIiwic2VuZFB1cmNoYXNlIiwiaW50ZW50SGFzaCIsImwiLCJyZWNlaXZlZFF1YW50aXR5Iiwib3ZlcmZsb3dXcmFwIiwiYWxsb3dlZEFjdGlvbnMiLCJpbmNsdWRlcyIsInN1cHBsaWVyQ29uZmlybWF0aW9uUmVmIiwiUmVjZWlwdHNQYWdlIiwiX3M1Iiwic2VhcmNoUGFyYW1zIiwib3JkZXJzIiwib3JkZXJJZCIsInNldE9yZGVySWQiLCJkb2N1bWVudCIsInNldERvY3VtZW50IiwicXVhbnRpdGllcyIsInNldFF1YW50aXRpZXMiLCJzZWxlY3RlZElkIiwic2V0U2VsZWN0ZWRJZCIsImNvbmZpcm1Qb3N0Iiwic2V0Q29uZmlybVBvc3QiLCJwdXJjaGFzZU9yZGVyIiwib3JkZXIiLCJyZWNlaXB0RGV0YWlsIiwicmVjZWlwdCIsInBvc3QiLCJyZWNlaXB0TGluZXMiLCJpbnB1dCIsImFjY2VwdGVkIiwicmVqZWN0ZWQiLCJwdXJjaGFzZUxpbmVJZCIsImFjY2VwdGVkUXVhbnRpdHkiLCJyZWplY3RlZFF1YW50aXR5IiwicmVjZWlwdExpbmVzVmFsaWQiLCJvcmlnaW5hbCIsInJlbWFpbmluZyIsImNyZWF0ZVZhbGlkIiwiY3JlYXRlUmVjZWlwdCIsInB1cmNoYXNlT3JkZXJJZCIsImV4cGVjdGVkUHVyY2hhc2VWZXJzaW9uIiwic291cmNlRG9jdW1lbnRSZWYiLCJwb3N0UmVjZWlwdCIsImludmFsaWQiLCJqb2luIiwiX2MiLCJfYzIiLCJfYzMiLCJfYzQiLCJfYzUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVZlcnNpb25lZERyYWZ0IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvdmVyc2lvbmVkLWRyYWZ0JztcclxuaW1wb3J0IHsgRHJhZnRDb25mbGljdCB9IGZyb20gJ0Avc2hhcmVkL3VpL2RyYWZ0LWNvbmZsaWN0JztcclxuaW1wb3J0IHsgRmllbGRHcm91cCwgRm9ybUZpZWxkcyB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VTeW5jRXh0ZXJuYWxTdG9yZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEFsZXJ0LCBCdXR0b24sIENoZWNrYm94LCBGb3JtQ29udHJvbExhYmVsLCBNZW51SXRlbSwgU3RhY2ssIFRhYiwgVGFicywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCB0eXBlIHsgUHVyY2hhc2VEZWxlZ2F0aW9uLCBTdXBwbGllciwgU3VwcGxpZXJPZmZlciwgUmVvcmRlclJ1bGUsIEdvb2RzUmVjZWlwdCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xyXG5pbXBvcnQgeyB1c2VBcGksIHVzZVBhZ2VkQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcclxuaW1wb3J0IHsgQXBpRXJyb3IsIFVua25vd25SZXN1bHRFcnJvciB9IGZyb20gJ0Avc2hhcmVkL2FwaS9lcnJvcnMnO1xyXG5pbXBvcnQgeyB1c2VTY29wZSwgdXNlQ2FuIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xyXG5pbXBvcnQgeyB1c2VMaXN0UXVlcnkgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcclxuaW1wb3J0IHsgbGltaXRDb2RlUG9pbnRzLCBjb2RlUG9pbnRMZW5ndGgsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgaW50ZW50U25hcHNob3QsIHN1YnNjcmliZUludGVudHMgfSBmcm9tICdAL3NoYXJlZC9hcGkvaW50ZW50cyc7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIsIFBhbmVsLCBEYXRhVGFibGUsIFF1ZXJ5U3RhdGUsIFRvb2xiYXIsIFBhZ2VyLCBTdGF0dXMsIEFtb3VudCwgTXV0YXRpb25CdXR0b24sIEVkaXREaWFsb2csIEVycm9yTm90aWNlLCBDb25maXJtRGlhbG9nLCBSb3V0ZUxpbmssIERldGFpbExpbmUsIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcclxuZXhwb3J0IGZ1bmN0aW9uIFN1cHBsaWVyc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBbcGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdFN1cHBsaWVycycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwLCBjdXJzb3I6IHBhcmFtcy5nZXQoJ3N1cHBsaWVyQ3Vyc29yJykgfHwgdW5kZWZpbmVkIH0gfSk7XHJcbiAgICBjb25zdCBvZmZlcnMgPSB1c2VBcGkoJ2xpc3RTdXBwbGllck9mZmVycycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwLCBjdXJzb3I6IHBhcmFtcy5nZXQoJ29mZmVyQ3Vyc29yJykgfHwgdW5kZWZpbmVkIH0gfSk7XHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IHVzZVBhZ2VkQXBpKCdsaXN0UHJvZHVjdHMnKTtcclxuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZVN1cHBsaWVyJywgWydsaXN0U3VwcGxpZXJzJ10pO1xyXG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlU3VwcGxpZXInLCBbJ2xpc3RTdXBwbGllcnMnXSk7XHJcbiAgICBjb25zdCBzdGF0dXMgPSB1c2VDb21tYW5kKCdzZXRTdXBwbGllclN0YXR1cycsIFsnbGlzdFN1cHBsaWVycyddKTtcclxuICAgIGNvbnN0IGFkZE9mZmVyID0gdXNlQ29tbWFuZCgnY3JlYXRlU3VwcGxpZXJPZmZlcicsIFsnbGlzdFN1cHBsaWVyT2ZmZXJzJ10pO1xyXG4gICAgY29uc3QgW2VkaXQsIHNldEVkaXRdID0gdXNlU3RhdGU8U3VwcGxpZXIgfCBudWxsIHwgdW5kZWZpbmVkPigpLCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJyksIFtjb250YWN0LCBzZXRDb250YWN0XSA9IHVzZVN0YXRlKCcnKSwgW2xlYWQsIHNldExlYWRdID0gdXNlU3RhdGUoJzMnKSwgW3Rlcm1zLCBzZXRUZXJtc10gPSB1c2VTdGF0ZSgnJyksIFttZXRob2QsIHNldE1ldGhvZF0gPSB1c2VTdGF0ZTwnbWFudWFsJyB8ICdhcHByb3ZlZF9hZGFwdGVyJz4oJ21hbnVhbCcpLCBbYWRhcHRlciwgc2V0QWRhcHRlcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbc3RhdHVzSXRlbSwgc2V0U3RhdHVzSXRlbV0gPSB1c2VTdGF0ZTxTdXBwbGllciB8IG51bGw+KG51bGwpLCBbc3RhdHVzVmFsdWUsIHNldFN0YXR1c1ZhbHVlXSA9IHVzZVN0YXRlPCdhcHByb3ZlZCcgfCAnc3VzcGVuZGVkJyB8ICdhcmNoaXZlZCc+KCdhcHByb3ZlZCcpLCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW29mZmVyU3VwcGxpZXIsIHNldE9mZmVyU3VwcGxpZXJdID0gdXNlU3RhdGU8U3VwcGxpZXIgfCBudWxsPihudWxsKSwgW3ZhcmlhbnQsIHNldFZhcmlhbnRdID0gdXNlU3RhdGUoJycpLCBbY29zdCwgc2V0Q29zdF0gPSB1c2VTdGF0ZSgnJyksIFttaW5pbXVtLCBzZXRNaW5pbXVtXSA9IHVzZVN0YXRlKCcxJyksIFtwYWNrLCBzZXRQYWNrXSA9IHVzZVN0YXRlKCcxJyk7XHJcbiAgICBjb25zdCBzdXBwbGllckRldGFpbElkID0gZWRpdD8uaWQgfHwgc3RhdHVzSXRlbT8uaWQgfHwgJyc7XHJcbiAgICBjb25zdCBzdXBwbGllckRldGFpbCA9IHVzZUFwaSgnZ2V0U3VwcGxpZXInLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogc3VwcGxpZXJEZXRhaWxJZCB9IH0sICEhc3VwcGxpZXJEZXRhaWxJZCk7XHJcbiAgICBjb25zdCBzdXBwbGllclNvdXJjZSA9IGVkaXQ/LmlkICYmIHN1cHBsaWVyRGV0YWlsLmRhdGE/LmRhdGEuaWQgPT09IGVkaXQuaWQgPyBzdXBwbGllckRldGFpbC5kYXRhLmRhdGEgOiBlZGl0O1xyXG4gICAgY29uc3Qgc3VwcGxpZXJFZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XHJcbiAgICAgICAgaWRlbnRpdHk6IGAke3Nob3AuaWR9OnN1cHBsaWVyOiR7ZWRpdD8uaWQgfHwgJ25ldyd9YCxcclxuICAgICAgICBzb3VyY2U6IHN1cHBsaWVyU291cmNlID8gc3VwcGxpZXJTbmFwc2hvdChzdXBwbGllclNvdXJjZSkgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgZHJhZnQ6IHsgbmFtZSwgY29udGFjdCwgbGVhZCwgdGVybXMsIG1ldGhvZCwgYWRhcHRlciB9LFxyXG4gICAgICAgIGFwcGx5OiB2YWx1ZXMgPT4geyBzZXROYW1lKHZhbHVlcy5uYW1lKTsgc2V0Q29udGFjdCh2YWx1ZXMuY29udGFjdCk7IHNldExlYWQodmFsdWVzLmxlYWQpOyBzZXRUZXJtcyh2YWx1ZXMudGVybXMpOyBzZXRNZXRob2QodmFsdWVzLm1ldGhvZCk7IHNldEFkYXB0ZXIodmFsdWVzLmFkYXB0ZXIpOyB9LFxyXG4gICAgICAgIHJlZnJlc2g6ICgpID0+IHN1cHBsaWVyRGV0YWlsLnJlZmV0Y2goeyB0aHJvd09uRXJyb3I6IHRydWUgfSksXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHN1cHBsaWVyRm9ybVZhbGlkID0gISFuYW1lLnRyaW0oKSAmJiBjb2RlUG9pbnRMZW5ndGgobmFtZS50cmltKCkpIDw9IDE2MCAmJiAhIWNvbnRhY3QudHJpbSgpICYmIGNvZGVQb2ludExlbmd0aChjb250YWN0LnRyaW0oKSkgPD0gMjAwICYmIE51bWJlci5pc0ludGVnZXIoTnVtYmVyKGxlYWQpKSAmJiBOdW1iZXIobGVhZCkgPj0gMCAmJiBjb2RlUG9pbnRMZW5ndGgodGVybXMpIDw9IDUwMCAmJiAobWV0aG9kID09PSAnbWFudWFsJyB8fCAhIWFkYXB0ZXIudHJpbSgpKTtcclxuICAgIGNvbnN0IG9mZmVyRm9ybVZhbGlkID0gISF2YXJpYW50ICYmIC9eKDB8WzEtOV1cXGQqKShcXC5cXGR7MSw0fSk/JC8udGVzdChjb3N0KSAmJiBOdW1iZXIuaXNJbnRlZ2VyKE51bWJlcihtaW5pbXVtKSkgJiYgTnVtYmVyKG1pbmltdW0pID49IDEgJiYgTnVtYmVyLmlzSW50ZWdlcihOdW1iZXIocGFjaykpICYmIE51bWJlcihwYWNrKSA+PSAxICYmIE51bWJlci5pc0ludGVnZXIoTnVtYmVyKGxlYWQpKSAmJiBOdW1iZXIobGVhZCkgPj0gMDtcclxuICAgIGNvbnN0IG9wZW4gPSAoczogU3VwcGxpZXIgfCBudWxsKSA9PiB7IHNldEVkaXQocyk7IHNldE5hbWUocz8ubmFtZSB8fCAnJyk7IHNldENvbnRhY3Qocz8uY29udGFjdExhYmVsIHx8ICcnKTsgc2V0TGVhZChTdHJpbmcocz8ubGVhZFRpbWVEYXlzID8/IDMpKTsgc2V0VGVybXMocz8ucGF5bWVudFRlcm1zIHx8ICcnKTsgc2V0TWV0aG9kKHM/LnNlbmRNZXRob2QgfHwgJ21hbnVhbCcpOyBzZXRBZGFwdGVyKHM/LmFwcHJvdmVkQWRhcHRlcklkIHx8ICcnKTsgfTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiTmjDoCBjdW5nIGPhuqVwIGjDoG5nIGjDs2FcIiBzdWJ0aXRsZT1cIlTDoWNoIGJp4buHdCB24bubaSBuaMOgIGN1bmcgY+G6pXAgQUkuIE11YSBow6BuZyBjaOG7iSB0cm9uZyDEkWnhu4F1IGtp4buHbiB2w6AgcXV54buBbiDEkcOjIGR1eeG7h3QuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC53cml0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBvcGVuKG51bGwpfT5UaMOqbSBuaMOgIGN1bmcgY+G6pXA8L011dGF0aW9uQnV0dG9uPn0vPjxQYW5lbD48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJOaMOgIGN1bmcgY+G6pXBcIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtzID0+IHMuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ25hbWUnLCBsYWJlbDogJ05ow6AgY3VuZyBj4bqlcCcsIHJlbmRlcjogcyA9PiA8U3RhY2s+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e3MubmFtZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57cy5jb250YWN0TGFiZWx9PC9UeXBvZ3JhcGh5PjwvU3RhY2s+XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7IGtleTogJ2xlYWQnLCBsYWJlbDogJ1Ro4budaSBnaWFuIGdpYW8nLCByZW5kZXI6IHMgPT4gYCR7cy5sZWFkVGltZURheXN9IG5nw6B5YCB9LCB7IGtleTogJ3Rlcm1zJywgbGFiZWw6ICdUaGFuaCB0b8OhbicsIHJlbmRlcjogcyA9PiBzLnBheW1lbnRUZXJtcyB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBzID0+IDxTdGF0dXMgdmFsdWU9e3Muc3RhdHVzfS8+IH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6ICdhY3Rpb25zJywgbGFiZWw6ICcnLCByZW5kZXI6IHMgPT4gPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGZsZXhXcmFwPVwid3JhcFwiPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJvY3VyZW1lbnQud3JpdGVcIiBvbkNsaWNrPXsoKSA9PiBvcGVuKHMpfT5T4butYTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC53cml0ZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0T2ZmZXJTdXBwbGllcihzKTsgc2V0VmFyaWFudCgnJyk7IHNldENvc3QoJycpOyBzZXRNaW5pbXVtKCcxJyk7IHNldFBhY2soJzEnKTsgc2V0TGVhZChTdHJpbmcocy5sZWFkVGltZURheXMpKTsgfX0+VGjDqm0gYsOhbyBnacOhPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByb2N1cmVtZW50Lm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U3RhdHVzSXRlbShzKTsgc2V0UmVhc29uKCcnKTsgc2V0U3RhdHVzVmFsdWUocy5zdGF0dXMgPT09ICdhcHByb3ZlZCcgPyAnc3VzcGVuZGVkJyA6ICdhcHByb3ZlZCcpOyB9fT5EdXnhu4d0IC8gdOG6oW0gZOG7q25nPC9NdXRhdGlvbkJ1dHRvbj48L1N0YWNrPlxyXG4gICAgICAgIH1cclxuICAgIF19Lz48UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9IGN1cnNvclBhcmFtPVwic3VwcGxpZXJDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gPFBhbmVsIHRpdGxlPVwiQsOhbyBnacOhIHPhuqNuIHBo4bqpbVwiIHN1YnRpdGxlPVwiR2nDoSB24buRbiwgbMaw4bujbmcgdOG7kWkgdGhp4buDdSwgcXV5IGPDoWNoIHbDoCBoaeG7h3UgbOG7sWMgxJHGsOG7o2MgcXXhuqNuIGzDvSByacOqbmcuXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e29mZmVyc30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e29mZmVycy5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIkLDoW8gZ2nDoSBz4bqjbiBwaOG6qW1cIiByb3dzPXtvZmZlcnMuZGF0YS5kYXRhfSByb3dLZXk9e28gPT4gby5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnc3VwcGxpZXInLCBsYWJlbDogJ05ow6AgY3VuZyBj4bqlcCcsIHJlbmRlcjogbyA9PiBsaXN0LmRhdGE/LmRhdGEuZmluZChzID0+IHMuaWQgPT09IG8uc3VwcGxpZXJJZCk/Lm5hbWUgfHwgYE3DoyBuaMOgIGN1bmcgY+G6pXA6ICR7by5zdXBwbGllcklkfWAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ3NrdScsIGxhYmVsOiAnQmnhur9uIHRo4buDJywgcmVuZGVyOiBvID0+IHByb2R1Y3RzLmRhdGE/LmRhdGEuZmxhdE1hcChwID0+IHAudmFyaWFudHMpLmZpbmQodiA9PiB2LmlkID09PSBvLnZhcmlhbnRJZCk/LnNrdSB8fCBgTcOjIGJp4bq/biB0aOG7gzogJHtvLnZhcmlhbnRJZH1gXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7IGtleTogJ2Nvc3QnLCBsYWJlbDogJ8SQxqFuIGdpw6EnLCByZW5kZXI6IG8gPT4gPEFtb3VudCB2YWx1ZT17by51bml0Q29zdH0vPiB9LCB7IGtleTogJ21vcScsIGxhYmVsOiAnVOG7kWkgdGhp4buDdSAvIFF1eSBjw6FjaCcsIHJlbmRlcjogbyA9PiBgJHtvLm1pbmltdW1RdWFudGl0eX0gLyAke28ucGFja1NpemV9YCB9LCB7IGtleTogJ2RhdGUnLCBsYWJlbDogJ0hp4buHdSBs4buxYyB04bubaScsIHJlbmRlcjogbyA9PiBvLnZhbGlkVW50aWwgPyBkYXRlVGltZShvLnZhbGlkVW50aWwsIHNob3AudGltZXpvbmUpIDogJ0NoxrBhIHF1eSDEkeG7i25oJyB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e29mZmVycy5kYXRhLnBhZ2V9IGN1cnNvclBhcmFtPVwib2ZmZXJDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gPEVkaXREaWFsb2cgYWxsb3dFZGl0c1doaWxlQnVzeSBvcGVuPXtlZGl0ICE9PSB1bmRlZmluZWR9IHRpdGxlPXtlZGl0ID8gJ0Phuq1wIG5o4bqtdCBuaMOgIGN1bmcgY+G6pXAnIDogJ05ow6AgY3VuZyBj4bqlcCBt4bubaSd9IG9uQ2xvc2U9eygpID0+IHNldEVkaXQodW5kZWZpbmVkKX0gYnVzeT17Y3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshc3VwcGxpZXJGb3JtVmFsaWQgfHwgY3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmcgfHwgKCEhZWRpdD8uaWQgJiYgKCFzdXBwbGllckRldGFpbC5kYXRhIHx8IHN1cHBsaWVyRGV0YWlsLmlzTG9hZGluZykpfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgbmFtZTogbmFtZS50cmltKCksIGNvbnRhY3RMYWJlbDogY29udGFjdC50cmltKCksIGN1cnJlbmN5OiBlZGl0Py5jdXJyZW5jeSB8fCBzaG9wLmN1cnJlbmN5LCBsZWFkVGltZURheXM6IE51bWJlcihsZWFkKSwgcGF5bWVudFRlcm1zOiB0ZXJtcy50cmltKCksIHNlbmRNZXRob2Q6IG1ldGhvZCwgYXBwcm92ZWRBZGFwdGVySWQ6IG1ldGhvZCA9PT0gJ2FwcHJvdmVkX2FkYXB0ZXInID8gYWRhcHRlci50cmltKCkgOiBudWxsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBzdWJtaXR0ZWQgPSB7IG5hbWUsIGNvbnRhY3QsIGxlYWQsIHRlcm1zLCBtZXRob2QsIGFkYXB0ZXIgfTtcclxuICAgICAgICBsZXQgcmVzdWx0OiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZS5leGVjdXRlPj47XHJcbiAgICAgICAgaWYgKGVkaXQpIHtcclxuICAgICAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBzdXBwbGllckVkaXRvci5wcmVwYXJlKCk7IGlmICghcHJlcGFyZWQpIHJldHVybjtcclxuICAgICAgICAgICAgY29uc3QgY2hhbmdlZCA9IHByZXBhcmVkLnBhdGNoO1xyXG4gICAgICAgICAgICByZXN1bHQgPSBhd2FpdCB1cGRhdGUuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogZWRpdC5pZCB9LCB2ZXJzaW9uOiBwcmVwYXJlZC52ZXJzaW9uLCBib2R5OiB7XHJcbiAgICAgICAgICAgICAgICBleHBlY3RlZFZlcnNpb246IHByZXBhcmVkLnZlcnNpb24sXHJcbiAgICAgICAgICAgICAgICAuLi4oY2hhbmdlZC5uYW1lICE9PSB1bmRlZmluZWQgPyB7IG5hbWU6IGJvZHkubmFtZSB9IDoge30pLFxyXG4gICAgICAgICAgICAgICAgLi4uKGNoYW5nZWQuY29udGFjdCAhPT0gdW5kZWZpbmVkID8geyBjb250YWN0TGFiZWw6IGJvZHkuY29udGFjdExhYmVsIH0gOiB7fSksXHJcbiAgICAgICAgICAgICAgICAuLi4oY2hhbmdlZC5sZWFkICE9PSB1bmRlZmluZWQgPyB7IGxlYWRUaW1lRGF5czogYm9keS5sZWFkVGltZURheXMgfSA6IHt9KSxcclxuICAgICAgICAgICAgICAgIC4uLihjaGFuZ2VkLnRlcm1zICE9PSB1bmRlZmluZWQgPyB7IHBheW1lbnRUZXJtczogYm9keS5wYXltZW50VGVybXMgfSA6IHt9KSxcclxuICAgICAgICAgICAgICAgIC4uLihjaGFuZ2VkLm1ldGhvZCAhPT0gdW5kZWZpbmVkID8geyBzZW5kTWV0aG9kOiBib2R5LnNlbmRNZXRob2QgfSA6IHt9KSxcclxuICAgICAgICAgICAgICAgIC4uLihjaGFuZ2VkLmFkYXB0ZXIgIT09IHVuZGVmaW5lZCB8fCBjaGFuZ2VkLm1ldGhvZCAhPT0gdW5kZWZpbmVkID8geyBhcHByb3ZlZEFkYXB0ZXJJZDogYm9keS5hcHByb3ZlZEFkYXB0ZXJJZCB9IDoge30pLFxyXG4gICAgICAgICAgICB9IH0pO1xyXG4gICAgICAgIH0gZWxzZSByZXN1bHQgPSBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHkgfSk7XHJcbiAgICAgICAgY29uc3QgY2xlYW4gPSBzdXBwbGllckVkaXRvci5jb21taXR0ZWQoc3VwcGxpZXJTbmFwc2hvdChyZXN1bHQuZGF0YSksIHN1Ym1pdHRlZCwgYCR7c2hvcC5pZH06c3VwcGxpZXI6JHtyZXN1bHQuZGF0YS5pZH1gKTtcclxuICAgICAgICBzZXRFZGl0KGNsZWFuID8gdW5kZWZpbmVkIDogcmVzdWx0LmRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IHN1cHBsaWVyRWRpdG9yLmZhaWxlZChlcnJvcik7IH0gfX0+TMawdTwvQnV0dG9uPn0+PEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3IgfHwgdXBkYXRlLmVycm9yIHx8IHN1cHBsaWVyRGV0YWlsLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtzdXBwbGllckVkaXRvcn0gbGFiZWxzPXt7IG5hbWU6ICdUw6puIG5ow6AgY3VuZyBj4bqlcCcsIGNvbnRhY3Q6ICfEkOG6p3UgbeG7kWkgbGnDqm4gaOG7hycsIGxlYWQ6ICdUaOG7nWkgZ2lhbiBnaWFvJywgdGVybXM6ICfEkGnhu4F1IGtp4buHbiB0aGFuaCB0b8OhbicsIG1ldGhvZDogJ0PDoWNoIGfhu61pIMSRxqFuJywgYWRhcHRlcjogJ0FkYXB0ZXInIH19IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfS8+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgbGFiZWw9XCJUw6puIG5ow6AgY3VuZyBj4bqlcFwiIHZhbHVlPXtuYW1lfSBvbkNoYW5nZT17ZSA9PiBzZXROYW1lKGxpbWl0Q29kZVBvaW50cyhlLnRhcmdldC52YWx1ZSwgMTYwKSl9IC8+PFRleHRGaWVsZCBsYWJlbD1cIsSQ4bqndSBt4buRaSBsacOqbiBo4buHXCIgdmFsdWU9e2NvbnRhY3R9IG9uQ2hhbmdlPXtlID0+IHNldENvbnRhY3QobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAyMDApKX0gLz48VGV4dEZpZWxkIGxhYmVsPVwiVGjhu51pIGdpYW4gZ2lhbyAobmfDoHkpXCIgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtsZWFkfSBvbkNoYW5nZT17ZSA9PiBzZXRMZWFkKGUudGFyZ2V0LnZhbHVlKX0gaW5wdXRQcm9wcz17eyBtaW46IDAsIHN0ZXA6IDEgfX0vPjxUZXh0RmllbGQgbGFiZWw9XCLEkGnhu4F1IGtp4buHbiB0aGFuaCB0b8OhblwiIHZhbHVlPXt0ZXJtc30gb25DaGFuZ2U9e2UgPT4gc2V0VGVybXMobGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCA1MDApKX0gbXVsdGlsaW5lIC8+PFRleHRGaWVsZCBsYWJlbD1cIkPDoWNoIGfhu61pIMSRxqFuXCIgc2VsZWN0IHZhbHVlPXttZXRob2R9IG9uQ2hhbmdlPXtlID0+IHNldE1ldGhvZChlLnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgbWV0aG9kKX0+PE1lbnVJdGVtIHZhbHVlPVwibWFudWFsXCI+VGjhu6cgY8O0bmcsIGPDsyB4w6FjIG5o4bqtbjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiYXBwcm92ZWRfYWRhcHRlclwiPkFkYXB0ZXIgxJHDoyDEkcaw4bujYyBkdXnhu4d0PC9NZW51SXRlbT48L1RleHRGaWVsZD57bWV0aG9kID09PSAnYXBwcm92ZWRfYWRhcHRlcicgJiYgPFRleHRGaWVsZCBsYWJlbD1cIk3DoyBhZGFwdGVyIMSRw6MgxJHGsOG7o2MgZHV54buHdFwiIHZhbHVlPXthZGFwdGVyfSBvbkNoYW5nZT17ZSA9PiBzZXRBZGFwdGVyKGUudGFyZ2V0LnZhbHVlKX0vPn08QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VOG6oW8gaOG7kyBzxqEga2jDtG5nIHThu7EgY+G6pXAgcXV54buBbiBtdWEgaG/hurdjIHRoYW5oIHRvw6FuLjwvQWxlcnQ+PC9Gb3JtRmllbGRzPjwvRWRpdERpYWxvZz5cclxuIDxFZGl0RGlhbG9nIG9wZW49eyEhc3RhdHVzSXRlbX0gdGl0bGU9XCLEkOG7lWkgdHLhuqFuZyB0aMOhaSBuaMOgIGN1bmcgY+G6pXBcIiBvbkNsb3NlPXsoKSA9PiBzZXRTdGF0dXNJdGVtKG51bGwpfSBidXN5PXtzdGF0dXMucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e2NvZGVQb2ludExlbmd0aChyZWFzb24udHJpbSgpKSA8IDUgfHwgc3RhdHVzLnBlbmRpbmcgfHwgIXN1cHBsaWVyRGV0YWlsLmRhdGEgfHwgc3VwcGxpZXJEZXRhaWwuaXNMb2FkaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGNvbnN0IGN1cnJlbnQgPSBzdXBwbGllckRldGFpbC5kYXRhPy5kYXRhOyBpZiAoIWN1cnJlbnQpXHJcbiAgICAgICAgcmV0dXJuOyB0cnkge1xyXG4gICAgICAgIGF3YWl0IHN0YXR1cy5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBjdXJyZW50LmlkIH0sIHZlcnNpb246IGN1cnJlbnQudmVyc2lvbiwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGN1cnJlbnQudmVyc2lvbiwgc3RhdHVzOiBzdGF0dXNWYWx1ZSwgcmVhc29uOiByZWFzb24udHJpbSgpIH0gfSk7XHJcbiAgICAgICAgc2V0U3RhdHVzSXRlbShudWxsKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PljDoWMgbmjhuq1uPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e3N0YXR1cy5lcnJvciB8fCBzdXBwbGllckRldGFpbC5lcnJvcn0vPjxGb3JtRmllbGRzID48VHlwb2dyYXBoeT57c3VwcGxpZXJEZXRhaWwuZGF0YT8uZGF0YS5uYW1lIHx8IHN0YXR1c0l0ZW0/Lm5hbWV9PC9UeXBvZ3JhcGh5PjxUZXh0RmllbGQgbGFiZWw9XCJUcuG6oW5nIHRow6FpXCIgc2VsZWN0IHZhbHVlPXtzdGF0dXNWYWx1ZX0gb25DaGFuZ2U9e2UgPT4gc2V0U3RhdHVzVmFsdWUoZS50YXJnZXQudmFsdWUgYXMgdHlwZW9mIHN0YXR1c1ZhbHVlKX0+PE1lbnVJdGVtIHZhbHVlPVwiYXBwcm92ZWRcIj5EdXnhu4d0IG5ow6AgY3VuZyBj4bqlcDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwic3VzcGVuZGVkXCI+VOG6oW0gZOG7q25nPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJhcmNoaXZlZFwiPk5n4burbmcgc+G7rSBk4bulbmc8L01lbnVJdGVtPjwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG9cIiB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17ZSA9PiBzZXRSZWFzb24obGltaXRDb2RlUG9pbnRzKGUudGFyZ2V0LnZhbHVlLCAxMDAwKSl9IG11bHRpbGluZSAvPjwvRm9ybUZpZWxkcz48L0VkaXREaWFsb2c+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXshIW9mZmVyU3VwcGxpZXJ9IHRpdGxlPXtgQsOhbyBnacOhIOKAlCAke29mZmVyU3VwcGxpZXI/Lm5hbWUgfHwgJyd9YH0gb25DbG9zZT17KCkgPT4gc2V0T2ZmZXJTdXBwbGllcihudWxsKX0gYnVzeT17YWRkT2ZmZXIucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFvZmZlckZvcm1WYWxpZCB8fCBhZGRPZmZlci5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGlmICghb2ZmZXJTdXBwbGllcilcclxuICAgICAgICByZXR1cm47IHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYWRkT2ZmZXIuZXhlY3V0ZSh7IGJvZHk6IHtcclxuICAgICAgICAgICAgICAgIHN1cHBsaWVySWQ6IG9mZmVyU3VwcGxpZXIuaWQsIHZhcmlhbnRJZDogdmFyaWFudCwgdW5pdENvc3Q6IHsgYW1vdW50OiBjb3N0LCBjdXJyZW5jeTogb2ZmZXJTdXBwbGllci5jdXJyZW5jeSB9LCBtaW5pbXVtUXVhbnRpdHk6IE51bWJlcihtaW5pbXVtKSwgcGFja1NpemU6IE51bWJlcihwYWNrKSwgbGVhZFRpbWVEYXlzOiBOdW1iZXIobGVhZCksIHZhbGlkVW50aWw6IG51bGxcclxuICAgICAgICAgICAgfSB9KTtcclxuICAgICAgICBzZXRPZmZlclN1cHBsaWVyKG51bGwpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+TMawdSBiw6FvIGdpw6EgbeG7m2k8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17YWRkT2ZmZXIuZXJyb3IgfHwgcHJvZHVjdHMuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+PFRleHRGaWVsZCBsYWJlbD1cIkJp4bq/biB0aOG7g1wiIHNlbGVjdCB2YWx1ZT17dmFyaWFudH0gb25DaGFuZ2U9e2UgPT4gc2V0VmFyaWFudChlLnRhcmdldC52YWx1ZSl9Pnt2YXJpYW50ICYmICFwcm9kdWN0cy5kYXRhPy5kYXRhLnNvbWUocHJvZHVjdCA9PiBwcm9kdWN0LnZhcmlhbnRzLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSB2YXJpYW50KSkgJiYgPE1lbnVJdGVtIHZhbHVlPXt2YXJpYW50fT57dmFyaWFudH08L01lbnVJdGVtPn17cHJvZHVjdHMuZGF0YT8uZGF0YS5mbGF0TWFwKHAgPT4gcC52YXJpYW50cy5tYXAodiA9PiA8TWVudUl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5pZH0+e3AubmFtZX0gwrcge3YubmFtZX0gwrcge3Yuc2t1fTwvTWVudUl0ZW0+KSl9PC9UZXh0RmllbGQ+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwic+G6o24gcGjhuqltXCIgbG9hZGVkQ291bnQ9e3Byb2R1Y3RzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtwcm9kdWN0cy5oYXNNb3JlfSBidXN5PXtwcm9kdWN0cy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtwcm9kdWN0cy5sb2FkTW9yZX0vPntwcm9kdWN0cy5pc0Vycm9yICYmIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChwcm9kdWN0cy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IHByb2R1Y3RzLmxvYWRNb3JlKCkgOiBwcm9kdWN0cy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIHPDoWNoIHPhuqNuIHBo4bqpbTwvQnV0dG9uPn08VGV4dEZpZWxkIGxhYmVsPVwiR2nDoSBuaOG6rXAgxJHGoW4gduG7i1wiIHZhbHVlPXtjb3N0fSBvbkNoYW5nZT17ZSA9PiBzZXRDb3N0KGUudGFyZ2V0LnZhbHVlKX0vPjxGaWVsZEdyb3VwIGRpcmVjdGlvbj1cInJvd1wiID48VGV4dEZpZWxkIGxhYmVsPVwiTMaw4bujbmcgdOG7kWkgdGhp4buDdVwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17bWluaW11bX0gb25DaGFuZ2U9e2UgPT4gc2V0TWluaW11bShlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgbWluOiAxLCBzdGVwOiAxIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiQuG7mWkgc+G7kSDEkcOzbmcgZ8OzaVwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17cGFja30gb25DaGFuZ2U9e2UgPT4gc2V0UGFjayhlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgbWluOiAxLCBzdGVwOiAxIH19Lz48L0ZpZWxkR3JvdXA+PFRleHRGaWVsZCBsYWJlbD1cIlRo4budaSBnaWFuIGdpYW8gKG5nw6B5KVwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17bGVhZH0gb25DaGFuZ2U9e2UgPT4gc2V0TGVhZChlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgbWluOiAwLCBzdGVwOiAxIH19Lz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gUmVwbGVuaXNobWVudFBhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgICBjb25zdCBbcGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3Qgc3VnZ2VzdGlvbnMgPSB1c2VBcGkoJ2xpc3RQdXJjaGFzZVN1Z2dlc3Rpb25zJywgeyBxdWVyeTogeyBsaW1pdDogMjAsIGN1cnNvcjogcGFyYW1zLmdldCgnc3VnZ2VzdGlvbkN1cnNvcicpIHx8IHVuZGVmaW5lZCB9IH0pO1xyXG4gICAgY29uc3QgcnVsZXMgPSB1c2VBcGkoJ2xpc3RSZW9yZGVyUnVsZXMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAyMCwgY3Vyc29yOiBwYXJhbXMuZ2V0KCdydWxlQ3Vyc29yJykgfHwgdW5kZWZpbmVkIH0gfSk7XHJcbiAgICBjb25zdCBvZmZlcnMgPSB1c2VQYWdlZEFwaSgnbGlzdFN1cHBsaWVyT2ZmZXJzJyk7XHJcbiAgICBjb25zdCBzdXBwbGllcnMgPSB1c2VQYWdlZEFwaSgnbGlzdFN1cHBsaWVycycpO1xyXG4gICAgY29uc3Qgd2FyZWhvdXNlcyA9IHVzZVBhZ2VkQXBpKCdsaXN0V2FyZWhvdXNlcycsIHsgcXVlcnk6IHsgc3RhdHVzOiAnYWN0aXZlJywgbGltaXQ6IDIwIH0gfSk7XHJcbiAgICBjb25zdCBbd2FyZWhvdXNlSWQsIHNldFdhcmVob3VzZUlkXSA9IHVzZVN0YXRlKHNob3AuZGVmYXVsdFdhcmVob3VzZUlkKTtcclxuICAgIGNvbnN0IGNhblJlYWRCdWRnZXRQb2xpY2llcyA9IHVzZUNhbignb3BlcmF0aW9ucy5yZWFkJyk7XHJcbiAgICBjb25zdCBldmFsdWF0ZSA9IHVzZUNvbW1hbmQoJ2V2YWx1YXRlUmVvcmRlcicsIFsnbGlzdFB1cmNoYXNlU3VnZ2VzdGlvbnMnLCAnbGlzdFB1cmNoYXNlT3JkZXJzJywgJ2xpc3RQdXJjaGFzZURlbGVnYXRpb25SZXNlcnZhdGlvbnMnLCAnbGlzdEJ1ZGdldFBvbGljaWVzJ10pO1xyXG4gICAgY29uc3QgcHVyY2hhc2UgPSB1c2VDb21tYW5kKCdjcmVhdGVQdXJjaGFzZU9yZGVyJywgWydsaXN0UHVyY2hhc2VPcmRlcnMnLCAnbGlzdFB1cmNoYXNlU3VnZ2VzdGlvbnMnXSk7XHJcbiAgICBjb25zdCBjcmVhdGUgPSB1c2VDb21tYW5kKCdjcmVhdGVSZW9yZGVyUnVsZScsIFsnbGlzdFJlb3JkZXJSdWxlcyddKTtcclxuICAgIGNvbnN0IHVwZGF0ZSA9IHVzZUNvbW1hbmQoJ3VwZGF0ZVJlb3JkZXJSdWxlJywgWydsaXN0UmVvcmRlclJ1bGVzJ10pO1xyXG4gICAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlKDApLCBbZWRpdCwgc2V0RWRpdF0gPSB1c2VTdGF0ZTxSZW9yZGVyUnVsZSB8IG51bGwgfCB1bmRlZmluZWQ+KCksIFtvZmZlcklkLCBzZXRPZmZlcl0gPSB1c2VTdGF0ZSgnJyksIFtyZW9yZGVyLCBzZXRSZW9yZGVyXSA9IHVzZVN0YXRlKCc1JyksIFt0YXJnZXQsIHNldFRhcmdldF0gPSB1c2VTdGF0ZSgnMjAnKSwgW3NhZmV0eSwgc2V0U2FmZXR5XSA9IHVzZVN0YXRlKCczJyksIFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPFJlb3JkZXJSdWxlWydtb2RlJ10+KCdkcmFmdF9mb3JfYXBwcm92YWwnKSwgW2VuYWJsZWQsIHNldEVuYWJsZWRdID0gdXNlU3RhdGUodHJ1ZSksIFtidWRnZXQsIHNldEJ1ZGdldF0gPSB1c2VTdGF0ZSgnJyksIFtkZWxlZ2F0aW9uSWQsIHNldERlbGVnYXRpb25JZF0gPSB1c2VTdGF0ZSgnJyksIFthdXRvQWNrLCBzZXRBdXRvQWNrXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IGNhblJlYWRBcHByb3ZhbHMgPSB1c2VDYW4oJ2FwcHJvdmFscy5yZWFkJyk7XHJcbiAgICBjb25zdCBidWRnZXRMb29rdXBzRW5hYmxlZCA9IGNhblJlYWRCdWRnZXRQb2xpY2llcyAmJiBjYW5SZWFkQXBwcm92YWxzICYmIGVkaXQgIT09IHVuZGVmaW5lZCAmJiBtb2RlID09PSAnYXV0b19zZW5kJztcclxuICAgIGNvbnN0IGJ1ZGdldHMgPSB1c2VBcGkoJ2xpc3RCdWRnZXRQb2xpY2llcycsIHt9LCBidWRnZXRMb29rdXBzRW5hYmxlZCk7XHJcbiAgICBjb25zdCBidWRnZXRBcHByb3ZhbHMgPSB1c2VBcGkoJ2xpc3RBcHByb3ZhbHMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAxMDAgfSB9LCBidWRnZXRMb29rdXBzRW5hYmxlZCk7XHJcbiAgICBjb25zdCBkZWxlZ2F0aW9ucyA9IHVzZUFwaSgnbGlzdFB1cmNoYXNlRGVsZWdhdGlvbnMnLCB7fSwgY2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmIGVkaXQgIT09IHVuZGVmaW5lZCAmJiBtb2RlID09PSAnYXV0b19zZW5kJyk7XHJcbiAgICBjb25zdCBhcHByb3ZlZFN1cHBsaWVySWRzID0gbmV3IFNldChzdXBwbGllcnMuZGF0YT8uZGF0YS5maWx0ZXIoc3VwcGxpZXIgPT4gc3VwcGxpZXIuc3RhdHVzID09PSAnYXBwcm92ZWQnKS5tYXAoc3VwcGxpZXIgPT4gc3VwcGxpZXIuaWQpIHx8IFtdKTtcclxuICAgIGNvbnN0IGVsaWdpYmxlT2ZmZXJzID0gb2ZmZXJzLmRhdGE/LmRhdGEuZmlsdGVyKG9mZmVyID0+IGFwcHJvdmVkU3VwcGxpZXJJZHMuaGFzKG9mZmVyLnN1cHBsaWVySWQpICYmIG9mZmVySXNDdXJyZW50KG9mZmVyKSkgfHwgW107XHJcbiAgICBjb25zdCBzZWxlY3RlZE9mZmVyRnJvbUxpc3QgPSBvZmZlcnMuZGF0YT8uZGF0YS5maW5kKG9mZmVyID0+IG9mZmVyLmlkID09PSBvZmZlcklkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkT2ZmZXJEZXRhaWwgPSB1c2VBcGkoJ2dldFN1cHBsaWVyT2ZmZXInLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogb2ZmZXJJZCB9IH0sICEhb2ZmZXJJZCAmJiAhc2VsZWN0ZWRPZmZlckZyb21MaXN0KTtcclxuICAgIGNvbnN0IHNlbGVjdGVkT2ZmZXIgPSBzZWxlY3RlZE9mZmVyRnJvbUxpc3QgfHwgc2VsZWN0ZWRPZmZlckRldGFpbC5kYXRhPy5kYXRhO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRTdXBwbGllckZyb21MaXN0ID0gc3VwcGxpZXJzLmRhdGE/LmRhdGEuZmluZChzdXBwbGllciA9PiBzdXBwbGllci5pZCA9PT0gc2VsZWN0ZWRPZmZlcj8uc3VwcGxpZXJJZCk7XHJcbiAgICBjb25zdCBzZWxlY3RlZFN1cHBsaWVyRGV0YWlsID0gdXNlQXBpKCdnZXRTdXBwbGllcicsIHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZE9mZmVyPy5zdXBwbGllcklkIHx8ICcnIH0gfSwgISFzZWxlY3RlZE9mZmVyPy5zdXBwbGllcklkICYmICFzZWxlY3RlZFN1cHBsaWVyRnJvbUxpc3QpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRTdXBwbGllciA9IHNlbGVjdGVkU3VwcGxpZXJGcm9tTGlzdCB8fCBzZWxlY3RlZFN1cHBsaWVyRGV0YWlsLmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBzZWxlY3RlZE9mZmVyRWxpZ2libGUgPSAhIXNlbGVjdGVkT2ZmZXIgJiYgc2VsZWN0ZWRTdXBwbGllcj8uc3RhdHVzID09PSAnYXBwcm92ZWQnICYmIG9mZmVySXNDdXJyZW50KHNlbGVjdGVkT2ZmZXIpO1xyXG4gICAgY29uc3QgYXBwcm92ZWRCdWRnZXRzID0gYnVkZ2V0cy5kYXRhPy5kYXRhLmZpbHRlcihpdGVtID0+IGl0ZW0ua2luZCA9PT0gJ3Byb2N1cmVtZW50JyAmJiBpdGVtLmVuYWJsZWQgJiYgISFpdGVtLmxpbWl0QW1vdW50ICYmICEhaXRlbS5hcHByb3ZhbElkICYmICEhYnVkZ2V0QXBwcm92YWxzLmRhdGE/Lm1ldGEuYXNPZiAmJiBidWRnZXRBcHByb3ZhbHMuZGF0YS5kYXRhLnNvbWUoYXBwcm92YWwgPT4gYXBwcm92YWwuaWQgPT09IGl0ZW0uYXBwcm92YWxJZCAmJiBhcHByb3ZhbC5zdGF0dXMgPT09ICdhcHByb3ZlZCcgJiYgYXBwcm92YWwucmVzb3VyY2UudHlwZSA9PT0gJ2J1ZGdldF9wb2xpY3knICYmIGFwcHJvdmFsLnJlc291cmNlLmlkID09PSBpdGVtLmlkICYmIGFwcHJvdmFsLnJlc291cmNlVmVyc2lvbiA9PT0gaXRlbS52ZXJzaW9uICYmIERhdGUucGFyc2UoYXBwcm92YWwuZXhwaXJlc0F0KSA+IERhdGUucGFyc2UoYnVkZ2V0QXBwcm92YWxzLmRhdGE/Lm1ldGEuYXNPZiB8fCAnJykpKSB8fCBbXTtcclxuICAgIGNvbnN0IGVsaWdpYmxlRGVsZWdhdGlvbnMgPSAoZGVsZWdhdGlvbnMuZGF0YT8uZGF0YSBhcyBQdXJjaGFzZURlbGVnYXRpb25bXSB8IHVuZGVmaW5lZCk/LmZpbHRlcihncmFudCA9PiBncmFudC5zdGF0dXMgPT09ICdhY3RpdmUnICYmIERhdGUucGFyc2UoZ3JhbnQuZXhwaXJlc0F0KSA+IERhdGUubm93KCkgJiYgZ3JhbnQuc3VwcGxpZXJJZCA9PT0gc2VsZWN0ZWRPZmZlcj8uc3VwcGxpZXJJZCAmJiBncmFudC53YXJlaG91c2VJZCA9PT0gd2FyZWhvdXNlSWQgJiYgZ3JhbnQuYnVkZ2V0UG9saWN5SWQgPT09IGJ1ZGdldCAmJiBncmFudC5vZmZlclNuYXBzaG90cy5zb21lKHNuYXBzaG90ID0+IHNuYXBzaG90LnN1cHBsaWVyT2ZmZXJJZCA9PT0gb2ZmZXJJZCAmJiBzbmFwc2hvdC5vZmZlclZlcnNpb24gPT09IHNlbGVjdGVkT2ZmZXI/LnZlcnNpb24gJiYgc25hcHNob3QudW5pdENvc3QuYW1vdW50ID09PSBzZWxlY3RlZE9mZmVyPy51bml0Q29zdC5hbW91bnQgJiYgc25hcHNob3QudW5pdENvc3QuY3VycmVuY3kgPT09IHNlbGVjdGVkT2ZmZXI/LnVuaXRDb3N0LmN1cnJlbmN5ICYmIHNuYXBzaG90Lm1pbmltdW1RdWFudGl0eSA9PT0gc2VsZWN0ZWRPZmZlcj8ubWluaW11bVF1YW50aXR5ICYmIHNuYXBzaG90LnBhY2tTaXplID09PSBzZWxlY3RlZE9mZmVyPy5wYWNrU2l6ZSkpIHx8IFtdO1xyXG4gICAgY29uc3QgYnVkZ2V0VmVyaWZpZWQgPSBtb2RlICE9PSAnYXV0b19zZW5kJyB8fCAoYnVkZ2V0TG9va3Vwc0VuYWJsZWQgJiYgIWJ1ZGdldHMuaXNQZW5kaW5nICYmICFidWRnZXRzLmlzRXJyb3IgJiYgIWJ1ZGdldEFwcHJvdmFscy5pc1BlbmRpbmcgJiYgIWJ1ZGdldEFwcHJvdmFscy5pc0Vycm9yICYmIGFwcHJvdmVkQnVkZ2V0cy5zb21lKGl0ZW0gPT4gaXRlbS5pZCA9PT0gYnVkZ2V0KSk7XHJcbiAgICBjb25zdCBkZWxlZ2F0aW9uVmVyaWZpZWQgPSBtb2RlICE9PSAnYXV0b19zZW5kJyB8fCAoY2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmICFkZWxlZ2F0aW9ucy5pc1BlbmRpbmcgJiYgIWRlbGVnYXRpb25zLmlzRXJyb3IgJiYgZWxpZ2libGVEZWxlZ2F0aW9ucy5zb21lKGl0ZW0gPT4gaXRlbS5pZCA9PT0gZGVsZWdhdGlvbklkKSk7XHJcbiAgICBjb25zdCBydWxlRm9ybVZhbGlkID0gc2VsZWN0ZWRPZmZlckVsaWdpYmxlICYmIHdhcmVob3VzZXMuZGF0YT8uZGF0YS5zb21lKHdhcmVob3VzZSA9PiB3YXJlaG91c2UuaWQgPT09IHdhcmVob3VzZUlkKSAmJiBOdW1iZXIuaXNJbnRlZ2VyKE51bWJlcihyZW9yZGVyKSkgJiYgTnVtYmVyKHJlb3JkZXIpID49IDAgJiYgTnVtYmVyLmlzSW50ZWdlcihOdW1iZXIodGFyZ2V0KSkgJiYgTnVtYmVyKHRhcmdldCkgPj0gTnVtYmVyKHJlb3JkZXIpICYmIE51bWJlci5pc0ludGVnZXIoTnVtYmVyKHNhZmV0eSkpICYmIE51bWJlcihzYWZldHkpID49IDAgJiYgKG1vZGUgIT09ICdhdXRvX3NlbmQnIHx8IChidWRnZXRWZXJpZmllZCAmJiBkZWxlZ2F0aW9uVmVyaWZpZWQgJiYgYXV0b0FjaykpO1xyXG4gICAgY29uc3Qgb3BlbiA9IChyOiBSZW9yZGVyUnVsZSB8IG51bGwpID0+IHsgc2V0RWRpdChyKTsgc2V0V2FyZWhvdXNlSWQocj8ud2FyZWhvdXNlSWQgfHwgc2hvcC5kZWZhdWx0V2FyZWhvdXNlSWQpOyBzZXRPZmZlcihyPy5zdXBwbGllck9mZmVySWQgfHwgJycpOyBzZXRSZW9yZGVyKFN0cmluZyhyPy5yZW9yZGVyUG9pbnQgPz8gNSkpOyBzZXRUYXJnZXQoU3RyaW5nKHI/LnRhcmdldFF1YW50aXR5ID8/IDIwKSk7IHNldFNhZmV0eShTdHJpbmcocj8uc2FmZXR5U3RvY2sgPz8gMykpOyBzZXRNb2RlKHI/Lm1vZGUgfHwgJ2RyYWZ0X2Zvcl9hcHByb3ZhbCcpOyBzZXRFbmFibGVkKHI/LmVuYWJsZWQgPz8gdHJ1ZSk7IHNldEJ1ZGdldChyPy5idWRnZXRQb2xpY3lJZCB8fCAnJyk7IHNldERlbGVnYXRpb25JZChyPy5wdXJjaGFzZURlbGVnYXRpb25JZCB8fCAnJyk7IHNldEF1dG9BY2soZmFsc2UpOyB9O1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJOaOG6rXAgbOG6oWkgaMOgbmdcIiBzdWJ0aXRsZT1cIlRy4burIGjDoG5nIMSRw6MgxJHhurd0IHRyxrDhu5tjIGtoaSDEkeG7gSB4deG6pXQgbXVhIHRow6ptLiBU4buxIGfhu61pIMSRxqFuIGNo4buJIGtoaSDEkcaw4bujYyBi4bqtdCB2w6AgxJHhu6cgaOG6oW4gbeG7qWMuXCIgYWN0aW9ucz17PD48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByb2N1cmVtZW50Lm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IG9wZW4obnVsbCl9PlRow6ptIHF1eSB04bqvYzwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC53cml0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtldmFsdWF0ZS5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIGV2YWx1YXRlLmV4ZWN1dGUoKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpfT7EkMOhbmggZ2nDoSBuaHUgY+G6p3Ugbmjhuq1wPC9NdXRhdGlvbkJ1dHRvbj48Lz59Lz48RXJyb3JOb3RpY2UgZXJyb3I9e2V2YWx1YXRlLmVycm9yIHx8IHB1cmNoYXNlLmVycm9yfS8+PFRhYnMgdmFsdWU9e3RhYn0gb25DaGFuZ2U9eyhfLCB2OiBudW1iZXIpID0+IHNldFRhYih2KX0gc3g9e2xheW91dFN4LnBhZ2Uuc2VjdGlvbkFmdGVyfT48VGFiIGxhYmVsPVwixJDhu4Egbmdo4buLIG5o4bqtcFwiLz48VGFiIGxhYmVsPVwiUXV5IHThuq9jIHRoZW8gU0tVXCIvPjwvVGFicz57dGFiID09PSAwID8gPFBhbmVsPjxGaWVsZEdyb3VwIGJvZHlNb2RlPVwidG9vbGJhclwiPjxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogXCJjb2x1bW5cIiwgc206IFwicm93XCIgfX0gPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImLDoW8gZ2nDoVwiIGxvYWRlZENvdW50PXtvZmZlcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e29mZmVycy5oYXNNb3JlfSBidXN5PXtvZmZlcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17b2ZmZXJzLmxvYWRNb3JlfS8+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwibmjDoCBjdW5nIGPhuqVwXCIgbG9hZGVkQ291bnQ9e3N1cHBsaWVycy5sb2FkZWRDb3VudH0gaGFzTW9yZT17c3VwcGxpZXJzLmhhc01vcmV9IGJ1c3k9e3N1cHBsaWVycy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXtzdXBwbGllcnMubG9hZE1vcmV9Lz48L0ZpZWxkR3JvdXA+eyhvZmZlcnMuaGFzTW9yZSB8fCBzdXBwbGllcnMuaGFzTW9yZSkgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPsSQYW5nIHThuqNpIHThu6tuZyBwaOG6p24gYsOhbyBnacOhL25ow6AgY3VuZyBj4bqlcC4gSMOjeSB04bqjaSB0aMOqbSB0csaw4bubYyBraGkgeMOhYyBuaOG6rW4gY8OhYyDEkeG7gSB4deG6pXQgbuG6sW0gbmdvw6BpIHBo4bqnbiDEkcOjIHThuqNpLjwvQWxlcnQ+fXtvZmZlcnMuaXNQZW5kaW5nICYmIDxUeXBvZ3JhcGh5IHJvbGU9XCJzdGF0dXNcIj7EkGFuZyB04bqjaSBkYW5oIHPDoWNoIGLDoW8gZ2nDoeKApjwvVHlwb2dyYXBoeT59e29mZmVycy5pc0Vycm9yICYmIDxGaWVsZEdyb3VwIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJUcuG6oW5nIHRow6FpIGRhbmggc8OhY2ggYsOhbyBnacOhXCIgPjxFcnJvck5vdGljZSBlcnJvcj17b2ZmZXJzLmVycm9yfS8+e2NhblJldHJ5TG9va3VwKG9mZmVycy5lcnJvcikgJiYgPEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgKG9mZmVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IG9mZmVycy5sb2FkTW9yZSgpIDogb2ZmZXJzLnJlZmV0Y2goKSk7IH19PlRo4butIGzhuqFpIGRhbmggc8OhY2ggYsOhbyBnacOhPC9CdXR0b24+fTwvRmllbGRHcm91cD59eyFvZmZlcnMuaXNQZW5kaW5nICYmICFvZmZlcnMuaXNFcnJvciAmJiBvZmZlcnMubG9hZGVkQ291bnQgPT09IDAgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPkNoxrBhIGPDsyBiw6FvIGdpw6EgdHJvbmcgZGFuaCBzw6FjaCDEkcOjIHThuqNpLjwvVHlwb2dyYXBoeT59e3N1cHBsaWVycy5pc1BlbmRpbmcgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPsSQYW5nIHThuqNpIGRhbmggc8OhY2ggbmjDoCBjdW5nIGPhuqVw4oCmPC9UeXBvZ3JhcGh5Pn17c3VwcGxpZXJzLmlzRXJyb3IgJiYgPEZpZWxkR3JvdXAgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlRy4bqhbmcgdGjDoWkgZGFuaCBzw6FjaCBuaMOgIGN1bmcgY+G6pXBcIiA+PEVycm9yTm90aWNlIGVycm9yPXtzdXBwbGllcnMuZXJyb3J9Lz57Y2FuUmV0cnlMb29rdXAoc3VwcGxpZXJzLmVycm9yKSAmJiA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAoc3VwcGxpZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gc3VwcGxpZXJzLmxvYWRNb3JlKCkgOiBzdXBwbGllcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCBuaMOgIGN1bmcgY+G6pXA8L0J1dHRvbj59PC9GaWVsZEdyb3VwPn17IXN1cHBsaWVycy5pc1BlbmRpbmcgJiYgIXN1cHBsaWVycy5pc0Vycm9yICYmIHN1cHBsaWVycy5sb2FkZWRDb3VudCA9PT0gMCAmJiA8VHlwb2dyYXBoeSByb2xlPVwic3RhdHVzXCI+Q2jGsGEgY8OzIG5ow6AgY3VuZyBj4bqlcCB0cm9uZyBkYW5oIHPDoWNoIMSRw6MgdOG6o2kuPC9UeXBvZ3JhcGh5Pn08L0ZpZWxkR3JvdXA+PFF1ZXJ5U3RhdGUgcXVlcnk9e3N1Z2dlc3Rpb25zfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57c3VnZ2VzdGlvbnMuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCLEkOG7gSBuZ2jhu4sgbmjhuq1wIGjDoG5nXCIgcm93cz17c3VnZ2VzdGlvbnMuZGF0YS5kYXRhfSByb3dLZXk9e3IgPT4gci5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnc2t1JywgbGFiZWw6ICdCaeG6v24gdGjhu4MnLCByZW5kZXI6IHIgPT4gYE3DoyBiaeG6v24gdGjhu4M6ICR7ci52YXJpYW50SWR9YCB9LCB7IGtleTogJ3N1cHBsaWVyJywgbGFiZWw6ICdOaMOgIGN1bmcgY+G6pXAnLCByZW5kZXI6IHIgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBvZmZlciA9IG9mZmVycy5kYXRhPy5kYXRhLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSByLnN1cHBsaWVyT2ZmZXJJZCk7XHJcbiAgICAgICAgICAgIGlmICghb2ZmZXIpIHJldHVybiBvZmZlcnMuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIGLDoW8gZ2nDoeKApicgOiBvZmZlcnMuaXNFcnJvciA/ICdLaMO0bmcgeMOhYyBtaW5oIMSRxrDhu6NjIGLDoW8gZ2nDoScgOiBvZmZlcnMuaGFzTW9yZSA/ICdU4bqjaSB0aMOqbSBiw6FvIGdpw6EgxJHhu4MgeMOhYyBtaW5oJyA6ICdLaMO0bmcgdMOsbSB0aOG6pXkgYsOhbyBnacOhIHRyb25nIGRhbmggc8OhY2ggxJHDoyB04bqjaSc7XHJcbiAgICAgICAgICAgIGNvbnN0IHN1cHBsaWVyID0gc3VwcGxpZXJzLmRhdGE/LmRhdGEuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IG9mZmVyLnN1cHBsaWVySWQpO1xyXG4gICAgICAgICAgICBpZiAoIXN1cHBsaWVyKSByZXR1cm4gc3VwcGxpZXJzLmlzUGVuZGluZyA/ICfEkGFuZyB04bqjaSBuaMOgIGN1bmcgY+G6pXDigKYnIDogc3VwcGxpZXJzLmlzRXJyb3IgPyAnS2jDtG5nIHjDoWMgbWluaCDEkcaw4bujYyBuaMOgIGN1bmcgY+G6pXAnIDogc3VwcGxpZXJzLmhhc01vcmUgPyAnVOG6o2kgdGjDqm0gbmjDoCBjdW5nIGPhuqVwIMSR4buDIHjDoWMgbWluaCcgOiAnS2jDtG5nIHTDrG0gdGjhuqV5IG5ow6AgY3VuZyBj4bqlcCB0cm9uZyBkYW5oIHPDoWNoIMSRw6MgdOG6o2knO1xyXG4gICAgICAgICAgICBpZiAoc3VwcGxpZXIuc3RhdHVzICE9PSAnYXBwcm92ZWQnKSByZXR1cm4gc3VwcGxpZXIubmFtZSArICcgwrcgY2jGsGEgxJHGsOG7o2MgZHV54buHdCc7XHJcbiAgICAgICAgICAgIHJldHVybiBzdXBwbGllci5uYW1lO1xyXG4gICAgICAgIH0gfSwgeyBrZXk6ICdhdmFpbGFibGUnLCBsYWJlbDogJ0PDsyB0aOG7gyBiw6FuJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogciA9PiByLmF2YWlsYWJsZSB9LCB7IGtleTogJ2luY29taW5nJywgbGFiZWw6ICfEkGFuZyB24buBJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogciA9PiByLmNvbmZpcm1lZEluYm91bmQgfSwgeyBrZXk6ICdwcm9wb3NlZCcsIGxhYmVsOiAnxJDDoyDEkeG7gSB4deG6pXQnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByID0+IHIub3BlblByb3Bvc2FsUXVhbnRpdHkgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ3F0eScsIGxhYmVsOiAnTsOqbiBuaOG6rXAnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByID0+IDxUeXBvZ3JhcGh5IGNvbG9yPVwicHJpbWFyeS5tYWluXCIgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LmJvbGR9PntyLnN1Z2dlc3RlZFF1YW50aXR5fTwvVHlwb2dyYXBoeT5cclxuICAgICAgICB9LFxyXG4gICAgICAgIHsga2V5OiAncmVhc29uJywgbGFiZWw6ICdDxINuIGPhu6knLCByZW5kZXI6IHIgPT4gPFN0YWNrPjxUeXBvZ3JhcGh5PntyLnJlYXNvbn08L1R5cG9ncmFwaHk+e3IuYXV0b1NlbmRTdGF0dXMgJiYgci5hdXRvU2VuZFN0YXR1cyAhPT0gJ25vdF9hdHRlbXB0ZWQnICYmIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCI+VOG7sSBn4butaToge3IuYXV0b1NlbmRTdGF0dXN9e3IuYXV0b1NlbmRSZWFzb24gPyBgIMK3ICR7ci5hdXRvU2VuZFJlYXNvbn1gIDogJyd9PC9UeXBvZ3JhcGh5Pn08L1N0YWNrPiB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHIgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC53cml0ZVwiIGRpc2FibGVkPXshIXIuYWN0aXZlUHVyY2hhc2VPcmRlcklkIHx8IHIuc3VnZ2VzdGVkUXVhbnRpdHkgPD0gMCB8fCAhZWxpZ2libGVPZmZlcnMuc29tZShvZmZlciA9PiBvZmZlci5pZCA9PT0gci5zdXBwbGllck9mZmVySWQpfSBidXN5PXtwdXJjaGFzZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGNvbnN0IG8gPSBlbGlnaWJsZU9mZmVycy5maW5kKG8gPT4gby5pZCA9PT0gci5zdXBwbGllck9mZmVySWQpOyBpZiAoIW8pXHJcbiAgICAgICAgICAgICAgICByZXR1cm47IHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBwdXJjaGFzZS5leGVjdXRlKHsgYm9keToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdXBwbGllcklkOiBvLnN1cHBsaWVySWQsIHdhcmVob3VzZUlkOiByLndhcmVob3VzZUlkLCBzdWdnZXN0aW9uSWQ6IHIuaWQsIGxpbmVzOiBbeyB2YXJpYW50SWQ6IHIudmFyaWFudElkLCBzdXBwbGllck9mZmVySWQ6IG8uaWQsIHF1YW50aXR5OiByLnN1Z2dlc3RlZFF1YW50aXR5IH1dXHJcbiAgICAgICAgICAgICAgICAgICAgfSB9KTtcclxuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvcy8ke3Nob3AuaWR9L3B1cmNoYXNlc2ApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19Pkzhuq1wIMSRxqFuIG5ow6FwPC9NdXRhdGlvbkJ1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e3N1Z2dlc3Rpb25zLmRhdGEucGFnZX0gY3Vyc29yUGFyYW09XCJzdWdnZXN0aW9uQ3Vyc29yXCIvPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD4gOiA8UGFuZWw+PFF1ZXJ5U3RhdGUgcXVlcnk9e3J1bGVzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57cnVsZXMuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJDaMOtbmggc8OhY2ggYuG7lSBzdW5nIGjDoG5nXCIgcm93cz17cnVsZXMuZGF0YS5kYXRhfSByb3dLZXk9e3IgPT4gci5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnc2t1JywgbGFiZWw6ICdCaeG6v24gdGjhu4MnLCByZW5kZXI6IHIgPT4gYE3DoyBiaeG6v24gdGjhu4M6ICR7ci52YXJpYW50SWR9YCB9LCB7IGtleTogJ3RocmVzaG9sZCcsIGxhYmVsOiAnTmfGsOG7oW5nIC8gTeG7pWMgdGnDqnUnLCByZW5kZXI6IHIgPT4gYCR7ci5yZW9yZGVyUG9pbnR9IC8gJHtyLnRhcmdldFF1YW50aXR5fWAgfSwgeyBrZXk6ICdzYWZldHknLCBsYWJlbDogJ1Thu5NuIGFuIHRvw6BuJywgcmVuZGVyOiByID0+IHIuc2FmZXR5U3RvY2sgfSwgeyBrZXk6ICdtb2RlJywgbGFiZWw6ICdN4bupYyB04buxIMSR4buZbmcnLCByZW5kZXI6IHIgPT4gPFN0YXR1cyB2YWx1ZT17ci5tb2RlfS8+IH0sIHsga2V5OiAnZW5hYmxlZCcsIGxhYmVsOiAnQuG6rXQnLCByZW5kZXI6IHIgPT4gci5lbmFibGVkID8gJ0PDsycgOiAnQ2jGsGEgYuG6rXQnIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6ICdlZGl0JywgbGFiZWw6ICcnLCByZW5kZXI6IHIgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC5tYW5hZ2VcIiBvbkNsaWNrPXsoKSA9PiBvcGVuKHIpfT5DaOG7iW5oIHF1eSB04bqvYzwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgfVxyXG4gICAgXX0vPjxQYWdlciBwYWdlPXtydWxlcy5kYXRhLnBhZ2V9IGN1cnNvclBhcmFtPVwicnVsZUN1cnNvclwiLz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+fVxyXG4gPEVkaXREaWFsb2cgYWxsb3dFZGl0c1doaWxlQnVzeSBvcGVuPXtlZGl0ICE9PSB1bmRlZmluZWR9IHRpdGxlPVwiUXV5IHThuq9jIG5o4bqtcCBs4bqhaVwiIG9uQ2xvc2U9eygpID0+IHNldEVkaXQodW5kZWZpbmVkKX0gYnVzeT17Y3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshcnVsZUZvcm1WYWxpZCB8fCBjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyBjb25zdCBvID0gc2VsZWN0ZWRPZmZlckVsaWdpYmxlID8gc2VsZWN0ZWRPZmZlciA6IHVuZGVmaW5lZDsgaWYgKCFvKVxyXG4gICAgICAgIHJldHVybjsgY29uc3QgYm9keSA9IHtcclxuICAgICAgICB2YXJpYW50SWQ6IG8udmFyaWFudElkLCB3YXJlaG91c2VJZCwgc3VwcGxpZXJPZmZlcklkOiBvZmZlcklkLCByZW9yZGVyUG9pbnQ6IE51bWJlcihyZW9yZGVyKSwgdGFyZ2V0UXVhbnRpdHk6IE51bWJlcih0YXJnZXQpLCBzYWZldHlTdG9jazogTnVtYmVyKHNhZmV0eSksIG1vZGUsIGVuYWJsZWQsIGJ1ZGdldFBvbGljeUlkOiBidWRnZXQgfHwgbnVsbCwgcHVyY2hhc2VEZWxlZ2F0aW9uSWQ6IG1vZGUgPT09ICdhdXRvX3NlbmQnID8gZGVsZWdhdGlvbklkIDogbnVsbFxyXG4gICAgfTsgdHJ5IHtcclxuICAgICAgICBpZiAoZWRpdClcclxuICAgICAgICAgICAgYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IGVkaXQuaWQgfSwgYm9keTogeyAuLi5ib2R5LCBleHBlY3RlZFZlcnNpb246IGVkaXQudmVyc2lvbiB9IH0pO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5IH0pO1xyXG4gICAgICAgIHNldEVkaXQodW5kZWZpbmVkKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PkzGsHUgcXV5IHThuq9jPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz57b2ZmZXJJZCAmJiBzZWxlY3RlZE9mZmVyRGV0YWlsLmlzUGVuZGluZyAmJiAhc2VsZWN0ZWRPZmZlciAmJiA8VHlwb2dyYXBoeSByb2xlPVwic3RhdHVzXCI+xJBhbmcgdOG6o2kgYsOhbyBnacOhIMSRw6MgY2jhu41u4oCmPC9UeXBvZ3JhcGh5Pn17c2VsZWN0ZWRPZmZlckRldGFpbC5pc0Vycm9yICYmIDxGaWVsZEdyb3VwIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJUcuG6oW5nIHRow6FpIGLDoW8gZ2nDoSDEkcOjIGNo4buNblwiID48RXJyb3JOb3RpY2UgZXJyb3I9e3NlbGVjdGVkT2ZmZXJEZXRhaWwuZXJyb3J9Lz57Y2FuUmV0cnlMb29rdXAoc2VsZWN0ZWRPZmZlckRldGFpbC5lcnJvcikgJiYgPEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgc2VsZWN0ZWRPZmZlckRldGFpbC5yZWZldGNoKCk7IH19PlRo4butIGzhuqFpIGLDoW8gZ2nDoSDEkcOjIGNo4buNbjwvQnV0dG9uPn08L0ZpZWxkR3JvdXA+fXtzZWxlY3RlZE9mZmVyPy5zdXBwbGllcklkICYmIHNlbGVjdGVkU3VwcGxpZXJEZXRhaWwuaXNQZW5kaW5nICYmICFzZWxlY3RlZFN1cHBsaWVyICYmIDxUeXBvZ3JhcGh5IHJvbGU9XCJzdGF0dXNcIj7EkGFuZyB04bqjaSBuaMOgIGN1bmcgY+G6pXAgxJHDoyBjaOG7jW7igKY8L1R5cG9ncmFwaHk+fXtzZWxlY3RlZFN1cHBsaWVyRGV0YWlsLmlzRXJyb3IgJiYgPEZpZWxkR3JvdXAgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlRy4bqhbmcgdGjDoWkgbmjDoCBjdW5nIGPhuqVwIMSRw6MgY2jhu41uXCIgPjxFcnJvck5vdGljZSBlcnJvcj17c2VsZWN0ZWRTdXBwbGllckRldGFpbC5lcnJvcn0vPntjYW5SZXRyeUxvb2t1cChzZWxlY3RlZFN1cHBsaWVyRGV0YWlsLmVycm9yKSAmJiA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCBzZWxlY3RlZFN1cHBsaWVyRGV0YWlsLnJlZmV0Y2goKTsgfX0+VGjhu60gbOG6oWkgbmjDoCBjdW5nIGPhuqVwIMSRw6MgY2jhu41uPC9CdXR0b24+fTwvRmllbGRHcm91cD59e29mZmVycy5pc1BlbmRpbmcgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPsSQYW5nIHThuqNpIGRhbmggc8OhY2ggYsOhbyBnacOh4oCmPC9UeXBvZ3JhcGh5Pn17b2ZmZXJzLmlzRXJyb3IgJiYgPEZpZWxkR3JvdXAgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlRy4bqhbmcgdGjDoWkgZGFuaCBzw6FjaCBiw6FvIGdpw6EgdHJvbmcgcXV5IHThuq9jXCIgPjxFcnJvck5vdGljZSBlcnJvcj17b2ZmZXJzLmVycm9yfS8+e2NhblJldHJ5TG9va3VwKG9mZmVycy5lcnJvcikgJiYgPEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgKG9mZmVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IG9mZmVycy5sb2FkTW9yZSgpIDogb2ZmZXJzLnJlZmV0Y2goKSk7IH19PlRo4butIGzhuqFpIGRhbmggc8OhY2ggYsOhbyBnacOhPC9CdXR0b24+fTwvRmllbGRHcm91cD59e3N1cHBsaWVycy5pc1BlbmRpbmcgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPsSQYW5nIHThuqNpIGRhbmggc8OhY2ggbmjDoCBjdW5nIGPhuqVw4oCmPC9UeXBvZ3JhcGh5Pn17c3VwcGxpZXJzLmlzRXJyb3IgJiYgPEZpZWxkR3JvdXAgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIlRy4bqhbmcgdGjDoWkgZGFuaCBzw6FjaCBuaMOgIGN1bmcgY+G6pXAgdHJvbmcgcXV5IHThuq9jXCIgPjxFcnJvck5vdGljZSBlcnJvcj17c3VwcGxpZXJzLmVycm9yfS8+e2NhblJldHJ5TG9va3VwKHN1cHBsaWVycy5lcnJvcikgJiYgPEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgKHN1cHBsaWVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IHN1cHBsaWVycy5sb2FkTW9yZSgpIDogc3VwcGxpZXJzLnJlZmV0Y2goKSk7IH19PlRo4butIGzhuqFpIGRhbmggc8OhY2ggbmjDoCBjdW5nIGPhuqVwPC9CdXR0b24+fTwvRmllbGRHcm91cD59PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiS2hvIG5o4bqtcCBs4bqhaVwiIHZhbHVlPXt3YXJlaG91c2VJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFdhcmVob3VzZUlkKGV2ZW50LnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXtjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30+e3dhcmVob3VzZUlkICYmICF3YXJlaG91c2VzLmRhdGE/LmRhdGEuc29tZSh3YXJlaG91c2UgPT4gd2FyZWhvdXNlLmlkID09PSB3YXJlaG91c2VJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXt3YXJlaG91c2VJZH0+xJBhbmcgZ2nhu68ga2hvIHt3YXJlaG91c2VJZH07IHThuqNpIGRhbmggbeG7pWMgxJHhu4Mga2nhu4NtIHRyYTwvTWVudUl0ZW0+fXt3YXJlaG91c2VzLmRhdGE/LmRhdGEubWFwKHdhcmVob3VzZSA9PiA8TWVudUl0ZW0ga2V5PXt3YXJlaG91c2UuaWR9IHZhbHVlPXt3YXJlaG91c2UuaWR9Pnt3YXJlaG91c2UuY29kZX0gwrcge3dhcmVob3VzZS5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJraG8gbmjhuq1wIGzhuqFpXCIgbG9hZGVkQ291bnQ9e3dhcmVob3VzZXMubG9hZGVkQ291bnR9IGhhc01vcmU9e3dhcmVob3VzZXMuaGFzTW9yZX0gYnVzeT17d2FyZWhvdXNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXt3YXJlaG91c2VzLmxvYWRNb3JlfS8+PEVycm9yTm90aWNlIGVycm9yPXt3YXJlaG91c2VzLmVycm9yfS8+PFRleHRGaWVsZCBsYWJlbD1cIkLDoW8gZ2nDoSAvIFNLVVwiIHNlbGVjdCB2YWx1ZT17b2ZmZXJJZH0gb25DaGFuZ2U9e2UgPT4gc2V0T2ZmZXIoZS50YXJnZXQudmFsdWUpfT57b2ZmZXJJZCAmJiAhb2ZmZXJzLmRhdGE/LmRhdGEuc29tZShvZmZlciA9PiBvZmZlci5pZCA9PT0gb2ZmZXJJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXtvZmZlcklkfT57c2VsZWN0ZWRPZmZlckRldGFpbC5pc1BlbmRpbmcgPyBcIsSQYW5nIHThuqNpIGLDoW8gZ2nDoSDEkcOjIGNo4buNbuKAplwiIDogc2VsZWN0ZWRPZmZlckRldGFpbC5pc0Vycm9yID8gXCJLaMO0bmcgdGjhu4MgdOG6o2kgYsOhbyBnacOhIMSRw6MgY2jhu41uXCIgOiBzZWxlY3RlZE9mZmVyPy52YXJpYW50SWQgfHwgc2VsZWN0ZWRPZmZlcj8uaWQgfHwgXCJLaMO0bmcgdMOsbSB0aOG6pXkgYsOhbyBnacOhIMSRw6MgY2jhu41uXCJ9PC9NZW51SXRlbT59e2VsaWdpYmxlT2ZmZXJzLm1hcChvID0+IDxNZW51SXRlbSBrZXk9e28uaWR9IHZhbHVlPXtvLmlkfT57by52YXJpYW50SWR9IMK3IHtvLnN1cHBsaWVySWR9IMK3IHtvLnVuaXRDb3N0LmFtb3VudH0ge28udW5pdENvc3QuY3VycmVuY3l9IMK3IE1PUSB7by5taW5pbXVtUXVhbnRpdHl9IC8gcXV5IGPDoWNoIHtvLnBhY2tTaXplfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJiw6FvIGdpw6FcIiBsb2FkZWRDb3VudD17b2ZmZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtvZmZlcnMuaGFzTW9yZX0gYnVzeT17b2ZmZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e29mZmVycy5sb2FkTW9yZX0vPjxGaWVsZEdyb3VwIGRpcmVjdGlvbj1cInJvd1wiID48VGV4dEZpZWxkIGxhYmVsPVwiTmfGsOG7oW5nIG5o4bqtcFwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17cmVvcmRlcn0gb25DaGFuZ2U9e2UgPT4gc2V0UmVvcmRlcihlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgbWluOiAwLCBzdGVwOiAxIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiTmjhuq1wIHThu5tpXCIgdHlwZT1cIm51bWJlclwiIHZhbHVlPXt0YXJnZXR9IG9uQ2hhbmdlPXtlID0+IHNldFRhcmdldChlLnRhcmdldC52YWx1ZSl9IGlucHV0UHJvcHM9e3sgbWluOiBNYXRoLm1heCgwLCBOdW1iZXIocmVvcmRlcikgfHwgMCksIHN0ZXA6IDEgfX0gZXJyb3I9e051bWJlci5pc0Zpbml0ZShOdW1iZXIodGFyZ2V0KSkgJiYgTnVtYmVyKHRhcmdldCkgPCBOdW1iZXIocmVvcmRlcil9Lz48VGV4dEZpZWxkIGxhYmVsPVwiVOG7k24gYW4gdG/DoG5cIiB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e3NhZmV0eX0gb25DaGFuZ2U9e2UgPT4gc2V0U2FmZXR5KGUudGFyZ2V0LnZhbHVlKX0gaW5wdXRQcm9wcz17eyBtaW46IDAsIHN0ZXA6IDEgfX0vPjwvRmllbGRHcm91cD48VGV4dEZpZWxkIGxhYmVsPVwiTeG7qWMgdOG7sSDEkeG7mW5nXCIgc2VsZWN0IHZhbHVlPXttb2RlfSBvbkNoYW5nZT17ZSA9PiB7IHNldE1vZGUoZS50YXJnZXQudmFsdWUgYXMgdHlwZW9mIG1vZGUpOyBzZXREZWxlZ2F0aW9uSWQoJycpOyB9fT48TWVudUl0ZW0gdmFsdWU9XCJub3RpZnlfb25seVwiPjEgwrcgQ2jhu4kgY+G6o25oIGLDoW88L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cImRyYWZ0X2Zvcl9hcHByb3ZhbFwiPjIgwrcgTOG6rXAgbmjDoXAgY2jhu50gZHV54buHdDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiYXV0b19zZW5kXCI+MyDCtyBU4buxIGfhu61pIHRyb25nIGjhuqFuIG3hu6ljPC9NZW51SXRlbT48L1RleHRGaWVsZD57bW9kZSA9PT0gJ2F1dG9fc2VuZCcgJiYgPD48QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+V29ya2VyIE1TVyBsb2NhbCBnaGkgbmjhuq1uIGvhur90IHF14bqjIHjDoWMgxJHhu4tuaDsga2jDtG5nIGfhu41pIEFJLCBuaMOgIGN1bmcgY+G6pXAgaG/hurdjIGThu4tjaCB24bulIHRoYW5oIHRvw6FuLjwvQWxlcnQ+eyFjYW5SZWFkQnVkZ2V0UG9saWNpZXMgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBraMO0bmcgY8OzIHF1eeG7gW4geGVtIG5nw6JuIHPDoWNoL+G7p3kgcXV54buBbjsga2jDtG5nIHRo4buDIGzGsHUgY2jhur8gxJHhu5kgdOG7sSBn4butaS48L0FsZXJ0Pn17Y2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmIGJ1ZGdldHMuaXNQZW5kaW5nICYmIDxUeXBvZ3JhcGh5IHJvbGU9XCJzdGF0dXNcIj7EkGFuZyB04bqjaSBjaMOtbmggc8OhY2ggbmfDom4gc8OhY2ggbXVhIGjDoG5n4oCmPC9UeXBvZ3JhcGh5Pn17Y2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmIGJ1ZGdldHMuaXNFcnJvciAmJiA8RmllbGRHcm91cCByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiVHLhuqFuZyB0aMOhaSBjaMOtbmggc8OhY2ggbmfDom4gc8OhY2ggbXVhIGjDoG5nXCI+PEVycm9yTm90aWNlIGVycm9yPXtidWRnZXRzLmVycm9yfS8+e2NhblJldHJ5TG9va3VwKGJ1ZGdldHMuZXJyb3IpICYmIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIGJ1ZGdldHMucmVmZXRjaCgpOyB9fT5UaOG7rSBs4bqhaSBjaMOtbmggc8OhY2ggbmfDom4gc8OhY2g8L0J1dHRvbj59PC9GaWVsZEdyb3VwPn17Y2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmICFidWRnZXRzLmlzUGVuZGluZyAmJiAhYnVkZ2V0cy5pc0Vycm9yICYmIGFwcHJvdmVkQnVkZ2V0cy5sZW5ndGggPT09IDAgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPktow7RuZyBjw7MgY2jDrW5oIHPDoWNoIG5nw6JuIHPDoWNoIG11YSBow6BuZyDEkWFuZyBi4bqtdCB2w6AgY8OzIGjhuqFuIG3hu6ljLjwvVHlwb2dyYXBoeT59e2NhblJlYWRCdWRnZXRQb2xpY2llcyAmJiBhcHByb3ZlZEJ1ZGdldHMubGVuZ3RoID4gMCAmJiA8VGV4dEZpZWxkIGxhYmVsPVwiTmfDom4gc8OhY2ggbXVhIGjDoG5nIMSRw6MgZHV54buHdFwiIHNlbGVjdCB2YWx1ZT17YnVkZ2V0fSBvbkNoYW5nZT17ZSA9PiB7IHNldEJ1ZGdldChlLnRhcmdldC52YWx1ZSk7IHNldERlbGVnYXRpb25JZCgnJyk7IH19PnthcHByb3ZlZEJ1ZGdldHMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmlkfSDCtyB7aXRlbS5saW1pdEFtb3VudD8uYW1vdW50fSB7aXRlbS5saW1pdEFtb3VudD8uY3VycmVuY3l9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPn17Y2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmIGRlbGVnYXRpb25zLmlzUGVuZGluZyAmJiA8VHlwb2dyYXBoeSByb2xlPVwic3RhdHVzXCI+xJBhbmcgdOG6o2kg4buneSBxdXnhu4FuIHBow7kgaOG7o3DigKY8L1R5cG9ncmFwaHk+fXtjYW5SZWFkQnVkZ2V0UG9saWNpZXMgJiYgZGVsZWdhdGlvbnMuaXNFcnJvciAmJiA8RmllbGRHcm91cCByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiVHLhuqFuZyB0aMOhaSDhu6d5IHF1eeG7gW4gbXVhIGjDoG5nXCI+PEVycm9yTm90aWNlIGVycm9yPXtkZWxlZ2F0aW9ucy5lcnJvcn0vPjxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIGRlbGVnYXRpb25zLnJlZmV0Y2goKTsgfX0+VGjhu60gbOG6oWkg4buneSBxdXnhu4FuPC9CdXR0b24+PC9GaWVsZEdyb3VwPn17Y2FuUmVhZEJ1ZGdldFBvbGljaWVzICYmICFkZWxlZ2F0aW9ucy5pc1BlbmRpbmcgJiYgIWRlbGVnYXRpb25zLmlzRXJyb3IgJiYgZWxpZ2libGVEZWxlZ2F0aW9ucy5sZW5ndGggPT09IDAgJiYgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiPktow7RuZyBjw7Mg4buneSBxdXnhu4FuIMSRYW5nIGhp4buHdSBs4buxYyBraOG7m3AgbmjDoCBjdW5nIGPhuqVwLCBraG8sIGLDoW8gZ2nDoSBzbmFwc2hvdCB2w6AgbmfDom4gc8OhY2guPC9UeXBvZ3JhcGh5Pn17ZWxpZ2libGVEZWxlZ2F0aW9ucy5sZW5ndGggPiAwICYmIDxUZXh0RmllbGQgbGFiZWw9XCLhu6Z5IHF1eeG7gW4gcHVyY2hhc2Uuc2VuZFwiIHNlbGVjdCB2YWx1ZT17ZGVsZWdhdGlvbklkfSBvbkNoYW5nZT17ZSA9PiBzZXREZWxlZ2F0aW9uSWQoZS50YXJnZXQudmFsdWUpfT57ZWxpZ2libGVEZWxlZ2F0aW9ucy5tYXAoZ3JhbnQgPT4gPE1lbnVJdGVtIGtleT17Z3JhbnQuaWR9IHZhbHVlPXtncmFudC5pZH0+e2dyYW50LmlkfSDCtyB04buRaSDEkWEge2dyYW50Lm1heFBlck9yZGVyLmFtb3VudH0ge2dyYW50Lm1heFBlck9yZGVyLmN1cnJlbmN5fS/EkcahbiDCtyDEkeG6v24ge2RhdGVUaW1lKGdyYW50LmV4cGlyZXNBdCwgc2hvcC50aW1lem9uZSl9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPn08Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIlTDtGkgxJHDoyBraeG7g20gZ2nhu5tpIGjhuqFuLCBzbmFwc2hvdCB2w6AgcGjhuqFtIHZpIHThu7EgZ+G7rWlcIiBjb250cm9sPXs8Q2hlY2tib3ggY2hlY2tlZD17YXV0b0Fja30gb25DaGFuZ2U9e2UgPT4gc2V0QXV0b0FjayhlLnRhcmdldC5jaGVja2VkKX0vPn0gLz48Lz59PEZvcm1Db250cm9sTGFiZWwgbGFiZWw9XCJC4bqtdCBxdXkgdOG6r2NcIiBjb250cm9sPXs8Q2hlY2tib3ggY2hlY2tlZD17ZW5hYmxlZH0gb25DaGFuZ2U9e2UgPT4gc2V0RW5hYmxlZChlLnRhcmdldC5jaGVja2VkKX0vPn0gLz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG5mdW5jdGlvbiBjYW5SZXRyeUxvb2t1cChlcnJvcjogdW5rbm93bikge1xyXG4gICAgcmV0dXJuICEoZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvcikgfHwgKGVycm9yLnN0YXR1cyAhPT0gNDAzICYmIGVycm9yLnN0YXR1cyAhPT0gNDA0KTtcclxufVxyXG50eXBlIFB1cmNoYXNlRHJhZnRMaW5lID0geyBrZXk6IG51bWJlcjsgc3VwcGxpZXJPZmZlcklkOiBzdHJpbmc7IHF1YW50aXR5OiBzdHJpbmcgfTtcclxuXHJcbmZ1bmN0aW9uIHF1YW50aXR5TWF0Y2hlc09mZmVyKHF1YW50aXR5OiBzdHJpbmcsIG9mZmVyOiBTdXBwbGllck9mZmVyIHwgdW5kZWZpbmVkKSB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IE51bWJlcihxdWFudGl0eSk7XHJcbiAgICByZXR1cm4gISFvZmZlciAmJiBOdW1iZXIuaXNJbnRlZ2VyKHZhbHVlKSAmJiB2YWx1ZSA+PSBvZmZlci5taW5pbXVtUXVhbnRpdHkgJiYgdmFsdWUgJSBvZmZlci5wYWNrU2l6ZSA9PT0gMDtcclxufVxyXG5cclxuZnVuY3Rpb24gb2ZmZXJJc0N1cnJlbnQob2ZmZXI6IFN1cHBsaWVyT2ZmZXIpIHtcclxuICAgIHJldHVybiAhb2ZmZXIudmFsaWRVbnRpbCB8fCBEYXRlLnBhcnNlKG9mZmVyLnZhbGlkVW50aWwpID4gRGF0ZS5ub3coKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFB1cmNoYXNlc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBbcGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdFB1cmNoYXNlT3JkZXJzJywgeyBxdWVyeTogeyBsaW1pdDogMjAsIGN1cnNvcjogcGFyYW1zLmdldCgnY3Vyc29yJykgfHwgdW5kZWZpbmVkIH0gfSk7XHJcbiAgICBjb25zdCBzdXBwbGllcnMgPSB1c2VQYWdlZEFwaSgnbGlzdFN1cHBsaWVycycpO1xyXG4gICAgY29uc3Qgb2ZmZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RTdXBwbGllck9mZmVycycpO1xyXG4gICAgY29uc3Qgd2FyZWhvdXNlcyA9IHVzZVBhZ2VkQXBpKCdsaXN0V2FyZWhvdXNlcycsIHsgcXVlcnk6IHsgc3RhdHVzOiAnYWN0aXZlJywgbGltaXQ6IDIwIH0gfSk7XHJcbiAgICBjb25zdCBbd2FyZWhvdXNlSWQsIHNldFdhcmVob3VzZUlkXSA9IHVzZVN0YXRlKHNob3AuZGVmYXVsdFdhcmVob3VzZUlkKTtcclxuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZVB1cmNoYXNlT3JkZXInLCBbJ2xpc3RQdXJjaGFzZU9yZGVycyddKTtcclxuICAgIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKSwgW3N1cHBsaWVySWQsIHNldFN1cHBsaWVySWRdID0gdXNlU3RhdGUoJycpLCBbcG9MaW5lcywgc2V0UG9MaW5lc10gPSB1c2VTdGF0ZTxQdXJjaGFzZURyYWZ0TGluZVtdPihbeyBrZXk6IDEsIHN1cHBsaWVyT2ZmZXJJZDogJycsIHF1YW50aXR5OiAnMScgfV0pLCBbbmV4dExpbmVLZXksIHNldE5leHRMaW5lS2V5XSA9IHVzZVN0YXRlKDIpLCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpLCBbZHJhZnRDb21taXQsIHNldERyYWZ0Q29tbWl0XSA9IHVzZVN0YXRlPHsgc2NvcGU6IHN0cmluZyB8IG51bGw7IHNlcXVlbmNlOiBudW1iZXIgfT4oKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkU3VwcGxpZXIgPSBzdXBwbGllcnMuZGF0YT8uZGF0YS5maW5kKHN1cHBsaWVyID0+IHN1cHBsaWVyLmlkID09PSBzdXBwbGllcklkKTtcclxuICAgIGNvbnN0IGF2YWlsYWJsZU9mZmVycyA9IG9mZmVycy5kYXRhPy5kYXRhLmZpbHRlcihvZmZlciA9PiBvZmZlci5zdXBwbGllcklkID09PSBzdXBwbGllcklkICYmIG9mZmVyLnVuaXRDb3N0LmN1cnJlbmN5ID09PSBzZWxlY3RlZFN1cHBsaWVyPy5jdXJyZW5jeSAmJiBvZmZlcklzQ3VycmVudChvZmZlcikpIHx8IFtdO1xyXG4gICAgY29uc3QgY2FuQ3JlYXRlID0gd2FyZWhvdXNlcy5kYXRhPy5kYXRhLnNvbWUod2FyZWhvdXNlID0+IHdhcmVob3VzZS5pZCA9PT0gd2FyZWhvdXNlSWQpICYmICEhc2VsZWN0ZWRTdXBwbGllciAmJiBzZWxlY3RlZFN1cHBsaWVyLnN0YXR1cyA9PT0gJ2FwcHJvdmVkJyAmJiBwb0xpbmVzLmxlbmd0aCA+IDAgJiYgcG9MaW5lcy5ldmVyeShsaW5lID0+IHF1YW50aXR5TWF0Y2hlc09mZmVyKGxpbmUucXVhbnRpdHksIGF2YWlsYWJsZU9mZmVycy5maW5kKG9mZmVyID0+IG9mZmVyLmlkID09PSBsaW5lLnN1cHBsaWVyT2ZmZXJJZCkpKSAmJiBuZXcgU2V0KHBvTGluZXMubWFwKGxpbmUgPT4gbGluZS5zdXBwbGllck9mZmVySWQpKS5zaXplID09PSBwb0xpbmVzLmxlbmd0aCAmJiAhY3JlYXRlLnBlbmRpbmc7XHJcbiAgICBjb25zdCBzdGFydFB1cmNoYXNlID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFN1cHBsaWVySWQoJycpO1xyXG4gICAgICAgIHNldFdhcmVob3VzZUlkKHNob3AuZGVmYXVsdFdhcmVob3VzZUlkKTtcclxuICAgICAgICBzZXRQb0xpbmVzKFt7IGtleTogMSwgc3VwcGxpZXJPZmZlcklkOiAnJywgcXVhbnRpdHk6ICcxJyB9XSk7XHJcbiAgICAgICAgc2V0TmV4dExpbmVLZXkoMik7XHJcbiAgICAgICAgc2V0T3Blbih0cnVlKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBzZWxlY3RTdXBwbGllciA9IChuZXh0U3VwcGxpZXJJZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0U3VwcGxpZXJJZChuZXh0U3VwcGxpZXJJZCk7XHJcbiAgICAgICAgc2V0UG9MaW5lcyhbeyBrZXk6IDEsIHN1cHBsaWVyT2ZmZXJJZDogJycsIHF1YW50aXR5OiAnMScgfV0pO1xyXG4gICAgICAgIHNldE5leHRMaW5lS2V5KDIpO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IHNlbGVjdE9mZmVyID0gKGtleTogbnVtYmVyLCBzdXBwbGllck9mZmVySWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGNvbnN0IG9mZmVyID0gYXZhaWxhYmxlT2ZmZXJzLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBzdXBwbGllck9mZmVySWQpO1xyXG4gICAgICAgIGNvbnN0IHF1YW50aXR5ID0gb2ZmZXIgPyBTdHJpbmcoTWF0aC5jZWlsKG9mZmVyLm1pbmltdW1RdWFudGl0eSAvIG9mZmVyLnBhY2tTaXplKSAqIG9mZmVyLnBhY2tTaXplKSA6ICcxJztcclxuICAgICAgICBzZXRQb0xpbmVzKGxpbmVzID0+IGxpbmVzLm1hcChsaW5lID0+IGxpbmUua2V5ID09PSBrZXkgPyB7IC4uLmxpbmUsIHN1cHBsaWVyT2ZmZXJJZCwgcXVhbnRpdHkgfSA6IGxpbmUpKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBzdWJtaXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFjYW5DcmVhdGUgfHwgIXNlbGVjdGVkU3VwcGxpZXIpIHJldHVybjtcclxuICAgICAgICBjb25zdCBsaW5lcyA9IHBvTGluZXMubWFwKGxpbmUgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBvZmZlciA9IGF2YWlsYWJsZU9mZmVycy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PT0gbGluZS5zdXBwbGllck9mZmVySWQpO1xyXG4gICAgICAgICAgICBpZiAoIW9mZmVyKSB0aHJvdyBuZXcgRXJyb3IoJ0LDoW8gZ2nDoSBraMO0bmcgY8OybiBraOG6oyBk4bulbmcuIFThuqNpIGzhuqFpIGRhbmggc8OhY2ggdHLGsOG7m2Mga2hpIGzhuq1wIMSRxqFuLicpO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YXJpYW50SWQ6IG9mZmVyLnZhcmlhbnRJZCwgc3VwcGxpZXJPZmZlcklkOiBvZmZlci5pZCwgcXVhbnRpdHk6IE51bWJlcihsaW5lLnF1YW50aXR5KSB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNyZWF0ZS5leGVjdXRlKHsgYm9keTogeyBzdXBwbGllcklkOiBzZWxlY3RlZFN1cHBsaWVyLmlkLCB3YXJlaG91c2VJZCwgc3VnZ2VzdGlvbklkOiBudWxsLCBsaW5lcyB9IH0pO1xyXG4gICAgICAgICAgICBzZXREcmFmdENvbW1pdChwcmV2aW91cyA9PiAoeyBzY29wZTogbnVsbCwgc2VxdWVuY2U6IChwcmV2aW91cz8uc2VxdWVuY2UgfHwgMCkgKyAxIH0pKTtcclxuICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkKHJlc3VsdC5kYXRhLmlkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggeyAvKiBrZWVwIHRoZSBjb21wbGV0ZSBkcmFmdCB2aXNpYmxlIGFmdGVyIEFQSSByZWplY3Rpb24gKi8gfVxyXG4gICAgfTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwixJDGoW4gbXVhIGjDoG5nXCIgc3VidGl0bGU9XCJEdXnhu4d0IMSRw7puZyBu4buZaSBkdW5nIHRyxrDhu5tjIGtoaSBn4butaS4gS+G6v3QgcXXhuqMgZ+G7rWkgY2jGsGEgcsO1IHBo4bqjaSDEkeG7kWkgY2hp4bq/dSwga2jDtG5nIGfhu61pIGzhuqFpIG3DuSBxdcOhbmcuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC53cml0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXtzdGFydFB1cmNoYXNlfT5U4bqhbyDEkcahbiBtdWE8L011dGF0aW9uQnV0dG9uPn0vPjxQYW5lbD48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCLEkMahbiBtdWEgaMOgbmdcIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtwID0+IHAuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICfEkMahbiBtdWEnLCByZW5kZXI6IHAgPT4gPFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e3AuaWR9PC9UeXBvZ3JhcGh5PiB9LCB7IGtleTogJ3N1cHBsaWVyJywgbGFiZWw6ICdOaMOgIGN1bmcgY+G6pXAnLCByZW5kZXI6IHAgPT4gc3VwcGxpZXJzLmRhdGE/LmRhdGEuZmluZChzID0+IHMuaWQgPT09IHAuc3VwcGxpZXJJZCk/Lm5hbWUgfHwgYE3DoyBuaMOgIGN1bmcgY+G6pXA6ICR7cC5zdXBwbGllcklkfWAgfSwgeyBrZXk6ICd0b3RhbCcsIGxhYmVsOiAnVOG7lW5nIGNhbSBr4bq/dCcsIHJlbmRlcjogcCA9PiA8QW1vdW50IHZhbHVlPXtwLnRvdGFsfS8+IH0sIHsga2V5OiAnc3RhdHVzJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBwID0+IDxTdGF0dXMgdmFsdWU9e3Auc3RhdHVzfS8+IH0sIHsga2V5OiAncmVmJywgbGFiZWw6ICdUaGFtIGNoaeG6v3UnLCByZW5kZXI6IHAgPT4gcC5leHRlcm5hbFJlZmVyZW5jZSB8fCAnQ2jGsGEgZ+G7rWknIH0sIHsga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHAgPT4gPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZChwLmlkKX0+WGVtIGNoaSB0aeG6v3Q8L0J1dHRvbj4gfVxyXG4gICAgXX0vPjxQYWdlciBwYWdlPXtsaXN0LmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cclxuICAgIDxFZGl0RGlhbG9nIG9wZW49e29wZW59IHRpdGxlPVwixJDGoW4gbXVhIG3hu5tpXCIgb25DbG9zZT17KCkgPT4gc2V0T3BlbihmYWxzZSl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBkcmFmdENvbW1pdD17ZHJhZnRDb21taXR9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshY2FuQ3JlYXRlfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHN1Ym1pdCgpfT5MxrB1IMSRxqFuIG5ow6FwPC9CdXR0b24+fT5cclxuICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvciB8fCB3YXJlaG91c2VzLmVycm9yfS8+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiS2hvIG5o4bqtbiBow6BuZ1wiIHZhbHVlPXt3YXJlaG91c2VJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFdhcmVob3VzZUlkKGV2ZW50LnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXtjcmVhdGUucGVuZGluZ30+e3dhcmVob3VzZUlkICYmICF3YXJlaG91c2VzLmRhdGE/LmRhdGEuc29tZSh3YXJlaG91c2UgPT4gd2FyZWhvdXNlLmlkID09PSB3YXJlaG91c2VJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXt3YXJlaG91c2VJZH0+xJBhbmcgZ2nhu68ga2hvIHt3YXJlaG91c2VJZH07IHThuqNpIGRhbmggbeG7pWMgxJHhu4Mga2nhu4NtIHRyYTwvTWVudUl0ZW0+fXt3YXJlaG91c2VzLmRhdGE/LmRhdGEubWFwKHdhcmVob3VzZSA9PiA8TWVudUl0ZW0ga2V5PXt3YXJlaG91c2UuaWR9IHZhbHVlPXt3YXJlaG91c2UuaWR9Pnt3YXJlaG91c2UuY29kZX0gwrcge3dhcmVob3VzZS5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJraG8gbmjhuq1uIGjDoG5nXCIgbG9hZGVkQ291bnQ9e3dhcmVob3VzZXMubG9hZGVkQ291bnR9IGhhc01vcmU9e3dhcmVob3VzZXMuaGFzTW9yZX0gYnVzeT17d2FyZWhvdXNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXt3YXJlaG91c2VzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOaMOgIGN1bmcgY+G6pXAgxJHDoyBkdXnhu4d0XCIgc2VsZWN0IHZhbHVlPXtzdXBwbGllcklkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2VsZWN0U3VwcGxpZXIoZXZlbnQudGFyZ2V0LnZhbHVlKX0+e3N1cHBsaWVySWQgJiYgIXN1cHBsaWVycy5kYXRhPy5kYXRhLnNvbWUoc3VwcGxpZXIgPT4gc3VwcGxpZXIuaWQgPT09IHN1cHBsaWVySWQpICYmIDxNZW51SXRlbSB2YWx1ZT17c3VwcGxpZXJJZH0+e3N1cHBsaWVySWR9PC9NZW51SXRlbT59e3N1cHBsaWVycy5kYXRhPy5kYXRhLmZpbHRlcihzdXBwbGllciA9PiBzdXBwbGllci5zdGF0dXMgPT09ICdhcHByb3ZlZCcpLm1hcChzdXBwbGllciA9PiA8TWVudUl0ZW0ga2V5PXtzdXBwbGllci5pZH0gdmFsdWU9e3N1cHBsaWVyLmlkfT57c3VwcGxpZXIubmFtZX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cIm5ow6AgY3VuZyBj4bqlcFwiIGxvYWRlZENvdW50PXtzdXBwbGllcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e3N1cHBsaWVycy5oYXNNb3JlfSBidXN5PXtzdXBwbGllcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17c3VwcGxpZXJzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgIHtzdXBwbGllcnMuaXNFcnJvciAmJiA8RmllbGRHcm91cCA+PEVycm9yTm90aWNlIGVycm9yPXtzdXBwbGllcnMuZXJyb3J9Lz48QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAoc3VwcGxpZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gc3VwcGxpZXJzLmxvYWRNb3JlKCkgOiBzdXBwbGllcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCBuaMOgIGN1bmcgY+G6pXA8L0J1dHRvbj48L0ZpZWxkR3JvdXA+fVxyXG4gICAgICAgICAgICB7IXN1cHBsaWVycy5kYXRhPy5kYXRhLnNvbWUoc3VwcGxpZXIgPT4gc3VwcGxpZXIuc3RhdHVzID09PSAnYXBwcm92ZWQnKSAmJiA8QWxlcnQgc2V2ZXJpdHk9e3N1cHBsaWVycy5oYXNNb3JlID8gJ2luZm8nIDogJ3dhcm5pbmcnfT57c3VwcGxpZXJzLmhhc01vcmUgPyAnQ2jGsGEgdOG6o2kgaOG6v3QgbmjDoCBjdW5nIGPhuqVwOyB04bqjaSB0aMOqbSB0csaw4bubYyBraGkga+G6v3QgbHXhuq1uIGtow7RuZyBjw7MgbmjDoCBjdW5nIGPhuqVwIMSRxrDhu6NjIGR1eeG7h3QuJyA6ICdDaMawYSBjw7MgbmjDoCBjdW5nIGPhuqVwIMSRxrDhu6NjIGR1eeG7h3QgxJHhu4MgbOG6rXAgxJHGoW4uJ308L0FsZXJ0Pn1cclxuICAgICAgICAgICAge3BvTGluZXMubWFwKChsaW5lLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbGluZU9mZmVyID0gYXZhaWxhYmxlT2ZmZXJzLmZpbmQob2ZmZXIgPT4gb2ZmZXIuaWQgPT09IGxpbmUuc3VwcGxpZXJPZmZlcklkKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNob2ljZXMgPSBhdmFpbGFibGVPZmZlcnMuZmlsdGVyKG9mZmVyID0+ICFwb0xpbmVzLnNvbWUob3RoZXIgPT4gb3RoZXIua2V5ICE9PSBsaW5lLmtleSAmJiBvdGhlci5zdXBwbGllck9mZmVySWQgPT09IG9mZmVyLmlkKSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gPEZvcm1GaWVsZHMga2V5PXtsaW5lLmtleX0gYm9keU1vZGU9XCJvdXRsaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBhbGlnbkl0ZW1zPXt7IHNtOiAnY2VudGVyJyB9fSBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmd9PkTDsm5nIGjDoG5nIHtpbmRleCArIDF9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cG9MaW5lcy5sZW5ndGggPiAxICYmIDxCdXR0b24gY29sb3I9XCJpbmhlcml0XCIgb25DbGljaz17KCkgPT4gc2V0UG9MaW5lcyhsaW5lcyA9PiBsaW5lcy5maWx0ZXIoaXRlbSA9PiBpdGVtLmtleSAhPT0gbGluZS5rZXkpKX0+WMOzYSBkw7JuZyB7aW5kZXggKyAxfTwvQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgICAgICA8L0ZpZWxkR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm1GaWVsZHMgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19ID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBmdWxsV2lkdGggbGFiZWw9e2BCw6FvIGdpw6EgZMOybmcgJHtpbmRleCArIDF9YH0gc2VsZWN0IHZhbHVlPXtsaW5lLnN1cHBsaWVyT2ZmZXJJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNlbGVjdE9mZmVyKGxpbmUua2V5LCBldmVudC50YXJnZXQudmFsdWUpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaG9pY2VzLm1hcChvZmZlciA9PiA8TWVudUl0ZW0ga2V5PXtvZmZlci5pZH0gdmFsdWU9e29mZmVyLmlkfT57b2ZmZXIudmFyaWFudElkfSDCtyB7b2ZmZXIudW5pdENvc3QuYW1vdW50fSB7b2ZmZXIudW5pdENvc3QuY3VycmVuY3l9IMK3IE1PUSB7b2ZmZXIubWluaW11bVF1YW50aXR5fSAvIHF1eSBjw6FjaCB7b2ZmZXIucGFja1NpemV9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD17YFPhu5EgbMaw4bujbmcgZMOybmcgJHtpbmRleCArIDF9YH0gdHlwZT1cIm51bWJlclwiIHZhbHVlPXtsaW5lLnF1YW50aXR5fSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UG9MaW5lcyhsaW5lcyA9PiBsaW5lcy5tYXAoaXRlbSA9PiBpdGVtLmtleSA9PT0gbGluZS5rZXkgPyB7IC4uLml0ZW0sIHF1YW50aXR5OiBldmVudC50YXJnZXQudmFsdWUgfSA6IGl0ZW0pKX0gaW5wdXRQcm9wcz17eyBtaW46IGxpbmVPZmZlcj8ubWluaW11bVF1YW50aXR5IHx8IDEsIHN0ZXA6IGxpbmVPZmZlcj8ucGFja1NpemUgfHwgMSB9fSBlcnJvcj17ISFsaW5lT2ZmZXIgJiYgISFsaW5lLnF1YW50aXR5ICYmICFxdWFudGl0eU1hdGNoZXNPZmZlcihsaW5lLnF1YW50aXR5LCBsaW5lT2ZmZXIpfSBoZWxwZXJUZXh0PXtsaW5lT2ZmZXIgPyBgU+G7kSBuZ3V5w6puLCB04buRaSB0aGnhu4N1ICR7bGluZU9mZmVyLm1pbmltdW1RdWFudGl0eX0gdsOgIGLhu5lpIHPhu5EgJHtsaW5lT2ZmZXIucGFja1NpemV9LmAgOiAnQ2jhu41uIGLDoW8gZ2nDoSBjw7luZyBuaMOgIGN1bmcgY+G6pXAuJ30vPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz47XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8TG9va3VwTG9hZE1vcmUgbGFiZWw9XCJiw6FvIGdpw6FcIiBsb2FkZWRDb3VudD17b2ZmZXJzLmxvYWRlZENvdW50fSBoYXNNb3JlPXtvZmZlcnMuaGFzTW9yZX0gYnVzeT17b2ZmZXJzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e29mZmVycy5sb2FkTW9yZX0vPlxyXG4gICAgICAgICAgICB7b2ZmZXJzLmlzRXJyb3IgJiYgPEZpZWxkR3JvdXAgPjxFcnJvck5vdGljZSBlcnJvcj17b2ZmZXJzLmVycm9yfS8+PEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgKG9mZmVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IG9mZmVycy5sb2FkTW9yZSgpIDogb2ZmZXJzLnJlZmV0Y2goKSk7IH19PlRo4butIGzhuqFpIGRhbmggc8OhY2ggYsOhbyBnacOhPC9CdXR0b24+PC9GaWVsZEdyb3VwPn1cclxuICAgICAgICAgICAge29mZmVycy5oYXNNb3JlICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5C4buZIGNo4buNbiBjaOG7iSBs4buNYyB0cm9uZyB7b2ZmZXJzLmxvYWRlZENvdW50fSBiw6FvIGdpw6EgxJHDoyB04bqjaS4gVOG6o2kgdGjDqm0gxJHhu4MgdMOsbSBvZmZlciBj4bunYSBuaMOgIGN1bmcgY+G6pXAgxJHDoyBjaOG7jW4uPC9BbGVydD59XHJcbiAgICAgICAgICAgIDxCdXR0b24gZGlzYWJsZWQ9eyFzdXBwbGllcklkIHx8ICFhdmFpbGFibGVPZmZlcnMuc29tZShvZmZlciA9PiAhcG9MaW5lcy5zb21lKGxpbmUgPT4gbGluZS5zdXBwbGllck9mZmVySWQgPT09IG9mZmVyLmlkKSl9IG9uQ2xpY2s9eygpID0+IHsgc2V0UG9MaW5lcyhsaW5lcyA9PiBbLi4ubGluZXMsIHsga2V5OiBuZXh0TGluZUtleSwgc3VwcGxpZXJPZmZlcklkOiAnJywgcXVhbnRpdHk6ICcxJyB9XSk7IHNldE5leHRMaW5lS2V5KGtleSA9PiBrZXkgKyAxKTsgfX0+VGjDqm0gZMOybmcgaMOgbmc8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkdpw6EgdGhlbyB04burbmcgYsOhbyBnacOhIMSRw6MgY2jhu41uOyB04buVbmcgY2FtIGvhur90IGNow61uaCB0aOG7qWMgZG8gQVBJIHRy4bqjIHbhu4EgdsOgIMSRxrDhu6NjIGfhuq9uIHbDoG8gbuG7mWkgZHVuZyB4aW4gZHV54buHdC48L0FsZXJ0PlxyXG4gICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgIDwvRWRpdERpYWxvZz57c2VsZWN0ZWQgJiYgPFB1cmNoYXNlRGlhbG9nIHJlc291cmNlSWQ9e3NlbGVjdGVkfSBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0vPn08Lz47XHJcbn1cclxuZnVuY3Rpb24gUHVyY2hhc2VEaWFsb2coeyByZXNvdXJjZUlkLCBvbkNsb3NlIH06IHtcclxuICAgIHJlc291cmNlSWQ6IHN0cmluZztcclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGdldCA9IHVzZUFwaSgnZ2V0UHVyY2hhc2VPcmRlcicsIHsgcGF0aDogeyByZXNvdXJjZUlkIH0gfSk7XHJcbiAgICBjb25zdCBwID0gZ2V0LmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBhcHByb3ZhbCA9IHVzZUNvbW1hbmQoJ3JlcXVlc3RQdXJjaGFzZUFwcHJvdmFsJywgWydnZXRQdXJjaGFzZU9yZGVyJywgJ2xpc3RQdXJjaGFzZU9yZGVycycsICdsaXN0QXBwcm92YWxzJ10pO1xyXG4gICAgY29uc3Qgc2VuZCA9IHVzZUNvbW1hbmQoJ3NlbmRQdXJjaGFzZU9yZGVyJywgWydnZXRQdXJjaGFzZU9yZGVyJywgJ2xpc3RQdXJjaGFzZU9yZGVycycsICdsaXN0QXBwcm92YWxzJ10pO1xyXG4gICAgY29uc3QgY29uZmlybSA9IHVzZUNvbW1hbmQoJ2NvbmZpcm1QdXJjaGFzZU9yZGVyJywgWydnZXRQdXJjaGFzZU9yZGVyJywgJ2xpc3RQdXJjaGFzZU9yZGVycyddKTtcclxuICAgIGNvbnN0IGNhbmNlbCA9IHVzZUNvbW1hbmQoJ2NhbmNlbFB1cmNoYXNlT3JkZXInLCBbJ2dldFB1cmNoYXNlT3JkZXInLCAnbGlzdFB1cmNoYXNlT3JkZXJzJywgJ2xpc3RQdXJjaGFzZVN1Z2dlc3Rpb25zJ10pO1xyXG4gICAgY29uc3QgW2FjdGlvbiwgc2V0QWN0aW9uXSA9IHVzZVN0YXRlPCdzZW5kJyB8ICdjYW5jZWwnIHwgJ2NvbmZpcm0nIHwgbnVsbD4obnVsbCksIFtleHRlcm5hbCwgc2V0RXh0ZXJuYWxdID0gdXNlU3RhdGUoJycpLCBbcHJvb2YsIHNldFByb29mXSA9IHVzZVN0YXRlKCcnKSwgW2RyYWZ0Q29tbWl0LCBzZXREcmFmdENvbW1pdF0gPSB1c2VTdGF0ZTx7IHNjb3BlOiBzdHJpbmcgfCBudWxsOyBzZXF1ZW5jZTogbnVtYmVyIH0+KCk7XHJcbiAgICBjb25zdCB1bnJlc29sdmVkU2VuZCA9IHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZUludGVudHMsIGludGVudFNuYXBzaG90LCBpbnRlbnRTbmFwc2hvdCkuc29tZShpbnRlbnQgPT4gaW50ZW50LnNob3BJZCA9PT0gc2hvcC5pZCAmJiBpbnRlbnQub3BlcmF0aW9uID09PSAnc2VuZFB1cmNoYXNlT3JkZXInKTtcclxuICAgIGNvbnN0IHNlbmRQdXJjaGFzZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICByZXR1cm4gYXdhaXQgc2VuZC5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBwPy52ZXJzaW9uIHx8IDEsIGFwcHJvdmFsSWQ6IHA/LmFwcHJvdmFsSWQgfHwgJycsIGludGVudEhhc2g6IHA/LmludGVudEhhc2ggfHwgJycgfSB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFVua25vd25SZXN1bHRFcnJvcikgc2V0QWN0aW9uKG51bGwpO1xyXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIDw+PEVkaXREaWFsb2cgb3BlbiB0aXRsZT17YMSQxqFuIG11YSAke3Jlc291cmNlSWR9YH0gb25DbG9zZT17b25DbG9zZX0gYWN0aW9ucz17PEJ1dHRvbiBvbkNsaWNrPXtvbkNsb3NlfT7EkMOzbmc8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17YXBwcm92YWwuZXJyb3IgfHwgc2VuZC5lcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtnZXR9PntwICYmIDxGb3JtRmllbGRzID48U3RhdHVzIHZhbHVlPXtwLnN0YXR1c30vPjxEZXRhaWxMaW5lIGxhYmVsPVwiTmjDoCBjdW5nIGPhuqVwXCI+TcOjIG5ow6AgY3VuZyBj4bqlcDoge3Auc3VwcGxpZXJJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJU4buVbmcgY2FtIGvhur90XCI+PEFtb3VudCB3cmFwIHZhbHVlPXtwLnRvdGFsfS8+PC9EZXRhaWxMaW5lPjxEYXRhVGFibGUgbGFiZWw9XCJT4bqjbiBwaOG6qW0gdHJvbmcgxJHGoW4gbXVhXCIgcm93cz17cC5saW5lc30gcm93S2V5PXtsID0+IGwuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ3NrdScsIGxhYmVsOiAnQmnhur9uIHRo4buDJywgcmVuZGVyOiBsID0+IGwudmFyaWFudElkIH0sIHsga2V5OiAncXR5JywgbGFiZWw6ICfEkOG6t3QnLCByZW5kZXI6IGwgPT4gbC5xdWFudGl0eSB9LCB7IGtleTogJ3JlY2VpdmVkJywgbGFiZWw6ICfEkMOjIG5o4bqtbicsIHJlbmRlcjogbCA9PiBsLnJlY2VpdmVkUXVhbnRpdHkgfSwgeyBrZXk6ICdjb3N0JywgbGFiZWw6ICfEkMahbiBnacOhJywgcmVuZGVyOiBsID0+IDxBbW91bnQgdmFsdWU9e2wudW5pdENvc3R9Lz4gfVxyXG4gICAgXX0vPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgc3g9e3sgb3ZlcmZsb3dXcmFwOiAnYW55d2hlcmUnIH19Pkhhc2ggbuG7mWkgZHVuZzoge3AuaW50ZW50SGFzaH08L1R5cG9ncmFwaHk+PEZpZWxkR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgIGZsZXhXcmFwPVwid3JhcFwiPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJvY3VyZW1lbnQud3JpdGVcIiBhbGxvd2VkQWN0aW9ucz17cC5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwicmVxdWVzdF9hcHByb3ZhbFwiIGJ1c3k9e2FwcHJvdmFsLnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgYXBwcm92YWwuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZCB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogcC52ZXJzaW9uIH0gfSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKX0+WGluIHBow6ogZHV54buHdDwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC5zZW5kXCIgYWxsb3dlZEFjdGlvbnM9e3AuYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cInNlbmRcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e3VucmVzb2x2ZWRTZW5kfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ3NlbmQnKX0+R+G7rWkgxJHGoW4gbXVhPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByb2N1cmVtZW50LndyaXRlXCIgYWxsb3dlZEFjdGlvbnM9e3AuYWxsb3dlZEFjdGlvbnN9IGFjdGlvbj1cImNvbmZpcm1cIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3Rpb24oJ2NvbmZpcm0nKX0+TmjDoCBjdW5nIGPhuqVwIMSRw6MgeMOhYyBuaOG6rW48L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJvY3VyZW1lbnQud3JpdGVcIiBhbGxvd2VkQWN0aW9ucz17cC5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwiY2FuY2VsXCIgY29sb3I9XCJlcnJvclwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGlvbignY2FuY2VsJyl9Pkjhu6d5IMSRxqFuPC9NdXRhdGlvbkJ1dHRvbj48L0ZpZWxkR3JvdXA+e3AuYXBwcm92YWxJZCAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9hcHByb3ZhbHNgfT5YZW0gcGjDqiBkdXnhu4d0IHtwLmFwcHJvdmFsSWR9PC9Sb3V0ZUxpbms+fXtbJ2NvbmZpcm1lZCcsICdwYXJ0X3JlY2VpdmVkJ10uaW5jbHVkZXMocC5zdGF0dXMpICYmIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L3JlY2VpcHRzP3B1cmNoYXNlT3JkZXJJZD0ke3AuaWR9YH0+Tmjhuq1uIGjDoG5nIHRoZW8gxJHGoW4gbsOgeTwvUm91dGVMaW5rPn17KHAuc3RhdHVzID09PSAndW5rbm93bicgfHwgdW5yZXNvbHZlZFNlbmQpICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5DaMawYSB4w6FjIG1pbmgga+G6v3QgcXXhuqMgZ+G7rWkuIEtow7RuZyBn4butaSBs4bqhaTsgaMOjeSBraeG7g20gdHJhIHRy4bqhbmcgdGjDoWkgbOG7h25oIHRyxrDhu5tjIGtoaSB0aeG6v3AgdOG7pWMuPC9BbGVydD59PC9Gb3JtRmllbGRzPn08L1F1ZXJ5U3RhdGU+PC9FZGl0RGlhbG9nPlxyXG4gPENvbmZpcm1EaWFsb2cgb3Blbj17YWN0aW9uID09PSAnc2VuZCcgJiYgIXVucmVzb2x2ZWRTZW5kfSB0aXRsZT1cIkfhu61pIMSRxqFuIG11YSDEkcOjIGR1eeG7h3RcIiBjb25maXJtTGFiZWw9XCJH4butaSDEkcahbiBtdWFcIiBkZXNjcmlwdGlvbj17YMSQxqFuIG11YSAke3A/LmlkIHx8IHJlc291cmNlSWR9IMK3ICR7cD8udG90YWwuYW1vdW50IHx8IFwiXCJ9ICR7cD8udG90YWwuY3VycmVuY3kgfHwgXCJcIn06IGfhu61pIMSRw7puZyBu4buZaSBkdW5nIMSRw6MgxJHGsOG7o2MgZHV54buHdCBjaG8gbmjDoCBjdW5nIGPhuqVwICR7cD8uc3VwcGxpZXJJZCB8fCBcIlwifS4gS2jDtG5nIGNodXnhu4NuIHRp4buBbjsga+G6v3QgcXXhuqMgY2jGsGEgcsO1IHBo4bqjaSDEkcaw4bujYyBraeG7g20gdHJhIHRyxrDhu5tjIGtoaSBn4butaSBs4bqhaS5gfSBvbkNsb3NlPXsoKSA9PiBzZXRBY3Rpb24obnVsbCl9IGVycm9yPXtzZW5kLmVycm9yfSBidXN5PXtzZW5kLnBlbmRpbmd9IG9uQ29uZmlybT17c2VuZFB1cmNoYXNlfS8+PENvbmZpcm1EaWFsb2cgb3Blbj17YWN0aW9uID09PSAnY2FuY2VsJ30gdGl0bGU9XCJI4buneSDEkcahbiBtdWFcIiBjb25maXJtTGFiZWw9XCJI4buneSDEkcahbiBtdWFcIiBkZXNjcmlwdGlvbj17YMSQxqFuIG11YSAke3A/LmlkIHx8IHJlc291cmNlSWR9OiBo4buneSB0w6FjIHbhu6UgY2jGsGEgxJHGsOG7o2MgdGnhur9wIG5o4bqtbiBraGkgxJHhu6cgxJFp4buBdSBraeG7h24uIEtow7RuZyBjb2kgdmnhu4djIGjhu6d5IFVJIGzDoCB0aHUgaOG7k2kgdMOhYyDEkeG7mW5nIG5ow6AgY3VuZyBj4bqlcCDEkcOjIG5o4bqtbi5gfSByZXF1aXJlUmVhc29uIG9uQ2xvc2U9eygpID0+IHNldEFjdGlvbihudWxsKX0gZXJyb3I9e2NhbmNlbC5lcnJvcn0gYnVzeT17Y2FuY2VsLnBlbmRpbmd9IG9uQ29uZmlybT17cmVhc29uID0+IGNhbmNlbC5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBwPy52ZXJzaW9uIHx8IDEsIHJlYXNvbiB9IH0pfS8+XHJcbiA8RWRpdERpYWxvZyBvcGVuPXthY3Rpb24gPT09ICdjb25maXJtJ30gdGl0bGU9XCJHaGkgbmjhuq1uIHjDoWMgbmjhuq1uIGPhu6dhIG5ow6AgY3VuZyBj4bqlcFwiIG9uQ2xvc2U9eygpID0+IHNldEFjdGlvbihudWxsKX0gYnVzeT17Y29uZmlybS5wZW5kaW5nfSBkcmFmdENvbW1pdD17ZHJhZnRDb21taXR9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshZXh0ZXJuYWwgfHwgIXByb29mIHx8IGNvbmZpcm0ucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xyXG4gICAgICAgIGF3YWl0IGNvbmZpcm0uZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZCB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogcD8udmVyc2lvbiB8fCAxLCBleHRlcm5hbFJlZmVyZW5jZTogZXh0ZXJuYWwsIHN1cHBsaWVyQ29uZmlybWF0aW9uUmVmOiBwcm9vZiB9IH0pO1xyXG4gICAgICAgIHNldERyYWZ0Q29tbWl0KHByZXZpb3VzID0+ICh7IHNjb3BlOiBudWxsLCBzZXF1ZW5jZTogKHByZXZpb3VzPy5zZXF1ZW5jZSB8fCAwKSArIDEgfSkpO1xyXG4gICAgICAgIHNldEFjdGlvbihudWxsKTtcclxuICAgIH1cclxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19PkdoaSB4w6FjIG5o4bqtbjwvQnV0dG9uPn0+PEVycm9yTm90aWNlIGVycm9yPXtjb25maXJtLmVycm9yfS8+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgbGFiZWw9XCJUaGFtIGNoaeG6v3UgxJHGoW4gcGjDrWEgbmjDoCBjdW5nIGPhuqVwXCIgdmFsdWU9e2V4dGVybmFsfSBvbkNoYW5nZT17ZSA9PiBzZXRFeHRlcm5hbChlLnRhcmdldC52YWx1ZSl9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIGLhurFuZyBjaOG7qW5nIHjDoWMgbmjhuq1uXCIgdmFsdWU9e3Byb29mfSBvbkNoYW5nZT17ZSA9PiBzZXRQcm9vZihlLnRhcmdldC52YWx1ZSl9Lz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gUmVjZWlwdHNQYWdlKCkge1xyXG4gICAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RHb29kc1JlY2VpcHRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0R29vZHNSZWNlaXB0cycpIH0pO1xyXG4gICAgY29uc3Qgb3JkZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RQdXJjaGFzZU9yZGVycycpO1xyXG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbb3JkZXJJZCwgc2V0T3JkZXJJZF0gPSB1c2VTdGF0ZSgoKSA9PiBzZWFyY2hQYXJhbXMuZ2V0KCdwdXJjaGFzZU9yZGVySWQnKSB8fCAnJyksIFtkb2N1bWVudCwgc2V0RG9jdW1lbnRdID0gdXNlU3RhdGUoJycpLCBbcXVhbnRpdGllcywgc2V0UXVhbnRpdGllc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCB7IGFjY2VwdGVkOiBzdHJpbmc7IHJlamVjdGVkOiBzdHJpbmc7IHJlYXNvbjogc3RyaW5nIH0+Pih7fSksIFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpLCBbY29uZmlybVBvc3QsIHNldENvbmZpcm1Qb3N0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IHB1cmNoYXNlT3JkZXIgPSB1c2VBcGkoJ2dldFB1cmNoYXNlT3JkZXInLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogb3JkZXJJZCB9IH0sICEhb3JkZXJJZCk7XHJcbiAgICBjb25zdCBvcmRlciA9IHB1cmNoYXNlT3JkZXIuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IHJlY2VpcHREZXRhaWwgPSB1c2VBcGkoJ2dldEdvb2RzUmVjZWlwdCcsIHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZElkIHx8ICcnIH0gfSwgISFzZWxlY3RlZElkKTtcclxuICAgIGNvbnN0IHJlY2VpcHQ6IEdvb2RzUmVjZWlwdCB8IHVuZGVmaW5lZCA9IHJlY2VpcHREZXRhaWwuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IGNyZWF0ZSA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUdvb2RzUmVjZWlwdCcsIFsnbGlzdEdvb2RzUmVjZWlwdHMnXSk7XHJcbiAgICBjb25zdCBwb3N0ID0gdXNlQ29tbWFuZCgncG9zdEdvb2RzUmVjZWlwdCcsIFsnZ2V0R29vZHNSZWNlaXB0JywgJ2dldFB1cmNoYXNlT3JkZXInLCAnbGlzdEdvb2RzUmVjZWlwdHMnLCAnbGlzdFB1cmNoYXNlT3JkZXJzJywgJ2xpc3RTdG9ja1NuYXBzaG90cycsICdsaXN0RGVidEl0ZW1zJywgJ2xpc3RKb3VybmFscyddKTtcclxuICAgIGNvbnN0IHJlY2VpcHRMaW5lcyA9IG9yZGVyPy5saW5lcy5mbGF0TWFwKGxpbmUgPT4ge1xyXG4gICAgICAgIGNvbnN0IGlucHV0ID0gcXVhbnRpdGllc1tsaW5lLmlkXSB8fCB7IGFjY2VwdGVkOiAnMCcsIHJlamVjdGVkOiAnMCcsIHJlYXNvbjogJycgfTtcclxuICAgICAgICBjb25zdCBhY2NlcHRlZCA9IE51bWJlcihpbnB1dC5hY2NlcHRlZCB8fCAwKSwgcmVqZWN0ZWQgPSBOdW1iZXIoaW5wdXQucmVqZWN0ZWQgfHwgMCk7XHJcbiAgICAgICAgcmV0dXJuIGFjY2VwdGVkICsgcmVqZWN0ZWQgPiAwID8gW3sgcHVyY2hhc2VMaW5lSWQ6IGxpbmUuaWQsIGFjY2VwdGVkUXVhbnRpdHk6IGFjY2VwdGVkLCByZWplY3RlZFF1YW50aXR5OiByZWplY3RlZCwgcmVhc29uOiBpbnB1dC5yZWFzb24udHJpbSgpIH1dIDogW107XHJcbiAgICB9KSB8fCBbXTtcclxuICAgIGNvbnN0IHJlY2VpcHRMaW5lc1ZhbGlkID0gISFvcmRlciAmJiByZWNlaXB0TGluZXMubGVuZ3RoID4gMCAmJiByZWNlaXB0TGluZXMuZXZlcnkoaW5wdXQgPT4ge1xyXG4gICAgICAgIGNvbnN0IG9yaWdpbmFsID0gb3JkZXIubGluZXMuZmluZChsaW5lID0+IGxpbmUuaWQgPT09IGlucHV0LnB1cmNoYXNlTGluZUlkKTtcclxuICAgICAgICBjb25zdCByZW1haW5pbmcgPSBvcmlnaW5hbCA/IG9yaWdpbmFsLnF1YW50aXR5IC0gb3JpZ2luYWwucmVjZWl2ZWRRdWFudGl0eSAtIG9yaWdpbmFsLnJlamVjdGVkUXVhbnRpdHkgOiAwO1xyXG4gICAgICAgIHJldHVybiBOdW1iZXIuaXNJbnRlZ2VyKGlucHV0LmFjY2VwdGVkUXVhbnRpdHkpICYmIGlucHV0LmFjY2VwdGVkUXVhbnRpdHkgPj0gMCAmJiBOdW1iZXIuaXNJbnRlZ2VyKGlucHV0LnJlamVjdGVkUXVhbnRpdHkpICYmIGlucHV0LnJlamVjdGVkUXVhbnRpdHkgPj0gMCAmJiBpbnB1dC5hY2NlcHRlZFF1YW50aXR5ICsgaW5wdXQucmVqZWN0ZWRRdWFudGl0eSA8PSByZW1haW5pbmcgJiYgKGlucHV0LnJlamVjdGVkUXVhbnRpdHkgPT09IDAgfHwgISFpbnB1dC5yZWFzb24pICYmIGNvZGVQb2ludExlbmd0aChpbnB1dC5yZWFzb24pIDw9IDEwMDA7XHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGNyZWF0ZVZhbGlkID0gISFvcmRlciAmJiBbJ2NvbmZpcm1lZCcsICdwYXJ0X3JlY2VpdmVkJ10uaW5jbHVkZXMob3JkZXIuc3RhdHVzKSAmJiBkb2N1bWVudC50cmltKCkubGVuZ3RoID4gMCAmJiBjb2RlUG9pbnRMZW5ndGgoZG9jdW1lbnQudHJpbSgpKSA8PSAxNjAgJiYgcmVjZWlwdExpbmVzVmFsaWQgJiYgIWNyZWF0ZS5wZW5kaW5nO1xyXG4gICAgY29uc3QgY3JlYXRlUmVjZWlwdCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBpZiAoIWNyZWF0ZVZhbGlkIHx8ICFvcmRlcikgcmV0dXJuO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZS5leGVjdXRlKHsgYm9keTogeyBwdXJjaGFzZU9yZGVySWQ6IG9yZGVyLmlkLCBleHBlY3RlZFB1cmNoYXNlVmVyc2lvbjogb3JkZXIudmVyc2lvbiwgc291cmNlRG9jdW1lbnRSZWY6IGRvY3VtZW50LnRyaW0oKSwgbGluZXM6IHJlY2VpcHRMaW5lcyB9IH0pO1xyXG4gICAgICAgICAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0T3JkZXJJZCgnJyk7XHJcbiAgICAgICAgICAgIHNldERvY3VtZW50KCcnKTtcclxuICAgICAgICAgICAgc2V0UXVhbnRpdGllcyh7fSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIHsgLyogcmV0YWluIGNoZWNrZWQgcXVhbnRpdGllcyBhbmQgZG9jdW1lbnQgYWZ0ZXIgQVBJIHJlamVjdGlvbiAqLyB9XHJcbiAgICB9O1xyXG4gICAgY29uc3QgcG9zdFJlY2VpcHQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyZWNlaXB0IHx8IHJlY2VpcHQuc3RhdHVzICE9PSAnZHJhZnQnKSByZXR1cm47XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgcG9zdC5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiByZWNlaXB0LmlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiByZWNlaXB0LnZlcnNpb24gfSB9KTtcclxuICAgICAgICAgICAgc2V0Q29uZmlybVBvc3QoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXRjaCB7IC8qIGxlYXZlIHRoZSBkaWFsb2cgYW5kIHVzZXIgaW50ZW50IHZpc2libGUgZm9yIHJlY29uY2lsaWF0aW9uICovIH1cclxuICAgIH07XHJcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIk5o4bqtbiBow6BuZ1wiIHN1YnRpdGxlPVwiTmjhuq1uIHThu6tuZyBwaOG6p24sIGdoaSBow6BuZyDEkeG6oXQvaOG7j25nOyBjaOG7iSBow6BuZyDEkeG6oXQgbMOgbSB0xINuZyB04buTbiB2w6AgY8O0bmcgbuG7oyBtw7QgcGjhu49uZy5cIiBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByb2N1cmVtZW50LndyaXRlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IHsgc2V0T3JkZXJJZChzZWFyY2hQYXJhbXMuZ2V0KCdwdXJjaGFzZU9yZGVySWQnKSB8fCAnJyk7IHNldERvY3VtZW50KCcnKTsgc2V0UXVhbnRpdGllcyh7fSk7IHNldE9wZW4odHJ1ZSk7IH19PlThuqFvIHBoaeG6v3Ugbmjhuq1uPC9NdXRhdGlvbkJ1dHRvbj59Lz48UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdEdvb2RzUmVjZWlwdHNcIiAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIlBoaeG6v3Ugbmjhuq1uIGjDoG5nXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17ciA9PiByLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnUGhp4bq/dSBuaOG6rW4nLCByZW5kZXI6IHIgPT4gci5pZCB9LCB7IGtleTogJ3BvJywgbGFiZWw6ICfEkMahbiBtdWEnLCByZW5kZXI6IHIgPT4gci5wdXJjaGFzZU9yZGVySWQgfSwgeyBrZXk6ICdzb3VyY2UnLCBsYWJlbDogJ0No4bupbmcgdOG7qyBuZ3Xhu5NuJywgcmVuZGVyOiByID0+IHIuc291cmNlRG9jdW1lbnRSZWYgfSwgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIHZhbHVlPXtyLnN0YXR1c30vPiB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHIgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC5yZWNlaXZlXCIgZGlzYWJsZWQ9e3Iuc3RhdHVzICE9PSAnZHJhZnQnfSBvbkNsaWNrPXsoKSA9PiB7IHNldENvbmZpcm1Qb3N0KGZhbHNlKTsgc2V0U2VsZWN0ZWRJZChyLmlkKTsgfX0+WGVtIC8gZ2hpIG5o4bqtbiBwaGnhur91PC9NdXRhdGlvbkJ1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gICAgPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9XCJQaGnhur91IG5o4bqtbiBow6BuZyBt4bubaVwiIG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfSBidXN5PXtjcmVhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjcmVhdGVWYWxpZH0gb25DbGljaz17KCkgPT4gdm9pZCBjcmVhdGVSZWNlaXB0KCl9PlThuqFvIHBoaeG6v3UgbmjDoXA8L0J1dHRvbj59PlxyXG4gICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yfS8+PEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwixJDGoW4gbXVhIMSRw6MgeMOhYyBuaOG6rW5cIiBzZWxlY3QgdmFsdWU9e29yZGVySWR9IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldE9yZGVySWQoZXZlbnQudGFyZ2V0LnZhbHVlKTsgc2V0UXVhbnRpdGllcyh7fSk7IH19IGRpc2FibGVkPXtvcmRlcnMuaXNQZW5kaW5nICYmICFvcmRlcnMuZGF0YX0+XHJcbiAgICAgICAgICAgICAgICB7b3JkZXJJZCAmJiAhb3JkZXJzLmRhdGE/LmRhdGEuc29tZShpdGVtID0+IGl0ZW0uaWQgPT09IG9yZGVySWQpICYmIDxNZW51SXRlbSB2YWx1ZT17b3JkZXJJZH0+e29yZGVyPy5pZCB8fCAocHVyY2hhc2VPcmRlci5pc1BlbmRpbmcgPyAnxJBhbmcgdOG6o2kgxJHGoW4gxJHDoyBjaOG7jW7igKYnIDogb3JkZXJJZCl9PC9NZW51SXRlbT59XHJcbiAgICAgICAgICAgICAgICB7b3JkZXJzLmRhdGE/LmRhdGEuZmlsdGVyKGl0ZW0gPT4gWydjb25maXJtZWQnLCAncGFydF9yZWNlaXZlZCddLmluY2x1ZGVzKGl0ZW0uc3RhdHVzKSkubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmlkfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cIsSRxqFuIG11YVwiIGxvYWRlZENvdW50PXtvcmRlcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e29yZGVycy5oYXNNb3JlfSBidXN5PXtvcmRlcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17b3JkZXJzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgIHtvcmRlcnMuaXNFcnJvciAmJiA8RmllbGRHcm91cCA+PEVycm9yTm90aWNlIGVycm9yPXtvcmRlcnMuZXJyb3J9Lz48QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHsgdm9pZCAob3JkZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gb3JkZXJzLmxvYWRNb3JlKCkgOiBvcmRlcnMucmVmZXRjaCgpKTsgfX0+VGjhu60gbOG6oWkgZGFuaCBzw6FjaCDEkcahbiBtdWE8L0J1dHRvbj48L0ZpZWxkR3JvdXA+fVxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHBoaeG6v3UgZ2lhbyAvIGNo4bupbmcgdOG7qyBuZ3Xhu5NuXCIgdmFsdWU9e2RvY3VtZW50fSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0RG9jdW1lbnQobGltaXRDb2RlUG9pbnRzKGV2ZW50LnRhcmdldC52YWx1ZSwgMTYwKSl9IC8+XHJcbiAgICAgICAgICAgIHtvcmRlcklkICYmIDxRdWVyeVN0YXRlIHF1ZXJ5PXtwdXJjaGFzZU9yZGVyfT57b3JkZXIgJiYgPEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICAgICAge29yZGVyLmxpbmVzLm1hcChsaW5lID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpbnB1dCA9IHF1YW50aXRpZXNbbGluZS5pZF0gfHwgeyBhY2NlcHRlZDogJzAnLCByZWplY3RlZDogJzAnLCByZWFzb246ICcnIH07XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVtYWluaW5nID0gbGluZS5xdWFudGl0eSAtIGxpbmUucmVjZWl2ZWRRdWFudGl0eSAtIGxpbmUucmVqZWN0ZWRRdWFudGl0eTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpbnZhbGlkID0gISFpbnB1dC5hY2NlcHRlZCAmJiAhTnVtYmVyLmlzSW50ZWdlcihOdW1iZXIoaW5wdXQuYWNjZXB0ZWQpKSB8fCAhIWlucHV0LnJlamVjdGVkICYmICFOdW1iZXIuaXNJbnRlZ2VyKE51bWJlcihpbnB1dC5yZWplY3RlZCkpIHx8IE51bWJlcihpbnB1dC5hY2NlcHRlZCB8fCAwKSArIE51bWJlcihpbnB1dC5yZWplY3RlZCB8fCAwKSA+IHJlbWFpbmluZyB8fCAoTnVtYmVyKGlucHV0LnJlamVjdGVkIHx8IDApID4gMCAmJiAhaW5wdXQucmVhc29uLnRyaW0oKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxGb3JtRmllbGRzIGtleT17bGluZS5pZH0gYm9keU1vZGU9XCJvdXRsaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT5Nw6MgYmnhur9uIHRo4buDOiB7bGluZS52YXJpYW50SWR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPsSQ4bq3dCB7bGluZS5xdWFudGl0eX0gwrcgxJHDoyBuaOG6rW4ge2xpbmUucmVjZWl2ZWRRdWFudGl0eX0gwrcgYuG7iyB04burIGNo4buRaSB7bGluZS5yZWplY3RlZFF1YW50aXR5fSDCtyBjw7JuIHtyZW1haW5pbmd9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRHcm91cCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD17YE5o4bqtbiDEkeG6oXQgbcOjIGJp4bq/biB0aOG7gyAke2xpbmUudmFyaWFudElkfWB9IHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17aW5wdXQuYWNjZXB0ZWR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRRdWFudGl0aWVzKHByZXZpb3VzID0+ICh7IC4uLnByZXZpb3VzLCBbbGluZS5pZF06IHsgLi4uaW5wdXQsIGFjY2VwdGVkOiBldmVudC50YXJnZXQudmFsdWUgfSB9KSl9IGlucHV0UHJvcHM9e3sgbWluOiAwLCBtYXg6IHJlbWFpbmluZywgc3RlcDogMSB9fSBlcnJvcj17aW52YWxpZH0vPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD17YFThu6sgY2jhu5FpIC8gaOG7j25nIG3DoyBiaeG6v24gdGjhu4MgJHtsaW5lLnZhcmlhbnRJZH1gfSB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e2lucHV0LnJlamVjdGVkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UXVhbnRpdGllcyhwcmV2aW91cyA9PiAoeyAuLi5wcmV2aW91cywgW2xpbmUuaWRdOiB7IC4uLmlucHV0LCByZWplY3RlZDogZXZlbnQudGFyZ2V0LnZhbHVlIH0gfSkpfSBpbnB1dFByb3BzPXt7IG1pbjogMCwgbWF4OiByZW1haW5pbmcsIHN0ZXA6IDEgfX0gZXJyb3I9e2ludmFsaWR9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPXtgR2hpIGNow7oga2nhu4NtIGjDoG5nIG3DoyBiaeG6v24gdGjhu4MgJHtsaW5lLnZhcmlhbnRJZH1gfSBmdWxsV2lkdGggdmFsdWU9e2lucHV0LnJlYXNvbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFF1YW50aXRpZXMocHJldmlvdXMgPT4gKHsgLi4ucHJldmlvdXMsIFtsaW5lLmlkXTogeyAuLi5pbnB1dCwgcmVhc29uOiBsaW1pdENvZGVQb2ludHMoZXZlbnQudGFyZ2V0LnZhbHVlLCAxMDAwKSB9IH0pKX0gIGVycm9yPXtpbnZhbGlkICYmIE51bWJlcihpbnB1dC5yZWplY3RlZCB8fCAwKSA+IDB9IGhlbHBlclRleHQ9e051bWJlcihpbnB1dC5yZWplY3RlZCB8fCAwKSA+IDAgJiYgIWlucHV0LnJlYXNvbi50cmltKCkgPyAnQ+G6p24gZ2hpIHLDtSBsw70gZG8gaMOgbmcgYuG7iyB04burIGNo4buRaS4nIDogdW5kZWZpbmVkfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPjtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+fTwvUXVlcnlTdGF0ZT59XHJcbiAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgPEVkaXREaWFsb2cgb3Blbj17ISFzZWxlY3RlZElkfSB0aXRsZT17YFBoaeG6v3Ugbmjhuq1uICR7c2VsZWN0ZWRJZCB8fCAnJ31gfSBvbkNsb3NlPXsoKSA9PiB7IHNldENvbmZpcm1Qb3N0KGZhbHNlKTsgc2V0U2VsZWN0ZWRJZChudWxsKTsgfX0gYnVzeT17cG9zdC5wZW5kaW5nfSBhY3Rpb25zPXs8RmllbGRHcm91cCBkaXJlY3Rpb249XCJyb3dcIiA+XHJcbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldENvbmZpcm1Qb3N0KGZhbHNlKTsgc2V0U2VsZWN0ZWRJZChudWxsKTsgfX0+xJDDs25nPC9CdXR0b24+XHJcbiAgICAgICAge3JlY2VpcHQ/LnN0YXR1cyA9PT0gJ2RyYWZ0JyAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cInByb2N1cmVtZW50LnJlY2VpdmVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17cG9zdC5wZW5kaW5nfSBkaXNhYmxlZD17cmVjZWlwdERldGFpbC5pc0xvYWRpbmd9IG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1Qb3N0KHRydWUpfT5LaeG7g20gJiBnaGkgbmjhuq1uIHbDoG8ga2hvPC9NdXRhdGlvbkJ1dHRvbj59XHJcbiAgICA8L0ZpZWxkR3JvdXA+fT5cclxuICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e3JlY2VpcHREZXRhaWwuZXJyb3IgfHwgcG9zdC5lcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtyZWNlaXB0RGV0YWlsfT57cmVjZWlwdCAmJiA8RmllbGRHcm91cCA+XHJcbiAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwixJDGoW4gbXVhXCI+e3JlY2VpcHQucHVyY2hhc2VPcmRlcklkfTwvRGV0YWlsTGluZT5cclxuICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJDaOG7qW5nIHThu6sgbmd14buTblwiPntyZWNlaXB0LnNvdXJjZURvY3VtZW50UmVmfTwvRGV0YWlsTGluZT5cclxuICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJUcuG6oW5nIHRow6FpXCI+PFN0YXR1cyB2YWx1ZT17cmVjZWlwdC5zdGF0dXN9Lz48L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJDw6FjIGTDsm5nIGtp4buDbSBuaOG6rW5cIiByb3dzPXtyZWNlaXB0LmxpbmVzfSByb3dLZXk9e2xpbmUgPT4gbGluZS5wdXJjaGFzZUxpbmVJZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdsaW5lJywgbGFiZWw6ICdEw7JuZyDEkcahbiBtdWEnLCByZW5kZXI6IGxpbmUgPT4gbGluZS5wdXJjaGFzZUxpbmVJZCB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdhY2NlcHRlZCcsIGxhYmVsOiAnTmjhuq1uIMSR4bqhdCcsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGxpbmUgPT4gbGluZS5hY2NlcHRlZFF1YW50aXR5IH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ3JlamVjdGVkJywgbGFiZWw6ICdU4burIGNo4buRaScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGxpbmUgPT4gbGluZS5yZWplY3RlZFF1YW50aXR5IH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiBsaW5lID0+IGxpbmUucmVhc29uIHx8ICfigJQnIH0sXHJcbiAgICAgICAgICAgIF19Lz5cclxuICAgICAgICAgICAge3JlY2VpcHQuc3RhdHVzID09PSAncG9zdGVkJyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCI+UGhp4bq/dSDEkcOjIMSRxrDhu6NjIGdoaSBuaOG6rW4uIEdoaSBz4buVIGtoby9jw7RuZyBu4bujIGtow7RuZyB0aOG7gyBn4butaSBs4bqhaSB04burIHRy4bqhbmcgdGjDoWkgbsOgeS48L0FsZXJ0Pn1cclxuICAgICAgICA8L0ZpZWxkR3JvdXA+fTwvUXVlcnlTdGF0ZT5cclxuICAgIDwvRWRpdERpYWxvZz5cclxuICAgIDxDb25maXJtRGlhbG9nIG9wZW49e2NvbmZpcm1Qb3N0ICYmICEhc2VsZWN0ZWRJZCAmJiByZWNlaXB0Py5zdGF0dXMgPT09ICdkcmFmdCd9IHRpdGxlPVwiR2hpIG5o4bqtbiBow6BuZyDEkcOjIGtp4buDbSB2w6BvIGtob1wiIGNvbmZpcm1MYWJlbD1cIkdoaSBuaOG6rW4gdsOgbyBraG9cIiBkZXNjcmlwdGlvbj17YFBoaeG6v3UgJHtyZWNlaXB0Py5pZCB8fCAnJ306ICR7cmVjZWlwdD8ubGluZXMubWFwKGxpbmUgPT4gYCR7bGluZS5hY2NlcHRlZFF1YW50aXR5fSBuaOG6rW4gxJHhuqF0LCAke2xpbmUucmVqZWN0ZWRRdWFudGl0eX0gdOG7qyBjaOG7kWlgKS5qb2luKCc7ICcpIHx8ICcnfS4gQ2jhu4kgbMaw4bujbmcgxJHhuqF0IHTEg25nIHThu5NuIHbDoCBjw7RuZyBu4bujIG3DtCBwaOG7j25nOyBBUEkga2nhu4NtIGzhuqFpIHZlcnNpb24gdsOgIGNo4buRbmcgZ2hpIHRyw7luZy5gfSBvbkNsb3NlPXsoKSA9PiBzZXRDb25maXJtUG9zdChmYWxzZSl9IGJ1c3k9e3Bvc3QucGVuZGluZ30gZXJyb3I9e3Bvc3QuZXJyb3J9IG9uQ29uZmlybT17cG9zdFJlY2VpcHR9Lz48Lz47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN1cHBsaWVyU25hcHNob3Qoc3VwcGxpZXI6IFN1cHBsaWVyKSB7XHJcbiAgICByZXR1cm4geyB2ZXJzaW9uOiBzdXBwbGllci52ZXJzaW9uLCB2YWx1ZXM6IHsgbmFtZTogc3VwcGxpZXIubmFtZSwgY29udGFjdDogc3VwcGxpZXIuY29udGFjdExhYmVsLCBsZWFkOiBTdHJpbmcoc3VwcGxpZXIubGVhZFRpbWVEYXlzKSwgdGVybXM6IHN1cHBsaWVyLnBheW1lbnRUZXJtcywgbWV0aG9kOiBzdXBwbGllci5zZW5kTWV0aG9kLCBhZGFwdGVyOiBzdXBwbGllci5hcHByb3ZlZEFkYXB0ZXJJZCB8fCAnJyB9IH07XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvcHJvY3VyZW1lbnQvaW5kZXgudHN4In0=