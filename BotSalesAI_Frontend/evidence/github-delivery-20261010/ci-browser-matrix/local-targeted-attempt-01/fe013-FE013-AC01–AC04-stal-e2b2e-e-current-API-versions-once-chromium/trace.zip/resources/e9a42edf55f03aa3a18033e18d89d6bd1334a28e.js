import { setFault, setRole, resetService } from "/src/mocks/service.ts";
import { loadLargeCustomerDataset } from "/src/mocks/database.ts";
import { loadEmptyManagementDataset } from "/src/mocks/finance-dataset.ts";
export async function setMockControl(key, value) {
  if (!__MOCK__)
    throw new Error("Mock control bị tắt.");
  if (key === "role")
    setRole(value);
  else if (key === "dataset") {
    if (value === "seed")
      resetService();
    else if (value === "large-customers")
      loadLargeCustomerDataset();
    else if (value === "finance-empty") {
      resetService();
      loadEmptyManagementDataset();
    } else
      throw new Error("Không hỗ trợ bộ dữ liệu mô phỏng.");
  } else if (key === "reset")
    resetService();
  else if (key === "fault") {
    const mode = { normal: "none", slow: "slow", error: "error", error_persistent: "error_persistent", error_persistent_all: "error_persistent_all", forbidden: "forbidden", conflict: "stale", empty: "empty", empty_persistent: "empty_persistent", unknown: "unknown", budget_exceeded: "budget_exceeded", tool_denied: "tool_denied" }[value];
    if (!mode)
      throw new Error("Không hỗ trợ trạng thái.");
    setFault(mode);
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRyb2wudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2V0RmF1bHQsIHNldFJvbGUsIHJlc2V0U2VydmljZSB9IGZyb20gJy4vc2VydmljZSc7XG5pbXBvcnQgeyBsb2FkTGFyZ2VDdXN0b21lckRhdGFzZXQgfSBmcm9tICcuL2RhdGFiYXNlJztcbmltcG9ydCB7bG9hZEVtcHR5TWFuYWdlbWVudERhdGFzZXR9IGZyb20gJy4vZmluYW5jZS1kYXRhc2V0JztcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNb2NrQ29udHJvbChrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xuICAgIGlmICghX19NT0NLX18pXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTW9jayBjb250cm9sIGLhu4sgdOG6r3QuJyk7XG4gICAgaWYgKGtleSA9PT0gJ3JvbGUnKVxuICAgICAgICBzZXRSb2xlKHZhbHVlKTtcbiAgICBlbHNlIGlmIChrZXkgPT09ICdkYXRhc2V0Jykge1xuICAgICAgICBpZiAodmFsdWUgPT09ICdzZWVkJylcbiAgICAgICAgICAgIHJlc2V0U2VydmljZSgpO1xuICAgICAgICBlbHNlIGlmICh2YWx1ZSA9PT0gJ2xhcmdlLWN1c3RvbWVycycpXG4gICAgICAgICAgICBsb2FkTGFyZ2VDdXN0b21lckRhdGFzZXQoKTtcbiAgICAgICAgZWxzZSBpZiAodmFsdWUgPT09ICdmaW5hbmNlLWVtcHR5Jykge1xuICAgICAgICAgICAgcmVzZXRTZXJ2aWNlKCk7bG9hZEVtcHR5TWFuYWdlbWVudERhdGFzZXQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0tow7RuZyBo4buXIHRy4bujIGLhu5kgZOG7ryBsaeG7h3UgbcO0IHBo4buPbmcuJyk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGtleSA9PT0gJ3Jlc2V0JylcbiAgICAgICAgcmVzZXRTZXJ2aWNlKCk7XG4gICAgZWxzZSBpZiAoa2V5ID09PSAnZmF1bHQnKSB7XG4gICAgICAgIGNvbnN0IG1vZGUgPSAoeyBub3JtYWw6ICdub25lJywgc2xvdzogJ3Nsb3cnLCBlcnJvcjogJ2Vycm9yJywgZXJyb3JfcGVyc2lzdGVudDogJ2Vycm9yX3BlcnNpc3RlbnQnLCBlcnJvcl9wZXJzaXN0ZW50X2FsbDogJ2Vycm9yX3BlcnNpc3RlbnRfYWxsJywgZm9yYmlkZGVuOiAnZm9yYmlkZGVuJywgY29uZmxpY3Q6ICdzdGFsZScsIGVtcHR5OiAnZW1wdHknLCBlbXB0eV9wZXJzaXN0ZW50OiAnZW1wdHlfcGVyc2lzdGVudCcsIHVua25vd246ICd1bmtub3duJywgYnVkZ2V0X2V4Y2VlZGVkOiAnYnVkZ2V0X2V4Y2VlZGVkJywgdG9vbF9kZW5pZWQ6ICd0b29sX2RlbmllZCcgfSBhcyBjb25zdClbdmFsdWUgYXMgJ25vcm1hbCddO1xuICAgICAgICBpZiAoIW1vZGUpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0tow7RuZyBo4buXIHRy4bujIHRy4bqhbmcgdGjDoWkuJyk7XG4gICAgICAgIHNldEZhdWx0KG1vZGUpO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFNBQVMsb0JBQW9CO0FBQ2hELFNBQVMsZ0NBQWdDO0FBQ3pDLFNBQVEsa0NBQWlDO0FBQ3pDLHNCQUFzQixlQUFlLEtBQWEsT0FBZTtBQUM3RCxNQUFJLENBQUM7QUFDRCxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFDMUMsTUFBSSxRQUFRO0FBQ1IsWUFBUSxLQUFLO0FBQUEsV0FDUixRQUFRLFdBQVc7QUFDeEIsUUFBSSxVQUFVO0FBQ1YsbUJBQWE7QUFBQSxhQUNSLFVBQVU7QUFDZiwrQkFBeUI7QUFBQSxhQUNwQixVQUFVLGlCQUFpQjtBQUNoQyxtQkFBYTtBQUFFLGlDQUEyQjtBQUFBLElBQzlDO0FBRUksWUFBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQUEsRUFDM0QsV0FDUyxRQUFRO0FBQ2IsaUJBQWE7QUFBQSxXQUNSLFFBQVEsU0FBUztBQUN0QixVQUFNLE9BQVEsRUFBRSxRQUFRLFFBQVEsTUFBTSxRQUFRLE9BQU8sU0FBUyxrQkFBa0Isb0JBQW9CLHNCQUFzQix3QkFBd0IsV0FBVyxhQUFhLFVBQVUsU0FBUyxPQUFPLFNBQVMsa0JBQWtCLG9CQUFvQixTQUFTLFdBQVcsaUJBQWlCLG1CQUFtQixhQUFhLGNBQWMsRUFBWSxLQUFpQjtBQUNuVyxRQUFJLENBQUM7QUFDRCxZQUFNLElBQUksTUFBTSwwQkFBMEI7QUFDOUMsYUFBUyxJQUFJO0FBQUEsRUFDakI7QUFDSjsiLCJuYW1lcyI6W119