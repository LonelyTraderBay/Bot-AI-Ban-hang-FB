import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/management.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react_jsx-dev-runtime.js?v=585edd0d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react.js?v=585edd0d"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react-router-dom.js?v=585edd0d";
import { Alert, Button, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/@mui_material.js?v=585edd0d";
import { useForm, useWatch, useFieldArray } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react-hook-form.js?v=585edd0d";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/@hookform_resolvers_zod.js?v=585edd0d";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/zod.js?v=585edd0d";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { useVersionedDraft, draftEqual } from "/src/shared/model/versioned-draft.ts";
import { dateTime, dateOnlyInTimezone, isValidDateOnly, codePointLength, formatDateOnly } from "/src/shared/model/format.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { ActionGroup, FormFields, SurfaceContent } from "/src/shared/ui/composition.tsx";
import { Amount, ConfirmDialog, DataTable, DetailLine, EditDialog, ErrorNotice, LookupLoadMore, MutationButton, PageHeader, Pager, Panel, QueryState, RouteLink, Stat, Stats, Status, Toolbar } from "/src/shared/ui/components.tsx";
import { useReportRange, ReportRangeFields } from "/src/modules/finance/report-range.tsx";
import { accountGroupName } from "/src/modules/finance/accounts.tsx";
export function BookProvenance({ report }) {
  _s();
  const { shop } = useScope();
  return /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
    /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dữ liệu tại", children: dateTime(report.asOf, shop.timezone) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 42,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: report.policyVersion || "Chưa có" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mức đầy đủ", children: /* @__PURE__ */ jsxDEV(Status, { value: report.completeness || "incomplete" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 44,
      columnNumber: 40
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    report.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: w }, w, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 45,
      columnNumber: 37
    }, this)),
    report.sourceJournalIds && /* @__PURE__ */ jsxDEV(ActionGroup, { children: report.sourceJournalIds.length ? report.sourceJournalIds.map((id) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/journals?journalId=${encodeURIComponent(id)}`, children: [
      "Chứng từ ",
      id
    ] }, id, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 46,
      columnNumber: 120
    }, this)) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Không có bút toán trong khoảng này." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 46,
      columnNumber: 243
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 46,
      columnNumber: 37
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 41,
    columnNumber: 10
  }, this);
}
_s(BookProvenance, "24fT8/FpGlVhGqHka90etXz7lQ8=", false, function() {
  return [useScope];
});
_c = BookProvenance;
export function LedgerPage() {
  _s2();
  const { shop } = useScope(), range = useReportRange(shop.timezone), [params, setParams] = useSearchParams();
  const accountId = params.get("accountId") || void 0, cursor = params.get("cursor") || void 0;
  const accounts = usePagedApi("listAccounts");
  const query = useApi("getLedger", { query: { ...range.query, accountId, cursor, limit: 20 } }, range.valid), report = query.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Sổ cái", subtitle: "Tổng Nợ, Có và số dư lấy từ toàn bộ chứng từ trong khoảng; phân trang chỉ áp dụng các dòng chi tiết." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 54,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: range.range, timezone: shop.timezone, setFrom: range.setFrom, setTo: range.setTo }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 55,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { afterGap: "section", children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Tài khoản sổ cái", value: accountId || "", onChange: (e) => {
        const next = new URLSearchParams(params);
        next.delete("cursor");
        if (e.target.value) next.set("accountId", e.target.value);
        else next.delete("accountId");
        setParams(next);
      }, children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả tài khoản" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        accountId && !accounts.data?.data.some((a) => a.id === accountId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: accountId, children: [
          "Đang giữ tài khoản ",
          accountId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 57,
          columnNumber: 129
        }, this),
        accounts.data?.data.map((a) => /* @__PURE__ */ jsxDEV(MenuItem, { value: a.id, children: [
          a.code,
          " · ",
          a.name
        ] }, a.id, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 57,
          columnNumber: 231
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 56,
        columnNumber: 40
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: accounts.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 57,
        columnNumber: 309
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "tài khoản", loadedCount: accounts.loadedCount, hasMore: accounts.hasMore, busy: accounts.isLoadingMore, onLoadMore: accounts.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 57,
        columnNumber: 347
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 56,
      columnNumber: 9
    }, this),
    range.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query, pendingProfile: "section", children: report && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Số dư đầu khoảng (Nợ − Có)", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.openingBalance }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 143
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 95
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tổng phát sinh Nợ", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.totalDebit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 231
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 192
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tổng phát sinh Có", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.totalCredit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 315
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 276
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Số dư cuối khoảng (Nợ − Có)", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.closingBalance }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 410
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 361
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 58,
        columnNumber: 88
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Các dòng sổ cái", children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Sổ cái theo chứng từ", rows: report.entries, rowKey: (r) => r.id, columns: [
          { key: "date", label: "Ngày hiệu lực", render: (r) => formatDateOnly(r.effectiveDate) },
          { key: "account", label: "Tài khoản", render: (r) => `${r.accountCode} · ${r.accountName}` },
          { key: "note", label: "Diễn giải", render: (r) => r.description },
          { key: "debit", label: "Nợ", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.debit }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 59,
            columnNumber: 305
          }, this) },
          { key: "credit", label: "Có", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.credit }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 59,
            columnNumber: 380
          }, this) },
          { key: "balance", label: "Số dư tài khoản (Nợ − Có)", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.balance }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 59,
            columnNumber: 480
          }, this) },
          { key: "source", label: "Chứng từ", render: (r) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/journals?journalId=${r.journalId}`, children: [
            "Mã chứng từ: ",
            r.journalId
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 59,
            columnNumber: 563
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 58,
          columnNumber: 498
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: report.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 60,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 58,
        columnNumber: 467
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Nguồn và giới hạn", bodyMode: "inset", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(BookProvenance, { report }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 60,
        columnNumber: 121
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 60,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 58,
      columnNumber: 86
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 58,
      columnNumber: 24
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 60,
      columnNumber: 183
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 54,
    columnNumber: 10
  }, this);
}
_s2(LedgerPage, "WthLo1N8h9TjdQPOtSdCm1f4NDY=", false, function() {
  return [useScope, useReportRange, useSearchParams, usePagedApi, useApi];
});
_c2 = LedgerPage;
export function TrialBalancePage() {
  _s3();
  const { shop } = useScope(), range = useReportRange(shop.timezone), query = useApi("getTrialBalance", { query: range.query }, range.valid), report = query.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Cân đối phát sinh", subtitle: "Số dư đầu, phát sinh và số dư cuối do read-model tổng hợp đầy đủ theo tài khoản." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 65,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: range.range, timezone: shop.timezone, setFrom: range.setFrom, setTo: range.setTo }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 65,
      columnNumber: 144
    }, this),
    range.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query, pendingProfile: "section", children: report && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Phát sinh Nợ", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.totalDebit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 129
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 95
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Phát sinh Có", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.totalCredit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 208
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 174
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chênh lệch cuối", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.difference }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 291
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 254
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Kiểm cân bằng", value: report.balanced ? "Cân bằng" : "Không cân bằng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 66,
          columnNumber: 336
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 66,
        columnNumber: 88
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Cân đối theo tài khoản", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Cân đối phát sinh các tài khoản", rows: report.rows, rowKey: (r) => r.accountId, columns: [
        { key: "code", label: "Tài khoản", render: (r) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/ledger?accountId=${r.accountId}&fromDate=${range.range.from}&toDate=${range.range.to}`, children: [
          r.code,
          " · ",
          r.name
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 61
        }, this) },
        { key: "openingDebit", label: "Đầu kỳ Nợ", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.openingDebit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 280
        }, this) },
        { key: "openingCredit", label: "Đầu kỳ Có", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.openingCredit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 376
        }, this) },
        { key: "debit", label: "Phát sinh Nợ", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.debit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 468
        }, this) },
        { key: "credit", label: "Phát sinh Có", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.credit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 553
        }, this) },
        { key: "closingDebit", label: "Cuối kỳ Nợ", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.closingDebit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 643
        }, this) },
        { key: "closingCredit", label: "Cuối kỳ Có", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.closingCredit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 67,
          columnNumber: 740
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 66,
        columnNumber: 468
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 66,
        columnNumber: 430
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Nguồn và giới hạn", bodyMode: "inset", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(BookProvenance, { report }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 68,
        columnNumber: 93
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 68,
        columnNumber: 23
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 66,
      columnNumber: 86
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 66,
      columnNumber: 24
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 68,
      columnNumber: 155
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 65,
    columnNumber: 10
  }, this);
}
_s3(TrialBalancePage, "RoR5LL2vmrhrVGPShZQeh5NfjcU=", false, function() {
  return [useScope, useReportRange, useApi];
});
_c3 = TrialBalancePage;
export function BalanceSheetPage() {
  _s4();
  const { shop } = useScope(), [params, setParams] = useSearchParams();
  const atDate = params.get("atDate") ?? dateOnlyInTimezone(/* @__PURE__ */ new Date(), shop.timezone), valid = isValidDateOnly(atDate);
  const query = useApi("getBalanceSheet", { query: { atDate } }, valid), report = query.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Cân đối quản trị", subtitle: "Tài sản = nợ phải trả + vốn chủ sở hữu + kết quả lũy kế; đây là báo cáo quản trị theo chính sách của shop." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 74,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { afterGap: "section", children: /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Tại ngày", value: atDate, onChange: (e) => {
      const next = new URLSearchParams(params);
      next.set("atDate", e.target.value);
      setParams(next);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 74,
      columnNumber: 200
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 74,
      columnNumber: 169
    }, this),
    valid ? /* @__PURE__ */ jsxDEV(QueryState, { query, pendingProfile: "section", children: report && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tài sản", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.assets }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 118
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 89
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Nợ phải trả", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.liabilities }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 192
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 159
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Vốn chủ sở hữu", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.equity }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 274
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 238
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Kết quả lũy kế", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.retainedProfit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 351
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 315
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 75,
        columnNumber: 82
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Kiểm cân đối", bodyMode: "inset", children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Cân bằng", children: report.balanced ? "Có" : "Không" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 453
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chênh lệch", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: report.difference }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 560
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 75,
          columnNumber: 529
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 75,
        columnNumber: 408
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Số dư theo nhóm", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Tài khoản của báo cáo cân đối quản trị", rows: report.rows, rowKey: (r) => r.accountId, columns: [
        { key: "code", label: "Tài khoản", render: (r) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/ledger?accountId=${r.accountId}`, children: [
          r.code,
          " · ",
          r.name
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 76,
          columnNumber: 61
        }, this) },
        { key: "group", label: "Nhóm", render: (r) => accountGroupName[r.group] },
        { key: "balance", label: "Số dư theo chiều nhóm", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.balance }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 76,
          columnNumber: 308
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 75,
        columnNumber: 673
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 75,
        columnNumber: 622
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Nguồn và giới hạn", bodyMode: "inset", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(BookProvenance, { report }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 77,
        columnNumber: 93
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 77,
        columnNumber: 23
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 75,
      columnNumber: 80
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 75,
      columnNumber: 18
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Chọn ngày hợp lệ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 77,
      columnNumber: 155
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 74,
    columnNumber: 10
  }, this);
}
_s4(BalanceSheetPage, "F8By7Su9rska+WRqpcxBYk7iDx8=", false, function() {
  return [useScope, useSearchParams, useApi];
});
_c4 = BalanceSheetPage;
const exact = z.string().regex(/^\d+(\.\d{1,4})?$/, "Nhập số không âm, tối đa 4 chữ số thập phân.");
const moneySchema = z.object({ amount: exact, currency: z.string().min(1) });
const reasonSchema = z.string().refine((v) => codePointLength(v) <= 1e3, "Lý do tối đa 1.000 ký tự.").trim().min(5, "Lý do cần ít nhất 5 ký tự.");
const periodSchema = z.object({ startDate: z.string().refine(isValidDateOnly, "Chọn ngày hợp lệ."), endDate: z.string().refine(isValidDateOnly, "Chọn ngày hợp lệ."), reason: reasonSchema }).refine((v) => v.startDate <= v.endDate, { path: ["endDate"], message: "Ngày cuối kỳ phải từ ngày đầu kỳ trở đi." });
export function CreatePeriodDialog({ onClose, onSaved }) {
  _s5();
  const create = useCommand("createAccountingPeriod", ["listAccountingPeriods"]);
  const form = useForm({ defaultValues: { startDate: "", endDate: "", reason: "" }, resolver: zodResolver(periodSchema) });
  useWatch({ control: form.control });
  const bind = useDraftForm(form.formState.isDirty), ref = useRef(null);
  return /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: "Tạo kỳ kế toán", onClose, busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "period-create", variant: "contained", disabled: create.pending || create.unresolved, children: "Tạo kỳ kế toán" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 88,
    columnNumber: 99
  }, this), children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 88,
      columnNumber: 234
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "period-create", noValidate: true, ref: (node) => {
      ref.current = node;
      bind(node);
    }, "data-draft-clean": !form.formState.isDirty ? "true" : void 0, onSubmit: form.handleSubmit(async (values) => {
      try {
        await create.execute({ body: values });
        if (ref.current) markDraftClean(ref.current);
        onSaved();
        onClose();
      } catch {
      }
    }), children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Kỳ mới phải không chồng lấn kỳ đã có; API kiểm lại trước khi tạo." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 90,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Ngày đầu kỳ", type: "date", ...form.register("startDate"), error: Boolean(form.formState.errors.startDate), helperText: form.formState.errors.startDate?.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 91,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Ngày cuối kỳ", type: "date", ...form.register("endDate"), error: Boolean(form.formState.errors.endDate), helperText: form.formState.errors.endDate?.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 92,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do tạo kỳ", ...form.register("reason"), error: Boolean(form.formState.errors.reason), helperText: form.formState.errors.reason?.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 93,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 88,
    columnNumber: 10
  }, this);
}
_s5(CreatePeriodDialog, "0aDQG1uXUJbus+UicCtG2ad85m8=", false, function() {
  return [useCommand, useForm, useWatch, useDraftForm];
});
_c5 = CreatePeriodDialog;
const openingSchema = z.object({ effectiveDate: z.string().refine(isValidDateOnly, "Chọn ngày hợp lệ."), policyVersion: z.literal("synthetic-policy-1"), reason: reasonSchema, lines: z.array(z.object({ accountId: z.string().min(1, "Chọn tài khoản."), debit: moneySchema, credit: moneySchema, description: z.string().refine((v) => codePointLength(v) <= 300, "Diễn giải tối đa 300 ký tự.").trim().min(1, "Nhập diễn giải.") })), inventory: z.array(z.object({ variantId: z.string().min(1, "Chọn biến thể."), warehouseId: z.string().min(1, "Chọn kho."), quantity: z.number().int().min(0, "Số lượng không âm."), unitCost: moneySchema })) }).superRefine((values, ctx) => {
  const units = (a) => {
    const [n = "", f = ""] = a.split(".");
    return /^\d+(\.\d{1,4})?$/.test(a) ? BigInt(n) * 10000n + BigInt(f.padEnd(4, "0")) : 0n;
  };
  let d = 0n, c = 0n;
  values.lines.forEach((line, i) => {
    const debit = units(line.debit.amount), credit = units(line.credit.amount);
    d += debit;
    c += credit;
    if (debit > 0n === credit > 0n) ctx.addIssue({ code: "custom", path: ["lines", i, "debit", "amount"], message: "Mỗi dòng cần đúng một bên Nợ hoặc Có dương." });
  });
  if (d !== c) ctx.addIssue({ code: "custom", path: ["lines", 0, "debit", "amount"], message: "Tổng số dư Nợ phải bằng tổng số dư Có." });
  const keys = /* @__PURE__ */ new Set();
  values.inventory.forEach((line, i) => {
    const key = `${line.warehouseId}:${line.variantId}`;
    if (keys.has(key)) ctx.addIssue({ code: "custom", path: ["inventory", i, "variantId"], message: "Không lặp kho/biến thể." });
    keys.add(key);
  });
});
const snapshot = (r) => ({ version: r.version, values: { effectiveDate: r.effectiveDate, policyVersion: r.policyVersion, reason: r.reason, lines: r.lines, inventory: r.inventory } });
export function OpeningBalancesPage() {
  _s6();
  const { shop } = useScope(), can = useCan("finance.post");
  const list = useApi("listOpeningBalances", { query: useListQuery("listOpeningBalances") });
  const [open, setOpen] = useState(false), [selected, setSelected] = useState(null), [postRow, setPostRow] = useState(null), [success, setSuccess] = useState("");
  const detail = useApi("getOpeningBalance", { path: { openingId: selected?.id || "" } }, open && Boolean(selected));
  const accounts = usePagedApi("listAccounts", { query: { status: "active" } }), warehouses = usePagedApi("listWarehouses", { query: { status: "active" } }), products = usePagedApi("listProducts", { query: { status: "active" } });
  const create = useCommand("createOpeningBalance", ["listOpeningBalances"]), update = useCommand("updateOpeningBalance", ["listOpeningBalances", "getOpeningBalance"]), post = useCommand("postOpeningBalance", ["listOpeningBalances", "getOpeningBalance", "listStockSnapshots", "getLedger", "getTrialBalance", "getBalanceSheet", "getProfitLoss", "getCashflow", "listJournals"]);
  const empty = { effectiveDate: dateOnlyInTimezone(/* @__PURE__ */ new Date(), shop.timezone), policyVersion: "synthetic-policy-1", reason: "", lines: [], inventory: [] };
  const form = useForm({ defaultValues: empty, resolver: zodResolver(openingSchema) });
  useWatch({ control: form.control });
  const lines = useFieldArray({ control: form.control, name: "lines" }), inventory = useFieldArray({ control: form.control, name: "inventory" }), formRef = useRef(null);
  const editor = useVersionedDraft({ identity: `${shop.id}:opening:${selected?.id || "new"}`, source: detail.data ? snapshot(detail.data.data) : selected ? snapshot(selected) : void 0, draft: form.getValues(), apply: (v) => form.reset(v), refresh: () => detail.refetch({ throwOnError: true }) });
  const dirty = open && (selected ? editor.dirty : !draftEqual(empty, form.getValues())), bind = useDraftForm(dirty), busy = create.pending || update.pending, blocked = selected ? update.unresolved : create.unresolved;
  const submit = form.handleSubmit(async (values) => {
    if (!can || blocked) return;
    try {
      if (selected) {
        const prepared = editor.prepare();
        if (!prepared) return;
        const submitted = form.getValues();
        const result = await update.execute({ path: { openingId: selected.id }, version: prepared.version, body: values });
        if (!editor.committed(snapshot(result.data), submitted)) return;
      } else await create.execute({ body: values });
      if (formRef.current) markDraftClean(formRef.current);
      setOpen(false);
      setSuccess("Đã lưu nháp mở sổ. Kiểm lại số dư và tồn trước khi ghi sổ.");
    } catch (e) {
      editor.failed(e);
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Mở sổ kế toán", subtitle: "Ghi số dư và tồn đầu kỳ một lần sau đối chiếu; API chặn ghi đè shop đã có nghiệp vụ.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", variant: "contained", onClick: () => {
      setSelected(null);
      form.reset(empty);
      setOpen(true);
    }, children: "Tạo nháp mở sổ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 117,
      columnNumber: 151
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 117,
      columnNumber: 12
    }, this),
    success && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: success }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 117,
      columnNumber: 329
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listOpeningBalances" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 118,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Hồ sơ mở sổ", rows: list.data.data, rowKey: (r) => r.id, columns: [
          { key: "id", label: "Hồ sơ", render: (r) => r.id },
          { key: "date", label: "Ngày hiệu lực", render: (r) => formatDateOnly(r.effectiveDate) },
          { key: "reason", label: "Lý do", render: (r) => r.reason },
          { key: "status", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 119,
            columnNumber: 265
          }, this) },
          { key: "actions", label: "Thao tác", render: (r) => r.status === "draft" ? /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => {
              setSelected(r);
              form.reset(snapshot(r).values);
              setOpen(true);
            }, children: [
              "Sửa mở sổ ",
              r.id
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 119,
              columnNumber: 384
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setPostRow(r), children: [
              "Ghi mở sổ ",
              r.id
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 119,
              columnNumber: 538
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 119,
            columnNumber: 371
          }, this) : r.journalId ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/journals?journalId=${r.journalId}`, children: "Bút toán mở sổ" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 119,
            columnNumber: 674
          }, this) : "Mở sổ số dư bằng 0" }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 118,
          columnNumber: 125
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 120,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 118,
        columnNumber: 123
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 118,
        columnNumber: 59
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 118,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: selected ? `Sửa mở sổ ${selected.id}` : "Nháp mở sổ mới", onClose: () => setOpen(false), busy, actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "opening-form", variant: "contained", disabled: busy || blocked || !can || Boolean(selected) && !editor.dirty, children: "Lưu nháp mở sổ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 121,
      columnNumber: 150
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || detail.error || accounts.error || warehouses.error || products.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 122,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { effectiveDate: "Ngày hiệu lực", policyVersion: "Chính sách", reason: "Lý do", lines: "Toàn bộ số dư tài khoản", inventory: "Toàn bộ tồn đầu kỳ" }, busy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 122,
        columnNumber: 137
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "opening-form", noValidate: true, onSubmit: submit, ref: (node) => {
        formRef.current = node;
        bind(node);
      }, "data-draft-clean": !dirty ? "true" : void 0, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Số dư bằng 0 được phép để trống dòng. Giá trị tồn phải khớp tài khoản 156; số dư cần cân bằng và chỉ ghi trong kỳ đang mở." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 124,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Ngày mở sổ", ...form.register("effectiveDate"), error: Boolean(form.formState.errors.effectiveDate), helperText: form.formState.errors.effectiveDate?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 125,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Chính sách mở sổ", value: "synthetic-policy-1", InputProps: { readOnly: true } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 126,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "tài khoản mở sổ", loadedCount: accounts.loadedCount, hasMore: accounts.hasMore, busy: accounts.isLoadingMore, onLoadMore: accounts.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 127,
          columnNumber: 17
        }, this),
        lines.fields.map((field, i) => /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactOutlined", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
          /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Tài khoản số dư ${i + 1}`, ...form.register(`lines.${i}.accountId`), value: form.watch(`lines.${i}.accountId`), error: Boolean(form.formState.errors.lines?.[i]?.accountId), helperText: form.formState.errors.lines?.[i]?.accountId?.message, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn tài khoản" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 129,
              columnNumber: 287
            }, this),
            accounts.data?.data.map((a) => /* @__PURE__ */ jsxDEV(MenuItem, { value: a.id, children: [
              a.code,
              " · ",
              a.name
            ] }, a.id, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 129,
              columnNumber: 363
            }, this))
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 129,
            columnNumber: 21
          }, this),
          ["debit", "credit"].map((side) => /* @__PURE__ */ jsxDEV(TextField, { label: `${side === "debit" ? "Nợ" : "Có"} số dư ${i + 1} (${shop.currency})`, ...form.register(`lines.${i}.${side}.amount`), error: Boolean(form.formState.errors.lines?.[i]?.[side]?.amount), helperText: form.formState.errors.lines?.[i]?.[side]?.amount?.message, inputProps: { inputMode: "decimal" } }, side, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 130,
            columnNumber: 67
          }, this)),
          /* @__PURE__ */ jsxDEV(TextField, { label: `Diễn giải số dư ${i + 1}`, ...form.register(`lines.${i}.description`), error: Boolean(form.formState.errors.lines?.[i]?.description), helperText: form.formState.errors.lines?.[i]?.description?.message }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 131,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => lines.remove(i), children: [
            "Bỏ số dư ",
            i + 1
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 131,
            columnNumber: 245
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 128,
          columnNumber: 107
        }, this) }, field.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 128,
          columnNumber: 49
        }, this)),
        form.formState.errors.lines?.message && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: form.formState.errors.lines.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 133,
          columnNumber: 58
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => lines.append({ accountId: "", debit: { amount: "0", currency: shop.currency }, credit: { amount: "0", currency: shop.currency }, description: "" }), children: "Thêm số dư tài khoản" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 134,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "kho mở sổ", loadedCount: warehouses.loadedCount, hasMore: warehouses.hasMore, busy: warehouses.isLoadingMore, onLoadMore: warehouses.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 135,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "sản phẩm mở sổ", loadedCount: products.loadedCount, hasMore: products.hasMore, busy: products.isLoadingMore, onLoadMore: products.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 135,
          columnNumber: 184
        }, this),
        inventory.fields.map((field, i) => /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactOutlined", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
          /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Kho tồn đầu ${i + 1}`, ...form.register(`inventory.${i}.warehouseId`), value: form.watch(`inventory.${i}.warehouseId`), error: Boolean(form.formState.errors.inventory?.[i]?.warehouseId), helperText: form.formState.errors.inventory?.[i]?.warehouseId?.message, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn kho" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 137,
              columnNumber: 307
            }, this),
            warehouses.data?.data.map((w) => /* @__PURE__ */ jsxDEV(MenuItem, { value: w.id, children: [
              w.code,
              " · ",
              w.name
            ] }, w.id, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 137,
              columnNumber: 379
            }, this))
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 137,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Biến thể tồn đầu ${i + 1}`, ...form.register(`inventory.${i}.variantId`), value: form.watch(`inventory.${i}.variantId`), error: Boolean(form.formState.errors.inventory?.[i]?.variantId), helperText: form.formState.errors.inventory?.[i]?.variantId?.message, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn biến thể" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 138,
              columnNumber: 304
            }, this),
            products.data?.data.flatMap((p) => p.variants.map((v) => /* @__PURE__ */ jsxDEV(MenuItem, { value: v.id, children: [
              v.sku,
              " · ",
              p.name
            ] }, v.id, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
              lineNumber: 138,
              columnNumber: 405
            }, this)))
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 138,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: `Số lượng tồn đầu ${i + 1}`, ...form.register(`inventory.${i}.quantity`, { valueAsNumber: true }), error: Boolean(form.formState.errors.inventory?.[i]?.quantity), helperText: form.formState.errors.inventory?.[i]?.quantity?.message, inputProps: { inputMode: "numeric" } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 139,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: `Giá vốn đơn vị ${i + 1} (${shop.currency})`, ...form.register(`inventory.${i}.unitCost.amount`), error: Boolean(form.formState.errors.inventory?.[i]?.unitCost?.amount), helperText: form.formState.errors.inventory?.[i]?.unitCost?.amount?.message, inputProps: { inputMode: "decimal" } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 140,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => inventory.remove(i), children: [
            "Bỏ tồn đầu ",
            i + 1
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
            lineNumber: 140,
            columnNumber: 327
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 136,
          columnNumber: 111
        }, this) }, field.id, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 136,
          columnNumber: 53
        }, this)),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => inventory.append({ warehouseId: "", variantId: "", quantity: 0, unitCost: { amount: "0", currency: shop.currency } }), children: "Thêm tồn đầu kỳ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 142,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do mở sổ", multiline: true, minRows: 2, ...form.register("reason"), error: Boolean(form.formState.errors.reason), helperText: form.formState.errors.reason?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
          lineNumber: 143,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
        lineNumber: 123,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 121,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: Boolean(postRow), title: "Ghi mở sổ", confirmLabel: "Ghi mở sổ", description: `Hồ sơ ${postRow?.id || ""}, hiệu lực ${formatDateOnly(postRow?.effectiveDate)}: ghi số dư và tồn sau đối chiếu. Không sửa trực tiếp sau ghi; mọi điều kiện được API kiểm lại.`, busy: post.pending, error: post.error, onClose: () => setPostRow(null), onConfirm: async () => {
      if (!postRow) return;
      await post.execute({ path: { openingId: postRow.id }, body: { expectedVersion: postRow.version } });
      setSuccess("Đã ghi mở sổ; số dư và tồn lấy từ hồ sơ đã kiểm.");
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
      lineNumber: 146,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx",
    lineNumber: 117,
    columnNumber: 10
  }, this);
}
_s6(OpeningBalancesPage, "CgENY8JoNmS2dpQW/pXsyiC7+zc=", false, function() {
  return [useScope, useCan, useApi, useListQuery, useApi, usePagedApi, usePagedApi, usePagedApi, useCommand, useCommand, useCommand, useForm, useWatch, useFieldArray, useFieldArray, useVersionedDraft, useDraftForm];
});
_c6 = OpeningBalancesPage;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "BookProvenance");
$RefreshReg$(_c2, "LedgerPage");
$RefreshReg$(_c3, "TrialBalancePage");
$RefreshReg$(_c4, "BalanceSheetPage");
$RefreshReg$(_c5, "CreatePeriodDialog");
$RefreshReg$(_c6, "OpeningBalancesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/management.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRLFNBZ0J5RSxVQWhCekU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdEJSLFNBQVFBLFFBQU9DLGdCQUFlO0FBQzlCLFNBQVFDLHVCQUFzQjtBQUM5QixTQUFRQyxPQUFNQyxRQUFPQyxVQUFTQyxpQkFBZ0I7QUFDOUMsU0FBUUMsU0FBUUMsVUFBU0MscUJBQW9CO0FBQzdDLFNBQVFDLG1CQUFrQjtBQUMxQixTQUFRQyxTQUFRO0FBRWhCLFNBQVFDLFFBQU9DLFlBQVdDLG1CQUFrQjtBQUM1QyxTQUFRQyxVQUFTQyxjQUFhO0FBQzlCLFNBQVFDLG9CQUFtQjtBQUMzQixTQUFRQyxjQUFhQyxzQkFBcUI7QUFDMUMsU0FBUUMsbUJBQWtCQyxrQkFBaUI7QUFDM0MsU0FBUUMsVUFBU0Msb0JBQW1CQyxpQkFBZ0JDLGlCQUFnQkMsc0JBQXFCO0FBQ3pGLFNBQVFDLHFCQUFvQjtBQUM1QixTQUFRQyxhQUFZQyxZQUFXQyxzQkFBcUI7QUFDcEQsU0FBUUMsUUFBT0MsZUFBY0MsV0FBVUMsWUFBV0MsWUFBV0MsYUFBWUMsZ0JBQWVDLGdCQUFlQyxZQUFXQyxPQUFNQyxPQUFNQyxZQUFXQyxXQUFVQyxNQUFLQyxPQUFNQyxRQUFPQyxlQUFjO0FBQ25MLFNBQVFDLGdCQUFlQyx5QkFBd0I7QUFDL0MsU0FBUUMsd0JBQXVCO0FBRXhCLGdCQUFTQyxlQUFlLEVBQUNDLE9BQXNILEdBQUc7QUFBQUMsS0FBQTtBQUNySixRQUFNLEVBQUNDLEtBQUksSUFBRXZDLFNBQVM7QUFDdEIsU0FBTyx1QkFBQyxrQkFDSjtBQUFBLDJCQUFDLGNBQVcsT0FBTSxlQUFlTyxtQkFBUzhCLE9BQU9HLE1BQUtELEtBQUtFLFFBQVEsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRTtBQUFBLElBQ3JFLHVCQUFDLGNBQVcsT0FBTSxjQUFjSixpQkFBT0ssaUJBQWUsYUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRTtBQUFBLElBQ2hFLHVCQUFDLGNBQVcsT0FBTSxjQUFhLGlDQUFDLFVBQU8sT0FBT0wsT0FBT00sZ0JBQWMsZ0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRjtBQUFBLElBQ2pGTixPQUFPTyxTQUFTQyxJQUFJLENBQUFDLE1BQUcsdUJBQUMsU0FBYyxVQUFTLFdBQVdBLGVBQXZCQSxHQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUMsQ0FBUTtBQUFBLElBQ3BFVCxPQUFPVSxvQkFBa0IsdUJBQUMsZUFBYVYsaUJBQU9VLGlCQUFpQkMsU0FBT1gsT0FBT1UsaUJBQWlCRixJQUFJLENBQUFJLE9BQUksdUJBQUMsYUFBbUIsSUFBSSxNQUFNVixLQUFLVSxFQUFFLCtCQUErQkMsbUJBQW1CRCxFQUFFLENBQUMsSUFBSTtBQUFBO0FBQUEsTUFBVUE7QUFBQUEsU0FBeEZBLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkcsQ0FBWSxJQUFFLHVCQUFDLFNBQU0sVUFBUyxRQUFPLG1EQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBELEtBQWhRO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeVE7QUFBQSxPQUxoUztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTVA7QUFDSjtBQUFDWCxHQVRlRixnQkFBYztBQUFBLFVBQ2JwQyxRQUFRO0FBQUE7QUFBQSxLQURUb0M7QUFVVCxnQkFBU2UsYUFBYTtBQUFBQyxNQUFBO0FBQ3pCLFFBQU0sRUFBQ2IsS0FBSSxJQUFFdkMsU0FBUyxHQUFFcUQsUUFBTXBCLGVBQWVNLEtBQUtFLFFBQVEsR0FBRSxDQUFDYSxRQUFPQyxTQUFTLElBQUVwRSxnQkFBZ0I7QUFDL0YsUUFBTXFFLFlBQVVGLE9BQU9HLElBQUksV0FBVyxLQUFHQyxRQUFVQyxTQUFPTCxPQUFPRyxJQUFJLFFBQVEsS0FBR0M7QUFDaEYsUUFBTUUsV0FBUzdELFlBQVksY0FBYztBQUN6QyxRQUFNOEQsUUFBTWhFLE9BQU8sYUFBWSxFQUFDZ0UsT0FBTSxFQUFDLEdBQUdSLE1BQU1RLE9BQU1MLFdBQVVHLFFBQU9HLE9BQU0sR0FBRSxFQUFDLEdBQUVULE1BQU1VLEtBQUssR0FBRTFCLFNBQU93QixNQUFNRyxNQUFNQTtBQUNsSCxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLFVBQVMsVUFBUywwR0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSTtBQUFBLElBQy9JLHVCQUFDLHFCQUFrQixPQUFPWCxNQUFNQSxPQUFPLFVBQVVkLEtBQUtFLFVBQVUsU0FBU1ksTUFBTVksU0FBUyxPQUFPWixNQUFNYSxTQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJHO0FBQUEsSUFDM0csdUJBQUMsY0FBVyxVQUFTLFdBQVU7QUFBQSw2QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLG9CQUFtQixPQUFPVixhQUFXLElBQUksVUFBVSxDQUFBVyxNQUFHO0FBQUMsY0FBTUMsT0FBSyxJQUFJQyxnQkFBZ0JmLE1BQU07QUFBRWMsYUFBS0UsT0FBTyxRQUFRO0FBQUUsWUFBR0gsRUFBRUksT0FBT0MsTUFBTUosTUFBS0ssSUFBSSxhQUFZTixFQUFFSSxPQUFPQyxLQUFLO0FBQUEsWUFBT0osTUFBS0UsT0FBTyxXQUFXO0FBQUVmLGtCQUFVYSxJQUFJO0FBQUEsTUFBRSxHQUM1UTtBQUFBLCtCQUFDLFlBQVMsT0FBTSxJQUFHLGdDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsUUFBWVosYUFBVyxDQUFDSSxTQUFTSSxNQUFNQSxLQUFLVSxLQUFLLENBQUFDLE1BQUdBLEVBQUUxQixPQUFLTyxTQUFTLEtBQUcsdUJBQUMsWUFBUyxPQUFPQSxXQUFXO0FBQUE7QUFBQSxVQUFvQkE7QUFBQUEsYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFFBQWFJLFNBQVNJLE1BQU1BLEtBQUtuQixJQUFJLENBQUE4QixNQUFHLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUUxQixJQUFLMEI7QUFBQUEsWUFBRUM7QUFBQUEsVUFBSztBQUFBLFVBQUlELEVBQUVFO0FBQUFBLGFBQWpDRixFQUFFMUIsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRCxDQUFXO0FBQUEsV0FEalA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUNtUDtBQUFBLE1BQVksdUJBQUMsZUFBWSxPQUFPVyxTQUFTa0IsU0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLE1BQUUsdUJBQUMsa0JBQWUsT0FBTSxhQUFZLGFBQWFsQixTQUFTbUIsYUFBYSxTQUFTbkIsU0FBU29CLFNBQVMsTUFBTXBCLFNBQVNxQixlQUFlLFlBQVlyQixTQUFTc0IsWUFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SjtBQUFBLFNBRC9kO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDaWU7QUFBQSxJQUNoZTdCLE1BQU1VLFFBQU0sdUJBQUMsY0FBVyxPQUFjLGdCQUFlLFdBQVcxQixvQkFBUSxtQ0FBRTtBQUFBLDZCQUFDLFNBQU07QUFBQSwrQkFBQyxRQUFLLE9BQU0sOEJBQTZCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT0EsT0FBTzhDLGtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUFFLHVCQUFDLFFBQUssT0FBTSxxQkFBb0IsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPOUMsT0FBTytDLGNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLHFCQUFvQixPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU8vQyxPQUFPZ0QsZUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QyxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sK0JBQThCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT2hELE9BQU9pRCxrQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGO0FBQUEsV0FBelc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyVztBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLG1CQUFrQjtBQUFBLCtCQUFDLGFBQVUsT0FBTSx3QkFBdUIsTUFBTWpELE9BQU9rRCxTQUFTLFFBQVEsQ0FBQUMsTUFBR0EsRUFBRXZDLElBQUksU0FBUztBQUFBLFVBQ2pqQixFQUFDd0MsS0FBSSxRQUFPQyxPQUFNLGlCQUFnQkMsUUFBT0EsQ0FBQUgsTUFBRzdFLGVBQWU2RSxFQUFFSSxhQUFhLEVBQUM7QUFBQSxVQUFFLEVBQUNILEtBQUksV0FBVUMsT0FBTSxhQUFZQyxRQUFPQSxDQUFBSCxNQUFHLEdBQUdBLEVBQUVLLFdBQVcsTUFBTUwsRUFBRU0sV0FBVyxHQUFFO0FBQUEsVUFBRSxFQUFDTCxLQUFJLFFBQU9DLE9BQU0sYUFBWUMsUUFBT0EsQ0FBQUgsTUFBR0EsRUFBRU8sWUFBVztBQUFBLFVBQUUsRUFBQ04sS0FBSSxTQUFRQyxPQUFNLE1BQUtDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFUSxTQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QixFQUFFO0FBQUEsVUFBRSxFQUFDUCxLQUFJLFVBQVNDLE9BQU0sTUFBS0MsUUFBT0EsQ0FBQUgsTUFBRyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVTLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUU7QUFBQSxVQUFFLEVBQUNSLEtBQUksV0FBVUMsT0FBTSw2QkFBNEJDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFVSxXQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QixFQUFFO0FBQUEsVUFBRSxFQUFDVCxLQUFJLFVBQVNDLE9BQU0sWUFBV0MsUUFBT0EsQ0FBQUgsTUFBRyx1QkFBQyxhQUFVLElBQUksTUFBTWpELEtBQUtVLEVBQUUsK0JBQStCdUMsRUFBRVcsU0FBUyxJQUFJO0FBQUE7QUFBQSxZQUFjWCxFQUFFVztBQUFBQSxlQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRyxFQUFZO0FBQUEsUUFBQyxLQUQzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRTNkO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU05RCxPQUFPK0QsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFdBRmlhO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFL1o7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxxQkFBb0IsVUFBUyxTQUFRLFdBQVUsV0FBVSxpQ0FBQyxrQkFBZSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUc7QUFBQSxTQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRTZFLEtBRnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFNkksSUFBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxzREFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLE9BTm5PO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPUDtBQUNKO0FBQUNoRCxJQWJlRCxZQUFVO0FBQUEsVUFDVG5ELFVBQWlCaUMsZ0JBQWlEOUMsaUJBRWhFWSxhQUNIRixNQUFNO0FBQUE7QUFBQSxNQUpOc0Q7QUFjVCxnQkFBU2tELG1CQUFtQjtBQUFBQyxNQUFBO0FBQy9CLFFBQU0sRUFBQy9ELEtBQUksSUFBRXZDLFNBQVMsR0FBRXFELFFBQU1wQixlQUFlTSxLQUFLRSxRQUFRLEdBQUVvQixRQUFNaEUsT0FBTyxtQkFBa0IsRUFBQ2dFLE9BQU1SLE1BQU1RLE1BQUssR0FBRVIsTUFBTVUsS0FBSyxHQUFFMUIsU0FBT3dCLE1BQU1HLE1BQU1BO0FBQy9JLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0scUJBQW9CLFVBQVMsc0ZBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUk7QUFBQSxJQUFFLHVCQUFDLHFCQUFrQixPQUFPWCxNQUFNQSxPQUFPLFVBQVVkLEtBQUtFLFVBQVUsU0FBU1ksTUFBTVksU0FBUyxPQUFPWixNQUFNYSxTQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJHO0FBQUEsSUFDbFBiLE1BQU1VLFFBQU0sdUJBQUMsY0FBVyxPQUFjLGdCQUFlLFdBQVcxQixvQkFBUSxtQ0FBRTtBQUFBLDZCQUFDLFNBQU07QUFBQSwrQkFBQyxRQUFLLE9BQU0sZ0JBQWUsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPQSxPQUFPK0MsY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sZ0JBQWUsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPL0MsT0FBT2dELGVBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUMsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9oRCxPQUFPa0UsY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0saUJBQWdCLE9BQU9sRSxPQUFPbUUsV0FBUyxhQUFXLG9CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsV0FBalU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtVTtBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLDBCQUF5QixpQ0FBQyxhQUFVLE9BQU0sbUNBQWtDLE1BQU1uRSxPQUFPb0UsTUFBTSxRQUFRLENBQUFqQixNQUFHQSxFQUFFaEMsV0FBVyxTQUFTO0FBQUEsUUFDL2hCLEVBQUNpQyxLQUFJLFFBQU9DLE9BQU0sYUFBWUMsUUFBT0EsQ0FBQUgsTUFBRyx1QkFBQyxhQUFVLElBQUksTUFBTWpELEtBQUtVLEVBQUUsNkJBQTZCdUMsRUFBRWhDLFNBQVMsYUFBYUgsTUFBTUEsTUFBTXFELElBQUksV0FBV3JELE1BQU1BLE1BQU1zRCxFQUFFLElBQUtuQjtBQUFBQSxZQUFFWjtBQUFBQSxVQUFLO0FBQUEsVUFBSVksRUFBRVg7QUFBQUEsYUFBNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSixFQUFZO0FBQUEsUUFBRSxFQUFDWSxLQUFJLGdCQUFlQyxPQUFNLGFBQVlDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFb0IsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsRUFBRTtBQUFBLFFBQUUsRUFBQ25CLEtBQUksaUJBQWdCQyxPQUFNLGFBQVlDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFcUIsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0IsRUFBRTtBQUFBLFFBQUUsRUFBQ3BCLEtBQUksU0FBUUMsT0FBTSxnQkFBZUMsUUFBT0EsQ0FBQUgsTUFBRyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVRLFNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsRUFBRTtBQUFBLFFBQUUsRUFBQ1AsS0FBSSxVQUFTQyxPQUFNLGdCQUFlQyxRQUFPQSxDQUFBSCxNQUFHLHVCQUFDLFVBQU8sT0FBT0EsRUFBRVMsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QixFQUFFO0FBQUEsUUFBRSxFQUFDUixLQUFJLGdCQUFlQyxPQUFNLGNBQWFDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFc0IsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsRUFBRTtBQUFBLFFBQUUsRUFBQ3JCLEtBQUksaUJBQWdCQyxPQUFNLGNBQWFDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFdUIsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0IsRUFBRTtBQUFBLE1BQUMsS0FENU87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUUxYixLQUZvWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRWxaO0FBQUEsTUFBUSx1QkFBQyxTQUFNLE9BQU0scUJBQW9CLFVBQVMsU0FBUSxXQUFVLFdBQVUsaUNBQUMsa0JBQWUsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVHO0FBQUEsU0FGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVrRCxLQUY5RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRWtILElBQWMsdUJBQUMsU0FBTSxVQUFTLFNBQVEsc0RBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxPQUh4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSVA7QUFDSjtBQUFDVCxJQVBlRCxrQkFBZ0I7QUFBQSxVQUNmckcsVUFBaUJpQyxnQkFBb0NwQyxNQUFNO0FBQUE7QUFBQSxNQUQ1RHdHO0FBUVQsZ0JBQVNXLG1CQUFtQjtBQUFBQyxNQUFBO0FBQy9CLFFBQU0sRUFBQzFFLEtBQUksSUFBRXZDLFNBQVMsR0FBRSxDQUFDc0QsUUFBT0MsU0FBUyxJQUFFcEUsZ0JBQWdCO0FBQUUsUUFBTStILFNBQU81RCxPQUFPRyxJQUFJLFFBQVEsS0FBR2pELG1CQUFtQixvQkFBSTJHLEtBQUssR0FBRTVFLEtBQUtFLFFBQVEsR0FBRXNCLFFBQU10RCxnQkFBZ0J5RyxNQUFNO0FBQ3pLLFFBQU1yRCxRQUFNaEUsT0FBTyxtQkFBa0IsRUFBQ2dFLE9BQU0sRUFBQ3FELE9BQU0sRUFBQyxHQUFFbkQsS0FBSyxHQUFFMUIsU0FBT3dCLE1BQU1HLE1BQU1BO0FBQ2hGLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sb0JBQW1CLFVBQVMsZ0hBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEo7QUFBQSxJQUFFLHVCQUFDLGNBQVcsVUFBUyxXQUFVLGlDQUFDLGFBQVUsTUFBSyxRQUFPLE9BQU0sWUFBVyxPQUFPa0QsUUFBUSxVQUFVLENBQUEvQyxNQUFHO0FBQUMsWUFBTUMsT0FBSyxJQUFJQyxnQkFBZ0JmLE1BQU07QUFBRWMsV0FBS0ssSUFBSSxVQUFTTixFQUFFSSxPQUFPQyxLQUFLO0FBQUVqQixnQkFBVWEsSUFBSTtBQUFBLElBQUUsS0FBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnSyxLQUEvTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlNO0FBQUEsSUFDaldMLFFBQU0sdUJBQUMsY0FBVyxPQUFjLGdCQUFlLFdBQVcxQixvQkFBUSxtQ0FBRTtBQUFBLDZCQUFDLFNBQU07QUFBQSwrQkFBQyxRQUFLLE9BQU0sV0FBVSxPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9BLE9BQU8rRSxVQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUFFLHVCQUFDLFFBQUssT0FBTSxlQUFjLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBTy9FLE9BQU9nRixlQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUFFLHVCQUFDLFFBQUssT0FBTSxrQkFBaUIsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPaEYsT0FBT2lGLFVBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0MsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLGtCQUFpQixPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9qRixPQUFPa0Ysa0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBQXBUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc1Q7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxnQkFBZSxVQUFTLFNBQVE7QUFBQSwrQkFBQyxjQUFXLE9BQU0sWUFBWWxGLGlCQUFPbUUsV0FBUyxPQUFLLFdBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUFhLHVCQUFDLGNBQVcsT0FBTSxjQUFhLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9uRSxPQUFPa0UsY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsV0FBNUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5TTtBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLG1CQUFrQixXQUFVLFdBQVUsaUNBQUMsYUFBVSxPQUFNLDBDQUF5QyxNQUFNbEUsT0FBT29FLE1BQU0sUUFBUSxDQUFBakIsTUFBR0EsRUFBRWhDLFdBQVcsU0FBUztBQUFBLFFBQ2p2QixFQUFDaUMsS0FBSSxRQUFPQyxPQUFNLGFBQVlDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsYUFBVSxJQUFJLE1BQU1qRCxLQUFLVSxFQUFFLDZCQUE2QnVDLEVBQUVoQyxTQUFTLElBQUtnQztBQUFBQSxZQUFFWjtBQUFBQSxVQUFLO0FBQUEsVUFBSVksRUFBRVg7QUFBQUEsYUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRixFQUFZO0FBQUEsUUFBRSxFQUFDWSxLQUFJLFNBQVFDLE9BQU0sUUFBT0MsUUFBT0EsQ0FBQUgsTUFBR3JELGlCQUFpQnFELEVBQUVnQyxLQUFLLEVBQUM7QUFBQSxRQUFFLEVBQUMvQixLQUFJLFdBQVVDLE9BQU0seUJBQXdCQyxRQUFPQSxDQUFBSCxNQUFHLHVCQUFDLFVBQU8sT0FBT0EsRUFBRVUsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QixFQUFFO0FBQUEsTUFBQyxLQURnVztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRXJvQixLQUZrbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVobEI7QUFBQSxNQUFRLHVCQUFDLFNBQU0sT0FBTSxxQkFBb0IsVUFBUyxTQUFRLFdBQVUsV0FBVSxpQ0FBQyxrQkFBZSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUc7QUFBQSxTQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXdELEtBRnBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFd0gsSUFBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxpQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLE9BSG5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJUDtBQUNKO0FBQUNlLElBUmVELGtCQUFnQjtBQUFBLFVBQ2ZoSCxVQUE4QmIsaUJBQy9CVSxNQUFNO0FBQUE7QUFBQSxNQUZObUg7QUFTaEIsTUFBTVMsUUFBTTdILEVBQUU4SCxPQUFPLEVBQUVDLE1BQU0scUJBQW9CLDhDQUE4QztBQUMvRixNQUFNQyxjQUFZaEksRUFBRWlJLE9BQU8sRUFBQ0MsUUFBT0wsT0FBTU0sVUFBU25JLEVBQUU4SCxPQUFPLEVBQUVNLElBQUksQ0FBQyxFQUFDLENBQUM7QUFDcEUsTUFBTUMsZUFBYXJJLEVBQUU4SCxPQUFPLEVBQUVRLE9BQU8sQ0FBQUMsTUFBR3pILGdCQUFnQnlILENBQUMsS0FBRyxLQUFLLDJCQUEyQixFQUFFQyxLQUFLLEVBQUVKLElBQUksR0FBRSw0QkFBNEI7QUFDdkksTUFBTUssZUFBYXpJLEVBQUVpSSxPQUFPLEVBQUNTLFdBQVUxSSxFQUFFOEgsT0FBTyxFQUFFUSxPQUFPekgsaUJBQWdCLG1CQUFtQixHQUFFOEgsU0FBUTNJLEVBQUU4SCxPQUFPLEVBQUVRLE9BQU96SCxpQkFBZ0IsbUJBQW1CLEdBQUUrSCxRQUFPUCxhQUFZLENBQUMsRUFBRUMsT0FBTyxDQUFBQyxNQUFHQSxFQUFFRyxhQUFXSCxFQUFFSSxTQUFRLEVBQUNFLE1BQUssQ0FBQyxTQUFTLEdBQUVDLFNBQVEsMkNBQTBDLENBQUM7QUFDbFIsZ0JBQVNDLG1CQUFtQixFQUFDQyxTQUFRQyxRQUEyQyxHQUFHO0FBQUFDLE1BQUE7QUFDdEYsUUFBTUMsU0FBT2pKLFdBQVcsMEJBQXlCLENBQUMsdUJBQXVCLENBQUM7QUFDMUUsUUFBTWtKLE9BQUt4SixRQUFzQyxFQUFDeUosZUFBYyxFQUFDWCxXQUFVLElBQUdDLFNBQVEsSUFBR0MsUUFBTyxHQUFFLEdBQUVVLFVBQVN2SixZQUFZMEksWUFBWSxFQUFDLENBQUM7QUFBRTVJLFdBQVMsRUFBQzBKLFNBQVFILEtBQUtHLFFBQU8sQ0FBQztBQUN4SyxRQUFNQyxPQUFLakosYUFBYTZJLEtBQUtLLFVBQVVDLE9BQU8sR0FBRUMsTUFBSXRLLE9BQTZCLElBQUk7QUFDckYsU0FBTyx1QkFBQyxjQUFXLE1BQUksTUFBQyxPQUFNLGtCQUFpQixTQUFrQixNQUFNOEosT0FBT1MsU0FBUyxTQUFTLHVCQUFDLFVBQU8sTUFBSyxVQUFTLE1BQUssaUJBQWdCLFNBQVEsYUFBWSxVQUFVVCxPQUFPUyxXQUFTVCxPQUFPVSxZQUFZLDhCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBILEdBQVc7QUFBQSwyQkFBQyxlQUFZLE9BQU9WLE9BQU9qRSxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDbFEsdUJBQUMsY0FBVyxXQUFVLFFBQU8sSUFBRyxpQkFBZ0IsWUFBVSxNQUFDLEtBQUssQ0FBQTRFLFNBQU07QUFBQ0gsVUFBSUksVUFBUUQ7QUFBS04sV0FBS00sSUFBSTtBQUFBLElBQUUsR0FBRyxvQkFBa0IsQ0FBQ1YsS0FBS0ssVUFBVUMsVUFBUSxTQUFPNUYsUUFBVyxVQUFVc0YsS0FBS1ksYUFBYSxPQUFNQyxXQUFRO0FBQUMsVUFBRztBQUFDLGNBQU1kLE9BQU9lLFFBQVEsRUFBQ0MsTUFBS0YsT0FBTSxDQUFDO0FBQUUsWUFBR04sSUFBSUksUUFBUXZKLGdCQUFlbUosSUFBSUksT0FBTztBQUFFZCxnQkFBUTtBQUFFRCxnQkFBUTtBQUFBLE1BQUUsUUFBTTtBQUFBLE1BQUM7QUFBQSxJQUFpQyxDQUFDLEdBQ3pWO0FBQUEsNkJBQUMsU0FBTSxVQUFTLFFBQU8saUZBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Y7QUFBQSxNQUN4Rix1QkFBQyxhQUFVLE9BQU0sZUFBYyxNQUFLLFFBQU8sR0FBSUksS0FBS2dCLFNBQVMsV0FBVyxHQUFHLE9BQU9DLFFBQVFqQixLQUFLSyxVQUFVYSxPQUFPNUIsU0FBUyxHQUFHLFlBQVlVLEtBQUtLLFVBQVVhLE9BQU81QixXQUFXSSxXQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlMO0FBQUEsTUFDakwsdUJBQUMsYUFBVSxPQUFNLGdCQUFlLE1BQUssUUFBTyxHQUFJTSxLQUFLZ0IsU0FBUyxTQUFTLEdBQUcsT0FBT0MsUUFBUWpCLEtBQUtLLFVBQVVhLE9BQU8zQixPQUFPLEdBQUcsWUFBWVMsS0FBS0ssVUFBVWEsT0FBTzNCLFNBQVNHLFdBQXBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEs7QUFBQSxNQUM1Syx1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsR0FBSU0sS0FBS2dCLFNBQVMsUUFBUSxHQUFHLE9BQU9DLFFBQVFqQixLQUFLSyxVQUFVYSxPQUFPMUIsTUFBTSxHQUFHLFlBQVlRLEtBQUtLLFVBQVVhLE9BQU8xQixRQUFRRSxXQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZKO0FBQUEsU0FKaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsT0FORztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT1A7QUFDSjtBQUFDSSxJQVplSCxvQkFBa0I7QUFBQSxVQUNqQjdJLFlBQ0ZOLFNBQThIQyxVQUM5SFUsWUFBWTtBQUFBO0FBQUEsTUFIWHdJO0FBYWhCLE1BQU13QixnQkFBY3ZLLEVBQUVpSSxPQUFPLEVBQUNqQyxlQUFjaEcsRUFBRThILE9BQU8sRUFBRVEsT0FBT3pILGlCQUFnQixtQkFBbUIsR0FBRWlDLGVBQWM5QyxFQUFFd0ssUUFBUSxvQkFBb0IsR0FBRTVCLFFBQU9QLGNBQWFvQyxPQUFNekssRUFBRTBLLE1BQU0xSyxFQUFFaUksT0FBTyxFQUFDckUsV0FBVTVELEVBQUU4SCxPQUFPLEVBQUVNLElBQUksR0FBRSxpQkFBaUIsR0FBRWhDLE9BQU00QixhQUFZM0IsUUFBTzJCLGFBQVk3QixhQUFZbkcsRUFBRThILE9BQU8sRUFBRVEsT0FBTyxDQUFBQyxNQUFHekgsZ0JBQWdCeUgsQ0FBQyxLQUFHLEtBQUksNkJBQTZCLEVBQUVDLEtBQUssRUFBRUosSUFBSSxHQUFFLGlCQUFpQixFQUFDLENBQUMsQ0FBQyxHQUFFdUMsV0FBVTNLLEVBQUUwSyxNQUFNMUssRUFBRWlJLE9BQU8sRUFBQzJDLFdBQVU1SyxFQUFFOEgsT0FBTyxFQUFFTSxJQUFJLEdBQUUsZ0JBQWdCLEdBQUV5QyxhQUFZN0ssRUFBRThILE9BQU8sRUFBRU0sSUFBSSxHQUFFLFdBQVcsR0FBRTBDLFVBQVM5SyxFQUFFK0ssT0FBTyxFQUFFQyxJQUFJLEVBQUU1QyxJQUFJLEdBQUUsb0JBQW9CLEdBQUU2QyxVQUFTakQsWUFBVyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUVrRCxZQUFZLENBQUNqQixRQUFPa0IsUUFBTTtBQUNwbUIsUUFBTUMsUUFBTUEsQ0FBQ3JHLE1BQVc7QUFBQyxVQUFNLENBQUNzRyxJQUFFLElBQUdDLElBQUUsRUFBRSxJQUFFdkcsRUFBRXdHLE1BQU0sR0FBRztBQUFFLFdBQU8sb0JBQW9CQyxLQUFLekcsQ0FBQyxJQUFFMEcsT0FBT0osQ0FBQyxJQUFFLFNBQU9JLE9BQU9ILEVBQUVJLE9BQU8sR0FBRSxHQUFHLENBQUMsSUFBRTtBQUFBLEVBQUc7QUFBRSxNQUFJQyxJQUFFLElBQUdDLElBQUU7QUFDcEozQixTQUFPUSxNQUFNb0IsUUFBUSxDQUFDQyxNQUFLQyxNQUFJO0FBQUMsVUFBTTNGLFFBQU1nRixNQUFNVSxLQUFLMUYsTUFBTThCLE1BQU0sR0FBRTdCLFNBQU8rRSxNQUFNVSxLQUFLekYsT0FBTzZCLE1BQU07QUFBRXlELFNBQUd2RjtBQUFNd0YsU0FBR3ZGO0FBQU8sUUFBSUQsUUFBTSxPQUFPQyxTQUFPLEdBQUk4RSxLQUFJYSxTQUFTLEVBQUNoSCxNQUFLLFVBQVM2RCxNQUFLLENBQUMsU0FBUWtELEdBQUUsU0FBUSxRQUFRLEdBQUVqRCxTQUFRLDhDQUE2QyxDQUFDO0FBQUEsRUFBRSxDQUFDO0FBQzVRLE1BQUc2QyxNQUFJQyxFQUFFVCxLQUFJYSxTQUFTLEVBQUNoSCxNQUFLLFVBQVM2RCxNQUFLLENBQUMsU0FBUSxHQUFFLFNBQVEsUUFBUSxHQUFFQyxTQUFRLHlDQUF3QyxDQUFDO0FBQ3hILFFBQU1tRCxPQUFLLG9CQUFJQyxJQUFZO0FBQUVqQyxTQUFPVSxVQUFVa0IsUUFBUSxDQUFDQyxNQUFLQyxNQUFJO0FBQUMsVUFBTWxHLE1BQUksR0FBR2lHLEtBQUtqQixXQUFXLElBQUlpQixLQUFLbEIsU0FBUztBQUFHLFFBQUdxQixLQUFLRSxJQUFJdEcsR0FBRyxFQUFFc0YsS0FBSWEsU0FBUyxFQUFDaEgsTUFBSyxVQUFTNkQsTUFBSyxDQUFDLGFBQVlrRCxHQUFFLFdBQVcsR0FBRWpELFNBQVEsMEJBQXlCLENBQUM7QUFBRW1ELFNBQUtHLElBQUl2RyxHQUFHO0FBQUEsRUFBRSxDQUFDO0FBQ3hQLENBQUM7QUFDRCxNQUFNd0csV0FBU0EsQ0FBQ3pHLE9BQW9CLEVBQUMwRyxTQUFRMUcsRUFBRTBHLFNBQVFyQyxRQUFPLEVBQUNqRSxlQUFjSixFQUFFSSxlQUFjbEQsZUFBYzhDLEVBQUU5QyxlQUFzQzhGLFFBQU9oRCxFQUFFZ0QsUUFBTzZCLE9BQU03RSxFQUFFNkUsT0FBTUUsV0FBVS9FLEVBQUUrRSxVQUFTLEVBQUM7QUFFaE0sZ0JBQVM0QixzQkFBc0I7QUFBQUMsTUFBQTtBQUNsQyxRQUFNLEVBQUM3SixLQUFJLElBQUV2QyxTQUFTLEdBQUVxTSxNQUFJcE0sT0FBTyxjQUFjO0FBQUUsUUFBTXFNLE9BQUt6TSxPQUFPLHVCQUFzQixFQUFDZ0UsT0FBTTNELGFBQWEscUJBQXFCLEVBQUMsQ0FBQztBQUN0SSxRQUFNLENBQUNxTSxNQUFLQyxPQUFPLElBQUV0TixTQUFTLEtBQUssR0FBRSxDQUFDdU4sVUFBU0MsV0FBVyxJQUFFeE4sU0FBOEIsSUFBSSxHQUFFLENBQUN5TixTQUFRQyxVQUFVLElBQUUxTixTQUE4QixJQUFJLEdBQUUsQ0FBQzJOLFNBQVFDLFVBQVUsSUFBRTVOLFNBQVMsRUFBRTtBQUN6TCxRQUFNNk4sU0FBT2xOLE9BQU8scUJBQW9CLEVBQUM0SSxNQUFLLEVBQUN1RSxXQUFVUCxVQUFVeEosTUFBSSxHQUFFLEVBQUMsR0FBRXNKLFFBQU10QyxRQUFRd0MsUUFBUSxDQUFDO0FBQ25HLFFBQU03SSxXQUFTN0QsWUFBWSxnQkFBZSxFQUFDOEQsT0FBTSxFQUFDb0osUUFBTyxTQUFRLEVBQUMsQ0FBQyxHQUFFQyxhQUFXbk4sWUFBWSxrQkFBaUIsRUFBQzhELE9BQU0sRUFBQ29KLFFBQU8sU0FBUSxFQUFDLENBQUMsR0FBRUUsV0FBU3BOLFlBQVksZ0JBQWUsRUFBQzhELE9BQU0sRUFBQ29KLFFBQU8sU0FBUSxFQUFDLENBQUM7QUFDck0sUUFBTWxFLFNBQU9qSixXQUFXLHdCQUF1QixDQUFDLHFCQUFxQixDQUFDLEdBQUVzTixTQUFPdE4sV0FBVyx3QkFBdUIsQ0FBQyx1QkFBc0IsbUJBQW1CLENBQUMsR0FBRXVOLE9BQUt2TixXQUFXLHNCQUFxQixDQUFDLHVCQUFzQixxQkFBb0Isc0JBQXFCLGFBQVksbUJBQWtCLG1CQUFrQixpQkFBZ0IsZUFBYyxjQUFjLENBQUM7QUFDaFcsUUFBTXdOLFFBQW9CLEVBQUMxSCxlQUFjcEYsbUJBQW1CLG9CQUFJMkcsS0FBSyxHQUFFNUUsS0FBS0UsUUFBUSxHQUFFQyxlQUFjLHNCQUFxQjhGLFFBQU8sSUFBRzZCLE9BQU0sSUFBR0UsV0FBVSxHQUFFO0FBQ3hKLFFBQU12QixPQUFLeEosUUFBdUIsRUFBQ3lKLGVBQWNxRSxPQUFNcEUsVUFBU3ZKLFlBQVl3SyxhQUFhLEVBQUMsQ0FBQztBQUFFMUssV0FBUyxFQUFDMEosU0FBUUgsS0FBS0csUUFBTyxDQUFDO0FBQzVILFFBQU1rQixRQUFNM0ssY0FBYyxFQUFDeUosU0FBUUgsS0FBS0csU0FBUXRFLE1BQUssUUFBTyxDQUFDLEdBQUUwRixZQUFVN0ssY0FBYyxFQUFDeUosU0FBUUgsS0FBS0csU0FBUXRFLE1BQUssWUFBVyxDQUFDLEdBQUUwSSxVQUFRdE8sT0FBNkIsSUFBSTtBQUN6SyxRQUFNdU8sU0FBT25OLGtCQUFrQixFQUFDb04sVUFBUyxHQUFHbEwsS0FBS1UsRUFBRSxZQUFZd0osVUFBVXhKLE1BQUksS0FBSyxJQUFHeUssUUFBT1gsT0FBTy9JLE9BQUtpSSxTQUFTYyxPQUFPL0ksS0FBS0EsSUFBSSxJQUFFeUksV0FBU1IsU0FBU1EsUUFBUSxJQUFFL0ksUUFBVWlLLE9BQU0zRSxLQUFLNEUsVUFBVSxHQUFFQyxPQUFNQSxDQUFBMUYsTUFBR2EsS0FBSzhFLE1BQU0zRixDQUFDLEdBQUU0RixTQUFRQSxNQUFJaEIsT0FBT2lCLFFBQVEsRUFBQ0MsY0FBYSxLQUFJLENBQUMsRUFBQyxDQUFDO0FBQ3ZRLFFBQU1DLFFBQU0zQixTQUFPRSxXQUFTZSxPQUFPVSxRQUFNLENBQUM1TixXQUFXZ04sT0FBTXRFLEtBQUs0RSxVQUFVLENBQUMsSUFBR3hFLE9BQUtqSixhQUFhK04sS0FBSyxHQUFFQyxPQUFLcEYsT0FBT1MsV0FBUzRELE9BQU81RCxTQUFRNEUsVUFBUTNCLFdBQVNXLE9BQU8zRCxhQUFXVixPQUFPVTtBQUNyTCxRQUFNNEUsU0FBT3JGLEtBQUtZLGFBQWEsT0FBTUMsV0FBUTtBQUFDLFFBQUcsQ0FBQ3dDLE9BQUsrQixRQUFRO0FBQU8sUUFBSTtBQUFDLFVBQUczQixVQUFTO0FBQUMsY0FBTTZCLFdBQVNkLE9BQU9lLFFBQVE7QUFBRSxZQUFHLENBQUNELFNBQVM7QUFBTyxjQUFNRSxZQUFVeEYsS0FBSzRFLFVBQVU7QUFBRSxjQUFNYSxTQUFPLE1BQU1yQixPQUFPdEQsUUFBUSxFQUFDckIsTUFBSyxFQUFDdUUsV0FBVVAsU0FBU3hKLEdBQUUsR0FBRWlKLFNBQVFvQyxTQUFTcEMsU0FBUW5DLE1BQUtGLE9BQTZCLENBQUM7QUFBRSxZQUFHLENBQUMyRCxPQUFPa0IsVUFBVXpDLFNBQVN3QyxPQUFPekssSUFBSSxHQUFFd0ssU0FBUyxFQUFFO0FBQUEsTUFBTyxNQUFNLE9BQU16RixPQUFPZSxRQUFRLEVBQUNDLE1BQUtGLE9BQU0sQ0FBQztBQUFFLFVBQUcwRCxRQUFRNUQsUUFBUXZKLGdCQUFlbU4sUUFBUTVELE9BQU87QUFBRTZDLGNBQVEsS0FBSztBQUFFTSxpQkFBVyw0REFBNEQ7QUFBQSxJQUFFLFNBQU8zSSxHQUFFO0FBQUNxSixhQUFPbUIsT0FBT3hLLENBQUM7QUFBQSxJQUFFO0FBQUEsRUFBQyxDQUFDO0FBQzFqQixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLHdGQUF1RixTQUFTLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUSxhQUFZLFNBQVMsTUFBSTtBQUFDdUksa0JBQVksSUFBSTtBQUFFMUQsV0FBSzhFLE1BQU1SLEtBQUs7QUFBRWQsY0FBUSxJQUFJO0FBQUEsSUFBRSxHQUFHLDhCQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStJLEtBQTFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNFM7QUFBQSxJQUFHSyxXQUFTLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBVUEscUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUM5Vyx1QkFBQyxTQUFNO0FBQUEsNkJBQUMsV0FBUSxXQUFVLHlCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU9QLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS3RJLFFBQU0sbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sZUFBYyxNQUFNc0ksS0FBS3RJLEtBQUtBLE1BQU0sUUFBUSxDQUFBd0IsTUFBR0EsRUFBRXZDLElBQUksU0FBUztBQUFBLFVBQzVMLEVBQUN3QyxLQUFJLE1BQUtDLE9BQU0sU0FBUUMsUUFBT0EsQ0FBQUgsTUFBR0EsRUFBRXZDLEdBQUU7QUFBQSxVQUFFLEVBQUN3QyxLQUFJLFFBQU9DLE9BQU0saUJBQWdCQyxRQUFPQSxDQUFBSCxNQUFHN0UsZUFBZTZFLEVBQUVJLGFBQWEsRUFBQztBQUFBLFVBQUUsRUFBQ0gsS0FBSSxVQUFTQyxPQUFNLFNBQVFDLFFBQU9BLENBQUFILE1BQUdBLEVBQUVnRCxPQUFNO0FBQUEsVUFBRSxFQUFDL0MsS0FBSSxVQUFTQyxPQUFNLGNBQWFDLFFBQU9BLENBQUFILE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFeUgsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsRUFBRTtBQUFBLFVBQUUsRUFBQ3hILEtBQUksV0FBVUMsT0FBTSxZQUFXQyxRQUFPQSxDQUFBSCxNQUFHQSxFQUFFeUgsV0FBUyxVQUFRLHVCQUFDLGVBQVk7QUFBQSxtQ0FBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVMsTUFBSTtBQUFDUCwwQkFBWWxILENBQUM7QUFBRXdELG1CQUFLOEUsTUFBTTdCLFNBQVN6RyxDQUFDLEVBQUVxRSxNQUFNO0FBQUUyQyxzQkFBUSxJQUFJO0FBQUEsWUFBRSxHQUFHO0FBQUE7QUFBQSxjQUFXaEgsRUFBRXZDO0FBQUFBLGlCQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1STtBQUFBLFlBQWlCLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUyxNQUFJMkosV0FBV3BILENBQUMsR0FBRztBQUFBO0FBQUEsY0FBV0EsRUFBRXZDO0FBQUFBLGlCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBQTNQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRRLElBQWV1QyxFQUFFVyxZQUFVLHVCQUFDLGFBQVUsSUFBSSxNQUFNNUQsS0FBS1UsRUFBRSwrQkFBK0J1QyxFQUFFVyxTQUFTLElBQUksOEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGLElBQWEscUJBQW9CO0FBQUEsUUFBQyxLQUQ3bEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUUvRztBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNbUcsS0FBS3RJLEtBQUtvQyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGK0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUU3RSxLQUZlO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFWDtBQUFBLFNBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFbUQ7QUFBQSxJQUNuRCx1QkFBQyxjQUFXLE1BQVksT0FBT3FHLFdBQVMsYUFBYUEsU0FBU3hKLEVBQUUsS0FBRyxrQkFBa0IsU0FBUyxNQUFJdUosUUFBUSxLQUFLLEdBQUcsTUFBWSxTQUFTLHVCQUFDLFVBQU8sTUFBSyxVQUFTLE1BQUssZ0JBQWUsU0FBUSxhQUFZLFVBQVUyQixRQUFNQyxXQUFTLENBQUMvQixPQUFNcEMsUUFBUXdDLFFBQVEsS0FBRyxDQUFDZSxPQUFPVSxPQUFRLDhCQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStJLEdBQ2xSO0FBQUEsNkJBQUMsZUFBWSxPQUFPbkYsT0FBT2pFLFNBQU9zSSxPQUFPdEksU0FBT2lJLE9BQU9qSSxTQUFPbEIsU0FBU2tCLFNBQU9vSSxXQUFXcEksU0FBT3FJLFNBQVNySSxTQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStHO0FBQUEsTUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUNjLGVBQWMsaUJBQWdCbEQsZUFBYyxjQUFhOEYsUUFBTyxTQUFRNkIsT0FBTSwyQkFBMEJFLFdBQVUscUJBQW9CLEdBQUcsUUFBakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0TDtBQUFBLE1BQzdTLHVCQUFDLGNBQVcsV0FBVSxRQUFPLElBQUcsZ0JBQWUsWUFBVSxNQUFDLFVBQVU4RCxRQUFRLEtBQUssQ0FBQTNFLFNBQU07QUFBQzZELGdCQUFRNUQsVUFBUUQ7QUFBS04sYUFBS00sSUFBSTtBQUFBLE1BQUUsR0FBRyxvQkFBa0IsQ0FBQ3dFLFFBQU0sU0FBT3hLLFFBQ3ZKO0FBQUEsK0JBQUMsU0FBTSxVQUFTLFFBQU8sMElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUo7QUFBQSxRQUNqSix1QkFBQyxhQUFVLE1BQUssUUFBTyxPQUFNLGNBQWEsR0FBSXNGLEtBQUtnQixTQUFTLGVBQWUsR0FBRyxPQUFPQyxRQUFRakIsS0FBS0ssVUFBVWEsT0FBT3RFLGFBQWEsR0FBRyxZQUFZb0QsS0FBS0ssVUFBVWEsT0FBT3RFLGVBQWU4QyxXQUFwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRMO0FBQUEsUUFDNUwsdUJBQUMsYUFBVSxPQUFNLG9CQUFtQixPQUFNLHNCQUFxQixZQUFZLEVBQUNrRyxVQUFTLEtBQUksS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRjtBQUFBLFFBQzNGLHVCQUFDLGtCQUFlLE9BQU0sbUJBQWtCLGFBQWFoTCxTQUFTbUIsYUFBYSxTQUFTbkIsU0FBU29CLFNBQVMsTUFBTXBCLFNBQVNxQixlQUFlLFlBQVlyQixTQUFTc0IsWUFBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSztBQUFBLFFBQ2pLbUYsTUFBTXdFLE9BQU9oTSxJQUFJLENBQUNpTSxPQUFNbkQsTUFBSSx1QkFBQyxrQkFBOEIsVUFBUyxtQkFBa0IsaUNBQUMsY0FDcEY7QUFBQSxpQ0FBQyxhQUFVLFFBQU0sTUFBQyxPQUFPLG1CQUFtQkEsSUFBRSxDQUFDLElBQUksR0FBSTNDLEtBQUtnQixTQUFTLFNBQVMyQixDQUFDLFlBQVksR0FBRyxPQUFPM0MsS0FBSytGLE1BQU0sU0FBU3BELENBQUMsWUFBWSxHQUFHLE9BQU8xQixRQUFRakIsS0FBS0ssVUFBVWEsT0FBT0csUUFBUXNCLENBQUMsR0FBR25JLFNBQVMsR0FBRyxZQUFZd0YsS0FBS0ssVUFBVWEsT0FBT0csUUFBUXNCLENBQUMsR0FBR25JLFdBQVdrRixTQUFTO0FBQUEsbUNBQUMsWUFBUyxPQUFNLElBQUcsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsWUFBWTlFLFNBQVNJLE1BQU1BLEtBQUtuQixJQUFJLENBQUE4QixNQUFHLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUUxQixJQUFLMEI7QUFBQUEsZ0JBQUVDO0FBQUFBLGNBQUs7QUFBQSxjQUFJRCxFQUFFRTtBQUFBQSxpQkFBakNGLEVBQUUxQixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRCxDQUFXO0FBQUEsZUFBaFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa1o7QUFBQSxVQUNoWixDQUFDLFNBQVEsUUFBUSxFQUFZSixJQUFJLENBQUFtTSxTQUFNLHVCQUFDLGFBQXFCLE9BQU8sR0FBR0EsU0FBTyxVQUFRLE9BQUssSUFBSSxVQUFVckQsSUFBRSxDQUFDLEtBQUtwSixLQUFLd0YsUUFBUSxLQUFLLEdBQUlpQixLQUFLZ0IsU0FBUyxTQUFTMkIsQ0FBQyxJQUFJcUQsSUFBSSxTQUFTLEdBQUcsT0FBTy9FLFFBQVFqQixLQUFLSyxVQUFVYSxPQUFPRyxRQUFRc0IsQ0FBQyxJQUFJcUQsSUFBSSxHQUFHbEgsTUFBTSxHQUFHLFlBQVlrQixLQUFLSyxVQUFVYSxPQUFPRyxRQUFRc0IsQ0FBQyxJQUFJcUQsSUFBSSxHQUFHbEgsUUFBUVksU0FBUyxZQUFZLEVBQUN1RyxXQUFVLFVBQVMsS0FBclNELE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVULENBQUU7QUFBQSxVQUNsVyx1QkFBQyxhQUFVLE9BQU8sbUJBQW1CckQsSUFBRSxDQUFDLElBQUksR0FBSTNDLEtBQUtnQixTQUFTLFNBQVMyQixDQUFDLGNBQWMsR0FBRyxPQUFPMUIsUUFBUWpCLEtBQUtLLFVBQVVhLE9BQU9HLFFBQVFzQixDQUFDLEdBQUc1RixXQUFXLEdBQUcsWUFBWWlELEtBQUtLLFVBQVVhLE9BQU9HLFFBQVFzQixDQUFDLEdBQUc1RixhQUFhMkMsV0FBbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMk47QUFBQSxVQUFFLHVCQUFDLFVBQU8sU0FBUyxNQUFJMkIsTUFBTTZFLE9BQU92RCxDQUFDLEdBQUc7QUFBQTtBQUFBLFlBQVVBLElBQUU7QUFBQSxlQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLGFBSDlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJdkYsS0FKa0RtRCxNQUFNN0wsSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUloQixDQUFpQjtBQUFBLFFBQzdCK0YsS0FBS0ssVUFBVWEsT0FBT0csT0FBTzNCLFdBQVMsdUJBQUMsU0FBTSxVQUFTLFNBQVNNLGVBQUtLLFVBQVVhLE9BQU9HLE1BQU0zQixXQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFDcEcsdUJBQUMsVUFBTyxTQUFTLE1BQUkyQixNQUFNOEUsT0FBTyxFQUFDM0wsV0FBVSxJQUFHd0MsT0FBTSxFQUFDOEIsUUFBTyxLQUFJQyxVQUFTeEYsS0FBS3dGLFNBQVEsR0FBRTlCLFFBQU8sRUFBQzZCLFFBQU8sS0FBSUMsVUFBU3hGLEtBQUt3RixTQUFRLEdBQUVoQyxhQUFZLEdBQUUsQ0FBQyxHQUFHLG9DQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJLO0FBQUEsUUFDM0ssdUJBQUMsa0JBQWUsT0FBTSxhQUFZLGFBQWFtSCxXQUFXbkksYUFBYSxTQUFTbUksV0FBV2xJLFNBQVMsTUFBTWtJLFdBQVdqSSxlQUFlLFlBQVlpSSxXQUFXaEksWUFBM0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSztBQUFBLFFBQUUsdUJBQUMsa0JBQWUsT0FBTSxrQkFBaUIsYUFBYWlJLFNBQVNwSSxhQUFhLFNBQVNvSSxTQUFTbkksU0FBUyxNQUFNbUksU0FBU2xJLGVBQWUsWUFBWWtJLFNBQVNqSSxZQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlLO0FBQUEsUUFDdFVxRixVQUFVc0UsT0FBT2hNLElBQUksQ0FBQ2lNLE9BQU1uRCxNQUFJLHVCQUFDLGtCQUE4QixVQUFTLG1CQUFrQixpQ0FBQyxjQUN4RjtBQUFBLGlDQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU8sZUFBZUEsSUFBRSxDQUFDLElBQUksR0FBSTNDLEtBQUtnQixTQUFTLGFBQWEyQixDQUFDLGNBQWMsR0FBRyxPQUFPM0MsS0FBSytGLE1BQU0sYUFBYXBELENBQUMsY0FBYyxHQUFHLE9BQU8xQixRQUFRakIsS0FBS0ssVUFBVWEsT0FBT0ssWUFBWW9CLENBQUMsR0FBR2xCLFdBQVcsR0FBRyxZQUFZekIsS0FBS0ssVUFBVWEsT0FBT0ssWUFBWW9CLENBQUMsR0FBR2xCLGFBQWEvQixTQUFTO0FBQUEsbUNBQUMsWUFBUyxPQUFNLElBQUcsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFBWXdFLFdBQVdsSixNQUFNQSxLQUFLbkIsSUFBSSxDQUFBQyxNQUFHLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVHLElBQUtIO0FBQUFBLGdCQUFFOEI7QUFBQUEsY0FBSztBQUFBLGNBQUk5QixFQUFFK0I7QUFBQUEsaUJBQWpDL0IsRUFBRUcsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQsQ0FBVztBQUFBLGVBQWhhO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWthO0FBQUEsVUFDbGEsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTyxvQkFBb0IwSSxJQUFFLENBQUMsSUFBSSxHQUFJM0MsS0FBS2dCLFNBQVMsYUFBYTJCLENBQUMsWUFBWSxHQUFHLE9BQU8zQyxLQUFLK0YsTUFBTSxhQUFhcEQsQ0FBQyxZQUFZLEdBQUcsT0FBTzFCLFFBQVFqQixLQUFLSyxVQUFVYSxPQUFPSyxZQUFZb0IsQ0FBQyxHQUFHbkIsU0FBUyxHQUFHLFlBQVl4QixLQUFLSyxVQUFVYSxPQUFPSyxZQUFZb0IsQ0FBQyxHQUFHbkIsV0FBVzlCLFNBQVM7QUFBQSxtQ0FBQyxZQUFTLE9BQU0sSUFBRyw2QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUFZeUUsU0FBU25KLE1BQU1BLEtBQUtvTCxRQUFRLENBQUFDLE1BQUdBLEVBQUVDLFNBQVN6TSxJQUFJLENBQUFzRixNQUFHLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVsRixJQUFLa0Y7QUFBQUEsZ0JBQUVvSDtBQUFBQSxjQUFJO0FBQUEsY0FBSUYsRUFBRXhLO0FBQUFBLGlCQUFoQ3NELEVBQUVsRixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxDQUFXLENBQUM7QUFBQSxlQUF0YjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3YjtBQUFBLFVBQ3hiLHVCQUFDLGFBQVUsT0FBTyxvQkFBb0IwSSxJQUFFLENBQUMsSUFBSSxHQUFJM0MsS0FBS2dCLFNBQVMsYUFBYTJCLENBQUMsYUFBWSxFQUFDNkQsZUFBYyxLQUFJLENBQUMsR0FBRyxPQUFPdkYsUUFBUWpCLEtBQUtLLFVBQVVhLE9BQU9LLFlBQVlvQixDQUFDLEdBQUdqQixRQUFRLEdBQUcsWUFBWTFCLEtBQUtLLFVBQVVhLE9BQU9LLFlBQVlvQixDQUFDLEdBQUdqQixVQUFVaEMsU0FBUyxZQUFZLEVBQUN1RyxXQUFVLFVBQVMsS0FBclI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdVI7QUFBQSxVQUN2Uix1QkFBQyxhQUFVLE9BQU8sa0JBQWtCdEQsSUFBRSxDQUFDLEtBQUtwSixLQUFLd0YsUUFBUSxLQUFLLEdBQUlpQixLQUFLZ0IsU0FBUyxhQUFhMkIsQ0FBQyxrQkFBa0IsR0FBRyxPQUFPMUIsUUFBUWpCLEtBQUtLLFVBQVVhLE9BQU9LLFlBQVlvQixDQUFDLEdBQUdkLFVBQVUvQyxNQUFNLEdBQUcsWUFBWWtCLEtBQUtLLFVBQVVhLE9BQU9LLFlBQVlvQixDQUFDLEdBQUdkLFVBQVUvQyxRQUFRWSxTQUFTLFlBQVksRUFBQ3VHLFdBQVUsVUFBUyxLQUF4UztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwUztBQUFBLFVBQUUsdUJBQUMsVUFBTyxTQUFTLE1BQUkxRSxVQUFVMkUsT0FBT3ZELENBQUMsR0FBRztBQUFBO0FBQUEsWUFBWUEsSUFBRTtBQUFBLGVBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsYUFKL1E7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUszRixLQUxzRG1ELE1BQU03TCxJQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3BCLENBQWlCO0FBQUEsUUFDOUIsdUJBQUMsVUFBTyxTQUFTLE1BQUlzSCxVQUFVNEUsT0FBTyxFQUFDMUUsYUFBWSxJQUFHRCxXQUFVLElBQUdFLFVBQVMsR0FBRUcsVUFBUyxFQUFDL0MsUUFBTyxLQUFJQyxVQUFTeEYsS0FBS3dGLFNBQVEsRUFBQyxDQUFDLEdBQUcsK0JBQTlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkk7QUFBQSxRQUM3SSx1QkFBQyxhQUFVLE9BQU0sZUFBYyxXQUFTLE1BQUMsU0FBUyxHQUFHLEdBQUlpQixLQUFLZ0IsU0FBUyxRQUFRLEdBQUcsT0FBT0MsUUFBUWpCLEtBQUtLLFVBQVVhLE9BQU8xQixNQUFNLEdBQUcsWUFBWVEsS0FBS0ssVUFBVWEsT0FBTzFCLFFBQVFFLFdBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0w7QUFBQSxXQXBCdEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLE1BQU11QixRQUFRMEMsT0FBTyxHQUFHLE9BQU0sYUFBWSxjQUFhLGFBQVksYUFBYSxTQUFTQSxTQUFTMUosTUFBSSxFQUFFLGNBQWN0QyxlQUFlZ00sU0FBUy9HLGFBQWEsQ0FBQyxtR0FBbUcsTUFBTXlILEtBQUs3RCxTQUFTLE9BQU82RCxLQUFLdkksT0FBTyxTQUFTLE1BQUk4SCxXQUFXLElBQUksR0FBRyxXQUFXLFlBQVM7QUFBQyxVQUFHLENBQUNELFFBQVE7QUFBTyxZQUFNVSxLQUFLdkQsUUFBUSxFQUFDckIsTUFBSyxFQUFDdUUsV0FBVUwsUUFBUTFKLEdBQUUsR0FBRThHLE1BQUssRUFBQzBGLGlCQUFnQjlDLFFBQVFULFFBQU8sRUFBQyxDQUFDO0FBQUVZLGlCQUFXLGtEQUFrRDtBQUFBLElBQUUsS0FBcGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc2hCO0FBQUEsT0E3Qm5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJQO0FBQ0o7QUFBQ1YsSUEzQ2VELHFCQUFtQjtBQUFBLFVBQ2xCbk0sVUFBZUMsUUFBa0NKLFFBQW9DSyxjQUVyRkwsUUFDRUUsYUFBaUVBLGFBQWlFQSxhQUNwSUQsWUFBa0VBLFlBQW9GQSxZQUV4Sk4sU0FBa0ZDLFVBQ2pGQyxlQUE2REEsZUFDNURXLG1CQUNzRUYsWUFBWTtBQUFBO0FBQUEsTUFWbkZnTTtBQUFtQixJQUFBdUQsSUFBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUM7QUFBQSxhQUFBTCxJQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQnV0dG9uIiwiTWVudUl0ZW0iLCJUZXh0RmllbGQiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJ1c2VGaWVsZEFycmF5Iiwiem9kUmVzb2x2ZXIiLCJ6IiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVBhZ2VkQXBpIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJ1c2VMaXN0UXVlcnkiLCJ1c2VEcmFmdEZvcm0iLCJtYXJrRHJhZnRDbGVhbiIsInVzZVZlcnNpb25lZERyYWZ0IiwiZHJhZnRFcXVhbCIsImRhdGVUaW1lIiwiZGF0ZU9ubHlJblRpbWV6b25lIiwiaXNWYWxpZERhdGVPbmx5IiwiY29kZVBvaW50TGVuZ3RoIiwiZm9ybWF0RGF0ZU9ubHkiLCJEcmFmdENvbmZsaWN0IiwiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiU3VyZmFjZUNvbnRlbnQiLCJBbW91bnQiLCJDb25maXJtRGlhbG9nIiwiRGF0YVRhYmxlIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkxvb2t1cExvYWRNb3JlIiwiTXV0YXRpb25CdXR0b24iLCJQYWdlSGVhZGVyIiwiUGFnZXIiLCJQYW5lbCIsIlF1ZXJ5U3RhdGUiLCJSb3V0ZUxpbmsiLCJTdGF0IiwiU3RhdHMiLCJTdGF0dXMiLCJUb29sYmFyIiwidXNlUmVwb3J0UmFuZ2UiLCJSZXBvcnRSYW5nZUZpZWxkcyIsImFjY291bnRHcm91cE5hbWUiLCJCb29rUHJvdmVuYW5jZSIsInJlcG9ydCIsIl9zIiwic2hvcCIsImFzT2YiLCJ0aW1lem9uZSIsInBvbGljeVZlcnNpb24iLCJjb21wbGV0ZW5lc3MiLCJ3YXJuaW5ncyIsIm1hcCIsInciLCJzb3VyY2VKb3VybmFsSWRzIiwibGVuZ3RoIiwiaWQiLCJlbmNvZGVVUklDb21wb25lbnQiLCJMZWRnZXJQYWdlIiwiX3MyIiwicmFuZ2UiLCJwYXJhbXMiLCJzZXRQYXJhbXMiLCJhY2NvdW50SWQiLCJnZXQiLCJ1bmRlZmluZWQiLCJjdXJzb3IiLCJhY2NvdW50cyIsInF1ZXJ5IiwibGltaXQiLCJ2YWxpZCIsImRhdGEiLCJzZXRGcm9tIiwic2V0VG8iLCJlIiwibmV4dCIsIlVSTFNlYXJjaFBhcmFtcyIsImRlbGV0ZSIsInRhcmdldCIsInZhbHVlIiwic2V0Iiwic29tZSIsImEiLCJjb2RlIiwibmFtZSIsImVycm9yIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwib3BlbmluZ0JhbGFuY2UiLCJ0b3RhbERlYml0IiwidG90YWxDcmVkaXQiLCJjbG9zaW5nQmFsYW5jZSIsImVudHJpZXMiLCJyIiwia2V5IiwibGFiZWwiLCJyZW5kZXIiLCJlZmZlY3RpdmVEYXRlIiwiYWNjb3VudENvZGUiLCJhY2NvdW50TmFtZSIsImRlc2NyaXB0aW9uIiwiZGViaXQiLCJjcmVkaXQiLCJiYWxhbmNlIiwiam91cm5hbElkIiwicGFnZSIsIlRyaWFsQmFsYW5jZVBhZ2UiLCJfczMiLCJkaWZmZXJlbmNlIiwiYmFsYW5jZWQiLCJyb3dzIiwiZnJvbSIsInRvIiwib3BlbmluZ0RlYml0Iiwib3BlbmluZ0NyZWRpdCIsImNsb3NpbmdEZWJpdCIsImNsb3NpbmdDcmVkaXQiLCJCYWxhbmNlU2hlZXRQYWdlIiwiX3M0IiwiYXREYXRlIiwiRGF0ZSIsImFzc2V0cyIsImxpYWJpbGl0aWVzIiwiZXF1aXR5IiwicmV0YWluZWRQcm9maXQiLCJncm91cCIsImV4YWN0Iiwic3RyaW5nIiwicmVnZXgiLCJtb25leVNjaGVtYSIsIm9iamVjdCIsImFtb3VudCIsImN1cnJlbmN5IiwibWluIiwicmVhc29uU2NoZW1hIiwicmVmaW5lIiwidiIsInRyaW0iLCJwZXJpb2RTY2hlbWEiLCJzdGFydERhdGUiLCJlbmREYXRlIiwicmVhc29uIiwicGF0aCIsIm1lc3NhZ2UiLCJDcmVhdGVQZXJpb2REaWFsb2ciLCJvbkNsb3NlIiwib25TYXZlZCIsIl9zNSIsImNyZWF0ZSIsImZvcm0iLCJkZWZhdWx0VmFsdWVzIiwicmVzb2x2ZXIiLCJjb250cm9sIiwiYmluZCIsImZvcm1TdGF0ZSIsImlzRGlydHkiLCJyZWYiLCJwZW5kaW5nIiwidW5yZXNvbHZlZCIsIm5vZGUiLCJjdXJyZW50IiwiaGFuZGxlU3VibWl0IiwidmFsdWVzIiwiZXhlY3V0ZSIsImJvZHkiLCJyZWdpc3RlciIsIkJvb2xlYW4iLCJlcnJvcnMiLCJvcGVuaW5nU2NoZW1hIiwibGl0ZXJhbCIsImxpbmVzIiwiYXJyYXkiLCJpbnZlbnRvcnkiLCJ2YXJpYW50SWQiLCJ3YXJlaG91c2VJZCIsInF1YW50aXR5IiwibnVtYmVyIiwiaW50IiwidW5pdENvc3QiLCJzdXBlclJlZmluZSIsImN0eCIsInVuaXRzIiwibiIsImYiLCJzcGxpdCIsInRlc3QiLCJCaWdJbnQiLCJwYWRFbmQiLCJkIiwiYyIsImZvckVhY2giLCJsaW5lIiwiaSIsImFkZElzc3VlIiwia2V5cyIsIlNldCIsImhhcyIsImFkZCIsInNuYXBzaG90IiwidmVyc2lvbiIsIk9wZW5pbmdCYWxhbmNlc1BhZ2UiLCJfczYiLCJjYW4iLCJsaXN0Iiwib3BlbiIsInNldE9wZW4iLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwicG9zdFJvdyIsInNldFBvc3RSb3ciLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsImRldGFpbCIsIm9wZW5pbmdJZCIsInN0YXR1cyIsIndhcmVob3VzZXMiLCJwcm9kdWN0cyIsInVwZGF0ZSIsInBvc3QiLCJlbXB0eSIsImZvcm1SZWYiLCJlZGl0b3IiLCJpZGVudGl0eSIsInNvdXJjZSIsImRyYWZ0IiwiZ2V0VmFsdWVzIiwiYXBwbHkiLCJyZXNldCIsInJlZnJlc2giLCJyZWZldGNoIiwidGhyb3dPbkVycm9yIiwiZGlydHkiLCJidXN5IiwiYmxvY2tlZCIsInN1Ym1pdCIsInByZXBhcmVkIiwicHJlcGFyZSIsInN1Ym1pdHRlZCIsInJlc3VsdCIsImNvbW1pdHRlZCIsImZhaWxlZCIsInJlYWRPbmx5IiwiZmllbGRzIiwiZmllbGQiLCJ3YXRjaCIsInNpZGUiLCJpbnB1dE1vZGUiLCJyZW1vdmUiLCJhcHBlbmQiLCJmbGF0TWFwIiwicCIsInZhcmlhbnRzIiwic2t1IiwidmFsdWVBc051bWJlciIsImV4cGVjdGVkVmVyc2lvbiIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1IiwiX2M2Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm1hbmFnZW1lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlUmVmLHVzZVN0YXRlfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7dXNlU2VhcmNoUGFyYW1zfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHtBbGVydCxCdXR0b24sTWVudUl0ZW0sVGV4dEZpZWxkfSBmcm9tICdAbXVpL21hdGVyaWFsJztcclxuaW1wb3J0IHt1c2VGb3JtLHVzZVdhdGNoLHVzZUZpZWxkQXJyYXl9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XHJcbmltcG9ydCB7em9kUmVzb2x2ZXJ9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJztcclxuaW1wb3J0IHt6fSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgdHlwZSB7T3BlbmluZ0JhbGFuY2UsT3BlbmluZ0JhbGFuY2VXcml0ZX0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7dXNlQXBpLHVzZUNvbW1hbmQsdXNlUGFnZWRBcGl9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7dXNlU2NvcGUsdXNlQ2FufSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7dXNlTGlzdFF1ZXJ5fSBmcm9tICdAL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcclxuaW1wb3J0IHt1c2VEcmFmdEZvcm0sbWFya0RyYWZ0Q2xlYW59IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XHJcbmltcG9ydCB7dXNlVmVyc2lvbmVkRHJhZnQsZHJhZnRFcXVhbH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvdmVyc2lvbmVkLWRyYWZ0JztcclxuaW1wb3J0IHtkYXRlVGltZSxkYXRlT25seUluVGltZXpvbmUsaXNWYWxpZERhdGVPbmx5LGNvZGVQb2ludExlbmd0aCxmb3JtYXREYXRlT25seX0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHtEcmFmdENvbmZsaWN0fSBmcm9tICdAL3NoYXJlZC91aS9kcmFmdC1jb25mbGljdCc7XHJcbmltcG9ydCB7QWN0aW9uR3JvdXAsRm9ybUZpZWxkcyxTdXJmYWNlQ29udGVudH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQge0Ftb3VudCxDb25maXJtRGlhbG9nLERhdGFUYWJsZSxEZXRhaWxMaW5lLEVkaXREaWFsb2csRXJyb3JOb3RpY2UsTG9va3VwTG9hZE1vcmUsTXV0YXRpb25CdXR0b24sUGFnZUhlYWRlcixQYWdlcixQYW5lbCxRdWVyeVN0YXRlLFJvdXRlTGluayxTdGF0LFN0YXRzLFN0YXR1cyxUb29sYmFyfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcclxuaW1wb3J0IHt1c2VSZXBvcnRSYW5nZSxSZXBvcnRSYW5nZUZpZWxkc30gZnJvbSAnLi9yZXBvcnQtcmFuZ2UnO1xyXG5pbXBvcnQge2FjY291bnRHcm91cE5hbWV9IGZyb20gJy4vYWNjb3VudHMnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEJvb2tQcm92ZW5hbmNlKHtyZXBvcnR9OiB7cmVwb3J0Onthc09mOnN0cmluZztwb2xpY3lWZXJzaW9uPzpzdHJpbmc7Y29tcGxldGVuZXNzPzpzdHJpbmc7d2FybmluZ3M6c3RyaW5nW107c291cmNlSm91cm5hbElkcz86c3RyaW5nW119fSkge1xyXG4gICAgY29uc3Qge3Nob3B9PXVzZVNjb3BlKCk7XHJcbiAgICByZXR1cm4gPFN1cmZhY2VDb250ZW50PlxyXG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiROG7ryBsaeG7h3UgdOG6oWlcIj57ZGF0ZVRpbWUocmVwb3J0LmFzT2Ysc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiQ2jDrW5oIHPDoWNoXCI+e3JlcG9ydC5wb2xpY3lWZXJzaW9ufHwnQ2jGsGEgY8OzJ308L0RldGFpbExpbmU+XHJcbiAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJN4bupYyDEkeG6p3kgxJHhu6dcIj48U3RhdHVzIHZhbHVlPXtyZXBvcnQuY29tcGxldGVuZXNzfHwnaW5jb21wbGV0ZSd9Lz48L0RldGFpbExpbmU+XHJcbiAgICAgICAge3JlcG9ydC53YXJuaW5ncy5tYXAodz0+PEFsZXJ0IGtleT17d30gc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+e3d9PC9BbGVydD4pfVxyXG4gICAgICAgIHtyZXBvcnQuc291cmNlSm91cm5hbElkcyYmPEFjdGlvbkdyb3VwPntyZXBvcnQuc291cmNlSm91cm5hbElkcy5sZW5ndGg/cmVwb3J0LnNvdXJjZUpvdXJuYWxJZHMubWFwKGlkPT48Um91dGVMaW5rIGtleT17aWR9IHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL2pvdXJuYWxzP2pvdXJuYWxJZD0ke2VuY29kZVVSSUNvbXBvbmVudChpZCl9YH0+Q2jhu6luZyB04burIHtpZH08L1JvdXRlTGluaz4pOjxBbGVydCBzZXZlcml0eT1cImluZm9cIj5LaMO0bmcgY8OzIGLDunQgdG/DoW4gdHJvbmcga2hv4bqjbmcgbsOgeS48L0FsZXJ0Pn08L0FjdGlvbkdyb3VwPn1cclxuICAgIDwvU3VyZmFjZUNvbnRlbnQ+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBMZWRnZXJQYWdlKCkge1xyXG4gICAgY29uc3Qge3Nob3B9PXVzZVNjb3BlKCkscmFuZ2U9dXNlUmVwb3J0UmFuZ2Uoc2hvcC50aW1lem9uZSksW3BhcmFtcyxzZXRQYXJhbXNdPXVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3QgYWNjb3VudElkPXBhcmFtcy5nZXQoJ2FjY291bnRJZCcpfHx1bmRlZmluZWQsY3Vyc29yPXBhcmFtcy5nZXQoJ2N1cnNvcicpfHx1bmRlZmluZWQ7XHJcbiAgICBjb25zdCBhY2NvdW50cz11c2VQYWdlZEFwaSgnbGlzdEFjY291bnRzJyk7XHJcbiAgICBjb25zdCBxdWVyeT11c2VBcGkoJ2dldExlZGdlcicse3F1ZXJ5OnsuLi5yYW5nZS5xdWVyeSxhY2NvdW50SWQsY3Vyc29yLGxpbWl0OjIwfX0scmFuZ2UudmFsaWQpLHJlcG9ydD1xdWVyeS5kYXRhPy5kYXRhO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJT4buVIGPDoWlcIiBzdWJ0aXRsZT1cIlThu5VuZyBO4bujLCBDw7MgdsOgIHPhu5EgZMawIGzhuqV5IHThu6sgdG/DoG4gYuG7mSBjaOG7qW5nIHThu6sgdHJvbmcga2hv4bqjbmc7IHBow6JuIHRyYW5nIGNo4buJIMOhcCBk4bulbmcgY8OhYyBkw7JuZyBjaGkgdGnhur90LlwiLz5cclxuICAgICAgICA8UmVwb3J0UmFuZ2VGaWVsZHMgcmFuZ2U9e3JhbmdlLnJhbmdlfSB0aW1lem9uZT17c2hvcC50aW1lem9uZX0gc2V0RnJvbT17cmFuZ2Uuc2V0RnJvbX0gc2V0VG89e3JhbmdlLnNldFRvfS8+XHJcbiAgICAgICAgPEZvcm1GaWVsZHMgYWZ0ZXJHYXA9XCJzZWN0aW9uXCI+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJUw6BpIGtob+G6o24gc+G7lSBjw6FpXCIgdmFsdWU9e2FjY291bnRJZHx8Jyd9IG9uQ2hhbmdlPXtlPT57Y29uc3QgbmV4dD1uZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7bmV4dC5kZWxldGUoJ2N1cnNvcicpO2lmKGUudGFyZ2V0LnZhbHVlKW5leHQuc2V0KCdhY2NvdW50SWQnLGUudGFyZ2V0LnZhbHVlKTtlbHNlIG5leHQuZGVsZXRlKCdhY2NvdW50SWQnKTtzZXRQYXJhbXMobmV4dCk7fX0+XHJcbiAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPlThuqV0IGPhuqMgdMOgaSBraG/huqNuPC9NZW51SXRlbT57YWNjb3VudElkJiYhYWNjb3VudHMuZGF0YT8uZGF0YS5zb21lKGE9PmEuaWQ9PT1hY2NvdW50SWQpJiY8TWVudUl0ZW0gdmFsdWU9e2FjY291bnRJZH0+xJBhbmcgZ2nhu68gdMOgaSBraG/huqNuIHthY2NvdW50SWR9PC9NZW51SXRlbT59e2FjY291bnRzLmRhdGE/LmRhdGEubWFwKGE9PjxNZW51SXRlbSBrZXk9e2EuaWR9IHZhbHVlPXthLmlkfT57YS5jb2RlfSDCtyB7YS5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD48RXJyb3JOb3RpY2UgZXJyb3I9e2FjY291bnRzLmVycm9yfS8+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwidMOgaSBraG/huqNuXCIgbG9hZGVkQ291bnQ9e2FjY291bnRzLmxvYWRlZENvdW50fSBoYXNNb3JlPXthY2NvdW50cy5oYXNNb3JlfSBidXN5PXthY2NvdW50cy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXthY2NvdW50cy5sb2FkTW9yZX0vPjwvRm9ybUZpZWxkcz5cclxuICAgICAgICB7cmFuZ2UudmFsaWQ/PFF1ZXJ5U3RhdGUgcXVlcnk9e3F1ZXJ5fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57cmVwb3J0JiY8PjxTdGF0cz48U3RhdCB0aXRsZT1cIlPhu5EgZMawIMSR4bqndSBraG/huqNuZyAoTuG7oyDiiJIgQ8OzKVwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3JlcG9ydC5vcGVuaW5nQmFsYW5jZX0vPn0vPjxTdGF0IHRpdGxlPVwiVOG7lW5nIHBow6F0IHNpbmggTuG7o1wiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3JlcG9ydC50b3RhbERlYml0fS8+fS8+PFN0YXQgdGl0bGU9XCJU4buVbmcgcGjDoXQgc2luaCBDw7NcIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXtyZXBvcnQudG90YWxDcmVkaXR9Lz59Lz48U3RhdCB0aXRsZT1cIlPhu5EgZMawIGN14buRaSBraG/huqNuZyAoTuG7oyDiiJIgQ8OzKVwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3JlcG9ydC5jbG9zaW5nQmFsYW5jZX0vPn0vPjwvU3RhdHM+PFBhbmVsIHRpdGxlPVwiQ8OhYyBkw7JuZyBz4buVIGPDoWlcIj48RGF0YVRhYmxlIGxhYmVsPVwiU+G7lSBjw6FpIHRoZW8gY2jhu6luZyB04burXCIgcm93cz17cmVwb3J0LmVudHJpZXN9IHJvd0tleT17cj0+ci5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICB7a2V5OidkYXRlJyxsYWJlbDonTmfDoHkgaGnhu4d1IGzhu7FjJyxyZW5kZXI6cj0+Zm9ybWF0RGF0ZU9ubHkoci5lZmZlY3RpdmVEYXRlKX0se2tleTonYWNjb3VudCcsbGFiZWw6J1TDoGkga2hv4bqjbicscmVuZGVyOnI9PmAke3IuYWNjb3VudENvZGV9IMK3ICR7ci5hY2NvdW50TmFtZX1gfSx7a2V5Oidub3RlJyxsYWJlbDonRGnhu4VuIGdp4bqjaScscmVuZGVyOnI9PnIuZGVzY3JpcHRpb259LHtrZXk6J2RlYml0JyxsYWJlbDonTuG7oycscmVuZGVyOnI9PjxBbW91bnQgdmFsdWU9e3IuZGViaXR9Lz59LHtrZXk6J2NyZWRpdCcsbGFiZWw6J0PDsycscmVuZGVyOnI9PjxBbW91bnQgdmFsdWU9e3IuY3JlZGl0fS8+fSx7a2V5OidiYWxhbmNlJyxsYWJlbDonU+G7kSBkxrAgdMOgaSBraG/huqNuIChO4bujIOKIkiBDw7MpJyxyZW5kZXI6cj0+PEFtb3VudCB2YWx1ZT17ci5iYWxhbmNlfS8+fSx7a2V5Oidzb3VyY2UnLGxhYmVsOidDaOG7qW5nIHThu6snLHJlbmRlcjpyPT48Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL2pvdXJuYWxzP2pvdXJuYWxJZD0ke3Iuam91cm5hbElkfWB9Pk3DoyBjaOG7qW5nIHThu6s6IHtyLmpvdXJuYWxJZH08L1JvdXRlTGluaz59LFxyXG4gICAgICAgIF19Lz48UGFnZXIgcGFnZT17cmVwb3J0LnBhZ2V9Lz48L1BhbmVsPjxQYW5lbCB0aXRsZT1cIk5ndeG7k24gdsOgIGdp4bubaSBo4bqhblwiIGJvZHlNb2RlPVwiaW5zZXRcIiBiZWZvcmVHYXA9XCJzZWN0aW9uXCI+PEJvb2tQcm92ZW5hbmNlIHJlcG9ydD17cmVwb3J0fS8+PC9QYW5lbD48Lz59PC9RdWVyeVN0YXRlPjo8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiPk5nw6B5IGLhuq90IMSR4bqndSBwaOG6o2kgdHLGsOG7m2MgbmfDoHkga+G6v3QgdGjDumMuPC9BbGVydD59XHJcbiAgICA8Lz47XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFRyaWFsQmFsYW5jZVBhZ2UoKSB7XHJcbiAgICBjb25zdCB7c2hvcH09dXNlU2NvcGUoKSxyYW5nZT11c2VSZXBvcnRSYW5nZShzaG9wLnRpbWV6b25lKSxxdWVyeT11c2VBcGkoJ2dldFRyaWFsQmFsYW5jZScse3F1ZXJ5OnJhbmdlLnF1ZXJ5fSxyYW5nZS52YWxpZCkscmVwb3J0PXF1ZXJ5LmRhdGE/LmRhdGE7XHJcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIkPDom4gxJHhu5FpIHBow6F0IHNpbmhcIiBzdWJ0aXRsZT1cIlPhu5EgZMawIMSR4bqndSwgcGjDoXQgc2luaCB2w6Agc+G7kSBkxrAgY3Xhu5FpIGRvIHJlYWQtbW9kZWwgdOG7lW5nIGjhu6NwIMSR4bqneSDEkeG7pyB0aGVvIHTDoGkga2hv4bqjbi5cIi8+PFJlcG9ydFJhbmdlRmllbGRzIHJhbmdlPXtyYW5nZS5yYW5nZX0gdGltZXpvbmU9e3Nob3AudGltZXpvbmV9IHNldEZyb209e3JhbmdlLnNldEZyb219IHNldFRvPXtyYW5nZS5zZXRUb30vPlxyXG4gICAgICAgIHtyYW5nZS52YWxpZD88UXVlcnlTdGF0ZSBxdWVyeT17cXVlcnl9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntyZXBvcnQmJjw+PFN0YXRzPjxTdGF0IHRpdGxlPVwiUGjDoXQgc2luaCBO4bujXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LnRvdGFsRGViaXR9Lz59Lz48U3RhdCB0aXRsZT1cIlBow6F0IHNpbmggQ8OzXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LnRvdGFsQ3JlZGl0fS8+fS8+PFN0YXQgdGl0bGU9XCJDaMOqbmggbOG7h2NoIGN14buRaVwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3JlcG9ydC5kaWZmZXJlbmNlfS8+fS8+PFN0YXQgdGl0bGU9XCJLaeG7g20gY8OibiBi4bqxbmdcIiB2YWx1ZT17cmVwb3J0LmJhbGFuY2VkPydDw6JuIGLhurFuZyc6J0tow7RuZyBjw6JuIGLhurFuZyd9Lz48L1N0YXRzPjxQYW5lbCB0aXRsZT1cIkPDom4gxJHhu5FpIHRoZW8gdMOgaSBraG/huqNuXCI+PERhdGFUYWJsZSBsYWJlbD1cIkPDom4gxJHhu5FpIHBow6F0IHNpbmggY8OhYyB0w6BpIGtob+G6o25cIiByb3dzPXtyZXBvcnQucm93c30gcm93S2V5PXtyPT5yLmFjY291bnRJZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICB7a2V5Oidjb2RlJyxsYWJlbDonVMOgaSBraG/huqNuJyxyZW5kZXI6cj0+PFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vZmluYW5jZS9sZWRnZXI/YWNjb3VudElkPSR7ci5hY2NvdW50SWR9JmZyb21EYXRlPSR7cmFuZ2UucmFuZ2UuZnJvbX0mdG9EYXRlPSR7cmFuZ2UucmFuZ2UudG99YH0+e3IuY29kZX0gwrcge3IubmFtZX08L1JvdXRlTGluaz59LHtrZXk6J29wZW5pbmdEZWJpdCcsbGFiZWw6J8SQ4bqndSBr4buzIE7hu6MnLHJlbmRlcjpyPT48QW1vdW50IHZhbHVlPXtyLm9wZW5pbmdEZWJpdH0vPn0se2tleTonb3BlbmluZ0NyZWRpdCcsbGFiZWw6J8SQ4bqndSBr4buzIEPDsycscmVuZGVyOnI9PjxBbW91bnQgdmFsdWU9e3Iub3BlbmluZ0NyZWRpdH0vPn0se2tleTonZGViaXQnLGxhYmVsOidQaMOhdCBzaW5oIE7hu6MnLHJlbmRlcjpyPT48QW1vdW50IHZhbHVlPXtyLmRlYml0fS8+fSx7a2V5OidjcmVkaXQnLGxhYmVsOidQaMOhdCBzaW5oIEPDsycscmVuZGVyOnI9PjxBbW91bnQgdmFsdWU9e3IuY3JlZGl0fS8+fSx7a2V5OidjbG9zaW5nRGViaXQnLGxhYmVsOidDdeG7kWkga+G7syBO4bujJyxyZW5kZXI6cj0+PEFtb3VudCB2YWx1ZT17ci5jbG9zaW5nRGViaXR9Lz59LHtrZXk6J2Nsb3NpbmdDcmVkaXQnLGxhYmVsOidDdeG7kWkga+G7syBDw7MnLHJlbmRlcjpyPT48QW1vdW50IHZhbHVlPXtyLmNsb3NpbmdDcmVkaXR9Lz59LFxyXG4gICAgICAgIF19Lz48L1BhbmVsPjxQYW5lbCB0aXRsZT1cIk5ndeG7k24gdsOgIGdp4bubaSBo4bqhblwiIGJvZHlNb2RlPVwiaW5zZXRcIiBiZWZvcmVHYXA9XCJzZWN0aW9uXCI+PEJvb2tQcm92ZW5hbmNlIHJlcG9ydD17cmVwb3J0fS8+PC9QYW5lbD48Lz59PC9RdWVyeVN0YXRlPjo8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiPk5nw6B5IGLhuq90IMSR4bqndSBwaOG6o2kgdHLGsOG7m2MgbmfDoHkga+G6v3QgdGjDumMuPC9BbGVydD59XHJcbiAgICA8Lz47XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIEJhbGFuY2VTaGVldFBhZ2UoKSB7XHJcbiAgICBjb25zdCB7c2hvcH09dXNlU2NvcGUoKSxbcGFyYW1zLHNldFBhcmFtc109dXNlU2VhcmNoUGFyYW1zKCk7Y29uc3QgYXREYXRlPXBhcmFtcy5nZXQoJ2F0RGF0ZScpPz9kYXRlT25seUluVGltZXpvbmUobmV3IERhdGUoKSxzaG9wLnRpbWV6b25lKSx2YWxpZD1pc1ZhbGlkRGF0ZU9ubHkoYXREYXRlKTtcclxuICAgIGNvbnN0IHF1ZXJ5PXVzZUFwaSgnZ2V0QmFsYW5jZVNoZWV0Jyx7cXVlcnk6e2F0RGF0ZX19LHZhbGlkKSxyZXBvcnQ9cXVlcnkuZGF0YT8uZGF0YTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiQ8OibiDEkeG7kWkgcXXhuqNuIHRy4buLXCIgc3VidGl0bGU9XCJUw6BpIHPhuqNuID0gbuG7oyBwaOG6o2kgdHLhuqMgKyB24buRbiBjaOG7pyBz4bufIGjhu691ICsga+G6v3QgcXXhuqMgbMWpeSBr4bq/OyDEkcOieSBsw6AgYsOhbyBjw6FvIHF14bqjbiB0cuG7iyB0aGVvIGNow61uaCBzw6FjaCBj4bunYSBzaG9wLlwiLz48Rm9ybUZpZWxkcyBhZnRlckdhcD1cInNlY3Rpb25cIj48VGV4dEZpZWxkIHR5cGU9XCJkYXRlXCIgbGFiZWw9XCJU4bqhaSBuZ8OgeVwiIHZhbHVlPXthdERhdGV9IG9uQ2hhbmdlPXtlPT57Y29uc3QgbmV4dD1uZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7bmV4dC5zZXQoJ2F0RGF0ZScsZS50YXJnZXQudmFsdWUpO3NldFBhcmFtcyhuZXh0KTt9fS8+PC9Gb3JtRmllbGRzPlxyXG4gICAgICAgIHt2YWxpZD88UXVlcnlTdGF0ZSBxdWVyeT17cXVlcnl9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntyZXBvcnQmJjw+PFN0YXRzPjxTdGF0IHRpdGxlPVwiVMOgaSBz4bqjblwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3JlcG9ydC5hc3NldHN9Lz59Lz48U3RhdCB0aXRsZT1cIk7hu6MgcGjhuqNpIHRy4bqjXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LmxpYWJpbGl0aWVzfS8+fS8+PFN0YXQgdGl0bGU9XCJW4buRbiBjaOG7pyBz4bufIGjhu691XCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LmVxdWl0eX0vPn0vPjxTdGF0IHRpdGxlPVwiS+G6v3QgcXXhuqMgbMWpeSBr4bq/XCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LnJldGFpbmVkUHJvZml0fS8+fS8+PC9TdGF0cz48UGFuZWwgdGl0bGU9XCJLaeG7g20gY8OibiDEkeG7kWlcIiBib2R5TW9kZT1cImluc2V0XCI+PERldGFpbExpbmUgbGFiZWw9XCJDw6JuIGLhurFuZ1wiPntyZXBvcnQuYmFsYW5jZWQ/J0PDsyc6J0tow7RuZyd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiQ2jDqm5oIGzhu4djaFwiPjxBbW91bnQgd3JhcCB2YWx1ZT17cmVwb3J0LmRpZmZlcmVuY2V9Lz48L0RldGFpbExpbmU+PC9QYW5lbD48UGFuZWwgdGl0bGU9XCJT4buRIGTGsCB0aGVvIG5ow7NtXCIgYmVmb3JlR2FwPVwic2VjdGlvblwiPjxEYXRhVGFibGUgbGFiZWw9XCJUw6BpIGtob+G6o24gY+G7p2EgYsOhbyBjw6FvIGPDom4gxJHhu5FpIHF14bqjbiB0cuG7i1wiIHJvd3M9e3JlcG9ydC5yb3dzfSByb3dLZXk9e3I9PnIuYWNjb3VudElkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgIHtrZXk6J2NvZGUnLGxhYmVsOidUw6BpIGtob+G6o24nLHJlbmRlcjpyPT48Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL2xlZGdlcj9hY2NvdW50SWQ9JHtyLmFjY291bnRJZH1gfT57ci5jb2RlfSDCtyB7ci5uYW1lfTwvUm91dGVMaW5rPn0se2tleTonZ3JvdXAnLGxhYmVsOidOaMOzbScscmVuZGVyOnI9PmFjY291bnRHcm91cE5hbWVbci5ncm91cF19LHtrZXk6J2JhbGFuY2UnLGxhYmVsOidT4buRIGTGsCB0aGVvIGNoaeG7gXUgbmjDs20nLHJlbmRlcjpyPT48QW1vdW50IHZhbHVlPXtyLmJhbGFuY2V9Lz59LFxyXG4gICAgICAgIF19Lz48L1BhbmVsPjxQYW5lbCB0aXRsZT1cIk5ndeG7k24gdsOgIGdp4bubaSBo4bqhblwiIGJvZHlNb2RlPVwiaW5zZXRcIiBiZWZvcmVHYXA9XCJzZWN0aW9uXCI+PEJvb2tQcm92ZW5hbmNlIHJlcG9ydD17cmVwb3J0fS8+PC9QYW5lbD48Lz59PC9RdWVyeVN0YXRlPjo8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiPkNo4buNbiBuZ8OgeSBo4bujcCBs4buHLjwvQWxlcnQ+fVxyXG4gICAgPC8+O1xyXG59XHJcbmNvbnN0IGV4YWN0PXouc3RyaW5nKCkucmVnZXgoL15cXGQrKFxcLlxcZHsxLDR9KT8kLywnTmjhuq1wIHPhu5Ega2jDtG5nIMOibSwgdOG7kWkgxJFhIDQgY2jhu68gc+G7kSB0aOG6rXAgcGjDom4uJyk7XHJcbmNvbnN0IG1vbmV5U2NoZW1hPXoub2JqZWN0KHthbW91bnQ6ZXhhY3QsY3VycmVuY3k6ei5zdHJpbmcoKS5taW4oMSl9KTtcclxuY29uc3QgcmVhc29uU2NoZW1hPXouc3RyaW5nKCkucmVmaW5lKHY9PmNvZGVQb2ludExlbmd0aCh2KTw9MTAwMCwnTMO9IGRvIHThu5FpIMSRYSAxLjAwMCBrw70gdOG7sS4nKS50cmltKCkubWluKDUsJ0zDvSBkbyBj4bqnbiDDrXQgbmjhuqV0IDUga8O9IHThu7EuJyk7XHJcbmNvbnN0IHBlcmlvZFNjaGVtYT16Lm9iamVjdCh7c3RhcnREYXRlOnouc3RyaW5nKCkucmVmaW5lKGlzVmFsaWREYXRlT25seSwnQ2jhu41uIG5nw6B5IGjhu6NwIGzhu4cuJyksZW5kRGF0ZTp6LnN0cmluZygpLnJlZmluZShpc1ZhbGlkRGF0ZU9ubHksJ0No4buNbiBuZ8OgeSBo4bujcCBs4buHLicpLHJlYXNvbjpyZWFzb25TY2hlbWF9KS5yZWZpbmUodj0+di5zdGFydERhdGU8PXYuZW5kRGF0ZSx7cGF0aDpbJ2VuZERhdGUnXSxtZXNzYWdlOidOZ8OgeSBjdeG7kWkga+G7syBwaOG6o2kgdOG7qyBuZ8OgeSDEkeG6p3Uga+G7syB0cuG7nyDEkWkuJ30pO1xyXG5leHBvcnQgZnVuY3Rpb24gQ3JlYXRlUGVyaW9kRGlhbG9nKHtvbkNsb3NlLG9uU2F2ZWR9OntvbkNsb3NlOigpPT52b2lkO29uU2F2ZWQ6KCk9PnZvaWR9KSB7XHJcbiAgICBjb25zdCBjcmVhdGU9dXNlQ29tbWFuZCgnY3JlYXRlQWNjb3VudGluZ1BlcmlvZCcsWydsaXN0QWNjb3VudGluZ1BlcmlvZHMnXSk7XHJcbiAgICBjb25zdCBmb3JtPXVzZUZvcm08ei5pbmZlcjx0eXBlb2YgcGVyaW9kU2NoZW1hPj4oe2RlZmF1bHRWYWx1ZXM6e3N0YXJ0RGF0ZTonJyxlbmREYXRlOicnLHJlYXNvbjonJ30scmVzb2x2ZXI6em9kUmVzb2x2ZXIocGVyaW9kU2NoZW1hKX0pO3VzZVdhdGNoKHtjb250cm9sOmZvcm0uY29udHJvbH0pO1xyXG4gICAgY29uc3QgYmluZD11c2VEcmFmdEZvcm0oZm9ybS5mb3JtU3RhdGUuaXNEaXJ0eSkscmVmPXVzZVJlZjxIVE1MRm9ybUVsZW1lbnR8bnVsbD4obnVsbCk7XHJcbiAgICByZXR1cm4gPEVkaXREaWFsb2cgb3BlbiB0aXRsZT1cIlThuqFvIGvhu7Mga+G6vyB0b8OhblwiIG9uQ2xvc2U9e29uQ2xvc2V9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwicGVyaW9kLWNyZWF0ZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17Y3JlYXRlLnBlbmRpbmd8fGNyZWF0ZS51bnJlc29sdmVkfT5U4bqhbyBr4buzIGvhur8gdG/DoW48L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yfS8+XHJcbiAgICAgICAgPEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIGlkPVwicGVyaW9kLWNyZWF0ZVwiIG5vVmFsaWRhdGUgcmVmPXtub2RlPT57cmVmLmN1cnJlbnQ9bm9kZTtiaW5kKG5vZGUpO319IGRhdGEtZHJhZnQtY2xlYW49eyFmb3JtLmZvcm1TdGF0ZS5pc0RpcnR5Pyd0cnVlJzp1bmRlZmluZWR9IG9uU3VibWl0PXtmb3JtLmhhbmRsZVN1Ym1pdChhc3luYyB2YWx1ZXM9Pnt0cnl7YXdhaXQgY3JlYXRlLmV4ZWN1dGUoe2JvZHk6dmFsdWVzfSk7aWYocmVmLmN1cnJlbnQpbWFya0RyYWZ0Q2xlYW4ocmVmLmN1cnJlbnQpO29uU2F2ZWQoKTtvbkNsb3NlKCk7fWNhdGNoey8qIFJldGFpbiBkcmFmdCBhbmQgcmVjb3ZlcnkuICovfX0pfT5cclxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkvhu7MgbeG7m2kgcGjhuqNpIGtow7RuZyBjaOG7k25nIGzhuqVuIGvhu7MgxJHDoyBjw7M7IEFQSSBraeG7g20gbOG6oWkgdHLGsOG7m2Mga2hpIHThuqFvLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJOZ8OgeSDEkeG6p3Uga+G7s1wiIHR5cGU9XCJkYXRlXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ3N0YXJ0RGF0ZScpfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuc3RhcnREYXRlKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLnN0YXJ0RGF0ZT8ubWVzc2FnZX0vPlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTmfDoHkgY3Xhu5FpIGvhu7NcIiB0eXBlPVwiZGF0ZVwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdlbmREYXRlJyl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5lbmREYXRlKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmVuZERhdGU/Lm1lc3NhZ2V9Lz5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkzDvSBkbyB04bqhbyBr4buzXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ3JlYXNvbicpfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMucmVhc29uKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLnJlYXNvbj8ubWVzc2FnZX0vPlxyXG4gICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgIDwvRWRpdERpYWxvZz47XHJcbn1cclxuY29uc3Qgb3BlbmluZ1NjaGVtYT16Lm9iamVjdCh7ZWZmZWN0aXZlRGF0ZTp6LnN0cmluZygpLnJlZmluZShpc1ZhbGlkRGF0ZU9ubHksJ0No4buNbiBuZ8OgeSBo4bujcCBs4buHLicpLHBvbGljeVZlcnNpb246ei5saXRlcmFsKCdzeW50aGV0aWMtcG9saWN5LTEnKSxyZWFzb246cmVhc29uU2NoZW1hLGxpbmVzOnouYXJyYXkoei5vYmplY3Qoe2FjY291bnRJZDp6LnN0cmluZygpLm1pbigxLCdDaOG7jW4gdMOgaSBraG/huqNuLicpLGRlYml0Om1vbmV5U2NoZW1hLGNyZWRpdDptb25leVNjaGVtYSxkZXNjcmlwdGlvbjp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTMwMCwnRGnhu4VuIGdp4bqjaSB04buRaSDEkWEgMzAwIGvDvSB04buxLicpLnRyaW0oKS5taW4oMSwnTmjhuq1wIGRp4buFbiBnaeG6o2kuJyl9KSksaW52ZW50b3J5OnouYXJyYXkoei5vYmplY3Qoe3ZhcmlhbnRJZDp6LnN0cmluZygpLm1pbigxLCdDaOG7jW4gYmnhur9uIHRo4buDLicpLHdhcmVob3VzZUlkOnouc3RyaW5nKCkubWluKDEsJ0No4buNbiBraG8uJykscXVhbnRpdHk6ei5udW1iZXIoKS5pbnQoKS5taW4oMCwnU+G7kSBsxrDhu6NuZyBraMO0bmcgw6JtLicpLHVuaXRDb3N0Om1vbmV5U2NoZW1hfSkpfSkuc3VwZXJSZWZpbmUoKHZhbHVlcyxjdHgpPT57XHJcbiAgICBjb25zdCB1bml0cz0oYTpzdHJpbmcpPT57Y29uc3QgW249JycsZj0nJ109YS5zcGxpdCgnLicpO3JldHVybiAvXlxcZCsoXFwuXFxkezEsNH0pPyQvLnRlc3QoYSk/QmlnSW50KG4pKjEwMDAwbitCaWdJbnQoZi5wYWRFbmQoNCwnMCcpKTowbjt9O2xldCBkPTBuLGM9MG47XHJcbiAgICB2YWx1ZXMubGluZXMuZm9yRWFjaCgobGluZSxpKT0+e2NvbnN0IGRlYml0PXVuaXRzKGxpbmUuZGViaXQuYW1vdW50KSxjcmVkaXQ9dW5pdHMobGluZS5jcmVkaXQuYW1vdW50KTtkKz1kZWJpdDtjKz1jcmVkaXQ7aWYoKGRlYml0PjBuKT09PShjcmVkaXQ+MG4pKWN0eC5hZGRJc3N1ZSh7Y29kZTonY3VzdG9tJyxwYXRoOlsnbGluZXMnLGksJ2RlYml0JywnYW1vdW50J10sbWVzc2FnZTonTeG7l2kgZMOybmcgY+G6p24gxJHDum5nIG3hu5l0IGLDqm4gTuG7oyBob+G6t2MgQ8OzIGTGsMahbmcuJ30pO30pO1xyXG4gICAgaWYoZCE9PWMpY3R4LmFkZElzc3VlKHtjb2RlOidjdXN0b20nLHBhdGg6WydsaW5lcycsMCwnZGViaXQnLCdhbW91bnQnXSxtZXNzYWdlOidU4buVbmcgc+G7kSBkxrAgTuG7oyBwaOG6o2kgYuG6sW5nIHThu5VuZyBz4buRIGTGsCBDw7MuJ30pO1xyXG4gICAgY29uc3Qga2V5cz1uZXcgU2V0PHN0cmluZz4oKTt2YWx1ZXMuaW52ZW50b3J5LmZvckVhY2goKGxpbmUsaSk9Pntjb25zdCBrZXk9YCR7bGluZS53YXJlaG91c2VJZH06JHtsaW5lLnZhcmlhbnRJZH1gO2lmKGtleXMuaGFzKGtleSkpY3R4LmFkZElzc3VlKHtjb2RlOidjdXN0b20nLHBhdGg6WydpbnZlbnRvcnknLGksJ3ZhcmlhbnRJZCddLG1lc3NhZ2U6J0tow7RuZyBs4bq3cCBraG8vYmnhur9uIHRo4buDLid9KTtrZXlzLmFkZChrZXkpO30pO1xyXG59KTtcclxuY29uc3Qgc25hcHNob3Q9KHI6T3BlbmluZ0JhbGFuY2UpPT4oe3ZlcnNpb246ci52ZXJzaW9uLHZhbHVlczp7ZWZmZWN0aXZlRGF0ZTpyLmVmZmVjdGl2ZURhdGUscG9saWN5VmVyc2lvbjpyLnBvbGljeVZlcnNpb24gYXMgJ3N5bnRoZXRpYy1wb2xpY3ktMScscmVhc29uOnIucmVhc29uLGxpbmVzOnIubGluZXMsaW52ZW50b3J5OnIuaW52ZW50b3J5fX0pO1xyXG50eXBlIE9wZW5pbmdGaWVsZHM9ei5pbmZlcjx0eXBlb2Ygb3BlbmluZ1NjaGVtYT47XHJcbmV4cG9ydCBmdW5jdGlvbiBPcGVuaW5nQmFsYW5jZXNQYWdlKCkge1xyXG4gICAgY29uc3Qge3Nob3B9PXVzZVNjb3BlKCksY2FuPXVzZUNhbignZmluYW5jZS5wb3N0Jyk7Y29uc3QgbGlzdD11c2VBcGkoJ2xpc3RPcGVuaW5nQmFsYW5jZXMnLHtxdWVyeTp1c2VMaXN0UXVlcnkoJ2xpc3RPcGVuaW5nQmFsYW5jZXMnKX0pO1xyXG4gICAgY29uc3QgW29wZW4sc2V0T3Blbl09dXNlU3RhdGUoZmFsc2UpLFtzZWxlY3RlZCxzZXRTZWxlY3RlZF09dXNlU3RhdGU8T3BlbmluZ0JhbGFuY2V8bnVsbD4obnVsbCksW3Bvc3RSb3csc2V0UG9zdFJvd109dXNlU3RhdGU8T3BlbmluZ0JhbGFuY2V8bnVsbD4obnVsbCksW3N1Y2Nlc3Msc2V0U3VjY2Vzc109dXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgZGV0YWlsPXVzZUFwaSgnZ2V0T3BlbmluZ0JhbGFuY2UnLHtwYXRoOntvcGVuaW5nSWQ6c2VsZWN0ZWQ/LmlkfHwnJ319LG9wZW4mJkJvb2xlYW4oc2VsZWN0ZWQpKTtcclxuICAgIGNvbnN0IGFjY291bnRzPXVzZVBhZ2VkQXBpKCdsaXN0QWNjb3VudHMnLHtxdWVyeTp7c3RhdHVzOidhY3RpdmUnfX0pLHdhcmVob3VzZXM9dXNlUGFnZWRBcGkoJ2xpc3RXYXJlaG91c2VzJyx7cXVlcnk6e3N0YXR1czonYWN0aXZlJ319KSxwcm9kdWN0cz11c2VQYWdlZEFwaSgnbGlzdFByb2R1Y3RzJyx7cXVlcnk6e3N0YXR1czonYWN0aXZlJ319KTtcclxuICAgIGNvbnN0IGNyZWF0ZT11c2VDb21tYW5kKCdjcmVhdGVPcGVuaW5nQmFsYW5jZScsWydsaXN0T3BlbmluZ0JhbGFuY2VzJ10pLHVwZGF0ZT11c2VDb21tYW5kKCd1cGRhdGVPcGVuaW5nQmFsYW5jZScsWydsaXN0T3BlbmluZ0JhbGFuY2VzJywnZ2V0T3BlbmluZ0JhbGFuY2UnXSkscG9zdD11c2VDb21tYW5kKCdwb3N0T3BlbmluZ0JhbGFuY2UnLFsnbGlzdE9wZW5pbmdCYWxhbmNlcycsJ2dldE9wZW5pbmdCYWxhbmNlJywnbGlzdFN0b2NrU25hcHNob3RzJywnZ2V0TGVkZ2VyJywnZ2V0VHJpYWxCYWxhbmNlJywnZ2V0QmFsYW5jZVNoZWV0JywnZ2V0UHJvZml0TG9zcycsJ2dldENhc2hmbG93JywnbGlzdEpvdXJuYWxzJ10pO1xyXG4gICAgY29uc3QgZW1wdHk6T3BlbmluZ0ZpZWxkcz17ZWZmZWN0aXZlRGF0ZTpkYXRlT25seUluVGltZXpvbmUobmV3IERhdGUoKSxzaG9wLnRpbWV6b25lKSxwb2xpY3lWZXJzaW9uOidzeW50aGV0aWMtcG9saWN5LTEnLHJlYXNvbjonJyxsaW5lczpbXSxpbnZlbnRvcnk6W119O1xyXG4gICAgY29uc3QgZm9ybT11c2VGb3JtPE9wZW5pbmdGaWVsZHM+KHtkZWZhdWx0VmFsdWVzOmVtcHR5LHJlc29sdmVyOnpvZFJlc29sdmVyKG9wZW5pbmdTY2hlbWEpfSk7dXNlV2F0Y2goe2NvbnRyb2w6Zm9ybS5jb250cm9sfSk7XHJcbiAgICBjb25zdCBsaW5lcz11c2VGaWVsZEFycmF5KHtjb250cm9sOmZvcm0uY29udHJvbCxuYW1lOidsaW5lcyd9KSxpbnZlbnRvcnk9dXNlRmllbGRBcnJheSh7Y29udHJvbDpmb3JtLmNvbnRyb2wsbmFtZTonaW52ZW50b3J5J30pLGZvcm1SZWY9dXNlUmVmPEhUTUxGb3JtRWxlbWVudHxudWxsPihudWxsKTtcclxuICAgIGNvbnN0IGVkaXRvcj11c2VWZXJzaW9uZWREcmFmdCh7aWRlbnRpdHk6YCR7c2hvcC5pZH06b3BlbmluZzoke3NlbGVjdGVkPy5pZHx8J25ldyd9YCxzb3VyY2U6ZGV0YWlsLmRhdGE/c25hcHNob3QoZGV0YWlsLmRhdGEuZGF0YSk6c2VsZWN0ZWQ/c25hcHNob3Qoc2VsZWN0ZWQpOnVuZGVmaW5lZCxkcmFmdDpmb3JtLmdldFZhbHVlcygpLGFwcGx5OnY9PmZvcm0ucmVzZXQodikscmVmcmVzaDooKT0+ZGV0YWlsLnJlZmV0Y2goe3Rocm93T25FcnJvcjp0cnVlfSl9KTtcclxuICAgIGNvbnN0IGRpcnR5PW9wZW4mJihzZWxlY3RlZD9lZGl0b3IuZGlydHk6IWRyYWZ0RXF1YWwoZW1wdHksZm9ybS5nZXRWYWx1ZXMoKSkpLGJpbmQ9dXNlRHJhZnRGb3JtKGRpcnR5KSxidXN5PWNyZWF0ZS5wZW5kaW5nfHx1cGRhdGUucGVuZGluZyxibG9ja2VkPXNlbGVjdGVkP3VwZGF0ZS51bnJlc29sdmVkOmNyZWF0ZS51bnJlc29sdmVkO1xyXG4gICAgY29uc3Qgc3VibWl0PWZvcm0uaGFuZGxlU3VibWl0KGFzeW5jIHZhbHVlcz0+e2lmKCFjYW58fGJsb2NrZWQpcmV0dXJuO3RyeSB7aWYoc2VsZWN0ZWQpe2NvbnN0IHByZXBhcmVkPWVkaXRvci5wcmVwYXJlKCk7aWYoIXByZXBhcmVkKXJldHVybjtjb25zdCBzdWJtaXR0ZWQ9Zm9ybS5nZXRWYWx1ZXMoKTtjb25zdCByZXN1bHQ9YXdhaXQgdXBkYXRlLmV4ZWN1dGUoe3BhdGg6e29wZW5pbmdJZDpzZWxlY3RlZC5pZH0sdmVyc2lvbjpwcmVwYXJlZC52ZXJzaW9uLGJvZHk6dmFsdWVzIGFzIE9wZW5pbmdCYWxhbmNlV3JpdGV9KTtpZighZWRpdG9yLmNvbW1pdHRlZChzbmFwc2hvdChyZXN1bHQuZGF0YSksc3VibWl0dGVkKSlyZXR1cm47fWVsc2UgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoe2JvZHk6dmFsdWVzfSk7aWYoZm9ybVJlZi5jdXJyZW50KW1hcmtEcmFmdENsZWFuKGZvcm1SZWYuY3VycmVudCk7c2V0T3BlbihmYWxzZSk7c2V0U3VjY2VzcygnxJDDoyBsxrB1IG5ow6FwIG3hu58gc+G7lS4gS2nhu4NtIGzhuqFpIHPhu5EgZMawIHbDoCB04buTbiB0csaw4bubYyBraGkgZ2hpIHPhu5UuJyk7fWNhdGNoKGUpe2VkaXRvci5mYWlsZWQoZSk7fX0pO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJN4bufIHPhu5Uga+G6vyB0b8OhblwiIHN1YnRpdGxlPVwiR2hpIHPhu5EgZMawIHbDoCB04buTbiDEkeG6p3Uga+G7syBt4buZdCBs4bqnbiBzYXUgxJHhu5FpIGNoaeG6v3U7IEFQSSBjaOG6t24gZ2hpIMSRw6ggc2hvcCDEkcOjIGPDsyBuZ2hp4buHcCB24bulLlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5wb3N0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpPT57c2V0U2VsZWN0ZWQobnVsbCk7Zm9ybS5yZXNldChlbXB0eSk7c2V0T3Blbih0cnVlKTt9fT5U4bqhbyBuaMOhcCBt4bufIHPhu5U8L011dGF0aW9uQnV0dG9uPn0vPntzdWNjZXNzJiY8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPntzdWNjZXNzfTwvQWxlcnQ+fVxyXG4gICAgICAgIDxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0T3BlbmluZ0JhbGFuY2VzXCIvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhJiY8PjxEYXRhVGFibGUgbGFiZWw9XCJI4buTIHPGoSBt4bufIHPhu5VcIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtyPT5yLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgIHtrZXk6J2lkJyxsYWJlbDonSOG7kyBzxqEnLHJlbmRlcjpyPT5yLmlkfSx7a2V5OidkYXRlJyxsYWJlbDonTmfDoHkgaGnhu4d1IGzhu7FjJyxyZW5kZXI6cj0+Zm9ybWF0RGF0ZU9ubHkoci5lZmZlY3RpdmVEYXRlKX0se2tleToncmVhc29uJyxsYWJlbDonTMO9IGRvJyxyZW5kZXI6cj0+ci5yZWFzb259LHtrZXk6J3N0YXR1cycsbGFiZWw6J1Ry4bqhbmcgdGjDoWknLHJlbmRlcjpyPT48U3RhdHVzIHZhbHVlPXtyLnN0YXR1c30vPn0se2tleTonYWN0aW9ucycsbGFiZWw6J1RoYW8gdMOhYycscmVuZGVyOnI9PnIuc3RhdHVzPT09J2RyYWZ0Jz88QWN0aW9uR3JvdXA+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBvbkNsaWNrPXsoKT0+e3NldFNlbGVjdGVkKHIpO2Zvcm0ucmVzZXQoc25hcHNob3QocikudmFsdWVzKTtzZXRPcGVuKHRydWUpO319PlPhu61hIG3hu58gc+G7lSB7ci5pZH08L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5wb3N0XCIgb25DbGljaz17KCk9PnNldFBvc3RSb3cocil9PkdoaSBt4bufIHPhu5Uge3IuaWR9PC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPjpyLmpvdXJuYWxJZD88Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL2pvdXJuYWxzP2pvdXJuYWxJZD0ke3Iuam91cm5hbElkfWB9PkLDunQgdG/DoW4gbeG7nyBz4buVPC9Sb3V0ZUxpbms+OidN4bufIHPhu5Ugc+G7kSBkxrAgYuG6sW5nIDAnfSxcclxuICAgICAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gICAgICAgIDxFZGl0RGlhbG9nIG9wZW49e29wZW59IHRpdGxlPXtzZWxlY3RlZD9gU+G7rWEgbeG7nyBz4buVICR7c2VsZWN0ZWQuaWR9YDonTmjDoXAgbeG7nyBz4buVIG3hu5tpJ30gb25DbG9zZT17KCk9PnNldE9wZW4oZmFsc2UpfSBidXN5PXtidXN5fSBhY3Rpb25zPXs8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwib3BlbmluZy1mb3JtXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtidXN5fHxibG9ja2VkfHwhY2FufHwoQm9vbGVhbihzZWxlY3RlZCkmJiFlZGl0b3IuZGlydHkpfT5MxrB1IG5ow6FwIG3hu58gc+G7lTwvQnV0dG9uPn0+XHJcbiAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yfHx1cGRhdGUuZXJyb3J8fGRldGFpbC5lcnJvcnx8YWNjb3VudHMuZXJyb3J8fHdhcmVob3VzZXMuZXJyb3J8fHByb2R1Y3RzLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17e2VmZmVjdGl2ZURhdGU6J05nw6B5IGhp4buHdSBs4buxYycscG9saWN5VmVyc2lvbjonQ2jDrW5oIHPDoWNoJyxyZWFzb246J0zDvSBkbycsbGluZXM6J1Rvw6BuIGLhu5kgc+G7kSBkxrAgdMOgaSBraG/huqNuJyxpbnZlbnRvcnk6J1Rvw6BuIGLhu5kgdOG7k24gxJHhuqd1IGvhu7MnfX0gYnVzeT17YnVzeX0vPlxyXG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgaWQ9XCJvcGVuaW5nLWZvcm1cIiBub1ZhbGlkYXRlIG9uU3VibWl0PXtzdWJtaXR9IHJlZj17bm9kZT0+e2Zvcm1SZWYuY3VycmVudD1ub2RlO2JpbmQobm9kZSk7fX0gZGF0YS1kcmFmdC1jbGVhbj17IWRpcnR5Pyd0cnVlJzp1bmRlZmluZWR9PlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlPhu5EgZMawIGLhurFuZyAwIMSRxrDhu6NjIHBow6lwIMSR4buDIHRy4buRbmcgZMOybmcuIEdpw6EgdHLhu4sgdOG7k24gcGjhuqNpIGto4bubcCB0w6BpIGtob+G6o24gMTU2OyBz4buRIGTGsCBj4bqnbiBjw6JuIGLhurFuZyB2w6AgY2jhu4kgZ2hpIHRyb25nIGvhu7MgxJFhbmcgbeG7ny48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwiTmfDoHkgbeG7nyBz4buVXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ2VmZmVjdGl2ZURhdGUnKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmVmZmVjdGl2ZURhdGUpfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuZWZmZWN0aXZlRGF0ZT8ubWVzc2FnZX0vPlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkNow61uaCBzw6FjaCBt4bufIHPhu5VcIiB2YWx1ZT1cInN5bnRoZXRpYy1wb2xpY3ktMVwiIElucHV0UHJvcHM9e3tyZWFkT25seTp0cnVlfX0vPlxyXG4gICAgICAgICAgICAgICAgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwidMOgaSBraG/huqNuIG3hu58gc+G7lVwiIGxvYWRlZENvdW50PXthY2NvdW50cy5sb2FkZWRDb3VudH0gaGFzTW9yZT17YWNjb3VudHMuaGFzTW9yZX0gYnVzeT17YWNjb3VudHMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17YWNjb3VudHMubG9hZE1vcmV9Lz5cclxuICAgICAgICAgICAgICAgIHtsaW5lcy5maWVsZHMubWFwKChmaWVsZCxpKT0+PFN1cmZhY2VDb250ZW50IGtleT17ZmllbGQuaWR9IGJvZHlNb2RlPVwiY29tcGFjdE91dGxpbmVkXCI+PEZvcm1GaWVsZHM+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9e2BUw6BpIGtob+G6o24gc+G7kSBkxrAgJHtpKzF9YH0gey4uLmZvcm0ucmVnaXN0ZXIoYGxpbmVzLiR7aX0uYWNjb3VudElkYCl9IHZhbHVlPXtmb3JtLndhdGNoKGBsaW5lcy4ke2l9LmFjY291bnRJZGApfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMubGluZXM/LltpXT8uYWNjb3VudElkKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmxpbmVzPy5baV0/LmFjY291bnRJZD8ubWVzc2FnZX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIHTDoGkga2hv4bqjbjwvTWVudUl0ZW0+e2FjY291bnRzLmRhdGE/LmRhdGEubWFwKGE9PjxNZW51SXRlbSBrZXk9e2EuaWR9IHZhbHVlPXthLmlkfT57YS5jb2RlfSDCtyB7YS5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICB7KFsnZGViaXQnLCdjcmVkaXQnXSBhcyBjb25zdCkubWFwKHNpZGU9PjxUZXh0RmllbGQga2V5PXtzaWRlfSBsYWJlbD17YCR7c2lkZT09PSdkZWJpdCc/J07hu6MnOidDw7MnfSBz4buRIGTGsCAke2krMX0gKCR7c2hvcC5jdXJyZW5jeX0pYH0gey4uLmZvcm0ucmVnaXN0ZXIoYGxpbmVzLiR7aX0uJHtzaWRlfS5hbW91bnRgKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmxpbmVzPy5baV0/LltzaWRlXT8uYW1vdW50KX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmxpbmVzPy5baV0/LltzaWRlXT8uYW1vdW50Py5tZXNzYWdlfSBpbnB1dFByb3BzPXt7aW5wdXRNb2RlOidkZWNpbWFsJ319Lz4pfVxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9e2BEaeG7hW4gZ2nhuqNpIHPhu5EgZMawICR7aSsxfWB9IHsuLi5mb3JtLnJlZ2lzdGVyKGBsaW5lcy4ke2l9LmRlc2NyaXB0aW9uYCl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5kZXNjcmlwdGlvbil9IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5kZXNjcmlwdGlvbj8ubWVzc2FnZX0vPjxCdXR0b24gb25DbGljaz17KCk9PmxpbmVzLnJlbW92ZShpKX0+QuG7jyBz4buRIGTGsCB7aSsxfTwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPjwvU3VyZmFjZUNvbnRlbnQ+KX1cclxuICAgICAgICAgICAgICAgIHtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMubGluZXM/Lm1lc3NhZ2UmJjxBbGVydCBzZXZlcml0eT1cImVycm9yXCI+e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcy5tZXNzYWdlfTwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKT0+bGluZXMuYXBwZW5kKHthY2NvdW50SWQ6JycsZGViaXQ6e2Ftb3VudDonMCcsY3VycmVuY3k6c2hvcC5jdXJyZW5jeX0sY3JlZGl0OnthbW91bnQ6JzAnLGN1cnJlbmN5OnNob3AuY3VycmVuY3l9LGRlc2NyaXB0aW9uOicnfSl9PlRow6ptIHPhu5EgZMawIHTDoGkga2hv4bqjbjwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwia2hvIG3hu58gc+G7lVwiIGxvYWRlZENvdW50PXt3YXJlaG91c2VzLmxvYWRlZENvdW50fSBoYXNNb3JlPXt3YXJlaG91c2VzLmhhc01vcmV9IGJ1c3k9e3dhcmVob3VzZXMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17d2FyZWhvdXNlcy5sb2FkTW9yZX0vPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cInPhuqNuIHBo4bqpbSBt4bufIHPhu5VcIiBsb2FkZWRDb3VudD17cHJvZHVjdHMubG9hZGVkQ291bnR9IGhhc01vcmU9e3Byb2R1Y3RzLmhhc01vcmV9IGJ1c3k9e3Byb2R1Y3RzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e3Byb2R1Y3RzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgICAgICB7aW52ZW50b3J5LmZpZWxkcy5tYXAoKGZpZWxkLGkpPT48U3VyZmFjZUNvbnRlbnQga2V5PXtmaWVsZC5pZH0gYm9keU1vZGU9XCJjb21wYWN0T3V0bGluZWRcIj48Rm9ybUZpZWxkcz5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD17YEtobyB04buTbiDEkeG6p3UgJHtpKzF9YH0gey4uLmZvcm0ucmVnaXN0ZXIoYGludmVudG9yeS4ke2l9LndhcmVob3VzZUlkYCl9IHZhbHVlPXtmb3JtLndhdGNoKGBpbnZlbnRvcnkuJHtpfS53YXJlaG91c2VJZGApfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuaW52ZW50b3J5Py5baV0/LndhcmVob3VzZUlkKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmludmVudG9yeT8uW2ldPy53YXJlaG91c2VJZD8ubWVzc2FnZX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIGtobzwvTWVudUl0ZW0+e3dhcmVob3VzZXMuZGF0YT8uZGF0YS5tYXAodz0+PE1lbnVJdGVtIGtleT17dy5pZH0gdmFsdWU9e3cuaWR9Pnt3LmNvZGV9IMK3IHt3Lm5hbWV9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPXtgQmnhur9uIHRo4buDIHThu5NuIMSR4bqndSAke2krMX1gfSB7Li4uZm9ybS5yZWdpc3RlcihgaW52ZW50b3J5LiR7aX0udmFyaWFudElkYCl9IHZhbHVlPXtmb3JtLndhdGNoKGBpbnZlbnRvcnkuJHtpfS52YXJpYW50SWRgKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmludmVudG9yeT8uW2ldPy52YXJpYW50SWQpfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuaW52ZW50b3J5Py5baV0/LnZhcmlhbnRJZD8ubWVzc2FnZX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIGJp4bq/biB0aOG7gzwvTWVudUl0ZW0+e3Byb2R1Y3RzLmRhdGE/LmRhdGEuZmxhdE1hcChwPT5wLnZhcmlhbnRzLm1hcCh2PT48TWVudUl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5pZH0+e3Yuc2t1fSDCtyB7cC5uYW1lfTwvTWVudUl0ZW0+KSl9PC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD17YFPhu5EgbMaw4bujbmcgdOG7k24gxJHhuqd1ICR7aSsxfWB9IHsuLi5mb3JtLnJlZ2lzdGVyKGBpbnZlbnRvcnkuJHtpfS5xdWFudGl0eWAse3ZhbHVlQXNOdW1iZXI6dHJ1ZX0pfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuaW52ZW50b3J5Py5baV0/LnF1YW50aXR5KX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmludmVudG9yeT8uW2ldPy5xdWFudGl0eT8ubWVzc2FnZX0gaW5wdXRQcm9wcz17e2lucHV0TW9kZTonbnVtZXJpYyd9fS8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD17YEdpw6EgduG7kW4gxJHGoW4gduG7iyAke2krMX0gKCR7c2hvcC5jdXJyZW5jeX0pYH0gey4uLmZvcm0ucmVnaXN0ZXIoYGludmVudG9yeS4ke2l9LnVuaXRDb3N0LmFtb3VudGApfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuaW52ZW50b3J5Py5baV0/LnVuaXRDb3N0Py5hbW91bnQpfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuaW52ZW50b3J5Py5baV0/LnVuaXRDb3N0Py5hbW91bnQ/Lm1lc3NhZ2V9IGlucHV0UHJvcHM9e3tpbnB1dE1vZGU6J2RlY2ltYWwnfX0vPjxCdXR0b24gb25DbGljaz17KCk9PmludmVudG9yeS5yZW1vdmUoaSl9PkLhu48gdOG7k24gxJHhuqd1IHtpKzF9PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+PC9TdXJmYWNlQ29udGVudD4pfVxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKT0+aW52ZW50b3J5LmFwcGVuZCh7d2FyZWhvdXNlSWQ6JycsdmFyaWFudElkOicnLHF1YW50aXR5OjAsdW5pdENvc3Q6e2Ftb3VudDonMCcsY3VycmVuY3k6c2hvcC5jdXJyZW5jeX19KX0+VGjDqm0gdOG7k24gxJHhuqd1IGvhu7M8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gbeG7nyBz4buVXCIgbXVsdGlsaW5lIG1pblJvd3M9ezJ9IHsuLi5mb3JtLnJlZ2lzdGVyKCdyZWFzb24nKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLnJlYXNvbil9IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5yZWFzb24/Lm1lc3NhZ2V9Lz5cclxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgICAgIDwvRWRpdERpYWxvZz5cclxuICAgICAgICA8Q29uZmlybURpYWxvZyBvcGVuPXtCb29sZWFuKHBvc3RSb3cpfSB0aXRsZT1cIkdoaSBt4bufIHPhu5VcIiBjb25maXJtTGFiZWw9XCJHaGkgbeG7nyBz4buVXCIgZGVzY3JpcHRpb249e2BI4buTIHPGoSAke3Bvc3RSb3c/LmlkfHwnJ30sIGhp4buHdSBs4buxYyAke2Zvcm1hdERhdGVPbmx5KHBvc3RSb3c/LmVmZmVjdGl2ZURhdGUpfTogZ2hpIHPhu5EgZMawIHbDoCB04buTbiBzYXUgxJHhu5FpIGNoaeG6v3UuIEtow7RuZyBz4butYSB0cuG7sWMgdGnhur9wIHNhdSBnaGk7IG3hu41pIMSRaeG7gXUga2nhu4duIMSRxrDhu6NjIEFQSSBraeG7g20gbOG6oWkuYH0gYnVzeT17cG9zdC5wZW5kaW5nfSBlcnJvcj17cG9zdC5lcnJvcn0gb25DbG9zZT17KCk9PnNldFBvc3RSb3cobnVsbCl9IG9uQ29uZmlybT17YXN5bmMoKT0+e2lmKCFwb3N0Um93KXJldHVybjthd2FpdCBwb3N0LmV4ZWN1dGUoe3BhdGg6e29wZW5pbmdJZDpwb3N0Um93LmlkfSxib2R5OntleHBlY3RlZFZlcnNpb246cG9zdFJvdy52ZXJzaW9ufX0pO3NldFN1Y2Nlc3MoJ8SQw6MgZ2hpIG3hu58gc+G7lTsgc+G7kSBkxrAgdsOgIHThu5NuIGzhuqV5IHThu6sgaOG7kyBzxqEgxJHDoyBraeG7g20uJyk7fX0vPlxyXG4gICAgPC8+O1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2ZpbmFuY2UvbWFuYWdlbWVudC50c3gifQ==