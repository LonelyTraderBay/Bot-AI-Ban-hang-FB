import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/entry-editor.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react_jsx-dev-runtime.js?v=585edd0d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react.js?v=585edd0d"; const useRef = __vite__cjsImport3_react["useRef"];
import { Alert, Button, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/@mui_material.js?v=585edd0d";
import { useForm, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/react-hook-form.js?v=585edd0d";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/@hookform_resolvers_zod.js?v=585edd0d";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-73092-50fd99b6-bc0d-47a5-95b6-0f61742bb93c/deps/zod.js?v=585edd0d";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useVersionedDraft, draftEqual } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { codePointLength } from "/src/shared/model/format.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { FormFields } from "/src/shared/ui/composition.tsx";
import { EditDialog, ErrorNotice } from "/src/shared/ui/components.tsx";
export const financeEntryClasses = { sales_receipt: "Thu bán hàng", inventory_purchase: "Mua tồn kho", shipping: "Vận chuyển", platform_fee: "Phí nền tảng", payment_fee: "Phí thanh toán", ai_expense: "Chi phí AI", operating_expense: "Chi phí vận hành", capital: "Góp vốn", loan_principal: "Gốc vay", transfer: "Chuyển nội bộ", other: "Khác" };
const schema = z.object({ kind: z.enum(["receipt", "disbursement"]), classification: z.enum(["sales_receipt", "inventory_purchase", "shipping", "platform_fee", "payment_fee", "ai_expense", "operating_expense", "capital", "loan_principal", "transfer", "other"]), amount: z.object({ amount: z.string().regex(/^\d+(\.\d{1,4})?$/, "Nhập số dương, tối đa 4 chữ số thập phân.").refine((v) => /[1-9]/.test(v), "Số tiền phải lớn hơn 0."), currency: z.string().min(1) }), occurredAt: z.string().datetime({ offset: true, message: "Nhập thời điểm ISO 8601 có múi giờ, ví dụ 2026-09-29T14:00:00Z." }), description: z.string().refine((v) => codePointLength(v) <= 2e3, "Diễn giải tối đa 2.000 ký tự.").trim().min(5, "Diễn giải cần ít nhất 5 ký tự."), sourceRef: z.object({ type: z.string(), id: z.string() }).nullable() });
const snapshot = (r) => ({ version: r.version, values: { kind: r.kind, classification: r.classification, amount: r.amount, occurredAt: r.occurredAt, description: r.description, sourceRef: r.sourceRef } });
export function FinanceEntryEditor({ initial, onClose, onSaved }) {
  _s();
  const { shop } = useScope(), can = useCan("finance.post");
  const empty = { kind: "disbursement", classification: "operating_expense", amount: { amount: "", currency: shop.currency }, occurredAt: (/* @__PURE__ */ new Date()).toISOString(), description: "", sourceRef: null };
  const initialEmpty = useRef(empty).current;
  const form = useForm({ defaultValues: initial ? snapshot(initial).values : initialEmpty, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const detail = useApi("getFinanceEntry", { path: { entryId: initial?.id || "" } }, Boolean(initial));
  const create = useCommand("createFinanceEntry", ["listFinanceEntries"]), update = useCommand("updateFinanceEntry", ["listFinanceEntries", "getFinanceEntry"]);
  const editor = useVersionedDraft({ identity: `${shop.id}:entry:${initial?.id || "new"}`, source: detail.data ? snapshot(detail.data.data) : initial ? snapshot(initial) : void 0, draft: form.getValues(), apply: (v) => form.reset(v), refresh: () => detail.refetch({ throwOnError: true }) });
  const dirty = initial ? editor.dirty : !draftEqual(initialEmpty, form.getValues()), ref = useRef(null), bind = useDraftForm(dirty), busy = create.pending || update.pending, blocked = initial ? update.unresolved : create.unresolved;
  const submit = form.handleSubmit(async (values) => {
    if (!can || blocked) return;
    try {
      if (initial) {
        const prepared = editor.prepare();
        if (!prepared) return;
        const submitted = form.getValues();
        const body = { ...prepared.patch };
        for (const key of Object.keys(body)) Object.assign(body, { [key]: values[key] });
        const result = await update.execute({ path: { entryId: initial.id }, version: prepared.version, body });
        if (!editor.committed(snapshot(result.data), submitted)) return;
      } else await create.execute({ body: values });
      if (ref.current) markDraftClean(ref.current);
      onSaved();
      onClose();
    } catch (e) {
      editor.failed(e);
    }
  });
  return /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: initial ? "Sửa phiếu nháp" : "Phiếu thu chi mới", onClose, busy, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", type: "submit", form: "finance-entry-editor", disabled: busy || blocked || !can || Boolean(initial) && !editor.dirty, children: "Lưu nháp" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
    lineNumber: 48,
    columnNumber: 123
  }, this), children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || detail.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { kind: "Loại phiếu", classification: "Phân loại", amount: "Số tiền", occurredAt: "Thời điểm", description: "Diễn giải", sourceRef: "Nguồn chứng từ" }, busy }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
      lineNumber: 49,
      columnNumber: 77
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "finance-entry-editor", noValidate: true, ref: (node) => {
      ref.current = node;
      bind(node);
    }, onSubmit: submit, "data-draft-clean": !dirty ? "true" : void 0, children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Loại phiếu", ...form.register("kind"), value: form.watch("kind"), children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "receipt", children: "Thu tiền" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
          lineNumber: 51,
          columnNumber: 104
        }, this),
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "disbursement", children: "Chi tiền" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
          lineNumber: 51,
          columnNumber: 149
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Phân loại", ...form.register("classification"), value: form.watch("classification"), children: Object.entries(financeEntryClasses).map(([value, label]) => /* @__PURE__ */ jsxDEV(MenuItem, { value, children: label }, value, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 52,
        columnNumber: 184
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: `Số tiền (${shop.currency})`, ...form.register("amount.amount"), error: Boolean(form.formState.errors.amount?.amount), helperText: form.formState.errors.amount?.amount?.message, inputProps: { inputMode: "decimal" } }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 53,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Thời điểm ISO 8601", ...form.register("occurredAt"), error: Boolean(form.formState.errors.occurredAt), helperText: form.formState.errors.occurredAt?.message || "Có múi giờ; không tự suy từ máy." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Diễn giải", multiline: true, minRows: 2, ...form.register("description"), error: Boolean(form.formState.errors.description), helperText: form.formState.errors.description?.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 55,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Ghi sổ theo chính sách quản trị. Chứng từ có nguồn đối soát/đơn phải điều chỉnh qua nghiệp vụ sở hữu, không đảo riêng làm lệch công nợ và tồn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
        lineNumber: 56,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx",
    lineNumber: 48,
    columnNumber: 10
  }, this);
}
_s(FinanceEntryEditor, "GiQFS00doy+yxgR7JyDlaFk9f70=", false, function() {
  return [useScope, useCan, useForm, useWatch, useApi, useCommand, useCommand, useVersionedDraft, useDraftForm];
});
_c = FinanceEntryEditor;
var _c;
$RefreshReg$(_c, "FinanceEntryEditor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/entry-editor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJ3SDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1QnhILFNBQVFBLGNBQWE7QUFDckIsU0FBUUMsT0FBTUMsUUFBT0MsVUFBU0MsaUJBQWdCO0FBQzlDLFNBQVFDLFNBQVFDLGdCQUFlO0FBQy9CLFNBQVFDLG1CQUFrQjtBQUMxQixTQUFRQyxTQUFRO0FBRWhCLFNBQVFDLFFBQU9DLGtCQUFpQjtBQUNoQyxTQUFRQyxVQUFTQyxjQUFhO0FBQzlCLFNBQVFDLG1CQUFrQkMsa0JBQWlCO0FBQzNDLFNBQVFDLGNBQWFDLHNCQUFxQjtBQUMxQyxTQUFRQyx1QkFBc0I7QUFDOUIsU0FBUUMscUJBQW9CO0FBQzVCLFNBQVFDLGtCQUFpQjtBQUN6QixTQUFRQyxZQUFXQyxtQkFBa0I7QUFFOUIsYUFBTUMsc0JBQXVFLEVBQUNDLGVBQWMsZ0JBQWVDLG9CQUFtQixlQUFjQyxVQUFTLGNBQWFDLGNBQWEsZ0JBQWVDLGFBQVksa0JBQWlCQyxZQUFXLGNBQWFDLG1CQUFrQixvQkFBbUJDLFNBQVEsV0FBVUMsZ0JBQWUsV0FBVUMsVUFBUyxpQkFBZ0JDLE9BQU0sT0FBTTtBQUMvVyxNQUFNQyxTQUFPMUIsRUFBRTJCLE9BQU8sRUFBQ0MsTUFBSzVCLEVBQUU2QixLQUFLLENBQUMsV0FBVSxjQUFjLENBQUMsR0FBRUMsZ0JBQWU5QixFQUFFNkIsS0FBSyxDQUFDLGlCQUFnQixzQkFBcUIsWUFBVyxnQkFBZSxlQUFjLGNBQWEscUJBQW9CLFdBQVUsa0JBQWlCLFlBQVcsT0FBTyxDQUFDLEdBQUVFLFFBQU8vQixFQUFFMkIsT0FBTyxFQUFDSSxRQUFPL0IsRUFBRWdDLE9BQU8sRUFBRUMsTUFBTSxxQkFBb0IsMkNBQTJDLEVBQUVDLE9BQU8sQ0FBQUMsTUFBRyxRQUFRQyxLQUFLRCxDQUFDLEdBQUUseUJBQXlCLEdBQUVFLFVBQVNyQyxFQUFFZ0MsT0FBTyxFQUFFTSxJQUFJLENBQUMsRUFBQyxDQUFDLEdBQUVDLFlBQVd2QyxFQUFFZ0MsT0FBTyxFQUFFUSxTQUFTLEVBQUNDLFFBQU8sTUFBS0MsU0FBUSxrRUFBaUUsQ0FBQyxHQUFFQyxhQUFZM0MsRUFBRWdDLE9BQU8sRUFBRUUsT0FBTyxDQUFBQyxNQUFHMUIsZ0JBQWdCMEIsQ0FBQyxLQUFHLEtBQUssK0JBQStCLEVBQUVTLEtBQUssRUFBRU4sSUFBSSxHQUFFLGdDQUFnQyxHQUFFTyxXQUFVN0MsRUFBRTJCLE9BQU8sRUFBQ21CLE1BQUs5QyxFQUFFZ0MsT0FBTyxHQUFFZSxJQUFHL0MsRUFBRWdDLE9BQU8sRUFBQyxDQUFDLEVBQUVnQixTQUFTLEVBQUMsQ0FBQztBQUNqdkIsTUFBTUMsV0FBU0EsQ0FBQ0MsT0FBa0IsRUFBQ0MsU0FBUUQsRUFBRUMsU0FBUUMsUUFBTyxFQUFDeEIsTUFBS3NCLEVBQUV0QixNQUFLRSxnQkFBZW9CLEVBQUVwQixnQkFBZUMsUUFBT21CLEVBQUVuQixRQUFPUSxZQUFXVyxFQUFFWCxZQUFXSSxhQUFZTyxFQUFFUCxhQUFZRSxXQUFVSyxFQUFFTCxVQUFTLEVBQUM7QUFDMUwsZ0JBQVNRLG1CQUFtQixFQUFDQyxTQUFRQyxTQUFRQyxRQUFxRSxHQUFHO0FBQUFDLEtBQUE7QUFDeEgsUUFBTSxFQUFDQyxLQUFJLElBQUV2RCxTQUFTLEdBQUV3RCxNQUFJdkQsT0FBTyxjQUFjO0FBQ2pELFFBQU13RCxRQUF3QixFQUFDaEMsTUFBSyxnQkFBZUUsZ0JBQWUscUJBQW9CQyxRQUFPLEVBQUNBLFFBQU8sSUFBR00sVUFBU3FCLEtBQUtyQixTQUFRLEdBQUVFLGFBQVcsb0JBQUlzQixLQUFLLEdBQUVDLFlBQVksR0FBRW5CLGFBQVksSUFBR0UsV0FBVSxLQUFJO0FBQ2pNLFFBQU1rQixlQUFhdkUsT0FBT29FLEtBQUssRUFBRUk7QUFDakMsUUFBTUMsT0FBS3BFLFFBQTJCLEVBQUNxRSxlQUFjWixVQUFRTCxTQUFTSyxPQUFPLEVBQUVGLFNBQU9XLGNBQWFJLFVBQVNwRSxZQUFZMkIsTUFBTSxFQUFDLENBQUM7QUFBRTVCLFdBQVMsRUFBQ3NFLFNBQVFILEtBQUtHLFFBQU8sQ0FBQztBQUNqSyxRQUFNQyxTQUFPcEUsT0FBTyxtQkFBa0IsRUFBQ3FFLE1BQUssRUFBQ0MsU0FBUWpCLFNBQVNQLE1BQUksR0FBRSxFQUFDLEdBQUV5QixRQUFRbEIsT0FBTyxDQUFDO0FBQ3ZGLFFBQU1tQixTQUFPdkUsV0FBVyxzQkFBcUIsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFFd0UsU0FBT3hFLFdBQVcsc0JBQXFCLENBQUMsc0JBQXFCLGlCQUFpQixDQUFDO0FBQ3BKLFFBQU15RSxTQUFPdEUsa0JBQWtCLEVBQUN1RSxVQUFTLEdBQUdsQixLQUFLWCxFQUFFLFVBQVVPLFNBQVNQLE1BQUksS0FBSyxJQUFHOEIsUUFBT1IsT0FBT1MsT0FBSzdCLFNBQVNvQixPQUFPUyxLQUFLQSxJQUFJLElBQUV4QixVQUFRTCxTQUFTSyxPQUFPLElBQUV5QixRQUFVQyxPQUFNZixLQUFLZ0IsVUFBVSxHQUFFQyxPQUFNQSxDQUFBL0MsTUFBRzhCLEtBQUtrQixNQUFNaEQsQ0FBQyxHQUFFaUQsU0FBUUEsTUFBSWYsT0FBT2dCLFFBQVEsRUFBQ0MsY0FBYSxLQUFJLENBQUMsRUFBQyxDQUFDO0FBQ2xRLFFBQU1DLFFBQU1qQyxVQUFRcUIsT0FBT1ksUUFBTSxDQUFDakYsV0FBV3lELGNBQWFFLEtBQUtnQixVQUFVLENBQUMsR0FBRU8sTUFBSWhHLE9BQTZCLElBQUksR0FBRWlHLE9BQUtsRixhQUFhZ0YsS0FBSyxHQUFFRyxPQUFLakIsT0FBT2tCLFdBQVNqQixPQUFPaUIsU0FBUUMsVUFBUXRDLFVBQVFvQixPQUFPbUIsYUFBV3BCLE9BQU9vQjtBQUN6TixRQUFNQyxTQUFPN0IsS0FBSzhCLGFBQWEsT0FBTTNDLFdBQVE7QUFBQyxRQUFHLENBQUNPLE9BQUtpQyxRQUFRO0FBQU8sUUFBRztBQUFDLFVBQUd0QyxTQUFRO0FBQUMsY0FBTTBDLFdBQVNyQixPQUFPc0IsUUFBUTtBQUFFLFlBQUcsQ0FBQ0QsU0FBUztBQUFPLGNBQU1FLFlBQVVqQyxLQUFLZ0IsVUFBVTtBQUFFLGNBQU1rQixPQUFLLEVBQUMsR0FBR0gsU0FBU0ksTUFBSztBQUFFLG1CQUFVQyxPQUFPQyxPQUFPQyxLQUFLSixJQUFJLEVBQWlDRyxRQUFPRSxPQUFPTCxNQUFLLEVBQUMsQ0FBQ0UsR0FBRyxHQUFFakQsT0FBT2lELEdBQUcsRUFBQyxDQUFDO0FBQUUsY0FBTUksU0FBTyxNQUFNL0IsT0FBT2dDLFFBQVEsRUFBQ3BDLE1BQUssRUFBQ0MsU0FBUWpCLFFBQVFQLEdBQUUsR0FBRUksU0FBUTZDLFNBQVM3QyxTQUFRZ0QsS0FBSSxDQUFDO0FBQUUsWUFBRyxDQUFDeEIsT0FBT2dDLFVBQVUxRCxTQUFTd0QsT0FBTzNCLElBQUksR0FBRW9CLFNBQVMsRUFBRTtBQUFBLE1BQU8sTUFBTSxPQUFNekIsT0FBT2lDLFFBQVEsRUFBQ1AsTUFBSy9DLE9BQU0sQ0FBQztBQUFFLFVBQUdvQyxJQUFJeEIsUUFBUXhELGdCQUFlZ0YsSUFBSXhCLE9BQU87QUFBRVIsY0FBUTtBQUFFRCxjQUFRO0FBQUEsSUFBRSxTQUFPcUQsR0FBRTtBQUFDakMsYUFBT2tDLE9BQU9ELENBQUM7QUFBQSxJQUFFO0FBQUEsRUFBQyxDQUFDO0FBQ3BsQixTQUFPLHVCQUFDLGNBQVcsTUFBSSxNQUFDLE9BQU90RCxVQUFRLG1CQUFpQixxQkFBcUIsU0FBa0IsTUFBWSxTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssVUFBUyxNQUFLLHdCQUF1QixVQUFVb0MsUUFBTUUsV0FBUyxDQUFDakMsT0FBTWEsUUFBUWxCLE9BQU8sS0FBRyxDQUFDcUIsT0FBT1ksT0FBUSx3QkFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnSixHQUNoUTtBQUFBLDJCQUFDLGVBQVksT0FBT2QsT0FBT3FDLFNBQU9wQyxPQUFPb0MsU0FBT3pDLE9BQU95QyxTQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUNsRixNQUFLLGNBQWFFLGdCQUFlLGFBQVlDLFFBQU8sV0FBVVEsWUFBVyxhQUFZSSxhQUFZLGFBQVlFLFdBQVUsaUJBQWdCLEdBQUcsUUFBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2TDtBQUFBLElBQzVQLHVCQUFDLGNBQVcsV0FBVSxRQUFPLElBQUcsd0JBQXVCLFlBQVUsTUFBQyxLQUFLLENBQUFrRSxTQUFNO0FBQUN2QixVQUFJeEIsVUFBUStDO0FBQUt0QixXQUFLc0IsSUFBSTtBQUFBLElBQUUsR0FBRyxVQUFVakIsUUFBUSxvQkFBa0IsQ0FBQ1AsUUFBTSxTQUFPUixRQUMzSjtBQUFBLDZCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sY0FBYSxHQUFJZCxLQUFLK0MsU0FBUyxNQUFNLEdBQUcsT0FBTy9DLEtBQUtnRCxNQUFNLE1BQU0sR0FBRztBQUFBLCtCQUFDLFlBQVMsT0FBTSxXQUFVLHdCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFBVyx1QkFBQyxZQUFTLE9BQU0sZ0JBQWUsd0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxXQUEvSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBMO0FBQUEsTUFDMUwsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxhQUFZLEdBQUloRCxLQUFLK0MsU0FBUyxnQkFBZ0IsR0FBRyxPQUFPL0MsS0FBS2dELE1BQU0sZ0JBQWdCLEdBQUlYLGlCQUFPWSxRQUFRcEcsbUJBQW1CLEVBQUVxRyxJQUFJLENBQUMsQ0FBQ0MsT0FBTUMsS0FBSyxNQUFJLHVCQUFDLFlBQXFCLE9BQWVBLG1CQUF0QkQsT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDLENBQVcsS0FBOU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnTztBQUFBLE1BQ2hPLHVCQUFDLGFBQVUsT0FBTyxZQUFZMUQsS0FBS3JCLFFBQVEsS0FBSyxHQUFJNEIsS0FBSytDLFNBQVMsZUFBZSxHQUFHLE9BQU94QyxRQUFRUCxLQUFLcUQsVUFBVUMsT0FBT3hGLFFBQVFBLE1BQU0sR0FBRyxZQUFZa0MsS0FBS3FELFVBQVVDLE9BQU94RixRQUFRQSxRQUFRVyxTQUFTLFlBQVksRUFBQzhFLFdBQVUsVUFBUyxLQUFyTztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVPO0FBQUEsTUFDdk8sdUJBQUMsYUFBVSxPQUFNLHNCQUFxQixHQUFJdkQsS0FBSytDLFNBQVMsWUFBWSxHQUFHLE9BQU94QyxRQUFRUCxLQUFLcUQsVUFBVUMsT0FBT2hGLFVBQVUsR0FBRyxZQUFZMEIsS0FBS3FELFVBQVVDLE9BQU9oRixZQUFZRyxXQUFTLHNDQUFoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1OO0FBQUEsTUFDbk4sdUJBQUMsYUFBVSxPQUFNLGFBQVksV0FBUyxNQUFDLFNBQVMsR0FBRyxHQUFJdUIsS0FBSytDLFNBQVMsYUFBYSxHQUFHLE9BQU94QyxRQUFRUCxLQUFLcUQsVUFBVUMsT0FBTzVFLFdBQVcsR0FBRyxZQUFZc0IsS0FBS3FELFVBQVVDLE9BQU81RSxhQUFhRCxXQUF2TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStMO0FBQUEsTUFDL0wsdUJBQUMsU0FBTSxVQUFTLFFBQU8sOEpBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUs7QUFBQSxTQU56SztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQVRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVUDtBQUNKO0FBQUNlLEdBckJlSixvQkFBa0I7QUFBQSxVQUNqQmxELFVBQWVDLFFBR2pCUCxTQUF1SEMsVUFDckhHLFFBQ0FDLFlBQStEQSxZQUMvREcsbUJBQzJHRSxZQUFZO0FBQUE7QUFBQSxLQVJ4SDhDO0FBQWtCLElBQUFvRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJBbGVydCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiVGV4dEZpZWxkIiwidXNlRm9ybSIsInVzZVdhdGNoIiwiem9kUmVzb2x2ZXIiLCJ6IiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlQ2FuIiwidXNlVmVyc2lvbmVkRHJhZnQiLCJkcmFmdEVxdWFsIiwidXNlRHJhZnRGb3JtIiwibWFya0RyYWZ0Q2xlYW4iLCJjb2RlUG9pbnRMZW5ndGgiLCJEcmFmdENvbmZsaWN0IiwiRm9ybUZpZWxkcyIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsImZpbmFuY2VFbnRyeUNsYXNzZXMiLCJzYWxlc19yZWNlaXB0IiwiaW52ZW50b3J5X3B1cmNoYXNlIiwic2hpcHBpbmciLCJwbGF0Zm9ybV9mZWUiLCJwYXltZW50X2ZlZSIsImFpX2V4cGVuc2UiLCJvcGVyYXRpbmdfZXhwZW5zZSIsImNhcGl0YWwiLCJsb2FuX3ByaW5jaXBhbCIsInRyYW5zZmVyIiwib3RoZXIiLCJzY2hlbWEiLCJvYmplY3QiLCJraW5kIiwiZW51bSIsImNsYXNzaWZpY2F0aW9uIiwiYW1vdW50Iiwic3RyaW5nIiwicmVnZXgiLCJyZWZpbmUiLCJ2IiwidGVzdCIsImN1cnJlbmN5IiwibWluIiwib2NjdXJyZWRBdCIsImRhdGV0aW1lIiwib2Zmc2V0IiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwidHJpbSIsInNvdXJjZVJlZiIsInR5cGUiLCJpZCIsIm51bGxhYmxlIiwic25hcHNob3QiLCJyIiwidmVyc2lvbiIsInZhbHVlcyIsIkZpbmFuY2VFbnRyeUVkaXRvciIsImluaXRpYWwiLCJvbkNsb3NlIiwib25TYXZlZCIsIl9zIiwic2hvcCIsImNhbiIsImVtcHR5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwiaW5pdGlhbEVtcHR5IiwiY3VycmVudCIsImZvcm0iLCJkZWZhdWx0VmFsdWVzIiwicmVzb2x2ZXIiLCJjb250cm9sIiwiZGV0YWlsIiwicGF0aCIsImVudHJ5SWQiLCJCb29sZWFuIiwiY3JlYXRlIiwidXBkYXRlIiwiZWRpdG9yIiwiaWRlbnRpdHkiLCJzb3VyY2UiLCJkYXRhIiwidW5kZWZpbmVkIiwiZHJhZnQiLCJnZXRWYWx1ZXMiLCJhcHBseSIsInJlc2V0IiwicmVmcmVzaCIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJkaXJ0eSIsInJlZiIsImJpbmQiLCJidXN5IiwicGVuZGluZyIsImJsb2NrZWQiLCJ1bnJlc29sdmVkIiwic3VibWl0IiwiaGFuZGxlU3VibWl0IiwicHJlcGFyZWQiLCJwcmVwYXJlIiwic3VibWl0dGVkIiwiYm9keSIsInBhdGNoIiwia2V5IiwiT2JqZWN0Iiwia2V5cyIsImFzc2lnbiIsInJlc3VsdCIsImV4ZWN1dGUiLCJjb21taXR0ZWQiLCJlIiwiZmFpbGVkIiwiZXJyb3IiLCJub2RlIiwicmVnaXN0ZXIiLCJ3YXRjaCIsImVudHJpZXMiLCJtYXAiLCJ2YWx1ZSIsImxhYmVsIiwiZm9ybVN0YXRlIiwiZXJyb3JzIiwiaW5wdXRNb2RlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiZW50cnktZWRpdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVJlZn0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtBbGVydCxCdXR0b24sTWVudUl0ZW0sVGV4dEZpZWxkfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7dXNlRm9ybSx1c2VXYXRjaH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJztcbmltcG9ydCB7em9kUmVzb2x2ZXJ9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJztcbmltcG9ydCB7en0gZnJvbSAnem9kJztcbmltcG9ydCB0eXBlIHtGaW5hbmNlRW50cnksRmluYW5jZUVudHJ5V3JpdGV9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHt1c2VBcGksdXNlQ29tbWFuZH0gZnJvbSAnQC9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7dXNlU2NvcGUsdXNlQ2FufSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQge3VzZVZlcnNpb25lZERyYWZ0LGRyYWZ0RXF1YWx9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XG5pbXBvcnQge3VzZURyYWZ0Rm9ybSxtYXJrRHJhZnRDbGVhbn0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZGlydHktZHJhZnRzJztcbmltcG9ydCB7Y29kZVBvaW50TGVuZ3RofSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHtEcmFmdENvbmZsaWN0fSBmcm9tICdAL3NoYXJlZC91aS9kcmFmdC1jb25mbGljdCc7XG5pbXBvcnQge0Zvcm1GaWVsZHN9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcbmltcG9ydCB7RWRpdERpYWxvZyxFcnJvck5vdGljZX0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG5cbmV4cG9ydCBjb25zdCBmaW5hbmNlRW50cnlDbGFzc2VzOlJlY29yZDxGaW5hbmNlRW50cnlXcml0ZVsnY2xhc3NpZmljYXRpb24nXSxzdHJpbmc+PXtzYWxlc19yZWNlaXB0OidUaHUgYsOhbiBow6BuZycsaW52ZW50b3J5X3B1cmNoYXNlOidNdWEgdOG7k24ga2hvJyxzaGlwcGluZzonVuG6rW4gY2h1eeG7g24nLHBsYXRmb3JtX2ZlZTonUGjDrSBu4buBbiB04bqjbmcnLHBheW1lbnRfZmVlOidQaMOtIHRoYW5oIHRvw6FuJyxhaV9leHBlbnNlOidDaGkgcGjDrSBBSScsb3BlcmF0aW5nX2V4cGVuc2U6J0NoaSBwaMOtIHbhuq1uIGjDoG5oJyxjYXBpdGFsOidHw7NwIHbhu5FuJyxsb2FuX3ByaW5jaXBhbDonR+G7kWMgdmF5Jyx0cmFuc2ZlcjonQ2h1eeG7g24gbuG7mWkgYuG7mScsb3RoZXI6J0tow6FjJ307XG5jb25zdCBzY2hlbWE9ei5vYmplY3Qoe2tpbmQ6ei5lbnVtKFsncmVjZWlwdCcsJ2Rpc2J1cnNlbWVudCddKSxjbGFzc2lmaWNhdGlvbjp6LmVudW0oWydzYWxlc19yZWNlaXB0JywnaW52ZW50b3J5X3B1cmNoYXNlJywnc2hpcHBpbmcnLCdwbGF0Zm9ybV9mZWUnLCdwYXltZW50X2ZlZScsJ2FpX2V4cGVuc2UnLCdvcGVyYXRpbmdfZXhwZW5zZScsJ2NhcGl0YWwnLCdsb2FuX3ByaW5jaXBhbCcsJ3RyYW5zZmVyJywnb3RoZXInXSksYW1vdW50Onoub2JqZWN0KHthbW91bnQ6ei5zdHJpbmcoKS5yZWdleCgvXlxcZCsoXFwuXFxkezEsNH0pPyQvLCdOaOG6rXAgc+G7kSBkxrDGoW5nLCB04buRaSDEkWEgNCBjaOG7ryBz4buRIHRo4bqtcCBwaMOibi4nKS5yZWZpbmUodj0+L1sxLTldLy50ZXN0KHYpLCdT4buRIHRp4buBbiBwaOG6o2kgbOG7m24gaMahbiAwLicpLGN1cnJlbmN5Onouc3RyaW5nKCkubWluKDEpfSksb2NjdXJyZWRBdDp6LnN0cmluZygpLmRhdGV0aW1lKHtvZmZzZXQ6dHJ1ZSxtZXNzYWdlOidOaOG6rXAgdGjhu51pIMSRaeG7g20gSVNPIDg2MDEgY8OzIG3DumkgZ2nhu50sIHbDrSBk4bulIDIwMjYtMDktMjlUMTQ6MDA6MDBaLid9KSxkZXNjcmlwdGlvbjp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTIwMDAsJ0Rp4buFbiBnaeG6o2kgdOG7kWkgxJFhIDIuMDAwIGvDvSB04buxLicpLnRyaW0oKS5taW4oNSwnRGnhu4VuIGdp4bqjaSBj4bqnbiDDrXQgbmjhuqV0IDUga8O9IHThu7EuJyksc291cmNlUmVmOnoub2JqZWN0KHt0eXBlOnouc3RyaW5nKCksaWQ6ei5zdHJpbmcoKX0pLm51bGxhYmxlKCl9KTtcbmNvbnN0IHNuYXBzaG90PShyOkZpbmFuY2VFbnRyeSk9Pih7dmVyc2lvbjpyLnZlcnNpb24sdmFsdWVzOntraW5kOnIua2luZCxjbGFzc2lmaWNhdGlvbjpyLmNsYXNzaWZpY2F0aW9uLGFtb3VudDpyLmFtb3VudCxvY2N1cnJlZEF0OnIub2NjdXJyZWRBdCxkZXNjcmlwdGlvbjpyLmRlc2NyaXB0aW9uLHNvdXJjZVJlZjpyLnNvdXJjZVJlZn19KTtcbmV4cG9ydCBmdW5jdGlvbiBGaW5hbmNlRW50cnlFZGl0b3Ioe2luaXRpYWwsb25DbG9zZSxvblNhdmVkfTp7aW5pdGlhbDpGaW5hbmNlRW50cnl8bnVsbDtvbkNsb3NlOigpPT52b2lkO29uU2F2ZWQ6KCk9PnZvaWR9KSB7XG4gICAgY29uc3Qge3Nob3B9PXVzZVNjb3BlKCksY2FuPXVzZUNhbignZmluYW5jZS5wb3N0Jyk7XG4gICAgY29uc3QgZW1wdHk6RmluYW5jZUVudHJ5V3JpdGU9e2tpbmQ6J2Rpc2J1cnNlbWVudCcsY2xhc3NpZmljYXRpb246J29wZXJhdGluZ19leHBlbnNlJyxhbW91bnQ6e2Ftb3VudDonJyxjdXJyZW5jeTpzaG9wLmN1cnJlbmN5fSxvY2N1cnJlZEF0Om5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxkZXNjcmlwdGlvbjonJyxzb3VyY2VSZWY6bnVsbH07XG4gICAgY29uc3QgaW5pdGlhbEVtcHR5PXVzZVJlZihlbXB0eSkuY3VycmVudDtcbiAgICBjb25zdCBmb3JtPXVzZUZvcm08RmluYW5jZUVudHJ5V3JpdGU+KHtkZWZhdWx0VmFsdWVzOmluaXRpYWw/c25hcHNob3QoaW5pdGlhbCkudmFsdWVzOmluaXRpYWxFbXB0eSxyZXNvbHZlcjp6b2RSZXNvbHZlcihzY2hlbWEpfSk7dXNlV2F0Y2goe2NvbnRyb2w6Zm9ybS5jb250cm9sfSk7XG4gICAgY29uc3QgZGV0YWlsPXVzZUFwaSgnZ2V0RmluYW5jZUVudHJ5Jyx7cGF0aDp7ZW50cnlJZDppbml0aWFsPy5pZHx8Jyd9fSxCb29sZWFuKGluaXRpYWwpKTtcbiAgICBjb25zdCBjcmVhdGU9dXNlQ29tbWFuZCgnY3JlYXRlRmluYW5jZUVudHJ5JyxbJ2xpc3RGaW5hbmNlRW50cmllcyddKSx1cGRhdGU9dXNlQ29tbWFuZCgndXBkYXRlRmluYW5jZUVudHJ5JyxbJ2xpc3RGaW5hbmNlRW50cmllcycsJ2dldEZpbmFuY2VFbnRyeSddKTtcbiAgICBjb25zdCBlZGl0b3I9dXNlVmVyc2lvbmVkRHJhZnQoe2lkZW50aXR5OmAke3Nob3AuaWR9OmVudHJ5OiR7aW5pdGlhbD8uaWR8fCduZXcnfWAsc291cmNlOmRldGFpbC5kYXRhP3NuYXBzaG90KGRldGFpbC5kYXRhLmRhdGEpOmluaXRpYWw/c25hcHNob3QoaW5pdGlhbCk6dW5kZWZpbmVkLGRyYWZ0OmZvcm0uZ2V0VmFsdWVzKCksYXBwbHk6dj0+Zm9ybS5yZXNldCh2KSxyZWZyZXNoOigpPT5kZXRhaWwucmVmZXRjaCh7dGhyb3dPbkVycm9yOnRydWV9KX0pO1xuICAgIGNvbnN0IGRpcnR5PWluaXRpYWw/ZWRpdG9yLmRpcnR5OiFkcmFmdEVxdWFsKGluaXRpYWxFbXB0eSxmb3JtLmdldFZhbHVlcygpKSxyZWY9dXNlUmVmPEhUTUxGb3JtRWxlbWVudHxudWxsPihudWxsKSxiaW5kPXVzZURyYWZ0Rm9ybShkaXJ0eSksYnVzeT1jcmVhdGUucGVuZGluZ3x8dXBkYXRlLnBlbmRpbmcsYmxvY2tlZD1pbml0aWFsP3VwZGF0ZS51bnJlc29sdmVkOmNyZWF0ZS51bnJlc29sdmVkO1xuICAgIGNvbnN0IHN1Ym1pdD1mb3JtLmhhbmRsZVN1Ym1pdChhc3luYyB2YWx1ZXM9PntpZighY2FufHxibG9ja2VkKXJldHVybjt0cnl7aWYoaW5pdGlhbCl7Y29uc3QgcHJlcGFyZWQ9ZWRpdG9yLnByZXBhcmUoKTtpZighcHJlcGFyZWQpcmV0dXJuO2NvbnN0IHN1Ym1pdHRlZD1mb3JtLmdldFZhbHVlcygpO2NvbnN0IGJvZHk9ey4uLnByZXBhcmVkLnBhdGNofTtmb3IoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGJvZHkpIGFzIChrZXlvZiBGaW5hbmNlRW50cnlXcml0ZSlbXSlPYmplY3QuYXNzaWduKGJvZHkse1trZXldOnZhbHVlc1trZXldfSk7Y29uc3QgcmVzdWx0PWF3YWl0IHVwZGF0ZS5leGVjdXRlKHtwYXRoOntlbnRyeUlkOmluaXRpYWwuaWR9LHZlcnNpb246cHJlcGFyZWQudmVyc2lvbixib2R5fSk7aWYoIWVkaXRvci5jb21taXR0ZWQoc25hcHNob3QocmVzdWx0LmRhdGEpLHN1Ym1pdHRlZCkpcmV0dXJuO31lbHNlIGF3YWl0IGNyZWF0ZS5leGVjdXRlKHtib2R5OnZhbHVlc30pO2lmKHJlZi5jdXJyZW50KW1hcmtEcmFmdENsZWFuKHJlZi5jdXJyZW50KTtvblNhdmVkKCk7b25DbG9zZSgpO31jYXRjaChlKXtlZGl0b3IuZmFpbGVkKGUpO319KTtcbiAgICByZXR1cm4gPEVkaXREaWFsb2cgb3BlbiB0aXRsZT17aW5pdGlhbD8nU+G7rWEgcGhp4bq/dSBuaMOhcCc6J1BoaeG6v3UgdGh1IGNoaSBt4bubaSd9IG9uQ2xvc2U9e29uQ2xvc2V9IGJ1c3k9e2J1c3l9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwiZmluYW5jZS1lbnRyeS1lZGl0b3JcIiBkaXNhYmxlZD17YnVzeXx8YmxvY2tlZHx8IWNhbnx8KEJvb2xlYW4oaW5pdGlhbCkmJiFlZGl0b3IuZGlydHkpfT5MxrB1IG5ow6FwPC9CdXR0b24+fT5cbiAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3J8fHVwZGF0ZS5lcnJvcnx8ZGV0YWlsLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17e2tpbmQ6J0xv4bqhaSBwaGnhur91JyxjbGFzc2lmaWNhdGlvbjonUGjDom4gbG/huqFpJyxhbW91bnQ6J1Phu5EgdGnhu4FuJyxvY2N1cnJlZEF0OidUaOG7nWkgxJFp4buDbScsZGVzY3JpcHRpb246J0Rp4buFbiBnaeG6o2knLHNvdXJjZVJlZjonTmd14buTbiBjaOG7qW5nIHThu6snfX0gYnVzeT17YnVzeX0vPlxuICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgaWQ9XCJmaW5hbmNlLWVudHJ5LWVkaXRvclwiIG5vVmFsaWRhdGUgcmVmPXtub2RlPT57cmVmLmN1cnJlbnQ9bm9kZTtiaW5kKG5vZGUpO319IG9uU3VibWl0PXtzdWJtaXR9IGRhdGEtZHJhZnQtY2xlYW49eyFkaXJ0eT8ndHJ1ZSc6dW5kZWZpbmVkfT5cbiAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTG/huqFpIHBoaeG6v3VcIiB7Li4uZm9ybS5yZWdpc3Rlcigna2luZCcpfSB2YWx1ZT17Zm9ybS53YXRjaCgna2luZCcpfT48TWVudUl0ZW0gdmFsdWU9XCJyZWNlaXB0XCI+VGh1IHRp4buBbjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiZGlzYnVyc2VtZW50XCI+Q2hpIHRp4buBbjwvTWVudUl0ZW0+PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIlBow6JuIGxv4bqhaVwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdjbGFzc2lmaWNhdGlvbicpfSB2YWx1ZT17Zm9ybS53YXRjaCgnY2xhc3NpZmljYXRpb24nKX0+e09iamVjdC5lbnRyaWVzKGZpbmFuY2VFbnRyeUNsYXNzZXMpLm1hcCgoW3ZhbHVlLGxhYmVsXSk9PjxNZW51SXRlbSBrZXk9e3ZhbHVlfSB2YWx1ZT17dmFsdWV9PntsYWJlbH08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPXtgU+G7kSB0aeG7gW4gKCR7c2hvcC5jdXJyZW5jeX0pYH0gey4uLmZvcm0ucmVnaXN0ZXIoJ2Ftb3VudC5hbW91bnQnKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmFtb3VudD8uYW1vdW50KX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmFtb3VudD8uYW1vdW50Py5tZXNzYWdlfSBpbnB1dFByb3BzPXt7aW5wdXRNb2RlOidkZWNpbWFsJ319Lz5cbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJUaOG7nWkgxJFp4buDbSBJU08gODYwMVwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdvY2N1cnJlZEF0Jyl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5vY2N1cnJlZEF0KX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLm9jY3VycmVkQXQ/Lm1lc3NhZ2V8fCdDw7MgbcO6aSBnaeG7nTsga2jDtG5nIHThu7Egc3V5IHThu6sgbcOheS4nfS8+XG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiRGnhu4VuIGdp4bqjaVwiIG11bHRpbGluZSBtaW5Sb3dzPXsyfSB7Li4uZm9ybS5yZWdpc3RlcignZGVzY3JpcHRpb24nKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmRlc2NyaXB0aW9uKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmRlc2NyaXB0aW9uPy5tZXNzYWdlfS8+XG4gICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+R2hpIHPhu5UgdGhlbyBjaMOtbmggc8OhY2ggcXXhuqNuIHRy4buLLiBDaOG7qW5nIHThu6sgY8OzIG5ndeG7k24gxJHhu5FpIHNvw6F0L8SRxqFuIHBo4bqjaSDEkWnhu4F1IGNo4buJbmggcXVhIG5naGnhu4dwIHbhu6Ugc+G7nyBo4buvdSwga2jDtG5nIMSR4bqjbyByacOqbmcgbMOgbSBs4buHY2ggY8O0bmcgbuG7oyB2w6AgdOG7k24uPC9BbGVydD5cbiAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgIDwvRWRpdERpYWxvZz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9maW5hbmNlL2VudHJ5LWVkaXRvci50c3gifQ==