import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/journal-editor.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react.js?v=f9568e8d"; const useRef = __vite__cjsImport3_react["useRef"];
import { Alert, Button, MenuItem, TextField } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/@mui_material.js?v=f9568e8d";
import { useForm, useWatch, useFieldArray } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react-hook-form.js?v=f9568e8d";
import { zodResolver } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/@hookform_resolvers_zod.js?v=f9568e8d";
import { z } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/zod.js?v=f9568e8d";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { dateOnlyInTimezone, isValidDateOnly, codePointLength } from "/src/shared/model/format.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { FormFields, SurfaceContent } from "/src/shared/ui/composition.tsx";
import { EditDialog, ErrorNotice, LookupLoadMore } from "/src/shared/ui/components.tsx";
const exact = z.string().regex(/^\d+(\.\d{1,4})?$/, "Nhập số không âm, tối đa 4 chữ số thập phân.");
const units = (value) => {
  const [whole = "", fraction = ""] = value.split(".");
  return /^\d+(\.\d{1,4})?$/.test(value) ? BigInt(whole) * 10000n + BigInt(fraction.padEnd(4, "0")) : 0n;
};
const money = z.object({ amount: exact, currency: z.string().min(1) });
const schema = z.object({ sourceType: z.string().refine((v) => codePointLength(v) <= 100, "Loại nguồn tối đa 100 ký tự.").trim().min(1, "Nhập loại nguồn."), sourceId: z.string().regex(/^[A-Za-z0-9_-]+$/, "Mã nguồn chỉ gồm chữ/số, gạch ngang và gạch dưới."), effectiveDate: z.string().refine(isValidDateOnly, "Chọn ngày hợp lệ."), reason: z.string().refine((v) => codePointLength(v) <= 1e3, "Lý do tối đa 1.000 ký tự.").trim().min(5, "Lý do cần ít nhất 5 ký tự."), replacesJournalId: z.string().nullable().optional(), lines: z.array(z.object({ accountId: z.string().min(1, "Chọn tài khoản."), debit: money, credit: money, description: z.string().refine((v) => codePointLength(v) <= 300, "Diễn giải tối đa 300 ký tự.").trim().min(1, "Nhập diễn giải.") })).min(2, "Bút toán cần ít nhất hai dòng.") }).superRefine((values, ctx) => {
  let debit = 0n, credit = 0n;
  values.lines.forEach((l, i) => {
    const d = units(l.debit.amount), c = units(l.credit.amount);
    debit += d;
    credit += c;
    if (d > 0n === c > 0n) ctx.addIssue({ code: "custom", path: ["lines", i, "debit", "amount"], message: "Mỗi dòng cần đúng một bên Nợ hoặc Có dương." });
  });
  if (debit !== credit) ctx.addIssue({ code: "custom", path: ["lines", 0, "debit", "amount"], message: "Tổng Nợ và Có cần cân bằng." });
});
export function JournalEditor({ replacement, onClose, onSaved }) {
  _s();
  const { shop } = useScope(), accounts = usePagedApi("listAccounts", { query: { status: "active" } }), periods = useApi("listAccountingPeriods"), create = useCommand("createJournal", ["listJournals"]);
  const newLine = () => ({ accountId: "", debit: { amount: "0", currency: shop.currency }, credit: { amount: "0", currency: shop.currency }, description: "" });
  const form = useForm({ defaultValues: { sourceType: replacement?.sourceType || "manual", sourceId: replacement?.sourceId || "", effectiveDate: dateOnlyInTimezone(/* @__PURE__ */ new Date(), shop.timezone), lines: replacement?.lines || [newLine(), newLine()], reason: "", replacesJournalId: replacement?.id || null }, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const lines = useFieldArray({ control: form.control, name: "lines" }), ref = useRef(null), bind = useDraftForm(form.formState.isDirty), date = form.watch("effectiveDate"), period = periods.data?.data.find((p) => date >= p.startDate && date <= p.endDate);
  const submit = form.handleSubmit(async (values) => {
    if (period?.state !== "open") {
      form.setError("effectiveDate", { message: "Ngày hiệu lực cần nằm trong kỳ kế toán đang mở." }, { shouldFocus: true });
      return;
    }
    try {
      const { replacesJournalId, ...body } = values;
      await create.execute({ body: replacesJournalId ? { ...body, replacesJournalId } : body });
      if (ref.current) markDraftClean(ref.current);
      onSaved();
      onClose();
    } catch {
    }
  });
  return /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: replacement ? "Thay thế bút toán đã đảo" : "Bút toán nháp", onClose, busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "journal-create", variant: "contained", disabled: create.pending || create.unresolved, children: "Lưu nháp" }, void 0, false, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
    lineNumber: 42,
    columnNumber: 143
  }, this), children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || accounts.error || periods.error }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "journal-create", noValidate: true, ref: (node) => {
      ref.current = node;
      bind(node);
    }, onSubmit: submit, "data-draft-clean": !form.formState.isDirty ? "true" : void 0, children: [
      replacement && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
        "Thay thế ",
        replacement.id,
        " sau đảo; giữ nguyên nguồn và lịch sử. API kiểm revision mới, phiên bản tài khoản và kỳ trước khi ghi."
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 44,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Loại chứng từ nguồn", ...form.register("sourceType"), InputProps: { readOnly: Boolean(replacement) }, error: Boolean(form.formState.errors.sourceType), helperText: form.formState.errors.sourceType?.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 45,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Mã chứng từ nguồn", ...form.register("sourceId"), InputProps: { readOnly: Boolean(replacement) }, error: Boolean(form.formState.errors.sourceId), helperText: form.formState.errors.sourceId?.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 46,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Ngày hiệu lực", ...form.register("effectiveDate"), error: Boolean(form.formState.errors.effectiveDate), helperText: form.formState.errors.effectiveDate?.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 47,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: period?.state === "open" ? "info" : "warning", children: period ? period.state === "open" ? `Kỳ ${period.startDate} – ${period.endDate} đang mở.` : `Kỳ ${period.startDate} – ${period.endDate} đã khóa.` : "Chưa có kỳ mở cho ngày này; tạo kỳ tại Công nợ & khóa kỳ." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 48,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "tài khoản kế toán", loadedCount: accounts.loadedCount, hasMore: accounts.hasMore, busy: accounts.isLoadingMore, onLoadMore: accounts.loadMore }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this),
      lines.fields.map((field, i) => /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "compactOutlined", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: `Tài khoản dòng ${i + 1}`, ...form.register(`lines.${i}.accountId`), value: form.watch(`lines.${i}.accountId`), error: Boolean(form.formState.errors.lines?.[i]?.accountId), helperText: form.formState.errors.lines?.[i]?.accountId?.message, children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn tài khoản" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
            lineNumber: 51,
            columnNumber: 282
          }, this),
          accounts.data?.data.map((a) => /* @__PURE__ */ jsxDEV(MenuItem, { value: a.id, children: [
            a.code,
            " · ",
            a.name
          ] }, a.id, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
            lineNumber: 51,
            columnNumber: 358
          }, this))
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
          lineNumber: 51,
          columnNumber: 17
        }, this),
        ["debit", "credit"].map((side) => /* @__PURE__ */ jsxDEV(TextField, { label: `${side === "debit" ? "Nợ" : "Có"} dòng ${i + 1}`, ...form.register(`lines.${i}.${side}.amount`), error: Boolean(form.formState.errors.lines?.[i]?.[side]?.amount), helperText: form.formState.errors.lines?.[i]?.[side]?.amount?.message, inputProps: { inputMode: "decimal" } }, side, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
          lineNumber: 52,
          columnNumber: 63
        }, this)),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Diễn giải dòng ${i + 1}`, ...form.register(`lines.${i}.description`), error: Boolean(form.formState.errors.lines?.[i]?.description), helperText: form.formState.errors.lines?.[i]?.description?.message }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
          lineNumber: 53,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { disabled: lines.fields.length <= 2, onClick: () => lines.remove(i), children: [
          "Bỏ dòng ",
          i + 1
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
          lineNumber: 53,
          columnNumber: 240
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 50,
        columnNumber: 103
      }, this) }, field.id, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 50,
        columnNumber: 45
      }, this)),
      form.formState.errors.lines?.message && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: form.formState.errors.lines.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 55,
        columnNumber: 54
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => lines.append(newLine()), children: "Thêm dòng" }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 55,
        columnNumber: 124
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", ...form.register("reason"), error: Boolean(form.formState.errors.reason), helperText: form.formState.errors.reason?.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
        lineNumber: 56,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
      lineNumber: 43,
      columnNumber: 80
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
}
_s(JournalEditor, "ZN3oYgHW7/25EUioBbSNtSC/D0A=", false, function() {
  return [useScope, usePagedApi, useApi, useCommand, useForm, useWatch, useFieldArray, useDraftForm];
});
_c = JournalEditor;
var _c;
$RefreshReg$(_c, "JournalEditor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/journal-editor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0I0STs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QjVJLFNBQVFBLGNBQWE7QUFDckIsU0FBUUMsT0FBTUMsUUFBT0MsVUFBU0MsaUJBQWdCO0FBQzlDLFNBQVFDLFNBQVFDLFVBQVNDLHFCQUFvQjtBQUM3QyxTQUFRQyxtQkFBa0I7QUFDMUIsU0FBUUMsU0FBUTtBQUVoQixTQUFRQyxRQUFPQyxhQUFZQyxrQkFBaUI7QUFDNUMsU0FBUUMsZ0JBQWU7QUFDdkIsU0FBUUMsb0JBQW1CQyxpQkFBZ0JDLHVCQUFzQjtBQUNqRSxTQUFRQyxjQUFhQyxzQkFBcUI7QUFDMUMsU0FBUUMsWUFBV0Msc0JBQXFCO0FBQ3hDLFNBQVFDLFlBQVdDLGFBQVlDLHNCQUFxQjtBQUNwRCxNQUFNQyxRQUFNZixFQUFFZ0IsT0FBTyxFQUFFQyxNQUFNLHFCQUFvQiw4Q0FBOEM7QUFDL0YsTUFBTUMsUUFBTUEsQ0FBQ0MsVUFBZTtBQUFDLFFBQU0sQ0FBQ0MsUUFBTSxJQUFHQyxXQUFTLEVBQUUsSUFBRUYsTUFBTUcsTUFBTSxHQUFHO0FBQUUsU0FBTyxvQkFBb0JDLEtBQUtKLEtBQUssSUFBRUssT0FBT0osS0FBSyxJQUFFLFNBQU9JLE9BQU9ILFNBQVNJLE9BQU8sR0FBRSxHQUFHLENBQUMsSUFBRTtBQUFHO0FBQ3pLLE1BQU1DLFFBQU0xQixFQUFFMkIsT0FBTyxFQUFDQyxRQUFPYixPQUFNYyxVQUFTN0IsRUFBRWdCLE9BQU8sRUFBRWMsSUFBSSxDQUFDLEVBQUMsQ0FBQztBQUM5RCxNQUFNQyxTQUFPL0IsRUFBRTJCLE9BQU8sRUFBQ0ssWUFBV2hDLEVBQUVnQixPQUFPLEVBQUVpQixPQUFPLENBQUFDLE1BQUczQixnQkFBZ0IyQixDQUFDLEtBQUcsS0FBSSw4QkFBOEIsRUFBRUMsS0FBSyxFQUFFTCxJQUFJLEdBQUUsa0JBQWtCLEdBQUVNLFVBQVNwQyxFQUFFZ0IsT0FBTyxFQUFFQyxNQUFNLG9CQUFtQixtREFBbUQsR0FBRW9CLGVBQWNyQyxFQUFFZ0IsT0FBTyxFQUFFaUIsT0FBTzNCLGlCQUFnQixtQkFBbUIsR0FBRWdDLFFBQU90QyxFQUFFZ0IsT0FBTyxFQUFFaUIsT0FBTyxDQUFBQyxNQUFHM0IsZ0JBQWdCMkIsQ0FBQyxLQUFHLEtBQUssMkJBQTJCLEVBQUVDLEtBQUssRUFBRUwsSUFBSSxHQUFFLDRCQUE0QixHQUFFUyxtQkFBa0J2QyxFQUFFZ0IsT0FBTyxFQUFFd0IsU0FBUyxFQUFFQyxTQUFTLEdBQUVDLE9BQU0xQyxFQUFFMkMsTUFBTTNDLEVBQUUyQixPQUFPLEVBQUNpQixXQUFVNUMsRUFBRWdCLE9BQU8sRUFBRWMsSUFBSSxHQUFFLGlCQUFpQixHQUFFZSxPQUFNbkIsT0FBTW9CLFFBQU9wQixPQUFNcUIsYUFBWS9DLEVBQUVnQixPQUFPLEVBQUVpQixPQUFPLENBQUFDLE1BQUczQixnQkFBZ0IyQixDQUFDLEtBQUcsS0FBSSw2QkFBNkIsRUFBRUMsS0FBSyxFQUFFTCxJQUFJLEdBQUUsaUJBQWlCLEVBQUMsQ0FBQyxDQUFDLEVBQUVBLElBQUksR0FBRSxnQ0FBZ0MsRUFBQyxDQUFDLEVBQUVrQixZQUFZLENBQUNDLFFBQU9DLFFBQU07QUFBQyxNQUFJTCxRQUFNLElBQUdDLFNBQU87QUFBR0csU0FBT1AsTUFBTVMsUUFBUSxDQUFDQyxHQUFFQyxNQUFJO0FBQUMsVUFBTUMsSUFBRXBDLE1BQU1rQyxFQUFFUCxNQUFNakIsTUFBTSxHQUFFMkIsSUFBRXJDLE1BQU1rQyxFQUFFTixPQUFPbEIsTUFBTTtBQUFFaUIsYUFBT1M7QUFBRVIsY0FBUVM7QUFBRSxRQUFJRCxJQUFFLE9BQU9DLElBQUUsR0FBSUwsS0FBSU0sU0FBUyxFQUFDQyxNQUFLLFVBQVNDLE1BQUssQ0FBQyxTQUFRTCxHQUFFLFNBQVEsUUFBUSxHQUFFTSxTQUFRLDhDQUE2QyxDQUFDO0FBQUEsRUFBRSxDQUFDO0FBQUUsTUFBR2QsVUFBUUMsT0FBT0ksS0FBSU0sU0FBUyxFQUFDQyxNQUFLLFVBQVNDLE1BQUssQ0FBQyxTQUFRLEdBQUUsU0FBUSxRQUFRLEdBQUVDLFNBQVEsOEJBQTZCLENBQUM7QUFBRSxDQUFDO0FBQ2xvQyxnQkFBU0MsY0FBYyxFQUFDQyxhQUFZQyxTQUFRQyxRQUFvRSxHQUFHO0FBQUFDLEtBQUE7QUFDdEgsUUFBTSxFQUFDQyxLQUFJLElBQUU3RCxTQUFTLEdBQUU4RCxXQUFTaEUsWUFBWSxnQkFBZSxFQUFDaUUsT0FBTSxFQUFDQyxRQUFPLFNBQVEsRUFBQyxDQUFDLEdBQUVDLFVBQVFwRSxPQUFPLHVCQUF1QixHQUFFcUUsU0FBT25FLFdBQVcsaUJBQWdCLENBQUMsY0FBYyxDQUFDO0FBQ2pMLFFBQU1vRSxVQUFRQSxPQUFpQixFQUFDM0IsV0FBVSxJQUFHQyxPQUFNLEVBQUNqQixRQUFPLEtBQUlDLFVBQVNvQyxLQUFLcEMsU0FBUSxHQUFFaUIsUUFBTyxFQUFDbEIsUUFBTyxLQUFJQyxVQUFTb0MsS0FBS3BDLFNBQVEsR0FBRWtCLGFBQVksR0FBRTtBQUNoSixRQUFNeUIsT0FBSzVFLFFBQXVCLEVBQUM2RSxlQUFjLEVBQUN6QyxZQUFXNkIsYUFBYTdCLGNBQVksVUFBU0ksVUFBU3lCLGFBQWF6QixZQUFVLElBQUdDLGVBQWNoQyxtQkFBbUIsb0JBQUlxRSxLQUFLLEdBQUVULEtBQUtVLFFBQVEsR0FBRWpDLE9BQU1tQixhQUFhbkIsU0FBTyxDQUFDNkIsUUFBUSxHQUFFQSxRQUFRLENBQUMsR0FBRWpDLFFBQU8sSUFBR0MsbUJBQWtCc0IsYUFBYWUsTUFBSSxLQUFJLEdBQUVDLFVBQVM5RSxZQUFZZ0MsTUFBTSxFQUFDLENBQUM7QUFBRWxDLFdBQVMsRUFBQ2lGLFNBQVFOLEtBQUtNLFFBQU8sQ0FBQztBQUM5VixRQUFNcEMsUUFBTTVDLGNBQWMsRUFBQ2dGLFNBQVFOLEtBQUtNLFNBQVFDLE1BQUssUUFBTyxDQUFDLEdBQUVDLE1BQUl6RixPQUE2QixJQUFJLEdBQUUwRixPQUFLekUsYUFBYWdFLEtBQUtVLFVBQVVDLE9BQU8sR0FBRUMsT0FBS1osS0FBS2EsTUFBTSxlQUFlLEdBQUVDLFNBQU9qQixRQUFRa0IsTUFBTUEsS0FBS0MsS0FBSyxDQUFBQyxNQUFHTCxRQUFNSyxFQUFFQyxhQUFXTixRQUFNSyxFQUFFRSxPQUFPO0FBQ3JQLFFBQU1DLFNBQU9wQixLQUFLcUIsYUFBYSxPQUFNNUMsV0FBUTtBQUFDLFFBQUdxQyxRQUFRUSxVQUFRLFFBQU87QUFBQ3RCLFdBQUt1QixTQUFTLGlCQUFnQixFQUFDcEMsU0FBUSxrREFBaUQsR0FBRSxFQUFDcUMsYUFBWSxLQUFJLENBQUM7QUFBRTtBQUFBLElBQU87QUFBQyxRQUFHO0FBQUMsWUFBTSxFQUFDekQsbUJBQWtCLEdBQUcwRCxLQUFJLElBQUVoRDtBQUFPLFlBQU1xQixPQUFPNEIsUUFBUSxFQUFDRCxNQUFLMUQsb0JBQWtCLEVBQUMsR0FBRzBELE1BQUsxRCxrQkFBaUIsSUFBRTBELEtBQUksQ0FBQztBQUFFLFVBQUdqQixJQUFJbUIsUUFBUTFGLGdCQUFldUUsSUFBSW1CLE9BQU87QUFBRXBDLGNBQVE7QUFBRUQsY0FBUTtBQUFBLElBQUUsUUFBTTtBQUFBLElBQUM7QUFBQSxFQUF5QyxDQUFDO0FBQzVhLFNBQU8sdUJBQUMsY0FBVyxNQUFJLE1BQUMsT0FBT0QsY0FBWSw2QkFBMkIsaUJBQWlCLFNBQWtCLE1BQU1TLE9BQU84QixTQUFTLFNBQVMsdUJBQUMsVUFBTyxNQUFLLFVBQVMsTUFBSyxrQkFBaUIsU0FBUSxhQUFZLFVBQVU5QixPQUFPOEIsV0FBUzlCLE9BQU8rQixZQUFZLHdCQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFILEdBQ3pQO0FBQUEsMkJBQUMsZUFBWSxPQUFPL0IsT0FBT2dDLFNBQU9wQyxTQUFTb0MsU0FBT2pDLFFBQVFpQyxTQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFBRSx1QkFBQyxjQUFXLFdBQVUsUUFBTyxJQUFHLGtCQUFpQixZQUFVLE1BQUMsS0FBSyxDQUFBQyxTQUFNO0FBQUN2QixVQUFJbUIsVUFBUUk7QUFBS3RCLFdBQUtzQixJQUFJO0FBQUEsSUFBRSxHQUFHLFVBQVVYLFFBQVEsb0JBQWtCLENBQUNwQixLQUFLVSxVQUFVQyxVQUFRLFNBQU9xQixRQUN2TzNDO0FBQUFBLHFCQUFhLHVCQUFDLFNBQU0sVUFBUyxRQUFPO0FBQUE7QUFBQSxRQUFVQSxZQUFZZTtBQUFBQSxRQUFHO0FBQUEsV0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzSjtBQUFBLE1BQ3BLLHVCQUFDLGFBQVUsT0FBTSx1QkFBc0IsR0FBSUosS0FBS2lDLFNBQVMsWUFBWSxHQUFHLFlBQVksRUFBQ0MsVUFBU0MsUUFBUTlDLFdBQVcsRUFBQyxHQUFHLE9BQU84QyxRQUFRbkMsS0FBS1UsVUFBVTBCLE9BQU81RSxVQUFVLEdBQUcsWUFBWXdDLEtBQUtVLFVBQVUwQixPQUFPNUUsWUFBWTJCLFdBQXJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNk47QUFBQSxNQUM3Tix1QkFBQyxhQUFVLE9BQU0scUJBQW9CLEdBQUlhLEtBQUtpQyxTQUFTLFVBQVUsR0FBRyxZQUFZLEVBQUNDLFVBQVNDLFFBQVE5QyxXQUFXLEVBQUMsR0FBRyxPQUFPOEMsUUFBUW5DLEtBQUtVLFVBQVUwQixPQUFPeEUsUUFBUSxHQUFHLFlBQVlvQyxLQUFLVSxVQUFVMEIsT0FBT3hFLFVBQVV1QixXQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFOO0FBQUEsTUFDck4sdUJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxpQkFBZ0IsR0FBSWEsS0FBS2lDLFNBQVMsZUFBZSxHQUFHLE9BQU9FLFFBQVFuQyxLQUFLVSxVQUFVMEIsT0FBT3ZFLGFBQWEsR0FBRyxZQUFZbUMsS0FBS1UsVUFBVTBCLE9BQU92RSxlQUFlc0IsV0FBdkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErTDtBQUFBLE1BQy9MLHVCQUFDLFNBQU0sVUFBVTJCLFFBQVFRLFVBQVEsU0FBTyxTQUFPLFdBQVlSLG1CQUFPQSxPQUFPUSxVQUFRLFNBQU8sTUFBTVIsT0FBT0ksU0FBUyxNQUFNSixPQUFPSyxPQUFPLGNBQVksTUFBTUwsT0FBT0ksU0FBUyxNQUFNSixPQUFPSyxPQUFPLGNBQVksK0RBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ1E7QUFBQSxNQUNoUSx1QkFBQyxrQkFBZSxPQUFNLHFCQUFvQixhQUFhekIsU0FBUzJDLGFBQWEsU0FBUzNDLFNBQVM0QyxTQUFTLE1BQU01QyxTQUFTNkMsZUFBZSxZQUFZN0MsU0FBUzhDLFlBQTNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0s7QUFBQSxNQUNuS3RFLE1BQU11RSxPQUFPQyxJQUFJLENBQUNDLE9BQU05RCxNQUFJLHVCQUFDLGtCQUE4QixVQUFTLG1CQUFrQixpQ0FBQyxjQUNwRjtBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU8sa0JBQWtCQSxJQUFFLENBQUMsSUFBSSxHQUFJbUIsS0FBS2lDLFNBQVMsU0FBU3BELENBQUMsWUFBWSxHQUFHLE9BQU9tQixLQUFLYSxNQUFNLFNBQVNoQyxDQUFDLFlBQVksR0FBRyxPQUFPc0QsUUFBUW5DLEtBQUtVLFVBQVUwQixPQUFPbEUsUUFBUVcsQ0FBQyxHQUFHVCxTQUFTLEdBQUcsWUFBWTRCLEtBQUtVLFVBQVUwQixPQUFPbEUsUUFBUVcsQ0FBQyxHQUFHVCxXQUFXZSxTQUFTO0FBQUEsaUNBQUMsWUFBUyxPQUFNLElBQUcsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFBWU8sU0FBU3FCLE1BQU1BLEtBQUsyQixJQUFJLENBQUFFLE1BQUcsdUJBQUMsWUFBb0IsT0FBT0EsRUFBRXhDLElBQUt3QztBQUFBQSxjQUFFM0Q7QUFBQUEsWUFBSztBQUFBLFlBQUkyRCxFQUFFckM7QUFBQUEsZUFBakNxQyxFQUFFeEMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQsQ0FBVztBQUFBLGFBQS9ZO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaVo7QUFBQSxRQUMvWSxDQUFDLFNBQVEsUUFBUSxFQUFZc0MsSUFBSSxDQUFBRyxTQUFNLHVCQUFDLGFBQXFCLE9BQU8sR0FBR0EsU0FBTyxVQUFRLE9BQUssSUFBSSxTQUFTaEUsSUFBRSxDQUFDLElBQUksR0FBSW1CLEtBQUtpQyxTQUFTLFNBQVNwRCxDQUFDLElBQUlnRSxJQUFJLFNBQVMsR0FBRyxPQUFPVixRQUFRbkMsS0FBS1UsVUFBVTBCLE9BQU9sRSxRQUFRVyxDQUFDLElBQUlnRSxJQUFJLEdBQUd6RixNQUFNLEdBQUcsWUFBWTRDLEtBQUtVLFVBQVUwQixPQUFPbEUsUUFBUVcsQ0FBQyxJQUFJZ0UsSUFBSSxHQUFHekYsUUFBUStCLFNBQVMsWUFBWSxFQUFDMkQsV0FBVSxVQUFTLEtBQWpSRCxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1TLENBQUU7QUFBQSxRQUM5VSx1QkFBQyxhQUFVLE9BQU8sa0JBQWtCaEUsSUFBRSxDQUFDLElBQUksR0FBSW1CLEtBQUtpQyxTQUFTLFNBQVNwRCxDQUFDLGNBQWMsR0FBRyxPQUFPc0QsUUFBUW5DLEtBQUtVLFVBQVUwQixPQUFPbEUsUUFBUVcsQ0FBQyxHQUFHTixXQUFXLEdBQUcsWUFBWXlCLEtBQUtVLFVBQVUwQixPQUFPbEUsUUFBUVcsQ0FBQyxHQUFHTixhQUFhWSxXQUFsTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBOO0FBQUEsUUFBRSx1QkFBQyxVQUFPLFVBQVVqQixNQUFNdUUsT0FBT00sVUFBUSxHQUFHLFNBQVMsTUFBSTdFLE1BQU04RSxPQUFPbkUsQ0FBQyxHQUFHO0FBQUE7QUFBQSxVQUFTQSxJQUFFO0FBQUEsYUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFdBSDlOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJdkYsS0FKa0Q4RCxNQUFNdkMsSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUloQixDQUFpQjtBQUFBLE1BQzdCSixLQUFLVSxVQUFVMEIsT0FBT2xFLE9BQU9pQixXQUFTLHVCQUFDLFNBQU0sVUFBUyxTQUFTYSxlQUFLVSxVQUFVMEIsT0FBT2xFLE1BQU1pQixXQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFBUyx1QkFBQyxVQUFPLFNBQVMsTUFBSWpCLE1BQU0rRSxPQUFPbEQsUUFBUSxDQUFDLEdBQUcseUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUNwSyx1QkFBQyxhQUFVLE9BQU0sU0FBUSxHQUFJQyxLQUFLaUMsU0FBUyxRQUFRLEdBQUcsT0FBT0UsUUFBUW5DLEtBQUtVLFVBQVUwQixPQUFPdEUsTUFBTSxHQUFHLFlBQVlrQyxLQUFLVSxVQUFVMEIsT0FBT3RFLFFBQVFxQixXQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNKO0FBQUEsU0FieEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNsRTtBQUFBLE9BZkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCUDtBQUNKO0FBQUNLLEdBdkJlSixlQUFhO0FBQUEsVUFDWnhELFVBQW9CRixhQUE4REQsUUFBdUNFLFlBRTNIUCxTQUFvVEMsVUFDblRDLGVBQStGVSxZQUFZO0FBQUE7QUFBQSxLQUozR29EO0FBQWEsSUFBQThEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVJlZiIsIkFsZXJ0IiwiQnV0dG9uIiwiTWVudUl0ZW0iLCJUZXh0RmllbGQiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJ1c2VGaWVsZEFycmF5Iiwiem9kUmVzb2x2ZXIiLCJ6IiwidXNlQXBpIiwidXNlUGFnZWRBcGkiLCJ1c2VDb21tYW5kIiwidXNlU2NvcGUiLCJkYXRlT25seUluVGltZXpvbmUiLCJpc1ZhbGlkRGF0ZU9ubHkiLCJjb2RlUG9pbnRMZW5ndGgiLCJ1c2VEcmFmdEZvcm0iLCJtYXJrRHJhZnRDbGVhbiIsIkZvcm1GaWVsZHMiLCJTdXJmYWNlQ29udGVudCIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkxvb2t1cExvYWRNb3JlIiwiZXhhY3QiLCJzdHJpbmciLCJyZWdleCIsInVuaXRzIiwidmFsdWUiLCJ3aG9sZSIsImZyYWN0aW9uIiwic3BsaXQiLCJ0ZXN0IiwiQmlnSW50IiwicGFkRW5kIiwibW9uZXkiLCJvYmplY3QiLCJhbW91bnQiLCJjdXJyZW5jeSIsIm1pbiIsInNjaGVtYSIsInNvdXJjZVR5cGUiLCJyZWZpbmUiLCJ2IiwidHJpbSIsInNvdXJjZUlkIiwiZWZmZWN0aXZlRGF0ZSIsInJlYXNvbiIsInJlcGxhY2VzSm91cm5hbElkIiwibnVsbGFibGUiLCJvcHRpb25hbCIsImxpbmVzIiwiYXJyYXkiLCJhY2NvdW50SWQiLCJkZWJpdCIsImNyZWRpdCIsImRlc2NyaXB0aW9uIiwic3VwZXJSZWZpbmUiLCJ2YWx1ZXMiLCJjdHgiLCJmb3JFYWNoIiwibCIsImkiLCJkIiwiYyIsImFkZElzc3VlIiwiY29kZSIsInBhdGgiLCJtZXNzYWdlIiwiSm91cm5hbEVkaXRvciIsInJlcGxhY2VtZW50Iiwib25DbG9zZSIsIm9uU2F2ZWQiLCJfcyIsInNob3AiLCJhY2NvdW50cyIsInF1ZXJ5Iiwic3RhdHVzIiwicGVyaW9kcyIsImNyZWF0ZSIsIm5ld0xpbmUiLCJmb3JtIiwiZGVmYXVsdFZhbHVlcyIsIkRhdGUiLCJ0aW1lem9uZSIsImlkIiwicmVzb2x2ZXIiLCJjb250cm9sIiwibmFtZSIsInJlZiIsImJpbmQiLCJmb3JtU3RhdGUiLCJpc0RpcnR5IiwiZGF0ZSIsIndhdGNoIiwicGVyaW9kIiwiZGF0YSIsImZpbmQiLCJwIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsInN1Ym1pdCIsImhhbmRsZVN1Ym1pdCIsInN0YXRlIiwic2V0RXJyb3IiLCJzaG91bGRGb2N1cyIsImJvZHkiLCJleGVjdXRlIiwiY3VycmVudCIsInBlbmRpbmciLCJ1bnJlc29sdmVkIiwiZXJyb3IiLCJub2RlIiwidW5kZWZpbmVkIiwicmVnaXN0ZXIiLCJyZWFkT25seSIsIkJvb2xlYW4iLCJlcnJvcnMiLCJsb2FkZWRDb3VudCIsImhhc01vcmUiLCJpc0xvYWRpbmdNb3JlIiwibG9hZE1vcmUiLCJmaWVsZHMiLCJtYXAiLCJmaWVsZCIsImEiLCJzaWRlIiwiaW5wdXRNb2RlIiwibGVuZ3RoIiwicmVtb3ZlIiwiYXBwZW5kIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiam91cm5hbC1lZGl0b3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlUmVmfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7QWxlcnQsQnV0dG9uLE1lbnVJdGVtLFRleHRGaWVsZH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCB7dXNlRm9ybSx1c2VXYXRjaCx1c2VGaWVsZEFycmF5fSBmcm9tICdyZWFjdC1ob29rLWZvcm0nO1xyXG5pbXBvcnQge3pvZFJlc29sdmVyfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCc7XHJcbmltcG9ydCB7en0gZnJvbSAnem9kJztcclxuaW1wb3J0IHR5cGUge0pvdXJuYWwsSm91cm5hbExpbmUsSm91cm5hbENyZWF0ZX0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7dXNlQXBpLHVzZVBhZ2VkQXBpLHVzZUNvbW1hbmR9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7dXNlU2NvcGV9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcclxuaW1wb3J0IHtkYXRlT25seUluVGltZXpvbmUsaXNWYWxpZERhdGVPbmx5LGNvZGVQb2ludExlbmd0aH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHt1c2VEcmFmdEZvcm0sbWFya0RyYWZ0Q2xlYW59IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XHJcbmltcG9ydCB7Rm9ybUZpZWxkcyxTdXJmYWNlQ29udGVudH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQge0VkaXREaWFsb2csRXJyb3JOb3RpY2UsTG9va3VwTG9hZE1vcmV9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xyXG5jb25zdCBleGFjdD16LnN0cmluZygpLnJlZ2V4KC9eXFxkKyhcXC5cXGR7MSw0fSk/JC8sJ05o4bqtcCBz4buRIGtow7RuZyDDom0sIHThu5FpIMSRYSA0IGNo4buvIHPhu5EgdGjhuq1wIHBow6JuLicpO1xyXG5jb25zdCB1bml0cz0odmFsdWU6c3RyaW5nKT0+e2NvbnN0IFt3aG9sZT0nJyxmcmFjdGlvbj0nJ109dmFsdWUuc3BsaXQoJy4nKTtyZXR1cm4gL15cXGQrKFxcLlxcZHsxLDR9KT8kLy50ZXN0KHZhbHVlKT9CaWdJbnQod2hvbGUpKjEwMDAwbitCaWdJbnQoZnJhY3Rpb24ucGFkRW5kKDQsJzAnKSk6MG47fTtcclxuY29uc3QgbW9uZXk9ei5vYmplY3Qoe2Ftb3VudDpleGFjdCxjdXJyZW5jeTp6LnN0cmluZygpLm1pbigxKX0pO1xyXG5jb25zdCBzY2hlbWE9ei5vYmplY3Qoe3NvdXJjZVR5cGU6ei5zdHJpbmcoKS5yZWZpbmUodj0+Y29kZVBvaW50TGVuZ3RoKHYpPD0xMDAsJ0xv4bqhaSBuZ3Xhu5NuIHThu5FpIMSRYSAxMDAga8O9IHThu7EuJykudHJpbSgpLm1pbigxLCdOaOG6rXAgbG/huqFpIG5ndeG7k24uJyksc291cmNlSWQ6ei5zdHJpbmcoKS5yZWdleCgvXltBLVphLXowLTlfLV0rJC8sJ03DoyBuZ3Xhu5NuIGNo4buJIGfhu5NtIGNo4buvL3Phu5EsIGfhuqFjaCBuZ2FuZyB2w6AgZ+G6oWNoIGTGsOG7m2kuJyksZWZmZWN0aXZlRGF0ZTp6LnN0cmluZygpLnJlZmluZShpc1ZhbGlkRGF0ZU9ubHksJ0No4buNbiBuZ8OgeSBo4bujcCBs4buHLicpLHJlYXNvbjp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTEwMDAsJ0zDvSBkbyB04buRaSDEkWEgMS4wMDAga8O9IHThu7EuJykudHJpbSgpLm1pbig1LCdMw70gZG8gY+G6p24gw610IG5o4bqldCA1IGvDvSB04buxLicpLHJlcGxhY2VzSm91cm5hbElkOnouc3RyaW5nKCkubnVsbGFibGUoKS5vcHRpb25hbCgpLGxpbmVzOnouYXJyYXkoei5vYmplY3Qoe2FjY291bnRJZDp6LnN0cmluZygpLm1pbigxLCdDaOG7jW4gdMOgaSBraG/huqNuLicpLGRlYml0Om1vbmV5LGNyZWRpdDptb25leSxkZXNjcmlwdGlvbjp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTMwMCwnRGnhu4VuIGdp4bqjaSB04buRaSDEkWEgMzAwIGvDvSB04buxLicpLnRyaW0oKS5taW4oMSwnTmjhuq1wIGRp4buFbiBnaeG6o2kuJyl9KSkubWluKDIsJ0LDunQgdG/DoW4gY+G6p24gw610IG5o4bqldCBoYWkgZMOybmcuJyl9KS5zdXBlclJlZmluZSgodmFsdWVzLGN0eCk9PntsZXQgZGViaXQ9MG4sY3JlZGl0PTBuO3ZhbHVlcy5saW5lcy5mb3JFYWNoKChsLGkpPT57Y29uc3QgZD11bml0cyhsLmRlYml0LmFtb3VudCksYz11bml0cyhsLmNyZWRpdC5hbW91bnQpO2RlYml0Kz1kO2NyZWRpdCs9YztpZigoZD4wbik9PT0oYz4wbikpY3R4LmFkZElzc3VlKHtjb2RlOidjdXN0b20nLHBhdGg6WydsaW5lcycsaSwnZGViaXQnLCdhbW91bnQnXSxtZXNzYWdlOidN4buXaSBkw7JuZyBj4bqnbiDEkcO6bmcgbeG7mXQgYsOqbiBO4bujIGhv4bq3YyBDw7MgZMawxqFuZy4nfSk7fSk7aWYoZGViaXQhPT1jcmVkaXQpY3R4LmFkZElzc3VlKHtjb2RlOidjdXN0b20nLHBhdGg6WydsaW5lcycsMCwnZGViaXQnLCdhbW91bnQnXSxtZXNzYWdlOidU4buVbmcgTuG7oyB2w6AgQ8OzIGPhuqduIGPDom4gYuG6sW5nLid9KTt9KTtcclxuZXhwb3J0IGZ1bmN0aW9uIEpvdXJuYWxFZGl0b3Ioe3JlcGxhY2VtZW50LG9uQ2xvc2Usb25TYXZlZH06e3JlcGxhY2VtZW50OkpvdXJuYWx8bnVsbDtvbkNsb3NlOigpPT52b2lkO29uU2F2ZWQ6KCk9PnZvaWR9KSB7XHJcbiAgICBjb25zdCB7c2hvcH09dXNlU2NvcGUoKSxhY2NvdW50cz11c2VQYWdlZEFwaSgnbGlzdEFjY291bnRzJyx7cXVlcnk6e3N0YXR1czonYWN0aXZlJ319KSxwZXJpb2RzPXVzZUFwaSgnbGlzdEFjY291bnRpbmdQZXJpb2RzJyksY3JlYXRlPXVzZUNvbW1hbmQoJ2NyZWF0ZUpvdXJuYWwnLFsnbGlzdEpvdXJuYWxzJ10pO1xyXG4gICAgY29uc3QgbmV3TGluZT0oKTpKb3VybmFsTGluZT0+KHthY2NvdW50SWQ6JycsZGViaXQ6e2Ftb3VudDonMCcsY3VycmVuY3k6c2hvcC5jdXJyZW5jeX0sY3JlZGl0OnthbW91bnQ6JzAnLGN1cnJlbmN5OnNob3AuY3VycmVuY3l9LGRlc2NyaXB0aW9uOicnfSk7XHJcbiAgICBjb25zdCBmb3JtPXVzZUZvcm08Sm91cm5hbENyZWF0ZT4oe2RlZmF1bHRWYWx1ZXM6e3NvdXJjZVR5cGU6cmVwbGFjZW1lbnQ/LnNvdXJjZVR5cGV8fCdtYW51YWwnLHNvdXJjZUlkOnJlcGxhY2VtZW50Py5zb3VyY2VJZHx8JycsZWZmZWN0aXZlRGF0ZTpkYXRlT25seUluVGltZXpvbmUobmV3IERhdGUoKSxzaG9wLnRpbWV6b25lKSxsaW5lczpyZXBsYWNlbWVudD8ubGluZXN8fFtuZXdMaW5lKCksbmV3TGluZSgpXSxyZWFzb246JycscmVwbGFjZXNKb3VybmFsSWQ6cmVwbGFjZW1lbnQ/LmlkfHxudWxsfSxyZXNvbHZlcjp6b2RSZXNvbHZlcihzY2hlbWEpfSk7dXNlV2F0Y2goe2NvbnRyb2w6Zm9ybS5jb250cm9sfSk7XHJcbiAgICBjb25zdCBsaW5lcz11c2VGaWVsZEFycmF5KHtjb250cm9sOmZvcm0uY29udHJvbCxuYW1lOidsaW5lcyd9KSxyZWY9dXNlUmVmPEhUTUxGb3JtRWxlbWVudHxudWxsPihudWxsKSxiaW5kPXVzZURyYWZ0Rm9ybShmb3JtLmZvcm1TdGF0ZS5pc0RpcnR5KSxkYXRlPWZvcm0ud2F0Y2goJ2VmZmVjdGl2ZURhdGUnKSxwZXJpb2Q9cGVyaW9kcy5kYXRhPy5kYXRhLmZpbmQocD0+ZGF0ZT49cC5zdGFydERhdGUmJmRhdGU8PXAuZW5kRGF0ZSk7XHJcbiAgICBjb25zdCBzdWJtaXQ9Zm9ybS5oYW5kbGVTdWJtaXQoYXN5bmMgdmFsdWVzPT57aWYocGVyaW9kPy5zdGF0ZSE9PSdvcGVuJyl7Zm9ybS5zZXRFcnJvcignZWZmZWN0aXZlRGF0ZScse21lc3NhZ2U6J05nw6B5IGhp4buHdSBs4buxYyBj4bqnbiBu4bqxbSB0cm9uZyBr4buzIGvhur8gdG/DoW4gxJFhbmcgbeG7ny4nfSx7c2hvdWxkRm9jdXM6dHJ1ZX0pO3JldHVybjt9dHJ5e2NvbnN0IHtyZXBsYWNlc0pvdXJuYWxJZCwuLi5ib2R5fT12YWx1ZXM7YXdhaXQgY3JlYXRlLmV4ZWN1dGUoe2JvZHk6cmVwbGFjZXNKb3VybmFsSWQ/ey4uLmJvZHkscmVwbGFjZXNKb3VybmFsSWR9OmJvZHl9KTtpZihyZWYuY3VycmVudCltYXJrRHJhZnRDbGVhbihyZWYuY3VycmVudCk7b25TYXZlZCgpO29uQ2xvc2UoKTt9Y2F0Y2h7LyogRHJhZnQgYW5kIHJlY292ZXJ5IHJlbWFpbiB2aXNpYmxlLiAqL319KTtcclxuICAgIHJldHVybiA8RWRpdERpYWxvZyBvcGVuIHRpdGxlPXtyZXBsYWNlbWVudD8nVGhheSB0aOG6vyBiw7p0IHRvw6FuIMSRw6MgxJHhuqNvJzonQsO6dCB0b8OhbiBuaMOhcCd9IG9uQ2xvc2U9e29uQ2xvc2V9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwiam91cm5hbC1jcmVhdGVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e2NyZWF0ZS5wZW5kaW5nfHxjcmVhdGUudW5yZXNvbHZlZH0+TMawdSBuaMOhcDwvQnV0dG9uPn0+XHJcbiAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3J8fGFjY291bnRzLmVycm9yfHxwZXJpb2RzLmVycm9yfS8+PEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIGlkPVwiam91cm5hbC1jcmVhdGVcIiBub1ZhbGlkYXRlIHJlZj17bm9kZT0+e3JlZi5jdXJyZW50PW5vZGU7YmluZChub2RlKTt9fSBvblN1Ym1pdD17c3VibWl0fSBkYXRhLWRyYWZ0LWNsZWFuPXshZm9ybS5mb3JtU3RhdGUuaXNEaXJ0eT8ndHJ1ZSc6dW5kZWZpbmVkfT5cclxuICAgICAgICAgICAge3JlcGxhY2VtZW50JiY8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VGhheSB0aOG6vyB7cmVwbGFjZW1lbnQuaWR9IHNhdSDEkeG6o287IGdp4buvIG5ndXnDqm4gbmd14buTbiB2w6AgbOG7i2NoIHPhu60uIEFQSSBraeG7g20gcmV2aXNpb24gbeG7m2ksIHBoacOqbiBi4bqjbiB0w6BpIGtob+G6o24gdsOgIGvhu7MgdHLGsOG7m2Mga2hpIGdoaS48L0FsZXJ0Pn1cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkxv4bqhaSBjaOG7qW5nIHThu6sgbmd14buTblwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdzb3VyY2VUeXBlJyl9IElucHV0UHJvcHM9e3tyZWFkT25seTpCb29sZWFuKHJlcGxhY2VtZW50KX19IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5zb3VyY2VUeXBlKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLnNvdXJjZVR5cGU/Lm1lc3NhZ2V9Lz5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk3DoyBjaOG7qW5nIHThu6sgbmd14buTblwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdzb3VyY2VJZCcpfSBJbnB1dFByb3BzPXt7cmVhZE9ubHk6Qm9vbGVhbihyZXBsYWNlbWVudCl9fSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuc291cmNlSWQpfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuc291cmNlSWQ/Lm1lc3NhZ2V9Lz5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwiTmfDoHkgaGnhu4d1IGzhu7FjXCIgey4uLmZvcm0ucmVnaXN0ZXIoJ2VmZmVjdGl2ZURhdGUnKX0gZXJyb3I9e0Jvb2xlYW4oZm9ybS5mb3JtU3RhdGUuZXJyb3JzLmVmZmVjdGl2ZURhdGUpfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMuZWZmZWN0aXZlRGF0ZT8ubWVzc2FnZX0vPlxyXG4gICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9e3BlcmlvZD8uc3RhdGU9PT0nb3Blbic/J2luZm8nOid3YXJuaW5nJ30+e3BlcmlvZD9wZXJpb2Quc3RhdGU9PT0nb3Blbic/YEvhu7MgJHtwZXJpb2Quc3RhcnREYXRlfSDigJMgJHtwZXJpb2QuZW5kRGF0ZX0gxJFhbmcgbeG7ny5gOmBL4buzICR7cGVyaW9kLnN0YXJ0RGF0ZX0g4oCTICR7cGVyaW9kLmVuZERhdGV9IMSRw6Mga2jDs2EuYDonQ2jGsGEgY8OzIGvhu7MgbeG7nyBjaG8gbmfDoHkgbsOgeTsgdOG6oW8ga+G7syB04bqhaSBDw7RuZyBu4bujICYga2jDs2Ega+G7sy4nfTwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cInTDoGkga2hv4bqjbiBr4bq/IHRvw6FuXCIgbG9hZGVkQ291bnQ9e2FjY291bnRzLmxvYWRlZENvdW50fSBoYXNNb3JlPXthY2NvdW50cy5oYXNNb3JlfSBidXN5PXthY2NvdW50cy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXthY2NvdW50cy5sb2FkTW9yZX0vPlxyXG4gICAgICAgICAgICB7bGluZXMuZmllbGRzLm1hcCgoZmllbGQsaSk9PjxTdXJmYWNlQ29udGVudCBrZXk9e2ZpZWxkLmlkfSBib2R5TW9kZT1cImNvbXBhY3RPdXRsaW5lZFwiPjxGb3JtRmllbGRzPlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9e2BUw6BpIGtob+G6o24gZMOybmcgJHtpKzF9YH0gey4uLmZvcm0ucmVnaXN0ZXIoYGxpbmVzLiR7aX0uYWNjb3VudElkYCl9IHZhbHVlPXtmb3JtLndhdGNoKGBsaW5lcy4ke2l9LmFjY291bnRJZGApfSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnMubGluZXM/LltpXT8uYWNjb3VudElkKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmxpbmVzPy5baV0/LmFjY291bnRJZD8ubWVzc2FnZX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+Q2jhu41uIHTDoGkga2hv4bqjbjwvTWVudUl0ZW0+e2FjY291bnRzLmRhdGE/LmRhdGEubWFwKGE9PjxNZW51SXRlbSBrZXk9e2EuaWR9IHZhbHVlPXthLmlkfT57YS5jb2RlfSDCtyB7YS5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgIHsoWydkZWJpdCcsJ2NyZWRpdCddIGFzIGNvbnN0KS5tYXAoc2lkZT0+PFRleHRGaWVsZCBrZXk9e3NpZGV9IGxhYmVsPXtgJHtzaWRlPT09J2RlYml0Jz8nTuG7oyc6J0PDsyd9IGTDsm5nICR7aSsxfWB9IHsuLi5mb3JtLnJlZ2lzdGVyKGBsaW5lcy4ke2l9LiR7c2lkZX0uYW1vdW50YCl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5bc2lkZV0/LmFtb3VudCl9IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5bc2lkZV0/LmFtb3VudD8ubWVzc2FnZX0gaW5wdXRQcm9wcz17e2lucHV0TW9kZTonZGVjaW1hbCd9fS8+KX1cclxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9e2BEaeG7hW4gZ2nhuqNpIGTDsm5nICR7aSsxfWB9IHsuLi5mb3JtLnJlZ2lzdGVyKGBsaW5lcy4ke2l9LmRlc2NyaXB0aW9uYCl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5kZXNjcmlwdGlvbil9IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8uW2ldPy5kZXNjcmlwdGlvbj8ubWVzc2FnZX0vPjxCdXR0b24gZGlzYWJsZWQ9e2xpbmVzLmZpZWxkcy5sZW5ndGg8PTJ9IG9uQ2xpY2s9eygpPT5saW5lcy5yZW1vdmUoaSl9PkLhu48gZMOybmcge2krMX08L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPjwvU3VyZmFjZUNvbnRlbnQ+KX1cclxuICAgICAgICAgICAge2Zvcm0uZm9ybVN0YXRlLmVycm9ycy5saW5lcz8ubWVzc2FnZSYmPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIj57Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmxpbmVzLm1lc3NhZ2V9PC9BbGVydD59PEJ1dHRvbiBvbkNsaWNrPXsoKT0+bGluZXMuYXBwZW5kKG5ld0xpbmUoKSl9PlRow6ptIGTDsm5nPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG9cIiB7Li4uZm9ybS5yZWdpc3RlcigncmVhc29uJyl9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5yZWFzb24pfSBoZWxwZXJUZXh0PXtmb3JtLmZvcm1TdGF0ZS5lcnJvcnMucmVhc29uPy5tZXNzYWdlfS8+XHJcbiAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgPC9FZGl0RGlhbG9nPjtcclxufVxyXG4iXSwiZmlsZSI6Ii9ob21lL3J1bm5lci93b3JrL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9maW5hbmNlL2pvdXJuYWwtZWRpdG9yLnRzeCJ9