import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/statement-import.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react.js?v=f9568e8d"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Alert, Button, MenuItem, TextField } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/@mui_material.js?v=f9568e8d";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { codePointLength, dateTime } from "/src/shared/model/format.ts";
import { FormFields } from "/src/shared/ui/composition.tsx";
import { DataTable, EditDialog, ErrorNotice, QueryState, RouteLink } from "/src/shared/ui/components.tsx";
export function StatementDialog({ onClose }) {
  _s();
  const { shop } = useScope(), formats = useApi("listStatementFormats");
  const upload = useCommand("uploadFile", []), previewCommand = useCommand("previewStatementImport", []), bank = useCommand("importBankStatement", ["listBankTransactions", "listReconciliationCases"]), cod = useCommand("importCODStatement", ["listCODSettlements"]);
  const [kind, setKind] = useState("bank"), [file, setFile] = useState(null), [resource, setResource] = useState(""), [batch, setBatch] = useState(""), [formatId, setFormat] = useState("botsales-csv-v1"), [fileId, setFileId] = useState(""), [preview, setPreview] = useState(null), [jobId, setJob] = useState(""), [error, setError] = useState(""), [draftCommit, setDraftCommit] = useState();
  const input = useRef(null), form = useRef(null), bind = useDraftForm(!jobId && Boolean(file || resource || batch));
  const descriptor = formats.data?.data.find((f) => f.kind === kind && f.formatId === formatId), busy = upload.pending || previewCommand.pending || bank.pending || cod.pending;
  const blocked = upload.unresolved || previewCommand.unresolved || bank.unresolved || cod.unresolved;
  const valid = Boolean(descriptor && file && descriptor.resourceOptions.some((r) => r.id === resource) && batch.trim() && codePointLength(batch) <= 200 && file.size > 0 && file.size <= descriptor.maxBytes && ["text/csv", "application/vnd.ms-excel"].includes(file.type));
  const clearPreview = () => {
    setPreview(null);
    setError("");
  };
  const prepare = async () => {
    if (!valid || !file || !descriptor || busy || blocked) {
      setError("Chọn CSV đúng loại/dung lượng, tài khoản hoặc đơn vị vận chuyển và mã đợt 1–200 ký tự.");
      return;
    }
    try {
      let id = fileId;
      if (!id) {
        const fd = new FormData();
        fd.append("purpose", kind === "bank" ? "bank_statement" : "cod_statement");
        fd.append("resourceId", resource);
        fd.append("file", file);
        const result2 = await upload.execute({ form: fd });
        if (result2.data.status !== "ready") {
          setError("Tệp chưa qua kiểm tra; chưa được xem trước hoặc nhập.");
          return;
        }
        id = result2.data.id;
        setFileId(id);
      }
      const result = await previewCommand.execute({ body: { fileId: id, accountOrCarrierId: resource, formatId, sourceBatchId: batch } });
      setPreview(result.data);
      setError("");
    } catch {
    }
  };
  const commit = async () => {
    if (!preview || !preview.validRows || busy || blocked) return;
    try {
      const body = { fileId: preview.fileId, accountOrCarrierId: preview.accountOrCarrierId, formatId: preview.formatId, sourceBatchId: preview.sourceBatchId, validationToken: preview.validationToken };
      const result = kind === "bank" ? await bank.execute({ body }) : await cod.execute({ body });
      setJob(result.data.id);
      if (form.current) markDraftClean(form.current);
      setDraftCommit((p) => ({ scope: null, sequence: (p?.sequence || 0) + 1 }));
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: "Nhập bảng đối soát", onClose, busy, draftCommit, actions: jobId ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Xem kết quả nhập" }, void 0, false, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
    lineNumber: 46,
    columnNumber: 127
  }, this) : preview ? /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: busy || blocked || preview.validRows === 0, onClick: () => void commit(), children: "Nhập các dòng hợp lệ" }, void 0, false, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
    lineNumber: 46,
    columnNumber: 214
  }, this) : /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "statement-import", variant: "contained", disabled: busy || blocked, children: "Xem trước bảng đối soát" }, void 0, false, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
    lineNumber: 46,
    columnNumber: 358
  }, this), children: [
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: upload.error || previewCommand.error || bank.error || cod.error }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: error }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
      lineNumber: 47,
      columnNumber: 106
    }, this),
    jobId ? /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã nhận kết quả nhập. Đối soát và ghi sổ vẫn cần thực hiện theo chứng từ; kiểm chi tiết dòng lỗi tại kết quả nhập." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
      lineNumber: 48,
      columnNumber: 18
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: formats, children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "statement-import", noValidate: true, ref: (node) => {
      form.current = node;
      bind(node);
    }, "data-draft-clean": jobId ? "true" : void 0, onSubmit: (e) => {
      e.preventDefault();
      void prepare();
    }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Loại bảng", value: kind, onChange: (e) => {
        setKind(e.target.value === "cod" ? "cod" : "bank");
        setResource("");
        setFileId("");
        clearPreview();
      }, children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "bank", children: "Ngân hàng" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 49,
          columnNumber: 179
        }, this),
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "cod", children: "COD" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 49,
          columnNumber: 222
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Định dạng CSV", value: formatId, onChange: (e) => {
        setFormat(e.target.value);
        clearPreview();
      }, children: formats.data?.data.filter((f) => f.kind === kind).map((f) => /* @__PURE__ */ jsxDEV(MenuItem, { value: f.formatId, children: f.name }, f.id, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 50,
        columnNumber: 194
      }, this)) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 50,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Tài khoản / đơn vị vận chuyển", value: resource, onChange: (e) => {
        setResource(e.target.value);
        setFileId("");
        clearPreview();
      }, children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn nguồn đối soát" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 51,
          columnNumber: 164
        }, this),
        descriptor?.resourceOptions.map((r) => /* @__PURE__ */ jsxDEV(MenuItem, { value: r.id, children: r.label }, r.id, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 51,
          columnNumber: 253
        }, this))
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", onClick: () => input.current?.click(), children: file ? file.name : "Chọn CSV" }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("input", { ref: input, hidden: true, type: "file", accept: ".csv,text/csv", "aria-label": "Tệp CSV", onChange: (e) => {
        setFile(e.target.files?.[0] || null);
        setFileId("");
        clearPreview();
      } }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 52,
        columnNumber: 119
      }, this),
      descriptor && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
        "CSV tối đa ",
        descriptor.maxBytes,
        " byte / ",
        descriptor.maxRows,
        " dòng. Cột bắt buộc: ",
        descriptor.requiredColumns.join(", "),
        ". ",
        /* @__PURE__ */ jsxDEV("a", { href: `/samples/${kind === "bank" ? "bank-transactions" : "cod-settlements"}.csv`, download: true, children: "Tải CSV mẫu" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 53,
          columnNumber: 173
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 53,
        columnNumber: 28
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { label: "Mã đợt nhập duy nhất", value: batch, onChange: (e) => {
        setBatch(e.target.value);
        clearPreview();
      }, helperText: "1–200 ký tự. Nguồn lặp sẽ có lỗi theo từng dòng, không tạo tiền hoặc chứng từ trùng." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      preview && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: preview.invalidRows ? "warning" : "success", children: [
          preview.validRows,
          " dòng hợp lệ · ",
          preview.invalidRows,
          " dòng lỗi. Kiểm lại trước khi nhập; token xem trước hết hạn lúc ",
          dateTime(preview.expiresAt, shop.timezone),
          "."
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 55,
          columnNumber: 27
        }, this),
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Xem trước bảng đối soát", rows: preview.rows, rowKey: (r) => String(r.row), columns: [{ key: "row", label: "Dòng CSV", render: (r) => r.row }, { key: "values", label: "Dữ liệu", render: (r) => Object.entries(r.values).map(([key, value]) => `${key}: ${value}`).join(" · ") }, { key: "errors", label: "Kiểm dữ liệu", render: (r) => r.errors.join("; ") || "Hợp lệ" }] }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 55,
          columnNumber: 261
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => void prepare(), disabled: busy || blocked, children: "Kiểm tra lại CSV" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
          lineNumber: 55,
          columnNumber: 646
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
        lineNumber: 55,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
      lineNumber: 48,
      columnNumber: 211
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
      lineNumber: 48,
      columnNumber: 183
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
}
_s(StatementDialog, "MWdxRp6P9iBszmg32gVWNtZAkgM=", false, function() {
  return [useScope, useApi, useCommand, useCommand, useCommand, useCommand, useDraftForm];
});
_c = StatementDialog;
var _c;
$RefreshReg$(_c, "StatementDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/statement-import.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEI4SCxTQVN4RyxVQVR3Rzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQjlILFNBQVFBLFFBQU9DLGdCQUFlO0FBQzlCLFNBQVFDLE9BQU1DLFFBQU9DLFVBQVNDLGlCQUFnQjtBQUU5QyxTQUFRQyxRQUFPQyxrQkFBaUI7QUFDaEMsU0FBUUMsZ0JBQWU7QUFDdkIsU0FBUUMsY0FBYUMsc0JBQXFCO0FBQzFDLFNBQVFDLGlCQUFnQkMsZ0JBQWU7QUFDdkMsU0FBUUMsa0JBQWlCO0FBQ3pCLFNBQVFDLFdBQVVDLFlBQVdDLGFBQVlDLFlBQVdDLGlCQUFnQjtBQUU3RCxnQkFBU0MsZ0JBQWdCLEVBQUNDLFFBQTBCLEdBQUc7QUFBQUMsS0FBQTtBQUMxRCxRQUFNLEVBQUNDLEtBQUksSUFBRWQsU0FBUyxHQUFFZSxVQUFRakIsT0FBTyxzQkFBc0I7QUFDN0QsUUFBTWtCLFNBQU9qQixXQUFXLGNBQWEsRUFBRSxHQUFFa0IsaUJBQWVsQixXQUFXLDBCQUF5QixFQUFFLEdBQUVtQixPQUFLbkIsV0FBVyx1QkFBc0IsQ0FBQyx3QkFBdUIseUJBQXlCLENBQUMsR0FBRW9CLE1BQUlwQixXQUFXLHNCQUFxQixDQUFDLG9CQUFvQixDQUFDO0FBQ3BQLFFBQU0sQ0FBQ3FCLE1BQUtDLE9BQU8sSUFBRTVCLFNBQXVCLE1BQU0sR0FBRSxDQUFDNkIsTUFBS0MsT0FBTyxJQUFFOUIsU0FBb0IsSUFBSSxHQUFFLENBQUMrQixVQUFTQyxXQUFXLElBQUVoQyxTQUFTLEVBQUUsR0FBRSxDQUFDaUMsT0FBTUMsUUFBUSxJQUFFbEMsU0FBUyxFQUFFLEdBQUUsQ0FBQ21DLFVBQVNDLFNBQVMsSUFBRXBDLFNBQVMsaUJBQWlCLEdBQUUsQ0FBQ3FDLFFBQU9DLFNBQVMsSUFBRXRDLFNBQVMsRUFBRSxHQUFFLENBQUN1QyxTQUFRQyxVQUFVLElBQUV4QyxTQUFnQyxJQUFJLEdBQUUsQ0FBQ3lDLE9BQU1DLE1BQU0sSUFBRTFDLFNBQVMsRUFBRSxHQUFFLENBQUMyQyxPQUFNQyxRQUFRLElBQUU1QyxTQUFTLEVBQUUsR0FBRSxDQUFDNkMsYUFBWUMsY0FBYyxJQUFFOUMsU0FBdUM7QUFDemEsUUFBTStDLFFBQU1oRCxPQUE4QixJQUFJLEdBQUVpRCxPQUFLakQsT0FBNkIsSUFBSSxHQUFFa0QsT0FBS3pDLGFBQWEsQ0FBQ2lDLFNBQU9TLFFBQVFyQixRQUFNRSxZQUFVRSxLQUFLLENBQUM7QUFDaEosUUFBTWtCLGFBQVc3QixRQUFROEIsTUFBTUEsS0FBS0MsS0FBSyxDQUFBQyxNQUFHQSxFQUFFM0IsU0FBT0EsUUFBTTJCLEVBQUVuQixhQUFXQSxRQUFRLEdBQUVvQixPQUFLaEMsT0FBT2lDLFdBQVNoQyxlQUFlZ0MsV0FBUy9CLEtBQUsrQixXQUFTOUIsSUFBSThCO0FBQ2pKLFFBQU1DLFVBQVFsQyxPQUFPbUMsY0FBWWxDLGVBQWVrQyxjQUFZakMsS0FBS2lDLGNBQVloQyxJQUFJZ0M7QUFDakYsUUFBTUMsUUFBTVQsUUFBUUMsY0FBWXRCLFFBQU1zQixXQUFXUyxnQkFBZ0JDLEtBQUssQ0FBQUMsTUFBR0EsRUFBRUMsT0FBS2hDLFFBQVEsS0FBR0UsTUFBTStCLEtBQUssS0FBR3RELGdCQUFnQnVCLEtBQUssS0FBRyxPQUFLSixLQUFLb0MsT0FBSyxLQUFHcEMsS0FBS29DLFFBQU1kLFdBQVdlLFlBQVUsQ0FBQyxZQUFXLDBCQUEwQixFQUFFQyxTQUFTdEMsS0FBS3VDLElBQUksQ0FBQztBQUM5TyxRQUFNQyxlQUFhQSxNQUFJO0FBQUM3QixlQUFXLElBQUk7QUFBRUksYUFBUyxFQUFFO0FBQUEsRUFBRTtBQUN0RCxRQUFNMEIsVUFBUSxZQUFTO0FBQ25CLFFBQUcsQ0FBQ1gsU0FBTyxDQUFDOUIsUUFBTSxDQUFDc0IsY0FBWUksUUFBTUUsU0FBUTtBQUFDYixlQUFTLHdGQUF3RjtBQUFFO0FBQUEsSUFBTztBQUN4SixRQUFJO0FBQUMsVUFBSW1CLEtBQUcxQjtBQUFPLFVBQUcsQ0FBQzBCLElBQUc7QUFBQyxjQUFNUSxLQUFHLElBQUlDLFNBQVM7QUFBRUQsV0FBR0UsT0FBTyxXQUFVOUMsU0FBTyxTQUFPLG1CQUFpQixlQUFlO0FBQUU0QyxXQUFHRSxPQUFPLGNBQWExQyxRQUFRO0FBQUV3QyxXQUFHRSxPQUFPLFFBQU81QyxJQUFJO0FBQUUsY0FBTTZDLFVBQU8sTUFBTW5ELE9BQU9vRCxRQUFRLEVBQUMzQixNQUFLdUIsR0FBRSxDQUFDO0FBQUUsWUFBR0csUUFBT3RCLEtBQUt3QixXQUFTLFNBQVE7QUFBQ2hDLG1CQUFTLHVEQUF1RDtBQUFFO0FBQUEsUUFBTztBQUFDbUIsYUFBR1csUUFBT3RCLEtBQUtXO0FBQUd6QixrQkFBVXlCLEVBQUU7QUFBQSxNQUFFO0FBQ25XLFlBQU1XLFNBQU8sTUFBTWxELGVBQWVtRCxRQUFRLEVBQUNFLE1BQUssRUFBQ3hDLFFBQU8wQixJQUFHZSxvQkFBbUIvQyxVQUFTSSxVQUFTNEMsZUFBYzlDLE1BQUssRUFBQyxDQUFDO0FBQUVPLGlCQUFXa0MsT0FBT3RCLElBQUk7QUFBRVIsZUFBUyxFQUFFO0FBQUEsSUFDOUosUUFBTTtBQUFBLElBQUM7QUFBQSxFQUNYO0FBQ0EsUUFBTW9DLFNBQU8sWUFBUztBQUFDLFFBQUcsQ0FBQ3pDLFdBQVMsQ0FBQ0EsUUFBUTBDLGFBQVcxQixRQUFNRSxRQUFRO0FBQU8sUUFBSTtBQUFDLFlBQU1vQixPQUFLLEVBQUN4QyxRQUFPRSxRQUFRRixRQUFPeUMsb0JBQW1CdkMsUUFBUXVDLG9CQUFtQjNDLFVBQVNJLFFBQVFKLFVBQVM0QyxlQUFjeEMsUUFBUXdDLGVBQWNHLGlCQUFnQjNDLFFBQVEyQyxnQkFBZTtBQUFFLFlBQU1SLFNBQU8vQyxTQUFPLFNBQU8sTUFBTUYsS0FBS2tELFFBQVEsRUFBQ0UsS0FBSSxDQUFDLElBQUUsTUFBTW5ELElBQUlpRCxRQUFRLEVBQUNFLEtBQUksQ0FBQztBQUFFbkMsYUFBT2dDLE9BQU90QixLQUFLVyxFQUFFO0FBQUUsVUFBR2YsS0FBS21DLFFBQVExRSxnQkFBZXVDLEtBQUttQyxPQUFPO0FBQUVyQyxxQkFBZSxDQUFBc0MsT0FBSSxFQUFDQyxPQUFNLE1BQUtDLFdBQVVGLEdBQUdFLFlBQVUsS0FBRyxFQUFDLEVBQUU7QUFBQSxJQUFFLFFBQU07QUFBQSxJQUFDO0FBQUEsRUFBMEU7QUFDNWlCLFNBQU8sdUJBQUMsY0FBVyxNQUFJLE1BQUMsT0FBTSxzQkFBcUIsU0FBa0IsTUFBWSxhQUEwQixTQUFTN0MsUUFBTSx1QkFBQyxhQUFVLElBQUksTUFBTXBCLEtBQUswQyxFQUFFLFNBQVN0QixLQUFLLElBQUksZ0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEQsSUFBYUYsVUFBUSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVZ0IsUUFBTUUsV0FBU2xCLFFBQVEwQyxjQUFZLEdBQUcsU0FBUyxNQUFJLEtBQUtELE9BQU8sR0FBRyxvQ0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0SCxJQUFVLHVCQUFDLFVBQU8sTUFBSyxVQUFTLE1BQUssb0JBQW1CLFNBQVEsYUFBWSxVQUFVekIsUUFBTUUsU0FBVSx1Q0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtSCxHQUNsYztBQUFBLDJCQUFDLGVBQVksT0FBT2xDLE9BQU9vQixTQUFPbkIsZUFBZW1CLFNBQU9sQixLQUFLa0IsU0FBT2pCLElBQUlpQixTQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThFO0FBQUEsSUFBR0EsU0FBTyx1QkFBQyxTQUFNLFVBQVMsU0FBU0EsbUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxJQUN0SEYsUUFBTSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVMsa0lBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEosSUFBUyx1QkFBQyxjQUFXLE9BQU9uQixTQUFTLGlDQUFDLGNBQVcsV0FBVSxRQUFPLElBQUcsb0JBQW1CLFlBQVUsTUFBQyxLQUFLLENBQUFpRSxTQUFNO0FBQUN2QyxXQUFLbUMsVUFBUUk7QUFBS3RDLFdBQUtzQyxJQUFJO0FBQUEsSUFBRSxHQUFHLG9CQUFrQjlDLFFBQU0sU0FBTytDLFFBQVcsVUFBVSxDQUFBQyxNQUFHO0FBQUNBLFFBQUVDLGVBQWU7QUFBRSxXQUFLcEIsUUFBUTtBQUFBLElBQUUsR0FDdFk7QUFBQSw2QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGFBQVksT0FBTzNDLE1BQU0sVUFBVSxDQUFBOEQsTUFBRztBQUFDN0QsZ0JBQVE2RCxFQUFFRSxPQUFPQyxVQUFRLFFBQU0sUUFBTSxNQUFNO0FBQUU1RCxvQkFBWSxFQUFFO0FBQUVNLGtCQUFVLEVBQUU7QUFBRStCLHFCQUFhO0FBQUEsTUFBRSxHQUFHO0FBQUEsK0JBQUMsWUFBUyxPQUFNLFFBQU8seUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUFXLHVCQUFDLFlBQVMsT0FBTSxPQUFNLG1CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsV0FBaE87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyTztBQUFBLE1BQzNPLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0saUJBQWdCLE9BQU9sQyxVQUFVLFVBQVUsQ0FBQXNELE1BQUc7QUFBQ3JELGtCQUFVcUQsRUFBRUUsT0FBT0MsS0FBSztBQUFFdkIscUJBQWE7QUFBQSxNQUFFLEdBQUkvQyxrQkFBUThCLE1BQU1BLEtBQUt5QyxPQUFPLENBQUF2QyxNQUFHQSxFQUFFM0IsU0FBT0EsSUFBSSxFQUFFbUUsSUFBSSxDQUFBeEMsTUFBRyx1QkFBQyxZQUFvQixPQUFPQSxFQUFFbkIsVUFBV21CLFlBQUV5QyxRQUE1QnpDLEVBQUVTLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0QsQ0FBVyxLQUFsTztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9PO0FBQUEsTUFDcE8sdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxpQ0FBZ0MsT0FBT2hDLFVBQVUsVUFBVSxDQUFBMEQsTUFBRztBQUFDekQsb0JBQVl5RCxFQUFFRSxPQUFPQyxLQUFLO0FBQUV0RCxrQkFBVSxFQUFFO0FBQUUrQixxQkFBYTtBQUFBLE1BQUUsR0FBRztBQUFBLCtCQUFDLFlBQVMsT0FBTSxJQUFHLG1DQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFBWWxCLFlBQVlTLGdCQUFnQmtDLElBQUksQ0FBQWhDLE1BQUcsdUJBQUMsWUFBb0IsT0FBT0EsRUFBRUMsSUFBS0QsWUFBRWtDLFNBQXRCbEMsRUFBRUMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQyxDQUFXO0FBQUEsV0FBOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnUztBQUFBLE1BQ2hTLHVCQUFDLFVBQU8sU0FBUSxZQUFXLFNBQVMsTUFBSWhCLE1BQU1vQyxTQUFTYyxNQUFNLEdBQUlwRSxpQkFBS0EsS0FBS2tFLE9BQUssY0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRjtBQUFBLE1BQVMsdUJBQUMsV0FBTSxLQUFLaEQsT0FBTyxRQUFNLE1BQUMsTUFBSyxRQUFPLFFBQU8saUJBQWdCLGNBQVcsV0FBVSxVQUFVLENBQUEwQyxNQUFHO0FBQUMzRCxnQkFBUTJELEVBQUVFLE9BQU9PLFFBQVEsQ0FBQyxLQUFHLElBQUk7QUFBRTVELGtCQUFVLEVBQUU7QUFBRStCLHFCQUFhO0FBQUEsTUFBRSxLQUFoSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtLO0FBQUEsTUFDclFsQixjQUFZLHVCQUFDLFNBQU0sVUFBUyxRQUFPO0FBQUE7QUFBQSxRQUFZQSxXQUFXZTtBQUFBQSxRQUFTO0FBQUEsUUFBU2YsV0FBV2dEO0FBQUFBLFFBQVE7QUFBQSxRQUFzQmhELFdBQVdpRCxnQkFBZ0JDLEtBQUssSUFBSTtBQUFBLFFBQUU7QUFBQSxRQUFFLHVCQUFDLE9BQUUsTUFBTSxZQUFZMUUsU0FBTyxTQUFPLHNCQUFvQixpQkFBaUIsUUFBUSxVQUFRLE1BQUMsMkJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxXQUFyUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlQO0FBQUEsTUFDdFEsdUJBQUMsYUFBVSxPQUFNLHdCQUF1QixPQUFPTSxPQUFPLFVBQVUsQ0FBQXdELE1BQUc7QUFBQ3ZELGlCQUFTdUQsRUFBRUUsT0FBT0MsS0FBSztBQUFFdkIscUJBQWE7QUFBQSxNQUFFLEdBQUcsWUFBVywwRkFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnTjtBQUFBLE1BQy9NOUIsV0FBUyxtQ0FBRTtBQUFBLCtCQUFDLFNBQU0sVUFBVUEsUUFBUStELGNBQVksWUFBVSxXQUFZL0Q7QUFBQUEsa0JBQVEwQztBQUFBQSxVQUFVO0FBQUEsVUFBZ0IxQyxRQUFRK0Q7QUFBQUEsVUFBWTtBQUFBLFVBQWlFM0YsU0FBUzRCLFFBQVFnRSxXQUFVbEYsS0FBS21GLFFBQVE7QUFBQSxVQUFFO0FBQUEsYUFBNU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TjtBQUFBLFFBQVEsdUJBQUMsYUFBVSxPQUFNLDJCQUEwQixNQUFNakUsUUFBUWtFLE1BQU0sUUFBUSxDQUFBM0MsTUFBRzRDLE9BQU81QyxFQUFFNkMsR0FBRyxHQUFHLFNBQVMsQ0FBQyxFQUFDQyxLQUFJLE9BQU1aLE9BQU0sWUFBV2EsUUFBT0EsQ0FBQS9DLE1BQUdBLEVBQUU2QyxJQUFHLEdBQUUsRUFBQ0MsS0FBSSxVQUFTWixPQUFNLFdBQVVhLFFBQU9BLENBQUEvQyxNQUFHZ0QsT0FBT0MsUUFBUWpELEVBQUVrRCxNQUFNLEVBQUVsQixJQUFJLENBQUMsQ0FBQ2MsS0FBSWhCLEtBQUssTUFBSSxHQUFHZ0IsR0FBRyxLQUFLaEIsS0FBSyxFQUFFLEVBQUVTLEtBQUssS0FBSyxFQUFDLEdBQUUsRUFBQ08sS0FBSSxVQUFTWixPQUFNLGdCQUFlYSxRQUFPQSxDQUFBL0MsTUFBR0EsRUFBRW1ELE9BQU9aLEtBQUssSUFBSSxLQUFHLFNBQVEsQ0FBQyxLQUFoVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtWO0FBQUEsUUFBRSx1QkFBQyxVQUFPLFNBQVMsTUFBSSxLQUFLL0IsUUFBUSxHQUFHLFVBQVVmLFFBQU1FLFNBQVMsZ0NBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxXQUF6b0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrcEI7QUFBQSxTQVAxZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUXRNLEtBUjBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRN0o7QUFBQSxPQVZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXUDtBQUNKO0FBQUNyQyxHQTVCZUYsaUJBQWU7QUFBQSxVQUNkWCxVQUFtQkYsUUFDbkJDLFlBQTJDQSxZQUE2Q0EsWUFBeUZBLFlBRWpHRSxZQUFZO0FBQUE7QUFBQSxLQUo3RlU7QUFBZSxJQUFBZ0c7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlU3RhdGUiLCJBbGVydCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiVGV4dEZpZWxkIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlRHJhZnRGb3JtIiwibWFya0RyYWZ0Q2xlYW4iLCJjb2RlUG9pbnRMZW5ndGgiLCJkYXRlVGltZSIsIkZvcm1GaWVsZHMiLCJEYXRhVGFibGUiLCJFZGl0RGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJRdWVyeVN0YXRlIiwiUm91dGVMaW5rIiwiU3RhdGVtZW50RGlhbG9nIiwib25DbG9zZSIsIl9zIiwic2hvcCIsImZvcm1hdHMiLCJ1cGxvYWQiLCJwcmV2aWV3Q29tbWFuZCIsImJhbmsiLCJjb2QiLCJraW5kIiwic2V0S2luZCIsImZpbGUiLCJzZXRGaWxlIiwicmVzb3VyY2UiLCJzZXRSZXNvdXJjZSIsImJhdGNoIiwic2V0QmF0Y2giLCJmb3JtYXRJZCIsInNldEZvcm1hdCIsImZpbGVJZCIsInNldEZpbGVJZCIsInByZXZpZXciLCJzZXRQcmV2aWV3Iiwiam9iSWQiLCJzZXRKb2IiLCJlcnJvciIsInNldEVycm9yIiwiZHJhZnRDb21taXQiLCJzZXREcmFmdENvbW1pdCIsImlucHV0IiwiZm9ybSIsImJpbmQiLCJCb29sZWFuIiwiZGVzY3JpcHRvciIsImRhdGEiLCJmaW5kIiwiZiIsImJ1c3kiLCJwZW5kaW5nIiwiYmxvY2tlZCIsInVucmVzb2x2ZWQiLCJ2YWxpZCIsInJlc291cmNlT3B0aW9ucyIsInNvbWUiLCJyIiwiaWQiLCJ0cmltIiwic2l6ZSIsIm1heEJ5dGVzIiwiaW5jbHVkZXMiLCJ0eXBlIiwiY2xlYXJQcmV2aWV3IiwicHJlcGFyZSIsImZkIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJyZXN1bHQiLCJleGVjdXRlIiwic3RhdHVzIiwiYm9keSIsImFjY291bnRPckNhcnJpZXJJZCIsInNvdXJjZUJhdGNoSWQiLCJjb21taXQiLCJ2YWxpZFJvd3MiLCJ2YWxpZGF0aW9uVG9rZW4iLCJjdXJyZW50IiwicCIsInNjb3BlIiwic2VxdWVuY2UiLCJub2RlIiwidW5kZWZpbmVkIiwiZSIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJmaWx0ZXIiLCJtYXAiLCJuYW1lIiwibGFiZWwiLCJjbGljayIsImZpbGVzIiwibWF4Um93cyIsInJlcXVpcmVkQ29sdW1ucyIsImpvaW4iLCJpbnZhbGlkUm93cyIsImV4cGlyZXNBdCIsInRpbWV6b25lIiwicm93cyIsIlN0cmluZyIsInJvdyIsImtleSIsInJlbmRlciIsIk9iamVjdCIsImVudHJpZXMiLCJ2YWx1ZXMiLCJlcnJvcnMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzdGF0ZW1lbnQtaW1wb3J0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVJlZix1c2VTdGF0ZX0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtBbGVydCxCdXR0b24sTWVudUl0ZW0sVGV4dEZpZWxkfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB0eXBlIHtTdGF0ZW1lbnRQcmV2aWV3fSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7dXNlQXBpLHVzZUNvbW1hbmR9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XG5pbXBvcnQge3VzZVNjb3BlfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQge3VzZURyYWZ0Rm9ybSxtYXJrRHJhZnRDbGVhbn0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZGlydHktZHJhZnRzJztcbmltcG9ydCB7Y29kZVBvaW50TGVuZ3RoLGRhdGVUaW1lfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHtGb3JtRmllbGRzfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XG5pbXBvcnQge0RhdGFUYWJsZSxFZGl0RGlhbG9nLEVycm9yTm90aWNlLFF1ZXJ5U3RhdGUsUm91dGVMaW5rfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcblxuZXhwb3J0IGZ1bmN0aW9uIFN0YXRlbWVudERpYWxvZyh7b25DbG9zZX06e29uQ2xvc2U6KCk9PnZvaWR9KSB7XG4gICAgY29uc3Qge3Nob3B9PXVzZVNjb3BlKCksZm9ybWF0cz11c2VBcGkoJ2xpc3RTdGF0ZW1lbnRGb3JtYXRzJyk7XG4gICAgY29uc3QgdXBsb2FkPXVzZUNvbW1hbmQoJ3VwbG9hZEZpbGUnLFtdKSxwcmV2aWV3Q29tbWFuZD11c2VDb21tYW5kKCdwcmV2aWV3U3RhdGVtZW50SW1wb3J0JyxbXSksYmFuaz11c2VDb21tYW5kKCdpbXBvcnRCYW5rU3RhdGVtZW50JyxbJ2xpc3RCYW5rVHJhbnNhY3Rpb25zJywnbGlzdFJlY29uY2lsaWF0aW9uQ2FzZXMnXSksY29kPXVzZUNvbW1hbmQoJ2ltcG9ydENPRFN0YXRlbWVudCcsWydsaXN0Q09EU2V0dGxlbWVudHMnXSk7XG4gICAgY29uc3QgW2tpbmQsc2V0S2luZF09dXNlU3RhdGU8J2JhbmsnfCdjb2QnPignYmFuaycpLFtmaWxlLHNldEZpbGVdPXVzZVN0YXRlPEZpbGV8bnVsbD4obnVsbCksW3Jlc291cmNlLHNldFJlc291cmNlXT11c2VTdGF0ZSgnJyksW2JhdGNoLHNldEJhdGNoXT11c2VTdGF0ZSgnJyksW2Zvcm1hdElkLHNldEZvcm1hdF09dXNlU3RhdGUoJ2JvdHNhbGVzLWNzdi12MScpLFtmaWxlSWQsc2V0RmlsZUlkXT11c2VTdGF0ZSgnJyksW3ByZXZpZXcsc2V0UHJldmlld109dXNlU3RhdGU8U3RhdGVtZW50UHJldmlld3xudWxsPihudWxsKSxbam9iSWQsc2V0Sm9iXT11c2VTdGF0ZSgnJyksW2Vycm9yLHNldEVycm9yXT11c2VTdGF0ZSgnJyksW2RyYWZ0Q29tbWl0LHNldERyYWZ0Q29tbWl0XT11c2VTdGF0ZTx7c2NvcGU6bnVsbDtzZXF1ZW5jZTpudW1iZXJ9PigpO1xuICAgIGNvbnN0IGlucHV0PXVzZVJlZjxIVE1MSW5wdXRFbGVtZW50fG51bGw+KG51bGwpLGZvcm09dXNlUmVmPEhUTUxGb3JtRWxlbWVudHxudWxsPihudWxsKSxiaW5kPXVzZURyYWZ0Rm9ybSgham9iSWQmJkJvb2xlYW4oZmlsZXx8cmVzb3VyY2V8fGJhdGNoKSk7XG4gICAgY29uc3QgZGVzY3JpcHRvcj1mb3JtYXRzLmRhdGE/LmRhdGEuZmluZChmPT5mLmtpbmQ9PT1raW5kJiZmLmZvcm1hdElkPT09Zm9ybWF0SWQpLGJ1c3k9dXBsb2FkLnBlbmRpbmd8fHByZXZpZXdDb21tYW5kLnBlbmRpbmd8fGJhbmsucGVuZGluZ3x8Y29kLnBlbmRpbmc7XG4gICAgY29uc3QgYmxvY2tlZD11cGxvYWQudW5yZXNvbHZlZHx8cHJldmlld0NvbW1hbmQudW5yZXNvbHZlZHx8YmFuay51bnJlc29sdmVkfHxjb2QudW5yZXNvbHZlZDtcbiAgICBjb25zdCB2YWxpZD1Cb29sZWFuKGRlc2NyaXB0b3ImJmZpbGUmJmRlc2NyaXB0b3IucmVzb3VyY2VPcHRpb25zLnNvbWUocj0+ci5pZD09PXJlc291cmNlKSYmYmF0Y2gudHJpbSgpJiZjb2RlUG9pbnRMZW5ndGgoYmF0Y2gpPD0yMDAmJmZpbGUuc2l6ZT4wJiZmaWxlLnNpemU8PWRlc2NyaXB0b3IubWF4Qnl0ZXMmJlsndGV4dC9jc3YnLCdhcHBsaWNhdGlvbi92bmQubXMtZXhjZWwnXS5pbmNsdWRlcyhmaWxlLnR5cGUpKTtcbiAgICBjb25zdCBjbGVhclByZXZpZXc9KCk9PntzZXRQcmV2aWV3KG51bGwpO3NldEVycm9yKCcnKTt9O1xuICAgIGNvbnN0IHByZXBhcmU9YXN5bmMoKT0+e1xuICAgICAgICBpZighdmFsaWR8fCFmaWxlfHwhZGVzY3JpcHRvcnx8YnVzeXx8YmxvY2tlZCl7c2V0RXJyb3IoJ0No4buNbiBDU1YgxJHDum5nIGxv4bqhaS9kdW5nIGzGsOG7o25nLCB0w6BpIGtob+G6o24gaG/hurdjIMSRxqFuIHbhu4sgduG6rW4gY2h1eeG7g24gdsOgIG3DoyDEkeG7o3QgMeKAkzIwMCBrw70gdOG7sS4nKTtyZXR1cm47fVxuICAgICAgICB0cnkge2xldCBpZD1maWxlSWQ7aWYoIWlkKXtjb25zdCBmZD1uZXcgRm9ybURhdGEoKTtmZC5hcHBlbmQoJ3B1cnBvc2UnLGtpbmQ9PT0nYmFuayc/J2Jhbmtfc3RhdGVtZW50JzonY29kX3N0YXRlbWVudCcpO2ZkLmFwcGVuZCgncmVzb3VyY2VJZCcscmVzb3VyY2UpO2ZkLmFwcGVuZCgnZmlsZScsZmlsZSk7Y29uc3QgcmVzdWx0PWF3YWl0IHVwbG9hZC5leGVjdXRlKHtmb3JtOmZkfSk7aWYocmVzdWx0LmRhdGEuc3RhdHVzIT09J3JlYWR5Jyl7c2V0RXJyb3IoJ1Thu4dwIGNoxrBhIHF1YSBraeG7g20gdHJhOyBjaMawYSDEkcaw4bujYyB4ZW0gdHLGsOG7m2MgaG/hurdjIG5o4bqtcC4nKTtyZXR1cm47fWlkPXJlc3VsdC5kYXRhLmlkO3NldEZpbGVJZChpZCk7fVxuICAgICAgICAgICAgY29uc3QgcmVzdWx0PWF3YWl0IHByZXZpZXdDb21tYW5kLmV4ZWN1dGUoe2JvZHk6e2ZpbGVJZDppZCxhY2NvdW50T3JDYXJyaWVySWQ6cmVzb3VyY2UsZm9ybWF0SWQsc291cmNlQmF0Y2hJZDpiYXRjaH19KTtzZXRQcmV2aWV3KHJlc3VsdC5kYXRhKTtzZXRFcnJvcignJyk7XG4gICAgICAgIH1jYXRjaHsvKiBDb21tYW5kIG5vdGljZSByZXRhaW5zIHVua25vd24vY29uZmxpY3Q7IHVwbG9hZGVkIGZpbGUgcmVtYWlucyBhdmFpbGFibGUgZm9yIHJldHJ5LiAqL31cbiAgICB9O1xuICAgIGNvbnN0IGNvbW1pdD1hc3luYygpPT57aWYoIXByZXZpZXd8fCFwcmV2aWV3LnZhbGlkUm93c3x8YnVzeXx8YmxvY2tlZClyZXR1cm47dHJ5IHtjb25zdCBib2R5PXtmaWxlSWQ6cHJldmlldy5maWxlSWQsYWNjb3VudE9yQ2FycmllcklkOnByZXZpZXcuYWNjb3VudE9yQ2FycmllcklkLGZvcm1hdElkOnByZXZpZXcuZm9ybWF0SWQsc291cmNlQmF0Y2hJZDpwcmV2aWV3LnNvdXJjZUJhdGNoSWQsdmFsaWRhdGlvblRva2VuOnByZXZpZXcudmFsaWRhdGlvblRva2VufTtjb25zdCByZXN1bHQ9a2luZD09PSdiYW5rJz9hd2FpdCBiYW5rLmV4ZWN1dGUoe2JvZHl9KTphd2FpdCBjb2QuZXhlY3V0ZSh7Ym9keX0pO3NldEpvYihyZXN1bHQuZGF0YS5pZCk7aWYoZm9ybS5jdXJyZW50KW1hcmtEcmFmdENsZWFuKGZvcm0uY3VycmVudCk7c2V0RHJhZnRDb21taXQocD0+KHtzY29wZTpudWxsLHNlcXVlbmNlOihwPy5zZXF1ZW5jZXx8MCkrMX0pKTt9Y2F0Y2h7LyogQVBJIHJldmFsaWRhdGVzIHByZXZpZXcgYmluZGluZ3MsIHJlZmVyZW5jZXMgYW5kIHNvdXJjZSB1bmlxdWVuZXNzLiAqL319O1xuICAgIHJldHVybiA8RWRpdERpYWxvZyBvcGVuIHRpdGxlPVwiTmjhuq1wIGLhuqNuZyDEkeG7kWkgc2/DoXRcIiBvbkNsb3NlPXtvbkNsb3NlfSBidXN5PXtidXN5fSBkcmFmdENvbW1pdD17ZHJhZnRDb21taXR9IGFjdGlvbnM9e2pvYklkPzxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2pvYnMvJHtqb2JJZH1gfT5YZW0ga+G6v3QgcXXhuqMgbmjhuq1wPC9Sb3V0ZUxpbms+OnByZXZpZXc/PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e2J1c3l8fGJsb2NrZWR8fHByZXZpZXcudmFsaWRSb3dzPT09MH0gb25DbGljaz17KCk9PnZvaWQgY29tbWl0KCl9Pk5o4bqtcCBjw6FjIGTDsm5nIGjhu6NwIGzhu4c8L0J1dHRvbj46PEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZm9ybT1cInN0YXRlbWVudC1pbXBvcnRcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9e2J1c3l8fGJsb2NrZWR9ID5YZW0gdHLGsOG7m2MgYuG6o25nIMSR4buRaSBzb8OhdDwvQnV0dG9uPn0+XG4gICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17dXBsb2FkLmVycm9yfHxwcmV2aWV3Q29tbWFuZC5lcnJvcnx8YmFuay5lcnJvcnx8Y29kLmVycm9yfS8+e2Vycm9yJiY8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiPntlcnJvcn08L0FsZXJ0Pn1cbiAgICAgICAge2pvYklkPzxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+xJDDoyBuaOG6rW4ga+G6v3QgcXXhuqMgbmjhuq1wLiDEkOG7kWkgc2/DoXQgdsOgIGdoaSBz4buVIHbhuqtuIGPhuqduIHRo4buxYyBoaeG7h24gdGhlbyBjaOG7qW5nIHThu6s7IGtp4buDbSBjaGkgdGnhur90IGTDsm5nIGzhu5dpIHThuqFpIGvhur90IHF14bqjIG5o4bqtcC48L0FsZXJ0Pjo8UXVlcnlTdGF0ZSBxdWVyeT17Zm9ybWF0c30+PEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIGlkPVwic3RhdGVtZW50LWltcG9ydFwiIG5vVmFsaWRhdGUgcmVmPXtub2RlPT57Zm9ybS5jdXJyZW50PW5vZGU7YmluZChub2RlKTt9fSBkYXRhLWRyYWZ0LWNsZWFuPXtqb2JJZD8ndHJ1ZSc6dW5kZWZpbmVkfSBvblN1Ym1pdD17ZT0+e2UucHJldmVudERlZmF1bHQoKTt2b2lkIHByZXBhcmUoKTt9fT5cbiAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTG/huqFpIGLhuqNuZ1wiIHZhbHVlPXtraW5kfSBvbkNoYW5nZT17ZT0+e3NldEtpbmQoZS50YXJnZXQudmFsdWU9PT0nY29kJz8nY29kJzonYmFuaycpO3NldFJlc291cmNlKCcnKTtzZXRGaWxlSWQoJycpO2NsZWFyUHJldmlldygpO319PjxNZW51SXRlbSB2YWx1ZT1cImJhbmtcIj5OZ8OibiBow6BuZzwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiY29kXCI+Q09EPC9NZW51SXRlbT48L1RleHRGaWVsZD5cbiAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwixJDhu4tuaCBk4bqhbmcgQ1NWXCIgdmFsdWU9e2Zvcm1hdElkfSBvbkNoYW5nZT17ZT0+e3NldEZvcm1hdChlLnRhcmdldC52YWx1ZSk7Y2xlYXJQcmV2aWV3KCk7fX0+e2Zvcm1hdHMuZGF0YT8uZGF0YS5maWx0ZXIoZj0+Zi5raW5kPT09a2luZCkubWFwKGY9PjxNZW51SXRlbSBrZXk9e2YuaWR9IHZhbHVlPXtmLmZvcm1hdElkfT57Zi5uYW1lfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD5cbiAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiVMOgaSBraG/huqNuIC8gxJHGoW4gduG7iyB24bqtbiBjaHV54buDblwiIHZhbHVlPXtyZXNvdXJjZX0gb25DaGFuZ2U9e2U9PntzZXRSZXNvdXJjZShlLnRhcmdldC52YWx1ZSk7c2V0RmlsZUlkKCcnKTtjbGVhclByZXZpZXcoKTt9fT48TWVudUl0ZW0gdmFsdWU9XCJcIj5DaOG7jW4gbmd14buTbiDEkeG7kWkgc2/DoXQ8L01lbnVJdGVtPntkZXNjcmlwdG9yPy5yZXNvdXJjZU9wdGlvbnMubWFwKHI9PjxNZW51SXRlbSBrZXk9e3IuaWR9IHZhbHVlPXtyLmlkfT57ci5sYWJlbH08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIG9uQ2xpY2s9eygpPT5pbnB1dC5jdXJyZW50Py5jbGljaygpfT57ZmlsZT9maWxlLm5hbWU6J0No4buNbiBDU1YnfTwvQnV0dG9uPjxpbnB1dCByZWY9e2lucHV0fSBoaWRkZW4gdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCIuY3N2LHRleHQvY3N2XCIgYXJpYS1sYWJlbD1cIlThu4dwIENTVlwiIG9uQ2hhbmdlPXtlPT57c2V0RmlsZShlLnRhcmdldC5maWxlcz8uWzBdfHxudWxsKTtzZXRGaWxlSWQoJycpO2NsZWFyUHJldmlldygpO319Lz5cbiAgICAgICAgICAgIHtkZXNjcmlwdG9yJiY8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+Q1NWIHThu5FpIMSRYSB7ZGVzY3JpcHRvci5tYXhCeXRlc30gYnl0ZSAvIHtkZXNjcmlwdG9yLm1heFJvd3N9IGTDsm5nLiBD4buZdCBi4bqvdCBideG7mWM6IHtkZXNjcmlwdG9yLnJlcXVpcmVkQ29sdW1ucy5qb2luKCcsICcpfS4gPGEgaHJlZj17YC9zYW1wbGVzLyR7a2luZD09PSdiYW5rJz8nYmFuay10cmFuc2FjdGlvbnMnOidjb2Qtc2V0dGxlbWVudHMnfS5jc3ZgfSBkb3dubG9hZD5U4bqjaSBDU1YgbeG6q3U8L2E+PC9BbGVydD59XG4gICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiTcOjIMSR4bujdCBuaOG6rXAgZHV5IG5o4bqldFwiIHZhbHVlPXtiYXRjaH0gb25DaGFuZ2U9e2U9PntzZXRCYXRjaChlLnRhcmdldC52YWx1ZSk7Y2xlYXJQcmV2aWV3KCk7fX0gaGVscGVyVGV4dD1cIjHigJMyMDAga8O9IHThu7EuIE5ndeG7k24gbOG6t3Agc+G6vSBjw7MgbOG7l2kgdGhlbyB04burbmcgZMOybmcsIGtow7RuZyB04bqhbyB0aeG7gW4gaG/hurdjIGNo4bupbmcgdOG7qyB0csO5bmcuXCIvPlxuICAgICAgICAgICAge3ByZXZpZXcmJjw+PEFsZXJ0IHNldmVyaXR5PXtwcmV2aWV3LmludmFsaWRSb3dzPyd3YXJuaW5nJzonc3VjY2Vzcyd9PntwcmV2aWV3LnZhbGlkUm93c30gZMOybmcgaOG7o3AgbOG7hyDCtyB7cHJldmlldy5pbnZhbGlkUm93c30gZMOybmcgbOG7l2kuIEtp4buDbSBs4bqhaSB0csaw4bubYyBraGkgbmjhuq1wOyB0b2tlbiB4ZW0gdHLGsOG7m2MgaOG6v3QgaOG6oW4gbMO6YyB7ZGF0ZVRpbWUocHJldmlldy5leHBpcmVzQXQsc2hvcC50aW1lem9uZSl9LjwvQWxlcnQ+PERhdGFUYWJsZSBsYWJlbD1cIlhlbSB0csaw4bubYyBi4bqjbmcgxJHhu5FpIHNvw6F0XCIgcm93cz17cHJldmlldy5yb3dzfSByb3dLZXk9e3I9PlN0cmluZyhyLnJvdyl9IGNvbHVtbnM9e1t7a2V5Oidyb3cnLGxhYmVsOidEw7JuZyBDU1YnLHJlbmRlcjpyPT5yLnJvd30se2tleTondmFsdWVzJyxsYWJlbDonROG7ryBsaeG7h3UnLHJlbmRlcjpyPT5PYmplY3QuZW50cmllcyhyLnZhbHVlcykubWFwKChba2V5LHZhbHVlXSk9PmAke2tleX06ICR7dmFsdWV9YCkuam9pbignIMK3ICcpfSx7a2V5OidlcnJvcnMnLGxhYmVsOidLaeG7g20gZOG7ryBsaeG7h3UnLHJlbmRlcjpyPT5yLmVycm9ycy5qb2luKCc7ICcpfHwnSOG7o3AgbOG7hyd9XX0vPjxCdXR0b24gb25DbGljaz17KCk9PnZvaWQgcHJlcGFyZSgpfSBkaXNhYmxlZD17YnVzeXx8YmxvY2tlZH0+S2nhu4NtIHRyYSBs4bqhaSBDU1Y8L0J1dHRvbj48Lz59XG4gICAgICAgIDwvRm9ybUZpZWxkcz48L1F1ZXJ5U3RhdGU+fVxuICAgIDwvRWRpdERpYWxvZz47XG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1bm5lci93b3JrL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9maW5hbmNlL3N0YXRlbWVudC1pbXBvcnQudHN4In0=