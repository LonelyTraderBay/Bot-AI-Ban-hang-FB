import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/report-range.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react.js?v=f9568e8d"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useSearchParams } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/react-router-dom.js?v=f9568e8d";
import { Alert, TextField } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-16658-d944d064-b72b-4a46-b58a-bcbcc72b98a5/deps/@mui_material.js?v=f9568e8d";
import { FormFields } from "/src/shared/ui/composition.tsx";
import { dateOnlyInTimezone, dateOnlyStartOfDayToISOString, isValidDateOnly } from "/src/shared/model/format.ts";
function previousMonthRange(timezone) {
  const [yearText = "", monthText = ""] = dateOnlyInTimezone(/* @__PURE__ */ new Date(), timezone).split("-");
  const year = Number(yearText), month = Number(monthText);
  const end = new Date(Date.UTC(year, month - 1, 1));
  const start = new Date(Date.UTC(year, month - 2, 1));
  const dateOnly = (value) => value.toISOString().slice(0, 10);
  return { from: dateOnly(start), to: dateOnly(end) };
}
export function useReportRange(timezone) {
  _s();
  const [params, setParams] = useSearchParams();
  const latestParams = useRef(new URLSearchParams(params));
  const pendingSearch = useRef(null);
  useEffect(() => {
    const committedSearch = params.toString();
    if (pendingSearch.current !== null && pendingSearch.current !== committedSearch) return;
    latestParams.current = new URLSearchParams(params);
    pendingSearch.current = null;
  }, [params]);
  const defaults = previousMonthRange(timezone);
  const readDate = (key) => {
    if (!params.has(key)) return defaults[key === "fromDate" ? "from" : "to"];
    const value = params.get(key);
    return value === "" ? "" : isValidDateOnly(value) ? value : defaults[key === "fromDate" ? "from" : "to"];
  };
  const readDateFrom = (source, key) => {
    if (!source.has(key)) return defaults[key === "fromDate" ? "from" : "to"];
    const value = source.get(key);
    return value === "" ? "" : isValidDateOnly(value) ? value : defaults[key === "fromDate" ? "from" : "to"];
  };
  const range = { from: readDate("fromDate"), to: readDate("toDate") };
  const valid = isValidDateOnly(range.from) && isValidDateOnly(range.to) && range.from < range.to;
  const setDate = (key, value) => {
    const next = new URLSearchParams(latestParams.current);
    next.delete("cursor");
    const from = key === "fromDate" ? isValidDateOnly(value) ? value : "" : readDateFrom(next, "fromDate");
    const to = key === "toDate" ? isValidDateOnly(value) ? value : "" : readDateFrom(next, "toDate");
    next.set("fromDate", from);
    next.set("toDate", to);
    latestParams.current = next;
    pendingSearch.current = next.toString();
    setParams(next, { flushSync: true });
  };
  return {
    range,
    setFrom: (from) => setDate("fromDate", from),
    setTo: (to) => setDate("toDate", to),
    valid,
    query: {
      from: valid ? dateOnlyStartOfDayToISOString(range.from, timezone) : "",
      to: valid ? dateOnlyStartOfDayToISOString(range.to, timezone) : "",
      timezone
    }
  };
}
_s(useReportRange, "cZto1zk24l7jjznDfOGbNe8JZJg=", false, function() {
  return [useSearchParams];
});
export function ReportRangeFields({ range, timezone, setFrom, setTo }) {
  return /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, afterGap: "section", children: [
    /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Từ ngày", value: range.from, onChange: (event) => setFrom(event.target.value), slotProps: { inputLabel: { shrink: true } } }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx",
      lineNumber: 81,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { type: "date", label: "Đến trước ngày", value: range.to, onChange: (event) => setTo(event.target.value), slotProps: { inputLabel: { shrink: true } } }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx",
      lineNumber: 82,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: { alignItems: "center" }, children: [
      "Khoảng [Từ, Đến); múi giờ ",
      timezone,
      "."
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx",
      lineNumber: 83,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx",
    lineNumber: 80,
    columnNumber: 10
  }, this);
}
_c = ReportRangeFields;
var _c;
$RefreshReg$(_c, "ReportRangeFields");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/report-range.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdEUixTQUFRQSxXQUFVQyxjQUFhO0FBQy9CLFNBQVFDLHVCQUFzQjtBQUM5QixTQUFRQyxPQUFNQyxpQkFBZ0I7QUFDOUIsU0FBUUMsa0JBQWlCO0FBQ3pCLFNBQVFDLG9CQUFtQkMsK0JBQThCQyx1QkFBc0I7QUFDL0UsU0FBU0MsbUJBQW1CQyxVQUFrQjtBQUMxQyxRQUFNLENBQUNDLFdBQVcsSUFBSUMsWUFBWSxFQUFFLElBQUlOLG1CQUFtQixvQkFBSU8sS0FBSyxHQUFHSCxRQUFRLEVBQUVJLE1BQU0sR0FBRztBQUMxRixRQUFNQyxPQUFPQyxPQUFPTCxRQUFRLEdBQUdNLFFBQVFELE9BQU9KLFNBQVM7QUFDdkQsUUFBTU0sTUFBTSxJQUFJTCxLQUFLQSxLQUFLTSxJQUFJSixNQUFNRSxRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBQ2pELFFBQU1HLFFBQVEsSUFBSVAsS0FBS0EsS0FBS00sSUFBSUosTUFBTUUsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUNuRCxRQUFNSSxXQUFXQSxDQUFDQyxVQUFnQkEsTUFBTUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUNqRSxTQUFPLEVBQUVDLE1BQU1KLFNBQVNELEtBQUssR0FBR00sSUFBSUwsU0FBU0gsR0FBRyxFQUFFO0FBQ3REO0FBQ08sZ0JBQVNTLGVBQWVqQixVQUFrQjtBQUFBa0IsS0FBQTtBQUM3QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTVCLGdCQUFnQjtBQUM1QyxRQUFNNkIsZUFBZTlCLE9BQU8sSUFBSStCLGdCQUFnQkgsTUFBTSxDQUFDO0FBQ3ZELFFBQU1JLGdCQUFnQmhDLE9BQXNCLElBQUk7QUFDaERELFlBQVUsTUFBTTtBQUNaLFVBQU1rQyxrQkFBa0JMLE9BQU9NLFNBQVM7QUFDeEMsUUFBSUYsY0FBY0csWUFBWSxRQUFRSCxjQUFjRyxZQUFZRixnQkFBaUI7QUFDakZILGlCQUFhSyxVQUFVLElBQUlKLGdCQUFnQkgsTUFBTTtBQUNqREksa0JBQWNHLFVBQVU7QUFBQSxFQUM1QixHQUFHLENBQUNQLE1BQU0sQ0FBQztBQUNYLFFBQU1RLFdBQVc1QixtQkFBbUJDLFFBQVE7QUFDNUMsUUFBTTRCLFdBQVdBLENBQUNDLFFBQStCO0FBQzdDLFFBQUksQ0FBQ1YsT0FBT1csSUFBSUQsR0FBRyxFQUFHLFFBQU9GLFNBQVNFLFFBQVEsYUFBYSxTQUFTLElBQUk7QUFDeEUsVUFBTWpCLFFBQVFPLE9BQU9ZLElBQUlGLEdBQUc7QUFDNUIsV0FBT2pCLFVBQVUsS0FBSyxLQUFLZCxnQkFBZ0JjLEtBQUssSUFBSUEsUUFBUWUsU0FBU0UsUUFBUSxhQUFhLFNBQVMsSUFBSTtBQUFBLEVBQzNHO0FBQ0EsUUFBTUcsZUFBZUEsQ0FBQ0MsUUFBeUJKLFFBQStCO0FBQzFFLFFBQUksQ0FBQ0ksT0FBT0gsSUFBSUQsR0FBRyxFQUFHLFFBQU9GLFNBQVNFLFFBQVEsYUFBYSxTQUFTLElBQUk7QUFDeEUsVUFBTWpCLFFBQVFxQixPQUFPRixJQUFJRixHQUFHO0FBQzVCLFdBQU9qQixVQUFVLEtBQUssS0FBS2QsZ0JBQWdCYyxLQUFLLElBQUlBLFFBQVFlLFNBQVNFLFFBQVEsYUFBYSxTQUFTLElBQUk7QUFBQSxFQUMzRztBQUNBLFFBQU1LLFFBQVEsRUFBRW5CLE1BQU1hLFNBQVMsVUFBVSxHQUFHWixJQUFJWSxTQUFTLFFBQVEsRUFBRTtBQUNuRSxRQUFNTyxRQUFRckMsZ0JBQWdCb0MsTUFBTW5CLElBQUksS0FBS2pCLGdCQUFnQm9DLE1BQU1sQixFQUFFLEtBQUtrQixNQUFNbkIsT0FBT21CLE1BQU1sQjtBQUM3RixRQUFNb0IsVUFBVUEsQ0FBQ1AsS0FBNEJqQixVQUFrQjtBQUMzRCxVQUFNeUIsT0FBTyxJQUFJZixnQkFBZ0JELGFBQWFLLE9BQU87QUFDckRXLFNBQUtDLE9BQU8sUUFBUTtBQUNwQixVQUFNdkIsT0FBT2MsUUFBUSxhQUFjL0IsZ0JBQWdCYyxLQUFLLElBQUlBLFFBQVEsS0FBTW9CLGFBQWFLLE1BQU0sVUFBVTtBQUN2RyxVQUFNckIsS0FBS2EsUUFBUSxXQUFZL0IsZ0JBQWdCYyxLQUFLLElBQUlBLFFBQVEsS0FBTW9CLGFBQWFLLE1BQU0sUUFBUTtBQUNqR0EsU0FBS0UsSUFBSSxZQUFZeEIsSUFBSTtBQUN6QnNCLFNBQUtFLElBQUksVUFBVXZCLEVBQUU7QUFDckJLLGlCQUFhSyxVQUFVVztBQUN2QmQsa0JBQWNHLFVBQVVXLEtBQUtaLFNBQVM7QUFDdENMLGNBQVVpQixNQUFNLEVBQUVHLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDdkM7QUFDQSxTQUFPO0FBQUEsSUFDSE47QUFBQUEsSUFDQU8sU0FBU0EsQ0FBQzFCLFNBQWlCcUIsUUFBUSxZQUFZckIsSUFBSTtBQUFBLElBQ25EMkIsT0FBT0EsQ0FBQzFCLE9BQWVvQixRQUFRLFVBQVVwQixFQUFFO0FBQUEsSUFDM0NtQjtBQUFBQSxJQUNBUSxPQUFPO0FBQUEsTUFDSDVCLE1BQU1vQixRQUFRdEMsOEJBQThCcUMsTUFBTW5CLE1BQU1mLFFBQVEsSUFBSTtBQUFBLE1BQ3BFZ0IsSUFBSW1CLFFBQVF0Qyw4QkFBOEJxQyxNQUFNbEIsSUFBSWhCLFFBQVEsSUFBSTtBQUFBLE1BQ2hFQTtBQUFBQSxJQUNKO0FBQUEsRUFDSjtBQUNKO0FBQUNrQixHQTdDZUQsZ0JBQWM7QUFBQSxVQUNFekIsZUFBZTtBQUFBO0FBNkN4QyxnQkFBU29ELGtCQUFrQixFQUFFVixPQUFPbEMsVUFBVXlDLFNBQVNDLE1BQW1JLEdBQUc7QUFDaE0sU0FBTyx1QkFBQyxjQUFXLFdBQVcsRUFBRUcsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxVQUFTLFdBQ2hFO0FBQUEsMkJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxXQUFVLE9BQU9aLE1BQU1uQixNQUFNLFVBQVUsQ0FBQWdDLFVBQVNOLFFBQVFNLE1BQU1DLE9BQU9wQyxLQUFLLEdBQUcsV0FBVyxFQUFFcUMsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxLQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNKO0FBQUEsSUFDdEosdUJBQUMsYUFBVSxNQUFLLFFBQU8sT0FBTSxrQkFBaUIsT0FBT2hCLE1BQU1sQixJQUFJLFVBQVUsQ0FBQStCLFVBQVNMLE1BQU1LLE1BQU1DLE9BQU9wQyxLQUFLLEdBQUcsV0FBVyxFQUFFcUMsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlKO0FBQUEsSUFDekosdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSSxFQUFFQyxZQUFZLFNBQVMsR0FBRztBQUFBO0FBQUEsTUFBMkJuRDtBQUFBQSxNQUFTO0FBQUEsU0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRjtBQUFBLE9BSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJUDtBQUNKO0FBQUNvRCxLQU5lUjtBQUFpQixJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTZWFyY2hQYXJhbXMiLCJBbGVydCIsIlRleHRGaWVsZCIsIkZvcm1GaWVsZHMiLCJkYXRlT25seUluVGltZXpvbmUiLCJkYXRlT25seVN0YXJ0T2ZEYXlUb0lTT1N0cmluZyIsImlzVmFsaWREYXRlT25seSIsInByZXZpb3VzTW9udGhSYW5nZSIsInRpbWV6b25lIiwieWVhclRleHQiLCJtb250aFRleHQiLCJEYXRlIiwic3BsaXQiLCJ5ZWFyIiwiTnVtYmVyIiwibW9udGgiLCJlbmQiLCJVVEMiLCJzdGFydCIsImRhdGVPbmx5IiwidmFsdWUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiZnJvbSIsInRvIiwidXNlUmVwb3J0UmFuZ2UiLCJfcyIsInBhcmFtcyIsInNldFBhcmFtcyIsImxhdGVzdFBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInBlbmRpbmdTZWFyY2giLCJjb21taXR0ZWRTZWFyY2giLCJ0b1N0cmluZyIsImN1cnJlbnQiLCJkZWZhdWx0cyIsInJlYWREYXRlIiwia2V5IiwiaGFzIiwiZ2V0IiwicmVhZERhdGVGcm9tIiwic291cmNlIiwicmFuZ2UiLCJ2YWxpZCIsInNldERhdGUiLCJuZXh0IiwiZGVsZXRlIiwic2V0IiwiZmx1c2hTeW5jIiwic2V0RnJvbSIsInNldFRvIiwicXVlcnkiLCJSZXBvcnRSYW5nZUZpZWxkcyIsInhzIiwic20iLCJldmVudCIsInRhcmdldCIsImlucHV0TGFiZWwiLCJzaHJpbmsiLCJhbGlnbkl0ZW1zIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsicmVwb3J0LXJhbmdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZUVmZmVjdCx1c2VSZWZ9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHt1c2VTZWFyY2hQYXJhbXN9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQge0FsZXJ0LFRleHRGaWVsZH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCB7Rm9ybUZpZWxkc30gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQge2RhdGVPbmx5SW5UaW1lem9uZSxkYXRlT25seVN0YXJ0T2ZEYXlUb0lTT1N0cmluZyxpc1ZhbGlkRGF0ZU9ubHl9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XHJcbmZ1bmN0aW9uIHByZXZpb3VzTW9udGhSYW5nZSh0aW1lem9uZTogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBbeWVhclRleHQgPSAnJywgbW9udGhUZXh0ID0gJyddID0gZGF0ZU9ubHlJblRpbWV6b25lKG5ldyBEYXRlKCksIHRpbWV6b25lKS5zcGxpdCgnLScpO1xyXG4gICAgY29uc3QgeWVhciA9IE51bWJlcih5ZWFyVGV4dCksIG1vbnRoID0gTnVtYmVyKG1vbnRoVGV4dCk7XHJcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShEYXRlLlVUQyh5ZWFyLCBtb250aCAtIDEsIDEpKTtcclxuICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoRGF0ZS5VVEMoeWVhciwgbW9udGggLSAyLCAxKSk7XHJcbiAgICBjb25zdCBkYXRlT25seSA9ICh2YWx1ZTogRGF0ZSkgPT4gdmFsdWUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbiAgICByZXR1cm4geyBmcm9tOiBkYXRlT25seShzdGFydCksIHRvOiBkYXRlT25seShlbmQpIH07XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZVJlcG9ydFJhbmdlKHRpbWV6b25lOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICAgIGNvbnN0IGxhdGVzdFBhcmFtcyA9IHVzZVJlZihuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcykpO1xyXG4gICAgY29uc3QgcGVuZGluZ1NlYXJjaCA9IHVzZVJlZjxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY29tbWl0dGVkU2VhcmNoID0gcGFyYW1zLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgaWYgKHBlbmRpbmdTZWFyY2guY3VycmVudCAhPT0gbnVsbCAmJiBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgIT09IGNvbW1pdHRlZFNlYXJjaCkgcmV0dXJuO1xyXG4gICAgICAgIGxhdGVzdFBhcmFtcy5jdXJyZW50ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpO1xyXG4gICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG51bGw7XHJcbiAgICB9LCBbcGFyYW1zXSk7XHJcbiAgICBjb25zdCBkZWZhdWx0cyA9IHByZXZpb3VzTW9udGhSYW5nZSh0aW1lem9uZSk7XHJcbiAgICBjb25zdCByZWFkRGF0ZSA9IChrZXk6ICdmcm9tRGF0ZScgfCAndG9EYXRlJykgPT4ge1xyXG4gICAgICAgIGlmICghcGFyYW1zLmhhcyhrZXkpKSByZXR1cm4gZGVmYXVsdHNba2V5ID09PSAnZnJvbURhdGUnID8gJ2Zyb20nIDogJ3RvJ107XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSBwYXJhbXMuZ2V0KGtleSk7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlID09PSAnJyA/ICcnIDogaXNWYWxpZERhdGVPbmx5KHZhbHVlKSA/IHZhbHVlIDogZGVmYXVsdHNba2V5ID09PSAnZnJvbURhdGUnID8gJ2Zyb20nIDogJ3RvJ107XHJcbiAgICB9O1xyXG4gICAgY29uc3QgcmVhZERhdGVGcm9tID0gKHNvdXJjZTogVVJMU2VhcmNoUGFyYW1zLCBrZXk6ICdmcm9tRGF0ZScgfCAndG9EYXRlJykgPT4ge1xyXG4gICAgICAgIGlmICghc291cmNlLmhhcyhrZXkpKSByZXR1cm4gZGVmYXVsdHNba2V5ID09PSAnZnJvbURhdGUnID8gJ2Zyb20nIDogJ3RvJ107XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSBzb3VyY2UuZ2V0KGtleSk7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlID09PSAnJyA/ICcnIDogaXNWYWxpZERhdGVPbmx5KHZhbHVlKSA/IHZhbHVlIDogZGVmYXVsdHNba2V5ID09PSAnZnJvbURhdGUnID8gJ2Zyb20nIDogJ3RvJ107XHJcbiAgICB9O1xyXG4gICAgY29uc3QgcmFuZ2UgPSB7IGZyb206IHJlYWREYXRlKCdmcm9tRGF0ZScpLCB0bzogcmVhZERhdGUoJ3RvRGF0ZScpIH07XHJcbiAgICBjb25zdCB2YWxpZCA9IGlzVmFsaWREYXRlT25seShyYW5nZS5mcm9tKSAmJiBpc1ZhbGlkRGF0ZU9ubHkocmFuZ2UudG8pICYmIHJhbmdlLmZyb20gPCByYW5nZS50bztcclxuICAgIGNvbnN0IHNldERhdGUgPSAoa2V5OiAnZnJvbURhdGUnIHwgJ3RvRGF0ZScsIHZhbHVlOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsYXRlc3RQYXJhbXMuY3VycmVudCk7XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2N1cnNvcicpO1xyXG4gICAgICAgIGNvbnN0IGZyb20gPSBrZXkgPT09ICdmcm9tRGF0ZScgPyAoaXNWYWxpZERhdGVPbmx5KHZhbHVlKSA/IHZhbHVlIDogJycpIDogcmVhZERhdGVGcm9tKG5leHQsICdmcm9tRGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IHRvID0ga2V5ID09PSAndG9EYXRlJyA/IChpc1ZhbGlkRGF0ZU9ubHkodmFsdWUpID8gdmFsdWUgOiAnJykgOiByZWFkRGF0ZUZyb20obmV4dCwgJ3RvRGF0ZScpO1xyXG4gICAgICAgIG5leHQuc2V0KCdmcm9tRGF0ZScsIGZyb20pO1xyXG4gICAgICAgIG5leHQuc2V0KCd0b0RhdGUnLCB0byk7XHJcbiAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXh0O1xyXG4gICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG5leHQudG9TdHJpbmcoKTtcclxuICAgICAgICBzZXRQYXJhbXMobmV4dCwgeyBmbHVzaFN5bmM6IHRydWUgfSk7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICByYW5nZSxcclxuICAgICAgICBzZXRGcm9tOiAoZnJvbTogc3RyaW5nKSA9PiBzZXREYXRlKCdmcm9tRGF0ZScsIGZyb20pLFxyXG4gICAgICAgIHNldFRvOiAodG86IHN0cmluZykgPT4gc2V0RGF0ZSgndG9EYXRlJywgdG8pLFxyXG4gICAgICAgIHZhbGlkLFxyXG4gICAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgICAgIGZyb206IHZhbGlkID8gZGF0ZU9ubHlTdGFydE9mRGF5VG9JU09TdHJpbmcocmFuZ2UuZnJvbSwgdGltZXpvbmUpIDogJycsXHJcbiAgICAgICAgICAgIHRvOiB2YWxpZCA/IGRhdGVPbmx5U3RhcnRPZkRheVRvSVNPU3RyaW5nKHJhbmdlLnRvLCB0aW1lem9uZSkgOiAnJyxcclxuICAgICAgICAgICAgdGltZXpvbmUsXHJcbiAgICAgICAgfSxcclxuICAgIH07XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFJlcG9ydFJhbmdlRmllbGRzKHsgcmFuZ2UsIHRpbWV6b25lLCBzZXRGcm9tLCBzZXRUbyB9OiB7IHJhbmdlOiB7IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9OyB0aW1lem9uZTogc3RyaW5nOyBzZXRGcm9tOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDsgc2V0VG86ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkIH0pIHtcclxuICAgIHJldHVybiA8Rm9ybUZpZWxkcyBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gYWZ0ZXJHYXA9XCJzZWN0aW9uXCI+XHJcbiAgICAgICAgPFRleHRGaWVsZCB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwiVOG7qyBuZ8OgeVwiIHZhbHVlPXtyYW5nZS5mcm9tfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0RnJvbShldmVudC50YXJnZXQudmFsdWUpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fS8+XHJcbiAgICAgICAgPFRleHRGaWVsZCB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwixJDhur9uIHRyxrDhu5tjIG5nw6B5XCIgdmFsdWU9e3JhbmdlLnRvfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0VG8oZXZlbnQudGFyZ2V0LnZhbHVlKX0gc2xvdFByb3BzPXt7IGlucHV0TGFiZWw6IHsgc2hyaW5rOiB0cnVlIH0gfX0vPlxyXG4gICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17eyBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5LaG/huqNuZyBbVOG7qywgxJDhur9uKTsgbcO6aSBnaeG7nSB7dGltZXpvbmV9LjwvQWxlcnQ+XHJcbiAgICA8L0Zvcm1GaWVsZHM+O1xyXG59XHJcbiJdLCJmaWxlIjoiL2hvbWUvcnVubmVyL3dvcmsvQm90LUFJLUJhbi1oYW5nLUZCL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2ZpbmFuY2UvcmVwb3J0LXJhbmdlLnRzeCJ9