import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/reports/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-15083-26c7a12e-3884-4e56-baba-40fd2e2345e4/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-15083-26c7a12e-3884-4e56-baba-40fd2e2345e4/deps/react.js?v=f9568e8d"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-15083-26c7a12e-3884-4e56-baba-40fd2e2345e4/deps/react-router-dom.js?v=f9568e8d";
import { Alert, Box, Button, Link, MenuItem, Stack, TextField, Typography } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-15083-26c7a12e-3884-4e56-baba-40fd2e2345e4/deps/@mui_material.js?v=f9568e8d";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-15083-26c7a12e-3884-4e56-baba-40fd2e2345e4/deps/recharts.js?v=f9568e8d";
import { colors, tokens } from "/@fs/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime, formatDateOnly, isValidDateOnly } from "/src/shared/model/format.ts";
import { Amount, DataTable, DetailLine, ErrorNotice, PageHeader, Panel, Pager, QueryState, RouteLink, Stat, Stats, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { authorizedDownloadHref, dateInTimezone, reportDateBoundary, reportFilename } from "/src/modules/reports/report-utils.ts";
const reportLabels = {
  inventory: "Tồn kho",
  orders: "Đơn hàng",
  cashflow: "Dòng tiền",
  profit_loss: "Lợi nhuận"
};
const sourcePermissions = {
  inventory: "inventory.read",
  orders: "orders.read",
  cashflow: "finance.read",
  profit_loss: "finance.read"
};
function MarketingReasonTick({ x = 0, y = 0, payload }) {
  const value = typeof payload?.value === "string" ? payload.value.trim() : "";
  const lines = [];
  let line = "";
  for (const word of value.split(/\s+/u).filter(Boolean)) {
    const pieces = [...word];
    while (pieces.length) {
      const piece = pieces.splice(0, 8).join("");
      const candidate = line ? `${line} ${piece}` : piece;
      if (line && [...candidate].length > 8) {
        lines.push(line);
        line = piece;
      } else {
        line = candidate;
      }
    }
  }
  if (line) lines.push(line);
  return /* @__PURE__ */ jsxDEV("text", { x, y, dy: 12, textAnchor: "middle", fill: colors.textSecondary, fontSize: tokens.fontSizes.body, children: lines.map((text, index) => /* @__PURE__ */ jsxDEV("tspan", { x, dy: index ? 14 : 0, children: [
    text,
    index < lines.length - 1 ? " " : ""
  ] }, `${index}-${text}`, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 63,
    columnNumber: 37
  }, this)) }, void 0, false, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
}
_c = MarketingReasonTick;
export function ReportsPage() {
  _s();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const latestParams = useRef(new URLSearchParams(params));
  const pendingSearch = useRef(null);
  useEffect(() => {
    const committedSearch = params.toString();
    if (pendingSearch.current !== null && pendingSearch.current !== committedSearch) return;
    latestParams.current = new URLSearchParams(params);
    pendingSearch.current = null;
  }, [params]);
  const summary = useApi("getReportSummary");
  const canReadJobs = useCan("jobs.read");
  const jobs = useApi("listJobs", { query: { limit: 10, cursor: params.get("cursor") || void 0 } }, canReadJobs);
  const run = useCommand("createExport", ["listJobs"]);
  const requestedType = params.get("reportType");
  const type = requestedType === "inventory" || requestedType === "cashflow" || requestedType === "profit_loss" ? requestedType : "orders";
  const snapshotAsOf = summary.data?.data.asOf;
  const defaultRange = useMemo(() => {
    if (!snapshotAsOf) return null;
    try {
      const currentDate = dateInTimezone(snapshotAsOf, shop.timezone);
      return { fromDate: `${currentDate.slice(0, 7)}-01`, toDate: currentDate };
    } catch {
      return null;
    }
  }, [shop.timezone, snapshotAsOf]);
  const fromValue = params.get("fromDate");
  const toValue = params.get("toDate");
  const readReportDate = (key, value) => {
    if (isValidDateOnly(value)) return value;
    if (params.has(key) && value === "") return "";
    return defaultRange?.[key] || "";
  };
  const from = readReportDate("fromDate", fromValue);
  const to = readReportDate("toDate", toValue);
  const setReportParam = (key, value) => {
    const next = new URLSearchParams(latestParams.current);
    if (key === "reportType") next.set(key, value);
    else
      next.set(key, isValidDateOnly(value) ? value : "");
    latestParams.current = next;
    pendingSearch.current = next.toString();
    setParams(next, { flushSync: true });
  };
  const [rangeError, setRangeError] = useState("");
  const [lastExport, setLastExport] = useState(null);
  const canExportReports = useCan("reports.export");
  const canExportSource = useCan(sourcePermissions[type]);
  const availableReports = summary.data?.data.availableReports || [];
  const reportAvailable = availableReports.includes(type);
  useEffect(() => {
    if (!snapshotAsOf) return;
    if (!defaultRange) {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
      return;
    }
    try {
      const next = new URLSearchParams(latestParams.current);
      let changed = false;
      if (requestedType !== "inventory" && requestedType !== "cashflow" && requestedType !== "profit_loss" && requestedType !== "orders") {
        next.set("reportType", "orders");
        changed = true;
      }
      if (!params.has("fromDate") || fromValue && !isValidDateOnly(fromValue)) {
        next.set("fromDate", defaultRange.fromDate);
        changed = true;
      }
      if (!params.has("toDate") || toValue && !isValidDateOnly(toValue)) {
        next.set("toDate", defaultRange.toDate);
        changed = true;
      }
      if (changed) {
        latestParams.current = next;
        pendingSearch.current = next.toString();
        setParams(next, { replace: true, flushSync: true });
      }
    } catch {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
    }
  }, [defaultRange, params, requestedType, fromValue, toValue, setParams, snapshotAsOf]);
  const submit = async () => {
    setRangeError("");
    try {
      if (!snapshotAsOf || !from || !to) throw new RangeError("Chưa có snapshot hoặc khoảng ngày đầy đủ.");
      const request = {
        reportType: type,
        format: "csv",
        from: reportDateBoundary(from, "start", shop.timezone),
        to: reportDateBoundary(to, "end", shop.timezone),
        timezone: shop.timezone,
        snapshotAsOf
      };
      setLastExport(null);
      const response = await run.execute({ body: request });
      setLastExport({ job: response.data, type, from, to });
    } catch (error) {
      if (error instanceof RangeError) setRangeError(error.message);
    }
  };
  const handleExport = () => {
    void submit();
  };
  const lastDownload = lastExport?.job.status === "succeeded" && lastExport.job.downloadUrl ? authorizedDownloadHref(lastExport.job.downloadUrl, location.origin, __MOCK__) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Báo cáo & xuất dữ liệu", subtitle: "Xuất snapshot do API tạo; số liệu tổng hợp không được tính từ một trang danh sách." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 174,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "reports-main-layout", columns: { xs: "minmax(0, 1fr)", xl: "minmax(0, 1.2fr) minmax(0, .8fr)" }, alignItems: "start", geometry: { minWidth: 0 }, children: [
      /* @__PURE__ */ jsxDEV(PageSections, { "data-testid": "reports-page-sections", children: [
        /* @__PURE__ */ jsxDEV(QueryState, { query: summary, pendingProfile: "section", children: summary.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Tạo tệp báo cáo", subtitle: "Ngày được hiểu theo múi giờ cửa hàng và gửi thành mốc thời gian rõ ràng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-export-form-layout", geometry: { maxWidth: 760 }, children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: run.error }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 180,
            columnNumber: 29
          }, this),
          rangeError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: rangeError }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 181,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Báo cáo", select: true, value: type, onChange: (event) => {
            const value = event.target.value;
            if (value === "orders" || value === "inventory" || value === "cashflow" || value === "profit_loss") setReportParam("reportType", value);
            setLastExport(null);
          }, children: availableReports.map((report) => /* @__PURE__ */ jsxDEV(MenuItem, { value: report, children: reportLabels[report] }, report, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 187,
            columnNumber: 67
          }, this)) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 182,
            columnNumber: 29
          }, this),
          availableReports.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại chưa có loại báo cáo khả dụng." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 189,
            columnNumber: 63
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-date-filters", direction: { xs: "column", sm: "row" }, children: [
            /* @__PURE__ */ jsxDEV(TextField, { label: "Từ ngày", type: "date", value: from, onChange: (event) => setReportParam("fromDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 191,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Đến ngày", type: "date", value: to, onChange: (event) => setReportParam("toDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 192,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 190,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Múi giờ", children: shop.timezone }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 194,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Snapshot API", children: snapshotAsOf ? dateTime(snapshotAsOf, shop.timezone) : "Chưa có snapshot" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 195,
            columnNumber: 29
          }, this),
          !canExportReports && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vai trò hiện tại không có quyền reports.export." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 196,
            columnNumber: 51
          }, this),
          canExportReports && !canExportSource && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
            "Quyền xuất không thay thế quyền đọc nguồn ",
            sourcePermissions[type],
            "; loại báo cáo này chưa thể xuất."
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 197,
            columnNumber: 70
          }, this),
          canExportReports && canExportSource && !reportAvailable && availableReports.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "API không liệt kê loại báo cáo này cho vai trò hiện tại." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 198,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: handleExport, disabled: !canExportReports || !canExportSource || !reportAvailable || !snapshotAsOf || !from || !to || from > to || run.pending, children: run.pending ? "Đang tạo snapshot…" : "Tạo tệp báo cáo CSV" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 199,
            columnNumber: 29
          }, this),
          lastExport && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "center" }, children: [
            /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${lastExport.job.id}`, children: [
              "Theo dõi công việc ",
              lastExport.job.id
            ] }, void 0, true, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 203,
              columnNumber: 33
            }, this),
            lastDownload && /* @__PURE__ */ jsxDEV(Link, { "data-testid": "reports-export-download", component: "a", href: lastDownload, download: reportFilename(lastExport.type, lastExport.from, lastExport.to), underline: "none", sx: [layoutSx.actions.linkTarget, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control, color: "text.primary", fontWeight: visualSx.typography.fontWeight.semibold, "&:hover": { bgcolor: "action.hover", textDecoration: "none" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: "Tải CSV" }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 204,
              columnNumber: 50
            }, this),
            lastExport.job.status !== "succeeded" && /* @__PURE__ */ jsxDEV(Alert, { severity: lastExport.job.status === "partial" || lastExport.job.status === "failed" ? "warning" : "info", children: "Tệp chỉ được tải khi công việc xác nhận succeeded." }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 205,
              columnNumber: 75
            }, this),
            lastExport.job.status === "succeeded" && lastExport.job.downloadUrl && !lastDownload && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không hợp lệ hoặc chưa thuộc HTTPS/nguồn hiện tại." }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 206,
              columnNumber: 122
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 202,
            columnNumber: 44
          }, this),
          summary.data.data.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: warning }, `${index}-${warning}`, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 208,
            columnNumber: 81
          }, this)),
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "API hiện chỉ trả danh sách loại báo cáo và thời điểm snapshot; bộ lọc ngày áp dụng cho lệnh xuất. Không có series hoặc tổng số liệu để giao diện tự suy ra." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 209,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 179,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 178,
          columnNumber: 38
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 177,
          columnNumber: 17
        }, this),
        canReadJobs ? /* @__PURE__ */ jsxDEV(QueryState, { query: jobs, pendingProfile: "section", children: jobs.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Công việc gần đây", subtitle: "Trạng thái và tiến độ lấy từ API; trang hiện tại có thể chứa nhiều loại công việc.", children: [
          /* @__PURE__ */ jsxDEV(DataTable, { rows: jobs.data.data, rowKey: (job) => job.id, label: "Công việc gần đây", empty: "Chưa có công việc trong trang này.", columns: [
            { key: "id", label: "Mã công việc", render: (job) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${job.id}`, children: job.id }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 216,
              columnNumber: 66
            }, this) },
            { key: "kind", label: "Loại", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.kind }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 217,
              columnNumber: 60
            }, this) },
            { key: "status", label: "Trạng thái", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 218,
              columnNumber: 68
            }, this) },
            { key: "progress", label: "Tiến độ", align: "right", render: (job) => `${job.completed} / ${job.total ?? "Chưa biết"}` },
            { key: "updatedAt", label: "Cập nhật", render: (job) => dateTime(job.updatedAt, shop.timezone) }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 215,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: jobs.data.page }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 222,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 214,
          columnNumber: 35
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 213,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có jobs.read; trạng thái công việc được ẩn theo quyền." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 224,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 176,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Phạm vi dữ liệu", subtitle: "Chỉ những gì API cung cấp mới được trình bày như số liệu.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.report.contextGap, children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Báo cáo dòng, biểu đồ và tổng hợp theo khoảng ngày chưa có trong getReportSummary. Frontend không cộng dữ liệu phân trang để tạo KPI thay thế." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 228,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Trạng thái export được lấy riêng từ listJobs; URL tải chỉ được mở sau khi API trả về công việc hoàn tất." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 229,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/reports/marketing`, children: "Xem thông tin marketing" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 230,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 227,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 226,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 175,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 173,
    columnNumber: 10
  }, this);
}
_s(ReportsPage, "DFyE6kGn/WrimxAHqu/xbuEgHPg=", false, function() {
  return [useScope, useSearchParams, useApi, useCan, useApi, useCommand, useCan, useCan];
});
_c2 = ReportsPage;
export function MarketingPage() {
  _s2();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const search = params.toString();
  const fromParam = params.get("fromDate") || "";
  const toParam = params.get("toDate") || "";
  const bucketParam = params.get("bucket") || "day";
  const hasDateFilter = params.has("fromDate") || params.has("toDate");
  const appliedError = marketingRangeError(fromParam, toParam, bucketParam, !hasDateFilter);
  const query = appliedError ? void 0 : {
    ...params.has("fromDate") ? { fromDate: fromParam } : {},
    ...params.has("toDate") ? { toDate: toParam } : {},
    ...params.has("bucket") ? { bucket: bucketParam } : {}
  };
  const data = useApi("getMarketingSummary", query && Object.keys(query).length ? { query } : void 0, !appliedError);
  const m = data.data?.data;
  const marketingPeriod = m?.period;
  const [draft, setDraft] = useState({ fromDate: fromParam, toDate: toParam, bucket: bucketParam });
  const [showFilterError, setShowFilterError] = useState(false);
  const fromRef = useRef(null);
  const toRef = useRef(null);
  const bucketRef = useRef(null);
  const draftError = marketingRangeError(draft.fromDate, draft.toDate, draft.bucket, false);
  const visibleFilterError = showFilterError ? draftError : appliedError;
  useEffect(() => {
    if (marketingPeriod) {
      setDraft({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      const next = new URLSearchParams({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      if (next.toString() !== search) setParams(next, { replace: true });
    }
  }, [marketingPeriod, search, setParams]);
  useEffect(() => {
    const current = new URLSearchParams(search);
    if (!current.has("fromDate") && !current.has("toDate")) return;
    setDraft({ fromDate: current.get("fromDate") || "", toDate: current.get("toDate") || "", bucket: current.get("bucket") || "day" });
    setShowFilterError(false);
  }, [search]);
  const applyFilter = (event) => {
    event.preventDefault();
    setShowFilterError(true);
    if (draftError) {
      const target = draftError.field === "fromDate" ? fromRef.current : draftError.field === "toDate" ? toRef.current : bucketRef.current;
      target?.focus();
      return;
    }
    const next = new URLSearchParams({ fromDate: draft.fromDate, toDate: draft.toDate, bucket: draft.bucket });
    setShowFilterError(false);
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thông tin cho marketing", subtitle: "Đề xuất chỉ đọc; trang không tự đăng nội dung hoặc thay đổi ngân sách." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 291,
      columnNumber: 9
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Số liệu mẫu do API mô phỏng tổng hợp; chưa kết nối tài khoản quảng cáo hoặc nguồn phân bổ thật." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 292,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Khoảng thời gian báo cáo", subtitle: `Ngày được tính theo lịch ${shop.timezone} của cửa hàng.`, bodyMode: "inset", afterGap: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", onSubmit: applyFilter, "data-testid": "marketing-range-form", children: [
      /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "flex-end" }, sx: layoutSx.toolbar.controlGap, children: [
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: fromRef, type: "date", label: "Từ ngày", value: draft.fromDate, onChange: (event) => setDraft((value) => ({ ...value, fromDate: event.target.value })), slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "fromDate", helperText: visibleFilterError?.field === "fromDate" ? visibleFilterError.message : "Ngày bắt đầu, tính cả ngày đã chọn." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 296,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: toRef, type: "date", label: "Đến ngày", value: draft.toDate, onChange: (event) => setDraft((value) => ({ ...value, toDate: event.target.value })), slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "toDate", helperText: visibleFilterError?.field === "toDate" ? visibleFilterError.message : "Tối đa 366 ngày, tính cả hai đầu." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 297,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: bucketRef, select: true, label: "Gộp theo", value: draft.bucket, onChange: (event) => setDraft((value) => ({ ...value, bucket: event.target.value })), error: visibleFilterError?.field === "bucket", helperText: visibleFilterError?.field === "bucket" ? visibleFilterError.message : "Chọn ngày, tuần hoặc tháng.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "day", children: "Ngày" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 299,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "week", children: "Tuần" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 299,
            columnNumber: 62
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "month", children: "Tháng" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 299,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 298,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", children: "Áp dụng" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 301,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 295,
        columnNumber: 17
      }, this),
      showFilterError && draftError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: draftError.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 303,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 294,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 293,
      columnNumber: 9
    }, this),
    appliedError ? /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Bộ lọc trên đường dẫn không hợp lệ." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 306,
        columnNumber: 62
      }, this),
      " Hãy sửa trường được đánh dấu trước khi áp dụng."
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 306,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: m && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn có nguồn xác định", value: m.knownAttributedOrders, note: "Được API tổng hợp trong kỳ" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 308,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn chưa rõ nguồn", value: m.unknownAttributionOrders, note: "Giữ riêng, không tự gán nguồn" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 309,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo thực tế", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.actualSpend }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 310,
          columnNumber: 60
        }, this), note: m.actualSpend ? "API cung cấp số thực tế" : "Kỳ này chưa có số thực tế từ API" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 310,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo ước tính", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.estimatedSpend }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 311,
          columnNumber: 61
        }, this), note: "Ước tính không phải số ghi sổ" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 311,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 307,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "marketing-as-of", sx: [layoutSx.report.contextGap, layoutSx.page.sectionAfter], children: [
        m.period && /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
          "Kỳ ",
          formatDateOnly(m.period.fromDate),
          " – ",
          formatDateOnly(m.period.toDate),
          " · gộp theo ",
          m.period.bucket === "day" ? "ngày" : m.period.bucket === "week" ? "tuần" : "tháng"
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 314,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Cập nhật ",
          dateTime(m.asOf, m.period?.timezone || shop.timezone),
          " · ",
          shop.name,
          " · múi giờ ",
          m.period?.timezone || shop.timezone
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 315,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 313,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "marketing-sections-grid", columns: { xs: "1fr", lg: "1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV(Panel, { title: "Đơn theo thời gian", subtitle: "Số đơn có nguồn xác định và chưa rõ nguồn do API tổng hợp.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Số đơn theo ${m.period?.bucket || "kỳ"} trong khoảng đã chọn`, "data-testid": "marketing-trend-chart", sx: [{ height: 280 }, layoutSx.report.chartViewportInset], children: m.trend?.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.trend, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 321,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "fromDate", stroke: colors.textSecondary, interval: Math.max(0, Math.ceil(m.trend.length / 7) - 1), tickFormatter: (value) => formatDateOnly(String(value)) }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 322,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 323,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { labelFormatter: (value) => formatDateOnly(String(value)), contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 324,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 325,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "knownAttributedOrders", name: "Có nguồn xác định", fill: colors.accent, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 326,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "unknownAttributionOrders", name: "Chưa rõ nguồn", fill: colors.textSecondary, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 327,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 320,
            columnNumber: 92
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 320,
            columnNumber: 44
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "API chưa có bucket dữ liệu trong kỳ đã chọn." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 328,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 319,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Tổng hợp marketing theo kỳ", rows: m.trend || [], rowKey: (point) => point.fromDate, empty: "Chưa có dữ liệu theo kỳ trong khoảng này.", columns: [
            { key: "range", label: "Khoảng ngày", render: (point) => `${formatDateOnly(point.fromDate)} – ${formatDateOnly(point.toDate)}` },
            { key: "known", label: "Có nguồn", align: "right", render: (point) => point.knownAttributedOrders },
            { key: "unknown", label: "Chưa rõ nguồn", align: "right", render: (point) => point.unknownAttributionOrders },
            { key: "estimated", label: "Chi ước tính", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.estimatedSpend }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 334,
              columnNumber: 91
            }, this) },
            { key: "actual", label: "Chi thực tế", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.actualSpend }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 335,
              columnNumber: 87
            }, this) }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 330,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 318,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Câu hỏi khách thường hỏi", subtitle: "Các mục do API tổng hợp cung cấp.", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "marketing-question-surface", sx: layoutSx.report.listSurfaceInset, children: /* @__PURE__ */ jsxDEV(Stack, { component: "ul", "data-testid": "marketing-top-questions", sx: [{ m: 0, p: 0 }, layoutSx.report.listMarkerInset, layoutSx.report.listItemGap], children: m.topQuestions.length ? m.topQuestions.map((question, index) => /* @__PURE__ */ jsxDEV(Typography, { component: "li", children: question }, `${index}-${question}`, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 341,
          columnNumber: 94
        }, this)) : /* @__PURE__ */ jsxDEV(Typography, { component: "li", color: "text.secondary", children: "Chưa có thống kê câu hỏi trong kỳ đã chọn." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 341,
          columnNumber: 177
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 340,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 339,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 338,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Lý do không chốt đơn", subtitle: "Biểu đồ và bảng dùng cùng một payload API.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Biểu đồ lý do không chốt đơn, ${m.lostSaleReasons.length} nhóm`, "data-testid": "marketing-loss-chart", sx: [{ height: 260 }, layoutSx.report.chartViewportInset], children: m.lostSaleReasons.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.lostSaleReasons, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 348,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "reason", stroke: colors.textSecondary, interval: 0, height: 64, tick: /* @__PURE__ */ jsxDEV(MarketingReasonTick, {}, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 349,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 349,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 350,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 351,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "count", name: "Số trường hợp", fill: colors.accent, radius: [4, 4, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 352,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 347,
            columnNumber: 101
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 347,
            columnNumber: 53
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "Chưa có lý do mất đơn trong kỳ này." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 353,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 346,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { rows: m.lostSaleReasons, rowKey: (reason) => reason.reason, label: "Lý do không chốt đơn", empty: "Chưa có lý do mất đơn trong kỳ đã chọn.", columns: [
            { key: "reason", label: "Lý do", render: (reason) => reason.reason },
            { key: "count", label: "Số trường hợp", align: "right", render: (reason) => reason.count }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 355,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 345,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 317,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.page.sectionBefore, children: "Không tự gán nguồn cho đơn thiếu dữ liệu, không ghi chi ước tính thành chi thực tế và không tự đăng nội dung hoặc tăng ngân sách." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 361,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 306,
      columnNumber: 229
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 306,
      columnNumber: 173
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 290,
    columnNumber: 10
  }, this);
}
_s2(MarketingPage, "XHRcSz0e7gB/5wuA5gDL5DvZ7FM=", false, function() {
  return [useScope, useSearchParams, useApi];
});
_c3 = MarketingPage;
function marketingRangeError(fromDate, toDate, bucket, allowDefault) {
  if (!["day", "week", "month"].includes(bucket)) return { field: "bucket", message: "Chọn nhóm ngày, tuần hoặc tháng." };
  if (allowDefault && !fromDate && !toDate) return null;
  if (!isValidDateOnly(fromDate)) return { field: "fromDate", message: "Nhập ngày bắt đầu hợp lệ." };
  if (!isValidDateOnly(toDate)) return { field: "toDate", message: "Nhập ngày kết thúc hợp lệ." };
  if (fromDate > toDate) return { field: "fromDate", message: "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc." };
  const days = Math.floor((Date.parse(`${toDate}T00:00:00.000Z`) - Date.parse(`${fromDate}T00:00:00.000Z`)) / (24 * 60 * 60 * 1e3)) + 1;
  if (days > 366) return { field: "toDate", message: "Khoảng báo cáo không được vượt quá 366 ngày." };
  return null;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "MarketingReasonTick");
$RefreshReg$(_c2, "ReportsPage");
$RefreshReg$(_c3, "MarketingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNvQyxTQThHekIsVUE5R3lCOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDcEMsU0FBU0EsYUFBYUMsWUFBWUMsY0FBY0MsbUJBQW1CO0FBQ25FLFNBQVNDLFdBQVdDLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUVyRCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLE9BQU9DLEtBQUtDLFFBQVFDLE1BQU1DLFVBQVVDLE9BQU9DLFdBQVdDLGtCQUFrQjtBQUNqRixTQUFTQyxLQUFLQyxVQUFVQyxlQUFlQyxRQUFRQyxxQkFBcUJDLFNBQVNDLE9BQU9DLGFBQWE7QUFFakcsU0FBU0MsUUFBUUMsY0FBYztBQUMvQixTQUFTQyxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxVQUFVQyxnQkFBZ0JDLHVCQUF1QjtBQUMxRCxTQUFTQyxRQUFRQyxXQUFXQyxZQUFZQyxhQUFhQyxZQUFZQyxPQUFPQyxPQUFPQyxZQUFZQyxXQUFXQyxNQUFNQyxPQUFPQyxjQUFjO0FBQ2pJLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx3QkFBd0JDLGdCQUFnQkMsb0JBQW9CQyxzQkFBc0I7QUFFM0YsTUFBTUMsZUFBNEQ7QUFBQSxFQUM5REMsV0FBVztBQUFBLEVBQVdDLFFBQVE7QUFBQSxFQUFZQyxVQUFVO0FBQUEsRUFBYUMsYUFBYTtBQUNsRjtBQUNBLE1BQU1DLG9CQUFpRTtBQUFBLEVBQ25FSixXQUFXO0FBQUEsRUFBa0JDLFFBQVE7QUFBQSxFQUFlQyxVQUFVO0FBQUEsRUFBZ0JDLGFBQWE7QUFDL0Y7QUFFQSxTQUFTRSxvQkFBb0IsRUFBRUMsSUFBSSxHQUFHQyxJQUFJLEdBQUdDLFFBQW1FLEdBQUc7QUFDL0csUUFBTUMsUUFBUSxPQUFPRCxTQUFTQyxVQUFVLFdBQVdELFFBQVFDLE1BQU1DLEtBQUssSUFBSTtBQUMxRSxRQUFNQyxRQUFrQjtBQUN4QixNQUFJQyxPQUFPO0FBQ1gsYUFBV0MsUUFBUUosTUFBTUssTUFBTSxNQUFNLEVBQUVDLE9BQU9DLE9BQU8sR0FBRztBQUNwRCxVQUFNQyxTQUFTLENBQUMsR0FBR0osSUFBSTtBQUN2QixXQUFPSSxPQUFPQyxRQUFRO0FBQ2xCLFlBQU1DLFFBQVFGLE9BQU9HLE9BQU8sR0FBRyxDQUFDLEVBQUVDLEtBQUssRUFBRTtBQUN6QyxZQUFNQyxZQUFZVixPQUFPLEdBQUdBLElBQUksSUFBSU8sS0FBSyxLQUFLQTtBQUM5QyxVQUFJUCxRQUFRLENBQUMsR0FBR1UsU0FBUyxFQUFFSixTQUFTLEdBQUc7QUFDbkNQLGNBQU1ZLEtBQUtYLElBQUk7QUFDZkEsZUFBT087QUFBQUEsTUFDWCxPQUFPO0FBQ0hQLGVBQU9VO0FBQUFBLE1BQ1g7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUNBLE1BQUlWLEtBQU1ELE9BQU1ZLEtBQUtYLElBQUk7QUFFekIsU0FBTyx1QkFBQyxVQUFLLEdBQU0sR0FBTSxJQUFJLElBQUksWUFBVyxVQUFTLE1BQU12QyxPQUFPbUQsZUFBZSxVQUFVbEQsT0FBT21ELFVBQVVDLE1BQ3ZHZixnQkFBTWdCLElBQUksQ0FBQ0MsTUFBTUMsVUFBVSx1QkFBQyxXQUErQixHQUFNLElBQUlBLFFBQVEsS0FBSyxHQUFJRDtBQUFBQTtBQUFBQSxJQUFNQyxRQUFRbEIsTUFBTU8sU0FBUyxJQUFJLE1BQU07QUFBQSxPQUF0RixHQUFHVyxLQUFLLElBQUlELElBQUksSUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxRyxDQUFRLEtBRHRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFUDtBQUNKO0FBQUNFLEtBdEJRekI7QUF3QkYsZ0JBQVMwQixjQUFjO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxFQUFFQyxLQUFLLElBQUl4RCxTQUFTO0FBQzFCLFFBQU0sQ0FBQ3lELFFBQVFDLFNBQVMsSUFBSS9FLGdCQUFnQjtBQUM1QyxRQUFNZ0YsZUFBZW5GLE9BQU8sSUFBSW9GLGdCQUFnQkgsTUFBTSxDQUFDO0FBQ3ZELFFBQU1JLGdCQUFnQnJGLE9BQXNCLElBQUk7QUFDaERGLFlBQVUsTUFBTTtBQUNaLFVBQU13RixrQkFBa0JMLE9BQU9NLFNBQVM7QUFDeEMsUUFBSUYsY0FBY0csWUFBWSxRQUFRSCxjQUFjRyxZQUFZRixnQkFBaUI7QUFDakZILGlCQUFhSyxVQUFVLElBQUlKLGdCQUFnQkgsTUFBTTtBQUNqREksa0JBQWNHLFVBQVU7QUFBQSxFQUM1QixHQUFHLENBQUNQLE1BQU0sQ0FBQztBQUNYLFFBQU1RLFVBQVVuRSxPQUFPLGtCQUFrQjtBQUN6QyxRQUFNb0UsY0FBY2pFLE9BQU8sV0FBVztBQUN0QyxRQUFNa0UsT0FBT3JFLE9BQU8sWUFBWSxFQUFFc0UsT0FBTyxFQUFFQyxPQUFPLElBQUlDLFFBQVFiLE9BQU9jLElBQUksUUFBUSxLQUFLQyxPQUFVLEVBQUUsR0FBR04sV0FBVztBQUNoSCxRQUFNTyxNQUFNMUUsV0FBVyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUM7QUFDbkQsUUFBTTJFLGdCQUFnQmpCLE9BQU9jLElBQUksWUFBWTtBQUM3QyxRQUFNSSxPQUFvQ0Qsa0JBQWtCLGVBQWVBLGtCQUFrQixjQUFjQSxrQkFBa0IsZ0JBQWdCQSxnQkFBZ0I7QUFDN0osUUFBTUUsZUFBZVgsUUFBUVksTUFBTUEsS0FBS0M7QUFDeEMsUUFBTUMsZUFBZXhHLFFBQVEsTUFBTTtBQUMvQixRQUFJLENBQUNxRyxhQUFjLFFBQU87QUFDMUIsUUFBSTtBQUNBLFlBQU1JLGNBQWM3RCxlQUFleUQsY0FBY3BCLEtBQUt5QixRQUFRO0FBQzlELGFBQU8sRUFBRUMsVUFBVSxHQUFHRixZQUFZRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU9DLFFBQVFKLFlBQVk7QUFBQSxJQUM1RSxRQUNNO0FBQUUsYUFBTztBQUFBLElBQU07QUFBQSxFQUN6QixHQUFHLENBQUN4QixLQUFLeUIsVUFBVUwsWUFBWSxDQUFDO0FBQ2hDLFFBQU1TLFlBQVk1QixPQUFPYyxJQUFJLFVBQVU7QUFDdkMsUUFBTWUsVUFBVTdCLE9BQU9jLElBQUksUUFBUTtBQUNuQyxRQUFNZ0IsaUJBQWlCQSxDQUFDQyxLQUE0QnhELFVBQXlCO0FBQ3pFLFFBQUk1QixnQkFBZ0I0QixLQUFLLEVBQUcsUUFBT0E7QUFDbkMsUUFBSXlCLE9BQU9nQyxJQUFJRCxHQUFHLEtBQUt4RCxVQUFVLEdBQUksUUFBTztBQUM1QyxXQUFPK0MsZUFBZVMsR0FBRyxLQUFLO0FBQUEsRUFDbEM7QUFDQSxRQUFNRSxPQUFPSCxlQUFlLFlBQVlGLFNBQVM7QUFDakQsUUFBTU0sS0FBS0osZUFBZSxVQUFVRCxPQUFPO0FBQzNDLFFBQU1NLGlCQUFpQkEsQ0FBQ0osS0FBMkN4RCxVQUFrQjtBQUNqRixVQUFNNkQsT0FBTyxJQUFJakMsZ0JBQWdCRCxhQUFhSyxPQUFPO0FBQ3JELFFBQUl3QixRQUFRLGFBQWNLLE1BQUtDLElBQUlOLEtBQUt4RCxLQUFLO0FBQUE7QUFDeEM2RCxXQUFLQyxJQUFJTixLQUFLcEYsZ0JBQWdCNEIsS0FBSyxJQUFJQSxRQUFRLEVBQUU7QUFDdEQyQixpQkFBYUssVUFBVTZCO0FBQ3ZCaEMsa0JBQWNHLFVBQVU2QixLQUFLOUIsU0FBUztBQUN0Q0wsY0FBVW1DLE1BQU0sRUFBRUUsV0FBVyxLQUFLLENBQUM7QUFBQSxFQUN2QztBQUNBLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJeEgsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lILFlBQVlDLGFBQWEsSUFBSTFILFNBQTJGLElBQUk7QUFDbkksUUFBTTJILG1CQUFtQm5HLE9BQU8sZ0JBQWdCO0FBQ2hELFFBQU1vRyxrQkFBa0JwRyxPQUFPMEIsa0JBQWtCZ0QsSUFBSSxDQUFDO0FBQ3RELFFBQU0yQixtQkFBbUJyQyxRQUFRWSxNQUFNQSxLQUFLeUIsb0JBQW9CO0FBQ2hFLFFBQU1DLGtCQUFrQkQsaUJBQWlCRSxTQUFTN0IsSUFBSTtBQUV0RHJHLFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ3NHLGFBQWM7QUFDbkIsUUFBSSxDQUFDRyxjQUFjO0FBQ2ZrQixvQkFBYywyREFBMkQ7QUFDekU7QUFBQSxJQUNKO0FBQ0EsUUFBSTtBQUNBLFlBQU1KLE9BQU8sSUFBSWpDLGdCQUFnQkQsYUFBYUssT0FBTztBQUNyRCxVQUFJeUMsVUFBVTtBQUNkLFVBQUkvQixrQkFBa0IsZUFBZUEsa0JBQWtCLGNBQWNBLGtCQUFrQixpQkFBaUJBLGtCQUFrQixVQUFVO0FBQ2hJbUIsYUFBS0MsSUFBSSxjQUFjLFFBQVE7QUFDL0JXLGtCQUFVO0FBQUEsTUFDZDtBQUNBLFVBQUksQ0FBQ2hELE9BQU9nQyxJQUFJLFVBQVUsS0FBTUosYUFBYSxDQUFDakYsZ0JBQWdCaUYsU0FBUyxHQUFJO0FBQ3ZFUSxhQUFLQyxJQUFJLFlBQVlmLGFBQWFHLFFBQVE7QUFDMUN1QixrQkFBVTtBQUFBLE1BQ2Q7QUFDQSxVQUFJLENBQUNoRCxPQUFPZ0MsSUFBSSxRQUFRLEtBQU1ILFdBQVcsQ0FBQ2xGLGdCQUFnQmtGLE9BQU8sR0FBSTtBQUNqRU8sYUFBS0MsSUFBSSxVQUFVZixhQUFhSyxNQUFNO0FBQ3RDcUIsa0JBQVU7QUFBQSxNQUNkO0FBQ0EsVUFBSUEsU0FBUztBQUNUOUMscUJBQWFLLFVBQVU2QjtBQUN2QmhDLHNCQUFjRyxVQUFVNkIsS0FBSzlCLFNBQVM7QUFDdENMLGtCQUFVbUMsTUFBTSxFQUFFYSxTQUFTLE1BQU1YLFdBQVcsS0FBSyxDQUFDO0FBQUEsTUFDdEQ7QUFBQSxJQUNKLFFBQ007QUFBRUUsb0JBQWMsMkRBQTJEO0FBQUEsSUFBRztBQUFBLEVBQ3hGLEdBQUcsQ0FBQ2xCLGNBQWN0QixRQUFRaUIsZUFBZVcsV0FBV0MsU0FBUzVCLFdBQVdrQixZQUFZLENBQUM7QUFFckYsUUFBTStCLFNBQVMsWUFBWTtBQUN2QlYsa0JBQWMsRUFBRTtBQUNoQixRQUFJO0FBQ0EsVUFBSSxDQUFDckIsZ0JBQWdCLENBQUNjLFFBQVEsQ0FBQ0MsR0FBSSxPQUFNLElBQUlpQixXQUFXLDJDQUEyQztBQUNuRyxZQUFNQyxVQUFVO0FBQUEsUUFDWkMsWUFBWW5DO0FBQUFBLFFBQ1pvQyxRQUFRO0FBQUEsUUFDUnJCLE1BQU10RSxtQkFBbUJzRSxNQUFNLFNBQVNsQyxLQUFLeUIsUUFBUTtBQUFBLFFBQ3JEVSxJQUFJdkUsbUJBQW1CdUUsSUFBSSxPQUFPbkMsS0FBS3lCLFFBQVE7QUFBQSxRQUMvQ0EsVUFBVXpCLEtBQUt5QjtBQUFBQSxRQUNmTDtBQUFBQSxNQUNKO0FBQ0F1QixvQkFBYyxJQUFJO0FBQ2xCLFlBQU1hLFdBQVcsTUFBTXZDLElBQUl3QyxRQUFRLEVBQUVoRSxNQUFNNEQsUUFBUSxDQUFDO0FBQ3BEVixvQkFBYyxFQUFFZSxLQUFLRixTQUFTbkMsTUFBTUYsTUFBTWUsTUFBTUMsR0FBRyxDQUFDO0FBQUEsSUFDeEQsU0FDT3dCLE9BQU87QUFDVixVQUFJQSxpQkFBaUJQLFdBQVlYLGVBQWNrQixNQUFNQyxPQUFPO0FBQUEsSUFDaEU7QUFBQSxFQUNKO0FBQ0EsUUFBTUMsZUFBZUEsTUFBTTtBQUFFLFNBQUtWLE9BQU87QUFBQSxFQUFHO0FBRTVDLFFBQU1XLGVBQWVwQixZQUFZZ0IsSUFBSUssV0FBVyxlQUFlckIsV0FBV2dCLElBQUlNLGNBQ3hFdEcsdUJBQXVCZ0YsV0FBV2dCLElBQUlNLGFBQWFDLFNBQVNDLFFBQVFDLFFBQVEsSUFDNUU7QUFFTixTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLDBCQUF5QixVQUFTLHdGQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdJO0FBQUEsSUFDeEksdUJBQUMsZUFBWSxlQUFZLHVCQUFzQixTQUFTLEVBQUVDLElBQUksa0JBQWtCQyxJQUFJLG1DQUFtQyxHQUFHLFlBQVksU0FBUyxVQUFVLEVBQUNDLFVBQVUsRUFBQyxHQUNqSztBQUFBLDZCQUFDLGdCQUFhLGVBQVkseUJBQ3RCO0FBQUEsK0JBQUMsY0FBVyxPQUFPN0QsU0FBUyxnQkFBZSxXQUN0Q0Esa0JBQVFZLFFBQVEsdUJBQUMsU0FBTSxPQUFNLG1CQUFrQixVQUFTLDRFQUEyRSxVQUFTLFNBQ3pJLGlDQUFDLGNBQVcsZUFBWSw4QkFBNkIsVUFBVSxFQUFDa0QsVUFBVSxJQUFHLEdBQ3pFO0FBQUEsaUNBQUMsZUFBWSxPQUFPdEQsSUFBSTBDLFNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDN0JuQixjQUFjLHVCQUFDLFNBQU0sVUFBUyxTQUFRLE1BQUssU0FBU0Esd0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDaEUsdUJBQUMsYUFBVSxPQUFNLFdBQVUsUUFBTSxNQUFDLE9BQU9yQixNQUFNLFVBQVUsQ0FBQXFELFVBQVM7QUFDOUQsa0JBQU1oRyxRQUFRZ0csTUFBTUMsT0FBT2pHO0FBQzNCLGdCQUFJQSxVQUFVLFlBQVlBLFVBQVUsZUFBZUEsVUFBVSxjQUFjQSxVQUFVLGNBQWU0RCxnQkFBZSxjQUFjNUQsS0FBSztBQUN0SW1FLDBCQUFjLElBQUk7QUFBQSxVQUN0QixHQUNLRywyQkFBaUJwRCxJQUFJLENBQUFnRixXQUFVLHVCQUFDLFlBQVMsT0FBT0EsUUFBc0I1Ryx1QkFBYTRHLE1BQU0sS0FBNUJBLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELENBQVcsS0FMM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0M1QixpQkFBaUI3RCxXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sK0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDeEcsdUJBQUMsY0FBVyxlQUFZLHdCQUF1QixXQUFXLEVBQUVtRixJQUFJLFVBQVVPLElBQUksTUFBTSxHQUNoRjtBQUFBLG1DQUFDLGFBQVUsT0FBTSxXQUFVLE1BQUssUUFBTyxPQUFPekMsTUFBTSxVQUFVLENBQUFzQyxVQUFTcEMsZUFBZSxZQUFZb0MsTUFBTUMsT0FBT2pHLEtBQUssR0FBRyxXQUFXLEVBQUVvRyxZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFFLEdBQUcsV0FBUyxRQUE3SztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SztBQUFBLFlBQzdLLHVCQUFDLGFBQVUsT0FBTSxZQUFXLE1BQUssUUFBTyxPQUFPMUMsSUFBSSxVQUFVLENBQUFxQyxVQUFTcEMsZUFBZSxVQUFVb0MsTUFBTUMsT0FBT2pHLEtBQUssR0FBRyxXQUFXLEVBQUVvRyxZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFFLEdBQUcsV0FBUyxRQUExSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSztBQUFBLGVBRjlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLGNBQVcsT0FBTSxXQUFXN0UsZUFBS3lCLFlBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFDM0MsdUJBQUMsY0FBVyxPQUFNLGdCQUFnQkwseUJBQWUxRSxTQUFTMEUsY0FBY3BCLEtBQUt5QixRQUFRLElBQUksc0JBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRHO0FBQUEsVUFDM0csQ0FBQ21CLG9CQUFvQix1QkFBQyxTQUFNLFVBQVMsV0FBVSwrREFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUM5RkEsb0JBQW9CLENBQUNDLG1CQUFtQix1QkFBQyxTQUFNLFVBQVMsV0FBVTtBQUFBO0FBQUEsWUFBMkMxRSxrQkFBa0JnRCxJQUFJO0FBQUEsWUFBRTtBQUFBLGVBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThIO0FBQUEsVUFDdEt5QixvQkFBb0JDLG1CQUFtQixDQUFDRSxtQkFBbUJELGlCQUFpQjdELFNBQVMsS0FBSyx1QkFBQyxTQUFNLFVBQVMsV0FBVSx3RUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUM3Syx1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTNEUsY0FBYyxVQUFVLENBQUNqQixvQkFBb0IsQ0FBQ0MsbUJBQW1CLENBQUNFLG1CQUFtQixDQUFDM0IsZ0JBQWdCLENBQUNjLFFBQVEsQ0FBQ0MsTUFBTUQsT0FBT0MsTUFBTWxCLElBQUk2RCxTQUN2SzdELGNBQUk2RCxVQUFVLHVCQUF1Qix5QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NwQyxjQUFjLHVCQUFDLGVBQVksV0FBVyxFQUFFMEIsSUFBSSxVQUFVTyxJQUFJLE1BQU0sR0FBSSxZQUFZLEVBQUVQLElBQUksV0FBV08sSUFBSSxTQUFTLEdBQzNHO0FBQUEsbUNBQUMsYUFBVSxJQUFJLE1BQU0zRSxLQUFLK0UsRUFBRSxTQUFTckMsV0FBV2dCLElBQUlxQixFQUFFLElBQUk7QUFBQTtBQUFBLGNBQW9CckMsV0FBV2dCLElBQUlxQjtBQUFBQSxpQkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0c7QUFBQSxZQUMvRmpCLGdCQUFnQix1QkFBQyxRQUFLLGVBQVksMkJBQTBCLFdBQVUsS0FBSSxNQUFNQSxjQUFjLFVBQVVqRyxlQUFlNkUsV0FBV3ZCLE1BQU11QixXQUFXUixNQUFNUSxXQUFXUCxFQUFFLEdBQUcsV0FBVSxRQUFPLElBQUksQ0FBQzFFLFNBQVN1SCxRQUFRQyxZQUFZLEVBQUVDLFFBQVEsR0FBR0MsYUFBYSxXQUFXQyxjQUFjbEssU0FBU21LLE9BQU9DLFNBQVNDLE9BQU8sZ0JBQWdCQyxZQUFZdEssU0FBU3VLLFdBQVdELFdBQVdFLFVBQVUsV0FBVyxFQUFFQyxTQUFTLGdCQUFnQkMsZ0JBQWdCLE9BQU8sR0FBRyxtQkFBbUIsRUFBRUMsU0FBUyxHQUFHeEosT0FBT3lKLFVBQVVDLEtBQUssWUFBWUMsY0FBYyxpQkFBaUJDLGVBQWU1SixPQUFPeUosVUFBVUksY0FBYyxFQUFFLENBQUMsR0FBRyx1QkFBMWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlrQjtBQUFBLFlBQ2psQnhELFdBQVdnQixJQUFJSyxXQUFXLGVBQWUsdUJBQUMsU0FBTSxVQUFVckIsV0FBV2dCLElBQUlLLFdBQVcsYUFBYXJCLFdBQVdnQixJQUFJSyxXQUFXLFdBQVcsWUFBWSxRQUFRLGtFQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSztBQUFBLFlBQzVNckIsV0FBV2dCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxlQUFlLENBQUNGLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSwwRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUpsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtmO0FBQUEsVUFDQ3JELFFBQVFZLEtBQUtBLEtBQUs4RSxTQUFTekcsSUFBSSxDQUFDMEcsU0FBU3hHLFVBQVUsdUJBQUMsU0FBa0MsVUFBUyxRQUFRd0cscUJBQXhDLEdBQUd4RyxLQUFLLElBQUl3RyxPQUFPLElBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELENBQVE7QUFBQSxVQUN4SCx1QkFBQyxTQUFNLFVBQVMsUUFBTywyS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0w7QUFBQSxhQTlCdEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQSxLQWhDYTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNqQixLQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFDQzFGLGNBQWMsdUJBQUMsY0FBVyxPQUFPQyxNQUFNLGdCQUFlLFdBQ2xEQSxlQUFLVSxRQUFRLHVCQUFDLFNBQU0sT0FBTSxxQkFBb0IsVUFBUyxzRkFDcEQ7QUFBQSxpQ0FBQyxhQUFVLE1BQU1WLEtBQUtVLEtBQUtBLE1BQU0sUUFBUSxDQUFBcUMsUUFBT0EsSUFBSXFCLElBQUksT0FBTSxxQkFBb0IsT0FBTSxzQ0FBcUMsU0FBUztBQUFBLFlBQ2xJLEVBQUUvQyxLQUFLLE1BQU1xRSxPQUFPLGdCQUFnQkMsUUFBUUEsQ0FBQTVDLFFBQU8sdUJBQUMsYUFBVSxJQUFJLE1BQU0xRCxLQUFLK0UsRUFBRSxTQUFTckIsSUFBSXFCLEVBQUUsSUFBS3JCLGNBQUlxQixNQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RCxFQUFhO0FBQUEsWUFDdkgsRUFBRS9DLEtBQUssUUFBUXFFLE9BQU8sUUFBUUMsUUFBUUEsQ0FBQTVDLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJNkMsUUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0IsRUFBSTtBQUFBLFlBQ3pFLEVBQUV2RSxLQUFLLFVBQVVxRSxPQUFPLGNBQWNDLFFBQVFBLENBQUE1QyxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSUssVUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEIsRUFBSTtBQUFBLFlBQ25GLEVBQUUvQixLQUFLLFlBQVlxRSxPQUFPLFdBQVdHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTVDLFFBQU8sR0FBR0EsSUFBSStDLFNBQVMsTUFBTS9DLElBQUlnRCxTQUFTLFdBQVcsR0FBRztBQUFBLFlBQ3JILEVBQUUxRSxLQUFLLGFBQWFxRSxPQUFPLFlBQVlDLFFBQVFBLENBQUE1QyxRQUFPaEgsU0FBU2dILElBQUlpRCxXQUFXM0csS0FBS3lCLFFBQVEsRUFBRTtBQUFBLFVBQUMsS0FMbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNRTtBQUFBLFVBQ0YsdUJBQUMsU0FBTSxNQUFNZCxLQUFLVSxLQUFLdUYsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQVJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU2QsS0FWVztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV2YsSUFBZ0IsdUJBQUMsU0FBTSxVQUFTLFFBQU8sNkZBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxXQWhEeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlEQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxPQUFNLG1CQUFrQixVQUFTLDZEQUE0RCxVQUFTLFNBQ3pHLGlDQUFDLFNBQU0sSUFBSW5KLFNBQVNpSCxPQUFPbUMsWUFDdkI7QUFBQSwrQkFBQyxjQUFXLE9BQU0sa0JBQWlCLDhKQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlMO0FBQUEsUUFDakwsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQix3SEFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEySTtBQUFBLFFBQzNJLHVCQUFDLGFBQVUsSUFBSSxNQUFNN0csS0FBSytFLEVBQUUsc0JBQXNCLHVDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsV0FIN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0F6REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBEQTtBQUFBLE9BNURHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2RFA7QUFDSjtBQUFDaEYsR0F4S2VELGFBQVc7QUFBQSxVQUNOdEQsVUFDV3JCLGlCQVNabUIsUUFDSUcsUUFDUEgsUUFDREMsWUErQmFFLFFBQ0RBLE1BQU07QUFBQTtBQUFBLE1BOUNsQnFEO0FBMEtULGdCQUFTZ0gsZ0JBQWdCO0FBQUFDLE1BQUE7QUFDNUIsUUFBTSxFQUFFL0csS0FBSyxJQUFJeEQsU0FBUztBQUMxQixRQUFNLENBQUN5RCxRQUFRQyxTQUFTLElBQUkvRSxnQkFBZ0I7QUFDNUMsUUFBTTZMLFNBQVMvRyxPQUFPTSxTQUFTO0FBQy9CLFFBQU0wRyxZQUFZaEgsT0FBT2MsSUFBSSxVQUFVLEtBQUs7QUFDNUMsUUFBTW1HLFVBQVVqSCxPQUFPYyxJQUFJLFFBQVEsS0FBSztBQUN4QyxRQUFNb0csY0FBY2xILE9BQU9jLElBQUksUUFBUSxLQUFLO0FBQzVDLFFBQU1xRyxnQkFBZ0JuSCxPQUFPZ0MsSUFBSSxVQUFVLEtBQUtoQyxPQUFPZ0MsSUFBSSxRQUFRO0FBQ25FLFFBQU1vRixlQUFlQyxvQkFBb0JMLFdBQVdDLFNBQVNDLGFBQWEsQ0FBQ0MsYUFBYTtBQUN4RixRQUFNeEcsUUFBUXlHLGVBQWVyRyxTQUFZO0FBQUEsSUFDckMsR0FBSWYsT0FBT2dDLElBQUksVUFBVSxJQUFJLEVBQUVQLFVBQVV1RixVQUFVLElBQUksQ0FBQztBQUFBLElBQ3hELEdBQUloSCxPQUFPZ0MsSUFBSSxRQUFRLElBQUksRUFBRUwsUUFBUXNGLFFBQVEsSUFBSSxDQUFDO0FBQUEsSUFDbEQsR0FBSWpILE9BQU9nQyxJQUFJLFFBQVEsSUFBSSxFQUFFc0YsUUFBUUosWUFBK0IsSUFBSSxDQUFDO0FBQUEsRUFDN0U7QUFDQSxRQUFNOUYsT0FBTy9FLE9BQU8sdUJBQXVCc0UsU0FBUzRHLE9BQU9DLEtBQUs3RyxLQUFLLEVBQUUzQixTQUFTLEVBQUUyQixNQUFNLElBQUlJLFFBQVcsQ0FBQ3FHLFlBQVk7QUFDcEgsUUFBTUssSUFBSXJHLEtBQUtBLE1BQU1BO0FBQ3JCLFFBQU1zRyxrQkFBa0JELEdBQUdFO0FBQzNCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJN00sU0FBUyxFQUFFeUcsVUFBVXVGLFdBQVdyRixRQUFRc0YsU0FBU0ssUUFBUUosWUFBWSxDQUFDO0FBQ2hHLFFBQU0sQ0FBQ1ksaUJBQWlCQyxrQkFBa0IsSUFBSS9NLFNBQVMsS0FBSztBQUM1RCxRQUFNZ04sVUFBVWpOLE9BQXlCLElBQUk7QUFDN0MsUUFBTWtOLFFBQVFsTixPQUF5QixJQUFJO0FBQzNDLFFBQU1tTixZQUFZbk4sT0FBeUIsSUFBSTtBQUMvQyxRQUFNb04sYUFBYWQsb0JBQW9CTyxNQUFNbkcsVUFBVW1HLE1BQU1qRyxRQUFRaUcsTUFBTU4sUUFBUSxLQUFLO0FBQ3hGLFFBQU1jLHFCQUFxQk4sa0JBQWtCSyxhQUFhZjtBQUUxRHZNLFlBQVUsTUFBTTtBQUNaLFFBQUk2TSxpQkFBaUI7QUFDakJHLGVBQVMsRUFBRXBHLFVBQVVpRyxnQkFBZ0JqRyxVQUFVRSxRQUFRK0YsZ0JBQWdCL0YsUUFBUTJGLFFBQVFJLGdCQUFnQkosT0FBTyxDQUFDO0FBQy9HLFlBQU1sRixPQUFPLElBQUlqQyxnQkFBZ0IsRUFBRXNCLFVBQVVpRyxnQkFBZ0JqRyxVQUFVRSxRQUFRK0YsZ0JBQWdCL0YsUUFBUTJGLFFBQVFJLGdCQUFnQkosT0FBTyxDQUFDO0FBQ3ZJLFVBQUlsRixLQUFLOUIsU0FBUyxNQUFNeUcsT0FBUTlHLFdBQVVtQyxNQUFNLEVBQUVhLFNBQVMsS0FBSyxDQUFDO0FBQUEsSUFDckU7QUFBQSxFQUNKLEdBQUcsQ0FBQ3lFLGlCQUFpQlgsUUFBUTlHLFNBQVMsQ0FBQztBQUV2Q3BGLFlBQVUsTUFBTTtBQUNaLFVBQU0wRixVQUFVLElBQUlKLGdCQUFnQjRHLE1BQU07QUFDMUMsUUFBSSxDQUFDeEcsUUFBUXlCLElBQUksVUFBVSxLQUFLLENBQUN6QixRQUFReUIsSUFBSSxRQUFRLEVBQUc7QUFDeEQ2RixhQUFTLEVBQUVwRyxVQUFVbEIsUUFBUU8sSUFBSSxVQUFVLEtBQUssSUFBSWEsUUFBUXBCLFFBQVFPLElBQUksUUFBUSxLQUFLLElBQUl3RyxRQUFRL0csUUFBUU8sSUFBSSxRQUFRLEtBQUssTUFBTSxDQUFDO0FBQ2pJaUgsdUJBQW1CLEtBQUs7QUFBQSxFQUM1QixHQUFHLENBQUNoQixNQUFNLENBQUM7QUFFWCxRQUFNc0IsY0FBY0EsQ0FBQzlELFVBQXNDO0FBQ3ZEQSxVQUFNK0QsZUFBZTtBQUNyQlAsdUJBQW1CLElBQUk7QUFDdkIsUUFBSUksWUFBWTtBQUNaLFlBQU0zRCxTQUFTMkQsV0FBV0ksVUFBVSxhQUFhUCxRQUFRekgsVUFBVTRILFdBQVdJLFVBQVUsV0FBV04sTUFBTTFILFVBQVUySCxVQUFVM0g7QUFDN0hpRSxjQUFRZ0UsTUFBTTtBQUNkO0FBQUEsSUFDSjtBQUNBLFVBQU1wRyxPQUFPLElBQUlqQyxnQkFBZ0IsRUFBRXNCLFVBQVVtRyxNQUFNbkcsVUFBVUUsUUFBUWlHLE1BQU1qRyxRQUFRMkYsUUFBUU0sTUFBTU4sT0FBTyxDQUFDO0FBQ3pHUyx1QkFBbUIsS0FBSztBQUN4QjlILGNBQVVtQyxJQUFJO0FBQUEsRUFDbEI7QUFFQSxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLDJCQUEwQixVQUFTLDRFQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZIO0FBQUEsSUFDNUg4QixZQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLElBQUkxRyxTQUFTaUwsT0FBT0MsVUFBVSwrR0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SjtBQUFBLElBQ3BLLHVCQUFDLFNBQU0sT0FBTSw0QkFBMkIsVUFBVSw0QkFBNEIzSSxLQUFLeUIsUUFBUSxrQkFBa0IsVUFBUyxTQUFRLFVBQVMsV0FDbkksaUNBQUMsY0FBVyxXQUFVLFFBQU8sVUFBVTZHLGFBQWEsZUFBWSx3QkFDNUQ7QUFBQSw2QkFBQyxTQUFNLFdBQVcsRUFBRWxFLElBQUksVUFBVXdFLElBQUksTUFBTSxHQUFHLFlBQVksRUFBRXhFLElBQUksV0FBV3dFLElBQUksV0FBVyxHQUFHLElBQUluTCxTQUFTb0wsUUFBUUMsWUFDL0c7QUFBQSwrQkFBQyxhQUFVLFVBQVViLFNBQVMsTUFBSyxRQUFPLE9BQU0sV0FBVSxPQUFPSixNQUFNbkcsVUFBVSxVQUFVLENBQUE4QyxVQUFTc0QsU0FBUyxDQUFBdEosV0FBVSxFQUFFLEdBQUdBLE9BQU9rRCxVQUFVOEMsTUFBTUMsT0FBT2pHLE1BQU0sRUFBRSxHQUFHLFdBQVcsRUFBRW9HLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxPQUFPd0Qsb0JBQW9CRyxVQUFVLFlBQVksWUFBWUgsb0JBQW9CRyxVQUFVLGFBQWFILG1CQUFtQnpFLFVBQVUseUNBQXZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNlg7QUFBQSxRQUM3WCx1QkFBQyxhQUFVLFVBQVVzRSxPQUFPLE1BQUssUUFBTyxPQUFNLFlBQVcsT0FBT0wsTUFBTWpHLFFBQVEsVUFBVSxDQUFBNEMsVUFBU3NELFNBQVMsQ0FBQXRKLFdBQVUsRUFBRSxHQUFHQSxPQUFPb0QsUUFBUTRDLE1BQU1DLE9BQU9qRyxNQUFNLEVBQUUsR0FBRyxXQUFXLEVBQUVvRyxZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFFLEdBQUcsT0FBT3dELG9CQUFvQkcsVUFBVSxVQUFVLFlBQVlILG9CQUFvQkcsVUFBVSxXQUFXSCxtQkFBbUJ6RSxVQUFVLHVDQUE5VTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtYO0FBQUEsUUFDbFgsdUJBQUMsYUFBVSxVQUFVdUUsV0FBVyxRQUFNLE1BQUMsT0FBTSxZQUFXLE9BQU9OLE1BQU1OLFFBQVEsVUFBVSxDQUFBL0MsVUFBU3NELFNBQVMsQ0FBQXRKLFdBQVUsRUFBRSxHQUFHQSxPQUFPK0ksUUFBUS9DLE1BQU1DLE9BQU9qRyxNQUFNLEVBQUUsR0FBRyxPQUFPNkosb0JBQW9CRyxVQUFVLFVBQVUsWUFBWUgsb0JBQW9CRyxVQUFVLFdBQVdILG1CQUFtQnpFLFVBQVUsK0JBQzVSO0FBQUEsaUNBQUMsWUFBUyxPQUFNLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sUUFBTyxvQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxTQUFRLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLGFBRDVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxhQUFZLHVCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsV0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQ21FLG1CQUFtQkssY0FBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHFCQUFXeEUsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLFNBVC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0N5RCxlQUFlLHVCQUFDLFNBQU0sVUFBUyxTQUFRLE1BQUssU0FBUTtBQUFBLDZCQUFDLFlBQU8sbURBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLE1BQVM7QUFBQSxTQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlJLElBQVcsdUJBQUMsY0FBVyxPQUFPaEcsTUFBTSxnQkFBZSxXQUFXcUcsZUFBSyxtQ0FDeE47QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBSyxPQUFNLHlCQUF3QixPQUFPQSxFQUFFcUIsdUJBQXVCLE1BQUssZ0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxRQUNyRyx1QkFBQyxRQUFLLE9BQU0scUJBQW9CLE9BQU9yQixFQUFFc0IsMEJBQTBCLE1BQUssbUNBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxRQUN2Ryx1QkFBQyxRQUFLLE9BQU0seUJBQXdCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT3RCLEVBQUV1QixlQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEdBQUssTUFBTXZCLEVBQUV1QixjQUFjLDRCQUE0QixzQ0FBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SztBQUFBLFFBQ3ZLLHVCQUFDLFFBQUssT0FBTSwwQkFBeUIsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPdkIsRUFBRXdCLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLEdBQUssTUFBSyxtQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBSjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxlQUFZLG1CQUFrQixJQUFJLENBQUN6TCxTQUFTaUgsT0FBT21DLFlBQVlwSixTQUFTbUosS0FBS3VDLFlBQVksR0FDM0Z6QjtBQUFBQSxVQUFFRSxVQUFVLHVCQUFDLGNBQVcsU0FBUSxTQUFRO0FBQUE7QUFBQSxVQUFJakwsZUFBZStLLEVBQUVFLE9BQU9sRyxRQUFRO0FBQUEsVUFBRTtBQUFBLFVBQUkvRSxlQUFlK0ssRUFBRUUsT0FBT2hHLE1BQU07QUFBQSxVQUFFO0FBQUEsVUFBYThGLEVBQUVFLE9BQU9MLFdBQVcsUUFBUSxTQUFTRyxFQUFFRSxPQUFPTCxXQUFXLFNBQVMsU0FBUztBQUFBLGFBQTlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc007QUFBQSxRQUNuTix1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQjtBQUFBO0FBQUEsVUFBVTdLLFNBQVNnTCxFQUFFcEcsTUFBTW9HLEVBQUVFLFFBQVFuRyxZQUFZekIsS0FBS3lCLFFBQVE7QUFBQSxVQUFFO0FBQUEsVUFBSXpCLEtBQUtvSjtBQUFBQSxVQUFLO0FBQUEsVUFBWTFCLEVBQUVFLFFBQVFuRyxZQUFZekIsS0FBS3lCO0FBQUFBLGFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUw7QUFBQSxXQUZ2TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGVBQVksZUFBWSwyQkFBMEIsU0FBUyxFQUFFMkMsSUFBSSxPQUFPaUYsSUFBSSxVQUFVLEdBQ25GO0FBQUEsK0JBQUMsU0FBTSxPQUFNLHNCQUFxQixVQUFTLDhEQUN2QztBQUFBLGlDQUFDLE9BQUksTUFBSyxPQUFNLGNBQVksZUFBZTNCLEVBQUVFLFFBQVFMLFVBQVUsSUFBSSx5QkFBeUIsZUFBWSx5QkFBd0IsSUFBSSxDQUFDLEVBQUUrQixRQUFRLElBQUksR0FBRzdMLFNBQVNpSCxPQUFPNkUsa0JBQWtCLEdBQ25MN0IsWUFBRThCLE9BQU92SyxTQUFTLHVCQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUFPLGlDQUFDLFlBQVMsTUFBTXlJLEVBQUU4QixPQUFPLG9CQUFrQixNQUMxRztBQUFBLG1DQUFDLGlCQUFjLFFBQVFwTixPQUFPcU4sa0JBQWtCLFVBQVUsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFNLFNBQVEsWUFBVyxRQUFRck4sT0FBT21ELGVBQWUsVUFBVW1LLEtBQUtDLElBQUksR0FBR0QsS0FBS0UsS0FBS2xDLEVBQUU4QixNQUFNdkssU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLGVBQWUsQ0FBQVQsVUFBUzdCLGVBQWVrTixPQUFPckwsS0FBSyxDQUFDLEtBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdLO0FBQUEsWUFDeEssdUJBQUMsU0FBTSxlQUFlLE9BQU8sUUFBUXBDLE9BQU9tRCxpQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxXQUFRLGdCQUFnQixDQUFBZixVQUFTN0IsZUFBZWtOLE9BQU9yTCxLQUFLLENBQUMsR0FBRyxjQUFjLEVBQUVzTCxZQUFZMU4sT0FBTzJOLFFBQVF4RSxPQUFPbkosT0FBTzROLGFBQWE3RSxhQUFhL0ksT0FBT3FOLGlCQUFpQixLQUE1SztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SztBQUFBLFlBQzlLLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBTztBQUFBLFlBQ1AsdUJBQUMsT0FBSSxTQUFRLHlCQUF3QixNQUFLLHFCQUFvQixNQUFNck4sT0FBTzZOLFFBQVEsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxZQUN4Ryx1QkFBQyxPQUFJLFNBQVEsNEJBQTJCLE1BQUssaUJBQWdCLE1BQU03TixPQUFPbUQsZUFBZSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RztBQUFBLGVBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUW5FLEtBUm1CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUVIsSUFBeUIsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixJQUFJOUIsU0FBU2lILE9BQU93RixpQkFBaUIsNERBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9ILEtBVDVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsT0FBTSw4QkFBNkIsTUFBTXhDLEVBQUU4QixTQUFTLElBQUksUUFBUSxDQUFBVyxVQUFTQSxNQUFNekksVUFBVSxPQUFNLDZDQUE0QyxTQUFTO0FBQUEsWUFDM0osRUFBRU0sS0FBSyxTQUFTcUUsT0FBTyxlQUFlQyxRQUFRQSxDQUFBNkQsVUFBUyxHQUFHeE4sZUFBZXdOLE1BQU16SSxRQUFRLENBQUMsTUFBTS9FLGVBQWV3TixNQUFNdkksTUFBTSxDQUFDLEdBQUc7QUFBQSxZQUM3SCxFQUFFSSxLQUFLLFNBQVNxRSxPQUFPLFlBQVlHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTZELFVBQVNBLE1BQU1wQixzQkFBc0I7QUFBQSxZQUNoRyxFQUFFL0csS0FBSyxXQUFXcUUsT0FBTyxpQkFBaUJHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTZELFVBQVNBLE1BQU1uQix5QkFBeUI7QUFBQSxZQUMxRyxFQUFFaEgsS0FBSyxhQUFhcUUsT0FBTyxnQkFBZ0JHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTZELFVBQVMsdUJBQUMsVUFBTyxPQUFPQSxNQUFNakIsa0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DLEVBQUk7QUFBQSxZQUNwSCxFQUFFbEgsS0FBSyxVQUFVcUUsT0FBTyxlQUFlRyxPQUFPLFNBQVNGLFFBQVFBLENBQUE2RCxVQUFTLHVCQUFDLFVBQU8sT0FBT0EsTUFBTWxCLGVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDLEVBQUk7QUFBQSxVQUFDLEtBTGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUU7QUFBQSxhQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE9BQU0sNEJBQTJCLFVBQVMscUNBQzdDLGlDQUFDLE9BQUksZUFBWSw4QkFBNkIsSUFBSXhMLFNBQVNpSCxPQUFPMEYsa0JBQzlELGlDQUFDLFNBQU0sV0FBVSxNQUFLLGVBQVksMkJBQTBCLElBQUksQ0FBQyxFQUFFMUMsR0FBRyxHQUFHMkMsR0FBRyxFQUFFLEdBQUc1TSxTQUFTaUgsT0FBTzRGLGlCQUFpQjdNLFNBQVNpSCxPQUFPNkYsV0FBVyxHQUN4STdDLFlBQUU4QyxhQUFhdkwsU0FBU3lJLEVBQUU4QyxhQUFhOUssSUFBSSxDQUFDK0ssVUFBVTdLLFVBQVUsdUJBQUMsY0FBVyxXQUFVLE1BQW1DNkssc0JBQXpCLEdBQUc3SyxLQUFLLElBQUk2SyxRQUFRLElBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0UsQ0FBYSxJQUFJLHVCQUFDLGNBQVcsV0FBVSxNQUFLLE9BQU0sa0JBQWlCLDBEQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGLEtBRHBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxPQUFNLHdCQUF1QixVQUFTLDhDQUN6QztBQUFBLGlDQUFDLE9BQUksTUFBSyxPQUFNLGNBQVksaUNBQWlDL0MsRUFBRWdELGdCQUFnQnpMLE1BQU0sU0FBUyxlQUFZLHdCQUF1QixJQUFJLENBQUMsRUFBRXFLLFFBQVEsSUFBSSxHQUFHN0wsU0FBU2lILE9BQU82RSxrQkFBa0IsR0FDcEw3QixZQUFFZ0QsZ0JBQWdCekwsU0FBUyx1QkFBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFBTyxpQ0FBQyxZQUFTLE1BQU15SSxFQUFFZ0QsaUJBQWlCLG9CQUFrQixNQUM3SDtBQUFBLG1DQUFDLGlCQUFjLFFBQVF0TyxPQUFPcU4sa0JBQWtCLFVBQVUsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFNLFNBQVEsVUFBUyxRQUFRck4sT0FBT21ELGVBQWUsVUFBVSxHQUFHLFFBQVEsSUFBSSxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsWUFDN0csdUJBQUMsU0FBTSxlQUFlLE9BQU8sUUFBUW5ELE9BQU9tRCxpQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxXQUFRLGNBQWMsRUFBRXVLLFlBQVkxTixPQUFPMk4sUUFBUXhFLE9BQU9uSixPQUFPNE4sYUFBYTdFLGFBQWEvSSxPQUFPcU4saUJBQWlCLEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNIO0FBQUEsWUFDdEgsdUJBQUMsT0FBSSxTQUFRLFNBQVEsTUFBSyxpQkFBZ0IsTUFBTXJOLE9BQU82TixRQUFRLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsZUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU01RSxLQU40QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1qQixJQUF5Qix1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUl4TSxTQUFTaUgsT0FBT3dGLGlCQUFpQixtREFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkcsS0FQbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxNQUFNeEMsRUFBRWdELGlCQUFpQixRQUFRLENBQUFDLFdBQVVBLE9BQU9BLFFBQVEsT0FBTSx3QkFBdUIsT0FBTSwyQ0FBMEMsU0FBUztBQUFBLFlBQ3ZKLEVBQUUzSSxLQUFLLFVBQVVxRSxPQUFPLFNBQVNDLFFBQVFBLENBQUFxRSxXQUFVQSxPQUFPQSxPQUFPO0FBQUEsWUFDakUsRUFBRTNJLEtBQUssU0FBU3FFLE9BQU8saUJBQWlCRyxPQUFPLFNBQVNGLFFBQVFBLENBQUFxRSxXQUFVQSxPQUFPQyxNQUFNO0FBQUEsVUFBQyxLQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdFO0FBQUEsYUFiTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkNBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJbk4sU0FBU21KLEtBQUtpRSxlQUFlLGlKQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlMO0FBQUEsU0F2RCtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RDVOLEtBeERvSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RoSztBQUFBLE9BeEVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RVA7QUFDSjtBQUFDOUQsSUEvSGVELGVBQWE7QUFBQSxVQUNSdEssVUFDV3JCLGlCQVlmbUIsTUFBTTtBQUFBO0FBQUEsTUFkUHdLO0FBaUloQixTQUFTUSxvQkFBb0I1RixVQUFrQkUsUUFBZ0IyRixRQUFnQnVELGNBQTRGO0FBQ3ZLLE1BQUksQ0FBQyxDQUFDLE9BQU8sUUFBUSxPQUFPLEVBQUU5SCxTQUFTdUUsTUFBTSxFQUFHLFFBQU8sRUFBRWlCLE9BQU8sVUFBVTVFLFNBQVMsbUNBQW1DO0FBQ3RILE1BQUlrSCxnQkFBZ0IsQ0FBQ3BKLFlBQVksQ0FBQ0UsT0FBUSxRQUFPO0FBQ2pELE1BQUksQ0FBQ2hGLGdCQUFnQjhFLFFBQVEsRUFBRyxRQUFPLEVBQUU4RyxPQUFPLFlBQVk1RSxTQUFTLDRCQUE0QjtBQUNqRyxNQUFJLENBQUNoSCxnQkFBZ0JnRixNQUFNLEVBQUcsUUFBTyxFQUFFNEcsT0FBTyxVQUFVNUUsU0FBUyw2QkFBNkI7QUFDOUYsTUFBSWxDLFdBQVdFLE9BQVEsUUFBTyxFQUFFNEcsT0FBTyxZQUFZNUUsU0FBUyxtREFBbUQ7QUFDL0csUUFBTW1ILE9BQU9yQixLQUFLc0IsT0FBT0MsS0FBS0MsTUFBTSxHQUFHdEosTUFBTSxnQkFBZ0IsSUFBSXFKLEtBQUtDLE1BQU0sR0FBR3hKLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLEtBQUssSUFBSyxJQUFJO0FBQ3JJLE1BQUlxSixPQUFPLElBQUssUUFBTyxFQUFFdkMsT0FBTyxVQUFVNUUsU0FBUywrQ0FBK0M7QUFDbEcsU0FBTztBQUNYO0FBQUMsSUFBQS9ELElBQUFzTCxLQUFBQztBQUFBLGFBQUF2TCxJQUFBO0FBQUEsYUFBQXNMLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU2VjdGlvbkdyaWQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiTGluayIsIk1lbnVJdGVtIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwiQmFyIiwiQmFyQ2hhcnQiLCJDYXJ0ZXNpYW5HcmlkIiwiTGVnZW5kIiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsIlRvb2x0aXAiLCJYQXhpcyIsIllBeGlzIiwiY29sb3JzIiwidG9rZW5zIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlQ2FuIiwiZGF0ZVRpbWUiLCJmb3JtYXREYXRlT25seSIsImlzVmFsaWREYXRlT25seSIsIkFtb3VudCIsIkRhdGFUYWJsZSIsIkRldGFpbExpbmUiLCJFcnJvck5vdGljZSIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIlBhZ2VyIiwiUXVlcnlTdGF0ZSIsIlJvdXRlTGluayIsIlN0YXQiLCJTdGF0cyIsIlN0YXR1cyIsImxheW91dFN4IiwiYXV0aG9yaXplZERvd25sb2FkSHJlZiIsImRhdGVJblRpbWV6b25lIiwicmVwb3J0RGF0ZUJvdW5kYXJ5IiwicmVwb3J0RmlsZW5hbWUiLCJyZXBvcnRMYWJlbHMiLCJpbnZlbnRvcnkiLCJvcmRlcnMiLCJjYXNoZmxvdyIsInByb2ZpdF9sb3NzIiwic291cmNlUGVybWlzc2lvbnMiLCJNYXJrZXRpbmdSZWFzb25UaWNrIiwieCIsInkiLCJwYXlsb2FkIiwidmFsdWUiLCJ0cmltIiwibGluZXMiLCJsaW5lIiwid29yZCIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsInBpZWNlcyIsImxlbmd0aCIsInBpZWNlIiwic3BsaWNlIiwiam9pbiIsImNhbmRpZGF0ZSIsInB1c2giLCJ0ZXh0U2Vjb25kYXJ5IiwiZm9udFNpemVzIiwiYm9keSIsIm1hcCIsInRleHQiLCJpbmRleCIsIl9jIiwiUmVwb3J0c1BhZ2UiLCJfcyIsInNob3AiLCJwYXJhbXMiLCJzZXRQYXJhbXMiLCJsYXRlc3RQYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJwZW5kaW5nU2VhcmNoIiwiY29tbWl0dGVkU2VhcmNoIiwidG9TdHJpbmciLCJjdXJyZW50Iiwic3VtbWFyeSIsImNhblJlYWRKb2JzIiwiam9icyIsInF1ZXJ5IiwibGltaXQiLCJjdXJzb3IiLCJnZXQiLCJ1bmRlZmluZWQiLCJydW4iLCJyZXF1ZXN0ZWRUeXBlIiwidHlwZSIsInNuYXBzaG90QXNPZiIsImRhdGEiLCJhc09mIiwiZGVmYXVsdFJhbmdlIiwiY3VycmVudERhdGUiLCJ0aW1lem9uZSIsImZyb21EYXRlIiwic2xpY2UiLCJ0b0RhdGUiLCJmcm9tVmFsdWUiLCJ0b1ZhbHVlIiwicmVhZFJlcG9ydERhdGUiLCJrZXkiLCJoYXMiLCJmcm9tIiwidG8iLCJzZXRSZXBvcnRQYXJhbSIsIm5leHQiLCJzZXQiLCJmbHVzaFN5bmMiLCJyYW5nZUVycm9yIiwic2V0UmFuZ2VFcnJvciIsImxhc3RFeHBvcnQiLCJzZXRMYXN0RXhwb3J0IiwiY2FuRXhwb3J0UmVwb3J0cyIsImNhbkV4cG9ydFNvdXJjZSIsImF2YWlsYWJsZVJlcG9ydHMiLCJyZXBvcnRBdmFpbGFibGUiLCJpbmNsdWRlcyIsImNoYW5nZWQiLCJyZXBsYWNlIiwic3VibWl0IiwiUmFuZ2VFcnJvciIsInJlcXVlc3QiLCJyZXBvcnRUeXBlIiwiZm9ybWF0IiwicmVzcG9uc2UiLCJleGVjdXRlIiwiam9iIiwiZXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlRXhwb3J0IiwibGFzdERvd25sb2FkIiwic3RhdHVzIiwiZG93bmxvYWRVcmwiLCJsb2NhdGlvbiIsIm9yaWdpbiIsIl9fTU9DS19fIiwieHMiLCJ4bCIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJldmVudCIsInRhcmdldCIsInJlcG9ydCIsInNtIiwiaW5wdXRMYWJlbCIsInNocmluayIsInBlbmRpbmciLCJpZCIsImFjdGlvbnMiLCJsaW5rVGFyZ2V0IiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJjb250cm9sIiwiY29sb3IiLCJmb250V2VpZ2h0IiwidHlwb2dyYXBoeSIsInNlbWlib2xkIiwiYmdjb2xvciIsInRleHREZWNvcmF0aW9uIiwib3V0bGluZSIsImZvY3VzUmluZyIsIndpZHRoIiwib3V0bGluZUNvbG9yIiwib3V0bGluZU9mZnNldCIsImNvbnRyb2xPZmZzZXQiLCJ3YXJuaW5ncyIsIndhcm5pbmciLCJsYWJlbCIsInJlbmRlciIsImtpbmQiLCJhbGlnbiIsImNvbXBsZXRlZCIsInRvdGFsIiwidXBkYXRlZEF0IiwicGFnZSIsImNvbnRleHRHYXAiLCJNYXJrZXRpbmdQYWdlIiwiX3MyIiwic2VhcmNoIiwiZnJvbVBhcmFtIiwidG9QYXJhbSIsImJ1Y2tldFBhcmFtIiwiaGFzRGF0ZUZpbHRlciIsImFwcGxpZWRFcnJvciIsIm1hcmtldGluZ1JhbmdlRXJyb3IiLCJidWNrZXQiLCJPYmplY3QiLCJrZXlzIiwibSIsIm1hcmtldGluZ1BlcmlvZCIsInBlcmlvZCIsImRyYWZ0Iiwic2V0RHJhZnQiLCJzaG93RmlsdGVyRXJyb3IiLCJzZXRTaG93RmlsdGVyRXJyb3IiLCJmcm9tUmVmIiwidG9SZWYiLCJidWNrZXRSZWYiLCJkcmFmdEVycm9yIiwidmlzaWJsZUZpbHRlckVycm9yIiwiYXBwbHlGaWx0ZXIiLCJwcmV2ZW50RGVmYXVsdCIsImZpZWxkIiwiZm9jdXMiLCJub3RpY2UiLCJhZnRlckdhcCIsIm1kIiwidG9vbGJhciIsImNvbnRyb2xHYXAiLCJrbm93bkF0dHJpYnV0ZWRPcmRlcnMiLCJ1bmtub3duQXR0cmlidXRpb25PcmRlcnMiLCJhY3R1YWxTcGVuZCIsImVzdGltYXRlZFNwZW5kIiwic2VjdGlvbkFmdGVyIiwibmFtZSIsImxnIiwiaGVpZ2h0IiwiY2hhcnRWaWV3cG9ydEluc2V0IiwidHJlbmQiLCJib3JkZXJEZWNvcmF0aXZlIiwiTWF0aCIsIm1heCIsImNlaWwiLCJTdHJpbmciLCJiYWNrZ3JvdW5kIiwicmFpc2VkIiwidGV4dFByaW1hcnkiLCJhY2NlbnQiLCJlbXB0eVN0YXRlSW5zZXQiLCJwb2ludCIsImxpc3RTdXJmYWNlSW5zZXQiLCJwIiwibGlzdE1hcmtlckluc2V0IiwibGlzdEl0ZW1HYXAiLCJ0b3BRdWVzdGlvbnMiLCJxdWVzdGlvbiIsImxvc3RTYWxlUmVhc29ucyIsInJlYXNvbiIsImNvdW50Iiwic2VjdGlvbkJlZm9yZSIsImFsbG93RGVmYXVsdCIsImRheXMiLCJmbG9vciIsIkRhdGUiLCJwYXJzZSIsIl9jMiIsIl9jMyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBGb3JtRXZlbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB2aXN1YWxTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL3Zpc3VhbCc7XG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEFsZXJ0LCBCb3gsIEJ1dHRvbiwgTGluaywgTWVudUl0ZW0sIFN0YWNrLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7IEJhciwgQmFyQ2hhcnQsIENhcnRlc2lhbkdyaWQsIExlZ2VuZCwgUmVzcG9uc2l2ZUNvbnRhaW5lciwgVG9vbHRpcCwgWEF4aXMsIFlBeGlzIH0gZnJvbSAncmVjaGFydHMnO1xuaW1wb3J0IHR5cGUgeyBFeHBvcnRSZXF1ZXN0LCBKb2IsIE1hcmtldGluZ0J1Y2tldCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgY29sb3JzLCB0b2tlbnMgfSBmcm9tICdAYm90c2FsZXMvdG9rZW5zJztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJy4uLy4uL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlU2NvcGUsIHVzZUNhbiB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyBkYXRlVGltZSwgZm9ybWF0RGF0ZU9ubHksIGlzVmFsaWREYXRlT25seSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgQW1vdW50LCBEYXRhVGFibGUsIERldGFpbExpbmUsIEVycm9yTm90aWNlLCBQYWdlSGVhZGVyLCBQYW5lbCwgUGFnZXIsIFF1ZXJ5U3RhdGUsIFJvdXRlTGluaywgU3RhdCwgU3RhdHMsIFN0YXR1cyB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb25lbnRzJztcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2xheW91dCc7XG5pbXBvcnQgeyBhdXRob3JpemVkRG93bmxvYWRIcmVmLCBkYXRlSW5UaW1lem9uZSwgcmVwb3J0RGF0ZUJvdW5kYXJ5LCByZXBvcnRGaWxlbmFtZSB9IGZyb20gJy4vcmVwb3J0LXV0aWxzJztcblxuY29uc3QgcmVwb3J0TGFiZWxzOiBSZWNvcmQ8RXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddLCBzdHJpbmc+ID0ge1xuICAgIGludmVudG9yeTogJ1Thu5NuIGtobycsIG9yZGVyczogJ8SQxqFuIGjDoG5nJywgY2FzaGZsb3c6ICdEw7JuZyB0aeG7gW4nLCBwcm9maXRfbG9zczogJ0zhu6NpIG5odeG6rW4nLFxufTtcbmNvbnN0IHNvdXJjZVBlcm1pc3Npb25zOiBSZWNvcmQ8RXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddLCBzdHJpbmc+ID0ge1xuICAgIGludmVudG9yeTogJ2ludmVudG9yeS5yZWFkJywgb3JkZXJzOiAnb3JkZXJzLnJlYWQnLCBjYXNoZmxvdzogJ2ZpbmFuY2UucmVhZCcsIHByb2ZpdF9sb3NzOiAnZmluYW5jZS5yZWFkJyxcbn07XG5cbmZ1bmN0aW9uIE1hcmtldGluZ1JlYXNvblRpY2soeyB4ID0gMCwgeSA9IDAsIHBheWxvYWQgfTogeyB4PzogbnVtYmVyOyB5PzogbnVtYmVyOyBwYXlsb2FkPzogeyB2YWx1ZT86IHVua25vd24gfSB9KSB7XG4gICAgY29uc3QgdmFsdWUgPSB0eXBlb2YgcGF5bG9hZD8udmFsdWUgPT09ICdzdHJpbmcnID8gcGF5bG9hZC52YWx1ZS50cmltKCkgOiAnJztcbiAgICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcbiAgICBsZXQgbGluZSA9ICcnO1xuICAgIGZvciAoY29uc3Qgd29yZCBvZiB2YWx1ZS5zcGxpdCgvXFxzKy91KS5maWx0ZXIoQm9vbGVhbikpIHtcbiAgICAgICAgY29uc3QgcGllY2VzID0gWy4uLndvcmRdO1xuICAgICAgICB3aGlsZSAocGllY2VzLmxlbmd0aCkge1xuICAgICAgICAgICAgY29uc3QgcGllY2UgPSBwaWVjZXMuc3BsaWNlKDAsIDgpLmpvaW4oJycpO1xuICAgICAgICAgICAgY29uc3QgY2FuZGlkYXRlID0gbGluZSA/IGAke2xpbmV9ICR7cGllY2V9YCA6IHBpZWNlO1xuICAgICAgICAgICAgaWYgKGxpbmUgJiYgWy4uLmNhbmRpZGF0ZV0ubGVuZ3RoID4gOCkge1xuICAgICAgICAgICAgICAgIGxpbmVzLnB1c2gobGluZSk7XG4gICAgICAgICAgICAgICAgbGluZSA9IHBpZWNlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBsaW5lID0gY2FuZGlkYXRlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChsaW5lKSBsaW5lcy5wdXNoKGxpbmUpO1xuXG4gICAgcmV0dXJuIDx0ZXh0IHg9e3h9IHk9e3l9IGR5PXsxMn0gdGV4dEFuY2hvcj1cIm1pZGRsZVwiIGZpbGw9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSBmb250U2l6ZT17dG9rZW5zLmZvbnRTaXplcy5ib2R5fT5cbiAgICAgICAge2xpbmVzLm1hcCgodGV4dCwgaW5kZXgpID0+IDx0c3BhbiBrZXk9e2Ake2luZGV4fS0ke3RleHR9YH0geD17eH0gZHk9e2luZGV4ID8gMTQgOiAwfT57dGV4dH17aW5kZXggPCBsaW5lcy5sZW5ndGggLSAxID8gJyAnIDogJyd9PC90c3Bhbj4pfVxuICAgIDwvdGV4dD47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXBvcnRzUGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgW3BhcmFtcywgc2V0UGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IGxhdGVzdFBhcmFtcyA9IHVzZVJlZihuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcykpO1xuICAgIGNvbnN0IHBlbmRpbmdTZWFyY2ggPSB1c2VSZWY8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgY29tbWl0dGVkU2VhcmNoID0gcGFyYW1zLnRvU3RyaW5nKCk7XG4gICAgICAgIGlmIChwZW5kaW5nU2VhcmNoLmN1cnJlbnQgIT09IG51bGwgJiYgcGVuZGluZ1NlYXJjaC5jdXJyZW50ICE9PSBjb21taXR0ZWRTZWFyY2gpIHJldHVybjtcbiAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7XG4gICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG51bGw7XG4gICAgfSwgW3BhcmFtc10pO1xuICAgIGNvbnN0IHN1bW1hcnkgPSB1c2VBcGkoJ2dldFJlcG9ydFN1bW1hcnknKTtcbiAgICBjb25zdCBjYW5SZWFkSm9icyA9IHVzZUNhbignam9icy5yZWFkJyk7XG4gICAgY29uc3Qgam9icyA9IHVzZUFwaSgnbGlzdEpvYnMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAxMCwgY3Vyc29yOiBwYXJhbXMuZ2V0KCdjdXJzb3InKSB8fCB1bmRlZmluZWQgfSB9LCBjYW5SZWFkSm9icyk7XG4gICAgY29uc3QgcnVuID0gdXNlQ29tbWFuZCgnY3JlYXRlRXhwb3J0JywgWydsaXN0Sm9icyddKTtcbiAgICBjb25zdCByZXF1ZXN0ZWRUeXBlID0gcGFyYW1zLmdldCgncmVwb3J0VHlwZScpO1xuICAgIGNvbnN0IHR5cGU6IEV4cG9ydFJlcXVlc3RbJ3JlcG9ydFR5cGUnXSA9IHJlcXVlc3RlZFR5cGUgPT09ICdpbnZlbnRvcnknIHx8IHJlcXVlc3RlZFR5cGUgPT09ICdjYXNoZmxvdycgfHwgcmVxdWVzdGVkVHlwZSA9PT0gJ3Byb2ZpdF9sb3NzJyA/IHJlcXVlc3RlZFR5cGUgOiAnb3JkZXJzJztcbiAgICBjb25zdCBzbmFwc2hvdEFzT2YgPSBzdW1tYXJ5LmRhdGE/LmRhdGEuYXNPZjtcbiAgICBjb25zdCBkZWZhdWx0UmFuZ2UgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFzbmFwc2hvdEFzT2YpIHJldHVybiBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudERhdGUgPSBkYXRlSW5UaW1lem9uZShzbmFwc2hvdEFzT2YsIHNob3AudGltZXpvbmUpO1xuICAgICAgICAgICAgcmV0dXJuIHsgZnJvbURhdGU6IGAke2N1cnJlbnREYXRlLnNsaWNlKDAsIDcpfS0wMWAsIHRvRGF0ZTogY3VycmVudERhdGUgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7IHJldHVybiBudWxsOyB9XG4gICAgfSwgW3Nob3AudGltZXpvbmUsIHNuYXBzaG90QXNPZl0pO1xuICAgIGNvbnN0IGZyb21WYWx1ZSA9IHBhcmFtcy5nZXQoJ2Zyb21EYXRlJyk7XG4gICAgY29uc3QgdG9WYWx1ZSA9IHBhcmFtcy5nZXQoJ3RvRGF0ZScpO1xuICAgIGNvbnN0IHJlYWRSZXBvcnREYXRlID0gKGtleTogJ2Zyb21EYXRlJyB8ICd0b0RhdGUnLCB2YWx1ZTogc3RyaW5nIHwgbnVsbCkgPT4ge1xuICAgICAgICBpZiAoaXNWYWxpZERhdGVPbmx5KHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuICAgICAgICBpZiAocGFyYW1zLmhhcyhrZXkpICYmIHZhbHVlID09PSAnJykgcmV0dXJuICcnO1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJhbmdlPy5ba2V5XSB8fCAnJztcbiAgICB9O1xuICAgIGNvbnN0IGZyb20gPSByZWFkUmVwb3J0RGF0ZSgnZnJvbURhdGUnLCBmcm9tVmFsdWUpO1xuICAgIGNvbnN0IHRvID0gcmVhZFJlcG9ydERhdGUoJ3RvRGF0ZScsIHRvVmFsdWUpO1xuICAgIGNvbnN0IHNldFJlcG9ydFBhcmFtID0gKGtleTogJ3JlcG9ydFR5cGUnIHwgJ2Zyb21EYXRlJyB8ICd0b0RhdGUnLCB2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxhdGVzdFBhcmFtcy5jdXJyZW50KTtcbiAgICAgICAgaWYgKGtleSA9PT0gJ3JlcG9ydFR5cGUnKSBuZXh0LnNldChrZXksIHZhbHVlKTtcbiAgICAgICAgZWxzZSBuZXh0LnNldChrZXksIGlzVmFsaWREYXRlT25seSh2YWx1ZSkgPyB2YWx1ZSA6ICcnKTtcbiAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgPSBuZXh0LnRvU3RyaW5nKCk7XG4gICAgICAgIHNldFBhcmFtcyhuZXh0LCB7IGZsdXNoU3luYzogdHJ1ZSB9KTtcbiAgICB9O1xuICAgIGNvbnN0IFtyYW5nZUVycm9yLCBzZXRSYW5nZUVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbbGFzdEV4cG9ydCwgc2V0TGFzdEV4cG9ydF0gPSB1c2VTdGF0ZTx7IGpvYjogSm9iOyB0eXBlOiBFeHBvcnRSZXF1ZXN0WydyZXBvcnRUeXBlJ107IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgY2FuRXhwb3J0UmVwb3J0cyA9IHVzZUNhbigncmVwb3J0cy5leHBvcnQnKTtcbiAgICBjb25zdCBjYW5FeHBvcnRTb3VyY2UgPSB1c2VDYW4oc291cmNlUGVybWlzc2lvbnNbdHlwZV0pO1xuICAgIGNvbnN0IGF2YWlsYWJsZVJlcG9ydHMgPSBzdW1tYXJ5LmRhdGE/LmRhdGEuYXZhaWxhYmxlUmVwb3J0cyB8fCBbXTtcbiAgICBjb25zdCByZXBvcnRBdmFpbGFibGUgPSBhdmFpbGFibGVSZXBvcnRzLmluY2x1ZGVzKHR5cGUpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFzbmFwc2hvdEFzT2YpIHJldHVybjtcbiAgICAgICAgaWYgKCFkZWZhdWx0UmFuZ2UpIHtcbiAgICAgICAgICAgIHNldFJhbmdlRXJyb3IoJ03DumkgZ2nhu50gY+G7rWEgaMOgbmcgaG/hurdjIG3hu5FjIHRo4budaSBnaWFuIGLDoW8gY8OhbyBraMO0bmcgaOG7o3AgbOG7hy4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobGF0ZXN0UGFyYW1zLmN1cnJlbnQpO1xuICAgICAgICAgICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0ZWRUeXBlICE9PSAnaW52ZW50b3J5JyAmJiByZXF1ZXN0ZWRUeXBlICE9PSAnY2FzaGZsb3cnICYmIHJlcXVlc3RlZFR5cGUgIT09ICdwcm9maXRfbG9zcycgJiYgcmVxdWVzdGVkVHlwZSAhPT0gJ29yZGVycycpIHtcbiAgICAgICAgICAgICAgICBuZXh0LnNldCgncmVwb3J0VHlwZScsICdvcmRlcnMnKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFyYW1zLmhhcygnZnJvbURhdGUnKSB8fCAoZnJvbVZhbHVlICYmICFpc1ZhbGlkRGF0ZU9ubHkoZnJvbVZhbHVlKSkpIHtcbiAgICAgICAgICAgICAgICBuZXh0LnNldCgnZnJvbURhdGUnLCBkZWZhdWx0UmFuZ2UuZnJvbURhdGUpO1xuICAgICAgICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFwYXJhbXMuaGFzKCd0b0RhdGUnKSB8fCAodG9WYWx1ZSAmJiAhaXNWYWxpZERhdGVPbmx5KHRvVmFsdWUpKSkge1xuICAgICAgICAgICAgICAgIG5leHQuc2V0KCd0b0RhdGUnLCBkZWZhdWx0UmFuZ2UudG9EYXRlKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICAgICAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICAgICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG5leHQudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICBzZXRQYXJhbXMobmV4dCwgeyByZXBsYWNlOiB0cnVlLCBmbHVzaFN5bmM6IHRydWUgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggeyBzZXRSYW5nZUVycm9yKCdNw7ppIGdp4budIGPhu61hIGjDoG5nIGhv4bq3YyBt4buRYyB0aOG7nWkgZ2lhbiBiw6FvIGPDoW8ga2jDtG5nIGjhu6NwIGzhu4cuJyk7IH1cbiAgICB9LCBbZGVmYXVsdFJhbmdlLCBwYXJhbXMsIHJlcXVlc3RlZFR5cGUsIGZyb21WYWx1ZSwgdG9WYWx1ZSwgc2V0UGFyYW1zLCBzbmFwc2hvdEFzT2ZdKTtcblxuICAgIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0UmFuZ2VFcnJvcignJyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoIXNuYXBzaG90QXNPZiB8fCAhZnJvbSB8fCAhdG8pIHRocm93IG5ldyBSYW5nZUVycm9yKCdDaMawYSBjw7Mgc25hcHNob3QgaG/hurdjIGtob+G6o25nIG5nw6B5IMSR4bqneSDEkeG7py4nKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgcmVwb3J0VHlwZTogdHlwZSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6ICdjc3YnLFxuICAgICAgICAgICAgICAgIGZyb206IHJlcG9ydERhdGVCb3VuZGFyeShmcm9tLCAnc3RhcnQnLCBzaG9wLnRpbWV6b25lKSxcbiAgICAgICAgICAgICAgICB0bzogcmVwb3J0RGF0ZUJvdW5kYXJ5KHRvLCAnZW5kJywgc2hvcC50aW1lem9uZSksXG4gICAgICAgICAgICAgICAgdGltZXpvbmU6IHNob3AudGltZXpvbmUsXG4gICAgICAgICAgICAgICAgc25hcHNob3RBc09mLFxuICAgICAgICAgICAgfSBzYXRpc2ZpZXMgRXhwb3J0UmVxdWVzdDtcbiAgICAgICAgICAgIHNldExhc3RFeHBvcnQobnVsbCk7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHJ1bi5leGVjdXRlKHsgYm9keTogcmVxdWVzdCB9KTtcbiAgICAgICAgICAgIHNldExhc3RFeHBvcnQoeyBqb2I6IHJlc3BvbnNlLmRhdGEsIHR5cGUsIGZyb20sIHRvIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgUmFuZ2VFcnJvcikgc2V0UmFuZ2VFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaGFuZGxlRXhwb3J0ID0gKCkgPT4geyB2b2lkIHN1Ym1pdCgpOyB9O1xuXG4gICAgY29uc3QgbGFzdERvd25sb2FkID0gbGFzdEV4cG9ydD8uam9iLnN0YXR1cyA9PT0gJ3N1Y2NlZWRlZCcgJiYgbGFzdEV4cG9ydC5qb2IuZG93bmxvYWRVcmxcbiAgICAgICAgPyBhdXRob3JpemVkRG93bmxvYWRIcmVmKGxhc3RFeHBvcnQuam9iLmRvd25sb2FkVXJsLCBsb2NhdGlvbi5vcmlnaW4sIF9fTU9DS19fKVxuICAgICAgICA6IG51bGw7XG5cbiAgICByZXR1cm4gPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJCw6FvIGPDoW8gJiB4deG6pXQgZOG7ryBsaeG7h3VcIiBzdWJ0aXRsZT1cIlh14bqldCBzbmFwc2hvdCBkbyBBUEkgdOG6oW87IHPhu5EgbGnhu4d1IHThu5VuZyBo4bujcCBraMO0bmcgxJHGsOG7o2MgdMOtbmggdOG7qyBt4buZdCB0cmFuZyBkYW5oIHPDoWNoLlwiIC8+XG4gICAgICAgIDxTZWN0aW9uR3JpZCBkYXRhLXRlc3RpZD1cInJlcG9ydHMtbWFpbi1sYXlvdXRcIiBjb2x1bW5zPXt7IHhzOiAnbWlubWF4KDAsIDFmciknLCB4bDogJ21pbm1heCgwLCAxLjJmcikgbWlubWF4KDAsIC44ZnIpJyB9fSBhbGlnbkl0ZW1zPXsnc3RhcnQnfSBnZW9tZXRyeT17e21pbldpZHRoOiAwfX0+XG4gICAgICAgICAgICA8UGFnZVNlY3Rpb25zIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1wYWdlLXNlY3Rpb25zXCIgPlxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtzdW1tYXJ5fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICAgICAge3N1bW1hcnkuZGF0YSAmJiA8UGFuZWwgdGl0bGU9XCJU4bqhbyB04buHcCBiw6FvIGPDoW9cIiBzdWJ0aXRsZT1cIk5nw6B5IMSRxrDhu6NjIGhp4buDdSB0aGVvIG3DumkgZ2nhu50gY+G7rWEgaMOgbmcgdsOgIGfhu61pIHRow6BuaCBt4buRYyB0aOG7nWkgZ2lhbiByw7UgcsOgbmcuXCIgYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1GaWVsZHMgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLWV4cG9ydC1mb3JtLWxheW91dFwiIGdlb21ldHJ5PXt7bWF4V2lkdGg6IDc2MH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17cnVuLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyYW5nZUVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3JhbmdlRXJyb3J9PC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkLDoW8gY8Ohb1wiIHNlbGVjdCB2YWx1ZT17dHlwZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJ29yZGVycycgfHwgdmFsdWUgPT09ICdpbnZlbnRvcnknIHx8IHZhbHVlID09PSAnY2FzaGZsb3cnIHx8IHZhbHVlID09PSAncHJvZml0X2xvc3MnKSBzZXRSZXBvcnRQYXJhbSgncmVwb3J0VHlwZScsIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TGFzdEV4cG9ydChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVJlcG9ydHMubWFwKHJlcG9ydCA9PiA8TWVudUl0ZW0gdmFsdWU9e3JlcG9ydH0ga2V5PXtyZXBvcnR9PntyZXBvcnRMYWJlbHNbcmVwb3J0XX08L01lbnVJdGVtPil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVJlcG9ydHMubGVuZ3RoID09PSAwICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5WYWkgdHLDsiBoaeG7h24gdOG6oWkgY2jGsGEgY8OzIGxv4bqhaSBiw6FvIGPDoW8ga2jhuqMgZOG7pW5nLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtRmllbGRzIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1kYXRlLWZpbHRlcnNcIiBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVOG7qyBuZ8OgeVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e2Zyb219IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRSZXBvcnRQYXJhbSgnZnJvbURhdGUnLCBldmVudC50YXJnZXQudmFsdWUpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBmdWxsV2lkdGggLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIsSQ4bq/biBuZ8OgeVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e3RvfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVwb3J0UGFyYW0oJ3RvRGF0ZScsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk3DumkgZ2nhu51cIj57c2hvcC50aW1lem9uZX08L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJTbmFwc2hvdCBBUElcIj57c25hcHNob3RBc09mID8gZGF0ZVRpbWUoc25hcHNob3RBc09mLCBzaG9wLnRpbWV6b25lKSA6ICdDaMawYSBjw7Mgc25hcHNob3QnfTwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWNhbkV4cG9ydFJlcG9ydHMgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBraMO0bmcgY8OzIHF1eeG7gW4gcmVwb3J0cy5leHBvcnQuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbkV4cG9ydFJlcG9ydHMgJiYgIWNhbkV4cG9ydFNvdXJjZSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+UXV54buBbiB4deG6pXQga2jDtG5nIHRoYXkgdGjhur8gcXV54buBbiDEkeG7jWMgbmd14buTbiB7c291cmNlUGVybWlzc2lvbnNbdHlwZV19OyBsb+G6oWkgYsOhbyBjw6FvIG7DoHkgY2jGsGEgdGjhu4MgeHXhuqV0LjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5FeHBvcnRSZXBvcnRzICYmIGNhbkV4cG9ydFNvdXJjZSAmJiAhcmVwb3J0QXZhaWxhYmxlICYmIGF2YWlsYWJsZVJlcG9ydHMubGVuZ3RoID4gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+QVBJIGtow7RuZyBsaeG7h3Qga8OqIGxv4bqhaSBiw6FvIGPDoW8gbsOgeSBjaG8gdmFpIHRyw7IgaGnhu4duIHThuqFpLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydH0gZGlzYWJsZWQ9eyFjYW5FeHBvcnRSZXBvcnRzIHx8ICFjYW5FeHBvcnRTb3VyY2UgfHwgIXJlcG9ydEF2YWlsYWJsZSB8fCAhc25hcHNob3RBc09mIHx8ICFmcm9tIHx8ICF0byB8fCBmcm9tID4gdG8gfHwgcnVuLnBlbmRpbmd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cnVuLnBlbmRpbmcgPyAnxJBhbmcgdOG6oW8gc25hcHNob3TigKYnIDogJ1ThuqFvIHThu4dwIGLDoW8gY8OhbyBDU1YnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RXhwb3J0ICYmIDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gIGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7bGFzdEV4cG9ydC5qb2IuaWR9YH0+VGhlbyBkw7VpIGPDtG5nIHZp4buHYyB7bGFzdEV4cG9ydC5qb2IuaWR9PC9Sb3V0ZUxpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RG93bmxvYWQgJiYgPExpbmsgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLWV4cG9ydC1kb3dubG9hZFwiIGNvbXBvbmVudD1cImFcIiBocmVmPXtsYXN0RG93bmxvYWR9IGRvd25sb2FkPXtyZXBvcnRGaWxlbmFtZShsYXN0RXhwb3J0LnR5cGUsIGxhc3RFeHBvcnQuZnJvbSwgbGFzdEV4cG9ydC50byl9IHVuZGVybGluZT1cIm5vbmVcIiBzeD17W2xheW91dFN4LmFjdGlvbnMubGlua1RhcmdldCwgeyBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wsIGNvbG9yOiAndGV4dC5wcmltYXJ5JywgZm9udFdlaWdodDogdmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnNlbWlib2xkLCAnJjpob3Zlcic6IHsgYmdjb2xvcjogJ2FjdGlvbi5ob3ZlcicsIHRleHREZWNvcmF0aW9uOiAnbm9uZScgfSwgJyY6Zm9jdXMtdmlzaWJsZSc6IHsgb3V0bGluZTogYCR7dG9rZW5zLmZvY3VzUmluZy53aWR0aH1weCBzb2xpZGAsIG91dGxpbmVDb2xvcjogJ3ByaW1hcnkubGlnaHQnLCBvdXRsaW5lT2Zmc2V0OiB0b2tlbnMuZm9jdXNSaW5nLmNvbnRyb2xPZmZzZXQgfSB9XX0+VOG6o2kgQ1NWPC9MaW5rPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RFeHBvcnQuam9iLnN0YXR1cyAhPT0gJ3N1Y2NlZWRlZCcgJiYgPEFsZXJ0IHNldmVyaXR5PXtsYXN0RXhwb3J0LmpvYi5zdGF0dXMgPT09ICdwYXJ0aWFsJyB8fCBsYXN0RXhwb3J0LmpvYi5zdGF0dXMgPT09ICdmYWlsZWQnID8gJ3dhcm5pbmcnIDogJ2luZm8nfT5U4buHcCBjaOG7iSDEkcaw4bujYyB04bqjaSBraGkgY8O0bmcgdmnhu4djIHjDoWMgbmjhuq1uIHN1Y2NlZWRlZC48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RFeHBvcnQuam9iLnN0YXR1cyA9PT0gJ3N1Y2NlZWRlZCcgJiYgbGFzdEV4cG9ydC5qb2IuZG93bmxvYWRVcmwgJiYgIWxhc3REb3dubG9hZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VVJMIHThuqNpIGtow7RuZyBo4bujcCBs4buHIGhv4bq3YyBjaMawYSB0aHXhu5ljIEhUVFBTL25ndeG7k24gaGnhu4duIHThuqFpLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQWN0aW9uR3JvdXA+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5LmRhdGEuZGF0YS53YXJuaW5ncy5tYXAoKHdhcm5pbmcsIGluZGV4KSA9PiA8QWxlcnQga2V5PXtgJHtpbmRleH0tJHt3YXJuaW5nfWB9IHNldmVyaXR5PVwiaW5mb1wiPnt3YXJuaW5nfTwvQWxlcnQ+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+QVBJIGhp4buHbiBjaOG7iSB0cuG6oyBkYW5oIHPDoWNoIGxv4bqhaSBiw6FvIGPDoW8gdsOgIHRo4budaSDEkWnhu4NtIHNuYXBzaG90OyBi4buZIGzhu41jIG5nw6B5IMOhcCBk4bulbmcgY2hvIGzhu4duaCB4deG6pXQuIEtow7RuZyBjw7Mgc2VyaWVzIGhv4bq3YyB04buVbmcgc+G7kSBsaeG7h3UgxJHhu4MgZ2lhbyBkaeG7h24gdOG7sSBzdXkgcmEuPC9BbGVydD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD59XG4gICAgICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxuICAgICAgICAgICAgICAgIHtjYW5SZWFkSm9icyA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtqb2JzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICAgICAge2pvYnMuZGF0YSAmJiA8UGFuZWwgdGl0bGU9XCJDw7RuZyB2aeG7h2MgZ+G6p24gxJHDonlcIiBzdWJ0aXRsZT1cIlRy4bqhbmcgdGjDoWkgdsOgIHRp4bq/biDEkeG7mSBs4bqleSB04burIEFQSTsgdHJhbmcgaGnhu4duIHThuqFpIGPDsyB0aOG7gyBjaOG7qWEgbmhp4buBdSBsb+G6oWkgY8O0bmcgdmnhu4djLlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSByb3dzPXtqb2JzLmRhdGEuZGF0YX0gcm93S2V5PXtqb2IgPT4gam9iLmlkfSBsYWJlbD1cIkPDtG5nIHZp4buHYyBn4bqnbiDEkcOieVwiIGVtcHR5PVwiQ2jGsGEgY8OzIGPDtG5nIHZp4buHYyB0cm9uZyB0cmFuZyBuw6B5LlwiIGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICdNw6MgY8O0bmcgdmnhu4djJywgcmVuZGVyOiBqb2IgPT4gPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2pvYi5pZH1gfT57am9iLmlkfTwvUm91dGVMaW5rPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAna2luZCcsIGxhYmVsOiAnTG/huqFpJywgcmVuZGVyOiBqb2IgPT4gPFN0YXR1cyB2YWx1ZT17am9iLmtpbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0dXMnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGpvYiA9PiA8U3RhdHVzIHZhbHVlPXtqb2Iuc3RhdHVzfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncHJvZ3Jlc3MnLCBsYWJlbDogJ1Rp4bq/biDEkeG7mScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGpvYiA9PiBgJHtqb2IuY29tcGxldGVkfSAvICR7am9iLnRvdGFsID8/ICdDaMawYSBiaeG6v3QnfWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3VwZGF0ZWRBdCcsIGxhYmVsOiAnQ+G6rXAgbmjhuq10JywgcmVuZGVyOiBqb2IgPT4gZGF0ZVRpbWUoam9iLnVwZGF0ZWRBdCwgc2hvcC50aW1lem9uZSkgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17am9icy5kYXRhLnBhZ2V9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvUGFuZWw+fVxuICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT4gOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VmFpIHRyw7IgaGnhu4duIHThuqFpIGtow7RuZyBjw7Mgam9icy5yZWFkOyB0cuG6oW5nIHRow6FpIGPDtG5nIHZp4buHYyDEkcaw4bujYyDhuqluIHRoZW8gcXV54buBbi48L0FsZXJ0Pn1cbiAgICAgICAgICAgIDwvUGFnZVNlY3Rpb25zPlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiUGjhuqFtIHZpIGThu68gbGnhu4d1XCIgc3VidGl0bGU9XCJDaOG7iSBuaOG7r25nIGfDrCBBUEkgY3VuZyBj4bqlcCBt4bubaSDEkcaw4bujYyB0csOsbmggYsOgeSBuaMawIHPhu5EgbGnhu4d1LlwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgc3g9e2xheW91dFN4LnJlcG9ydC5jb250ZXh0R2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkLDoW8gY8OhbyBkw7JuZywgYmnhu4N1IMSR4buTIHbDoCB04buVbmcgaOG7o3AgdGhlbyBraG/huqNuZyBuZ8OgeSBjaMawYSBjw7MgdHJvbmcgZ2V0UmVwb3J0U3VtbWFyeS4gRnJvbnRlbmQga2jDtG5nIGPhu5luZyBk4buvIGxp4buHdSBwaMOibiB0cmFuZyDEkeG7gyB04bqhbyBLUEkgdGhheSB0aOG6vy48L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5UcuG6oW5nIHRow6FpIGV4cG9ydCDEkcaw4bujYyBs4bqleSByacOqbmcgdOG7qyBsaXN0Sm9iczsgVVJMIHThuqNpIGNo4buJIMSRxrDhu6NjIG3hu58gc2F1IGtoaSBBUEkgdHLhuqMgduG7gSBjw7RuZyB2aeG7h2MgaG/DoG4gdOG6pXQuPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9yZXBvcnRzL21hcmtldGluZ2B9PlhlbSB0aMO0bmcgdGluIG1hcmtldGluZzwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8L1NlY3Rpb25HcmlkPlxuICAgIDwvPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1hcmtldGluZ1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBzZWFyY2ggPSBwYXJhbXMudG9TdHJpbmcoKTtcbiAgICBjb25zdCBmcm9tUGFyYW0gPSBwYXJhbXMuZ2V0KCdmcm9tRGF0ZScpIHx8ICcnO1xuICAgIGNvbnN0IHRvUGFyYW0gPSBwYXJhbXMuZ2V0KCd0b0RhdGUnKSB8fCAnJztcbiAgICBjb25zdCBidWNrZXRQYXJhbSA9IHBhcmFtcy5nZXQoJ2J1Y2tldCcpIHx8ICdkYXknO1xuICAgIGNvbnN0IGhhc0RhdGVGaWx0ZXIgPSBwYXJhbXMuaGFzKCdmcm9tRGF0ZScpIHx8IHBhcmFtcy5oYXMoJ3RvRGF0ZScpO1xuICAgIGNvbnN0IGFwcGxpZWRFcnJvciA9IG1hcmtldGluZ1JhbmdlRXJyb3IoZnJvbVBhcmFtLCB0b1BhcmFtLCBidWNrZXRQYXJhbSwgIWhhc0RhdGVGaWx0ZXIpO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYXBwbGllZEVycm9yID8gdW5kZWZpbmVkIDoge1xuICAgICAgICAuLi4ocGFyYW1zLmhhcygnZnJvbURhdGUnKSA/IHsgZnJvbURhdGU6IGZyb21QYXJhbSB9IDoge30pLFxuICAgICAgICAuLi4ocGFyYW1zLmhhcygndG9EYXRlJykgPyB7IHRvRGF0ZTogdG9QYXJhbSB9IDoge30pLFxuICAgICAgICAuLi4ocGFyYW1zLmhhcygnYnVja2V0JykgPyB7IGJ1Y2tldDogYnVja2V0UGFyYW0gYXMgTWFya2V0aW5nQnVja2V0IH0gOiB7fSksXG4gICAgfTtcbiAgICBjb25zdCBkYXRhID0gdXNlQXBpKCdnZXRNYXJrZXRpbmdTdW1tYXJ5JywgcXVlcnkgJiYgT2JqZWN0LmtleXMocXVlcnkpLmxlbmd0aCA/IHsgcXVlcnkgfSA6IHVuZGVmaW5lZCwgIWFwcGxpZWRFcnJvcik7XG4gICAgY29uc3QgbSA9IGRhdGEuZGF0YT8uZGF0YTtcbiAgICBjb25zdCBtYXJrZXRpbmdQZXJpb2QgPSBtPy5wZXJpb2Q7XG4gICAgY29uc3QgW2RyYWZ0LCBzZXREcmFmdF0gPSB1c2VTdGF0ZSh7IGZyb21EYXRlOiBmcm9tUGFyYW0sIHRvRGF0ZTogdG9QYXJhbSwgYnVja2V0OiBidWNrZXRQYXJhbSB9KTtcbiAgICBjb25zdCBbc2hvd0ZpbHRlckVycm9yLCBzZXRTaG93RmlsdGVyRXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGZyb21SZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgdG9SZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgYnVja2V0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGRyYWZ0RXJyb3IgPSBtYXJrZXRpbmdSYW5nZUVycm9yKGRyYWZ0LmZyb21EYXRlLCBkcmFmdC50b0RhdGUsIGRyYWZ0LmJ1Y2tldCwgZmFsc2UpO1xuICAgIGNvbnN0IHZpc2libGVGaWx0ZXJFcnJvciA9IHNob3dGaWx0ZXJFcnJvciA/IGRyYWZ0RXJyb3IgOiBhcHBsaWVkRXJyb3I7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobWFya2V0aW5nUGVyaW9kKSB7XG4gICAgICAgICAgICBzZXREcmFmdCh7IGZyb21EYXRlOiBtYXJrZXRpbmdQZXJpb2QuZnJvbURhdGUsIHRvRGF0ZTogbWFya2V0aW5nUGVyaW9kLnRvRGF0ZSwgYnVja2V0OiBtYXJrZXRpbmdQZXJpb2QuYnVja2V0IH0pO1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyBmcm9tRGF0ZTogbWFya2V0aW5nUGVyaW9kLmZyb21EYXRlLCB0b0RhdGU6IG1hcmtldGluZ1BlcmlvZC50b0RhdGUsIGJ1Y2tldDogbWFya2V0aW5nUGVyaW9kLmJ1Y2tldCB9KTtcbiAgICAgICAgICAgIGlmIChuZXh0LnRvU3RyaW5nKCkgIT09IHNlYXJjaCkgc2V0UGFyYW1zKG5leHQsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgIH0sIFttYXJrZXRpbmdQZXJpb2QsIHNlYXJjaCwgc2V0UGFyYW1zXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBjdXJyZW50ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhzZWFyY2gpO1xuICAgICAgICBpZiAoIWN1cnJlbnQuaGFzKCdmcm9tRGF0ZScpICYmICFjdXJyZW50LmhhcygndG9EYXRlJykpIHJldHVybjtcbiAgICAgICAgc2V0RHJhZnQoeyBmcm9tRGF0ZTogY3VycmVudC5nZXQoJ2Zyb21EYXRlJykgfHwgJycsIHRvRGF0ZTogY3VycmVudC5nZXQoJ3RvRGF0ZScpIHx8ICcnLCBidWNrZXQ6IGN1cnJlbnQuZ2V0KCdidWNrZXQnKSB8fCAnZGF5JyB9KTtcbiAgICAgICAgc2V0U2hvd0ZpbHRlckVycm9yKGZhbHNlKTtcbiAgICB9LCBbc2VhcmNoXSk7XG5cbiAgICBjb25zdCBhcHBseUZpbHRlciA9IChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0U2hvd0ZpbHRlckVycm9yKHRydWUpO1xuICAgICAgICBpZiAoZHJhZnRFcnJvcikge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZHJhZnRFcnJvci5maWVsZCA9PT0gJ2Zyb21EYXRlJyA/IGZyb21SZWYuY3VycmVudCA6IGRyYWZ0RXJyb3IuZmllbGQgPT09ICd0b0RhdGUnID8gdG9SZWYuY3VycmVudCA6IGJ1Y2tldFJlZi5jdXJyZW50O1xuICAgICAgICAgICAgdGFyZ2V0Py5mb2N1cygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHsgZnJvbURhdGU6IGRyYWZ0LmZyb21EYXRlLCB0b0RhdGU6IGRyYWZ0LnRvRGF0ZSwgYnVja2V0OiBkcmFmdC5idWNrZXQgfSk7XG4gICAgICAgIHNldFNob3dGaWx0ZXJFcnJvcihmYWxzZSk7XG4gICAgICAgIHNldFBhcmFtcyhuZXh0KTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiVGjDtG5nIHRpbiBjaG8gbWFya2V0aW5nXCIgc3VidGl0bGU9XCLEkOG7gSB4deG6pXQgY2jhu4kgxJHhu41jOyB0cmFuZyBraMO0bmcgdOG7sSDEkcSDbmcgbuG7mWkgZHVuZyBob+G6t2MgdGhheSDEkeG7lWkgbmfDom4gc8OhY2guXCIgLz5cbiAgICAgICAge19fTU9DS19fICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT5T4buRIGxp4buHdSBt4bqrdSBkbyBBUEkgbcO0IHBo4buPbmcgdOG7lW5nIGjhu6NwOyBjaMawYSBr4bq/dCBu4buRaSB0w6BpIGtob+G6o24gcXXhuqNuZyBjw6FvIGhv4bq3YyBuZ3Xhu5NuIHBow6JuIGLhu5UgdGjhuq10LjwvQWxlcnQ+fVxuICAgICAgICA8UGFuZWwgdGl0bGU9XCJLaG/huqNuZyB0aOG7nWkgZ2lhbiBiw6FvIGPDoW9cIiBzdWJ0aXRsZT17YE5nw6B5IMSRxrDhu6NjIHTDrW5oIHRoZW8gbOG7i2NoICR7c2hvcC50aW1lem9uZX0gY+G7p2EgY+G7rWEgaMOgbmcuYH0gYm9keU1vZGU9XCJpbnNldFwiIGFmdGVyR2FwPVwic2VjdGlvblwiPlxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIG9uU3VibWl0PXthcHBseUZpbHRlcn0gZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctcmFuZ2UtZm9ybVwiPlxuICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBtZDogJ3JvdycgfX0gYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBtZDogJ2ZsZXgtZW5kJyB9fSBzeD17bGF5b3V0U3gudG9vbGJhci5jb250cm9sR2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBpbnB1dFJlZj17ZnJvbVJlZn0gdHlwZT1cImRhdGVcIiBsYWJlbD1cIlThu6sgbmfDoHlcIiB2YWx1ZT17ZHJhZnQuZnJvbURhdGV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgZnJvbURhdGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGVycm9yPXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnZnJvbURhdGUnfSBoZWxwZXJUZXh0PXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnZnJvbURhdGUnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnTmfDoHkgYuG6r3QgxJHhuqd1LCB0w61uaCBj4bqjIG5nw6B5IMSRw6MgY2jhu41uLid9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e3RvUmVmfSB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwixJDhur9uIG5nw6B5XCIgdmFsdWU9e2RyYWZ0LnRvRGF0ZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldERyYWZ0KHZhbHVlID0+ICh7IC4uLnZhbHVlLCB0b0RhdGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGVycm9yPXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAndG9EYXRlJ30gaGVscGVyVGV4dD17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ3RvRGF0ZScgPyB2aXNpYmxlRmlsdGVyRXJyb3IubWVzc2FnZSA6ICdU4buRaSDEkWEgMzY2IG5nw6B5LCB0w61uaCBj4bqjIGhhaSDEkeG6p3UuJ30gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBpbnB1dFJlZj17YnVja2V0UmVmfSBzZWxlY3QgbGFiZWw9XCJH4buZcCB0aGVvXCIgdmFsdWU9e2RyYWZ0LmJ1Y2tldH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldERyYWZ0KHZhbHVlID0+ICh7IC4uLnZhbHVlLCBidWNrZXQ6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9IGVycm9yPXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnYnVja2V0J30gaGVscGVyVGV4dD17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ2J1Y2tldCcgPyB2aXNpYmxlRmlsdGVyRXJyb3IubWVzc2FnZSA6ICdDaOG7jW4gbmfDoHksIHR14bqnbiBob+G6t2MgdGjDoW5nLid9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwiZGF5XCI+TmfDoHk8L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cIndlZWtcIj5UdeG6p248L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cIm1vbnRoXCI+VGjDoW5nPC9NZW51SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj7DgXAgZOG7pW5nPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckVycm9yICYmIGRyYWZ0RXJyb3IgJiYgPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57ZHJhZnRFcnJvci5tZXNzYWdlfTwvQWxlcnQ+fVxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICA8L1BhbmVsPlxuICAgICAgICB7YXBwbGllZEVycm9yID8gPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj48c3Ryb25nPkLhu5kgbOG7jWMgdHLDqm4gxJHGsOG7nW5nIGThuqtuIGtow7RuZyBo4bujcCBs4buHLjwvc3Ryb25nPiBIw6N5IHPhu61hIHRyxrDhu51uZyDEkcaw4bujYyDEkcOhbmggZOG6pXUgdHLGsOG7m2Mga2hpIMOhcCBk4bulbmcuPC9BbGVydD4gOiA8UXVlcnlTdGF0ZSBxdWVyeT17ZGF0YX0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e20gJiYgPD5cbiAgICAgICAgICAgIDxTdGF0cz5cbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIsSQxqFuIGPDsyBuZ3Xhu5NuIHjDoWMgxJHhu4tuaFwiIHZhbHVlPXttLmtub3duQXR0cmlidXRlZE9yZGVyc30gbm90ZT1cIsSQxrDhu6NjIEFQSSB04buVbmcgaOG7o3AgdHJvbmcga+G7s1wiIC8+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCLEkMahbiBjaMawYSByw7Ugbmd14buTblwiIHZhbHVlPXttLnVua25vd25BdHRyaWJ1dGlvbk9yZGVyc30gbm90ZT1cIkdp4buvIHJpw6puZywga2jDtG5nIHThu7EgZ8OhbiBuZ3Xhu5NuXCIgLz5cbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkNoaSBxdeG6o25nIGPDoW8gdGjhu7FjIHThur9cIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXttLmFjdHVhbFNwZW5kfSAvPn0gbm90ZT17bS5hY3R1YWxTcGVuZCA/ICdBUEkgY3VuZyBj4bqlcCBz4buRIHRo4buxYyB04bq/JyA6ICdL4buzIG7DoHkgY2jGsGEgY8OzIHPhu5EgdGjhu7FjIHThur8gdOG7qyBBUEknfSAvPlxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiQ2hpIHF14bqjbmcgY8OhbyDGsOG7m2MgdMOtbmhcIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXttLmVzdGltYXRlZFNwZW5kfSAvPn0gbm90ZT1cIsav4bubYyB0w61uaCBraMO0bmcgcGjhuqNpIHPhu5EgZ2hpIHPhu5VcIiAvPlxuICAgICAgICAgICAgPC9TdGF0cz5cbiAgICAgICAgICAgIDxTdGFjayBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1hcy1vZlwiIHN4PXtbbGF5b3V0U3gucmVwb3J0LmNvbnRleHRHYXAsIGxheW91dFN4LnBhZ2Uuc2VjdGlvbkFmdGVyXX0+XG4gICAgICAgICAgICAgICAge20ucGVyaW9kICYmIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiPkvhu7Mge2Zvcm1hdERhdGVPbmx5KG0ucGVyaW9kLmZyb21EYXRlKX0g4oCTIHtmb3JtYXREYXRlT25seShtLnBlcmlvZC50b0RhdGUpfSDCtyBn4buZcCB0aGVvIHttLnBlcmlvZC5idWNrZXQgPT09ICdkYXknID8gJ25nw6B5JyA6IG0ucGVyaW9kLmJ1Y2tldCA9PT0gJ3dlZWsnID8gJ3R14bqnbicgOiAndGjDoW5nJ308L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkPhuq1wIG5o4bqtdCB7ZGF0ZVRpbWUobS5hc09mLCBtLnBlcmlvZD8udGltZXpvbmUgfHwgc2hvcC50aW1lem9uZSl9IMK3IHtzaG9wLm5hbWV9IMK3IG3DumkgZ2nhu50ge20ucGVyaW9kPy50aW1lem9uZSB8fCBzaG9wLnRpbWV6b25lfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICA8U2VjdGlvbkdyaWQgZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctc2VjdGlvbnMtZ3JpZFwiIGNvbHVtbnM9e3sgeHM6ICcxZnInLCBsZzogJzFmciAxZnInIH19PlxuICAgICAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIsSQxqFuIHRoZW8gdGjhu51pIGdpYW5cIiBzdWJ0aXRsZT1cIlPhu5EgxJHGoW4gY8OzIG5ndeG7k24geMOhYyDEkeG7i25oIHbDoCBjaMawYSByw7Ugbmd14buTbiBkbyBBUEkgdOG7lW5nIGjhu6NwLlwiPlxuICAgICAgICAgICAgICAgICAgICA8Qm94IHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPXtgU+G7kSDEkcahbiB0aGVvICR7bS5wZXJpb2Q/LmJ1Y2tldCB8fCAna+G7syd9IHRyb25nIGtob+G6o25nIMSRw6MgY2jhu41uYH0gZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctdHJlbmQtY2hhcnRcIiBzeD17W3sgaGVpZ2h0OiAyODAgfSwgbGF5b3V0U3gucmVwb3J0LmNoYXJ0Vmlld3BvcnRJbnNldF19PlxuICAgICAgICAgICAgICAgICAgICAgICAge20udHJlbmQ/Lmxlbmd0aCA/IDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj48QmFyQ2hhcnQgZGF0YT17bS50cmVuZH0gYWNjZXNzaWJpbGl0eUxheWVyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZT17Y29sb3JzLmJvcmRlckRlY29yYXRpdmV9IHZlcnRpY2FsPXtmYWxzZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cImZyb21EYXRlXCIgc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gaW50ZXJ2YWw9e01hdGgubWF4KDAsIE1hdGguY2VpbChtLnRyZW5kLmxlbmd0aCAvIDcpIC0gMSl9IHRpY2tGb3JtYXR0ZXI9e3ZhbHVlID0+IGZvcm1hdERhdGVPbmx5KFN0cmluZyh2YWx1ZSkpfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBhbGxvd0RlY2ltYWxzPXtmYWxzZX0gc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBsYWJlbEZvcm1hdHRlcj17dmFsdWUgPT4gZm9ybWF0RGF0ZU9ubHkoU3RyaW5nKHZhbHVlKSl9IGNvbnRlbnRTdHlsZT17eyBiYWNrZ3JvdW5kOiBjb2xvcnMucmFpc2VkLCBjb2xvcjogY29sb3JzLnRleHRQcmltYXJ5LCBib3JkZXJDb2xvcjogY29sb3JzLmJvcmRlckRlY29yYXRpdmUgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGVnZW5kIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwia25vd25BdHRyaWJ1dGVkT3JkZXJzXCIgbmFtZT1cIkPDsyBuZ3Xhu5NuIHjDoWMgxJHhu4tuaFwiIGZpbGw9e2NvbG9ycy5hY2NlbnR9IHJhZGl1cz17WzMsIDMsIDAsIDBdfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cInVua25vd25BdHRyaWJ1dGlvbk9yZGVyc1wiIG5hbWU9XCJDaMawYSByw7Ugbmd14buTblwiIGZpbGw9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSByYWRpdXM9e1szLCAzLCAwLCAwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+PC9SZXNwb25zaXZlQ29udGFpbmVyPiA6IDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17bGF5b3V0U3gucmVwb3J0LmVtcHR5U3RhdGVJbnNldH0+QVBJIGNoxrBhIGPDsyBidWNrZXQgZOG7ryBsaeG7h3UgdHJvbmcga+G7syDEkcOjIGNo4buNbi48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSBsYWJlbD1cIlThu5VuZyBo4bujcCBtYXJrZXRpbmcgdGhlbyBr4buzXCIgcm93cz17bS50cmVuZCB8fCBbXX0gcm93S2V5PXtwb2ludCA9PiBwb2ludC5mcm9tRGF0ZX0gZW1wdHk9XCJDaMawYSBjw7MgZOG7ryBsaeG7h3UgdGhlbyBr4buzIHRyb25nIGtob+G6o25nIG7DoHkuXCIgY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyYW5nZScsIGxhYmVsOiAnS2hv4bqjbmcgbmfDoHknLCByZW5kZXI6IHBvaW50ID0+IGAke2Zvcm1hdERhdGVPbmx5KHBvaW50LmZyb21EYXRlKX0g4oCTICR7Zm9ybWF0RGF0ZU9ubHkocG9pbnQudG9EYXRlKX1gIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2tub3duJywgbGFiZWw6ICdDw7Mgbmd14buTbicsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHBvaW50ID0+IHBvaW50Lmtub3duQXR0cmlidXRlZE9yZGVycyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICd1bmtub3duJywgbGFiZWw6ICdDaMawYSByw7Ugbmd14buTbicsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHBvaW50ID0+IHBvaW50LnVua25vd25BdHRyaWJ1dGlvbk9yZGVycyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdlc3RpbWF0ZWQnLCBsYWJlbDogJ0NoaSDGsOG7m2MgdMOtbmgnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiA8QW1vdW50IHZhbHVlPXtwb2ludC5lc3RpbWF0ZWRTcGVuZH0gLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnYWN0dWFsJywgbGFiZWw6ICdDaGkgdGjhu7FjIHThur8nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiA8QW1vdW50IHZhbHVlPXtwb2ludC5hY3R1YWxTcGVuZH0gLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cbiAgICAgICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIkPDonUgaOG7j2kga2jDoWNoIHRoxrDhu51uZyBo4buPaVwiIHN1YnRpdGxlPVwiQ8OhYyBt4bulYyBkbyBBUEkgdOG7lW5nIGjhu6NwIGN1bmcgY+G6pXAuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctcXVlc3Rpb24tc3VyZmFjZVwiIHN4PXtsYXlvdXRTeC5yZXBvcnQubGlzdFN1cmZhY2VJbnNldH0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgY29tcG9uZW50PVwidWxcIiBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy10b3AtcXVlc3Rpb25zXCIgc3g9e1t7IG06IDAsIHA6IDAgfSwgbGF5b3V0U3gucmVwb3J0Lmxpc3RNYXJrZXJJbnNldCwgbGF5b3V0U3gucmVwb3J0Lmxpc3RJdGVtR2FwXX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge20udG9wUXVlc3Rpb25zLmxlbmd0aCA/IG0udG9wUXVlc3Rpb25zLm1hcCgocXVlc3Rpb24sIGluZGV4KSA9PiA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJsaVwiIGtleT17YCR7aW5kZXh9LSR7cXVlc3Rpb259YH0+e3F1ZXN0aW9ufTwvVHlwb2dyYXBoeT4pIDogPFR5cG9ncmFwaHkgY29tcG9uZW50PVwibGlcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+Q2jGsGEgY8OzIHRo4buRbmcga8OqIGPDonUgaOG7j2kgdHJvbmcga+G7syDEkcOjIGNo4buNbi48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJMw70gZG8ga2jDtG5nIGNo4buRdCDEkcahblwiIHN1YnRpdGxlPVwiQmnhu4N1IMSR4buTIHbDoCBi4bqjbmcgZMO5bmcgY8O5bmcgbeG7mXQgcGF5bG9hZCBBUEkuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCb3ggcm9sZT1cImltZ1wiIGFyaWEtbGFiZWw9e2BCaeG7g3UgxJHhu5MgbMO9IGRvIGtow7RuZyBjaOG7kXQgxJHGoW4sICR7bS5sb3N0U2FsZVJlYXNvbnMubGVuZ3RofSBuaMOzbWB9IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLWxvc3MtY2hhcnRcIiBzeD17W3sgaGVpZ2h0OiAyNjAgfSwgbGF5b3V0U3gucmVwb3J0LmNoYXJ0Vmlld3BvcnRJbnNldF19PlxuICAgICAgICAgICAgICAgICAgICAgICAge20ubG9zdFNhbGVSZWFzb25zLmxlbmd0aCA/IDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj48QmFyQ2hhcnQgZGF0YT17bS5sb3N0U2FsZVJlYXNvbnN9IGFjY2Vzc2liaWxpdHlMYXllcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2U9e2NvbG9ycy5ib3JkZXJEZWNvcmF0aXZlfSB2ZXJ0aWNhbD17ZmFsc2V9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJyZWFzb25cIiBzdHJva2U9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSBpbnRlcnZhbD17MH0gaGVpZ2h0PXs2NH0gdGljaz17PE1hcmtldGluZ1JlYXNvblRpY2sgLz59IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFlBeGlzIGFsbG93RGVjaW1hbHM9e2ZhbHNlfSBzdHJva2U9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIGNvbnRlbnRTdHlsZT17eyBiYWNrZ3JvdW5kOiBjb2xvcnMucmFpc2VkLCBjb2xvcjogY29sb3JzLnRleHRQcmltYXJ5LCBib3JkZXJDb2xvcjogY29sb3JzLmJvcmRlckRlY29yYXRpdmUgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJjb3VudFwiIG5hbWU9XCJT4buRIHRyxrDhu51uZyBo4bujcFwiIGZpbGw9e2NvbG9ycy5hY2NlbnR9IHJhZGl1cz17WzQsIDQsIDAsIDBdfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD48L1Jlc3BvbnNpdmVDb250YWluZXI+IDogPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtsYXlvdXRTeC5yZXBvcnQuZW1wdHlTdGF0ZUluc2V0fT5DaMawYSBjw7MgbMO9IGRvIG3huqV0IMSRxqFuIHRyb25nIGvhu7MgbsOgeS48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSByb3dzPXttLmxvc3RTYWxlUmVhc29uc30gcm93S2V5PXtyZWFzb24gPT4gcmVhc29uLnJlYXNvbn0gbGFiZWw9XCJMw70gZG8ga2jDtG5nIGNo4buRdCDEkcahblwiIGVtcHR5PVwiQ2jGsGEgY8OzIGzDvSBkbyBt4bqldCDEkcahbiB0cm9uZyBr4buzIMSRw6MgY2jhu41uLlwiIGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncmVhc29uJywgbGFiZWw6ICdMw70gZG8nLCByZW5kZXI6IHJlYXNvbiA9PiByZWFzb24ucmVhc29uIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2NvdW50JywgbGFiZWw6ICdT4buRIHRyxrDhu51uZyBo4bujcCcsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHJlYXNvbiA9PiByZWFzb24uY291bnQgfSxcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cbiAgICAgICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICAgICAgPC9TZWN0aW9uR3JpZD5cbiAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3gucGFnZS5zZWN0aW9uQmVmb3JlfT5LaMO0bmcgdOG7sSBnw6FuIG5ndeG7k24gY2hvIMSRxqFuIHRoaeG6v3UgZOG7ryBsaeG7h3UsIGtow7RuZyBnaGkgY2hpIMaw4bubYyB0w61uaCB0aMOgbmggY2hpIHRo4buxYyB04bq/IHbDoCBraMO0bmcgdOG7sSDEkcSDbmcgbuG7mWkgZHVuZyBob+G6t2MgdMSDbmcgbmfDom4gc8OhY2guPC9BbGVydD5cbiAgICAgICAgPC8+fTwvUXVlcnlTdGF0ZT59XG4gICAgPC8+O1xufVxuXG5mdW5jdGlvbiBtYXJrZXRpbmdSYW5nZUVycm9yKGZyb21EYXRlOiBzdHJpbmcsIHRvRGF0ZTogc3RyaW5nLCBidWNrZXQ6IHN0cmluZywgYWxsb3dEZWZhdWx0OiBib29sZWFuKTogeyBmaWVsZDogJ2Zyb21EYXRlJyB8ICd0b0RhdGUnIHwgJ2J1Y2tldCc7IG1lc3NhZ2U6IHN0cmluZyB9IHwgbnVsbCB7XG4gICAgaWYgKCFbJ2RheScsICd3ZWVrJywgJ21vbnRoJ10uaW5jbHVkZXMoYnVja2V0KSkgcmV0dXJuIHsgZmllbGQ6ICdidWNrZXQnLCBtZXNzYWdlOiAnQ2jhu41uIG5ow7NtIG5nw6B5LCB0deG6p24gaG/hurdjIHRow6FuZy4nIH07XG4gICAgaWYgKGFsbG93RGVmYXVsdCAmJiAhZnJvbURhdGUgJiYgIXRvRGF0ZSkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFpc1ZhbGlkRGF0ZU9ubHkoZnJvbURhdGUpKSByZXR1cm4geyBmaWVsZDogJ2Zyb21EYXRlJywgbWVzc2FnZTogJ05o4bqtcCBuZ8OgeSBi4bqvdCDEkeG6p3UgaOG7o3AgbOG7hy4nIH07XG4gICAgaWYgKCFpc1ZhbGlkRGF0ZU9ubHkodG9EYXRlKSkgcmV0dXJuIHsgZmllbGQ6ICd0b0RhdGUnLCBtZXNzYWdlOiAnTmjhuq1wIG5nw6B5IGvhur90IHRow7pjIGjhu6NwIGzhu4cuJyB9O1xuICAgIGlmIChmcm9tRGF0ZSA+IHRvRGF0ZSkgcmV0dXJuIHsgZmllbGQ6ICdmcm9tRGF0ZScsIG1lc3NhZ2U6ICdOZ8OgeSBi4bqvdCDEkeG6p3UgcGjhuqNpIHRyxrDhu5tjIGhv4bq3YyBi4bqxbmcgbmfDoHkga+G6v3QgdGjDumMuJyB9O1xuICAgIGNvbnN0IGRheXMgPSBNYXRoLmZsb29yKChEYXRlLnBhcnNlKGAke3RvRGF0ZX1UMDA6MDA6MDAuMDAwWmApIC0gRGF0ZS5wYXJzZShgJHtmcm9tRGF0ZX1UMDA6MDA6MDAuMDAwWmApKSAvICgyNCAqIDYwICogNjAgKiAxMDAwKSkgKyAxO1xuICAgIGlmIChkYXlzID4gMzY2KSByZXR1cm4geyBmaWVsZDogJ3RvRGF0ZScsIG1lc3NhZ2U6ICdLaG/huqNuZyBiw6FvIGPDoW8ga2jDtG5nIMSRxrDhu6NjIHbGsOG7o3QgcXXDoSAzNjYgbmfDoHkuJyB9O1xuICAgIHJldHVybiBudWxsO1xufVxuIl0sImZpbGUiOiIvaG9tZS9ydW5uZXIvd29yay9Cb3QtQUktQmFuLWhhbmctRkIvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvcmVwb3J0cy9pbmRleC50c3gifQ==