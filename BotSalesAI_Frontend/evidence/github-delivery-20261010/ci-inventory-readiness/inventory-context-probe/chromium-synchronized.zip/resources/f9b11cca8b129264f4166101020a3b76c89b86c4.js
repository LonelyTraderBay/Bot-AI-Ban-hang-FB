import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/inventory/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/react_jsx-dev-runtime.js?v=aafd8062"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { ActionGroup, FormFields } from "/src/shared/ui/composition.tsx";
export { WarehousesPage } from "/src/modules/inventory/warehouses.tsx";
import __vite__cjsImport5_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/react.js?v=aafd8062"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/react-router-dom.js?v=abb1ec1f";
import { Controller, useForm } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/react-hook-form.js?v=8171f1d6";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/@hookform_resolvers_zod.js?v=4645cbbe";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/zod.js?v=34692623";
import { Alert, Button, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-67708-6eae9a2c-d0f7-4e3a-abc8-7887a05f0cbf-inventory-lazy-probe/deps/@mui_material.js?v=3b54192f";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, codePointLength, dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, Amount, MutationButton, EditDialog, ErrorNotice, RouteLink, LookupLoadMore } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
const adjustmentSchema = z.object({
  quantityDelta: z.string().trim().min(1, "Nhập số lượng cần điều chỉnh").regex(/^-?\d+$/, "Số lượng phải là số nguyên"),
  reason: z.string().trim().refine((value) => codePointLength(value) >= 5, "Lý do cần ít nhất 5 ký tự").refine((value) => codePointLength(value) <= 1e3, "Lý do không được quá 1.000 ký tự"),
  unitCost: z.string().trim().max(60, "Giá vốn không được quá 60 ký tự").refine((value) => !value || /^(0|[1-9]\d*)(\.\d{1,18})?$/.test(value), "Giá vốn phải là số thập phân không âm, tối đa 18 chữ số lẻ")
}).superRefine(({ quantityDelta }, context) => {
  const amount = Number(quantityDelta);
  if (!Number.isSafeInteger(amount) || amount === 0 || Math.abs(amount) > 2147483647)
    context.addIssue({ code: "custom", path: ["quantityDelta"], message: "Số điều chỉnh phải khác 0 và nằm trong giới hạn hợp đồng." });
});
const emptyAdjustment = { quantityDelta: "", reason: "", unitCost: "" };
function InventoryFilters({ includeVariant = false }) {
  _s();
  const [params, setParams] = useSearchParams();
  const warehouses = usePagedApi("listWarehouses", { query: { limit: 20 } });
  const [warehouseId, setWarehouseId] = useState(params.get("warehouseId") || "");
  const [variantId, setVariantId] = useState(params.get("variantId") || "");
  useEffect(() => {
    setWarehouseId(params.get("warehouseId") || "");
    setVariantId(params.get("variantId") || "");
  }, [params]);
  const apply = () => {
    const next = new URLSearchParams(params);
    const filters = [["warehouseId", warehouseId], ["variantId", includeVariant ? variantId : ""]];
    for (const [key, value] of filters) {
      const normalized = value.trim();
      if (normalized) next.set(key, normalized);
      else
        next.delete(key);
    }
    next.delete("cursor");
    setParams(next);
  };
  const clear = () => {
    setWarehouseId("");
    setVariantId("");
    const next = new URLSearchParams(params);
    next.delete("warehouseId");
    next.delete("variantId");
    next.delete("cursor");
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, alignItems: { sm: "center" }, flexWrap: "wrap", children: [
    /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Kho", value: warehouseId, onChange: (event) => setWarehouseId(event.target.value), sx: { minWidth: { sm: 150 } }, children: [
        /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả kho" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 84,
          columnNumber: 164
        }, this),
        warehouseId && !warehouses.data?.data.some((w) => w.id === warehouseId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouseId, children: [
          "Đang giữ bộ lọc ",
          warehouseId
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 84,
          columnNumber: 280
        }, this),
        warehouses.data?.data.map((w) => /* @__PURE__ */ jsxDEV(MenuItem, { value: w.id, children: [
          w.code,
          " · ",
          w.name
        ] }, w.id, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 84,
          columnNumber: 385
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 84,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "kho", loadedCount: warehouses.loadedCount, hasMore: warehouses.hasMore, busy: warehouses.isLoadingMore, onLoadMore: warehouses.loadMore }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 84,
        columnNumber: 463
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: warehouses.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 84,
        columnNumber: 624
      }, this),
      includeVariant && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(TextField, { size: "small", label: "Mã biến thể", value: variantId, onChange: (event) => setVariantId(limitCodePoints(event.target.value, 120)), sx: { minWidth: { sm: 160 } } }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 86,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 85,
        columnNumber: 32
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 83,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
      /* @__PURE__ */ jsxDEV(Button, { type: "button", size: "small", variant: "outlined", onClick: apply, children: "Áp dụng bộ lọc" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 90,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "button", size: "small", onClick: clear, children: "Xóa bộ lọc" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 91,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
}
_s(InventoryFilters, "zaj8GiNyVWUdbuXzRIorXsFoTyg=", false, function() {
  return [useSearchParams, usePagedApi];
});
_c = InventoryFilters;
export function InventoryPage() {
  _s2();
  const { shop } = useScope();
  const canFinance = useCan("finance.read");
  const canCatalog = useCan("catalog.read");
  const list = useApi("listStockSnapshots", { query: useListQuery("listStockSnapshots") });
  const adjust = useCommand("createInventoryAdjustment", ["listStockSnapshots", "listStockMovements", "getDashboard"]);
  const [item, setItem] = useState(null);
  const [completedCommandId, setCompletedCommandId] = useState("");
  const { control, register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({
    defaultValues: emptyAdjustment,
    resolver: zodResolver(adjustmentSchema)
  });
  const edit = (snapshot) => {
    setItem(snapshot);
    setCompletedCommandId("");
    reset({ quantityDelta: "", reason: "", unitCost: canFinance ? snapshot.unitCost?.amount || "" : "" });
    adjust.clearError();
  };
  const close = () => {
    setItem(null);
    reset(emptyAdjustment);
  };
  const submitAdjustment = async (fields) => {
    if (!item) return;
    try {
      const result = await adjust.execute({ version: item.version, body: {
        variantId: item.variantId,
        warehouseId: item.warehouseId,
        quantityDelta: Number(fields.quantityDelta),
        reason: fields.reason.trim(),
        expectedVersion: item.version,
        unitCost: canFinance && fields.unitCost ? { amount: fields.unitCost, currency: shop.currency } : null
      } });
      setCompletedCommandId(result.data.id);
      close();
    } catch {
    }
  };
  const submitting = adjust.pending || isSubmitting;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Tồn kho", subtitle: "Tồn thực tế, đã giữ cho đơn và số còn có thể bán.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/inventory/movements`, children: "Lịch sử biến động" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 138,
      columnNumber: 107
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 138,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.page.sectionAfter, children: [
      "Snapshot kho do API cung cấp; không cộng hàng đang về hoặc hàng cách ly vào số có thể bán. Kho mặc định: ",
      shop.defaultWarehouseId,
      "."
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 139,
      columnNumber: 9
    }, this),
    completedCommandId && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", sx: layoutSx.notice.afterGap, children: [
      "Điều chỉnh đã được xác nhận. Mã lệnh: ",
      completedCommandId,
      ". Tồn kho và lịch sử đã được tải lại."
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 140,
      columnNumber: 32
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listStockSnapshots", placeholder: "Tìm SKU hoặc mã biến thể…", filters: /* @__PURE__ */ jsxDEV(InventoryFilters, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 141,
        columnNumber: 105
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 141,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Tồn kho theo vị trí", rows: list.data.data, rowKey: (row) => row.id, columns: [
          { key: "sku", label: "SKU / Kho", render: (row) => /* @__PURE__ */ jsxDEV(Stack, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: row.sku }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
              lineNumber: 143,
              columnNumber: 69
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
              "Mã kho: ",
              row.warehouseId,
              " · snapshot ",
              dateTime(row.asOf, shop.timezone)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
              lineNumber: 143,
              columnNumber: 154
            }, this),
            canCatalog && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/products?q=${encodeURIComponent(row.sku)}`, children: "Mở sản phẩm" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
              lineNumber: 143,
              columnNumber: 307
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 143,
            columnNumber: 62
          }, this) },
          { key: "onHand", label: "Thực tế", align: "right", render: (row) => row.onHand },
          { key: "reserved", label: "Đã giữ", align: "right", render: (row) => row.reserved },
          { key: "available", label: "Có thể bán", align: "right", render: (row) => /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.display, color: row.available <= row.lowStockThreshold ? "warning.main" : "text.primary", children: row.available }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 146,
            columnNumber: 85
          }, this) },
          { key: "threshold", label: "Ngưỡng cảnh báo", align: "right", render: (row) => row.lowStockThreshold },
          ...canFinance ? [{ key: "cost", label: "Giá vốn/đơn vị", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.unitCost }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 148,
            columnNumber: 101
          }, this) }] : [],
          { key: "state", label: "Tình trạng", render: (row) => /* @__PURE__ */ jsxDEV(Status, { domain: "stock", value: row.available <= 0 ? "out_of_stock" : row.available <= row.lowStockThreshold ? "low_stock" : "in_stock" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 149,
            columnNumber: 65
          }, this) },
          { key: "action", label: "", render: (row) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "inventory.adjust", onClick: () => edit(row), children: "Điều chỉnh" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 150,
            columnNumber: 56
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 142,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 152,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 141,
        columnNumber: 193
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 141,
        columnNumber: 129
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!item, title: `Điều chỉnh ${item?.sku || ""}`, description: "Nhập phần tăng hoặc giảm của vị trí này. Số tồn chỉ đổi sau khi lệnh được xác nhận.", onClose: close, busy: submitting, actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "inventory.adjust", variant: "contained", busy: submitting, type: "button", onClick: () => void handleSubmit(submitAdjustment)(), children: "Xác nhận điều chỉnh" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 154,
      columnNumber: 216
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: adjust.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 155,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "inventory-adjustment-form", noValidate: true, onSubmit: (event) => {
        event.preventDefault();
        void handleSubmit(submitAdjustment)(event);
      }, children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "API kiểm tra lại phiên bản và lượng đang giữ. Không nhập tổng tồn; không thể giảm thấp hơn lượng đã giữ." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 157,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Thay đổi số lượng", inputProps: { inputMode: "numeric" }, ...register("quantityDelta"), error: !!errors.quantityDelta, helperText: errors.quantityDelta?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 158,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do điều chỉnh", multiline: true, minRows: 2, ...register("reason"), error: !!errors.reason, helperText: errors.reason?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 159,
          columnNumber: 17
        }, this),
        canFinance && /* @__PURE__ */ jsxDEV(Controller, { name: "unitCost", control, render: ({ field }) => /* @__PURE__ */ jsxDEV(TextField, { ...field, label: `Giá vốn đơn vị (${shop.currency})`, inputProps: { inputMode: "decimal" }, error: !!errors.unitCost, helperText: errors.unitCost?.message || "Để trống nếu không cập nhật giá vốn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 160,
          columnNumber: 101
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 160,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 156,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 154,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
    lineNumber: 137,
    columnNumber: 10
  }, this);
}
_s2(InventoryPage, "9oIHvC6BAHfqPIpbRTTbVusBnBc=", false, function() {
  return [useScope, useCan, useCan, useApi, useListQuery, useCommand, useForm];
});
_c2 = InventoryPage;
export function MovementsPage() {
  _s3();
  const { shop } = useScope();
  const canReadOrders = useCan("orders.read");
  const list = useApi("listStockMovements", { query: useListQuery("listStockMovements") });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Lịch sử kho", subtitle: "Truy nguyên mỗi thay đổi đến chứng từ và người thực hiện.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/inventory`, children: "Về tồn kho" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 171,
      columnNumber: 119
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 171,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listStockMovements", placeholder: "Tìm SKU, mã biến thể hoặc mã chứng từ…", filters: /* @__PURE__ */ jsxDEV(InventoryFilters, { includeVariant: true }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 172,
        columnNumber: 118
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 172,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử biến động kho", rows: list.data.data, rowKey: (row) => row.id, columns: [
          { key: "date", label: "Thời gian", render: (row) => dateTime(row.createdAt, shop.timezone) },
          { key: "kind", label: "Loại", render: (row) => /* @__PURE__ */ jsxDEV(Status, { domain: "stockMovement", value: row.kind }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
            lineNumber: 175,
            columnNumber: 58
          }, this) },
          { key: "variant", label: "Biến thể", render: (row) => `Mã biến thể: ${row.variantId}` },
          { key: "warehouse", label: "Kho", render: (row) => `Mã kho: ${row.warehouseId}` },
          { key: "quantity", label: "Tồn ±", align: "right", render: (row) => row.quantityDelta },
          { key: "reserved", label: "Giữ ±", align: "right", render: (row) => row.reservedDelta },
          { key: "source", label: "Nguồn", render: (row) => movementSource(row, shop.id, canReadOrders) },
          { key: "actor", label: "Người thực hiện", render: (row) => `Mã nhân sự: ${row.actorId}` },
          { key: "reason", label: "Lý do", render: (row) => row.reason }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 173,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
          lineNumber: 184,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 172,
        columnNumber: 221
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
        lineNumber: 172,
        columnNumber: 157
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 172,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
    lineNumber: 170,
    columnNumber: 10
  }, this);
}
_s3(MovementsPage, "ILg/g3KTi4DOaAN0QqT04yjOgkw=", false, function() {
  return [useScope, useCan, useApi, useListQuery];
});
_c3 = MovementsPage;
function movementSource(row, shopId, canReadOrders) {
  if (!row.sourceRef) return "Điều chỉnh thủ công";
  if (row.sourceRef.type === "order" && canReadOrders)
    return /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shopId}/orders/${encodeURIComponent(row.sourceRef.id)}`, children: [
      "Đơn ",
      row.sourceRef.id
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx",
      lineNumber: 192,
      columnNumber: 10
    }, this);
  return `${row.sourceRef.type} · ${row.sourceRef.id}`;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "InventoryFilters");
$RefreshReg$(_c2, "InventoryPage");
$RefreshReg$(_c3, "MovementsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VpSyxTQUNsSSxVQURrSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoRWpLLFNBQVNBLGFBQWFDLGtCQUFrQjtBQUN4QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQ3BDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsWUFBWUMsZUFBZTtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBUztBQUNsQixTQUFTQyxPQUFPQyxRQUFRQyxVQUFVQyxPQUFPQyxXQUFXQyxrQkFBa0I7QUFFdEUsU0FBU0MsUUFBUUMsWUFBWUMsbUJBQW1CO0FBQ2hELFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxpQkFBaUJDLGdCQUFnQjtBQUMzRCxTQUFTQyxZQUFZQyxPQUFPQyxXQUFXQyxZQUFZQyxTQUFTQyxPQUFPQyxRQUFRQyxRQUFRQyxnQkFBZ0JDLFlBQVlDLGFBQWFDLFdBQVdDLHNCQUFzQjtBQUM3SixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMsbUJBQW1COUIsRUFBRStCLE9BQU87QUFBQSxFQUM5QkMsZUFBZWhDLEVBQUVpQyxPQUFPLEVBQUVDLEtBQUssRUFBRUMsSUFBSSxHQUFHLDhCQUE4QixFQUFFQyxNQUFNLFdBQVcsNEJBQTRCO0FBQUEsRUFDckhDLFFBQVFyQyxFQUFFaUMsT0FBTyxFQUFFQyxLQUFLLEVBQUVJLE9BQU8sQ0FBQUMsVUFBU3pCLGdCQUFnQnlCLEtBQUssS0FBSyxHQUFHLDJCQUEyQixFQUFFRCxPQUFPLENBQUFDLFVBQVN6QixnQkFBZ0J5QixLQUFLLEtBQUssS0FBTSxrQ0FBa0M7QUFBQSxFQUN0TEMsVUFBVXhDLEVBQUVpQyxPQUFPLEVBQUVDLEtBQUssRUFBRU8sSUFBSSxJQUFJLGlDQUFpQyxFQUFFSCxPQUFPLENBQUFDLFVBQVMsQ0FBQ0EsU0FBUyw4QkFBOEJHLEtBQUtILEtBQUssR0FBRyw0REFBNEQ7QUFDNU0sQ0FBQyxFQUFFSSxZQUFZLENBQUMsRUFBRVgsY0FBYyxHQUFHWSxZQUFZO0FBQzNDLFFBQU1DLFNBQVNDLE9BQU9kLGFBQWE7QUFDbkMsTUFBSSxDQUFDYyxPQUFPQyxjQUFjRixNQUFNLEtBQUtBLFdBQVcsS0FBS0csS0FBS0MsSUFBSUosTUFBTSxJQUFJO0FBQ3BFRCxZQUFRTSxTQUFTLEVBQUVDLE1BQU0sVUFBVUMsTUFBTSxDQUFDLGVBQWUsR0FBR0MsU0FBUyw0REFBNEQsQ0FBQztBQUMxSSxDQUFDO0FBRUQsTUFBTUMsa0JBQW9DLEVBQUV0QixlQUFlLElBQUlLLFFBQVEsSUFBSUcsVUFBVSxHQUFHO0FBRXhGLFNBQVNlLGlCQUFpQixFQUFFQyxpQkFBaUIsTUFBb0MsR0FBRztBQUFBQyxLQUFBO0FBQ2hGLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJL0QsZ0JBQWdCO0FBQzVDLFFBQU1nRSxhQUFhbkQsWUFBWSxrQkFBa0IsRUFBRW9ELE9BQU8sRUFBRUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6RSxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXRFLFNBQVNnRSxPQUFPTyxJQUFJLGFBQWEsS0FBSyxFQUFFO0FBQzlFLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJekUsU0FBU2dFLE9BQU9PLElBQUksV0FBVyxLQUFLLEVBQUU7QUFFeEV4RSxZQUFVLE1BQU07QUFDWnVFLG1CQUFlTixPQUFPTyxJQUFJLGFBQWEsS0FBSyxFQUFFO0FBQzlDRSxpQkFBYVQsT0FBT08sSUFBSSxXQUFXLEtBQUssRUFBRTtBQUFBLEVBQzlDLEdBQUcsQ0FBQ1AsTUFBTSxDQUFDO0FBRVgsUUFBTVUsUUFBUUEsTUFBTTtBQUNoQixVQUFNQyxPQUFPLElBQUlDLGdCQUFnQlosTUFBTTtBQUN2QyxVQUFNYSxVQUFtQyxDQUFDLENBQUMsZUFBZVIsV0FBVyxHQUFHLENBQUMsYUFBYVAsaUJBQWlCVSxZQUFZLEVBQUUsQ0FBQztBQUN0SCxlQUFXLENBQUNNLEtBQUtqQyxLQUFLLEtBQUtnQyxTQUFTO0FBQ2hDLFlBQU1FLGFBQWFsQyxNQUFNTCxLQUFLO0FBQzlCLFVBQUl1QyxXQUFZSixNQUFLSyxJQUFJRixLQUFLQyxVQUFVO0FBQUE7QUFDbkNKLGFBQUtNLE9BQU9ILEdBQUc7QUFBQSxJQUN4QjtBQUNBSCxTQUFLTSxPQUFPLFFBQVE7QUFDcEJoQixjQUFVVSxJQUFJO0FBQUEsRUFDbEI7QUFFQSxRQUFNTyxRQUFRQSxNQUFNO0FBQ2hCWixtQkFBZSxFQUFFO0FBQ2pCRyxpQkFBYSxFQUFFO0FBQ2YsVUFBTUUsT0FBTyxJQUFJQyxnQkFBZ0JaLE1BQU07QUFDdkNXLFNBQUtNLE9BQU8sYUFBYTtBQUN6Qk4sU0FBS00sT0FBTyxXQUFXO0FBQ3ZCTixTQUFLTSxPQUFPLFFBQVE7QUFDcEJoQixjQUFVVSxJQUFJO0FBQUEsRUFDbEI7QUFFQSxTQUFPLHVCQUFDLGNBQVcsV0FBVyxFQUFFUSxJQUFJLFVBQVVDLElBQUksTUFBTSxHQUFJLFlBQVksRUFBRUEsSUFBSSxTQUFTLEdBQUcsVUFBUyxRQUMvRjtBQUFBLDJCQUFDLGNBQVcsV0FBVyxFQUFFRCxJQUFJLFVBQVVDLElBQUksTUFBTSxHQUM3QztBQUFBLDZCQUFDLGFBQVUsUUFBTSxNQUFDLE1BQUssU0FBUSxPQUFNLE9BQU0sT0FBT2YsYUFBYSxVQUFVLENBQUFnQixVQUFTZixlQUFlZSxNQUFNQyxPQUFPekMsS0FBSyxHQUFHLElBQUksRUFBRTBDLFVBQVUsRUFBRUgsSUFBSSxJQUFJLEVBQUUsR0FBRztBQUFBLCtCQUFDLFlBQVMsT0FBTSxJQUFHLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFBWWYsZUFBZSxDQUFDSCxXQUFXc0IsTUFBTUEsS0FBS0MsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPdEIsV0FBVyxLQUFLLHVCQUFDLFlBQVMsT0FBT0EsYUFBYTtBQUFBO0FBQUEsVUFBaUJBO0FBQUFBLGFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUFhSCxXQUFXc0IsTUFBTUEsS0FBS0ksSUFBSSxDQUFBRixNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVDLElBQUtEO0FBQUFBLFlBQUVqQztBQUFBQSxVQUFLO0FBQUEsVUFBSWlDLEVBQUVHO0FBQUFBLGFBQWpDSCxFQUFFQyxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFELENBQVc7QUFBQSxXQUE5YTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdiO0FBQUEsTUFBWSx1QkFBQyxrQkFBZSxPQUFNLE9BQU0sYUFBYXpCLFdBQVc0QixhQUFhLFNBQVM1QixXQUFXNkIsU0FBUyxNQUFNN0IsV0FBVzhCLGVBQWUsWUFBWTlCLFdBQVcrQixZQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThKO0FBQUEsTUFBRSx1QkFBQyxlQUFZLE9BQU8vQixXQUFXZ0MsU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLE1BQ2hvQnBDLGtCQUFrQixtQ0FDZixpQ0FBQyxhQUFVLE1BQUssU0FBUSxPQUFNLGVBQWMsT0FBT1UsV0FBVyxVQUFVLENBQUFhLFVBQVNaLGFBQWF0RCxnQkFBZ0JrRSxNQUFNQyxPQUFPekMsT0FBTyxHQUFHLENBQUMsR0FBSSxJQUFJLEVBQUUwQyxVQUFVLEVBQUVILElBQUksSUFBSSxFQUFFLEtBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0ssS0FEeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVuQjtBQUFBLFNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLFdBQVUsT0FDbkI7QUFBQSw2QkFBQyxVQUFPLE1BQUssVUFBUyxNQUFLLFNBQVEsU0FBUSxZQUFXLFNBQVNWLE9BQU8sOEJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Y7QUFBQSxNQUNwRix1QkFBQyxVQUFPLE1BQUssVUFBUyxNQUFLLFNBQVEsU0FBU1EsT0FBTywwQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLFNBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BVkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdQO0FBQ0o7QUFBQ25CLEdBN0NRRixrQkFBZ0I7QUFBQSxVQUNPM0QsaUJBQ1RhLFdBQVc7QUFBQTtBQUFBLEtBRnpCOEM7QUErQ0YsZ0JBQVNzQyxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUVDLEtBQUssSUFBSXBGLFNBQVM7QUFDMUIsUUFBTXFGLGFBQWF0RixPQUFPLGNBQWM7QUFDeEMsUUFBTXVGLGFBQWF2RixPQUFPLGNBQWM7QUFDeEMsUUFBTXdGLE9BQU8zRixPQUFPLHNCQUFzQixFQUFFc0QsT0FBT2pELGFBQWEsb0JBQW9CLEVBQUUsQ0FBQztBQUN2RixRQUFNdUYsU0FBUzNGLFdBQVcsNkJBQTZCLENBQUMsc0JBQXNCLHNCQUFzQixjQUFjLENBQUM7QUFDbkgsUUFBTSxDQUFDNEYsTUFBTUMsT0FBTyxJQUFJM0csU0FBK0IsSUFBSTtBQUMzRCxRQUFNLENBQUM0RyxvQkFBb0JDLHFCQUFxQixJQUFJN0csU0FBUyxFQUFFO0FBQy9ELFFBQU0sRUFBRThHLFNBQVNDLFVBQVVDLGNBQWNDLE9BQU9DLFdBQVcsRUFBRUMsUUFBUUMsYUFBYSxFQUFFLElBQUloSCxRQUEwQjtBQUFBLElBQzlHaUgsZUFBZXpEO0FBQUFBLElBQ2YwRCxVQUFVakgsWUFBWStCLGdCQUFnQjtBQUFBLEVBQzFDLENBQUM7QUFFRCxRQUFNbUYsT0FBT0EsQ0FBQ0MsYUFBNEI7QUFDdENiLFlBQVFhLFFBQVE7QUFDaEJYLDBCQUFzQixFQUFFO0FBQ3hCSSxVQUFNLEVBQUUzRSxlQUFlLElBQUlLLFFBQVEsSUFBSUcsVUFBVXdELGFBQWFrQixTQUFTMUUsVUFBVUssVUFBVSxLQUFLLEdBQUcsQ0FBQztBQUNwR3NELFdBQU9nQixXQUFXO0FBQUEsRUFDdEI7QUFDQSxRQUFNQyxRQUFRQSxNQUFNO0FBQ2hCZixZQUFRLElBQUk7QUFDWk0sVUFBTXJELGVBQWU7QUFBQSxFQUN6QjtBQUNBLFFBQU0rRCxtQkFBbUIsT0FBT0MsV0FBNkI7QUFDekQsUUFBSSxDQUFDbEIsS0FBTTtBQUNYLFFBQUk7QUFDQSxZQUFNbUIsU0FBUyxNQUFNcEIsT0FBT3FCLFFBQVEsRUFBRUMsU0FBU3JCLEtBQUtxQixTQUFTQyxNQUFNO0FBQUEsUUFDL0R4RCxXQUFXa0MsS0FBS2xDO0FBQUFBLFFBQ2hCSCxhQUFhcUMsS0FBS3JDO0FBQUFBLFFBQ2xCL0IsZUFBZWMsT0FBT3dFLE9BQU90RixhQUFhO0FBQUEsUUFDMUNLLFFBQVFpRixPQUFPakYsT0FBT0gsS0FBSztBQUFBLFFBQzNCeUYsaUJBQWlCdkIsS0FBS3FCO0FBQUFBLFFBQ3RCakYsVUFBVXdELGNBQWNzQixPQUFPOUUsV0FBVyxFQUFFSyxRQUFReUUsT0FBTzlFLFVBQVVvRixVQUFVN0IsS0FBSzZCLFNBQVMsSUFBSTtBQUFBLE1BQ3JHLEVBQUUsQ0FBQztBQUNIckIsNEJBQXNCZ0IsT0FBT3JDLEtBQUtHLEVBQUU7QUFDcEMrQixZQUFNO0FBQUEsSUFDVixRQUNNO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFDQSxRQUFNUyxhQUFhMUIsT0FBTzJCLFdBQVdoQjtBQUVyQyxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLFdBQVUsVUFBUyxxREFBb0QsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTWYsS0FBS1YsRUFBRSx3QkFBd0IsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUUsS0FBdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvTDtBQUFBLElBQ3BMLHVCQUFDLFNBQU0sVUFBUyxRQUFPLElBQUl4RCxTQUFTa0csS0FBS0MsY0FBYztBQUFBO0FBQUEsTUFBMEdqQyxLQUFLa0M7QUFBQUEsTUFBbUI7QUFBQSxTQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBMO0FBQUEsSUFDekwzQixzQkFBc0IsdUJBQUMsU0FBTSxVQUFTLFdBQVUsTUFBSyxVQUFTLElBQUl6RSxTQUFTcUcsT0FBT0MsVUFBVTtBQUFBO0FBQUEsTUFBdUM3QjtBQUFBQSxNQUFtQjtBQUFBLFNBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUs7QUFBQSxJQUM1TCx1QkFBQyxTQUFNO0FBQUEsNkJBQUMsV0FBUSxXQUFVLHNCQUFxQixhQUFZLDZCQUE0QixTQUFTLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPSixNQUFNLGdCQUFlLFdBQVdBLGVBQUtoQixRQUFRLG1DQUNsTDtBQUFBLCtCQUFDLGFBQVUsT0FBTSx1QkFBc0IsTUFBTWdCLEtBQUtoQixLQUFLQSxNQUFNLFFBQVEsQ0FBQWtELFFBQU9BLElBQUkvQyxJQUFJLFNBQVM7QUFBQSxVQUN6RixFQUFFYixLQUFLLE9BQU82RCxPQUFPLGFBQWFDLFFBQVFBLENBQUFGLFFBQU8sdUJBQUMsU0FBTTtBQUFBLG1DQUFDLGNBQVcsWUFBWXpJLFNBQVM0SSxXQUFXQyxXQUFXQyxRQUFTTCxjQUFJTSxPQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQWEsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLGNBQVNOLElBQUlyRTtBQUFBQSxjQUFZO0FBQUEsY0FBYWhELFNBQVNxSCxJQUFJTyxNQUFNNUMsS0FBSzZDLFFBQVE7QUFBQSxpQkFBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkg7QUFBQSxZQUFjM0MsY0FBYyx1QkFBQyxhQUFVLElBQUksTUFBTUYsS0FBS1YsRUFBRSxlQUFld0QsbUJBQW1CVCxJQUFJTSxHQUFHLENBQUMsSUFBSSwyQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxlQUExVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1VixFQUFTO0FBQUEsVUFDalosRUFBRWxFLEtBQUssVUFBVTZELE9BQU8sV0FBV1MsT0FBTyxTQUFTUixRQUFRQSxDQUFBRixRQUFPQSxJQUFJVyxPQUFPO0FBQUEsVUFDN0UsRUFBRXZFLEtBQUssWUFBWTZELE9BQU8sVUFBVVMsT0FBTyxTQUFTUixRQUFRQSxDQUFBRixRQUFPQSxJQUFJWSxTQUFTO0FBQUEsVUFDaEYsRUFBRXhFLEtBQUssYUFBYTZELE9BQU8sY0FBY1MsT0FBTyxTQUFTUixRQUFRQSxDQUFBRixRQUFPLHVCQUFDLGNBQVcsWUFBWXpJLFNBQVM0SSxXQUFXQyxXQUFXUyxTQUFTLE9BQU9iLElBQUljLGFBQWFkLElBQUllLG9CQUFvQixpQkFBaUIsZ0JBQWlCZixjQUFJYyxhQUF0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSyxFQUFjO0FBQUEsVUFDdFAsRUFBRTFFLEtBQUssYUFBYTZELE9BQU8sbUJBQW1CUyxPQUFPLFNBQVNSLFFBQVFBLENBQUFGLFFBQU9BLElBQUllLGtCQUFrQjtBQUFBLFVBQ25HLEdBQUluRCxhQUFhLENBQUMsRUFBRXhCLEtBQUssUUFBUTZELE9BQU8sa0JBQWtCQyxRQUFRQSxDQUFDRixRQUF1Qix1QkFBQyxVQUFPLE9BQU9BLElBQUk1RixZQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QixFQUFHLENBQUMsSUFBSTtBQUFBLFVBQzlILEVBQUVnQyxLQUFLLFNBQVM2RCxPQUFPLGNBQWNDLFFBQVFBLENBQUFGLFFBQU8sdUJBQUMsVUFBTyxRQUFPLFNBQVEsT0FBT0EsSUFBSWMsYUFBYSxJQUFJLGlCQUFpQmQsSUFBSWMsYUFBYWQsSUFBSWUsb0JBQW9CLGNBQWMsY0FBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0ksRUFBRztBQUFBLFVBQzdMLEVBQUUzRSxLQUFLLFVBQVU2RCxPQUFPLElBQUlDLFFBQVFBLENBQUFGLFFBQU8sdUJBQUMsa0JBQWUsWUFBVyxvQkFBbUIsU0FBUyxNQUFNbkIsS0FBS21CLEdBQUcsR0FBRywwQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0YsRUFBa0I7QUFBQSxRQUFDLEtBUnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTRTtBQUFBLFFBQ0YsdUJBQUMsU0FBTSxNQUFNbEMsS0FBS2hCLEtBQUs2QyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FYc0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVl0TCxLQVpzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWWxIO0FBQUEsU0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWWlCO0FBQUEsSUFDakIsdUJBQUMsY0FBVyxNQUFNLENBQUMsQ0FBQzNCLE1BQU0sT0FBTyxjQUFjQSxNQUFNc0MsT0FBTyxFQUFFLElBQUksYUFBWSx1RkFBc0YsU0FBU3RCLE9BQU8sTUFBTVMsWUFBWSxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsb0JBQW1CLFNBQVEsYUFBWSxNQUFNQSxZQUFZLE1BQUssVUFBUyxTQUFTLE1BQU0sS0FBS25CLGFBQWFXLGdCQUFnQixFQUFFLEdBQUcsbUNBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkssR0FDdFg7QUFBQSw2QkFBQyxlQUFZLE9BQU9sQixPQUFPUCxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsY0FBVyxXQUFVLFFBQU8sSUFBRyw2QkFBNEIsWUFBVSxNQUFFLFVBQVUsQ0FBQWIsVUFBUztBQUFFQSxjQUFNcUUsZUFBZTtBQUFHLGFBQUsxQyxhQUFhVyxnQkFBZ0IsRUFBRXRDLEtBQUs7QUFBQSxNQUFHLEdBQzdKO0FBQUEsK0JBQUMsU0FBTSxVQUFTLFdBQVUsd0hBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0k7QUFBQSxRQUNsSSx1QkFBQyxhQUFVLE9BQU0scUJBQW9CLFlBQVksRUFBRXNFLFdBQVcsVUFBVSxHQUFHLEdBQUk1QyxTQUFTLGVBQWUsR0FBRyxPQUFPLENBQUMsQ0FBQ0ksT0FBTzdFLGVBQWUsWUFBWTZFLE9BQU83RSxlQUFlcUIsV0FBM0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTDtBQUFBLFFBQ25MLHVCQUFDLGFBQVUsT0FBTSxvQkFBbUIsV0FBUyxNQUFDLFNBQVMsR0FBRyxHQUFJb0QsU0FBUyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUNJLE9BQU94RSxRQUFRLFlBQVl3RSxPQUFPeEUsUUFBUWdCLFdBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkk7QUFBQSxRQUM1STJDLGNBQWMsdUJBQUMsY0FBVyxNQUFLLFlBQVcsU0FBa0IsUUFBUSxDQUFDLEVBQUVzRCxNQUFNLE1BQU0sdUJBQUMsYUFBVSxHQUFJQSxPQUFPLE9BQU8sbUJBQW1CdkQsS0FBSzZCLFFBQVEsS0FBSyxZQUFZLEVBQUV5QixXQUFXLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FBQ3hDLE9BQU9yRSxVQUFVLFlBQVlxRSxPQUFPckUsVUFBVWEsV0FBVywwQ0FBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTixLQUF0UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlSO0FBQUEsV0FKNVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQXpCRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJQO0FBQ0o7QUFBQ3lDLElBcEVlRCxlQUFhO0FBQUEsVUFDUmxGLFVBQ0VELFFBQ0FBLFFBQ05ILFFBQXNDSyxjQUNwQ0osWUFHeUVWLE9BQU87QUFBQTtBQUFBLE1BUm5GK0Y7QUFzRVQsZ0JBQVMwRCxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUV6RCxLQUFLLElBQUlwRixTQUFTO0FBQzFCLFFBQU04SSxnQkFBZ0IvSSxPQUFPLGFBQWE7QUFDMUMsUUFBTXdGLE9BQU8zRixPQUFPLHNCQUFzQixFQUFFc0QsT0FBT2pELGFBQWEsb0JBQW9CLEVBQUUsQ0FBQztBQUN2RixTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGVBQWMsVUFBUyw2REFBNEQsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTW1GLEtBQUtWLEVBQUUsY0FBYywwQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxLQUFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStLO0FBQUEsSUFDL0ssdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxzQkFBcUIsYUFBWSwwQ0FBeUMsU0FBUyx1QkFBQyxvQkFBaUIsZ0JBQWMsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlJO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU9hLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS2hCLFFBQVEsbUNBQzlNO0FBQUEsK0JBQUMsYUFBVSxPQUFNLHlCQUF3QixNQUFNZ0IsS0FBS2hCLEtBQUtBLE1BQU0sUUFBUSxDQUFBa0QsUUFBT0EsSUFBSS9DLElBQUksU0FBUztBQUFBLFVBQzNGLEVBQUViLEtBQUssUUFBUTZELE9BQU8sYUFBYUMsUUFBUUEsQ0FBQUYsUUFBT3JILFNBQVNxSCxJQUFJc0IsV0FBVzNELEtBQUs2QyxRQUFRLEVBQUU7QUFBQSxVQUN6RixFQUFFcEUsS0FBSyxRQUFRNkQsT0FBTyxRQUFRQyxRQUFRQSxDQUFBRixRQUFPLHVCQUFDLFVBQU8sUUFBTyxpQkFBZ0IsT0FBT0EsSUFBSXVCLFFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDLEVBQUc7QUFBQSxVQUMvRixFQUFFbkYsS0FBSyxXQUFXNkQsT0FBTyxZQUFZQyxRQUFRQSxDQUFBRixRQUFPLGdCQUFnQkEsSUFBSWxFLFNBQVMsR0FBRztBQUFBLFVBQ3BGLEVBQUVNLEtBQUssYUFBYTZELE9BQU8sT0FBT0MsUUFBUUEsQ0FBQUYsUUFBTyxXQUFXQSxJQUFJckUsV0FBVyxHQUFHO0FBQUEsVUFDOUUsRUFBRVMsS0FBSyxZQUFZNkQsT0FBTyxTQUFTUyxPQUFPLFNBQVNSLFFBQVFBLENBQUFGLFFBQU9BLElBQUlwRyxjQUFjO0FBQUEsVUFDcEYsRUFBRXdDLEtBQUssWUFBWTZELE9BQU8sU0FBU1MsT0FBTyxTQUFTUixRQUFRQSxDQUFBRixRQUFPQSxJQUFJd0IsY0FBYztBQUFBLFVBQ3BGLEVBQUVwRixLQUFLLFVBQVU2RCxPQUFPLFNBQVNDLFFBQVFBLENBQUFGLFFBQU95QixlQUFlekIsS0FBS3JDLEtBQUtWLElBQUlvRSxhQUFhLEVBQUU7QUFBQSxVQUM1RixFQUFFakYsS0FBSyxTQUFTNkQsT0FBTyxtQkFBbUJDLFFBQVFBLENBQUFGLFFBQU8sZUFBZUEsSUFBSTBCLE9BQU8sR0FBRztBQUFBLFVBQ3RGLEVBQUV0RixLQUFLLFVBQVU2RCxPQUFPLFNBQVNDLFFBQVFBLENBQUFGLFFBQU9BLElBQUkvRixPQUFPO0FBQUEsUUFBQyxLQVRoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUU7QUFBQSxRQUNGLHVCQUFDLFNBQU0sTUFBTTZELEtBQUtoQixLQUFLNkMsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBWmtMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhbE4sS0Fia0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWE5STtBQUFBLFNBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFpQjtBQUFBLE9BZmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCUDtBQUNKO0FBQUN5QixJQXJCZUQsZUFBYTtBQUFBLFVBQ1I1SSxVQUNLRCxRQUNUSCxRQUFzQ0ssWUFBWTtBQUFBO0FBQUEsTUFIbkQySTtBQXVCaEIsU0FBU00sZUFBZXpCLEtBQW9CMkIsUUFBZ0JOLGVBQXdCO0FBQ2hGLE1BQUksQ0FBQ3JCLElBQUk0QixVQUFXLFFBQU87QUFDM0IsTUFBSTVCLElBQUk0QixVQUFVQyxTQUFTLFdBQVdSO0FBQ2xDLFdBQU8sdUJBQUMsYUFBVSxJQUFJLE1BQU1NLE1BQU0sV0FBV2xCLG1CQUFtQlQsSUFBSTRCLFVBQVUzRSxFQUFFLENBQUMsSUFBSTtBQUFBO0FBQUEsTUFBSytDLElBQUk0QixVQUFVM0U7QUFBQUEsU0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRztBQUMvRyxTQUFPLEdBQUcrQyxJQUFJNEIsVUFBVUMsSUFBSSxNQUFNN0IsSUFBSTRCLFVBQVUzRSxFQUFFO0FBQ3REO0FBQUMsSUFBQTZFLElBQUFDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiV2FyZWhvdXNlc1BhZ2UiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInZpc3VhbFN4IiwidXNlU2VhcmNoUGFyYW1zIiwiQ29udHJvbGxlciIsInVzZUZvcm0iLCJ6b2RSZXNvbHZlciIsInoiLCJBbGVydCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVBhZ2VkQXBpIiwidXNlQ2FuIiwidXNlU2NvcGUiLCJ1c2VMaXN0UXVlcnkiLCJsaW1pdENvZGVQb2ludHMiLCJjb2RlUG9pbnRMZW5ndGgiLCJkYXRlVGltZSIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIkRhdGFUYWJsZSIsIlF1ZXJ5U3RhdGUiLCJUb29sYmFyIiwiUGFnZXIiLCJTdGF0dXMiLCJBbW91bnQiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIlJvdXRlTGluayIsIkxvb2t1cExvYWRNb3JlIiwibGF5b3V0U3giLCJhZGp1c3RtZW50U2NoZW1hIiwib2JqZWN0IiwicXVhbnRpdHlEZWx0YSIsInN0cmluZyIsInRyaW0iLCJtaW4iLCJyZWdleCIsInJlYXNvbiIsInJlZmluZSIsInZhbHVlIiwidW5pdENvc3QiLCJtYXgiLCJ0ZXN0Iiwic3VwZXJSZWZpbmUiLCJjb250ZXh0IiwiYW1vdW50IiwiTnVtYmVyIiwiaXNTYWZlSW50ZWdlciIsIk1hdGgiLCJhYnMiLCJhZGRJc3N1ZSIsImNvZGUiLCJwYXRoIiwibWVzc2FnZSIsImVtcHR5QWRqdXN0bWVudCIsIkludmVudG9yeUZpbHRlcnMiLCJpbmNsdWRlVmFyaWFudCIsIl9zIiwicGFyYW1zIiwic2V0UGFyYW1zIiwid2FyZWhvdXNlcyIsInF1ZXJ5IiwibGltaXQiLCJ3YXJlaG91c2VJZCIsInNldFdhcmVob3VzZUlkIiwiZ2V0IiwidmFyaWFudElkIiwic2V0VmFyaWFudElkIiwiYXBwbHkiLCJuZXh0IiwiVVJMU2VhcmNoUGFyYW1zIiwiZmlsdGVycyIsImtleSIsIm5vcm1hbGl6ZWQiLCJzZXQiLCJkZWxldGUiLCJjbGVhciIsInhzIiwic20iLCJldmVudCIsInRhcmdldCIsIm1pbldpZHRoIiwiZGF0YSIsInNvbWUiLCJ3IiwiaWQiLCJtYXAiLCJuYW1lIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiZXJyb3IiLCJJbnZlbnRvcnlQYWdlIiwiX3MyIiwic2hvcCIsImNhbkZpbmFuY2UiLCJjYW5DYXRhbG9nIiwibGlzdCIsImFkanVzdCIsIml0ZW0iLCJzZXRJdGVtIiwiY29tcGxldGVkQ29tbWFuZElkIiwic2V0Q29tcGxldGVkQ29tbWFuZElkIiwiY29udHJvbCIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwicmVzZXQiLCJmb3JtU3RhdGUiLCJlcnJvcnMiLCJpc1N1Ym1pdHRpbmciLCJkZWZhdWx0VmFsdWVzIiwicmVzb2x2ZXIiLCJlZGl0Iiwic25hcHNob3QiLCJjbGVhckVycm9yIiwiY2xvc2UiLCJzdWJtaXRBZGp1c3RtZW50IiwiZmllbGRzIiwicmVzdWx0IiwiZXhlY3V0ZSIsInZlcnNpb24iLCJib2R5IiwiZXhwZWN0ZWRWZXJzaW9uIiwiY3VycmVuY3kiLCJzdWJtaXR0aW5nIiwicGVuZGluZyIsInBhZ2UiLCJzZWN0aW9uQWZ0ZXIiLCJkZWZhdWx0V2FyZWhvdXNlSWQiLCJub3RpY2UiLCJhZnRlckdhcCIsInJvdyIsImxhYmVsIiwicmVuZGVyIiwidHlwb2dyYXBoeSIsImZvbnRXZWlnaHQiLCJzdHJvbmciLCJza3UiLCJhc09mIiwidGltZXpvbmUiLCJlbmNvZGVVUklDb21wb25lbnQiLCJhbGlnbiIsIm9uSGFuZCIsInJlc2VydmVkIiwiZGlzcGxheSIsImF2YWlsYWJsZSIsImxvd1N0b2NrVGhyZXNob2xkIiwicHJldmVudERlZmF1bHQiLCJpbnB1dE1vZGUiLCJmaWVsZCIsIk1vdmVtZW50c1BhZ2UiLCJfczMiLCJjYW5SZWFkT3JkZXJzIiwiY3JlYXRlZEF0Iiwia2luZCIsInJlc2VydmVkRGVsdGEiLCJtb3ZlbWVudFNvdXJjZSIsImFjdG9ySWQiLCJzaG9wSWQiLCJzb3VyY2VSZWYiLCJ0eXBlIiwiX2MiLCJfYzIiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFjdGlvbkdyb3VwLCBGb3JtRmllbGRzIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuZXhwb3J0IHsgV2FyZWhvdXNlc1BhZ2UgfSBmcm9tICcuL3dhcmVob3VzZXMnO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB2aXN1YWxTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL3Zpc3VhbCc7XHJcbmltcG9ydCB7IHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBDb250cm9sbGVyLCB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJztcclxuaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCc7XHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgeyBBbGVydCwgQnV0dG9uLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgdHlwZSB7IFN0b2NrTW92ZW1lbnQsIFN0b2NrU25hcHNob3QgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcclxuaW1wb3J0IHsgdXNlQXBpLCB1c2VDb21tYW5kLCB1c2VQYWdlZEFwaSB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZUNhbiwgdXNlU2NvcGUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xyXG5pbXBvcnQgeyBsaW1pdENvZGVQb2ludHMsIGNvZGVQb2ludExlbmd0aCwgZGF0ZVRpbWUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xyXG5pbXBvcnQgeyBQYWdlSGVhZGVyLCBQYW5lbCwgRGF0YVRhYmxlLCBRdWVyeVN0YXRlLCBUb29sYmFyLCBQYWdlciwgU3RhdHVzLCBBbW91bnQsIE11dGF0aW9uQnV0dG9uLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgUm91dGVMaW5rLCBMb29rdXBMb2FkTW9yZSB9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xyXG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL2xheW91dCc7XHJcblxyXG5jb25zdCBhZGp1c3RtZW50U2NoZW1hID0gei5vYmplY3Qoe1xyXG4gICAgcXVhbnRpdHlEZWx0YTogei5zdHJpbmcoKS50cmltKCkubWluKDEsICdOaOG6rXAgc+G7kSBsxrDhu6NuZyBj4bqnbiDEkWnhu4F1IGNo4buJbmgnKS5yZWdleCgvXi0/XFxkKyQvLCAnU+G7kSBsxrDhu6NuZyBwaOG6o2kgbMOgIHPhu5Egbmd1ecOqbicpLFxyXG4gICAgcmVhc29uOiB6LnN0cmluZygpLnRyaW0oKS5yZWZpbmUodmFsdWUgPT4gY29kZVBvaW50TGVuZ3RoKHZhbHVlKSA+PSA1LCAnTMO9IGRvIGPhuqduIMOtdCBuaOG6pXQgNSBrw70gdOG7sScpLnJlZmluZSh2YWx1ZSA9PiBjb2RlUG9pbnRMZW5ndGgodmFsdWUpIDw9IDEwMDAsICdMw70gZG8ga2jDtG5nIMSRxrDhu6NjIHF1w6EgMS4wMDAga8O9IHThu7EnKSxcclxuICAgIHVuaXRDb3N0OiB6LnN0cmluZygpLnRyaW0oKS5tYXgoNjAsICdHacOhIHbhu5FuIGtow7RuZyDEkcaw4bujYyBxdcOhIDYwIGvDvSB04buxJykucmVmaW5lKHZhbHVlID0+ICF2YWx1ZSB8fCAvXigwfFsxLTldXFxkKikoXFwuXFxkezEsMTh9KT8kLy50ZXN0KHZhbHVlKSwgJ0dpw6EgduG7kW4gcGjhuqNpIGzDoCBz4buRIHRo4bqtcCBwaMOibiBraMO0bmcgw6JtLCB04buRaSDEkWEgMTggY2jhu68gc+G7kSBs4bq7JyksXHJcbn0pLnN1cGVyUmVmaW5lKCh7IHF1YW50aXR5RGVsdGEgfSwgY29udGV4dCkgPT4ge1xyXG4gICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKHF1YW50aXR5RGVsdGEpO1xyXG4gICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihhbW91bnQpIHx8IGFtb3VudCA9PT0gMCB8fCBNYXRoLmFicyhhbW91bnQpID4gMl8xNDdfNDgzXzY0NylcclxuICAgICAgICBjb250ZXh0LmFkZElzc3VlKHsgY29kZTogJ2N1c3RvbScsIHBhdGg6IFsncXVhbnRpdHlEZWx0YSddLCBtZXNzYWdlOiAnU+G7kSDEkWnhu4F1IGNo4buJbmggcGjhuqNpIGtow6FjIDAgdsOgIG7hurFtIHRyb25nIGdp4bubaSBo4bqhbiBo4bujcCDEkeG7k25nLicgfSk7XHJcbn0pO1xyXG50eXBlIEFkanVzdG1lbnRGaWVsZHMgPSB6LmluZmVyPHR5cGVvZiBhZGp1c3RtZW50U2NoZW1hPjtcclxuY29uc3QgZW1wdHlBZGp1c3RtZW50OiBBZGp1c3RtZW50RmllbGRzID0geyBxdWFudGl0eURlbHRhOiAnJywgcmVhc29uOiAnJywgdW5pdENvc3Q6ICcnIH07XHJcblxyXG5mdW5jdGlvbiBJbnZlbnRvcnlGaWx0ZXJzKHsgaW5jbHVkZVZhcmlhbnQgPSBmYWxzZSB9OiB7IGluY2x1ZGVWYXJpYW50PzogYm9vbGVhbiB9KSB7XHJcbiAgICBjb25zdCBbcGFyYW1zLCBzZXRQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XHJcbiAgICBjb25zdCB3YXJlaG91c2VzID0gdXNlUGFnZWRBcGkoJ2xpc3RXYXJlaG91c2VzJywgeyBxdWVyeTogeyBsaW1pdDogMjAgfSB9KTtcclxuICAgIGNvbnN0IFt3YXJlaG91c2VJZCwgc2V0V2FyZWhvdXNlSWRdID0gdXNlU3RhdGUocGFyYW1zLmdldCgnd2FyZWhvdXNlSWQnKSB8fCAnJyk7XHJcbiAgICBjb25zdCBbdmFyaWFudElkLCBzZXRWYXJpYW50SWRdID0gdXNlU3RhdGUocGFyYW1zLmdldCgndmFyaWFudElkJykgfHwgJycpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgc2V0V2FyZWhvdXNlSWQocGFyYW1zLmdldCgnd2FyZWhvdXNlSWQnKSB8fCAnJyk7XHJcbiAgICAgICAgc2V0VmFyaWFudElkKHBhcmFtcy5nZXQoJ3ZhcmlhbnRJZCcpIHx8ICcnKTtcclxuICAgIH0sIFtwYXJhbXNdKTtcclxuXHJcbiAgICBjb25zdCBhcHBseSA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlcnM6IEFycmF5PFtzdHJpbmcsIHN0cmluZ10+ID0gW1snd2FyZWhvdXNlSWQnLCB3YXJlaG91c2VJZF0sIFsndmFyaWFudElkJywgaW5jbHVkZVZhcmlhbnQgPyB2YXJpYW50SWQgOiAnJ11dO1xyXG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGZpbHRlcnMpIHtcclxuICAgICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHZhbHVlLnRyaW0oKTtcclxuICAgICAgICAgICAgaWYgKG5vcm1hbGl6ZWQpIG5leHQuc2V0KGtleSwgbm9ybWFsaXplZCk7XHJcbiAgICAgICAgICAgIGVsc2UgbmV4dC5kZWxldGUoa2V5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2N1cnNvcicpO1xyXG4gICAgICAgIHNldFBhcmFtcyhuZXh0KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY2xlYXIgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0V2FyZWhvdXNlSWQoJycpO1xyXG4gICAgICAgIHNldFZhcmlhbnRJZCgnJyk7XHJcbiAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMocGFyYW1zKTtcclxuICAgICAgICBuZXh0LmRlbGV0ZSgnd2FyZWhvdXNlSWQnKTtcclxuICAgICAgICBuZXh0LmRlbGV0ZSgndmFyaWFudElkJyk7XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2N1cnNvcicpO1xyXG4gICAgICAgIHNldFBhcmFtcyhuZXh0KTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIDxGb3JtRmllbGRzIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSAgYWxpZ25JdGVtcz17eyBzbTogJ2NlbnRlcicgfX0gZmxleFdyYXA9XCJ3cmFwXCI+XHJcbiAgICAgICAgPEZvcm1GaWVsZHMgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19ID5cclxuICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3Qgc2l6ZT1cInNtYWxsXCIgbGFiZWw9XCJLaG9cIiB2YWx1ZT17d2FyZWhvdXNlSWR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRXYXJlaG91c2VJZChldmVudC50YXJnZXQudmFsdWUpfSBzeD17eyBtaW5XaWR0aDogeyBzbTogMTUwIH0gfX0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+VOG6pXQgY+G6oyBraG88L01lbnVJdGVtPnt3YXJlaG91c2VJZCAmJiAhd2FyZWhvdXNlcy5kYXRhPy5kYXRhLnNvbWUodyA9PiB3LmlkID09PSB3YXJlaG91c2VJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXt3YXJlaG91c2VJZH0+xJBhbmcgZ2nhu68gYuG7mSBs4buNYyB7d2FyZWhvdXNlSWR9PC9NZW51SXRlbT59e3dhcmVob3VzZXMuZGF0YT8uZGF0YS5tYXAodyA9PiA8TWVudUl0ZW0ga2V5PXt3LmlkfSB2YWx1ZT17dy5pZH0+e3cuY29kZX0gwrcge3cubmFtZX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwia2hvXCIgbG9hZGVkQ291bnQ9e3dhcmVob3VzZXMubG9hZGVkQ291bnR9IGhhc01vcmU9e3dhcmVob3VzZXMuaGFzTW9yZX0gYnVzeT17d2FyZWhvdXNlcy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXt3YXJlaG91c2VzLmxvYWRNb3JlfS8+PEVycm9yTm90aWNlIGVycm9yPXt3YXJlaG91c2VzLmVycm9yfS8+XHJcbiAgICAgICAgICAgIHtpbmNsdWRlVmFyaWFudCAmJiA8PlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzaXplPVwic21hbGxcIiBsYWJlbD1cIk3DoyBiaeG6v24gdGjhu4NcIiB2YWx1ZT17dmFyaWFudElkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0VmFyaWFudElkKGxpbWl0Q29kZVBvaW50cyhldmVudC50YXJnZXQudmFsdWUsIDEyMCkpfSAgc3g9e3sgbWluV2lkdGg6IHsgc206IDE2MCB9IH19Lz5cclxuICAgICAgICAgICAgPC8+fVxyXG4gICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgICAgICA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiBzaXplPVwic21hbGxcIiB2YXJpYW50PVwib3V0bGluZWRcIiBvbkNsaWNrPXthcHBseX0+w4FwIGThu6VuZyBi4buZIGzhu41jPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9e2NsZWFyfT5Yw7NhIGLhu5kgbOG7jWM8L0J1dHRvbj5cclxuICAgICAgICA8L0FjdGlvbkdyb3VwPlxyXG4gICAgPC9Gb3JtRmllbGRzPjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEludmVudG9yeVBhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBjYW5GaW5hbmNlID0gdXNlQ2FuKCdmaW5hbmNlLnJlYWQnKTtcclxuICAgIGNvbnN0IGNhbkNhdGFsb2cgPSB1c2VDYW4oJ2NhdGFsb2cucmVhZCcpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdFN0b2NrU25hcHNob3RzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0U3RvY2tTbmFwc2hvdHMnKSB9KTtcclxuICAgIGNvbnN0IGFkanVzdCA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUludmVudG9yeUFkanVzdG1lbnQnLCBbJ2xpc3RTdG9ja1NuYXBzaG90cycsICdsaXN0U3RvY2tNb3ZlbWVudHMnLCAnZ2V0RGFzaGJvYXJkJ10pO1xyXG4gICAgY29uc3QgW2l0ZW0sIHNldEl0ZW1dID0gdXNlU3RhdGU8U3RvY2tTbmFwc2hvdCB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2NvbXBsZXRlZENvbW1hbmRJZCwgc2V0Q29tcGxldGVkQ29tbWFuZElkXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IHsgY29udHJvbCwgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgcmVzZXQsIGZvcm1TdGF0ZTogeyBlcnJvcnMsIGlzU3VibWl0dGluZyB9IH0gPSB1c2VGb3JtPEFkanVzdG1lbnRGaWVsZHM+KHtcclxuICAgICAgICBkZWZhdWx0VmFsdWVzOiBlbXB0eUFkanVzdG1lbnQsXHJcbiAgICAgICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGFkanVzdG1lbnRTY2hlbWEpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZWRpdCA9IChzbmFwc2hvdDogU3RvY2tTbmFwc2hvdCkgPT4ge1xyXG4gICAgICAgIHNldEl0ZW0oc25hcHNob3QpO1xyXG4gICAgICAgIHNldENvbXBsZXRlZENvbW1hbmRJZCgnJyk7XHJcbiAgICAgICAgcmVzZXQoeyBxdWFudGl0eURlbHRhOiAnJywgcmVhc29uOiAnJywgdW5pdENvc3Q6IGNhbkZpbmFuY2UgPyBzbmFwc2hvdC51bml0Q29zdD8uYW1vdW50IHx8ICcnIDogJycgfSk7XHJcbiAgICAgICAgYWRqdXN0LmNsZWFyRXJyb3IoKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBjbG9zZSA9ICgpID0+IHtcclxuICAgICAgICBzZXRJdGVtKG51bGwpO1xyXG4gICAgICAgIHJlc2V0KGVtcHR5QWRqdXN0bWVudCk7XHJcbiAgICB9O1xyXG4gICAgY29uc3Qgc3VibWl0QWRqdXN0bWVudCA9IGFzeW5jIChmaWVsZHM6IEFkanVzdG1lbnRGaWVsZHMpID0+IHtcclxuICAgICAgICBpZiAoIWl0ZW0pIHJldHVybjtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhZGp1c3QuZXhlY3V0ZSh7IHZlcnNpb246IGl0ZW0udmVyc2lvbiwgYm9keToge1xyXG4gICAgICAgICAgICAgICAgdmFyaWFudElkOiBpdGVtLnZhcmlhbnRJZCxcclxuICAgICAgICAgICAgICAgIHdhcmVob3VzZUlkOiBpdGVtLndhcmVob3VzZUlkLFxyXG4gICAgICAgICAgICAgICAgcXVhbnRpdHlEZWx0YTogTnVtYmVyKGZpZWxkcy5xdWFudGl0eURlbHRhKSxcclxuICAgICAgICAgICAgICAgIHJlYXNvbjogZmllbGRzLnJlYXNvbi50cmltKCksXHJcbiAgICAgICAgICAgICAgICBleHBlY3RlZFZlcnNpb246IGl0ZW0udmVyc2lvbixcclxuICAgICAgICAgICAgICAgIHVuaXRDb3N0OiBjYW5GaW5hbmNlICYmIGZpZWxkcy51bml0Q29zdCA/IHsgYW1vdW50OiBmaWVsZHMudW5pdENvc3QsIGN1cnJlbmN5OiBzaG9wLmN1cnJlbmN5IH0gOiBudWxsLFxyXG4gICAgICAgICAgICB9IH0pO1xyXG4gICAgICAgICAgICBzZXRDb21wbGV0ZWRDb21tYW5kSWQocmVzdWx0LmRhdGEuaWQpO1xyXG4gICAgICAgICAgICBjbG9zZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXRjaCB7IC8qIEtlZXAgdGhlIGVudGVyZWQgdmFsdWVzOyB1bmtub3duIG91dGNvbWVzIHN0YXkgbG9ja2VkIGJ5IHVzZUNvbW1hbmQgcmVjb3ZlcnkuICovIH1cclxuICAgIH07XHJcbiAgICBjb25zdCBzdWJtaXR0aW5nID0gYWRqdXN0LnBlbmRpbmcgfHwgaXNTdWJtaXR0aW5nO1xyXG5cclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiVOG7k24ga2hvXCIgc3VidGl0bGU9XCJU4buTbiB0aOG7sWMgdOG6vywgxJHDoyBnaeG7ryBjaG8gxJHGoW4gdsOgIHPhu5EgY8OybiBjw7MgdGjhu4MgYsOhbi5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9pbnZlbnRvcnkvbW92ZW1lbnRzYH0+TOG7i2NoIHPhu60gYmnhur9uIMSR4buZbmc8L1JvdXRlTGluaz59Lz5cclxuICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4LnBhZ2Uuc2VjdGlvbkFmdGVyfT5TbmFwc2hvdCBraG8gZG8gQVBJIGN1bmcgY+G6pXA7IGtow7RuZyBj4buZbmcgaMOgbmcgxJFhbmcgduG7gSBob+G6t2MgaMOgbmcgY8OhY2ggbHkgdsOgbyBz4buRIGPDsyB0aOG7gyBiw6FuLiBLaG8gbeG6t2MgxJHhu4tuaDoge3Nob3AuZGVmYXVsdFdhcmVob3VzZUlkfS48L0FsZXJ0PlxyXG4gICAgICAgIHtjb21wbGV0ZWRDb21tYW5kSWQgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT7EkGnhu4F1IGNo4buJbmggxJHDoyDEkcaw4bujYyB4w6FjIG5o4bqtbi4gTcOjIGzhu4duaDoge2NvbXBsZXRlZENvbW1hbmRJZH0uIFThu5NuIGtobyB2w6AgbOG7i2NoIHPhu60gxJHDoyDEkcaw4bujYyB04bqjaSBs4bqhaS48L0FsZXJ0Pn1cclxuICAgICAgICA8UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdFN0b2NrU25hcHNob3RzXCIgcGxhY2Vob2xkZXI9XCJUw6xtIFNLVSBob+G6t2MgbcOjIGJp4bq/biB0aOG7g+KAplwiIGZpbHRlcnM9ezxJbnZlbnRvcnlGaWx0ZXJzLz59Lz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PlxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiVOG7k24ga2hvIHRoZW8gduG7iyB0csOtXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17cm93ID0+IHJvdy5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdza3UnLCBsYWJlbDogJ1NLVSAvIEtobycsIHJlbmRlcjogcm93ID0+IDxTdGFjaz48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT57cm93LnNrdX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+TcOjIGtobzoge3Jvdy53YXJlaG91c2VJZH0gwrcgc25hcHNob3Qge2RhdGVUaW1lKHJvdy5hc09mLCBzaG9wLnRpbWV6b25lKX08L1R5cG9ncmFwaHk+e2NhbkNhdGFsb2cgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vcHJvZHVjdHM/cT0ke2VuY29kZVVSSUNvbXBvbmVudChyb3cuc2t1KX1gfT5N4bufIHPhuqNuIHBo4bqpbTwvUm91dGVMaW5rPn08L1N0YWNrPiB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdvbkhhbmQnLCBsYWJlbDogJ1Ro4buxYyB04bq/JywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcm93ID0+IHJvdy5vbkhhbmQgfSxcclxuICAgICAgICAgICAgICAgIHsga2V5OiAncmVzZXJ2ZWQnLCBsYWJlbDogJ8SQw6MgZ2nhu68nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByb3cgPT4gcm93LnJlc2VydmVkIH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ2F2YWlsYWJsZScsIGxhYmVsOiAnQ8OzIHRo4buDIGLDoW4nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByb3cgPT4gPFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LmRpc3BsYXl9IGNvbG9yPXtyb3cuYXZhaWxhYmxlIDw9IHJvdy5sb3dTdG9ja1RocmVzaG9sZCA/ICd3YXJuaW5nLm1haW4nIDogJ3RleHQucHJpbWFyeSd9Pntyb3cuYXZhaWxhYmxlfTwvVHlwb2dyYXBoeT4gfSxcclxuICAgICAgICAgICAgICAgIHsga2V5OiAndGhyZXNob2xkJywgbGFiZWw6ICdOZ8aw4buhbmcgY+G6o25oIGLDoW8nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByb3cgPT4gcm93Lmxvd1N0b2NrVGhyZXNob2xkIH0sXHJcbiAgICAgICAgICAgICAgICAuLi4oY2FuRmluYW5jZSA/IFt7IGtleTogJ2Nvc3QnLCBsYWJlbDogJ0dpw6EgduG7kW4vxJHGoW4gduG7iycsIHJlbmRlcjogKHJvdzogU3RvY2tTbmFwc2hvdCkgPT4gPEFtb3VudCB2YWx1ZT17cm93LnVuaXRDb3N0fS8+IH1dIDogW10pLFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVMOsbmggdHLhuqFuZycsIHJlbmRlcjogcm93ID0+IDxTdGF0dXMgZG9tYWluPVwic3RvY2tcIiB2YWx1ZT17cm93LmF2YWlsYWJsZSA8PSAwID8gJ291dF9vZl9zdG9jaycgOiByb3cuYXZhaWxhYmxlIDw9IHJvdy5sb3dTdG9ja1RocmVzaG9sZCA/ICdsb3dfc3RvY2snIDogJ2luX3N0b2NrJ30vPiB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJycsIHJlbmRlcjogcm93ID0+IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW52ZW50b3J5LmFkanVzdFwiIG9uQ2xpY2s9eygpID0+IGVkaXQocm93KX0+xJBp4buBdSBjaOG7iW5oPC9NdXRhdGlvbkJ1dHRvbj4gfSxcclxuICAgICAgICAgICAgXX0vPlxyXG4gICAgICAgICAgICA8UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9Lz5cclxuICAgICAgICA8Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+XHJcbiAgICAgICAgPEVkaXREaWFsb2cgb3Blbj17ISFpdGVtfSB0aXRsZT17YMSQaeG7gXUgY2jhu4luaCAke2l0ZW0/LnNrdSB8fCAnJ31gfSBkZXNjcmlwdGlvbj1cIk5o4bqtcCBwaOG6p24gdMSDbmcgaG/hurdjIGdp4bqjbSBj4bunYSB24buLIHRyw60gbsOgeS4gU+G7kSB04buTbiBjaOG7iSDEkeG7lWkgc2F1IGtoaSBs4buHbmggxJHGsOG7o2MgeMOhYyBuaOG6rW4uXCIgb25DbG9zZT17Y2xvc2V9IGJ1c3k9e3N1Ym1pdHRpbmd9IGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW52ZW50b3J5LmFkanVzdFwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBidXN5PXtzdWJtaXR0aW5nfSB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVTdWJtaXQoc3VibWl0QWRqdXN0bWVudCkoKX0+WMOhYyBuaOG6rW4gxJFp4buBdSBjaOG7iW5oPC9NdXRhdGlvbkJ1dHRvbj59PlxyXG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2FkanVzdC5lcnJvcn0vPlxyXG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgaWQ9XCJpbnZlbnRvcnktYWRqdXN0bWVudC1mb3JtXCIgbm9WYWxpZGF0ZSAgb25TdWJtaXQ9e2V2ZW50ID0+IHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgdm9pZCBoYW5kbGVTdWJtaXQoc3VibWl0QWRqdXN0bWVudCkoZXZlbnQpOyB9fT5cclxuICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5BUEkga2nhu4NtIHRyYSBs4bqhaSBwaGnDqm4gYuG6o24gdsOgIGzGsOG7o25nIMSRYW5nIGdp4buvLiBLaMO0bmcgbmjhuq1wIHThu5VuZyB04buTbjsga2jDtG5nIHRo4buDIGdp4bqjbSB0aOG6pXAgaMahbiBsxrDhu6NuZyDEkcOjIGdp4buvLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVGhheSDEkeG7lWkgc+G7kSBsxrDhu6NuZ1wiIGlucHV0UHJvcHM9e3sgaW5wdXRNb2RlOiAnbnVtZXJpYycgfX0gey4uLnJlZ2lzdGVyKCdxdWFudGl0eURlbHRhJyl9IGVycm9yPXshIWVycm9ycy5xdWFudGl0eURlbHRhfSBoZWxwZXJUZXh0PXtlcnJvcnMucXVhbnRpdHlEZWx0YT8ubWVzc2FnZX0vPlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkzDvSBkbyDEkWnhu4F1IGNo4buJbmhcIiBtdWx0aWxpbmUgbWluUm93cz17Mn0gey4uLnJlZ2lzdGVyKCdyZWFzb24nKX0gZXJyb3I9eyEhZXJyb3JzLnJlYXNvbn0gaGVscGVyVGV4dD17ZXJyb3JzLnJlYXNvbj8ubWVzc2FnZX0vPlxyXG4gICAgICAgICAgICAgICAge2NhbkZpbmFuY2UgJiYgPENvbnRyb2xsZXIgbmFtZT1cInVuaXRDb3N0XCIgY29udHJvbD17Y29udHJvbH0gcmVuZGVyPXsoeyBmaWVsZCB9KSA9PiA8VGV4dEZpZWxkIHsuLi5maWVsZH0gbGFiZWw9e2BHacOhIHbhu5FuIMSRxqFuIHbhu4sgKCR7c2hvcC5jdXJyZW5jeX0pYH0gaW5wdXRQcm9wcz17eyBpbnB1dE1vZGU6ICdkZWNpbWFsJyB9fSBlcnJvcj17ISFlcnJvcnMudW5pdENvc3R9IGhlbHBlclRleHQ9e2Vycm9ycy51bml0Q29zdD8ubWVzc2FnZSB8fCAnxJDhu4MgdHLhu5FuZyBu4bq/dSBraMO0bmcgY+G6rXAgbmjhuq10IGdpw6EgduG7kW4uJ30vPn0vPn1cclxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgICAgIDwvRWRpdERpYWxvZz5cclxuICAgIDwvPjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vdmVtZW50c1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBjYW5SZWFkT3JkZXJzID0gdXNlQ2FuKCdvcmRlcnMucmVhZCcpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdFN0b2NrTW92ZW1lbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0U3RvY2tNb3ZlbWVudHMnKSB9KTtcclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiTOG7i2NoIHPhu60ga2hvXCIgc3VidGl0bGU9XCJUcnV5IG5ndXnDqm4gbeG7l2kgdGhheSDEkeG7lWkgxJHhur9uIGNo4bupbmcgdOG7qyB2w6AgbmfGsOG7nWkgdGjhu7FjIGhp4buHbi5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9pbnZlbnRvcnlgfT5W4buBIHThu5NuIGtobzwvUm91dGVMaW5rPn0vPlxyXG4gICAgICAgIDxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0U3RvY2tNb3ZlbWVudHNcIiBwbGFjZWhvbGRlcj1cIlTDrG0gU0tVLCBtw6MgYmnhur9uIHRo4buDIGhv4bq3YyBtw6MgY2jhu6luZyB04bur4oCmXCIgZmlsdGVycz17PEludmVudG9yeUZpbHRlcnMgaW5jbHVkZVZhcmlhbnQvPn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhICYmIDw+XHJcbiAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJM4buLY2ggc+G7rSBiaeG6v24gxJHhu5luZyBraG9cIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtyb3cgPT4gcm93LmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ2RhdGUnLCBsYWJlbDogJ1Ro4budaSBnaWFuJywgcmVuZGVyOiByb3cgPT4gZGF0ZVRpbWUocm93LmNyZWF0ZWRBdCwgc2hvcC50aW1lem9uZSkgfSxcclxuICAgICAgICAgICAgICAgIHsga2V5OiAna2luZCcsIGxhYmVsOiAnTG/huqFpJywgcmVuZGVyOiByb3cgPT4gPFN0YXR1cyBkb21haW49XCJzdG9ja01vdmVtZW50XCIgdmFsdWU9e3Jvdy5raW5kfS8+IH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ3ZhcmlhbnQnLCBsYWJlbDogJ0Jp4bq/biB0aOG7gycsIHJlbmRlcjogcm93ID0+IGBNw6MgYmnhur9uIHRo4buDOiAke3Jvdy52YXJpYW50SWR9YCB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICd3YXJlaG91c2UnLCBsYWJlbDogJ0tobycsIHJlbmRlcjogcm93ID0+IGBNw6Mga2hvOiAke3Jvdy53YXJlaG91c2VJZH1gIH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ3F1YW50aXR5JywgbGFiZWw6ICdU4buTbiDCsScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHJvdyA9PiByb3cucXVhbnRpdHlEZWx0YSB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdyZXNlcnZlZCcsIGxhYmVsOiAnR2nhu68gwrEnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByb3cgPT4gcm93LnJlc2VydmVkRGVsdGEgfSxcclxuICAgICAgICAgICAgICAgIHsga2V5OiAnc291cmNlJywgbGFiZWw6ICdOZ3Xhu5NuJywgcmVuZGVyOiByb3cgPT4gbW92ZW1lbnRTb3VyY2Uocm93LCBzaG9wLmlkLCBjYW5SZWFkT3JkZXJzKSB9LFxyXG4gICAgICAgICAgICAgICAgeyBrZXk6ICdhY3RvcicsIGxhYmVsOiAnTmfGsOG7nWkgdGjhu7FjIGhp4buHbicsIHJlbmRlcjogcm93ID0+IGBNw6MgbmjDom4gc+G7sTogJHtyb3cuYWN0b3JJZH1gIH0sXHJcbiAgICAgICAgICAgICAgICB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiByb3cgPT4gcm93LnJlYXNvbiB9LFxyXG4gICAgICAgICAgICBdfS8+XHJcbiAgICAgICAgICAgIDxQYWdlciBwYWdlPXtsaXN0LmRhdGEucGFnZX0vPlxyXG4gICAgICAgIDwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cclxuICAgIDwvPjtcclxufVxyXG5cclxuZnVuY3Rpb24gbW92ZW1lbnRTb3VyY2Uocm93OiBTdG9ja01vdmVtZW50LCBzaG9wSWQ6IHN0cmluZywgY2FuUmVhZE9yZGVyczogYm9vbGVhbikge1xyXG4gICAgaWYgKCFyb3cuc291cmNlUmVmKSByZXR1cm4gJ8SQaeG7gXUgY2jhu4luaCB0aOG7pyBjw7RuZyc7XHJcbiAgICBpZiAocm93LnNvdXJjZVJlZi50eXBlID09PSAnb3JkZXInICYmIGNhblJlYWRPcmRlcnMpXHJcbiAgICAgICAgcmV0dXJuIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3BJZH0vb3JkZXJzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KHJvdy5zb3VyY2VSZWYuaWQpfWB9PsSQxqFuIHtyb3cuc291cmNlUmVmLmlkfTwvUm91dGVMaW5rPjtcclxuICAgIHJldHVybiBgJHtyb3cuc291cmNlUmVmLnR5cGV9IMK3ICR7cm93LnNvdXJjZVJlZi5pZH1gO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2ludmVudG9yeS9pbmRleC50c3gifQ==