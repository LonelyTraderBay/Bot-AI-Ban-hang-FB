import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/inventory/warehouses.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/react_jsx-dev-runtime.js?v=2340f281"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/react.js?v=2340f281"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Button, TextField, Alert } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/@mui_material.js?v=ae0ca96a";
import { useForm, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/react-hook-form.js?v=bb5d820a";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/@hookform_resolvers_zod.js?v=7f6e23cc";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-66432-b8e38c92-c631-447a-87a2-7ae98af5af71-inventory-lazy-probe/deps/zod.js?v=7347da82";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { useVersionedDraft, draftEqual } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { codePointLength } from "/src/shared/model/format.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { FormFields, ActionGroup } from "/src/shared/ui/composition.tsx";
import { PageHeader, Panel, Toolbar, QueryState, DataTable, Pager, Status, MutationButton, EditDialog, ConfirmDialog, ErrorNotice } from "/src/shared/ui/components.tsx";
const schema = z.object({ code: z.string().refine((v) => codePointLength(v) <= 40, "Mã kho tối đa 40 ký tự.").trim().min(1, "Nhập mã kho."), name: z.string().refine((v) => codePointLength(v) <= 160, "Tên kho tối đa 160 ký tự.").trim().min(1, "Nhập tên kho."), addressLine: z.string().refine((v) => codePointLength(v) <= 500, "Địa điểm tối đa 500 ký tự.").trim().min(1, "Nhập địa điểm kho.") });
const empty = { code: "", name: "", addressLine: "" };
const snapshot = (warehouse) => ({ version: warehouse.version, values: { code: warehouse.code, name: warehouse.name, addressLine: warehouse.addressLine } });
export function WarehousesPage() {
  _s();
  const { shop } = useScope(), canEdit = useCan("warehouses.manage");
  const list = useApi("listWarehouses", { query: useListQuery("listWarehouses") });
  const [open, setOpen] = useState(false), [selected, setSelected] = useState(null), [archive, setArchive] = useState(null), [success, setSuccess] = useState("");
  const detail = useApi("getWarehouse", { path: { warehouseId: selected?.id || "" } }, open && Boolean(selected));
  const create = useCommand("createWarehouse", ["listWarehouses"]), update = useCommand("updateWarehouse", ["listWarehouses", "getWarehouse"]), remove = useCommand("archiveWarehouse", ["listWarehouses", "getWarehouse"]);
  const form = useForm({ defaultValues: empty, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const editor = useVersionedDraft({ identity: `${shop.id}:warehouse:${selected?.id || "new"}`, source: detail.data ? snapshot(detail.data.data) : selected ? snapshot(selected) : void 0, draft: form.getValues(), apply: (values) => form.reset(values), refresh: () => detail.refetch({ throwOnError: true }) });
  const dirty = open && (selected ? editor.dirty : !draftEqual(empty, form.getValues())), bindDraft = useDraftForm(dirty), formRef = useRef(null);
  const busy = create.pending || update.pending;
  const blocked = Boolean(selected ? update.unresolved : create.unresolved);
  const submit = form.handleSubmit(async (values) => {
    if (!canEdit || blocked) return;
    try {
      if (selected) {
        const prepared = editor.prepare();
        if (!prepared) return;
        const submitted = form.getValues(), patch = { ...prepared.patch };
        for (const key of Object.keys(patch)) patch[key] = values[key];
        const response = await update.execute({ path: { warehouseId: selected.id }, version: prepared.version, body: patch });
        if (!editor.committed(snapshot(response.data), submitted)) return;
      } else
        await create.execute({ body: values });
      if (formRef.current) markDraftClean(formRef.current);
      setSuccess(`Đã lưu kho ${values.name}.`);
      setOpen(false);
      form.reset(empty);
    } catch (error) {
      editor.failed(error);
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Quản trị kho", subtitle: "Một danh mục kho dùng chung cho đơn hàng, tồn kho và mua hàng; ngừng dùng giữ nguyên lịch sử.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "warehouses.manage", variant: "contained", onClick: () => {
      setSelected(null);
      form.reset(empty);
      setOpen(true);
    }, children: "Thêm kho" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 61,
      columnNumber: 156
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    success && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: success }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 62,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listWarehouses", placeholder: "Tìm mã hoặc tên kho…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 63,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh mục kho", rows: list.data.data, rowKey: (warehouse) => warehouse.id, columns: [
          { key: "code", label: "Mã kho", render: (w) => w.code },
          { key: "name", label: "Tên kho", render: (w) => w.name },
          { key: "address", label: "Địa điểm", render: (w) => w.addressLine },
          { key: "status", label: "Trạng thái", render: (w) => /* @__PURE__ */ jsxDEV(Status, { value: w.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
            lineNumber: 65,
            columnNumber: 248
          }, this) },
          { key: "edit", label: "Thao tác", render: (w) => w.status === "active" ? /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "warehouses.manage", onClick: () => {
              setSelected(w);
              form.reset(snapshot(w).values);
              setOpen(true);
            }, children: [
              "Sửa kho ",
              w.code
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
              lineNumber: 66,
              columnNumber: 97
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "warehouses.manage", onClick: () => setArchive(w), children: [
              "Ngừng dùng ",
              w.code
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
              lineNumber: 66,
              columnNumber: 256
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
            lineNumber: 66,
            columnNumber: 84
          }, this) : "Lịch sử được giữ" }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
          lineNumber: 64,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
          lineNumber: 67,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 63,
        columnNumber: 153
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 63,
        columnNumber: 89
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 63,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: selected ? `Sửa kho ${selected.name}` : "Thêm kho", busy, onClose: () => setOpen(false), actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "warehouse-editor", variant: "contained", disabled: busy || blocked || !canEdit || Boolean(selected) && !editor.dirty, children: "Lưu kho" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 68,
      columnNumber: 144
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || detail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 69,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { code: "Mã kho", name: "Tên kho", addressLine: "Địa điểm kho" }, busy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 69,
        columnNumber: 81
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "warehouse-editor", noValidate: true, ref: (node) => {
        formRef.current = node;
        bindDraft(node);
      }, onSubmit: submit, "data-draft-clean": !dirty ? "true" : void 0, children: ["code", "name", "addressLine"].map((key, i) => /* @__PURE__ */ jsxDEV(TextField, { label: ["Mã kho", "Tên kho", "Địa điểm kho"][i], ...form.register(key), disabled: busy || !canEdit, error: Boolean(form.formState.errors[key]), helperText: form.formState.errors[key]?.message }, key, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 71,
        columnNumber: 77
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
        lineNumber: 70,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 68,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: Boolean(archive), title: "Ngừng dùng kho", confirmLabel: "Ngừng dùng kho", description: `Kho ${archive?.name || ""} (${archive?.code || ""}) sẽ không xuất hiện trong lựa chọn mới. API chặn kho mặc định, kho còn tồn/giữ hàng hoặc nghiệp vụ đang mở; lịch sử được giữ.`, requireReason: true, busy: remove.pending, error: remove.error, onClose: () => setArchive(null), onConfirm: async (reason) => {
      if (!archive) return;
      await remove.execute({ path: { warehouseId: archive.id }, body: { expectedVersion: archive.version, reason } });
      setSuccess(`Đã ngừng dùng kho ${archive.name}.`);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
      lineNumber: 74,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx",
    lineNumber: 60,
    columnNumber: 10
  }, this);
}
_s(WarehousesPage, "QDxPe0m4vmQHG2pWKHQpgvdtP6Q=", false, function() {
  return [useScope, useCan, useApi, useListQuery, useApi, useCommand, useCommand, useCommand, useForm, useWatch, useVersionedDraft, useDraftForm];
});
_c = WarehousesPage;
var _c;
$RefreshReg$(_c, "WarehousesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inventory/warehouses.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUMySixTQUVOLFVBRk07Ozs7Ozs7Ozs7Ozs7Ozs7O0FBekMzSixTQUFTQSxRQUFRQyxnQkFBZ0I7QUFDakMsU0FBU0MsUUFBUUMsV0FBV0MsYUFBYTtBQUN6QyxTQUFTQyxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFNBQVM7QUFFbEIsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLFVBQVVDLGNBQWM7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQkMsa0JBQWtCO0FBQzlDLFNBQVNDLGNBQWNDLHNCQUFzQjtBQUM3QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFlBQVlDLG1CQUFtQjtBQUN4QyxTQUFTQyxZQUFZQyxPQUFPQyxTQUFTQyxZQUFZQyxXQUFXQyxPQUFPQyxRQUFRQyxnQkFBZ0JDLFlBQVlDLGVBQWVDLG1CQUFtQjtBQUV6SSxNQUFNQyxTQUFPekIsRUFBRTBCLE9BQU8sRUFBQ0MsTUFBSzNCLEVBQUU0QixPQUFPLEVBQUVDLE9BQU8sQ0FBQUMsTUFBR3BCLGdCQUFnQm9CLENBQUMsS0FBRyxJQUFHLHlCQUF5QixFQUFFQyxLQUFLLEVBQUVDLElBQUksR0FBRSxjQUFjLEdBQUVDLE1BQUtqQyxFQUFFNEIsT0FBTyxFQUFFQyxPQUFPLENBQUFDLE1BQUdwQixnQkFBZ0JvQixDQUFDLEtBQUcsS0FBSSwyQkFBMkIsRUFBRUMsS0FBSyxFQUFFQyxJQUFJLEdBQUUsZUFBZSxHQUFFRSxhQUFZbEMsRUFBRTRCLE9BQU8sRUFBRUMsT0FBTyxDQUFBQyxNQUFHcEIsZ0JBQWdCb0IsQ0FBQyxLQUFHLEtBQUksNEJBQTRCLEVBQUVDLEtBQUssRUFBRUMsSUFBSSxHQUFFLG9CQUFvQixFQUFDLENBQUM7QUFFdlcsTUFBTUcsUUFBYSxFQUFDUixNQUFLLElBQUdNLE1BQUssSUFBR0MsYUFBWSxHQUFFO0FBQ2xELE1BQU1FLFdBQVNBLENBQUNDLGVBQXVCLEVBQUNDLFNBQVFELFVBQVVDLFNBQVFDLFFBQU8sRUFBQ1osTUFBS1UsVUFBVVYsTUFBS00sTUFBS0ksVUFBVUosTUFBS0MsYUFBWUcsVUFBVUgsWUFBVyxFQUFDO0FBRTdJLGdCQUFTTSxpQkFBaUI7QUFBQUMsS0FBQTtBQUM3QixRQUFNLEVBQUNDLEtBQUksSUFBRXZDLFNBQVMsR0FBRXdDLFVBQVF2QyxPQUFPLG1CQUFtQjtBQUMxRCxRQUFNd0MsT0FBSzNDLE9BQU8sa0JBQWlCLEVBQUM0QyxPQUFNeEMsYUFBYSxnQkFBZ0IsRUFBQyxDQUFDO0FBQ3pFLFFBQU0sQ0FBQ3lDLE1BQUtDLE9BQU8sSUFBRXRELFNBQVMsS0FBSyxHQUFFLENBQUN1RCxVQUFTQyxXQUFXLElBQUV4RCxTQUF5QixJQUFJLEdBQUUsQ0FBQ3lELFNBQVFDLFVBQVUsSUFBRTFELFNBQXlCLElBQUksR0FBRSxDQUFDMkQsU0FBUUMsVUFBVSxJQUFFNUQsU0FBUyxFQUFFO0FBQy9LLFFBQU02RCxTQUFPckQsT0FBTyxnQkFBZSxFQUFDc0QsTUFBSyxFQUFDQyxhQUFZUixVQUFVUyxNQUFJLEdBQUUsRUFBQyxHQUFFWCxRQUFNWSxRQUFRVixRQUFRLENBQUM7QUFDaEcsUUFBTVcsU0FBT3pELFdBQVcsbUJBQWtCLENBQUMsZ0JBQWdCLENBQUMsR0FBRTBELFNBQU8xRCxXQUFXLG1CQUFrQixDQUFDLGtCQUFpQixjQUFjLENBQUMsR0FBRTJELFNBQU8zRCxXQUFXLG9CQUFtQixDQUFDLGtCQUFpQixjQUFjLENBQUM7QUFDM00sUUFBTTRELE9BQUtqRSxRQUFnQixFQUFDa0UsZUFBYzVCLE9BQU02QixVQUFTakUsWUFBWTBCLE1BQU0sRUFBQyxDQUFDO0FBQUUzQixXQUFTLEVBQUNtRSxTQUFRSCxLQUFLRyxRQUFPLENBQUM7QUFDOUcsUUFBTUMsU0FBTzVELGtCQUFrQixFQUFDNkQsVUFBUyxHQUFHekIsS0FBS2UsRUFBRSxjQUFjVCxVQUFVUyxNQUFJLEtBQUssSUFBR1csUUFBT2QsT0FBT2UsT0FBS2pDLFNBQVNrQixPQUFPZSxLQUFLQSxJQUFJLElBQUVyQixXQUFTWixTQUFTWSxRQUFRLElBQUVzQixRQUFVQyxPQUFNVCxLQUFLVSxVQUFVLEdBQUVDLE9BQU1BLENBQUFsQyxXQUFRdUIsS0FBS1ksTUFBTW5DLE1BQU0sR0FBRW9DLFNBQVFBLE1BQUlyQixPQUFPc0IsUUFBUSxFQUFDQyxjQUFhLEtBQUksQ0FBQyxFQUFDLENBQUM7QUFDblIsUUFBTUMsUUFBTWhDLFNBQU9FLFdBQVNrQixPQUFPWSxRQUFNLENBQUN2RSxXQUFXNEIsT0FBTTJCLEtBQUtVLFVBQVUsQ0FBQyxJQUFHTyxZQUFVdkUsYUFBYXNFLEtBQUssR0FBRUUsVUFBUXhGLE9BQTZCLElBQUk7QUFDckosUUFBTXlGLE9BQUt0QixPQUFPdUIsV0FBU3RCLE9BQU9zQjtBQUNsQyxRQUFNQyxVQUFRekIsUUFBUVYsV0FBU1ksT0FBT3dCLGFBQVd6QixPQUFPeUIsVUFBVTtBQUNsRSxRQUFNQyxTQUFPdkIsS0FBS3dCLGFBQWEsT0FBTS9DLFdBQVE7QUFDekMsUUFBRyxDQUFDSSxXQUFTd0MsUUFBUTtBQUNyQixRQUFJO0FBQ0EsVUFBR25DLFVBQVU7QUFBQyxjQUFNdUMsV0FBU3JCLE9BQU9zQixRQUFRO0FBQUUsWUFBRyxDQUFDRCxTQUFTO0FBQU8sY0FBTUUsWUFBVTNCLEtBQUtVLFVBQVUsR0FBRWtCLFFBQU0sRUFBQyxHQUFHSCxTQUFTRyxNQUFLO0FBQUUsbUJBQVVDLE9BQU9DLE9BQU9DLEtBQUtILEtBQUssRUFBdUJBLE9BQU1DLEdBQUcsSUFBRXBELE9BQU9vRCxHQUFHO0FBQUUsY0FBTUcsV0FBUyxNQUFNbEMsT0FBT21DLFFBQVEsRUFBQ3hDLE1BQUssRUFBQ0MsYUFBWVIsU0FBU1MsR0FBRSxHQUFFbkIsU0FBUWlELFNBQVNqRCxTQUFRMEQsTUFBS04sTUFBSyxDQUFDO0FBQUUsWUFBRyxDQUFDeEIsT0FBTytCLFVBQVU3RCxTQUFTMEQsU0FBU3pCLElBQUksR0FBRW9CLFNBQVMsRUFBRTtBQUFBLE1BQU87QUFDalgsY0FBTTlCLE9BQU9vQyxRQUFRLEVBQUNDLE1BQUt6RCxPQUFNLENBQUM7QUFDdkMsVUFBR3lDLFFBQVFrQixRQUFRekYsZ0JBQWV1RSxRQUFRa0IsT0FBTztBQUFFN0MsaUJBQVcsY0FBY2QsT0FBT04sSUFBSSxHQUFHO0FBQUVjLGNBQVEsS0FBSztBQUFFZSxXQUFLWSxNQUFNdkMsS0FBSztBQUFBLElBQy9ILFNBQU9nRSxPQUFNO0FBQUNqQyxhQUFPa0MsT0FBT0QsS0FBSztBQUFBLElBQUU7QUFBQSxFQUN2QyxDQUFDO0FBQ0QsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxnQkFBZSxVQUFTLGlHQUFnRyxTQUFTLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVEsYUFBWSxTQUFTLE1BQUk7QUFBQ2xELGtCQUFZLElBQUk7QUFBRWEsV0FBS1ksTUFBTXZDLEtBQUs7QUFBRVksY0FBUSxJQUFJO0FBQUEsSUFBRSxHQUFHLHdCQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThJLEtBQWpTO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbVQ7QUFBQSxJQUNsVEssV0FBUyx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVVBLHFCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDM0QsdUJBQUMsU0FBTTtBQUFBLDZCQUFDLFdBQVEsV0FBVSxrQkFBaUIsYUFBWSwwQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPUixNQUFNLGdCQUFlLFdBQVdBLGVBQUt5QixRQUFNLG1DQUN6STtBQUFBLCtCQUFDLGFBQVUsT0FBTSxnQkFBZSxNQUFNekIsS0FBS3lCLEtBQUtBLE1BQU0sUUFBUSxDQUFBaEMsY0FBV0EsVUFBVW9CLElBQUksU0FBUztBQUFBLFVBQzVGLEVBQUNrQyxLQUFJLFFBQU9VLE9BQU0sVUFBU0MsUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRTVFLEtBQUk7QUFBQSxVQUFFLEVBQUNnRSxLQUFJLFFBQU9VLE9BQU0sV0FBVUMsUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRXRFLEtBQUk7QUFBQSxVQUFFLEVBQUMwRCxLQUFJLFdBQVVVLE9BQU0sWUFBV0MsUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRXJFLFlBQVc7QUFBQSxVQUFFLEVBQUN5RCxLQUFJLFVBQVNVLE9BQU0sY0FBYUMsUUFBT0EsQ0FBQUMsTUFBRyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVDLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUU7QUFBQSxVQUN6TixFQUFDYixLQUFJLFFBQU9VLE9BQU0sWUFBV0MsUUFBT0EsQ0FBQUMsTUFBR0EsRUFBRUMsV0FBUyxXQUFTLHVCQUFDLGVBQVk7QUFBQSxtQ0FBQyxrQkFBZSxZQUFXLHFCQUFvQixTQUFTLE1BQUk7QUFBQ3ZELDBCQUFZc0QsQ0FBQztBQUFFekMsbUJBQUtZLE1BQU10QyxTQUFTbUUsQ0FBQyxFQUFFaEUsTUFBTTtBQUFFUSxzQkFBUSxJQUFJO0FBQUEsWUFBRSxHQUFHO0FBQUE7QUFBQSxjQUFTd0QsRUFBRTVFO0FBQUFBLGlCQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0STtBQUFBLFlBQWlCLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVMsTUFBSXdCLFdBQVdvRCxDQUFDLEdBQUc7QUFBQTtBQUFBLGNBQVlBLEVBQUU1RTtBQUFBQSxpQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxlQUF4UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5UixJQUFlLG1CQUFrQjtBQUFBLFFBQUMsS0FGMVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdFO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1pQixLQUFLeUIsS0FBS29DLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQUp5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSXZHLEtBSnlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJckM7QUFBQSxTQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXVEO0FBQUEsSUFDdkQsdUJBQUMsY0FBVyxNQUFZLE9BQU96RCxXQUFTLFdBQVdBLFNBQVNmLElBQUksS0FBRyxZQUFZLE1BQVksU0FBUyxNQUFJYyxRQUFRLEtBQUssR0FBRyxTQUFTLHVCQUFDLFVBQU8sTUFBSyxVQUFTLE1BQUssb0JBQW1CLFNBQVEsYUFBWSxVQUFVa0MsUUFBTUUsV0FBUyxDQUFDeEMsV0FBVWUsUUFBUVYsUUFBUSxLQUFHLENBQUNrQixPQUFPWSxPQUFRLHVCQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdKLEdBQzdRO0FBQUEsNkJBQUMsZUFBWSxPQUFPbkIsT0FBT3dDLFNBQU92QyxPQUFPdUMsU0FBTzdDLE9BQU82QyxTQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUN4RSxNQUFLLFVBQVNNLE1BQUssV0FBVUMsYUFBWSxlQUFjLEdBQUcsUUFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLE1BQzVLLHVCQUFDLGNBQVcsV0FBVSxRQUFPLElBQUcsb0JBQW1CLFlBQVUsTUFBQyxLQUFLLENBQUF3RSxTQUFNO0FBQUMxQixnQkFBUWtCLFVBQVFRO0FBQUszQixrQkFBVTJCLElBQUk7QUFBQSxNQUFFLEdBQUcsVUFBVXJCLFFBQVEsb0JBQWtCLENBQUNQLFFBQU0sU0FBT1IsUUFDOUosV0FBQyxRQUFPLFFBQU8sYUFBYSxFQUFZcUMsSUFBSSxDQUFDaEIsS0FBSWlCLE1BQUksdUJBQUMsYUFBb0IsT0FBTyxDQUFDLFVBQVMsV0FBVSxjQUFjLEVBQUVBLENBQUMsR0FBRyxHQUFJOUMsS0FBSytDLFNBQVNsQixHQUFHLEdBQUcsVUFBVVYsUUFBTSxDQUFDdEMsU0FBUyxPQUFPZSxRQUFRSSxLQUFLZ0QsVUFBVUMsT0FBT3BCLEdBQUcsQ0FBQyxHQUFHLFlBQVk3QixLQUFLZ0QsVUFBVUMsT0FBT3BCLEdBQUcsR0FBR3FCLFdBQTFMckIsS0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrTixDQUFFLEtBRC9RO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxpQkFBYyxNQUFNakMsUUFBUVIsT0FBTyxHQUFHLE9BQU0sa0JBQWlCLGNBQWEsa0JBQWlCLGFBQWEsT0FBT0EsU0FBU2pCLFFBQU0sRUFBRSxLQUFLaUIsU0FBU3ZCLFFBQU0sRUFBRSxrSUFBa0ksZUFBYSxNQUFDLE1BQU1rQyxPQUFPcUIsU0FBUyxPQUFPckIsT0FBT3NDLE9BQU8sU0FBUyxNQUFJaEQsV0FBVyxJQUFJLEdBQUcsV0FBVyxPQUFNOEQsV0FBUTtBQUFDLFVBQUcsQ0FBQy9ELFFBQVE7QUFBTyxZQUFNVyxPQUFPa0MsUUFBUSxFQUFDeEMsTUFBSyxFQUFDQyxhQUFZTixRQUFRTyxHQUFFLEdBQUV1QyxNQUFLLEVBQUNrQixpQkFBZ0JoRSxRQUFRWixTQUFRMkUsT0FBTSxFQUFDLENBQUM7QUFBRTVELGlCQUFXLHFCQUFxQkgsUUFBUWpCLElBQUksR0FBRztBQUFBLElBQUUsS0FBbmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcWpCO0FBQUEsT0FkbGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlUDtBQUNKO0FBQUNRLEdBbkNlRCxnQkFBYztBQUFBLFVBQ2JyQyxVQUFtQkMsUUFDckJILFFBQStCSSxjQUU3QkosUUFDQUMsWUFBd0RBLFlBQXVFQSxZQUNqSUwsU0FBb0VDLFVBQ2xFUSxtQkFDMkVFLFlBQVk7QUFBQTtBQUFBLEtBUnhGZ0M7QUFBYyxJQUFBMkU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlU3RhdGUiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJBbGVydCIsInVzZUZvcm0iLCJ1c2VXYXRjaCIsInpvZFJlc29sdmVyIiwieiIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsInVzZUNhbiIsInVzZUxpc3RRdWVyeSIsInVzZVZlcnNpb25lZERyYWZ0IiwiZHJhZnRFcXVhbCIsInVzZURyYWZ0Rm9ybSIsIm1hcmtEcmFmdENsZWFuIiwiY29kZVBvaW50TGVuZ3RoIiwiRHJhZnRDb25mbGljdCIsIkZvcm1GaWVsZHMiLCJBY3Rpb25Hcm91cCIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIlRvb2xiYXIiLCJRdWVyeVN0YXRlIiwiRGF0YVRhYmxlIiwiUGFnZXIiLCJTdGF0dXMiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJDb25maXJtRGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJzY2hlbWEiLCJvYmplY3QiLCJjb2RlIiwic3RyaW5nIiwicmVmaW5lIiwidiIsInRyaW0iLCJtaW4iLCJuYW1lIiwiYWRkcmVzc0xpbmUiLCJlbXB0eSIsInNuYXBzaG90Iiwid2FyZWhvdXNlIiwidmVyc2lvbiIsInZhbHVlcyIsIldhcmVob3VzZXNQYWdlIiwiX3MiLCJzaG9wIiwiY2FuRWRpdCIsImxpc3QiLCJxdWVyeSIsIm9wZW4iLCJzZXRPcGVuIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImFyY2hpdmUiLCJzZXRBcmNoaXZlIiwic3VjY2VzcyIsInNldFN1Y2Nlc3MiLCJkZXRhaWwiLCJwYXRoIiwid2FyZWhvdXNlSWQiLCJpZCIsIkJvb2xlYW4iLCJjcmVhdGUiLCJ1cGRhdGUiLCJyZW1vdmUiLCJmb3JtIiwiZGVmYXVsdFZhbHVlcyIsInJlc29sdmVyIiwiY29udHJvbCIsImVkaXRvciIsImlkZW50aXR5Iiwic291cmNlIiwiZGF0YSIsInVuZGVmaW5lZCIsImRyYWZ0IiwiZ2V0VmFsdWVzIiwiYXBwbHkiLCJyZXNldCIsInJlZnJlc2giLCJyZWZldGNoIiwidGhyb3dPbkVycm9yIiwiZGlydHkiLCJiaW5kRHJhZnQiLCJmb3JtUmVmIiwiYnVzeSIsInBlbmRpbmciLCJibG9ja2VkIiwidW5yZXNvbHZlZCIsInN1Ym1pdCIsImhhbmRsZVN1Ym1pdCIsInByZXBhcmVkIiwicHJlcGFyZSIsInN1Ym1pdHRlZCIsInBhdGNoIiwia2V5IiwiT2JqZWN0Iiwia2V5cyIsInJlc3BvbnNlIiwiZXhlY3V0ZSIsImJvZHkiLCJjb21taXR0ZWQiLCJjdXJyZW50IiwiZXJyb3IiLCJmYWlsZWQiLCJsYWJlbCIsInJlbmRlciIsInciLCJzdGF0dXMiLCJwYWdlIiwibm9kZSIsIm1hcCIsImkiLCJyZWdpc3RlciIsImZvcm1TdGF0ZSIsImVycm9ycyIsIm1lc3NhZ2UiLCJyZWFzb24iLCJleHBlY3RlZFZlcnNpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJ3YXJlaG91c2VzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uLCBUZXh0RmllbGQsIEFsZXJ0IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgeyB1c2VGb3JtLCB1c2VXYXRjaCB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJztcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xuaW1wb3J0IHR5cGUgeyBXYXJlaG91c2UgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XG5pbXBvcnQgeyB1c2VTY29wZSwgdXNlQ2FuIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xuaW1wb3J0IHsgdXNlTGlzdFF1ZXJ5IH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZmlsdGVycyc7XG5pbXBvcnQgeyB1c2VWZXJzaW9uZWREcmFmdCwgZHJhZnRFcXVhbCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XG5pbXBvcnQgeyB1c2VEcmFmdEZvcm0sIG1hcmtEcmFmdENsZWFuIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZGlydHktZHJhZnRzJztcbmltcG9ydCB7IGNvZGVQb2ludExlbmd0aCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XG5pbXBvcnQgeyBEcmFmdENvbmZsaWN0IH0gZnJvbSAnQC9zaGFyZWQvdWkvZHJhZnQtY29uZmxpY3QnO1xuaW1wb3J0IHsgRm9ybUZpZWxkcywgQWN0aW9uR3JvdXAgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XG5pbXBvcnQgeyBQYWdlSGVhZGVyLCBQYW5lbCwgVG9vbGJhciwgUXVlcnlTdGF0ZSwgRGF0YVRhYmxlLCBQYWdlciwgU3RhdHVzLCBNdXRhdGlvbkJ1dHRvbiwgRWRpdERpYWxvZywgQ29uZmlybURpYWxvZywgRXJyb3JOb3RpY2UgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcblxuY29uc3Qgc2NoZW1hPXoub2JqZWN0KHtjb2RlOnouc3RyaW5nKCkucmVmaW5lKHY9PmNvZGVQb2ludExlbmd0aCh2KTw9NDAsJ03DoyBraG8gdOG7kWkgxJFhIDQwIGvDvSB04buxLicpLnRyaW0oKS5taW4oMSwnTmjhuq1wIG3DoyBraG8uJyksbmFtZTp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTE2MCwnVMOqbiBraG8gdOG7kWkgxJFhIDE2MCBrw70gdOG7sS4nKS50cmltKCkubWluKDEsJ05o4bqtcCB0w6puIGtoby4nKSxhZGRyZXNzTGluZTp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTUwMCwnxJDhu4thIMSRaeG7g20gdOG7kWkgxJFhIDUwMCBrw70gdOG7sS4nKS50cmltKCkubWluKDEsJ05o4bqtcCDEkeG7i2EgxJFp4buDbSBraG8uJyl9KTtcbnR5cGUgRmllbGRzPXouaW5mZXI8dHlwZW9mIHNjaGVtYT47XG5jb25zdCBlbXB0eTpGaWVsZHM9e2NvZGU6JycsbmFtZTonJyxhZGRyZXNzTGluZTonJ307XG5jb25zdCBzbmFwc2hvdD0od2FyZWhvdXNlOldhcmVob3VzZSk9Pih7dmVyc2lvbjp3YXJlaG91c2UudmVyc2lvbix2YWx1ZXM6e2NvZGU6d2FyZWhvdXNlLmNvZGUsbmFtZTp3YXJlaG91c2UubmFtZSxhZGRyZXNzTGluZTp3YXJlaG91c2UuYWRkcmVzc0xpbmV9fSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBXYXJlaG91c2VzUGFnZSgpIHtcbiAgICBjb25zdCB7c2hvcH09dXNlU2NvcGUoKSxjYW5FZGl0PXVzZUNhbihcIndhcmVob3VzZXMubWFuYWdlXCIpO1xuICAgIGNvbnN0IGxpc3Q9dXNlQXBpKCdsaXN0V2FyZWhvdXNlcycse3F1ZXJ5OnVzZUxpc3RRdWVyeSgnbGlzdFdhcmVob3VzZXMnKX0pO1xuICAgIGNvbnN0IFtvcGVuLHNldE9wZW5dPXVzZVN0YXRlKGZhbHNlKSxbc2VsZWN0ZWQsc2V0U2VsZWN0ZWRdPXVzZVN0YXRlPFdhcmVob3VzZXxudWxsPihudWxsKSxbYXJjaGl2ZSxzZXRBcmNoaXZlXT11c2VTdGF0ZTxXYXJlaG91c2V8bnVsbD4obnVsbCksW3N1Y2Nlc3Msc2V0U3VjY2Vzc109dXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGRldGFpbD11c2VBcGkoJ2dldFdhcmVob3VzZScse3BhdGg6e3dhcmVob3VzZUlkOnNlbGVjdGVkPy5pZHx8Jyd9fSxvcGVuJiZCb29sZWFuKHNlbGVjdGVkKSk7XG4gICAgY29uc3QgY3JlYXRlPXVzZUNvbW1hbmQoJ2NyZWF0ZVdhcmVob3VzZScsWydsaXN0V2FyZWhvdXNlcyddKSx1cGRhdGU9dXNlQ29tbWFuZCgndXBkYXRlV2FyZWhvdXNlJyxbJ2xpc3RXYXJlaG91c2VzJywnZ2V0V2FyZWhvdXNlJ10pLHJlbW92ZT11c2VDb21tYW5kKCdhcmNoaXZlV2FyZWhvdXNlJyxbJ2xpc3RXYXJlaG91c2VzJywnZ2V0V2FyZWhvdXNlJ10pO1xuICAgIGNvbnN0IGZvcm09dXNlRm9ybTxGaWVsZHM+KHtkZWZhdWx0VmFsdWVzOmVtcHR5LHJlc29sdmVyOnpvZFJlc29sdmVyKHNjaGVtYSl9KTt1c2VXYXRjaCh7Y29udHJvbDpmb3JtLmNvbnRyb2x9KTtcbiAgICBjb25zdCBlZGl0b3I9dXNlVmVyc2lvbmVkRHJhZnQoe2lkZW50aXR5OmAke3Nob3AuaWR9OndhcmVob3VzZToke3NlbGVjdGVkPy5pZHx8J25ldyd9YCxzb3VyY2U6ZGV0YWlsLmRhdGE/c25hcHNob3QoZGV0YWlsLmRhdGEuZGF0YSk6c2VsZWN0ZWQ/c25hcHNob3Qoc2VsZWN0ZWQpOnVuZGVmaW5lZCxkcmFmdDpmb3JtLmdldFZhbHVlcygpLGFwcGx5OnZhbHVlcz0+Zm9ybS5yZXNldCh2YWx1ZXMpLHJlZnJlc2g6KCk9PmRldGFpbC5yZWZldGNoKHt0aHJvd09uRXJyb3I6dHJ1ZX0pfSk7XG4gICAgY29uc3QgZGlydHk9b3BlbiYmKHNlbGVjdGVkP2VkaXRvci5kaXJ0eTohZHJhZnRFcXVhbChlbXB0eSxmb3JtLmdldFZhbHVlcygpKSksYmluZERyYWZ0PXVzZURyYWZ0Rm9ybShkaXJ0eSksZm9ybVJlZj11c2VSZWY8SFRNTEZvcm1FbGVtZW50fG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGJ1c3k9Y3JlYXRlLnBlbmRpbmd8fHVwZGF0ZS5wZW5kaW5nO1xuICAgIGNvbnN0IGJsb2NrZWQ9Qm9vbGVhbihzZWxlY3RlZD91cGRhdGUudW5yZXNvbHZlZDpjcmVhdGUudW5yZXNvbHZlZCk7XG4gICAgY29uc3Qgc3VibWl0PWZvcm0uaGFuZGxlU3VibWl0KGFzeW5jIHZhbHVlcz0+e1xuICAgICAgICBpZighY2FuRWRpdHx8YmxvY2tlZClyZXR1cm47XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZihzZWxlY3RlZCkge2NvbnN0IHByZXBhcmVkPWVkaXRvci5wcmVwYXJlKCk7aWYoIXByZXBhcmVkKXJldHVybjtjb25zdCBzdWJtaXR0ZWQ9Zm9ybS5nZXRWYWx1ZXMoKSxwYXRjaD17Li4ucHJlcGFyZWQucGF0Y2h9O2Zvcihjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMocGF0Y2gpIGFzIChrZXlvZiBGaWVsZHMpW10pIHBhdGNoW2tleV09dmFsdWVzW2tleV07Y29uc3QgcmVzcG9uc2U9YXdhaXQgdXBkYXRlLmV4ZWN1dGUoe3BhdGg6e3dhcmVob3VzZUlkOnNlbGVjdGVkLmlkfSx2ZXJzaW9uOnByZXBhcmVkLnZlcnNpb24sYm9keTpwYXRjaH0pO2lmKCFlZGl0b3IuY29tbWl0dGVkKHNuYXBzaG90KHJlc3BvbnNlLmRhdGEpLHN1Ym1pdHRlZCkpcmV0dXJuO31cbiAgICAgICAgICAgIGVsc2UgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoe2JvZHk6dmFsdWVzfSk7XG4gICAgICAgICAgICBpZihmb3JtUmVmLmN1cnJlbnQpbWFya0RyYWZ0Q2xlYW4oZm9ybVJlZi5jdXJyZW50KTtzZXRTdWNjZXNzKGDEkMOjIGzGsHUga2hvICR7dmFsdWVzLm5hbWV9LmApO3NldE9wZW4oZmFsc2UpO2Zvcm0ucmVzZXQoZW1wdHkpO1xuICAgICAgICB9Y2F0Y2goZXJyb3Ipe2VkaXRvci5mYWlsZWQoZXJyb3IpO31cbiAgICB9KTtcbiAgICByZXR1cm4gPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJRdeG6o24gdHLhu4sga2hvXCIgc3VidGl0bGU9XCJN4buZdCBkYW5oIG3hu6VjIGtobyBkw7luZyBjaHVuZyBjaG8gxJHGoW4gaMOgbmcsIHThu5NuIGtobyB2w6AgbXVhIGjDoG5nOyBuZ+G7q25nIGTDuW5nIGdp4buvIG5ndXnDqm4gbOG7i2NoIHPhu60uXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJ3YXJlaG91c2VzLm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKT0+e3NldFNlbGVjdGVkKG51bGwpO2Zvcm0ucmVzZXQoZW1wdHkpO3NldE9wZW4odHJ1ZSk7fX0+VGjDqm0ga2hvPC9NdXRhdGlvbkJ1dHRvbj59Lz5cbiAgICAgICAge3N1Y2Nlc3MmJjxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+e3N1Y2Nlc3N9PC9BbGVydD59XG4gICAgICAgIDxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0V2FyZWhvdXNlc1wiIHBsYWNlaG9sZGVyPVwiVMOsbSBtw6MgaG/hurdjIHTDqm4ga2hv4oCmXCIvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhJiY8PlxuICAgICAgICAgICAgPERhdGFUYWJsZSBsYWJlbD1cIkRhbmggbeG7pWMga2hvXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17d2FyZWhvdXNlPT53YXJlaG91c2UuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICB7a2V5Oidjb2RlJyxsYWJlbDonTcOjIGtobycscmVuZGVyOnc9PncuY29kZX0se2tleTonbmFtZScsbGFiZWw6J1TDqm4ga2hvJyxyZW5kZXI6dz0+dy5uYW1lfSx7a2V5OidhZGRyZXNzJyxsYWJlbDonxJDhu4thIMSRaeG7g20nLHJlbmRlcjp3PT53LmFkZHJlc3NMaW5lfSx7a2V5OidzdGF0dXMnLGxhYmVsOidUcuG6oW5nIHRow6FpJyxyZW5kZXI6dz0+PFN0YXR1cyB2YWx1ZT17dy5zdGF0dXN9Lz59LFxuICAgICAgICAgICAgICAgIHtrZXk6J2VkaXQnLGxhYmVsOidUaGFvIHTDoWMnLHJlbmRlcjp3PT53LnN0YXR1cz09PSdhY3RpdmUnPzxBY3Rpb25Hcm91cD48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIndhcmVob3VzZXMubWFuYWdlXCIgb25DbGljaz17KCk9PntzZXRTZWxlY3RlZCh3KTtmb3JtLnJlc2V0KHNuYXBzaG90KHcpLnZhbHVlcyk7c2V0T3Blbih0cnVlKTt9fT5T4butYSBraG8ge3cuY29kZX08L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwid2FyZWhvdXNlcy5tYW5hZ2VcIiBvbkNsaWNrPXsoKT0+c2V0QXJjaGl2ZSh3KX0+Tmfhu6tuZyBkw7luZyB7dy5jb2RlfTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD46J0zhu4tjaCBz4butIMSRxrDhu6NjIGdp4buvJ30sXG4gICAgICAgICAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxuICAgICAgICA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT17c2VsZWN0ZWQ/YFPhu61hIGtobyAke3NlbGVjdGVkLm5hbWV9YDonVGjDqm0ga2hvJ30gYnVzeT17YnVzeX0gb25DbG9zZT17KCk9PnNldE9wZW4oZmFsc2UpfSBhY3Rpb25zPXs8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBmb3JtPVwid2FyZWhvdXNlLWVkaXRvclwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17YnVzeXx8YmxvY2tlZHx8IWNhbkVkaXR8fChCb29sZWFuKHNlbGVjdGVkKSYmIWVkaXRvci5kaXJ0eSl9PkzGsHUga2hvPC9CdXR0b24+fT5cbiAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yfHx1cGRhdGUuZXJyb3J8fGRldGFpbC5lcnJvcn0vPjxEcmFmdENvbmZsaWN0IGVkaXRvcj17ZWRpdG9yfSBsYWJlbHM9e3tjb2RlOidNw6Mga2hvJyxuYW1lOidUw6puIGtobycsYWRkcmVzc0xpbmU6J8SQ4buLYSDEkWnhu4NtIGtobyd9fSBidXN5PXtidXN5fS8+XG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgaWQ9XCJ3YXJlaG91c2UtZWRpdG9yXCIgbm9WYWxpZGF0ZSByZWY9e25vZGU9Pntmb3JtUmVmLmN1cnJlbnQ9bm9kZTtiaW5kRHJhZnQobm9kZSk7fX0gb25TdWJtaXQ9e3N1Ym1pdH0gZGF0YS1kcmFmdC1jbGVhbj17IWRpcnR5Pyd0cnVlJzp1bmRlZmluZWR9PlxuICAgICAgICAgICAgICAgIHsoWydjb2RlJywnbmFtZScsJ2FkZHJlc3NMaW5lJ10gYXMgY29uc3QpLm1hcCgoa2V5LGkpPT48VGV4dEZpZWxkIGtleT17a2V5fSBsYWJlbD17WydNw6Mga2hvJywnVMOqbiBraG8nLCfEkOG7i2EgxJFp4buDbSBraG8nXVtpXX0gey4uLmZvcm0ucmVnaXN0ZXIoa2V5KX0gZGlzYWJsZWQ9e2J1c3l8fCFjYW5FZGl0fSBlcnJvcj17Qm9vbGVhbihmb3JtLmZvcm1TdGF0ZS5lcnJvcnNba2V5XSl9IGhlbHBlclRleHQ9e2Zvcm0uZm9ybVN0YXRlLmVycm9yc1trZXldPy5tZXNzYWdlfS8+KX1cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9FZGl0RGlhbG9nPlxuICAgICAgICA8Q29uZmlybURpYWxvZyBvcGVuPXtCb29sZWFuKGFyY2hpdmUpfSB0aXRsZT1cIk5n4burbmcgZMO5bmcga2hvXCIgY29uZmlybUxhYmVsPVwiTmfhu6tuZyBkw7luZyBraG9cIiBkZXNjcmlwdGlvbj17YEtobyAke2FyY2hpdmU/Lm5hbWV8fCcnfSAoJHthcmNoaXZlPy5jb2RlfHwnJ30pIHPhur0ga2jDtG5nIHh14bqldCBoaeG7h24gdHJvbmcgbOG7sWEgY2jhu41uIG3hu5tpLiBBUEkgY2jhurduIGtobyBt4bq3YyDEkeG7i25oLCBraG8gY8OybiB04buTbi9naeG7ryBow6BuZyBob+G6t2MgbmdoaeG7h3AgduG7pSDEkWFuZyBt4bufOyBs4buLY2ggc+G7rSDEkcaw4bujYyBnaeG7ry5gfSByZXF1aXJlUmVhc29uIGJ1c3k9e3JlbW92ZS5wZW5kaW5nfSBlcnJvcj17cmVtb3ZlLmVycm9yfSBvbkNsb3NlPXsoKT0+c2V0QXJjaGl2ZShudWxsKX0gb25Db25maXJtPXthc3luYyByZWFzb249PntpZighYXJjaGl2ZSlyZXR1cm47YXdhaXQgcmVtb3ZlLmV4ZWN1dGUoe3BhdGg6e3dhcmVob3VzZUlkOmFyY2hpdmUuaWR9LGJvZHk6e2V4cGVjdGVkVmVyc2lvbjphcmNoaXZlLnZlcnNpb24scmVhc29ufX0pO3NldFN1Y2Nlc3MoYMSQw6Mgbmfhu6tuZyBkw7luZyBraG8gJHthcmNoaXZlLm5hbWV9LmApO319Lz5cbiAgICA8Lz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9pbnZlbnRvcnkvd2FyZWhvdXNlcy50c3gifQ==