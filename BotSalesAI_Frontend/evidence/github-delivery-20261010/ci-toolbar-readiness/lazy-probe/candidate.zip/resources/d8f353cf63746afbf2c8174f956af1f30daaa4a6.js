"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-TJQ5SMJY.js?v=854b7ff2";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-YVU6SLE6.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-TQYMLHGU.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-FJYLEWCQ.js?v=854b7ff2";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-QF5IVN5P.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-QU3FZV7L.js?v=854b7ff2";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-PX6F3LHL.js?v=854b7ff2";

// ../../node_modules/@mui/icons-material/esm/ArrowBackRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var ArrowBackRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M19 11H7.83l4.88-4.88c.39-.39.39-1.03 0-1.42a.996.996 0 0 0-1.41 0l-6.59 6.59c-.39.39-.39 1.02 0 1.41l6.59 6.59c.39.39 1.02.39 1.41 0s.39-1.02 0-1.41L7.83 13H19c.55 0 1-.45 1-1s-.45-1-1-1"
}), "ArrowBackRounded");
export {
  ArrowBackRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_ArrowBackRounded.js.map
