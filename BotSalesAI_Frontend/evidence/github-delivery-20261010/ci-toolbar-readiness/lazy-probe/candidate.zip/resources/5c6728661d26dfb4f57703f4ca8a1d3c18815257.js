import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/inbox/conversation-components.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/react_jsx-dev-runtime.js?v=d0d91d7e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/react.js?v=d0d91d7e"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Alert, Box, Button, Chip, Divider, FormControlLabel, Checkbox, IconButton, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_material.js?v=b8e0ff7c";
import AttachFileRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_icons-material_AttachFileRounded.js?v=82735f78";
import CloseRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_icons-material_CloseRounded.js?v=825a22f7";
import SendRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_icons-material_SendRounded.js?v=0f8818e9";
import { colors } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { request } from "/src/shared/api/client.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useCan, useScope } from "/src/shared/model/scope.tsx";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { DetailLine, ErrorNotice, MutationButton, Panel, RouteLink, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
function revokeObjectUrl(url) {
  if (url?.startsWith("blob:")) URL.revokeObjectURL(url);
}
export function ConversationComposer({
  conversation
}) {
  _s();
  const { session, online } = useScope();
  const canReply = useCan("conversations.reply");
  const send = useCommand("sendMessage", ["listMessages", "getConversation", "listConversations"]);
  const note = useCommand("addInternalNote", ["listMessages"]);
  const upload = useCommand("uploadFile", []);
  const metadata = useApi("getInboxMetadata");
  const [text, setText] = useState("");
  const [internal, setInternal] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [mediaError, setMediaError] = useState("");
  const revision = useRef(0);
  const currentConversation = useRef(conversation.id);
  const attachmentInput = useRef(null);
  const attachmentRef = useRef([]);
  const alive = useRef(false);
  currentConversation.current = conversation.id;
  attachmentRef.current = attachments;
  const channel = metadata.data?.data.channels.find((item) => item.id === conversation.channelId);
  const mediaPolicy = channel?.mediaPolicy;
  const mediaSupported = Boolean(mediaPolicy?.allowedMimeTypes.length && mediaPolicy.maxAttachmentCount > 0 && mediaPolicy.maxFileSizeBytes > 0);
  const canSend = canReply && online && (internal || conversation.mode === "human" && conversation.assignedUserId === session.user.id && conversation.sendEligibility.state === "allowed");
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      for (const attachment of attachmentRef.current) revokeObjectUrl(attachment.previewUrl);
    };
  }, []);
  const updateAttachments = (update) => {
    const next = update(attachmentRef.current);
    attachmentRef.current = next;
    setAttachments(next);
  };
  const updateAttachment = (localId, patch) => {
    updateAttachments((current) => current.map((item) => item.localId === localId ? { ...item, ...patch } : item));
  };
  const uploadAttachment = async (attachment) => {
    if (!mediaPolicy || !alive.current || currentConversation.current !== conversation.id) return;
    updateAttachment(attachment.localId, { status: "uploading", error: void 0 });
    const form = new FormData();
    form.append("file", attachment.file);
    form.append("purpose", "conversation_media");
    form.append("resourceId", conversation.id);
    try {
      const result = await upload.execute({ form, idempotencyKey: attachment.uploadIntentId });
      if (!alive.current || currentConversation.current !== conversation.id) return;
      if (result.data.status !== "ready") {
        updateAttachment(attachment.localId, { fileId: result.data.id, status: "not_ready", error: "Tệp chưa qua kiểm tra mô phỏng nên chưa thể gửi." });
        return;
      }
      updateAttachment(attachment.localId, { fileId: result.data.id, status: "ready" });
    } catch (error) {
      if (!alive.current || currentConversation.current !== conversation.id) return;
      updateAttachment(attachment.localId, { status: "error", error: error instanceof Error ? error.message : "Tải tệp chưa hoàn tất." });
    }
  };
  const chooseFiles = async (event) => {
    const selected = Array.from(event.currentTarget.files || []);
    event.currentTarget.value = "";
    setMediaError("");
    if (!mediaPolicy || !mediaSupported) {
      setMediaError("Kênh này chưa công bố chính sách media; không thể đính kèm tệp.");
      return;
    }
    let remaining = Math.max(0, mediaPolicy.maxAttachmentCount - attachmentRef.current.length);
    const accepted = [];
    for (const file of selected) {
      if (remaining <= 0) {
        setMediaError(`Mỗi tin nhắn gửi tối đa ${mediaPolicy.maxAttachmentCount} tệp theo chính sách kênh.`);
        continue;
      }
      if (!mediaPolicy.allowedMimeTypes.includes(file.type)) {
        setMediaError(`Định dạng ${file.type || "không xác định"} không được kênh hỗ trợ.`);
        continue;
      }
      if (file.size <= 0 || file.size > mediaPolicy.maxFileSizeBytes) {
        setMediaError(`Mỗi tệp phải lớn hơn 0 và không vượt ${Math.ceil(mediaPolicy.maxFileSizeBytes / 1048576)} MB.`);
        continue;
      }
      accepted.push({
        localId: crypto.randomUUID(),
        file,
        previewUrl: typeof URL.createObjectURL === "function" ? URL.createObjectURL(file) : null,
        uploadIntentId: crypto.randomUUID(),
        status: "uploading"
      });
      remaining -= 1;
    }
    if (accepted.length) {
      revision.current += accepted.length;
      updateAttachments((current) => [...current, ...accepted]);
      for (const attachment of accepted) await uploadAttachment(attachment);
    }
  };
  const removeAttachment = (attachment) => {
    if (attachment.status === "uploading") return;
    revokeObjectUrl(attachment.previewUrl);
    revision.current += 1;
    updateAttachments((current) => current.filter((item) => item.localId !== attachment.localId));
  };
  const submit = async () => {
    const submittedText = text.trim();
    const submittedAttachments = internal ? [] : attachmentRef.current.filter((item) => item.status === "ready" && item.fileId);
    const hasInvalidAttachment = !internal && attachmentRef.current.some((item) => item.status !== "ready");
    if (!canSend || send.pending || note.pending || send.unresolved || note.unresolved || !internal && hasInvalidAttachment) return;
    if (internal ? !submittedText : !submittedText && submittedAttachments.length === 0) return;
    const submittedRevision = revision.current;
    const submittedConversation = conversation.id;
    try {
      if (internal) {
        await note.execute({ path: { conversationId: conversation.id }, body: { text: submittedText } });
      } else {
        await send.execute({
          path: { conversationId: conversation.id },
          body: {
            clientMessageId: crypto.randomUUID(),
            ...submittedText ? { text: submittedText } : {},
            ...submittedAttachments.length ? { fileIds: submittedAttachments.map((item) => item.fileId) } : {},
            expectedConversationVersion: conversation.version
          }
        });
      }
      if (currentConversation.current !== submittedConversation) return;
      if (revision.current === submittedRevision && text.trim() === submittedText) setText("");
      if (submittedAttachments.length) {
        const submittedIds = new Set(submittedAttachments.map((item) => item.localId));
        for (const item of attachmentRef.current) if (submittedIds.has(item.localId)) revokeObjectUrl(item.previewUrl);
        updateAttachments((current) => current.filter((item) => !submittedIds.has(item.localId)));
      }
      if (revision.current === submittedRevision) setMediaError("");
    } catch {
    }
  };
  const readyCount = attachments.filter((item) => item.status === "ready" && item.fileId).length;
  const sendingBlocked = internal ? !text.trim() || note.pending || note.unresolved : !text.trim() && readyCount === 0 || send.pending || send.unresolved || attachments.some((item) => item.status !== "ready");
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      component: "form",
      "data-draft-clean": text.trim() || attachments.length ? void 0 : "true",
      onSubmit: (event) => {
        event.preventDefault();
        void submit();
      },
      sx: [layoutSx.inbox.composerInset, { borderTop: 1, borderColor: "divider", minHeight: 0, display: "flex", flexDirection: "column" }],
      children: [
        /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-composer-body", sx: { minHeight: 0, minWidth: 0, flex: { xl: "1 1 auto" }, overflowY: { xl: "auto" } }, children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: send.error || note.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 216,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            FormControlLabel,
            {
              label: "Ghi chú nội bộ (không gửi khách)",
              control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: internal, onChange: (event) => {
                revision.current += 1;
                setInternal(event.target.checked);
              }, disabled: !canReply }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                lineNumber: 219,
                columnNumber: 20
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
              lineNumber: 217,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            TextField,
            {
              fullWidth: true,
              multiline: true,
              minRows: 2,
              maxRows: 7,
              label: internal ? "Ghi chú cho nhóm" : "Nội dung trả lời khách",
              value: text,
              onChange: (event) => {
                revision.current += 1;
                setText(limitCodePoints(event.target.value, internal ? 1e4 : 2e4));
              },
              disabled: !canReply
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
              lineNumber: 221,
              columnNumber: 13
            },
            this
          ),
          !internal && mediaSupported && /* @__PURE__ */ jsxDEV(Stack, { sx: [layoutSx.inbox.messageContentGap, { minWidth: 0 }], children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                ref: attachmentInput,
                hidden: true,
                type: "file",
                multiple: true,
                accept: mediaPolicy?.allowedMimeTypes.join(","),
                "aria-label": "Chọn ảnh, tin thoại hoặc tệp",
                "data-testid": "inbox-attachment-input",
                disabled: !canSend || upload.pending,
                onChange: (event) => void chooseFiles(event)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                lineNumber: 233,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "small",
                variant: "outlined",
                startIcon: /* @__PURE__ */ jsxDEV(AttachFileRounded, {}, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 247,
                  columnNumber: 24
                }, this),
                disabled: !canSend || upload.pending || attachments.length >= (mediaPolicy?.maxAttachmentCount || 0),
                onClick: () => attachmentInput.current?.click(),
                children: "Đính kèm"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                lineNumber: 244,
                columnNumber: 21
              },
              this
            ),
            mediaPolicy && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
              "Tối đa ",
              mediaPolicy.maxAttachmentCount,
              " tệp, mỗi tệp ",
              Math.ceil(mediaPolicy.maxFileSizeBytes / 1048576),
              " MB; chỉ gửi sau khi kiểm tra mô phỏng đạt."
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
              lineNumber: 253,
              columnNumber: 37
            }, this),
            mediaError && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", onClose: () => setMediaError(""), children: mediaError }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
              lineNumber: 254,
              columnNumber: 36
            }, this),
            attachments.map(
              (attachment) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: [layoutSx.inbox.composerActionGap, layoutSx.surface.compactInset, { minWidth: 0, border: 1, borderColor: "divider", borderRadius: visualSx.radius.control }], children: [
                attachment.previewUrl && attachment.file.type.startsWith("image/") ? /* @__PURE__ */ jsxDEV(Box, { component: "img", src: attachment.previewUrl, alt: `Xem trước ${attachment.file.name}`, sx: { width: 56, height: 56, objectFit: "cover", borderRadius: visualSx.radius.control, flexShrink: 0 } }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 258,
                  columnNumber: 13
                }, this) : attachment.previewUrl && attachment.file.type.startsWith("audio/") ? /* @__PURE__ */ jsxDEV("audio", { controls: true, preload: "metadata", src: attachment.previewUrl, "aria-label": `Nghe thử ${attachment.file.name}`, style: { maxWidth: "min(260px, 52vw)" } }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 260,
                  columnNumber: 13
                }, this) : /* @__PURE__ */ jsxDEV(AttachFileRounded, { "aria-hidden": "true" }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 261,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(Stack, { sx: { minWidth: 0, flex: 1 }, children: [
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", sx: { overflowWrap: "anywhere" }, children: attachment.file.name }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                    lineNumber: 263,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(Typography, { role: "status", variant: "caption", color: attachment.status === "error" || attachment.status === "not_ready" ? "error.main" : "text.secondary", children: attachment.status === "uploading" ? "Đang tải và kiểm tra tệp…" : attachment.status === "ready" ? "Sẵn sàng gửi · kiểm tra mô phỏng đạt" : attachment.error || "Chưa thể gửi tệp" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                    lineNumber: 264,
                    columnNumber: 33
                  }, this),
                  attachment.status === "error" && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => void uploadAttachment(attachment), children: "Thử tải lại" }, void 0, false, {
                    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                    lineNumber: 267,
                    columnNumber: 67
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 262,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(IconButton, { "aria-label": `Gỡ ${attachment.file.name}`, disabled: attachment.status === "uploading", onClick: () => removeAttachment(attachment), children: /* @__PURE__ */ jsxDEV(CloseRounded, {}, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 270,
                  columnNumber: 33
                }, this) }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                  lineNumber: 269,
                  columnNumber: 29
                }, this)
              ] }, attachment.localId, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                lineNumber: 256,
                columnNumber: 11
              }, this)
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 232,
            columnNumber: 9
          }, this),
          !internal && !mediaSupported && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Kênh này chưa khai báo loại tệp được hỗ trợ; bạn vẫn có thể gửi văn bản." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 276,
            columnNumber: 46
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 215,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", justifyContent: "space-between", sx: [layoutSx.inbox.composerControlsBeforeGap, layoutSx.inbox.composerActionGap, { flexShrink: 0 }], children: [
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: !online ? "Đang ngoại tuyến" : !canSend ? "Cần tiếp quản hoặc quyền gửi hợp lệ" : "Tin gửi qua API; trạng thái được xác nhận từ phản hồi lệnh" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 279,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "submit",
              variant: "contained",
              endIcon: /* @__PURE__ */ jsxDEV(SendRounded, {}, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
                lineNumber: 285,
                columnNumber: 20
              }, this),
              disabled: !canSend || sendingBlocked,
              children: internal ? "Lưu ghi chú" : "Gửi trả lời"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
              lineNumber: 282,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 278,
          columnNumber: 13
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
      lineNumber: 206,
      columnNumber: 5
    },
    this
  );
}
_s(ConversationComposer, "ozKjeKJrZoGOCWxWHVnlFdZpB3I=", false, function() {
  return [useScope, useCan, useCommand, useCommand, useCommand, useApi];
});
_c = ConversationComposer;
export function ConversationMessageList({
  messages,
  timezone,
  onRate
}) {
  return messages.slice().sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((message) => {
    const senderLabel = message.direction === "internal" ? "Ghi chú nội bộ" : message.senderKind === "customer" ? "Khách" : message.senderKind === "bot" ? "Trợ lý AI" : "Nhân viên";
    const messageText = (message.text || "").replace(/\s+/g, " ").trim();
    const preview = Array.from(messageText).slice(0, 64).join("");
    const messagePreview = messageText ? preview === messageText ? messageText : `${preview.trimEnd()}…` : `${message.attachments?.length || 0} tệp đính kèm`;
    return /* @__PURE__ */ jsxDEV(Stack, { alignItems: message.direction === "inbound" ? "flex-start" : "flex-end", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-message-bubble", sx: [layoutSx.inbox.bubbleInset, {
      maxWidth: "88%",
      borderRadius: visualSx.radius.bubble,
      bgcolor: message.direction === "internal" ? colors.selected : message.direction === "inbound" ? colors.surface : colors.raised,
      border: message.direction === "internal" ? "1px solid" : "none",
      borderColor: colors.heroBorder
    }], children: /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "inbox-message-meta-flow", sx: layoutSx.inbox.messageMetaGap, children: [
      /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "inbox-message-content-flow", sx: layoutSx.inbox.messageContentGap, children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: senderLabel }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 316,
          columnNumber: 25
        }, this),
        messageText && /* @__PURE__ */ jsxDEV(Typography, { sx: { whiteSpace: "pre-wrap", overflowWrap: "anywhere" }, children: message.text }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 319,
          columnNumber: 41
        }, this),
        message.attachments?.map((attachment) => /* @__PURE__ */ jsxDEV(MessageAttachmentView, { attachment }, attachment.fileId, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 320,
          columnNumber: 67
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
        lineNumber: 315,
        columnNumber: 21
      }, this),
      message.sourceEvidence.length > 0 && /* @__PURE__ */ jsxDEV(Stack, { direction: "row", sx: [layoutSx.surface.compactContentGap, { flexWrap: "wrap" }], "aria-label": "Nguồn tham chiếu", children: message.sourceEvidence.map(
        (reference, index) => /* @__PURE__ */ jsxDEV(Chip, { size: "small", variant: "outlined", label: `${businessLabel(reference.type)} · ${reference.id}`, title: reference.type }, `${reference.type}:${reference.id}:${index}`, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 325,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
        lineNumber: 323,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: [layoutSx.inbox.composerActionGap, { flexWrap: "wrap" }], children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          dateTime(message.createdAt, timezone),
          " · ",
          businessLabel(message.status, "message")
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 330,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            size: "small",
            "aria-label": `Đánh giá tin nhắn của ${senderLabel} lúc ${dateTime(message.createdAt, timezone)}: ${messagePreview}`,
            onClick: () => onRate(message),
            children: "Đánh giá"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 331,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
        lineNumber: 329,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
      lineNumber: 314,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
      lineNumber: 307,
      columnNumber: 13
    }, this) }, message.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
      lineNumber: 306,
      columnNumber: 12
    }, this);
  });
}
_c2 = ConversationMessageList;
function MessageAttachmentView({ attachment }) {
  _s2();
  const { shop, membership } = useScope();
  const [readUrl, setReadUrl] = useState(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    let ownedUrl = null;
    setReadUrl(null);
    setFailed(false);
    void request("getFile", { path: { shopId: shop.id, fileId: attachment.fileId }, signal: controller.signal }).then((response) => {
      const result = response.data;
      if (result.status !== "ready" || !result.readUrl) throw new Error("FILE_NOT_READY");
      if (!active) {
        revokeObjectUrl(result.readUrl);
        return;
      }
      ownedUrl = result.readUrl;
      setReadUrl(result.readUrl);
    }).catch(() => {
      if (active && !controller.signal.aborted) setFailed(true);
    });
    return () => {
      active = false;
      controller.abort();
      revokeObjectUrl(ownedUrl);
    };
  }, [attachment.fileId, membership.permissionVersion, shop.id]);
  if (failed) return /* @__PURE__ */ jsxDEV(Typography, { role: "status", variant: "caption", color: "text.secondary", children: "Không thể đọc tệp này theo quyền hoặc phạm vi hiện tại." }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
    lineNumber: 377,
    columnNumber: 22
  }, this);
  if (!readUrl) return /* @__PURE__ */ jsxDEV(Typography, { role: "status", variant: "caption", color: "text.secondary", children: "Đang tải tệp an toàn…" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
    lineNumber: 378,
    columnNumber: 24
  }, this);
  if (attachment.mimeType.startsWith("image/")) return /* @__PURE__ */ jsxDEV(Box, { component: "img", src: readUrl, alt: attachment.name, sx: { display: "block", maxWidth: "min(100%, 360px)", maxHeight: 280, objectFit: "contain", borderRadius: visualSx.radius.control } }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
    lineNumber: 379,
    columnNumber: 56
  }, this);
  if (attachment.mimeType.startsWith("audio/")) return /* @__PURE__ */ jsxDEV("audio", { controls: true, preload: "metadata", src: readUrl, "aria-label": `Phát ${attachment.name}`, style: { maxWidth: "100%" } }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
    lineNumber: 380,
    columnNumber: 56
  }, this);
  return /* @__PURE__ */ jsxDEV("a", { href: readUrl, download: attachment.name, children: [
    attachment.name,
    " · tải tệp"
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
    lineNumber: 381,
    columnNumber: 10
  }, this);
}
_s2(MessageAttachmentView, "fi9OTIWyhozYyJfclPpt5jjFyl8=", false, function() {
  return [useScope];
});
_c3 = MessageAttachmentView;
export function ConversationContextPanel({
  conversation,
  children
}) {
  _s3();
  const { shop } = useScope();
  const canReadCustomers = useCan("customers.read");
  const canCreateOrders = useCan("orders.write");
  const metadata = useApi("getInboxMetadata");
  const assign = useCommand("assignConversation", ["getConversation", "listConversations"]);
  const [assignee, setAssignee] = useState("");
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      "data-testid": "inbox-context-panel",
      component: "aside",
      "aria-label": "Bối cảnh khách hàng",
      tabIndex: 0,
      sx: { minWidth: 0, minHeight: 0, maxHeight: { xl: 650 }, overflowY: { xl: "auto" } },
      children: /* @__PURE__ */ jsxDEV(Panel, { title: "Bối cảnh khách hàng", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-context-content", sx: layoutSx.inbox.contextInset, children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: conversation.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 405,
          columnNumber: 52
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 405,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kênh", children: metadata.data?.data.channels.find((channel) => channel.id === conversation.channelId)?.displayName || conversation.channelId }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 406,
          columnNumber: 21
        }, this),
        canReadCustomers ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/customers/${conversation.customerId}`, children: "Hồ sơ khách" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 410,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Thông tin khách bị ẩn theo quyền hiện tại." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        canCreateOrders && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/new?customerId=${conversation.customerId}&conversationId=${conversation.id}`, children: "Tạo đơn từ hội thoại" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 413,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Divider, { sx: [layoutSx.surface.sectionBefore, layoutSx.notice.afterGap] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 417,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao cho nhân viên", select: true, fullWidth: true, size: "small", value: assignee, onChange: (event) => setAssignee(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn nhân viên" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 419,
            columnNumber: 25
          }, this),
          metadata.data?.data.assignees.map((user) => /* @__PURE__ */ jsxDEV(MenuItem, { value: user.userId, children: user.displayName }, user.userId, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 420,
            columnNumber: 70
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 418,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          MutationButton,
          {
            permission: "conversations.assign",
            disabled: !assignee,
            busy: assign.pending,
            onClick: () => {
              void assign.execute({
                path: { conversationId: conversation.id },
                body: { userId: assignee, expectedVersion: conversation.version }
              }).catch(() => void 0);
            },
            children: "Phân công"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
            lineNumber: 422,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(ErrorNotice, { error: assign.error }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
          lineNumber: 435,
          columnNumber: 21
        }, this),
        children
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
        lineNumber: 404,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
        lineNumber: 403,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx",
      lineNumber: 396,
      columnNumber: 5
    },
    this
  );
}
_s3(ConversationContextPanel, "GH5HIk+MXRQRHBiYM6/OhvXx8Uk=", false, function() {
  return [useScope, useCan, useCan, useApi, useCommand];
});
_c4 = ConversationContextPanel;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "ConversationComposer");
$RefreshReg$(_c2, "ConversationMessageList");
$RefreshReg$(_c3, "MessageAttachmentView");
$RefreshReg$(_c4, "ConversationContextPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/conversation-components.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb01ZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBNWixTQUFRQSxTQUFTQyxxQkFBb0I7QUFDckMsU0FBU0MsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQzVDLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxNQUFNQyxTQUFTQyxrQkFBa0JDLFVBQVVDLFlBQVlDLFVBQVVDLE9BQU9DLFdBQVdDLGtCQUFrQjtBQUNsSSxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGlCQUFpQjtBQUV4QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxpQkFBaUJDLGdCQUFnQjtBQUMxQyxTQUFTQyxZQUFZQyxhQUFhQyxnQkFBZ0JDLE9BQU9DLFdBQVdDLGNBQWM7QUFDbEYsU0FBU0MsZ0JBQWdCO0FBWXpCLFNBQVNDLGdCQUFnQkMsS0FBZ0M7QUFDckQsTUFBSUEsS0FBS0MsV0FBVyxPQUFPLEVBQUdDLEtBQUlDLGdCQUFnQkgsR0FBRztBQUN6RDtBQUVPLGdCQUFTSSxxQkFBcUI7QUFBQSxFQUFFQztBQUV2QyxHQUFHO0FBQUFDLEtBQUE7QUFDQyxRQUFNLEVBQUVDLFNBQVNDLE9BQU8sSUFBSW5CLFNBQVM7QUFDckMsUUFBTW9CLFdBQVdyQixPQUFPLHFCQUFxQjtBQUM3QyxRQUFNc0IsT0FBT3ZCLFdBQVcsZUFBZSxDQUFDLGdCQUFnQixtQkFBbUIsbUJBQW1CLENBQUM7QUFDL0YsUUFBTXdCLE9BQU94QixXQUFXLG1CQUFtQixDQUFDLGNBQWMsQ0FBQztBQUMzRCxRQUFNeUIsU0FBU3pCLFdBQVcsY0FBYyxFQUFFO0FBQzFDLFFBQU0wQixXQUFXM0IsT0FBTyxrQkFBa0I7QUFDMUMsUUFBTSxDQUFDNEIsTUFBTUMsT0FBTyxJQUFJaEQsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ2lELFVBQVVDLFdBQVcsSUFBSWxELFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNtRCxhQUFhQyxjQUFjLElBQUlwRCxTQUE0QixFQUFFO0FBQ3BFLFFBQU0sQ0FBQ3FELFlBQVlDLGFBQWEsSUFBSXRELFNBQVMsRUFBRTtBQUMvQyxRQUFNdUQsV0FBV3hELE9BQU8sQ0FBQztBQUN6QixRQUFNeUQsc0JBQXNCekQsT0FBT3VDLGFBQWFtQixFQUFFO0FBQ2xELFFBQU1DLGtCQUFrQjNELE9BQXlCLElBQUk7QUFDckQsUUFBTTRELGdCQUFnQjVELE9BQTBCLEVBQUU7QUFDbEQsUUFBTTZELFFBQVE3RCxPQUFPLEtBQUs7QUFDMUJ5RCxzQkFBb0JLLFVBQVV2QixhQUFhbUI7QUFDM0NFLGdCQUFjRSxVQUFVVjtBQUN4QixRQUFNVyxVQUFVaEIsU0FBU2lCLE1BQU1BLEtBQUtDLFNBQVNDLEtBQUssQ0FBQUMsU0FBUUEsS0FBS1QsT0FBT25CLGFBQWE2QixTQUFTO0FBQzVGLFFBQU1DLGNBQWNOLFNBQVNNO0FBQzdCLFFBQU1DLGlCQUFpQkMsUUFBUUYsYUFBYUcsaUJBQWlCQyxVQUFVSixZQUFZSyxxQkFBcUIsS0FBS0wsWUFBWU0sbUJBQW1CLENBQUM7QUFDN0ksUUFBTUMsVUFBVWpDLFlBQVlELFdBQVdRLFlBQ25DWCxhQUFhc0MsU0FBUyxXQUN0QnRDLGFBQWF1QyxtQkFBbUJyQyxRQUFRc0MsS0FBS3JCLE1BQzdDbkIsYUFBYXlDLGdCQUFnQkMsVUFBVTtBQUczQ2xGLFlBQVUsTUFBTTtBQUNaOEQsVUFBTUMsVUFBVTtBQUNoQixXQUFPLE1BQU07QUFDVEQsWUFBTUMsVUFBVTtBQUNoQixpQkFBV29CLGNBQWN0QixjQUFjRSxRQUFTN0IsaUJBQWdCaUQsV0FBV0MsVUFBVTtBQUFBLElBQ3pGO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFFTCxRQUFNQyxvQkFBb0JBLENBQUNDLFdBQThEO0FBQ3JGLFVBQU1DLE9BQU9ELE9BQU96QixjQUFjRSxPQUFPO0FBQ3pDRixrQkFBY0UsVUFBVXdCO0FBQ3hCakMsbUJBQWVpQyxJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNQyxtQkFBbUJBLENBQUNDLFNBQWlCQyxVQUFvQztBQUMzRUwsc0JBQWtCLENBQUF0QixZQUFXQSxRQUFRNEIsSUFBSSxDQUFBdkIsU0FBUUEsS0FBS3FCLFlBQVlBLFVBQVUsRUFBRSxHQUFHckIsTUFBTSxHQUFHc0IsTUFBTSxJQUFJdEIsSUFBSSxDQUFDO0FBQUEsRUFDN0c7QUFFQSxRQUFNd0IsbUJBQW1CLE9BQU9ULGVBQWdDO0FBQzVELFFBQUksQ0FBQ2IsZUFBZSxDQUFDUixNQUFNQyxXQUFXTCxvQkFBb0JLLFlBQVl2QixhQUFhbUIsR0FBSTtBQUN2RjZCLHFCQUFpQkwsV0FBV00sU0FBUyxFQUFFSSxRQUFRLGFBQWFDLE9BQU9DLE9BQVUsQ0FBQztBQUM5RSxVQUFNQyxPQUFPLElBQUlDLFNBQVM7QUFDMUJELFNBQUtFLE9BQU8sUUFBUWYsV0FBV2dCLElBQUk7QUFDbkNILFNBQUtFLE9BQU8sV0FBVyxvQkFBb0I7QUFDM0NGLFNBQUtFLE9BQU8sY0FBYzFELGFBQWFtQixFQUFFO0FBQ3pDLFFBQUk7QUFDQSxZQUFNeUMsU0FBUyxNQUFNckQsT0FBT3NELFFBQVEsRUFBRUwsTUFBTU0sZ0JBQWdCbkIsV0FBV29CLGVBQWUsQ0FBQztBQUN2RixVQUFJLENBQUN6QyxNQUFNQyxXQUFXTCxvQkFBb0JLLFlBQVl2QixhQUFhbUIsR0FBSTtBQUN2RSxVQUFJeUMsT0FBT25DLEtBQUs0QixXQUFXLFNBQVM7QUFDaENMLHlCQUFpQkwsV0FBV00sU0FBUyxFQUFFZSxRQUFRSixPQUFPbkMsS0FBS04sSUFBSWtDLFFBQVEsYUFBYUMsT0FBTyxtREFBbUQsQ0FBQztBQUMvSTtBQUFBLE1BQ0o7QUFDQU4sdUJBQWlCTCxXQUFXTSxTQUFTLEVBQUVlLFFBQVFKLE9BQU9uQyxLQUFLTixJQUFJa0MsUUFBUSxRQUFRLENBQUM7QUFBQSxJQUNwRixTQUFTQyxPQUFPO0FBQ1osVUFBSSxDQUFDaEMsTUFBTUMsV0FBV0wsb0JBQW9CSyxZQUFZdkIsYUFBYW1CLEdBQUk7QUFDdkU2Qix1QkFBaUJMLFdBQVdNLFNBQVMsRUFBRUksUUFBUSxTQUFTQyxPQUFPQSxpQkFBaUJXLFFBQVFYLE1BQU1ZLFVBQVUseUJBQXlCLENBQUM7QUFBQSxJQUN0STtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxjQUFjLE9BQU9DLFVBQXlDO0FBQ2hFLFVBQU1DLFdBQVdDLE1BQU1DLEtBQUtILE1BQU1JLGNBQWNDLFNBQVMsRUFBRTtBQUMzREwsVUFBTUksY0FBY0UsUUFBUTtBQUM1QjFELGtCQUFjLEVBQUU7QUFDaEIsUUFBSSxDQUFDYyxlQUFlLENBQUNDLGdCQUFnQjtBQUNqQ2Ysb0JBQWMsaUVBQWlFO0FBQy9FO0FBQUEsSUFDSjtBQUNBLFFBQUkyRCxZQUFZQyxLQUFLQyxJQUFJLEdBQUcvQyxZQUFZSyxxQkFBcUJkLGNBQWNFLFFBQVFXLE1BQU07QUFDekYsVUFBTTRDLFdBQThCO0FBQ3BDLGVBQVduQixRQUFRVSxVQUFVO0FBQ3pCLFVBQUlNLGFBQWEsR0FBRztBQUNoQjNELHNCQUFjLDJCQUEyQmMsWUFBWUssa0JBQWtCLDRCQUE0QjtBQUNuRztBQUFBLE1BQ0o7QUFDQSxVQUFJLENBQUNMLFlBQVlHLGlCQUFpQjhDLFNBQVNwQixLQUFLcUIsSUFBSSxHQUFHO0FBQ25EaEUsc0JBQWMsYUFBYTJDLEtBQUtxQixRQUFRLGdCQUFnQiwwQkFBMEI7QUFDbEY7QUFBQSxNQUNKO0FBQ0EsVUFBSXJCLEtBQUtzQixRQUFRLEtBQUt0QixLQUFLc0IsT0FBT25ELFlBQVlNLGtCQUFrQjtBQUM1RHBCLHNCQUFjLHdDQUF3QzRELEtBQUtNLEtBQUtwRCxZQUFZTSxtQkFBbUIsT0FBTyxDQUFDLE1BQU07QUFDN0c7QUFBQSxNQUNKO0FBQ0EwQyxlQUFTSyxLQUFLO0FBQUEsUUFDVmxDLFNBQVNtQyxPQUFPQyxXQUFXO0FBQUEsUUFBRzFCO0FBQUFBLFFBQzlCZixZQUFZLE9BQU8vQyxJQUFJeUYsb0JBQW9CLGFBQWF6RixJQUFJeUYsZ0JBQWdCM0IsSUFBSSxJQUFJO0FBQUEsUUFDcEZJLGdCQUFnQnFCLE9BQU9DLFdBQVc7QUFBQSxRQUFHaEMsUUFBUTtBQUFBLE1BQ2pELENBQUM7QUFDRHNCLG1CQUFhO0FBQUEsSUFDakI7QUFDQSxRQUFJRyxTQUFTNUMsUUFBUTtBQUNqQmpCLGVBQVNNLFdBQVd1RCxTQUFTNUM7QUFDN0JXLHdCQUFrQixDQUFBdEIsWUFBVyxDQUFDLEdBQUdBLFNBQVMsR0FBR3VELFFBQVEsQ0FBQztBQUN0RCxpQkFBV25DLGNBQWNtQyxTQUFVLE9BQU0xQixpQkFBaUJULFVBQVU7QUFBQSxJQUN4RTtBQUFBLEVBQ0o7QUFFQSxRQUFNNEMsbUJBQW1CQSxDQUFDNUMsZUFBZ0M7QUFDdEQsUUFBSUEsV0FBV1UsV0FBVyxZQUFhO0FBQ3ZDM0Qsb0JBQWdCaUQsV0FBV0MsVUFBVTtBQUNyQzNCLGFBQVNNLFdBQVc7QUFDcEJzQixzQkFBa0IsQ0FBQXRCLFlBQVdBLFFBQVFpRSxPQUFPLENBQUE1RCxTQUFRQSxLQUFLcUIsWUFBWU4sV0FBV00sT0FBTyxDQUFDO0FBQUEsRUFDNUY7QUFFQSxRQUFNd0MsU0FBUyxZQUFZO0FBQ3ZCLFVBQU1DLGdCQUFnQmpGLEtBQUtrRixLQUFLO0FBQ2hDLFVBQU1DLHVCQUF1QmpGLFdBQVcsS0FBS1UsY0FBY0UsUUFBUWlFLE9BQU8sQ0FBQTVELFNBQVFBLEtBQUt5QixXQUFXLFdBQVd6QixLQUFLb0MsTUFBTTtBQUN4SCxVQUFNNkIsdUJBQXVCLENBQUNsRixZQUFZVSxjQUFjRSxRQUFRdUUsS0FBSyxDQUFBbEUsU0FBUUEsS0FBS3lCLFdBQVcsT0FBTztBQUNwRyxRQUFJLENBQUNoQixXQUFXaEMsS0FBSzBGLFdBQVd6RixLQUFLeUYsV0FBVzFGLEtBQUsyRixjQUFjMUYsS0FBSzBGLGNBQWUsQ0FBQ3JGLFlBQVlrRixxQkFBdUI7QUFDM0gsUUFBSWxGLFdBQVcsQ0FBQytFLGdCQUFnQixDQUFDQSxpQkFBaUJFLHFCQUFxQjFELFdBQVcsRUFBRztBQUNyRixVQUFNK0Qsb0JBQW9CaEYsU0FBU007QUFDbkMsVUFBTTJFLHdCQUF3QmxHLGFBQWFtQjtBQUMzQyxRQUFJO0FBQ0EsVUFBSVIsVUFBVTtBQUNWLGNBQU1MLEtBQUt1RCxRQUFRLEVBQUVzQyxNQUFNLEVBQUVDLGdCQUFnQnBHLGFBQWFtQixHQUFHLEdBQUdrRixNQUFNLEVBQUU1RixNQUFNaUYsY0FBYyxFQUFFLENBQUM7QUFBQSxNQUNuRyxPQUFPO0FBQ0gsY0FBTXJGLEtBQUt3RCxRQUFRO0FBQUEsVUFDZnNDLE1BQU0sRUFBRUMsZ0JBQWdCcEcsYUFBYW1CLEdBQUc7QUFBQSxVQUN4Q2tGLE1BQU07QUFBQSxZQUNGQyxpQkFBaUJsQixPQUFPQyxXQUFXO0FBQUEsWUFDbkMsR0FBSUssZ0JBQWdCLEVBQUVqRixNQUFNaUYsY0FBYyxJQUFJLENBQUM7QUFBQSxZQUMvQyxHQUFJRSxxQkFBcUIxRCxTQUFTLEVBQUVxRSxTQUFTWCxxQkFBcUJ6QyxJQUFJLENBQUF2QixTQUFRQSxLQUFLb0MsTUFBTyxFQUFFLElBQUksQ0FBQztBQUFBLFlBQ2pHd0MsNkJBQTZCeEcsYUFBYXlHO0FBQUFBLFVBQzlDO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDTDtBQUNBLFVBQUl2RixvQkFBb0JLLFlBQVkyRSxzQkFBdUI7QUFHM0QsVUFBSWpGLFNBQVNNLFlBQVkwRSxxQkFBcUJ4RixLQUFLa0YsS0FBSyxNQUFNRCxjQUFlaEYsU0FBUSxFQUFFO0FBQ3ZGLFVBQUlrRixxQkFBcUIxRCxRQUFRO0FBQzdCLGNBQU13RSxlQUFlLElBQUlDLElBQUlmLHFCQUFxQnpDLElBQUksQ0FBQXZCLFNBQVFBLEtBQUtxQixPQUFPLENBQUM7QUFDM0UsbUJBQVdyQixRQUFRUCxjQUFjRSxRQUFTLEtBQUltRixhQUFhRSxJQUFJaEYsS0FBS3FCLE9BQU8sRUFBR3ZELGlCQUFnQmtDLEtBQUtnQixVQUFVO0FBQzdHQywwQkFBa0IsQ0FBQXRCLFlBQVdBLFFBQVFpRSxPQUFPLENBQUE1RCxTQUFRLENBQUM4RSxhQUFhRSxJQUFJaEYsS0FBS3FCLE9BQU8sQ0FBQyxDQUFDO0FBQUEsTUFDeEY7QUFDQSxVQUFJaEMsU0FBU00sWUFBWTBFLGtCQUFtQmpGLGVBQWMsRUFBRTtBQUFBLElBQ2hFLFFBQVE7QUFBQSxJQUNKO0FBQUEsRUFFUjtBQUVBLFFBQU02RixhQUFhaEcsWUFBWTJFLE9BQU8sQ0FBQTVELFNBQVFBLEtBQUt5QixXQUFXLFdBQVd6QixLQUFLb0MsTUFBTSxFQUFFOUI7QUFDdEYsUUFBTTRFLGlCQUFpQm5HLFdBQ2pCLENBQUNGLEtBQUtrRixLQUFLLEtBQUtyRixLQUFLeUYsV0FBV3pGLEtBQUswRixhQUNwQyxDQUFDdkYsS0FBS2tGLEtBQUssS0FBS2tCLGVBQWUsS0FBTXhHLEtBQUswRixXQUFXMUYsS0FBSzJGLGNBQWNuRixZQUFZaUYsS0FBSyxDQUFBbEUsU0FBUUEsS0FBS3lCLFdBQVcsT0FBTztBQUUvSCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFVO0FBQUEsTUFDVixvQkFBa0I1QyxLQUFLa0YsS0FBSyxLQUFLOUUsWUFBWXFCLFNBQVNxQixTQUFZO0FBQUEsTUFDbEUsVUFBVSxDQUFBYSxVQUFTO0FBQ2ZBLGNBQU0yQyxlQUFlO0FBQ3JCLGFBQUt0QixPQUFPO0FBQUEsTUFDaEI7QUFBQSxNQUNBLElBQUksQ0FBQ2hHLFNBQVN1SCxNQUFNQyxlQUFlLEVBQUVDLFdBQVcsR0FBR0MsYUFBYSxXQUFXQyxXQUFXLEdBQUdDLFNBQVMsUUFBUUMsZUFBZSxTQUFTLENBQUM7QUFBQSxNQUVuSTtBQUFBLCtCQUFDLE9BQUksZUFBWSx1QkFBc0IsSUFBSSxFQUFFRixXQUFXLEdBQUdHLFVBQVUsR0FBR0MsTUFBTSxFQUFFQyxJQUFJLFdBQVcsR0FBR0MsV0FBVyxFQUFFRCxJQUFJLE9BQU8sRUFBRSxHQUM1SDtBQUFBLGlDQUFDLGVBQVksT0FBT3BILEtBQUtpRCxTQUFTaEQsS0FBS2dELFNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDN0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU07QUFBQSxjQUNOLFNBQVMsdUJBQUMsWUFBUyxTQUFTM0MsVUFBVSxVQUFVLENBQUF5RCxVQUFTO0FBQUVuRCx5QkFBU00sV0FBVztBQUFHWCw0QkFBWXdELE1BQU11RCxPQUFPQyxPQUFPO0FBQUEsY0FBRyxHQUFHLFVBQVUsQ0FBQ3hILFlBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1JO0FBQUE7QUFBQSxZQUZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFb0o7QUFBQSxVQUVwSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0c7QUFBQSxjQUNBO0FBQUEsY0FDQSxTQUFTO0FBQUEsY0FDVCxTQUFTO0FBQUEsY0FDVCxPQUFPTyxXQUFXLHFCQUFxQjtBQUFBLGNBQ3ZDLE9BQU9GO0FBQUFBLGNBQ1AsVUFBVSxDQUFBMkQsVUFBUztBQUFFbkQseUJBQVNNLFdBQVc7QUFBR2Isd0JBQVF6QixnQkFBZ0JtRixNQUFNdUQsT0FBT2pELE9BQU8vRCxXQUFXLE1BQVEsR0FBSyxDQUFDO0FBQUEsY0FBRztBQUFBLGNBQ3BILFVBQVUsQ0FBQ1A7QUFBQUE7QUFBQUEsWUFSZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRd0I7QUFBQSxVQUV2QixDQUFDTyxZQUFZb0Isa0JBQ1YsdUJBQUMsU0FBTSxJQUFJLENBQUN0QyxTQUFTdUgsTUFBTWEsbUJBQW1CLEVBQUVOLFVBQVUsRUFBRSxDQUFDLEdBQ3pEO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxLQUFLbkc7QUFBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxRQUFRVSxhQUFhRyxpQkFBaUI2RixLQUFLLEdBQUc7QUFBQSxnQkFDOUMsY0FBVztBQUFBLGdCQUNYLGVBQVk7QUFBQSxnQkFDWixVQUFVLENBQUN6RixXQUFXOUIsT0FBT3dGO0FBQUFBLGdCQUM3QixVQUFVLENBQUEzQixVQUFTLEtBQUtELFlBQVlDLEtBQUs7QUFBQTtBQUFBLGNBVDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMrQztBQUFBLFlBRS9DO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFNBQVE7QUFBQSxnQkFDUixXQUFXLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQzdCLFVBQVUsQ0FBQy9CLFdBQVc5QixPQUFPd0YsV0FBV2xGLFlBQVlxQixXQUFXSixhQUFhSyxzQkFBc0I7QUFBQSxnQkFDbEcsU0FBUyxNQUFNZixnQkFBZ0JHLFNBQVN3RyxNQUFNO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQ2pHLGVBQWUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLGNBQVFBLFlBQVlLO0FBQUFBLGNBQW1CO0FBQUEsY0FBZXlDLEtBQUtNLEtBQUtwRCxZQUFZTSxtQkFBbUIsT0FBTztBQUFBLGNBQUU7QUFBQSxpQkFBN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd007QUFBQSxZQUN2TnJCLGNBQWMsdUJBQUMsU0FBTSxVQUFTLFdBQVUsU0FBUyxNQUFNQyxjQUFjLEVBQUUsR0FBSUQsd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFO0FBQUEsWUFDdEZGLFlBQVlzQztBQUFBQSxjQUFJLENBQUFSLGVBQ2IsdUJBQUMsU0FBK0IsV0FBVSxPQUFNLFlBQVcsVUFBUyxJQUFJLENBQUNsRCxTQUFTdUgsTUFBTWdCLG1CQUFtQnZJLFNBQVN3SSxRQUFRQyxjQUFjLEVBQUVYLFVBQVUsR0FBR1ksUUFBUSxHQUFHaEIsYUFBYSxXQUFXaUIsY0FBY3pLLFNBQVMwSyxPQUFPQyxRQUFRLENBQUMsR0FDOU4zRjtBQUFBQSwyQkFBV0MsY0FBY0QsV0FBV2dCLEtBQUtxQixLQUFLcEYsV0FBVyxRQUFRLElBQzVELHVCQUFDLE9BQUksV0FBVSxPQUFNLEtBQUsrQyxXQUFXQyxZQUFZLEtBQUssYUFBYUQsV0FBV2dCLEtBQUs0RSxJQUFJLElBQUksSUFBSSxFQUFFQyxPQUFPLElBQUlDLFFBQVEsSUFBSUMsV0FBVyxTQUFTTixjQUFjekssU0FBUzBLLE9BQU9DLFNBQVNLLFlBQVksRUFBRSxLQUFqTTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtTSxJQUNuTWhHLFdBQVdDLGNBQWNELFdBQVdnQixLQUFLcUIsS0FBS3BGLFdBQVcsUUFBUSxJQUM3RCx1QkFBQyxXQUFNLFVBQVEsTUFBQyxTQUFRLFlBQVcsS0FBSytDLFdBQVdDLFlBQVksY0FBWSxZQUFZRCxXQUFXZ0IsS0FBSzRFLElBQUksSUFBSSxPQUFPLEVBQUVLLFVBQVUsbUJBQW1CLEtBQXJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVKLElBQ3ZKLHVCQUFDLHFCQUFrQixlQUFZLFVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQy9DLHVCQUFDLFNBQU0sSUFBSSxFQUFFckIsVUFBVSxHQUFHQyxNQUFNLEVBQUUsR0FDOUI7QUFBQSx5Q0FBQyxjQUFXLFNBQVEsU0FBUSxJQUFJLEVBQUVxQixjQUFjLFdBQVcsR0FBSWxHLHFCQUFXZ0IsS0FBSzRFLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9GO0FBQUEsa0JBQ3BGLHVCQUFDLGNBQVcsTUFBSyxVQUFTLFNBQVEsV0FBVSxPQUFPNUYsV0FBV1UsV0FBVyxXQUFXVixXQUFXVSxXQUFXLGNBQWMsZUFBZSxrQkFDbElWLHFCQUFXVSxXQUFXLGNBQWMsOEJBQThCVixXQUFXVSxXQUFXLFVBQVUseUNBQXlDVixXQUFXVyxTQUFTLHNCQURwSztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0NYLFdBQVdVLFdBQVcsV0FBVyx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU0sS0FBS0QsaUJBQWlCVCxVQUFVLEdBQUcsMkJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtGO0FBQUEscUJBTHhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFDQSx1QkFBQyxjQUFXLGNBQVksTUFBTUEsV0FBV2dCLEtBQUs0RSxJQUFJLElBQUksVUFBVTVGLFdBQVdVLFdBQVcsYUFBYSxTQUFTLE1BQU1rQyxpQkFBaUI1QyxVQUFVLEdBQ3pJLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWEsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWZRQSxXQUFXTSxTQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLFlBQ0g7QUFBQSxlQXpDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBDQTtBQUFBLFVBRUgsQ0FBQ3RDLFlBQVksQ0FBQ29CLGtCQUFrQix1QkFBQyxTQUFNLFVBQVMsUUFBTyx3RkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQTdEaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThEQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxXQUFVLE9BQU0sWUFBVyxVQUFTLGdCQUFlLGlCQUFnQixJQUFJLENBQUN0QyxTQUFTdUgsTUFBTThCLDJCQUEyQnJKLFNBQVN1SCxNQUFNZ0IsbUJBQW1CLEVBQUVXLFlBQVksRUFBRSxDQUFDLEdBQ3hLO0FBQUEsaUNBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFDL0IsV0FBQ3hJLFNBQVMscUJBQXFCLENBQUNrQyxVQUFVLHdDQUF3QyxnRUFEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUNSLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWTtBQUFBLGNBQ3JCLFVBQVUsQ0FBQ0EsV0FBV3lFO0FBQUFBLGNBRXJCbkcscUJBQVcsZ0JBQWdCO0FBQUE7QUFBQSxZQU5oQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUE7QUFBQTtBQUFBLElBcEZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFGQTtBQUVSO0FBQUNWLEdBbFBlRixzQkFBb0I7QUFBQSxVQUdKZixVQUNYRCxRQUNKRCxZQUNBQSxZQUNFQSxZQUNFRCxNQUFNO0FBQUE7QUFBQSxLQVJYa0I7QUFvUFQsZ0JBQVNnSix3QkFBd0I7QUFBQSxFQUFFQztBQUFBQSxFQUFVQztBQUFBQSxFQUFVQztBQUk5RCxHQUFHO0FBQ0MsU0FBT0YsU0FBU0csTUFBTSxFQUFFQyxLQUFLLENBQUNDLEdBQUdDLE1BQU1ELEVBQUVFLFVBQVVDLGNBQWNGLEVBQUVDLFNBQVMsQ0FBQyxFQUFFcEcsSUFBSSxDQUFBZSxZQUFXO0FBQzFGLFVBQU11RixjQUFjdkYsUUFBUXdGLGNBQWMsYUFBYSxtQkFBbUJ4RixRQUFReUYsZUFBZSxhQUFhLFVBQVV6RixRQUFReUYsZUFBZSxRQUFRLGNBQWM7QUFDckssVUFBTUMsZUFBZTFGLFFBQVF6RCxRQUFRLElBQUlvSixRQUFRLFFBQVEsR0FBRyxFQUFFbEUsS0FBSztBQUNuRSxVQUFNbUUsVUFBVXhGLE1BQU1DLEtBQUtxRixXQUFXLEVBQUVULE1BQU0sR0FBRyxFQUFFLEVBQUVyQixLQUFLLEVBQUU7QUFDNUQsVUFBTWlDLGlCQUFpQkgsY0FBY0UsWUFBWUYsY0FBY0EsY0FBYyxHQUFHRSxRQUFRRSxRQUFRLENBQUMsTUFBTSxHQUFHOUYsUUFBUXJELGFBQWFxQixVQUFVLENBQUM7QUFFMUksV0FBTyx1QkFBQyxTQUF1QixZQUFZZ0MsUUFBUXdGLGNBQWMsWUFBWSxlQUFlLFlBQ3hGLGlDQUFDLE9BQUksZUFBWSx3QkFBdUIsSUFBSSxDQUFDakssU0FBU3VILE1BQU1pRCxhQUFhO0FBQUEsTUFDckVyQixVQUFVO0FBQUEsTUFDVlIsY0FBY3pLLFNBQVMwSyxPQUFPNkI7QUFBQUEsTUFDOUJDLFNBQVNqRyxRQUFRd0YsY0FBYyxhQUFhL0ssT0FBTzBGLFdBQVdILFFBQVF3RixjQUFjLFlBQVkvSyxPQUFPc0osVUFBVXRKLE9BQU95TDtBQUFBQSxNQUN4SGpDLFFBQVFqRSxRQUFRd0YsY0FBYyxhQUFhLGNBQWM7QUFBQSxNQUN6RHZDLGFBQWF4SSxPQUFPMEw7QUFBQUEsSUFDeEIsQ0FBQyxHQUNHLGlDQUFDLFNBQU0sZUFBWSwyQkFBMEIsSUFBSTVLLFNBQVN1SCxNQUFNc0QsZ0JBQzVEO0FBQUEsNkJBQUMsU0FBTSxlQUFZLDhCQUE2QixJQUFJN0ssU0FBU3VILE1BQU1hLG1CQUMvRDtBQUFBLCtCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQy9CNEIseUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQ0csZUFBZSx1QkFBQyxjQUFXLElBQUksRUFBRVcsWUFBWSxZQUFZMUIsY0FBYyxXQUFXLEdBQUkzRSxrQkFBUXpELFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxRQUNuR3lELFFBQVFyRCxhQUFhc0MsSUFBSSxDQUFBUixlQUFjLHVCQUFDLHlCQUE4QyxjQUFuQkEsV0FBV3FCLFFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0UsQ0FBRztBQUFBLFdBTHJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0NFLFFBQVFzRyxlQUFldEksU0FBUyxLQUM3Qix1QkFBQyxTQUFNLFdBQVUsT0FBTSxJQUFJLENBQUN6QyxTQUFTd0ksUUFBUXdDLG1CQUFtQixFQUFFQyxVQUFVLE9BQU8sQ0FBQyxHQUFHLGNBQVcsb0JBQzdGeEcsa0JBQVFzRyxlQUFlckg7QUFBQUEsUUFBSSxDQUFDd0gsV0FBV0MsVUFDcEMsdUJBQUMsUUFBd0QsTUFBSyxTQUFRLFNBQVEsWUFBVyxPQUFPLEdBQUdyTixjQUFjb04sVUFBVTNGLElBQUksQ0FBQyxNQUFNMkYsVUFBVXhKLEVBQUUsSUFBSSxPQUFPd0osVUFBVTNGLFFBQTVKLEdBQUcyRixVQUFVM0YsSUFBSSxJQUFJMkYsVUFBVXhKLEVBQUUsSUFBSXlKLEtBQUssSUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0SztBQUFBLE1BQy9LLEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFFSix1QkFBQyxTQUFNLFdBQVUsT0FBTSxZQUFXLFVBQVMsSUFBSSxDQUFDbkwsU0FBU3VILE1BQU1nQixtQkFBbUIsRUFBRTBDLFVBQVUsT0FBTyxDQUFDLEdBQ2xHO0FBQUEsK0JBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBa0J4TDtBQUFBQSxtQkFBU2dGLFFBQVFxRixXQUFXTixRQUFRO0FBQUEsVUFBRTtBQUFBLFVBQUkxTCxjQUFjMkcsUUFBUWIsUUFBUSxTQUFTO0FBQUEsYUFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5STtBQUFBLFFBQ3pJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxjQUFZLHlCQUF5Qm9HLFdBQVcsUUFBUXZLLFNBQVNnRixRQUFRcUYsV0FBV04sUUFBUSxDQUFDLEtBQUtjLGNBQWM7QUFBQSxZQUNoSCxTQUFTLE1BQU1iLE9BQU9oRixPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFIbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkEsS0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQSxLQWxDZUEsUUFBUS9DLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ1A7QUFBQSxFQUNKLENBQUM7QUFDTDtBQUFDMEosTUFoRGU5QjtBQWtEaEIsU0FBUytCLHNCQUFzQixFQUFFbkksV0FBOEMsR0FBRztBQUFBb0ksTUFBQTtBQUM5RSxRQUFNLEVBQUVDLE1BQU1DLFdBQVcsSUFBSWpNLFNBQVM7QUFDdEMsUUFBTSxDQUFDa00sU0FBU0MsVUFBVSxJQUFJek4sU0FBd0IsSUFBSTtBQUMxRCxRQUFNLENBQUMwTixRQUFRQyxTQUFTLElBQUkzTixTQUFTLEtBQUs7QUFFMUNGLFlBQVUsTUFBTTtBQUNaLFVBQU04TixhQUFhLElBQUlDLGdCQUFnQjtBQUN2QyxRQUFJQyxTQUFTO0FBQ2IsUUFBSUMsV0FBMEI7QUFDOUJOLGVBQVcsSUFBSTtBQUNmRSxjQUFVLEtBQUs7QUFDZixTQUFLek0sUUFBUSxXQUFXLEVBQUV1SCxNQUFNLEVBQUV1RixRQUFRVixLQUFLN0osSUFBSTZDLFFBQVFyQixXQUFXcUIsT0FBTyxHQUFHMkgsUUFBUUwsV0FBV0ssT0FBTyxDQUFDLEVBQ3RHQyxLQUFLLENBQUFDLGFBQVk7QUFDZCxZQUFNakksU0FBU2lJLFNBQVNwSztBQUN4QixVQUFJbUMsT0FBT1AsV0FBVyxXQUFXLENBQUNPLE9BQU9zSCxRQUFTLE9BQU0sSUFBSWpILE1BQU0sZ0JBQWdCO0FBQ2xGLFVBQUksQ0FBQ3VILFFBQVE7QUFDVDlMLHdCQUFnQmtFLE9BQU9zSCxPQUFPO0FBQzlCO0FBQUEsTUFDSjtBQUNBTyxpQkFBVzdILE9BQU9zSDtBQUNsQkMsaUJBQVd2SCxPQUFPc0gsT0FBTztBQUFBLElBQzdCLENBQUMsRUFDQVksTUFBTSxNQUFNO0FBQ1QsVUFBSU4sVUFBVSxDQUFDRixXQUFXSyxPQUFPSSxRQUFTVixXQUFVLElBQUk7QUFBQSxJQUM1RCxDQUFDO0FBQ0wsV0FBTyxNQUFNO0FBQ1RHLGVBQVM7QUFDVEYsaUJBQVdVLE1BQU07QUFDakJ0TSxzQkFBZ0IrTCxRQUFRO0FBQUEsSUFDNUI7QUFBQSxFQUNKLEdBQUcsQ0FBQzlJLFdBQVdxQixRQUFRaUgsV0FBV2dCLG1CQUFtQmpCLEtBQUs3SixFQUFFLENBQUM7QUFFN0QsTUFBSWlLLE9BQVEsUUFBTyx1QkFBQyxjQUFXLE1BQUssVUFBUyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsdUVBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEg7QUFDN0ksTUFBSSxDQUFDRixRQUFTLFFBQU8sdUJBQUMsY0FBVyxNQUFLLFVBQVMsU0FBUSxXQUFVLE9BQU0sa0JBQWlCLHFDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdGO0FBQzdHLE1BQUl2SSxXQUFXdUosU0FBU3RNLFdBQVcsUUFBUSxFQUFHLFFBQU8sdUJBQUMsT0FBSSxXQUFVLE9BQU0sS0FBS3NMLFNBQVMsS0FBS3ZJLFdBQVc0RixNQUFNLElBQUksRUFBRWxCLFNBQVMsU0FBU3VCLFVBQVUsb0JBQW9CdUQsV0FBVyxLQUFLekQsV0FBVyxXQUFXTixjQUFjekssU0FBUzBLLE9BQU9DLFFBQVEsS0FBM0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2TDtBQUNsUCxNQUFJM0YsV0FBV3VKLFNBQVN0TSxXQUFXLFFBQVEsRUFBRyxRQUFPLHVCQUFDLFdBQU0sVUFBUSxNQUFDLFNBQVEsWUFBVyxLQUFLc0wsU0FBUyxjQUFZLFFBQVF2SSxXQUFXNEYsSUFBSSxJQUFJLE9BQU8sRUFBRUssVUFBVSxPQUFPLEtBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0g7QUFDekssU0FBTyx1QkFBQyxPQUFFLE1BQU1zQyxTQUFTLFVBQVV2SSxXQUFXNEYsTUFBTzVGO0FBQUFBLGVBQVc0RjtBQUFBQSxJQUFLO0FBQUEsT0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3RTtBQUNuRjtBQUFDd0MsSUFyQ1FELHVCQUFxQjtBQUFBLFVBQ0c5TCxRQUFRO0FBQUE7QUFBQSxNQURoQzhMO0FBdUNGLGdCQUFTc0IseUJBQXlCO0FBQUEsRUFBRXBNO0FBQUFBLEVBQWNxTTtBQUd6RCxHQUFHO0FBQUFDLE1BQUE7QUFDQyxRQUFNLEVBQUV0QixLQUFLLElBQUloTSxTQUFTO0FBQzFCLFFBQU11TixtQkFBbUJ4TixPQUFPLGdCQUFnQjtBQUNoRCxRQUFNeU4sa0JBQWtCek4sT0FBTyxjQUFjO0FBQzdDLFFBQU15QixXQUFXM0IsT0FBTyxrQkFBa0I7QUFDMUMsUUFBTTROLFNBQVMzTixXQUFXLHNCQUFzQixDQUFDLG1CQUFtQixtQkFBbUIsQ0FBQztBQUN4RixRQUFNLENBQUM0TixVQUFVQyxXQUFXLElBQUlqUCxTQUFTLEVBQUU7QUFFM0MsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csZUFBWTtBQUFBLE1BQ1osV0FBVTtBQUFBLE1BQ1YsY0FBVztBQUFBLE1BQ1gsVUFBVTtBQUFBLE1BQ1YsSUFBSSxFQUFFNkosVUFBVSxHQUFHSCxXQUFXLEdBQUcrRSxXQUFXLEVBQUUxRSxJQUFJLElBQUksR0FBR0MsV0FBVyxFQUFFRCxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BRW5GLGlDQUFDLFNBQU0sT0FBTSx1QkFDVCxpQ0FBQyxPQUFJLGVBQVkseUJBQXdCLElBQUloSSxTQUFTdUgsTUFBTTRGLGNBQ3hEO0FBQUEsK0JBQUMsY0FBVyxPQUFNLGNBQWEsaUNBQUMsVUFBTyxPQUFPNU0sYUFBYXFELFVBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUMsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3JFLHVCQUFDLGNBQVcsT0FBTSxRQUNiN0MsbUJBQVNpQixNQUFNQSxLQUFLQyxTQUFTQyxLQUFLLENBQUFILFlBQVdBLFFBQVFMLE9BQU9uQixhQUFhNkIsU0FBUyxHQUFHZ0wsZUFBZTdNLGFBQWE2QixhQUR0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDMEssbUJBQ0ssdUJBQUMsYUFBVSxJQUFJLE1BQU12QixLQUFLN0osRUFBRSxjQUFjbkIsYUFBYThNLFVBQVUsSUFBSSwyQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRixJQUNoRix1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQiwwREFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQ3BHTixtQkFDRyx1QkFBQyxhQUFVLElBQUksTUFBTXhCLEtBQUs3SixFQUFFLDBCQUEwQm5CLGFBQWE4TSxVQUFVLG1CQUFtQjlNLGFBQWFtQixFQUFFLElBQUcsb0NBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUosdUJBQUMsV0FBUSxJQUFJLENBQUMxQixTQUFTd0ksUUFBUThFLGVBQWV0TixTQUFTdU4sT0FBT0MsUUFBUSxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEUsdUJBQUMsYUFBVSxPQUFNLHNCQUFxQixRQUFNLE1BQUMsV0FBUyxNQUFDLE1BQUssU0FBUSxPQUFPUCxVQUFVLFVBQVUsQ0FBQXRJLFVBQVN1SSxZQUFZdkksTUFBTXVELE9BQU9qRCxLQUFLLEdBQ2xJO0FBQUEsaUNBQUMsWUFBUyxPQUFNLElBQUcsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFDaENsRSxTQUFTaUIsTUFBTUEsS0FBS3lMLFVBQVUvSixJQUFJLENBQUFYLFNBQVEsdUJBQUMsWUFBMkIsT0FBT0EsS0FBSzJLLFFBQVMzSyxlQUFLcUssZUFBdkNySyxLQUFLMkssUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0UsQ0FBVztBQUFBLGFBRjVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFlBQVc7QUFBQSxZQUNYLFVBQVUsQ0FBQ1Q7QUFBQUEsWUFDWCxNQUFNRCxPQUFPMUc7QUFBQUEsWUFDYixTQUFTLE1BQU07QUFDWCxtQkFBSzBHLE9BQU81SSxRQUFRO0FBQUEsZ0JBQ2hCc0MsTUFBTSxFQUFFQyxnQkFBZ0JwRyxhQUFhbUIsR0FBRztBQUFBLGdCQUN4Q2tGLE1BQU0sRUFBRThHLFFBQVFULFVBQVVVLGlCQUFpQnBOLGFBQWF5RyxRQUFRO0FBQUEsY0FDcEUsQ0FBQyxFQUFFcUYsTUFBTSxNQUFNdkksTUFBUztBQUFBLFlBQzVCO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLFFBQ0EsdUJBQUMsZUFBWSxPQUFPa0osT0FBT25KLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUNoQytJO0FBQUFBLFdBaENMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0EsS0FsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBO0FBQUEsSUExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkNBO0FBRVI7QUFBQ0MsSUF6RGVGLDBCQUF3QjtBQUFBLFVBSW5CcE4sVUFDUUQsUUFDREEsUUFDUEYsUUFDRkMsVUFBVTtBQUFBO0FBQUEsTUFSYnNOO0FBQXdCLElBQUFpQixJQUFBeEMsS0FBQXlDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUF4QyxLQUFBO0FBQUEsYUFBQXlDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiQ2hpcCIsIkRpdmlkZXIiLCJGb3JtQ29udHJvbExhYmVsIiwiQ2hlY2tib3giLCJJY29uQnV0dG9uIiwiTWVudUl0ZW0iLCJTdGFjayIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJBdHRhY2hGaWxlUm91bmRlZCIsIkNsb3NlUm91bmRlZCIsIlNlbmRSb3VuZGVkIiwiY29sb3JzIiwicmVxdWVzdCIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VDYW4iLCJ1c2VTY29wZSIsImxpbWl0Q29kZVBvaW50cyIsImRhdGVUaW1lIiwiRGV0YWlsTGluZSIsIkVycm9yTm90aWNlIiwiTXV0YXRpb25CdXR0b24iLCJQYW5lbCIsIlJvdXRlTGluayIsIlN0YXR1cyIsImxheW91dFN4IiwicmV2b2tlT2JqZWN0VXJsIiwidXJsIiwic3RhcnRzV2l0aCIsIlVSTCIsInJldm9rZU9iamVjdFVSTCIsIkNvbnZlcnNhdGlvbkNvbXBvc2VyIiwiY29udmVyc2F0aW9uIiwiX3MiLCJzZXNzaW9uIiwib25saW5lIiwiY2FuUmVwbHkiLCJzZW5kIiwibm90ZSIsInVwbG9hZCIsIm1ldGFkYXRhIiwidGV4dCIsInNldFRleHQiLCJpbnRlcm5hbCIsInNldEludGVybmFsIiwiYXR0YWNobWVudHMiLCJzZXRBdHRhY2htZW50cyIsIm1lZGlhRXJyb3IiLCJzZXRNZWRpYUVycm9yIiwicmV2aXNpb24iLCJjdXJyZW50Q29udmVyc2F0aW9uIiwiaWQiLCJhdHRhY2htZW50SW5wdXQiLCJhdHRhY2htZW50UmVmIiwiYWxpdmUiLCJjdXJyZW50IiwiY2hhbm5lbCIsImRhdGEiLCJjaGFubmVscyIsImZpbmQiLCJpdGVtIiwiY2hhbm5lbElkIiwibWVkaWFQb2xpY3kiLCJtZWRpYVN1cHBvcnRlZCIsIkJvb2xlYW4iLCJhbGxvd2VkTWltZVR5cGVzIiwibGVuZ3RoIiwibWF4QXR0YWNobWVudENvdW50IiwibWF4RmlsZVNpemVCeXRlcyIsImNhblNlbmQiLCJtb2RlIiwiYXNzaWduZWRVc2VySWQiLCJ1c2VyIiwic2VuZEVsaWdpYmlsaXR5Iiwic3RhdGUiLCJhdHRhY2htZW50IiwicHJldmlld1VybCIsInVwZGF0ZUF0dGFjaG1lbnRzIiwidXBkYXRlIiwibmV4dCIsInVwZGF0ZUF0dGFjaG1lbnQiLCJsb2NhbElkIiwicGF0Y2giLCJtYXAiLCJ1cGxvYWRBdHRhY2htZW50Iiwic3RhdHVzIiwiZXJyb3IiLCJ1bmRlZmluZWQiLCJmb3JtIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJmaWxlIiwicmVzdWx0IiwiZXhlY3V0ZSIsImlkZW1wb3RlbmN5S2V5IiwidXBsb2FkSW50ZW50SWQiLCJmaWxlSWQiLCJFcnJvciIsIm1lc3NhZ2UiLCJjaG9vc2VGaWxlcyIsImV2ZW50Iiwic2VsZWN0ZWQiLCJBcnJheSIsImZyb20iLCJjdXJyZW50VGFyZ2V0IiwiZmlsZXMiLCJ2YWx1ZSIsInJlbWFpbmluZyIsIk1hdGgiLCJtYXgiLCJhY2NlcHRlZCIsImluY2x1ZGVzIiwidHlwZSIsInNpemUiLCJjZWlsIiwicHVzaCIsImNyeXB0byIsInJhbmRvbVVVSUQiLCJjcmVhdGVPYmplY3RVUkwiLCJyZW1vdmVBdHRhY2htZW50IiwiZmlsdGVyIiwic3VibWl0Iiwic3VibWl0dGVkVGV4dCIsInRyaW0iLCJzdWJtaXR0ZWRBdHRhY2htZW50cyIsImhhc0ludmFsaWRBdHRhY2htZW50Iiwic29tZSIsInBlbmRpbmciLCJ1bnJlc29sdmVkIiwic3VibWl0dGVkUmV2aXNpb24iLCJzdWJtaXR0ZWRDb252ZXJzYXRpb24iLCJwYXRoIiwiY29udmVyc2F0aW9uSWQiLCJib2R5IiwiY2xpZW50TWVzc2FnZUlkIiwiZmlsZUlkcyIsImV4cGVjdGVkQ29udmVyc2F0aW9uVmVyc2lvbiIsInZlcnNpb24iLCJzdWJtaXR0ZWRJZHMiLCJTZXQiLCJoYXMiLCJyZWFkeUNvdW50Iiwic2VuZGluZ0Jsb2NrZWQiLCJwcmV2ZW50RGVmYXVsdCIsImluYm94IiwiY29tcG9zZXJJbnNldCIsImJvcmRlclRvcCIsImJvcmRlckNvbG9yIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJtaW5XaWR0aCIsImZsZXgiLCJ4bCIsIm92ZXJmbG93WSIsInRhcmdldCIsImNoZWNrZWQiLCJtZXNzYWdlQ29udGVudEdhcCIsImpvaW4iLCJjbGljayIsImNvbXBvc2VyQWN0aW9uR2FwIiwic3VyZmFjZSIsImNvbXBhY3RJbnNldCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInJhZGl1cyIsImNvbnRyb2wiLCJuYW1lIiwid2lkdGgiLCJoZWlnaHQiLCJvYmplY3RGaXQiLCJmbGV4U2hyaW5rIiwibWF4V2lkdGgiLCJvdmVyZmxvd1dyYXAiLCJjb21wb3NlckNvbnRyb2xzQmVmb3JlR2FwIiwiQ29udmVyc2F0aW9uTWVzc2FnZUxpc3QiLCJtZXNzYWdlcyIsInRpbWV6b25lIiwib25SYXRlIiwic2xpY2UiLCJzb3J0IiwiYSIsImIiLCJjcmVhdGVkQXQiLCJsb2NhbGVDb21wYXJlIiwic2VuZGVyTGFiZWwiLCJkaXJlY3Rpb24iLCJzZW5kZXJLaW5kIiwibWVzc2FnZVRleHQiLCJyZXBsYWNlIiwicHJldmlldyIsIm1lc3NhZ2VQcmV2aWV3IiwidHJpbUVuZCIsImJ1YmJsZUluc2V0IiwiYnViYmxlIiwiYmdjb2xvciIsInJhaXNlZCIsImhlcm9Cb3JkZXIiLCJtZXNzYWdlTWV0YUdhcCIsIndoaXRlU3BhY2UiLCJzb3VyY2VFdmlkZW5jZSIsImNvbXBhY3RDb250ZW50R2FwIiwiZmxleFdyYXAiLCJyZWZlcmVuY2UiLCJpbmRleCIsIl9jMiIsIk1lc3NhZ2VBdHRhY2htZW50VmlldyIsIl9zMiIsInNob3AiLCJtZW1iZXJzaGlwIiwicmVhZFVybCIsInNldFJlYWRVcmwiLCJmYWlsZWQiLCJzZXRGYWlsZWQiLCJjb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwiYWN0aXZlIiwib3duZWRVcmwiLCJzaG9wSWQiLCJzaWduYWwiLCJ0aGVuIiwicmVzcG9uc2UiLCJjYXRjaCIsImFib3J0ZWQiLCJhYm9ydCIsInBlcm1pc3Npb25WZXJzaW9uIiwibWltZVR5cGUiLCJtYXhIZWlnaHQiLCJDb252ZXJzYXRpb25Db250ZXh0UGFuZWwiLCJjaGlsZHJlbiIsIl9zMyIsImNhblJlYWRDdXN0b21lcnMiLCJjYW5DcmVhdGVPcmRlcnMiLCJhc3NpZ24iLCJhc3NpZ25lZSIsInNldEFzc2lnbmVlIiwiY29udGV4dEluc2V0IiwiZGlzcGxheU5hbWUiLCJjdXN0b21lcklkIiwic2VjdGlvbkJlZm9yZSIsIm5vdGljZSIsImFmdGVyR2FwIiwiYXNzaWduZWVzIiwidXNlcklkIiwiZXhwZWN0ZWRWZXJzaW9uIiwiX2MiLCJfYzMiLCJfYzQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY29udmVyc2F0aW9uLWNvbXBvbmVudHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7bGFiZWwgYXMgYnVzaW5lc3NMYWJlbH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvbGFiZWxzJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcbmltcG9ydCB0eXBlIHsgQ2hhbmdlRXZlbnQsIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEFsZXJ0LCBCb3gsIEJ1dHRvbiwgQ2hpcCwgRGl2aWRlciwgRm9ybUNvbnRyb2xMYWJlbCwgQ2hlY2tib3gsIEljb25CdXR0b24sIE1lbnVJdGVtLCBTdGFjaywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgQXR0YWNoRmlsZVJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BdHRhY2hGaWxlUm91bmRlZCc7XG5pbXBvcnQgQ2xvc2VSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvQ2xvc2VSb3VuZGVkJztcbmltcG9ydCBTZW5kUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL1NlbmRSb3VuZGVkJztcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uLCBNZXNzYWdlLCBNZXNzYWdlQXR0YWNobWVudCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgY29sb3JzIH0gZnJvbSAnQGJvdHNhbGVzL3Rva2Vucyc7XG5pbXBvcnQgeyByZXF1ZXN0IH0gZnJvbSAnQC9zaGFyZWQvYXBpL2NsaWVudCc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlQ2FuLCB1c2VTY29wZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IGxpbWl0Q29kZVBvaW50cywgZGF0ZVRpbWUgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgRGV0YWlsTGluZSwgRXJyb3JOb3RpY2UsIE11dGF0aW9uQnV0dG9uLCBQYW5lbCwgUm91dGVMaW5rLCBTdGF0dXMgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcblxudHlwZSBEcmFmdEF0dGFjaG1lbnQgPSB7XG4gICAgbG9jYWxJZDogc3RyaW5nO1xuICAgIGZpbGU6IEZpbGU7XG4gICAgcHJldmlld1VybDogc3RyaW5nIHwgbnVsbDtcbiAgICB1cGxvYWRJbnRlbnRJZDogc3RyaW5nO1xuICAgIGZpbGVJZD86IHN0cmluZztcbiAgICBzdGF0dXM6ICd1cGxvYWRpbmcnIHwgJ3JlYWR5JyB8ICdub3RfcmVhZHknIHwgJ2Vycm9yJztcbiAgICBlcnJvcj86IHN0cmluZztcbn07XG5cbmZ1bmN0aW9uIHJldm9rZU9iamVjdFVybCh1cmw6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpIHtcbiAgICBpZiAodXJsPy5zdGFydHNXaXRoKCdibG9iOicpKSBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDb252ZXJzYXRpb25Db21wb3Nlcih7IGNvbnZlcnNhdGlvbiB9OiB7XG4gICAgY29udmVyc2F0aW9uOiBDb252ZXJzYXRpb247XG59KSB7XG4gICAgY29uc3QgeyBzZXNzaW9uLCBvbmxpbmUgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgY2FuUmVwbHkgPSB1c2VDYW4oJ2NvbnZlcnNhdGlvbnMucmVwbHknKTtcbiAgICBjb25zdCBzZW5kID0gdXNlQ29tbWFuZCgnc2VuZE1lc3NhZ2UnLCBbJ2xpc3RNZXNzYWdlcycsICdnZXRDb252ZXJzYXRpb24nLCAnbGlzdENvbnZlcnNhdGlvbnMnXSk7XG4gICAgY29uc3Qgbm90ZSA9IHVzZUNvbW1hbmQoJ2FkZEludGVybmFsTm90ZScsIFsnbGlzdE1lc3NhZ2VzJ10pO1xuICAgIGNvbnN0IHVwbG9hZCA9IHVzZUNvbW1hbmQoJ3VwbG9hZEZpbGUnLCBbXSk7XG4gICAgY29uc3QgbWV0YWRhdGEgPSB1c2VBcGkoJ2dldEluYm94TWV0YWRhdGEnKTtcbiAgICBjb25zdCBbdGV4dCwgc2V0VGV4dF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2ludGVybmFsLCBzZXRJbnRlcm5hbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2F0dGFjaG1lbnRzLCBzZXRBdHRhY2htZW50c10gPSB1c2VTdGF0ZTxEcmFmdEF0dGFjaG1lbnRbXT4oW10pO1xuICAgIGNvbnN0IFttZWRpYUVycm9yLCBzZXRNZWRpYUVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCByZXZpc2lvbiA9IHVzZVJlZigwKTtcbiAgICBjb25zdCBjdXJyZW50Q29udmVyc2F0aW9uID0gdXNlUmVmKGNvbnZlcnNhdGlvbi5pZCk7XG4gICAgY29uc3QgYXR0YWNobWVudElucHV0ID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGF0dGFjaG1lbnRSZWYgPSB1c2VSZWY8RHJhZnRBdHRhY2htZW50W10+KFtdKTtcbiAgICBjb25zdCBhbGl2ZSA9IHVzZVJlZihmYWxzZSk7XG4gICAgY3VycmVudENvbnZlcnNhdGlvbi5jdXJyZW50ID0gY29udmVyc2F0aW9uLmlkO1xuICAgIGF0dGFjaG1lbnRSZWYuY3VycmVudCA9IGF0dGFjaG1lbnRzO1xuICAgIGNvbnN0IGNoYW5uZWwgPSBtZXRhZGF0YS5kYXRhPy5kYXRhLmNoYW5uZWxzLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBjb252ZXJzYXRpb24uY2hhbm5lbElkKTtcbiAgICBjb25zdCBtZWRpYVBvbGljeSA9IGNoYW5uZWw/Lm1lZGlhUG9saWN5O1xuICAgIGNvbnN0IG1lZGlhU3VwcG9ydGVkID0gQm9vbGVhbihtZWRpYVBvbGljeT8uYWxsb3dlZE1pbWVUeXBlcy5sZW5ndGggJiYgbWVkaWFQb2xpY3kubWF4QXR0YWNobWVudENvdW50ID4gMCAmJiBtZWRpYVBvbGljeS5tYXhGaWxlU2l6ZUJ5dGVzID4gMCk7XG4gICAgY29uc3QgY2FuU2VuZCA9IGNhblJlcGx5ICYmIG9ubGluZSAmJiAoaW50ZXJuYWwgfHwgKFxuICAgICAgICBjb252ZXJzYXRpb24ubW9kZSA9PT0gJ2h1bWFuJyAmJlxuICAgICAgICBjb252ZXJzYXRpb24uYXNzaWduZWRVc2VySWQgPT09IHNlc3Npb24udXNlci5pZCAmJlxuICAgICAgICBjb252ZXJzYXRpb24uc2VuZEVsaWdpYmlsaXR5LnN0YXRlID09PSAnYWxsb3dlZCdcbiAgICApKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGFsaXZlLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgYWxpdmUuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgICAgZm9yIChjb25zdCBhdHRhY2htZW50IG9mIGF0dGFjaG1lbnRSZWYuY3VycmVudCkgcmV2b2tlT2JqZWN0VXJsKGF0dGFjaG1lbnQucHJldmlld1VybCk7XG4gICAgICAgIH07XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgdXBkYXRlQXR0YWNobWVudHMgPSAodXBkYXRlOiAoY3VycmVudDogRHJhZnRBdHRhY2htZW50W10pID0+IERyYWZ0QXR0YWNobWVudFtdKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSB1cGRhdGUoYXR0YWNobWVudFJlZi5jdXJyZW50KTtcbiAgICAgICAgYXR0YWNobWVudFJlZi5jdXJyZW50ID0gbmV4dDtcbiAgICAgICAgc2V0QXR0YWNobWVudHMobmV4dCk7XG4gICAgfTtcblxuICAgIGNvbnN0IHVwZGF0ZUF0dGFjaG1lbnQgPSAobG9jYWxJZDogc3RyaW5nLCBwYXRjaDogUGFydGlhbDxEcmFmdEF0dGFjaG1lbnQ+KSA9PiB7XG4gICAgICAgIHVwZGF0ZUF0dGFjaG1lbnRzKGN1cnJlbnQgPT4gY3VycmVudC5tYXAoaXRlbSA9PiBpdGVtLmxvY2FsSWQgPT09IGxvY2FsSWQgPyB7IC4uLml0ZW0sIC4uLnBhdGNoIH0gOiBpdGVtKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHVwbG9hZEF0dGFjaG1lbnQgPSBhc3luYyAoYXR0YWNobWVudDogRHJhZnRBdHRhY2htZW50KSA9PiB7XG4gICAgICAgIGlmICghbWVkaWFQb2xpY3kgfHwgIWFsaXZlLmN1cnJlbnQgfHwgY3VycmVudENvbnZlcnNhdGlvbi5jdXJyZW50ICE9PSBjb252ZXJzYXRpb24uaWQpIHJldHVybjtcbiAgICAgICAgdXBkYXRlQXR0YWNobWVudChhdHRhY2htZW50LmxvY2FsSWQsIHsgc3RhdHVzOiAndXBsb2FkaW5nJywgZXJyb3I6IHVuZGVmaW5lZCB9KTtcbiAgICAgICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3JtLmFwcGVuZCgnZmlsZScsIGF0dGFjaG1lbnQuZmlsZSk7XG4gICAgICAgIGZvcm0uYXBwZW5kKCdwdXJwb3NlJywgJ2NvbnZlcnNhdGlvbl9tZWRpYScpO1xuICAgICAgICBmb3JtLmFwcGVuZCgncmVzb3VyY2VJZCcsIGNvbnZlcnNhdGlvbi5pZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGxvYWQuZXhlY3V0ZSh7IGZvcm0sIGlkZW1wb3RlbmN5S2V5OiBhdHRhY2htZW50LnVwbG9hZEludGVudElkIH0pO1xuICAgICAgICAgICAgaWYgKCFhbGl2ZS5jdXJyZW50IHx8IGN1cnJlbnRDb252ZXJzYXRpb24uY3VycmVudCAhPT0gY29udmVyc2F0aW9uLmlkKSByZXR1cm47XG4gICAgICAgICAgICBpZiAocmVzdWx0LmRhdGEuc3RhdHVzICE9PSAncmVhZHknKSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlQXR0YWNobWVudChhdHRhY2htZW50LmxvY2FsSWQsIHsgZmlsZUlkOiByZXN1bHQuZGF0YS5pZCwgc3RhdHVzOiAnbm90X3JlYWR5JywgZXJyb3I6ICdU4buHcCBjaMawYSBxdWEga2nhu4NtIHRyYSBtw7QgcGjhu49uZyBuw6puIGNoxrBhIHRo4buDIGfhu61pLicgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdXBkYXRlQXR0YWNobWVudChhdHRhY2htZW50LmxvY2FsSWQsIHsgZmlsZUlkOiByZXN1bHQuZGF0YS5pZCwgc3RhdHVzOiAncmVhZHknIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKCFhbGl2ZS5jdXJyZW50IHx8IGN1cnJlbnRDb252ZXJzYXRpb24uY3VycmVudCAhPT0gY29udmVyc2F0aW9uLmlkKSByZXR1cm47XG4gICAgICAgICAgICB1cGRhdGVBdHRhY2htZW50KGF0dGFjaG1lbnQubG9jYWxJZCwgeyBzdGF0dXM6ICdlcnJvcicsIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdU4bqjaSB04buHcCBjaMawYSBob8OgbiB04bqldC4nIH0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGNob29zZUZpbGVzID0gYXN5bmMgKGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCBzZWxlY3RlZCA9IEFycmF5LmZyb20oZXZlbnQuY3VycmVudFRhcmdldC5maWxlcyB8fCBbXSk7XG4gICAgICAgIGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWUgPSAnJztcbiAgICAgICAgc2V0TWVkaWFFcnJvcignJyk7XG4gICAgICAgIGlmICghbWVkaWFQb2xpY3kgfHwgIW1lZGlhU3VwcG9ydGVkKSB7XG4gICAgICAgICAgICBzZXRNZWRpYUVycm9yKCdLw6puaCBuw6B5IGNoxrBhIGPDtG5nIGLhu5EgY2jDrW5oIHPDoWNoIG1lZGlhOyBraMO0bmcgdGjhu4MgxJHDrW5oIGvDqG0gdOG7h3AuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHJlbWFpbmluZyA9IE1hdGgubWF4KDAsIG1lZGlhUG9saWN5Lm1heEF0dGFjaG1lbnRDb3VudCAtIGF0dGFjaG1lbnRSZWYuY3VycmVudC5sZW5ndGgpO1xuICAgICAgICBjb25zdCBhY2NlcHRlZDogRHJhZnRBdHRhY2htZW50W10gPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHNlbGVjdGVkKSB7XG4gICAgICAgICAgICBpZiAocmVtYWluaW5nIDw9IDApIHtcbiAgICAgICAgICAgICAgICBzZXRNZWRpYUVycm9yKGBN4buXaSB0aW4gbmjhuq9uIGfhu61pIHThu5FpIMSRYSAke21lZGlhUG9saWN5Lm1heEF0dGFjaG1lbnRDb3VudH0gdOG7h3AgdGhlbyBjaMOtbmggc8OhY2gga8OqbmguYCk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW1lZGlhUG9saWN5LmFsbG93ZWRNaW1lVHlwZXMuaW5jbHVkZXMoZmlsZS50eXBlKSkge1xuICAgICAgICAgICAgICAgIHNldE1lZGlhRXJyb3IoYMSQ4buLbmggZOG6oW5nICR7ZmlsZS50eXBlIHx8ICdraMO0bmcgeMOhYyDEkeG7i25oJ30ga2jDtG5nIMSRxrDhu6NjIGvDqm5oIGjhu5cgdHLhu6MuYCk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZmlsZS5zaXplIDw9IDAgfHwgZmlsZS5zaXplID4gbWVkaWFQb2xpY3kubWF4RmlsZVNpemVCeXRlcykge1xuICAgICAgICAgICAgICAgIHNldE1lZGlhRXJyb3IoYE3hu5dpIHThu4dwIHBo4bqjaSBs4bubbiBoxqFuIDAgdsOgIGtow7RuZyB2xrDhu6N0ICR7TWF0aC5jZWlsKG1lZGlhUG9saWN5Lm1heEZpbGVTaXplQnl0ZXMgLyAxMDQ4NTc2KX0gTUIuYCk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhY2NlcHRlZC5wdXNoKHtcbiAgICAgICAgICAgICAgICBsb2NhbElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBmaWxlLFxuICAgICAgICAgICAgICAgIHByZXZpZXdVcmw6IHR5cGVvZiBVUkwuY3JlYXRlT2JqZWN0VVJMID09PSAnZnVuY3Rpb24nID8gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSA6IG51bGwsXG4gICAgICAgICAgICAgICAgdXBsb2FkSW50ZW50SWQ6IGNyeXB0by5yYW5kb21VVUlEKCksIHN0YXR1czogJ3VwbG9hZGluZydcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmVtYWluaW5nIC09IDE7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFjY2VwdGVkLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV2aXNpb24uY3VycmVudCArPSBhY2NlcHRlZC5sZW5ndGg7XG4gICAgICAgICAgICB1cGRhdGVBdHRhY2htZW50cyhjdXJyZW50ID0+IFsuLi5jdXJyZW50LCAuLi5hY2NlcHRlZF0pO1xuICAgICAgICAgICAgZm9yIChjb25zdCBhdHRhY2htZW50IG9mIGFjY2VwdGVkKSBhd2FpdCB1cGxvYWRBdHRhY2htZW50KGF0dGFjaG1lbnQpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHJlbW92ZUF0dGFjaG1lbnQgPSAoYXR0YWNobWVudDogRHJhZnRBdHRhY2htZW50KSA9PiB7XG4gICAgICAgIGlmIChhdHRhY2htZW50LnN0YXR1cyA9PT0gJ3VwbG9hZGluZycpIHJldHVybjtcbiAgICAgICAgcmV2b2tlT2JqZWN0VXJsKGF0dGFjaG1lbnQucHJldmlld1VybCk7XG4gICAgICAgIHJldmlzaW9uLmN1cnJlbnQgKz0gMTtcbiAgICAgICAgdXBkYXRlQXR0YWNobWVudHMoY3VycmVudCA9PiBjdXJyZW50LmZpbHRlcihpdGVtID0+IGl0ZW0ubG9jYWxJZCAhPT0gYXR0YWNobWVudC5sb2NhbElkKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkVGV4dCA9IHRleHQudHJpbSgpO1xuICAgICAgICBjb25zdCBzdWJtaXR0ZWRBdHRhY2htZW50cyA9IGludGVybmFsID8gW10gOiBhdHRhY2htZW50UmVmLmN1cnJlbnQuZmlsdGVyKGl0ZW0gPT4gaXRlbS5zdGF0dXMgPT09ICdyZWFkeScgJiYgaXRlbS5maWxlSWQpO1xuICAgICAgICBjb25zdCBoYXNJbnZhbGlkQXR0YWNobWVudCA9ICFpbnRlcm5hbCAmJiBhdHRhY2htZW50UmVmLmN1cnJlbnQuc29tZShpdGVtID0+IGl0ZW0uc3RhdHVzICE9PSAncmVhZHknKTtcbiAgICAgICAgaWYgKCFjYW5TZW5kIHx8IHNlbmQucGVuZGluZyB8fCBub3RlLnBlbmRpbmcgfHwgc2VuZC51bnJlc29sdmVkIHx8IG5vdGUudW5yZXNvbHZlZCB8fCAoIWludGVybmFsICYmIGhhc0ludmFsaWRBdHRhY2htZW50KSkgcmV0dXJuO1xuICAgICAgICBpZiAoaW50ZXJuYWwgPyAhc3VibWl0dGVkVGV4dCA6ICFzdWJtaXR0ZWRUZXh0ICYmIHN1Ym1pdHRlZEF0dGFjaG1lbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBzdWJtaXR0ZWRSZXZpc2lvbiA9IHJldmlzaW9uLmN1cnJlbnQ7XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZENvbnZlcnNhdGlvbiA9IGNvbnZlcnNhdGlvbi5pZDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChpbnRlcm5hbCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IG5vdGUuZXhlY3V0ZSh7IHBhdGg6IHsgY29udmVyc2F0aW9uSWQ6IGNvbnZlcnNhdGlvbi5pZCB9LCBib2R5OiB7IHRleHQ6IHN1Ym1pdHRlZFRleHQgfSB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgc2VuZC5leGVjdXRlKHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogeyBjb252ZXJzYXRpb25JZDogY29udmVyc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudE1lc3NhZ2VJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLihzdWJtaXR0ZWRUZXh0ID8geyB0ZXh0OiBzdWJtaXR0ZWRUZXh0IH0gOiB7fSksXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi4oc3VibWl0dGVkQXR0YWNobWVudHMubGVuZ3RoID8geyBmaWxlSWRzOiBzdWJtaXR0ZWRBdHRhY2htZW50cy5tYXAoaXRlbSA9PiBpdGVtLmZpbGVJZCEpIH0gOiB7fSksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZENvbnZlcnNhdGlvblZlcnNpb246IGNvbnZlcnNhdGlvbi52ZXJzaW9uLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGN1cnJlbnRDb252ZXJzYXRpb24uY3VycmVudCAhPT0gc3VibWl0dGVkQ29udmVyc2F0aW9uKSByZXR1cm47XG4gICAgICAgICAgICAvLyBgdGV4dGAgaXMgdGhlIHN1Ym1pdCByZW5kZXIncyBzbmFwc2hvdC4gT25seSBjbGVhciB3aGVuIG5vIG5ld2VyXG4gICAgICAgICAgICAvLyB0ZXh0LCBtb2RlLCBvciBhdHRhY2htZW50IGVkaXQgaGFzIGFkdmFuY2VkIHRoZSBkcmFmdCByZXZpc2lvbi5cbiAgICAgICAgICAgIGlmIChyZXZpc2lvbi5jdXJyZW50ID09PSBzdWJtaXR0ZWRSZXZpc2lvbiAmJiB0ZXh0LnRyaW0oKSA9PT0gc3VibWl0dGVkVGV4dCkgc2V0VGV4dCgnJyk7XG4gICAgICAgICAgICBpZiAoc3VibWl0dGVkQXR0YWNobWVudHMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3VibWl0dGVkSWRzID0gbmV3IFNldChzdWJtaXR0ZWRBdHRhY2htZW50cy5tYXAoaXRlbSA9PiBpdGVtLmxvY2FsSWQpKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgYXR0YWNobWVudFJlZi5jdXJyZW50KSBpZiAoc3VibWl0dGVkSWRzLmhhcyhpdGVtLmxvY2FsSWQpKSByZXZva2VPYmplY3RVcmwoaXRlbS5wcmV2aWV3VXJsKTtcbiAgICAgICAgICAgICAgICB1cGRhdGVBdHRhY2htZW50cyhjdXJyZW50ID0+IGN1cnJlbnQuZmlsdGVyKGl0ZW0gPT4gIXN1Ym1pdHRlZElkcy5oYXMoaXRlbS5sb2NhbElkKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJldmlzaW9uLmN1cnJlbnQgPT09IHN1Ym1pdHRlZFJldmlzaW9uKSBzZXRNZWRpYUVycm9yKCcnKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBVbmtub3duIHNlbmRzIHByZXNlcnZlIHRleHQgYW5kIG1lZGlhOyB0aGUgY29tbWFuZCBob29rIGJsb2NrcyBhIGJsaW5kIHJldHJ5LlxuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHJlYWR5Q291bnQgPSBhdHRhY2htZW50cy5maWx0ZXIoaXRlbSA9PiBpdGVtLnN0YXR1cyA9PT0gJ3JlYWR5JyAmJiBpdGVtLmZpbGVJZCkubGVuZ3RoO1xuICAgIGNvbnN0IHNlbmRpbmdCbG9ja2VkID0gaW50ZXJuYWxcbiAgICAgICAgPyAhdGV4dC50cmltKCkgfHwgbm90ZS5wZW5kaW5nIHx8IG5vdGUudW5yZXNvbHZlZFxuICAgICAgICA6ICghdGV4dC50cmltKCkgJiYgcmVhZHlDb3VudCA9PT0gMCkgfHwgc2VuZC5wZW5kaW5nIHx8IHNlbmQudW5yZXNvbHZlZCB8fCBhdHRhY2htZW50cy5zb21lKGl0ZW0gPT4gaXRlbS5zdGF0dXMgIT09ICdyZWFkeScpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEJveFxuICAgICAgICAgICAgY29tcG9uZW50PVwiZm9ybVwiXG4gICAgICAgICAgICBkYXRhLWRyYWZ0LWNsZWFuPXt0ZXh0LnRyaW0oKSB8fCBhdHRhY2htZW50cy5sZW5ndGggPyB1bmRlZmluZWQgOiAndHJ1ZSd9XG4gICAgICAgICAgICBvblN1Ym1pdD17ZXZlbnQgPT4ge1xuICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgdm9pZCBzdWJtaXQoKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBzeD17W2xheW91dFN4LmluYm94LmNvbXBvc2VySW5zZXQsIHsgYm9yZGVyVG9wOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInLCBtaW5IZWlnaHQ6IDAsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicgfV19XG4gICAgICAgID5cbiAgICAgICAgICAgIDxCb3ggZGF0YS10ZXN0aWQ9XCJpbmJveC1jb21wb3Nlci1ib2R5XCIgc3g9e3sgbWluSGVpZ2h0OiAwLCBtaW5XaWR0aDogMCwgZmxleDogeyB4bDogJzEgMSBhdXRvJyB9LCBvdmVyZmxvd1k6IHsgeGw6ICdhdXRvJyB9IH19PlxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtzZW5kLmVycm9yIHx8IG5vdGUuZXJyb3J9IC8+XG4gICAgICAgICAgICA8Rm9ybUNvbnRyb2xMYWJlbFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiR2hpIGNow7ogbuG7mWkgYuG7mSAoa2jDtG5nIGfhu61pIGtow6FjaClcIlxuICAgICAgICAgICAgICAgIGNvbnRyb2w9ezxDaGVja2JveCBjaGVja2VkPXtpbnRlcm5hbH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgcmV2aXNpb24uY3VycmVudCArPSAxOyBzZXRJbnRlcm5hbChldmVudC50YXJnZXQuY2hlY2tlZCk7IH19IGRpc2FibGVkPXshY2FuUmVwbHl9IC8+fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBtdWx0aWxpbmVcbiAgICAgICAgICAgICAgICBtaW5Sb3dzPXsyfVxuICAgICAgICAgICAgICAgIG1heFJvd3M9ezd9XG4gICAgICAgICAgICAgICAgbGFiZWw9e2ludGVybmFsID8gJ0doaSBjaMO6IGNobyBuaMOzbScgOiAnTuG7mWkgZHVuZyB0cuG6oyBs4budaSBraMOhY2gnfVxuICAgICAgICAgICAgICAgIHZhbHVlPXt0ZXh0fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtldmVudCA9PiB7IHJldmlzaW9uLmN1cnJlbnQgKz0gMTsgc2V0VGV4dChsaW1pdENvZGVQb2ludHMoZXZlbnQudGFyZ2V0LnZhbHVlLCBpbnRlcm5hbCA/IDEwMDAwIDogMjAwMDApKTsgfX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhblJlcGx5fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHshaW50ZXJuYWwgJiYgbWVkaWFTdXBwb3J0ZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxTdGFjayBzeD17W2xheW91dFN4LmluYm94Lm1lc3NhZ2VDb250ZW50R2FwLCB7IG1pbldpZHRoOiAwIH1dfT5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e2F0dGFjaG1lbnRJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGhpZGRlblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbXVsdGlwbGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD17bWVkaWFQb2xpY3k/LmFsbG93ZWRNaW1lVHlwZXMuam9pbignLCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNo4buNbiDhuqNuaCwgdGluIHRob+G6oWkgaG/hurdjIHThu4dwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiaW5ib3gtYXR0YWNobWVudC1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhblNlbmQgfHwgdXBsb2FkLnBlbmRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gdm9pZCBjaG9vc2VGaWxlcyhldmVudCl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRJY29uPXs8QXR0YWNoRmlsZVJvdW5kZWQgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhblNlbmQgfHwgdXBsb2FkLnBlbmRpbmcgfHwgYXR0YWNobWVudHMubGVuZ3RoID49IChtZWRpYVBvbGljeT8ubWF4QXR0YWNobWVudENvdW50IHx8IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXR0YWNobWVudElucHV0LmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIMSQw61uaCBrw6htXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICB7bWVkaWFQb2xpY3kgJiYgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+VOG7kWkgxJFhIHttZWRpYVBvbGljeS5tYXhBdHRhY2htZW50Q291bnR9IHThu4dwLCBt4buXaSB04buHcCB7TWF0aC5jZWlsKG1lZGlhUG9saWN5Lm1heEZpbGVTaXplQnl0ZXMgLyAxMDQ4NTc2KX0gTUI7IGNo4buJIGfhu61pIHNhdSBraGkga2nhu4NtIHRyYSBtw7QgcGjhu49uZyDEkeG6oXQuPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAge21lZGlhRXJyb3IgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIG9uQ2xvc2U9eygpID0+IHNldE1lZGlhRXJyb3IoJycpfT57bWVkaWFFcnJvcn08L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAge2F0dGFjaG1lbnRzLm1hcChhdHRhY2htZW50ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjayBrZXk9e2F0dGFjaG1lbnQubG9jYWxJZH0gZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIHN4PXtbbGF5b3V0U3guaW5ib3guY29tcG9zZXJBY3Rpb25HYXAsIGxheW91dFN4LnN1cmZhY2UuY29tcGFjdEluc2V0LCB7IG1pbldpZHRoOiAwLCBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wgfV19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthdHRhY2htZW50LnByZXZpZXdVcmwgJiYgYXR0YWNobWVudC5maWxlLnR5cGUuc3RhcnRzV2l0aCgnaW1hZ2UvJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8Qm94IGNvbXBvbmVudD1cImltZ1wiIHNyYz17YXR0YWNobWVudC5wcmV2aWV3VXJsfSBhbHQ9e2BYZW0gdHLGsOG7m2MgJHthdHRhY2htZW50LmZpbGUubmFtZX1gfSBzeD17eyB3aWR0aDogNTYsIGhlaWdodDogNTYsIG9iamVjdEZpdDogJ2NvdmVyJywgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuY29udHJvbCwgZmxleFNocmluazogMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGF0dGFjaG1lbnQucHJldmlld1VybCAmJiBhdHRhY2htZW50LmZpbGUudHlwZS5zdGFydHNXaXRoKCdhdWRpby8nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8YXVkaW8gY29udHJvbHMgcHJlbG9hZD1cIm1ldGFkYXRhXCIgc3JjPXthdHRhY2htZW50LnByZXZpZXdVcmx9IGFyaWEtbGFiZWw9e2BOZ2hlIHRo4butICR7YXR0YWNobWVudC5maWxlLm5hbWV9YH0gc3R5bGU9e3sgbWF4V2lkdGg6ICdtaW4oMjYwcHgsIDUydncpJyB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8QXR0YWNoRmlsZVJvdW5kZWQgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN0YWNrIHN4PXt7IG1pbldpZHRoOiAwLCBmbGV4OiAxIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBzeD17eyBvdmVyZmxvd1dyYXA6ICdhbnl3aGVyZScgfX0+e2F0dGFjaG1lbnQuZmlsZS5uYW1lfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiIHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9e2F0dGFjaG1lbnQuc3RhdHVzID09PSAnZXJyb3InIHx8IGF0dGFjaG1lbnQuc3RhdHVzID09PSAnbm90X3JlYWR5JyA/ICdlcnJvci5tYWluJyA6ICd0ZXh0LnNlY29uZGFyeSd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F0dGFjaG1lbnQuc3RhdHVzID09PSAndXBsb2FkaW5nJyA/ICfEkGFuZyB04bqjaSB2w6Aga2nhu4NtIHRyYSB04buHcOKApicgOiBhdHRhY2htZW50LnN0YXR1cyA9PT0gJ3JlYWR5JyA/ICdT4bq1biBzw6BuZyBn4butaSDCtyBraeG7g20gdHJhIG3DtCBwaOG7j25nIMSR4bqhdCcgOiBhdHRhY2htZW50LmVycm9yIHx8ICdDaMawYSB0aOG7gyBn4butaSB04buHcCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F0dGFjaG1lbnQuc3RhdHVzID09PSAnZXJyb3InICYmIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4gdm9pZCB1cGxvYWRBdHRhY2htZW50KGF0dGFjaG1lbnQpfT5UaOG7rSB04bqjaSBs4bqhaTwvQnV0dG9uPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGFyaWEtbGFiZWw9e2BH4buhICR7YXR0YWNobWVudC5maWxlLm5hbWV9YH0gZGlzYWJsZWQ9e2F0dGFjaG1lbnQuc3RhdHVzID09PSAndXBsb2FkaW5nJ30gb25DbGljaz17KCkgPT4gcmVtb3ZlQXR0YWNobWVudChhdHRhY2htZW50KX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9zZVJvdW5kZWQgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHshaW50ZXJuYWwgJiYgIW1lZGlhU3VwcG9ydGVkICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5Lw6puaCBuw6B5IGNoxrBhIGtoYWkgYsOhbyBsb+G6oWkgdOG7h3AgxJHGsOG7o2MgaOG7lyB0cuG7ozsgYuG6oW4gduG6q24gY8OzIHRo4buDIGfhu61pIHbEg24gYuG6o24uPC9BbGVydD59XG4gICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgc3g9e1tsYXlvdXRTeC5pbmJveC5jb21wb3NlckNvbnRyb2xzQmVmb3JlR2FwLCBsYXlvdXRTeC5pbmJveC5jb21wb3NlckFjdGlvbkdhcCwgeyBmbGV4U2hyaW5rOiAwIH1dfT5cbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgeyFvbmxpbmUgPyAnxJBhbmcgbmdv4bqhaSB0dXnhur9uJyA6ICFjYW5TZW5kID8gJ0PhuqduIHRp4bq/cCBxdeG6o24gaG/hurdjIHF1eeG7gW4gZ+G7rWkgaOG7o3AgbOG7hycgOiAnVGluIGfhu61pIHF1YSBBUEk7IHRy4bqhbmcgdGjDoWkgxJHGsOG7o2MgeMOhYyBuaOG6rW4gdOG7qyBwaOG6o24gaOG7k2kgbOG7h25oJ31cbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgICAgICAgICAgIGVuZEljb249ezxTZW5kUm91bmRlZCAvPn1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5TZW5kIHx8IHNlbmRpbmdCbG9ja2VkfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2ludGVybmFsID8gJ0zGsHUgZ2hpIGNow7onIDogJ0fhu61pIHRy4bqjIGzhu51pJ31cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgIDwvQm94PlxuICAgICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDb252ZXJzYXRpb25NZXNzYWdlTGlzdCh7IG1lc3NhZ2VzLCB0aW1lem9uZSwgb25SYXRlIH06IHtcbiAgICBtZXNzYWdlczogTWVzc2FnZVtdO1xuICAgIHRpbWV6b25lOiBzdHJpbmc7XG4gICAgb25SYXRlOiAobWVzc2FnZTogTWVzc2FnZSkgPT4gdm9pZDtcbn0pIHtcbiAgICByZXR1cm4gbWVzc2FnZXMuc2xpY2UoKS5zb3J0KChhLCBiKSA9PiBhLmNyZWF0ZWRBdC5sb2NhbGVDb21wYXJlKGIuY3JlYXRlZEF0KSkubWFwKG1lc3NhZ2UgPT4ge1xuICAgICAgICBjb25zdCBzZW5kZXJMYWJlbCA9IG1lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW50ZXJuYWwnID8gJ0doaSBjaMO6IG7hu5lpIGLhu5knIDogbWVzc2FnZS5zZW5kZXJLaW5kID09PSAnY3VzdG9tZXInID8gJ0tow6FjaCcgOiBtZXNzYWdlLnNlbmRlcktpbmQgPT09ICdib3QnID8gJ1Ry4bujIGzDvSBBSScgOiAnTmjDom4gdmnDqm4nO1xuICAgICAgICBjb25zdCBtZXNzYWdlVGV4dCA9IChtZXNzYWdlLnRleHQgfHwgJycpLnJlcGxhY2UoL1xccysvZywgJyAnKS50cmltKCk7XG4gICAgICAgIGNvbnN0IHByZXZpZXcgPSBBcnJheS5mcm9tKG1lc3NhZ2VUZXh0KS5zbGljZSgwLCA2NCkuam9pbignJyk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2VQcmV2aWV3ID0gbWVzc2FnZVRleHQgPyBwcmV2aWV3ID09PSBtZXNzYWdlVGV4dCA/IG1lc3NhZ2VUZXh0IDogYCR7cHJldmlldy50cmltRW5kKCl94oCmYCA6IGAke21lc3NhZ2UuYXR0YWNobWVudHM/Lmxlbmd0aCB8fCAwfSB04buHcCDEkcOtbmgga8OobWA7XG5cbiAgICAgICAgcmV0dXJuIDxTdGFjayBrZXk9e21lc3NhZ2UuaWR9IGFsaWduSXRlbXM9e21lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW5ib3VuZCcgPyAnZmxleC1zdGFydCcgOiAnZmxleC1lbmQnfT5cbiAgICAgICAgICAgIDxCb3ggZGF0YS10ZXN0aWQ9XCJpbmJveC1tZXNzYWdlLWJ1YmJsZVwiIHN4PXtbbGF5b3V0U3guaW5ib3guYnViYmxlSW5zZXQsIHtcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzg4JScsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuYnViYmxlLFxuICAgICAgICAgICAgICAgIGJnY29sb3I6IG1lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW50ZXJuYWwnID8gY29sb3JzLnNlbGVjdGVkIDogbWVzc2FnZS5kaXJlY3Rpb24gPT09ICdpbmJvdW5kJyA/IGNvbG9ycy5zdXJmYWNlIDogY29sb3JzLnJhaXNlZCxcbiAgICAgICAgICAgICAgICBib3JkZXI6IG1lc3NhZ2UuZGlyZWN0aW9uID09PSAnaW50ZXJuYWwnID8gJzFweCBzb2xpZCcgOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9ycy5oZXJvQm9yZGVyLFxuICAgICAgICAgICAgfV19PlxuICAgICAgICAgICAgICAgIDxTdGFjayBkYXRhLXRlc3RpZD1cImluYm94LW1lc3NhZ2UtbWV0YS1mbG93XCIgc3g9e2xheW91dFN4LmluYm94Lm1lc3NhZ2VNZXRhR2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGRhdGEtdGVzdGlkPVwiaW5ib3gtbWVzc2FnZS1jb250ZW50LWZsb3dcIiBzeD17bGF5b3V0U3guaW5ib3gubWVzc2FnZUNvbnRlbnRHYXB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbmRlckxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAge21lc3NhZ2VUZXh0ICYmIDxUeXBvZ3JhcGh5IHN4PXt7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcsIG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9fT57bWVzc2FnZS50ZXh0fTwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZS5hdHRhY2htZW50cz8ubWFwKGF0dGFjaG1lbnQgPT4gPE1lc3NhZ2VBdHRhY2htZW50VmlldyBrZXk9e2F0dGFjaG1lbnQuZmlsZUlkfSBhdHRhY2htZW50PXthdHRhY2htZW50fSAvPil9XG4gICAgICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAgICAgIHttZXNzYWdlLnNvdXJjZUV2aWRlbmNlLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIHN4PXtbbGF5b3V0U3guc3VyZmFjZS5jb21wYWN0Q29udGVudEdhcCwgeyBmbGV4V3JhcDogJ3dyYXAnIH1dfSBhcmlhLWxhYmVsPVwiTmd14buTbiB0aGFtIGNoaeG6v3VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZS5zb3VyY2VFdmlkZW5jZS5tYXAoKHJlZmVyZW5jZSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoaXAga2V5PXtgJHtyZWZlcmVuY2UudHlwZX06JHtyZWZlcmVuY2UuaWR9OiR7aW5kZXh9YH0gc2l6ZT1cInNtYWxsXCIgdmFyaWFudD1cIm91dGxpbmVkXCIgbGFiZWw9e2Ake2J1c2luZXNzTGFiZWwocmVmZXJlbmNlLnR5cGUpfSDCtyAke3JlZmVyZW5jZS5pZH1gfSB0aXRsZT17cmVmZXJlbmNlLnR5cGV9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIHN4PXtbbGF5b3V0U3guaW5ib3guY29tcG9zZXJBY3Rpb25HYXAsIHsgZmxleFdyYXA6ICd3cmFwJyB9XX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj57ZGF0ZVRpbWUobWVzc2FnZS5jcmVhdGVkQXQsIHRpbWV6b25lKX0gwrcge2J1c2luZXNzTGFiZWwobWVzc2FnZS5zdGF0dXMsICdtZXNzYWdlJyl9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YMSQw6FuaCBnacOhIHRpbiBuaOG6r24gY+G7p2EgJHtzZW5kZXJMYWJlbH0gbMO6YyAke2RhdGVUaW1lKG1lc3NhZ2UuY3JlYXRlZEF0LCB0aW1lem9uZSl9OiAke21lc3NhZ2VQcmV2aWV3fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25SYXRlKG1lc3NhZ2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIMSQw6FuaCBnacOhXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvU3RhY2s+O1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBNZXNzYWdlQXR0YWNobWVudFZpZXcoeyBhdHRhY2htZW50IH06IHsgYXR0YWNobWVudDogTWVzc2FnZUF0dGFjaG1lbnQgfSkge1xuICAgIGNvbnN0IHsgc2hvcCwgbWVtYmVyc2hpcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBbcmVhZFVybCwgc2V0UmVhZFVybF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZmFpbGVkLCBzZXRGYWlsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgbGV0IGFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGxldCBvd25lZFVybDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgICAgIHNldFJlYWRVcmwobnVsbCk7XG4gICAgICAgIHNldEZhaWxlZChmYWxzZSk7XG4gICAgICAgIHZvaWQgcmVxdWVzdCgnZ2V0RmlsZScsIHsgcGF0aDogeyBzaG9wSWQ6IHNob3AuaWQsIGZpbGVJZDogYXR0YWNobWVudC5maWxlSWQgfSwgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCB9KVxuICAgICAgICAgICAgLnRoZW4ocmVzcG9uc2UgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgIT09ICdyZWFkeScgfHwgIXJlc3VsdC5yZWFkVXJsKSB0aHJvdyBuZXcgRXJyb3IoJ0ZJTEVfTk9UX1JFQURZJyk7XG4gICAgICAgICAgICAgICAgaWYgKCFhY3RpdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV2b2tlT2JqZWN0VXJsKHJlc3VsdC5yZWFkVXJsKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBvd25lZFVybCA9IHJlc3VsdC5yZWFkVXJsO1xuICAgICAgICAgICAgICAgIHNldFJlYWRVcmwocmVzdWx0LnJlYWRVcmwpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGFjdGl2ZSAmJiAhY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgc2V0RmFpbGVkKHRydWUpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBhY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgICAgICAgIHJldm9rZU9iamVjdFVybChvd25lZFVybCk7XG4gICAgICAgIH07XG4gICAgfSwgW2F0dGFjaG1lbnQuZmlsZUlkLCBtZW1iZXJzaGlwLnBlcm1pc3Npb25WZXJzaW9uLCBzaG9wLmlkXSk7XG5cbiAgICBpZiAoZmFpbGVkKSByZXR1cm4gPFR5cG9ncmFwaHkgcm9sZT1cInN0YXR1c1wiIHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPktow7RuZyB0aOG7gyDEkeG7jWMgdOG7h3AgbsOgeSB0aGVvIHF1eeG7gW4gaG/hurdjIHBo4bqhbSB2aSBoaeG7h24gdOG6oWkuPC9UeXBvZ3JhcGh5PjtcbiAgICBpZiAoIXJlYWRVcmwpIHJldHVybiA8VHlwb2dyYXBoeSByb2xlPVwic3RhdHVzXCIgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+xJBhbmcgdOG6o2kgdOG7h3AgYW4gdG/DoG7igKY8L1R5cG9ncmFwaHk+O1xuICAgIGlmIChhdHRhY2htZW50Lm1pbWVUeXBlLnN0YXJ0c1dpdGgoJ2ltYWdlLycpKSByZXR1cm4gPEJveCBjb21wb25lbnQ9XCJpbWdcIiBzcmM9e3JlYWRVcmx9IGFsdD17YXR0YWNobWVudC5uYW1lfSBzeD17eyBkaXNwbGF5OiAnYmxvY2snLCBtYXhXaWR0aDogJ21pbigxMDAlLCAzNjBweCknLCBtYXhIZWlnaHQ6IDI4MCwgb2JqZWN0Rml0OiAnY29udGFpbicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wgfX0gLz47XG4gICAgaWYgKGF0dGFjaG1lbnQubWltZVR5cGUuc3RhcnRzV2l0aCgnYXVkaW8vJykpIHJldHVybiA8YXVkaW8gY29udHJvbHMgcHJlbG9hZD1cIm1ldGFkYXRhXCIgc3JjPXtyZWFkVXJsfSBhcmlhLWxhYmVsPXtgUGjDoXQgJHthdHRhY2htZW50Lm5hbWV9YH0gc3R5bGU9e3sgbWF4V2lkdGg6ICcxMDAlJyB9fSAvPjtcbiAgICByZXR1cm4gPGEgaHJlZj17cmVhZFVybH0gZG93bmxvYWQ9e2F0dGFjaG1lbnQubmFtZX0+e2F0dGFjaG1lbnQubmFtZX0gwrcgdOG6o2kgdOG7h3A8L2E+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ29udmVyc2F0aW9uQ29udGV4dFBhbmVsKHsgY29udmVyc2F0aW9uLCBjaGlsZHJlbiB9OiB7XG4gICAgY29udmVyc2F0aW9uOiBDb252ZXJzYXRpb247XG4gICAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59KSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IGNhblJlYWRDdXN0b21lcnMgPSB1c2VDYW4oJ2N1c3RvbWVycy5yZWFkJyk7XG4gICAgY29uc3QgY2FuQ3JlYXRlT3JkZXJzID0gdXNlQ2FuKCdvcmRlcnMud3JpdGUnKTtcbiAgICBjb25zdCBtZXRhZGF0YSA9IHVzZUFwaSgnZ2V0SW5ib3hNZXRhZGF0YScpO1xuICAgIGNvbnN0IGFzc2lnbiA9IHVzZUNvbW1hbmQoJ2Fzc2lnbkNvbnZlcnNhdGlvbicsIFsnZ2V0Q29udmVyc2F0aW9uJywgJ2xpc3RDb252ZXJzYXRpb25zJ10pO1xuICAgIGNvbnN0IFthc3NpZ25lZSwgc2V0QXNzaWduZWVdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEJveFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJpbmJveC1jb250ZXh0LXBhbmVsXCJcbiAgICAgICAgICAgIGNvbXBvbmVudD1cImFzaWRlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJC4buRaSBj4bqjbmgga2jDoWNoIGjDoG5nXCJcbiAgICAgICAgICAgIHRhYkluZGV4PXswfVxuICAgICAgICAgICAgc3g9e3sgbWluV2lkdGg6IDAsIG1pbkhlaWdodDogMCwgbWF4SGVpZ2h0OiB7IHhsOiA2NTAgfSwgb3ZlcmZsb3dZOiB7IHhsOiAnYXV0bycgfSB9fVxuICAgICAgICA+XG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJC4buRaSBj4bqjbmgga2jDoWNoIGjDoG5nXCI+XG4gICAgICAgICAgICAgICAgPEJveCBkYXRhLXRlc3RpZD1cImluYm94LWNvbnRleHQtY29udGVudFwiIHN4PXtsYXlvdXRTeC5pbmJveC5jb250ZXh0SW5zZXR9PlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlRy4bqhbmcgdGjDoWlcIj48U3RhdHVzIHZhbHVlPXtjb252ZXJzYXRpb24uc3RhdHVzfSAvPjwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJLw6puaFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge21ldGFkYXRhLmRhdGE/LmRhdGEuY2hhbm5lbHMuZmluZChjaGFubmVsID0+IGNoYW5uZWwuaWQgPT09IGNvbnZlcnNhdGlvbi5jaGFubmVsSWQpPy5kaXNwbGF5TmFtZSB8fCBjb252ZXJzYXRpb24uY2hhbm5lbElkfVxuICAgICAgICAgICAgICAgICAgICA8L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgIHtjYW5SZWFkQ3VzdG9tZXJzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2N1c3RvbWVycy8ke2NvbnZlcnNhdGlvbi5jdXN0b21lcklkfWB9Pkjhu5Mgc8ahIGtow6FjaDwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgOiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5UaMO0bmcgdGluIGtow6FjaCBi4buLIOG6qW4gdGhlbyBxdXnhu4FuIGhp4buHbiB04bqhaS48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgICAgICB7Y2FuQ3JlYXRlT3JkZXJzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy9uZXc/Y3VzdG9tZXJJZD0ke2NvbnZlcnNhdGlvbi5jdXN0b21lcklkfSZjb252ZXJzYXRpb25JZD0ke2NvbnZlcnNhdGlvbi5pZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBU4bqhbyDEkcahbiB04burIGjhu5lpIHRob+G6oWlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8RGl2aWRlciBzeD17W2xheW91dFN4LnN1cmZhY2Uuc2VjdGlvbkJlZm9yZSwgbGF5b3V0U3gubm90aWNlLmFmdGVyR2FwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkdpYW8gY2hvIG5ow6JuIHZpw6puXCIgc2VsZWN0IGZ1bGxXaWR0aCBzaXplPVwic21hbGxcIiB2YWx1ZT17YXNzaWduZWV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRBc3NpZ25lZShldmVudC50YXJnZXQudmFsdWUpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPkNo4buNbiBuaMOibiB2acOqbjwvTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bWV0YWRhdGEuZGF0YT8uZGF0YS5hc3NpZ25lZXMubWFwKHVzZXIgPT4gPE1lbnVJdGVtIGtleT17dXNlci51c2VySWR9IHZhbHVlPXt1c2VyLnVzZXJJZH0+e3VzZXIuZGlzcGxheU5hbWV9PC9NZW51SXRlbT4pfVxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uPVwiY29udmVyc2F0aW9ucy5hc3NpZ25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFhc3NpZ25lZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1c3k9e2Fzc2lnbi5wZW5kaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvaWQgYXNzaWduLmV4ZWN1dGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiB7IGNvbnZlcnNhdGlvbklkOiBjb252ZXJzYXRpb24uaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogeyB1c2VySWQ6IGFzc2lnbmVlLCBleHBlY3RlZFZlcnNpb246IGNvbnZlcnNhdGlvbi52ZXJzaW9uIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIFBow6JuIGPDtG5nXG4gICAgICAgICAgICAgICAgICAgIDwvTXV0YXRpb25CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17YXNzaWduLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8L0JveD5cbiAgICApO1xufVxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvaW5ib3gvY29udmVyc2F0aW9uLWNvbXBvbmVudHMudHN4In0=