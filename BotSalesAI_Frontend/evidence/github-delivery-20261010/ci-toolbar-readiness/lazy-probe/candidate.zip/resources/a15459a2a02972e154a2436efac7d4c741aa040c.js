"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-TJQ5SMJY.js?v=854b7ff2";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-YVU6SLE6.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-TQYMLHGU.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-FJYLEWCQ.js?v=854b7ff2";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-QF5IVN5P.js?v=854b7ff2";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-QU3FZV7L.js?v=854b7ff2";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/chunk-PX6F3LHL.js?v=854b7ff2";

// ../../node_modules/@mui/icons-material/esm/AttachFileRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var AttachFileRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M16.5 6.75v10.58c0 2.09-1.53 3.95-3.61 4.15-2.39.23-4.39-1.64-4.39-3.98V5.14c0-1.31.94-2.5 2.24-2.63 1.5-.15 2.76 1.02 2.76 2.49v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6.75c0-.41-.34-.75-.75-.75s-.75.34-.75.75v8.61c0 1.31.94 2.5 2.24 2.63 1.5.15 2.76-1.02 2.76-2.49V5.17c0-2.09-1.53-3.95-3.61-4.15C9.01.79 7 2.66 7 5v12.27c0 2.87 2.1 5.44 4.96 5.71 3.29.3 6.04-2.26 6.04-5.48V6.75c0-.41-.34-.75-.75-.75s-.75.34-.75.75"
}), "AttachFileRounded");
export {
  AttachFileRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_AttachFileRounded.js.map
