import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/inbox/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/react_jsx-dev-runtime.js?v=d0d91d7e"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { ActionGroup, FieldGroup, FormFields, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/react.js?v=d0d91d7e"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Link as RouterLink, useParams, useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/react-router-dom.js?v=1ee86159";
import { Alert, Avatar, Box, Button, List, ListItem, ListItemButton, MenuItem, Stack, Tab, Tabs, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_material.js?v=b8e0ff7c";
import ArrowBackRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-84540-b615d022-9d08-4d58-b085-d75da7584034-toolbar-lazy-probe/deps/@mui_icons-material_ArrowBackRounded.js?v=8fde6b04";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, QueryState, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, Empty, DataTable, Amount } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { ConversationComposer, ConversationContextPanel, ConversationMessageList } from "/src/modules/inbox/conversation-components.tsx";
export function InboxPage() {
  _s();
  const { conversationId } = useParams();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "";
  const rawMode = params.get("mode");
  const mode = ["bot", "human", "paused"].find((value) => value === rawMode);
  const status = ["open", "resolved"].find((value) => value === params.get("status"));
  const channelId = params.get("channelId") || void 0;
  const assignedUserId = params.get("assignedUserId") || void 0;
  const listCursorParam = conversationId ? "listCursor" : "cursor";
  const cursor = params.get(listCursorParam) || void 0;
  const metadata = useApi("getInboxMetadata");
  const list = useApi("listConversations", { query: { q: q || void 0, status, mode, channelId, assignedUserId, cursor, limit: 40 } });
  const updateFilter = (key, value) => {
    const next = new URLSearchParams(params);
    if (value)
      next.set(key, value);
    else
      next.delete(key);
    next.delete(listCursorParam);
    setParams(next);
  };
  const detailHref = (id) => {
    const next = new URLSearchParams(params);
    const listCursor = next.get(listCursorParam);
    next.delete("cursor");
    next.delete("listCursor");
    if (listCursor)
      next.set("listCursor", listCursor);
    const query = next.toString();
    return `/s/${shop.id}/inbox/${id}${query ? `?${query}` : ""}`;
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Hộp thư khách hàng", subtitle: "AI và nhân viên tiếp quản rõ ràng; chỉ gửi khi chính sách kênh cho phép." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 68,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "300px minmax(0,1fr)" }, geometry: { minHeight: 650 }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { geometry: { display: { xs: conversationId ? "none" : "block", lg: "block" } }, children: [
        /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listConversations", placeholder: "Tìm hội thoại…", cursorParam: listCursorParam, filters: /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, flexWrap: "wrap", role: "group", "aria-label": "Bộ lọc hội thoại", children: [
          /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Trạng thái", value: status || "", onChange: (event) => updateFilter("status", event.target.value), sx: { flex: 1, minWidth: 140 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả trạng thái" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 74,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "open", children: "Đang mở" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 74,
              columnNumber: 72
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "resolved", children: "Đã giải quyết" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 74,
              columnNumber: 113
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 73,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Chế độ", value: mode || "", onChange: (event) => updateFilter("mode", event.target.value), sx: { flex: 1, minWidth: 140 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả chế độ" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 77,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "bot", children: "Bot" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 77,
              columnNumber: 68
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "human", children: "Nhân viên" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 77,
              columnNumber: 104
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "paused", children: "Tạm dừng" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 77,
              columnNumber: 148
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 76,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Kênh", value: channelId || "", onChange: (event) => updateFilter("channelId", event.target.value), sx: { flex: 1, minWidth: 160 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả kênh" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 80,
              columnNumber: 25
            }, this),
            metadata.data?.data.channels.map((channel) => /* @__PURE__ */ jsxDEV(MenuItem, { value: channel.id, children: channel.displayName }, channel.id, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 80,
              columnNumber: 113
            }, this))
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 79,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Nhân viên", value: assignedUserId || "", onChange: (event) => updateFilter("assignedUserId", event.target.value), sx: { flex: 1, minWidth: 160 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả nhân viên" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 83,
              columnNumber: 25
            }, this),
            metadata.data?.data.assignees.map((assignee) => /* @__PURE__ */ jsxDEV(MenuItem, { value: assignee.userId, children: assignee.displayName }, assignee.userId, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 83,
              columnNumber: 120
            }, this))
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 82,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 72,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 71,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: [
          /* @__PURE__ */ jsxDEV(List, { disablePadding: true, children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(ListItem, { disablePadding: true, children: /* @__PURE__ */ jsxDEV(ListItemButton, { selected: c.id === conversationId, component: RouterLink, to: detailHref(c.id), sx: [layoutSx.inbox.listInset, layoutSx.inbox.listContentGap, { alignItems: "start", borderBottom: 1, borderColor: "divider" }], children: [
            /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: colors.raised, color: "text.primary", width: 38, height: 38 }, children: c.displayName.slice(0, 1) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 90,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { minWidth: 0, flex: 1 }, children: [
              /* @__PURE__ */ jsxDEV(Stack, { direction: "row", justifyContent: "space-between", sx: [layoutSx.surface.compactContentGap, { alignItems: "center" }], children: [
                /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, noWrap: true, children: c.displayName }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                  lineNumber: 93,
                  columnNumber: 41
                }, this),
                c.unreadCount > 0 && /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-unread-count", sx: [layoutSx.inbox.unreadCountInset, { bgcolor: "primary.main", color: colors.onAccent, borderRadius: visualSx.radius.large, fontSize: tokens.fontSizes.meta }], children: c.unreadCount }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                  lineNumber: 94,
                  columnNumber: 63
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 92,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", noWrap: true, color: "text.secondary", sx: [layoutSx.surface.titleDescriptionGap, { display: "block" }], children: c.lastMessagePreview || "Chưa có tin nhắn" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 96,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: layoutSx.inbox.listStatusBeforeGap, children: /* @__PURE__ */ jsxDEV(Status, { value: c.mode }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 97,
                columnNumber: 82
              }, this) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 97,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 91,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 89,
            columnNumber: 29
          }, this) }, c.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 88,
            columnNumber: 53
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 87,
            columnNumber: 21
          }, this),
          !list.data?.data.length && /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có hội thoại phù hợp." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 102,
            columnNumber: 49
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: list.data?.page, cursorParam: listCursorParam }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 103,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 86,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 70,
        columnNumber: 13
      }, this),
      conversationId ? /* @__PURE__ */ jsxDEV(ConversationPanel, { conversationId }, conversationId, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 106,
        columnNumber: 31
      }, this) : /* @__PURE__ */ jsxDEV(Panel, { children: /* @__PURE__ */ jsxDEV(Empty, { text: "Chọn một cuộc trò chuyện để xem lịch sử, tiếp quản và tạo đơn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 106,
        columnNumber: 115
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 106,
        columnNumber: 108
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 69,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 67,
    columnNumber: 10
  }, this);
}
_s(InboxPage, "PDdHWf3JJnycFYNxevx7q+/ATLA=", false, function() {
  return [useParams, useScope, useSearchParams, useApi, useApi];
});
_c = InboxPage;
function ConversationPanel({
  conversationId
}) {
  _s2();
  const { shop } = useScope();
  const [params] = useSearchParams();
  const c = useApi("getConversation", { path: { conversationId } });
  const messageCursor = params.get("cursor") || void 0;
  const messages = useApi("listMessages", { path: { conversationId }, query: { cursor: messageCursor, limit: 100 } });
  const takeover = useCommand("takeoverConversation", ["getConversation", "listConversations"]);
  const release = useCommand("releaseConversation", ["getConversation", "listConversations"]);
  const resolve = useCommand("resolveConversation", ["getConversation", "listConversations"]);
  const feedback = useCommand("createFeedback", ["listFeedback"]);
  const [action, setAction] = useState(null);
  const [ratingMessage, setRatingMessage] = useState(null);
  const [correction, setCorrection] = useState("");
  const [rating, setRating] = useState("negative");
  const end = useRef(null);
  useEffect(() => {
    if (!messageCursor) end.current?.scrollIntoView({ block: "nearest", behavior: "auto" });
  }, [messages.data, messageCursor]);
  const inboxHref = () => {
    const next = new URLSearchParams(params);
    const listCursor = next.get("listCursor");
    next.delete("listCursor");
    next.delete("cursor");
    if (listCursor) next.set("cursor", listCursor);
    const query = next.toString();
    return `/s/${shop.id}/inbox${query ? `?${query}` : ""}`;
  };
  const conversation = c.data?.data;
  return /* @__PURE__ */ jsxDEV(QueryState, { query: c, pendingProfile: "section", children: conversation && /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "inbox-conversation-layout", columns: { xs: "1fr", xl: "minmax(0,1fr) 260px" }, geometry: { minWidth: 0 }, children: [
    /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-thread", component: "section", "aria-label": "Nội dung hội thoại", sx: { minWidth: 0, height: { xl: 650 } }, children: /* @__PURE__ */ jsxDEV(Panel, { geometry: { display: "flex", flexDirection: "column", height: "100%" }, children: [
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", alignItems: "center", justifyContent: "space-between", bodyMode: "header", geometry: { flex: "0 0 auto" }, children: [
        /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: [layoutSx.surface.compactContentGap, { flexWrap: "wrap" }], children: [
          /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: inboxHref(), sx: { display: { lg: "none" }, minWidth: 44 }, "aria-label": "Danh sách hội thoại", children: /* @__PURE__ */ jsxDEV(ArrowBackRounded, {}, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 152,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 151,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: colors.selected, color: "primary.main" }, children: conversation.displayName.slice(0, 1) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 154,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", children: conversation.displayName }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 156,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
              conversation.mode === "human" ? "Nhân viên đang tiếp quản" : "Trợ lý tự động",
              " · ",
              conversation.id
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 157,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 155,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 150,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "conversations.assign", variant: "outlined", onClick: () => setAction(conversation.mode === "human" ? "release" : "takeover"), children: conversation.mode === "human" ? "Trả lại bot" : "Tiếp quản" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 163,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(MutationButton, { permission: "conversations.assign", disabled: conversation.status === "resolved", onClick: () => setAction("resolve"), children: "Giải quyết" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 166,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 162,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 149,
        columnNumber: 29
      }, this),
      conversation.sendEligibility.state !== "allowed" && /* @__PURE__ */ jsxDEV(Box, { sx: layoutSx.inbox.paneInset, children: /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
        "Không được gửi tin: ",
        conversation.sendEligibility.reasonCode || "Chưa xác minh quyền gửi",
        ". Không tự vượt cửa sổ/chính sách kênh."
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 173,
        columnNumber: 37
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 172,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { "data-testid": "inbox-message-list", sx: [layoutSx.inbox.paneInset, { flex: 1, minHeight: { xs: 350, xl: "6em" }, maxHeight: 550, overflowY: "auto", background: colors.canvas }], children: /* @__PURE__ */ jsxDEV(QueryState, { query: messages, children: [
        /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "inbox-message-groups", sx: layoutSx.inbox.messageGroupGap, children: [
          /* @__PURE__ */ jsxDEV(
            ConversationMessageList,
            {
              messages: messages.data?.data || [],
              timezone: shop.timezone,
              onRate: (message) => {
                setRatingMessage(message);
                setCorrection("");
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 181,
              columnNumber: 41
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { ref: end }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 189,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 180,
          columnNumber: 37
        }, this),
        !messages.data?.data.length && /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có tin nhắn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 191,
          columnNumber: 69
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: messages.data?.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 192,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 179,
        columnNumber: 33
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 178,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV(ConversationComposer, { conversation }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 195,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 148,
      columnNumber: 25
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 147,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(ConversationContextPanel, { conversation, children: [
      __MOCK__ && /* @__PURE__ */ jsxDEV(MockSalesFlowPreview, { customerId: conversation.customerId, conversationId: conversation.id }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 199,
        columnNumber: 38
      }, this),
      __MOCK__ && /* @__PURE__ */ jsxDEV(MockUpsellPreview, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 200,
        columnNumber: 38
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 198,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(
      ConfirmDialog,
      {
        open: !!action,
        title: action === "takeover" ? "Tiếp quản cuộc trò chuyện" : action === "release" ? "Trả cuộc trò chuyện về bot" : "Đánh dấu đã giải quyết",
        confirmLabel: action === "takeover" ? "Tiếp quản" : action === "release" ? "Trả về AI" : "Đánh dấu đã giải quyết",
        description: `${conversation.displayName} (${conversationId}): ${action === "takeover" ? "chuyển trách nhiệm trả lời sang nhân viên và chặn câu trả lời AI đang chờ trước khi gửi." : action === "release" ? "trả trách nhiệm trả lời về AI sau khi kiểm quyền và điều kiện gửi hiện tại." : "đánh dấu hội thoại đã giải quyết; lịch sử tin nhắn được giữ."}`,
        requireReason: true,
        onClose: () => setAction(null),
        busy: takeover.pending || release.pending || resolve.pending,
        error: takeover.error || release.error || resolve.error,
        onConfirm: (reason) => {
          const operation = action === "takeover" ? takeover : action === "release" ? release : resolve;
          return operation.execute({
            path: { conversationId },
            version: conversation.version,
            body: { expectedVersion: conversation.version, reason }
          });
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 202,
        columnNumber: 21
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      EditDialog,
      {
        open: !!ratingMessage,
        title: "Đánh giá câu trả lời",
        onClose: () => setRatingMessage(null),
        busy: feedback.pending,
        actions: /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "contained",
            disabled: feedback.pending,
            onClick: async () => {
              if (!ratingMessage) return;
              try {
                await feedback.execute({ body: { conversationId, messageId: ratingMessage.id, rating, correction } });
                setRatingMessage(null);
              } catch {
              }
            },
            children: "Lưu phản hồi"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 226,
            columnNumber: 11
          },
          this
        ),
        children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: feedback.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 243,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { sx: { whiteSpace: "pre-wrap" }, children: ratingMessage?.text }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 245,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Đánh giá", select: true, value: rating, onChange: (event) => setRating(event.target.value), autoFocus: true, children: [
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "positive", children: "Hữu ích" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 247,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "negative", children: "Cần sửa" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
                lineNumber: 248,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 246,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Nội dung đề xuất sửa", multiline: true, minRows: 4, value: correction, onChange: (event) => setCorrection(event.target.value) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 250,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Phản hồi không tự trở thành kiến thức đã xuất bản. Cần người duyệt và kiểm thử." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
              lineNumber: 251,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 244,
            columnNumber: 25
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 220,
        columnNumber: 21
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 146,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 144,
    columnNumber: 5
  }, this);
}
_s2(ConversationPanel, "q0w2f/X66dh1K3cWNpVhwnG6VyA=", false, function() {
  return [useScope, useSearchParams, useApi, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c2 = ConversationPanel;
const sampleSalesScripts = {
  fashion: {
    label: "Thời trang",
    questions: ["Bạn đang tìm kiểu dáng và dịp sử dụng nào?", "Bạn muốn xem màu và kích cỡ nào?", "Cho mình xin khu vực giao hàng để kiểm tra phí."],
    boundary: "Chỉ tư vấn chất liệu, kích cỡ và chính sách đã có nguồn; thiếu thông tin thì hỏi lại hoặc chuyển nhân viên."
  },
  beauty: {
    label: "Mỹ phẩm",
    questions: ["Bạn đang tìm sản phẩm cho nhu cầu nào?", "Bạn có dị ứng hoặc thành phần cần tránh không?", "Bạn muốn nhân viên tư vấn thêm trước khi chọn?"],
    boundary: "Không chẩn đoán, hứa hiệu quả điều trị hoặc khẳng định phù hợp khi chưa có thông tin nguồn."
  },
  home: {
    label: "Gia dụng",
    questions: ["Bạn cần dùng sản phẩm trong không gian nào?", "Kích thước hoặc công suất mong muốn là bao nhiêu?", "Bạn cần kiểm tra bảo hành hay cách lắp đặt?"],
    boundary: "Thiếu kích thước, bảo hành hoặc hướng dẫn có nguồn thì không tự suy diễn; chuyển nhân viên xác minh."
  }
};
function MockSalesFlowPreview({ customerId, conversationId }) {
  _s3();
  const { shop } = useScope();
  const canReadCatalog = useCan("catalog.read");
  const canReadInventory = useCan("inventory.read");
  const products = useApi("listProducts", { query: { limit: 100 } }, canReadCatalog);
  const stock = useApi("listStockSnapshots", { query: { limit: 100 } }, canReadInventory);
  const [tab, setTab] = useState("script");
  const [industry, setIndustry] = useState("fashion");
  const script = sampleSalesScripts[industry];
  const sourceRows = (products.data?.data || []).filter((product) => product.status === "active").flatMap((product) => product.variants.filter((variant) => variant.active && variant.price).flatMap((variant) => (stock.data?.data || []).filter((snapshot) => snapshot.variantId === variant.id).map((snapshot) => ({ key: `${variant.id}:${snapshot.warehouseId}`, product, variant, snapshot }))));
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Luồng tư vấn bán hàng · bản xem trước", subtitle: "Mẫu tương tác cục bộ; không gọi AI và không gửi tin cho khách.", beforeGap: "surface", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Nội dung dưới đây chỉ minh họa giao diện. Bản demo không tự tạo câu trả lời AI hoặc lưu kịch bản lên máy chủ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 300,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Tabs, { value: tab, onChange: (_, value) => setTab(value), variant: "scrollable", scrollButtons: "auto", "aria-label": "Các bước tư vấn bán hàng mẫu", children: [
      /* @__PURE__ */ jsxDEV(Tab, { value: "script", label: "Kịch bản" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 302,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { value: "sources", label: "Giá & tồn" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 303,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { value: "order", label: "Tạo đơn" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 304,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { value: "confirmation", label: "Xác nhận" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 305,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 301,
      columnNumber: 13
    }, this),
    tab === "script" && /* @__PURE__ */ jsxDEV(SurfaceContent, { role: "tabpanel", "aria-label": "Kịch bản tư vấn mẫu", children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Ngành hàng mẫu", value: industry, onChange: (event) => setIndustry(event.target.value), children: Object.entries(sampleSalesScripts).map(([key, value]) => /* @__PURE__ */ jsxDEV(MenuItem, { value: key, children: value.label }, key, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 309,
        columnNumber: 79
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 308,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { component: "h3", variant: "subtitle2", children: "Câu hỏi gợi ý" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 311,
        columnNumber: 17
      }, this),
      script.questions.map((question, index) => /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
        index + 1,
        ". ",
        question
      ] }, question, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 312,
        columnNumber: 60
      }, this)),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
        "Ranh giới mẫu: ",
        script.boundary
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 313,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Bản nháp mẫu riêng với cấu hình bot đang dùng; không có thao tác xuất bản ở đây." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 314,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 307,
      columnNumber: 34
    }, this),
    tab === "sources" && /* @__PURE__ */ jsxDEV(SurfaceContent, { role: "tabpanel", "aria-label": "Nguồn giá và tồn trong hộp thư", children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giá lấy từ catalog và tồn từ snapshot có thời điểm. Dữ liệu chỉ là mock; cần truy vấn lại trước khi xác nhận đơn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 317,
        columnNumber: 17
      }, this),
      !canReadCatalog || !canReadInventory ? /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Cần quyền xem sản phẩm và tồn kho để đối chiếu nguồn." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 319,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: products, pendingProfile: "section", children: products.data && /* @__PURE__ */ jsxDEV(QueryState, { query: stock, pendingProfile: "section", children: stock.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Nguồn giá và tồn trong hộp thư", rows: sourceRows, rowKey: (row) => row.key, empty: "Chưa có sản phẩm đủ dữ liệu để đối chiếu.", columns: [
          { key: "product", label: "Sản phẩm", render: (row) => row.product.name },
          { key: "sku", label: "SKU", render: (row) => row.variant.sku },
          { key: "price", label: "Giá", align: "right", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.variant.price }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 324,
            columnNumber: 78
          }, this) },
          { key: "available", label: "Có thể bán", align: "right", render: (row) => row.snapshot.available },
          { key: "asOf", label: "Snapshot lúc", render: (row) => dateTime(row.snapshot.asOf, shop.timezone) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 321,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Preview giới hạn ở 100 sản phẩm và 100 snapshot đầu tiên; không phải danh sách đầy đủ." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 328,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", density: "comfortable", children: [
          /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/products`, children: "Mở danh sách sản phẩm" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 329,
            columnNumber: 72
          }, this),
          /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/inventory`, children: "Mở danh sách tồn kho" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
            lineNumber: 329,
            columnNumber: 146
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
          lineNumber: 329,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 320,
        columnNumber: 147
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 320,
        columnNumber: 81
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 320,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 316,
      columnNumber: 35
    }, this),
    tab === "order" && /* @__PURE__ */ jsxDEV(SurfaceContent, { role: "tabpanel", "aria-label": "Tạo đơn từ hội thoại", children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: "Chuyển sang biểu mẫu đơn để nhân viên kiểm tra khách, sản phẩm, số lượng và báo giá." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 333,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/new?customerId=${customerId}&conversationId=${conversationId}`, children: "Mở biểu mẫu tạo đơn từ hội thoại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 334,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Đơn trong demo được lưu vào MSW cục bộ của tab; đây không phải đơn trên máy chủ." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 335,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 332,
      columnNumber: 33
    }, this),
    tab === "confirmation" && /* @__PURE__ */ jsxDEV(SurfaceContent, { role: "tabpanel", "aria-label": "Điều kiện xác nhận đơn", children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không tự chốt đơn trong giao diện này. Bằng chứng xác nhận của khách, báo giá hiện hành và điều kiện giao nhận phải được kiểm tra trước khi nhân viên xác nhận." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 338,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", disabled: true, children: "Tự động xác nhận đơn chưa được hỗ trợ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 339,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Cần bổ sung capability và policy trong contract trước khi bật tự động xác nhận." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 340,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 337,
      columnNumber: 40
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 299,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 298,
    columnNumber: 10
  }, this);
}
_s3(MockSalesFlowPreview, "2T9NFmo2MyYgbt2bAsU1NH/v2g0=", false, function() {
  return [useScope, useCan, useCan, useApi, useApi];
});
_c3 = MockSalesFlowPreview;
function MockUpsellPreview() {
  _s4();
  const [open, setOpen] = useState(false);
  return /* @__PURE__ */ jsxDEV(SurfaceContent, { beforeGap: "surface", children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h3", variant: "subtitle2", children: "Gợi ý bán kèm mẫu · DEMO-PROMO-01" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 349,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Combo áo thun + túi tote chỉ minh họa giao diện. Không có API khuyến mại; giá, lợi nhuận, SKU và tồn kho chưa được xác thực." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 350,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { size: "small", variant: "outlined", onClick: () => setOpen((value) => !value), children: open ? "Ẩn điều kiện mẫu" : "Xem điều kiện combo mẫu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 351,
      columnNumber: 9
    }, this),
    open && /* @__PURE__ */ jsxDEV(Stack, { role: "status", "data-testid": "mock-promotion-preview", sx: [layoutSx.surface.compactContentGap, layoutSx.surface.compactInset, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control }], children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h3", variant: "subtitle2", children: "Combo mẫu · DEMO-PROMO-01" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 353,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: "Điều kiện minh họa: có ít nhất một áo và một phụ kiện trong đơn nháp." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 354,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Không áp dụng giảm giá, không sửa đơn và không khẳng định đạt biên lợi nhuận." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
        lineNumber: 355,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
      lineNumber: 352,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx",
    lineNumber: 348,
    columnNumber: 10
  }, this);
}
_s4(MockUpsellPreview, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c4 = MockUpsellPreview;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "InboxPage");
$RefreshReg$(_c2, "ConversationPanel");
$RefreshReg$(_c3, "MockSalesFlowPreview");
$RefreshReg$(_c4, "MockUpsellPreview");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/inbox/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NXLG1CQUNILGNBREc7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBL0NYLFNBQVNBLGFBQWFDLFlBQVlDLFlBQVlDLGFBQWFDLHNCQUFzQjtBQUNqRixTQUFTQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFFBQVFDLFlBQVlDLFdBQVdDLHVCQUF1QjtBQUMvRCxTQUFTQyxPQUFPQyxRQUFRQyxLQUFLQyxRQUFRQyxNQUFNQyxVQUFVQyxnQkFBZ0JDLFVBQVVDLE9BQU9DLEtBQUtDLE1BQU1DLFdBQVdDLGtCQUFrQjtBQUM5SCxPQUFPQyxzQkFBc0I7QUFFN0IsU0FBU0MsUUFBUUMsY0FBYztBQUMvQixTQUFTQyxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWUMsT0FBT0MsWUFBWUMsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxZQUFZQyxhQUFhQyxlQUFlQyxXQUFXQyxPQUFPQyxXQUFXQyxjQUFjO0FBQ25LLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxzQkFBc0JDLDBCQUEwQkMsK0JBQStCO0FBQ2pGLGdCQUFTQyxZQUFZO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxFQUFFQyxlQUFlLElBQUkzQyxVQUFVO0FBQ3JDLFFBQU0sRUFBRTRDLEtBQUssSUFBSXhCLFNBQVM7QUFDMUIsUUFBTSxDQUFDeUIsUUFBUUMsU0FBUyxJQUFJN0MsZ0JBQWdCO0FBQzVDLFFBQU04QyxJQUFJRixPQUFPRyxJQUFJLEdBQUcsS0FBSztBQUM3QixRQUFNQyxVQUFVSixPQUFPRyxJQUFJLE1BQU07QUFDakMsUUFBTUUsT0FBUSxDQUFDLE9BQU8sU0FBUyxRQUFRLEVBQVlDLEtBQUssQ0FBQUMsVUFBU0EsVUFBVUgsT0FBTztBQUNsRixRQUFNSSxTQUFVLENBQUMsUUFBUSxVQUFVLEVBQVlGLEtBQUssQ0FBQUMsVUFBU0EsVUFBVVAsT0FBT0csSUFBSSxRQUFRLENBQUM7QUFDM0YsUUFBTU0sWUFBWVQsT0FBT0csSUFBSSxXQUFXLEtBQUtPO0FBQzdDLFFBQU1DLGlCQUFpQlgsT0FBT0csSUFBSSxnQkFBZ0IsS0FBS087QUFDdkQsUUFBTUUsa0JBQWtCZCxpQkFBaUIsZUFBZTtBQUN4RCxRQUFNZSxTQUFTYixPQUFPRyxJQUFJUyxlQUFlLEtBQUtGO0FBQzlDLFFBQU1JLFdBQVd6QyxPQUFPLGtCQUFrQjtBQUMxQyxRQUFNMEMsT0FBTzFDLE9BQU8scUJBQXFCLEVBQUUyQyxPQUFPLEVBQUVkLEdBQUdBLEtBQUtRLFFBQVdGLFFBQVFILE1BQU1JLFdBQVdFLGdCQUFnQkUsUUFBUUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUNySSxRQUFNQyxlQUFlQSxDQUFDQyxLQUFhWixVQUFrQjtBQUNqRCxVQUFNYSxPQUFPLElBQUlDLGdCQUFnQnJCLE1BQU07QUFDdkMsUUFBSU87QUFDQWEsV0FBS0UsSUFBSUgsS0FBS1osS0FBSztBQUFBO0FBRW5CYSxXQUFLRyxPQUFPSixHQUFHO0FBQ25CQyxTQUFLRyxPQUFPWCxlQUFlO0FBQzNCWCxjQUFVbUIsSUFBSTtBQUFBLEVBQ2xCO0FBQ0EsUUFBTUksYUFBYUEsQ0FBQ0MsT0FBZTtBQUMvQixVQUFNTCxPQUFPLElBQUlDLGdCQUFnQnJCLE1BQU07QUFDdkMsVUFBTTBCLGFBQWFOLEtBQUtqQixJQUFJUyxlQUFlO0FBQzNDUSxTQUFLRyxPQUFPLFFBQVE7QUFDcEJILFNBQUtHLE9BQU8sWUFBWTtBQUN4QixRQUFJRztBQUNBTixXQUFLRSxJQUFJLGNBQWNJLFVBQVU7QUFDckMsVUFBTVYsUUFBUUksS0FBS08sU0FBUztBQUM1QixXQUFPLE1BQU01QixLQUFLMEIsRUFBRSxVQUFVQSxFQUFFLEdBQUdULFFBQVEsSUFBSUEsS0FBSyxLQUFLLEVBQUU7QUFBQSxFQUMvRDtBQUNBLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0sc0JBQXFCLFVBQVMsOEVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEg7QUFBQSxJQUMxSCx1QkFBQyxlQUFZLFNBQVMsRUFBRVksSUFBSSxPQUFPQyxJQUFJLHNCQUFzQixHQUFHLFVBQVUsRUFBQ0MsV0FBVyxJQUFHLEdBQ3JGO0FBQUEsNkJBQUMsU0FBTSxVQUFVLEVBQUVDLFNBQVMsRUFBRUgsSUFBSTlCLGlCQUFpQixTQUFTLFNBQVMrQixJQUFJLFFBQVEsRUFBRSxHQUMvRTtBQUFBLCtCQUFDLFdBQVEsV0FBVSxxQkFBb0IsYUFBWSxrQkFBaUIsYUFBYWpCLGlCQUFpQixTQUNsRyx1QkFBQyxjQUFXLFdBQVcsRUFBRWdCLElBQUksVUFBVUksSUFBSSxNQUFNLEdBQUcsVUFBUyxRQUFPLE1BQUssU0FBUSxjQUFXLG9CQUN4RjtBQUFBLGlDQUFDLGFBQVUsUUFBTSxNQUFDLE1BQUssU0FBUSxPQUFNLGNBQWEsT0FBT3hCLFVBQVUsSUFBSSxVQUFVLENBQUF5QixVQUFTZixhQUFhLFVBQVVlLE1BQU1DLE9BQU8zQixLQUFLLEdBQUcsSUFBSSxFQUFFNEIsTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDL0o7QUFBQSxtQ0FBQyxZQUFTLE9BQU0sSUFBRyxpQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQSxZQUFXLHVCQUFDLFlBQVMsT0FBTSxRQUFPLHVCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQVcsdUJBQUMsWUFBUyxPQUFNLFlBQVcsNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsZUFEcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxRQUFNLE1BQUMsTUFBSyxTQUFRLE9BQU0sVUFBUyxPQUFPL0IsUUFBUSxJQUFJLFVBQVUsQ0FBQTRCLFVBQVNmLGFBQWEsUUFBUWUsTUFBTUMsT0FBTzNCLEtBQUssR0FBRyxJQUFJLEVBQUU0QixNQUFNLEdBQUdDLFVBQVUsSUFBSSxHQUN2SjtBQUFBLG1DQUFDLFlBQVMsT0FBTSxJQUFHLDZCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQVcsdUJBQUMsWUFBUyxPQUFNLE9BQU0sbUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsWUFBVyx1QkFBQyxZQUFTLE9BQU0sU0FBUSx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUFXLHVCQUFDLFlBQVMsT0FBTSxVQUFTLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLGVBRGhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE1BQUssU0FBUSxPQUFNLFFBQU8sT0FBTzNCLGFBQWEsSUFBSSxVQUFVLENBQUF3QixVQUFTZixhQUFhLGFBQWFlLE1BQU1DLE9BQU8zQixLQUFLLEdBQUcsSUFBSSxFQUFFNEIsTUFBTSxHQUFHQyxVQUFVLElBQUksR0FDL0o7QUFBQSxtQ0FBQyxZQUFTLE9BQU0sSUFBRywyQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUFZdEIsU0FBU3VCLE1BQU1BLEtBQUtDLFNBQVNDLElBQUksQ0FBQUMsWUFBVyx1QkFBQyxZQUEwQixPQUFPQSxRQUFRZixJQUFLZSxrQkFBUUMsZUFBeENELFFBQVFmLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FLENBQVc7QUFBQSxlQUR4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLFFBQU0sTUFBQyxNQUFLLFNBQVEsT0FBTSxhQUFZLE9BQU9kLGtCQUFrQixJQUFJLFVBQVUsQ0FBQXNCLFVBQVNmLGFBQWEsa0JBQWtCZSxNQUFNQyxPQUFPM0IsS0FBSyxHQUFHLElBQUksRUFBRTRCLE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQzlLO0FBQUEsbUNBQUMsWUFBUyxPQUFNLElBQUcsZ0NBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsWUFBWXRCLFNBQVN1QixNQUFNQSxLQUFLSyxVQUFVSCxJQUFJLENBQUFJLGFBQVksdUJBQUMsWUFBK0IsT0FBT0EsU0FBU0MsUUFBU0QsbUJBQVNGLGVBQW5ERSxTQUFTQyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RSxDQUFXO0FBQUEsZUFEMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBLEtBZEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNjO0FBQUEsUUFDZCx1QkFBQyxjQUFXLE9BQU83QixNQUNmO0FBQUEsaUNBQUMsUUFBSyxnQkFBYyxNQUNmQSxlQUFLc0IsTUFBTUEsS0FBS0UsSUFBSSxDQUFBTSxNQUFLLHVCQUFDLFlBQW9CLGdCQUFjLE1BQ3pELGlDQUFDLGtCQUFlLFVBQVVBLEVBQUVwQixPQUFPM0IsZ0JBQWdCLFdBQVc1QyxZQUFZLElBQUlzRSxXQUFXcUIsRUFBRXBCLEVBQUUsR0FBRyxJQUFJLENBQUNqQyxTQUFTc0QsTUFBTUMsV0FBV3ZELFNBQVNzRCxNQUFNRSxnQkFBZ0IsRUFBRUMsWUFBWSxTQUFTQyxjQUFjLEdBQUdDLGFBQWEsVUFBVSxDQUFDLEdBQzFOO0FBQUEsbUNBQUMsVUFBTyxJQUFJLEVBQUVDLFNBQVNqRixPQUFPa0YsUUFBUUMsT0FBTyxnQkFBZ0JDLE9BQU8sSUFBSUMsUUFBUSxHQUFHLEdBQUlYLFlBQUVKLFlBQVlnQixNQUFNLEdBQUcsQ0FBQyxLQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSDtBQUFBLFlBQ2pILHVCQUFDLE9BQUksSUFBSSxFQUFFckIsVUFBVSxHQUFHRCxNQUFNLEVBQUUsR0FDNUI7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsT0FBTSxnQkFBZSxpQkFBZ0IsSUFBSSxDQUFDM0MsU0FBU2tFLFFBQVFDLG1CQUFtQixFQUFFVixZQUFZLFNBQVMsQ0FBQyxHQUNuSDtBQUFBLHVDQUFDLGNBQVcsWUFBWWpHLFNBQVM0RyxXQUFXQyxXQUFXQyxRQUFRLFFBQU0sTUFBRWpCLFlBQUVKLGVBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsZ0JBQ3BGSSxFQUFFa0IsY0FBYyxLQUFLLHVCQUFDLE9BQUksZUFBWSxzQkFBcUIsSUFBSSxDQUFDdkUsU0FBU3NELE1BQU1rQixrQkFBa0IsRUFBRVosU0FBUyxnQkFBZ0JFLE9BQU9uRixPQUFPOEYsVUFBVUMsY0FBY2xILFNBQVNtSCxPQUFPQyxPQUFPQyxVQUFVakcsT0FBT2tHLFVBQVVDLEtBQUssQ0FBQyxHQUFJMUIsWUFBRWtCLGVBQTNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVOO0FBQUEsbUJBRmpQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLGNBQVcsU0FBUSxTQUFRLFFBQU0sTUFBQyxPQUFNLGtCQUFpQixJQUFJLENBQUN2RSxTQUFTa0UsUUFBUWMscUJBQXFCLEVBQUV6QyxTQUFTLFFBQVEsQ0FBQyxHQUFJYyxZQUFFNEIsc0JBQXNCLHNCQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SztBQUFBLGNBQ3hLLHVCQUFDLE9BQUksSUFBSWpGLFNBQVNzRCxNQUFNNEIscUJBQXFCLGlDQUFDLFVBQU8sT0FBTzdCLEVBQUV4QyxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQixLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGlCQU4xRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWHFDd0MsRUFBRXBCLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWTFCLENBQVcsS0FiZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFDQyxDQUFDVixLQUFLc0IsTUFBTUEsS0FBS3NDLFVBQVUsdUJBQUMsU0FBTSxNQUFLLGdDQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFDcEUsdUJBQUMsU0FBTSxNQUFNNUQsS0FBS3NCLE1BQU11QyxNQUFNLGFBQWFoRSxtQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxhQWpCL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQ0E7QUFBQSxNQUNDZCxpQkFBaUIsdUJBQUMscUJBQXVDLGtCQUFoQkEsZ0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUUsSUFBTSx1QkFBQyxTQUFNLGlDQUFDLFNBQU0sTUFBSyxvRUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxTQXJDekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNDQTtBQUFBLE9BeENHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q1A7QUFDSjtBQUFDRCxHQTNFZUQsV0FBUztBQUFBLFVBQ016QyxXQUNWb0IsVUFDV25CLGlCQVNYaUIsUUFDSkEsTUFBTTtBQUFBO0FBQUEsS0FiUHVCO0FBNEVoQixTQUFTaUYsa0JBQWtCO0FBQUEsRUFBRS9FO0FBRTdCLEdBQUc7QUFBQWdGLE1BQUE7QUFDQyxRQUFNLEVBQUUvRSxLQUFLLElBQUl4QixTQUFTO0FBQzFCLFFBQU0sQ0FBQ3lCLE1BQU0sSUFBSTVDLGdCQUFnQjtBQUNqQyxRQUFNeUYsSUFBSXhFLE9BQU8sbUJBQW1CLEVBQUUwRyxNQUFNLEVBQUVqRixlQUFlLEVBQUUsQ0FBQztBQUNoRSxRQUFNa0YsZ0JBQWdCaEYsT0FBT0csSUFBSSxRQUFRLEtBQUtPO0FBQzlDLFFBQU11RSxXQUFXNUcsT0FBTyxnQkFBZ0IsRUFBRTBHLE1BQU0sRUFBRWpGLGVBQWUsR0FBR2tCLE9BQU8sRUFBRUgsUUFBUW1FLGVBQWUvRCxPQUFPLElBQUksRUFBRSxDQUFDO0FBQ2xILFFBQU1pRSxXQUFXNUcsV0FBVyx3QkFBd0IsQ0FBQyxtQkFBbUIsbUJBQW1CLENBQUM7QUFDNUYsUUFBTTZHLFVBQVU3RyxXQUFXLHVCQUF1QixDQUFDLG1CQUFtQixtQkFBbUIsQ0FBQztBQUMxRixRQUFNOEcsVUFBVTlHLFdBQVcsdUJBQXVCLENBQUMsbUJBQW1CLG1CQUFtQixDQUFDO0FBQzFGLFFBQU0rRyxXQUFXL0csV0FBVyxrQkFBa0IsQ0FBQyxjQUFjLENBQUM7QUFDOUQsUUFBTSxDQUFDZ0gsUUFBUUMsU0FBUyxJQUFJeEksU0FBb0QsSUFBSTtBQUNwRixRQUFNLENBQUN5SSxlQUFlQyxnQkFBZ0IsSUFBSTFJLFNBQXlCLElBQUk7QUFDdkUsUUFBTSxDQUFDMkksWUFBWUMsYUFBYSxJQUFJNUksU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzZJLFFBQVFDLFNBQVMsSUFBSTlJLFNBQWtDLFVBQVU7QUFDeEUsUUFBTStJLE1BQU1oSixPQUF1QixJQUFJO0FBRXZDRCxZQUFVLE1BQU07QUFDWixRQUFJLENBQUNtSSxjQUFlYyxLQUFJQyxTQUFTQyxlQUFlLEVBQUVDLE9BQU8sV0FBV0MsVUFBVSxPQUFPLENBQUM7QUFBQSxFQUMxRixHQUFHLENBQUNqQixTQUFTNUMsTUFBTTJDLGFBQWEsQ0FBQztBQUVqQyxRQUFNbUIsWUFBWUEsTUFBTTtBQUNwQixVQUFNL0UsT0FBTyxJQUFJQyxnQkFBZ0JyQixNQUFNO0FBQ3ZDLFVBQU0wQixhQUFhTixLQUFLakIsSUFBSSxZQUFZO0FBQ3hDaUIsU0FBS0csT0FBTyxZQUFZO0FBQ3hCSCxTQUFLRyxPQUFPLFFBQVE7QUFDcEIsUUFBSUcsV0FBWU4sTUFBS0UsSUFBSSxVQUFVSSxVQUFVO0FBQzdDLFVBQU1WLFFBQVFJLEtBQUtPLFNBQVM7QUFDNUIsV0FBTyxNQUFNNUIsS0FBSzBCLEVBQUUsU0FBU1QsUUFBUSxJQUFJQSxLQUFLLEtBQUssRUFBRTtBQUFBLEVBQ3pEO0FBRUEsUUFBTW9GLGVBQWV2RCxFQUFFUixNQUFNQTtBQUM3QixTQUNJLHVCQUFDLGNBQVcsT0FBT1EsR0FBRyxnQkFBZSxXQUNoQ3VELDBCQUNHLHVCQUFDLGVBQVksZUFBWSw2QkFBNEIsU0FBUyxFQUFFeEUsSUFBSSxPQUFPeUUsSUFBSSxzQkFBc0IsR0FBRyxVQUFVLEVBQUNqRSxVQUFVLEVBQUMsR0FDMUg7QUFBQSwyQkFBQyxPQUFJLGVBQVksZ0JBQWUsV0FBVSxXQUFVLGNBQVcsc0JBQXFCLElBQUksRUFBRUEsVUFBVSxHQUFHb0IsUUFBUSxFQUFFNkMsSUFBSSxJQUFJLEVBQUUsR0FDdkgsaUNBQUMsU0FBTSxVQUFVLEVBQUV0RSxTQUFTLFFBQVF1RSxlQUFlLFVBQVU5QyxRQUFRLE9BQU8sR0FDeEU7QUFBQSw2QkFBQyxlQUFZLFdBQVUsT0FBTSxZQUFXLFVBQVMsZ0JBQWUsaUJBQWdCLFVBQVMsVUFBUyxVQUFVLEVBQUVyQixNQUFNLFdBQVcsR0FDM0g7QUFBQSwrQkFBQyxTQUFNLFdBQVUsT0FBTSxZQUFXLFVBQVMsSUFBSSxDQUFDM0MsU0FBU2tFLFFBQVFDLG1CQUFtQixFQUFFNEMsVUFBVSxPQUFPLENBQUMsR0FDcEc7QUFBQSxpQ0FBQyxVQUFPLFdBQVdySixZQUFZLElBQUlpSixVQUFVLEdBQUcsSUFBSSxFQUFFcEUsU0FBUyxFQUFFRixJQUFJLE9BQU8sR0FBR08sVUFBVSxHQUFHLEdBQUcsY0FBVyx1QkFDdEcsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxJQUFJLEVBQUVnQixTQUFTakYsT0FBT3FJLFVBQVVsRCxPQUFPLGVBQWUsR0FBSThDLHVCQUFhM0QsWUFBWWdCLE1BQU0sR0FBRyxDQUFDLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVHO0FBQUEsVUFDdkcsdUJBQUMsT0FDRztBQUFBLG1DQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBTTJDLHVCQUFhM0QsZUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUMvQjJEO0FBQUFBLDJCQUFhL0YsU0FBUyxVQUFVLDZCQUE2QjtBQUFBLGNBQWlCO0FBQUEsY0FBSStGLGFBQWEzRTtBQUFBQSxpQkFEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxlQUFZLFdBQVUsT0FDbkI7QUFBQSxpQ0FBQyxrQkFBZSxZQUFXLHdCQUF1QixTQUFRLFlBQVcsU0FBUyxNQUFNOEQsVUFBVWEsYUFBYS9GLFNBQVMsVUFBVSxZQUFZLFVBQVUsR0FDL0krRix1QkFBYS9GLFNBQVMsVUFBVSxnQkFBZ0IsZUFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsVUFBVStGLGFBQWE1RixXQUFXLFlBQVksU0FBUyxNQUFNK0UsVUFBVSxTQUFTLEdBQUcsMEJBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUNDYSxhQUFhSyxnQkFBZ0JDLFVBQVUsYUFDcEMsdUJBQUMsT0FBSSxJQUFJbEgsU0FBU3NELE1BQU02RCxXQUNwQixpQ0FBQyxTQUFNLFVBQVMsV0FBVTtBQUFBO0FBQUEsUUFDRFAsYUFBYUssZ0JBQWdCRyxjQUFjO0FBQUEsUUFBMEI7QUFBQSxXQUQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVKLHVCQUFDLE9BQUksZUFBWSxzQkFBcUIsSUFBSSxDQUFDcEgsU0FBU3NELE1BQU02RCxXQUFXLEVBQUV4RSxNQUFNLEdBQUdMLFdBQVcsRUFBRUYsSUFBSSxLQUFLeUUsSUFBSSxNQUFNLEdBQUdRLFdBQVcsS0FBS0MsV0FBVyxRQUFRQyxZQUFZNUksT0FBTzZJLE9BQU8sQ0FBQyxHQUM3SyxpQ0FBQyxjQUFXLE9BQU8vQixVQUNmO0FBQUEsK0JBQUMsU0FBTSxlQUFZLHdCQUF1QixJQUFJekYsU0FBU3NELE1BQU1tRSxpQkFDekQ7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csVUFBVWhDLFNBQVM1QyxNQUFNQSxRQUFRO0FBQUEsY0FDakMsVUFBVXRDLEtBQUttSDtBQUFBQSxjQUNmLFFBQVEsQ0FBQUMsWUFBVztBQUNmMUIsaUNBQWlCMEIsT0FBTztBQUN4QnhCLDhCQUFjLEVBQUU7QUFBQSxjQUNwQjtBQUFBO0FBQUEsWUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNTTtBQUFBLFVBRU4sdUJBQUMsU0FBSSxLQUFLRyxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxhQVRsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNDLENBQUNiLFNBQVM1QyxNQUFNQSxLQUFLc0MsVUFBVSx1QkFBQyxTQUFNLE1BQUssdUJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQy9ELHVCQUFDLFNBQU0sTUFBTU0sU0FBUzVDLE1BQU11QyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FickM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBLEtBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BQ0EsdUJBQUMsd0JBQXFCLGdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsU0EvQ3JEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREEsS0FqREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtEQTtBQUFBLElBQ0EsdUJBQUMsNEJBQXlCLGNBQ3JCd0M7QUFBQUEsa0JBQVksdUJBQUMsd0JBQXFCLFlBQVloQixhQUFhaUIsWUFBWSxnQkFBZ0JqQixhQUFhM0UsTUFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRjtBQUFBLE1BQ3ZHMkYsWUFBWSx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsU0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTSxDQUFDLENBQUM5QjtBQUFBQSxRQUNSLE9BQU9BLFdBQVcsYUFBYSw4QkFBOEJBLFdBQVcsWUFBWSwrQkFBK0I7QUFBQSxRQUNuSCxjQUFjQSxXQUFXLGFBQWEsY0FBY0EsV0FBVyxZQUFZLGNBQWM7QUFBQSxRQUN6RixhQUFhLEdBQUdjLGFBQWEzRCxXQUFXLEtBQUszQyxjQUFjLE1BQU13RixXQUFXLGFBQWEsNkZBQTZGQSxXQUFXLFlBQVksZ0ZBQWdGLDhEQUE4RDtBQUFBLFFBQzNWO0FBQUEsUUFDQSxTQUFTLE1BQU1DLFVBQVUsSUFBSTtBQUFBLFFBQzdCLE1BQU1MLFNBQVNvQyxXQUFXbkMsUUFBUW1DLFdBQVdsQyxRQUFRa0M7QUFBQUEsUUFDckQsT0FBT3BDLFNBQVNxQyxTQUFTcEMsUUFBUW9DLFNBQVNuQyxRQUFRbUM7QUFBQUEsUUFDbEQsV0FBVyxDQUFBQyxXQUFVO0FBQ2pCLGdCQUFNQyxZQUFZbkMsV0FBVyxhQUFhSixXQUFXSSxXQUFXLFlBQVlILFVBQVVDO0FBQ3RGLGlCQUFPcUMsVUFBVUMsUUFBUTtBQUFBLFlBQ3JCM0MsTUFBTSxFQUFFakYsZUFBZTtBQUFBLFlBQ3ZCNkgsU0FBU3ZCLGFBQWF1QjtBQUFBQSxZQUN0QkMsTUFBTSxFQUFFQyxpQkFBaUJ6QixhQUFhdUIsU0FBU0gsT0FBTztBQUFBLFVBQzFELENBQUM7QUFBQSxRQUNMO0FBQUE7QUFBQSxNQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQk07QUFBQSxJQUVOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFNLENBQUMsQ0FBQ2hDO0FBQUFBLFFBQ1IsT0FBTTtBQUFBLFFBQ04sU0FBUyxNQUFNQyxpQkFBaUIsSUFBSTtBQUFBLFFBQ3BDLE1BQU1KLFNBQVNpQztBQUFBQSxRQUNmLFNBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFNBQVE7QUFBQSxZQUNSLFVBQVVqQyxTQUFTaUM7QUFBQUEsWUFDbkIsU0FBUyxZQUFZO0FBQ2pCLGtCQUFJLENBQUM5QixjQUFlO0FBQ3BCLGtCQUFJO0FBQ0Esc0JBQU1ILFNBQVNxQyxRQUFRLEVBQUVFLE1BQU0sRUFBRTlILGdCQUFnQmdJLFdBQVd0QyxjQUFjL0QsSUFBSW1FLFFBQVFGLFdBQVcsRUFBRSxDQUFDO0FBQ3BHRCxpQ0FBaUIsSUFBSTtBQUFBLGNBQ3pCLFFBQVE7QUFBQSxjQUNKO0FBQUEsWUFFUjtBQUFBLFlBQUU7QUFBQTtBQUFBLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBY0E7QUFBQSxRQUdKO0FBQUEsaUNBQUMsZUFBWSxPQUFPSixTQUFTa0MsU0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxVQUNuQyx1QkFBQyxjQUNHO0FBQUEsbUNBQUMsY0FBVyxJQUFJLEVBQUVRLFlBQVksV0FBVyxHQUFJdkMseUJBQWV3QyxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLGFBQVUsT0FBTSxZQUFXLFFBQU0sTUFBQyxPQUFPcEMsUUFBUSxVQUFVLENBQUEzRCxVQUFTNEQsVUFBVTVELE1BQU1DLE9BQU8zQixLQUFzQixHQUFHLFdBQVMsTUFDMUg7QUFBQSxxQ0FBQyxZQUFTLE9BQU0sWUFBVyx1QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUNsQyx1QkFBQyxZQUFTLE9BQU0sWUFBVyx1QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxpQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxPQUFNLHdCQUF1QixXQUFTLE1BQUMsU0FBUyxHQUFHLE9BQU9tRixZQUFZLFVBQVUsQ0FBQXpELFVBQVMwRCxjQUFjMUQsTUFBTUMsT0FBTzNCLEtBQUssS0FBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0k7QUFBQSxZQUN0SSx1QkFBQyxTQUFNLFVBQVMsUUFBTywrRkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0c7QUFBQSxlQVAxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUE7QUFBQTtBQUFBLE1BaENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlDQTtBQUFBLE9BM0dKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0R0EsS0E5R1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdIQTtBQUVSO0FBQUN1RSxJQXBKUUQsbUJBQWlCO0FBQUEsVUFHTHRHLFVBQ0FuQixpQkFDUGlCLFFBRU9BLFFBQ0FDLFlBQ0RBLFlBQ0FBLFlBQ0NBLFVBQVU7QUFBQTtBQUFBLE1BWHRCdUc7QUE0SlQsTUFBTW9ELHFCQUFxQjtBQUFBLEVBQ3ZCQyxTQUFTO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLFdBQVcsQ0FBQyw4Q0FBOEMsb0NBQW9DLGlEQUFpRDtBQUFBLElBQy9JQyxVQUFVO0FBQUEsRUFDZDtBQUFBLEVBQ0FDLFFBQVE7QUFBQSxJQUNKSCxPQUFPO0FBQUEsSUFDUEMsV0FBVyxDQUFDLDBDQUEwQyxrREFBa0QsZ0RBQWdEO0FBQUEsSUFDeEpDLFVBQVU7QUFBQSxFQUNkO0FBQUEsRUFDQUUsTUFBTTtBQUFBLElBQ0ZKLE9BQU87QUFBQSxJQUNQQyxXQUFXLENBQUMsK0NBQStDLHFEQUFxRCw2Q0FBNkM7QUFBQSxJQUM3SkMsVUFBVTtBQUFBLEVBQ2Q7QUFDSjtBQUVBLFNBQVNHLHFCQUFxQixFQUFFbkIsWUFBWXZILGVBQStELEdBQUc7QUFBQTJJLE1BQUE7QUFDMUcsUUFBTSxFQUFFMUksS0FBSyxJQUFJeEIsU0FBUztBQUMxQixRQUFNbUssaUJBQWlCbEssT0FBTyxjQUFjO0FBQzVDLFFBQU1tSyxtQkFBbUJuSyxPQUFPLGdCQUFnQjtBQUNoRCxRQUFNb0ssV0FBV3ZLLE9BQU8sZ0JBQWdCLEVBQUUyQyxPQUFPLEVBQUVDLE9BQU8sSUFBSSxFQUFFLEdBQUd5SCxjQUFjO0FBQ2pGLFFBQU1HLFFBQVF4SyxPQUFPLHNCQUFzQixFQUFFMkMsT0FBTyxFQUFFQyxPQUFPLElBQUksRUFBRSxHQUFHMEgsZ0JBQWdCO0FBQ3RGLFFBQU0sQ0FBQ0csS0FBS0MsTUFBTSxJQUFJaE0sU0FBMEIsUUFBUTtBQUN4RCxRQUFNLENBQUNpTSxVQUFVQyxXQUFXLElBQUlsTSxTQUEwQyxTQUFTO0FBQ25GLFFBQU1tTSxTQUFTakIsbUJBQW1CZSxRQUFRO0FBQzFDLFFBQU1HLGNBQWNQLFNBQVN2RyxNQUFNQSxRQUFRLElBQUkrRyxPQUFPLENBQUFDLFlBQVdBLFFBQVE3SSxXQUFXLFFBQVEsRUFDdkY4SSxRQUF3QixDQUFBRCxZQUFXQSxRQUFRRSxTQUFTSCxPQUFPLENBQUFJLFlBQVdBLFFBQVFDLFVBQVVELFFBQVFFLEtBQUssRUFDakdKLFFBQVEsQ0FBQUUsYUFBWVgsTUFBTXhHLE1BQU1BLFFBQVEsSUFBSStHLE9BQU8sQ0FBQU8sYUFBWUEsU0FBU0MsY0FBY0osUUFBUS9ILEVBQUUsRUFDNUZjLElBQUksQ0FBQW9ILGNBQWEsRUFBRXhJLEtBQUssR0FBR3FJLFFBQVEvSCxFQUFFLElBQUlrSSxTQUFTRSxXQUFXLElBQUlSLFNBQVNHLFNBQVNHLFNBQVMsRUFBRSxDQUFDLENBQUM7QUFFN0csU0FBTyx1QkFBQyxTQUFNLE9BQU0seUNBQXdDLFVBQVMsa0VBQWlFLFdBQVUsV0FBVSxVQUFTLFNBQy9KLGlDQUFDLGtCQUNHO0FBQUEsMkJBQUMsU0FBTSxVQUFTLFFBQU8sNkhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0k7QUFBQSxJQUNwSSx1QkFBQyxRQUFLLE9BQU9iLEtBQUssVUFBVSxDQUFDZ0IsR0FBR3ZKLFVBQTJCd0ksT0FBT3hJLEtBQUssR0FBRyxTQUFRLGNBQWEsZUFBYyxRQUFPLGNBQVcsZ0NBQzNIO0FBQUEsNkJBQUMsT0FBSSxPQUFNLFVBQVMsT0FBTSxjQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFDcEMsdUJBQUMsT0FBSSxPQUFNLFdBQVUsT0FBTSxlQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNDO0FBQUEsTUFDdEMsdUJBQUMsT0FBSSxPQUFNLFNBQVEsT0FBTSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMsT0FBSSxPQUFNLGdCQUFlLE9BQU0sY0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLFNBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0N1SSxRQUFRLFlBQVksdUJBQUMsa0JBQWdCLE1BQUssWUFBVyxjQUFXLHVCQUM3RDtBQUFBLDZCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sa0JBQWlCLE9BQU9FLFVBQVUsVUFBVSxDQUFBL0csVUFBU2dILFlBQVloSCxNQUFNQyxPQUFPM0IsS0FBd0MsR0FDekl3SixpQkFBT0MsUUFBUS9CLGtCQUFrQixFQUFFMUYsSUFBSSxDQUFDLENBQUNwQixLQUFLWixLQUFLLE1BQU0sdUJBQUMsWUFBbUIsT0FBT1ksS0FBTVosZ0JBQU00SCxTQUF4QmhILEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QyxDQUFXLEtBRHRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxhQUFZLDZCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDM0QrSCxPQUFPZCxVQUFVN0YsSUFBSSxDQUFDMEgsVUFBVUMsVUFBVSx1QkFBQyxjQUEwQixTQUFRLFNBQVNBO0FBQUFBLGdCQUFRO0FBQUEsUUFBRTtBQUFBLFFBQUdEO0FBQUFBLFdBQXhDQSxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFLENBQWE7QUFBQSxNQUMxSCx1QkFBQyxTQUFNLFVBQVMsV0FBVTtBQUFBO0FBQUEsUUFBZ0JmLE9BQU9iO0FBQUFBLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUMxRCx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQixnR0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxSTtBQUFBLFNBUHBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRckI7QUFBQSxJQUNDUyxRQUFRLGFBQWEsdUJBQUMsa0JBQWdCLE1BQUssWUFBVyxjQUFXLGtDQUM5RDtBQUFBLDZCQUFDLFNBQU0sVUFBUyxRQUFPLGlJQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdJO0FBQUEsTUFDdkksQ0FBQ0osa0JBQWtCLENBQUNDLG1CQUNmLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHFFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFLElBQy9FLHVCQUFDLGNBQVcsT0FBT0MsVUFBVSxnQkFBZSxXQUFXQSxtQkFBU3ZHLFFBQVEsdUJBQUMsY0FBVyxPQUFPd0csT0FBTyxnQkFBZSxXQUFXQSxnQkFBTXhHLFFBQVEsbUNBQzVJO0FBQUEsK0JBQUMsYUFBVSxPQUFNLGtDQUFpQyxNQUFNOEcsWUFBWSxRQUFRLENBQUFnQixRQUFPQSxJQUFJaEosS0FBSyxPQUFNLDZDQUE0QyxTQUFTO0FBQUEsVUFDbkosRUFBRUEsS0FBSyxXQUFXZ0gsT0FBTyxZQUFZaUMsUUFBUUEsQ0FBQUQsUUFBT0EsSUFBSWQsUUFBUWdCLEtBQUs7QUFBQSxVQUNyRSxFQUFFbEosS0FBSyxPQUFPZ0gsT0FBTyxPQUFPaUMsUUFBUUEsQ0FBQUQsUUFBT0EsSUFBSVgsUUFBUWMsSUFBSTtBQUFBLFVBQzNELEVBQUVuSixLQUFLLFNBQVNnSCxPQUFPLE9BQU9vQyxPQUFPLFNBQVNILFFBQVFBLENBQUFELFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJWCxRQUFRRSxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQyxFQUFJO0FBQUEsVUFDbEcsRUFBRXZJLEtBQUssYUFBYWdILE9BQU8sY0FBY29DLE9BQU8sU0FBU0gsUUFBUUEsQ0FBQUQsUUFBT0EsSUFBSVIsU0FBU2EsVUFBVTtBQUFBLFVBQy9GLEVBQUVySixLQUFLLFFBQVFnSCxPQUFPLGdCQUFnQmlDLFFBQVFBLENBQUFELFFBQU8xTCxTQUFTMEwsSUFBSVIsU0FBU2MsTUFBTTFLLEtBQUttSCxRQUFRLEVBQUU7QUFBQSxRQUFDLEtBTHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNRTtBQUFBLFFBQ0YsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsc0dBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkk7QUFBQSxRQUMzSSx1QkFBQyxlQUFZLFdBQVUsT0FBTSxTQUFRLGVBQWM7QUFBQSxpQ0FBQyxhQUFVLElBQUksTUFBTW5ILEtBQUswQixFQUFFLGFBQWEscUNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsVUFBWSx1QkFBQyxhQUFVLElBQUksTUFBTTFCLEtBQUswQixFQUFFLGNBQWMsb0NBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsYUFBM0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TTtBQUFBLFdBVDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVNUksS0FWMEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVV0RSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVZ0I7QUFBQSxTQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FldEI7QUFBQSxJQUNDcUgsUUFBUSxXQUFXLHVCQUFDLGtCQUFnQixNQUFLLFlBQVcsY0FBVyx3QkFDNUQ7QUFBQSw2QkFBQyxjQUFXLFNBQVEsU0FBUSxvR0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnSDtBQUFBLE1BQ2hILHVCQUFDLGFBQVUsSUFBSSxNQUFNL0ksS0FBSzBCLEVBQUUsMEJBQTBCNEYsVUFBVSxtQkFBbUJ2SCxjQUFjLElBQUksZ0RBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUk7QUFBQSxNQUNySSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxnR0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RztBQUFBLFNBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJcEI7QUFBQSxJQUNDZ0osUUFBUSxrQkFBa0IsdUJBQUMsa0JBQWdCLE1BQUssWUFBVyxjQUFXLDBCQUNuRTtBQUFBLDZCQUFDLFNBQU0sVUFBUyxXQUFVLCtLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlMO0FBQUEsTUFDekwsdUJBQUMsVUFBTyxTQUFRLFlBQVcsVUFBUSxNQUFDLHFEQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFDekUsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsK0ZBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0k7QUFBQSxTQUg3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSTNCO0FBQUEsT0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQSxLQTVDRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNQO0FBQ0o7QUFBQ0wsSUE1RFFELHNCQUFvQjtBQUFBLFVBQ1JqSyxVQUNNQyxRQUNFQSxRQUNSSCxRQUNIQSxNQUFNO0FBQUE7QUFBQSxNQUxmbUs7QUE4RFQsU0FBU2tDLG9CQUFvQjtBQUFBQyxNQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJOU4sU0FBUyxLQUFLO0FBQ3RDLFNBQU8sdUJBQUMsa0JBQWUsV0FBVSxXQUM3QjtBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsYUFBWSxpREFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRjtBQUFBLElBQ2hGLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDRJQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1KO0FBQUEsSUFDbkosdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUSxZQUFXLFNBQVMsTUFBTThOLFFBQVEsQ0FBQXRLLFVBQVMsQ0FBQ0EsS0FBSyxHQUFJcUssaUJBQU8scUJBQXFCLDZCQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdJO0FBQUEsSUFDdklBLFFBQVEsdUJBQUMsU0FBTSxNQUFLLFVBQVMsZUFBWSwwQkFBeUIsSUFBSSxDQUFDcEwsU0FBU2tFLFFBQVFDLG1CQUFtQm5FLFNBQVNrRSxRQUFRb0gsY0FBYyxFQUFFQyxRQUFRLEdBQUc1SCxhQUFhLFdBQVdlLGNBQWNsSCxTQUFTbUgsT0FBTzZHLFFBQVEsQ0FBQyxHQUNuTjtBQUFBLDZCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsYUFBWSx5Q0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLGNBQVcsU0FBUSxTQUFRLHFGQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlHO0FBQUEsTUFDakcsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIsNkZBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0k7QUFBQSxTQUg3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSVQ7QUFBQSxPQVJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTUDtBQUNKO0FBQUNMLElBWlFELG1CQUFpQjtBQUFBLE1BQWpCQTtBQUFpQixJQUFBTyxJQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFILElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJBY3Rpb25Hcm91cCIsIkZpZWxkR3JvdXAiLCJGb3JtRmllbGRzIiwiU2VjdGlvbkdyaWQiLCJTdXJmYWNlQ29udGVudCIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJMaW5rIiwiUm91dGVyTGluayIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQXZhdGFyIiwiQm94IiwiQnV0dG9uIiwiTGlzdCIsIkxpc3RJdGVtIiwiTGlzdEl0ZW1CdXR0b24iLCJNZW51SXRlbSIsIlN0YWNrIiwiVGFiIiwiVGFicyIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJBcnJvd0JhY2tSb3VuZGVkIiwiY29sb3JzIiwidG9rZW5zIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlQ2FuIiwiZGF0ZVRpbWUiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJRdWVyeVN0YXRlIiwiVG9vbGJhciIsIlBhZ2VyIiwiU3RhdHVzIiwiTXV0YXRpb25CdXR0b24iLCJFZGl0RGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJDb25maXJtRGlhbG9nIiwiUm91dGVMaW5rIiwiRW1wdHkiLCJEYXRhVGFibGUiLCJBbW91bnQiLCJsYXlvdXRTeCIsIkNvbnZlcnNhdGlvbkNvbXBvc2VyIiwiQ29udmVyc2F0aW9uQ29udGV4dFBhbmVsIiwiQ29udmVyc2F0aW9uTWVzc2FnZUxpc3QiLCJJbmJveFBhZ2UiLCJfcyIsImNvbnZlcnNhdGlvbklkIiwic2hvcCIsInBhcmFtcyIsInNldFBhcmFtcyIsInEiLCJnZXQiLCJyYXdNb2RlIiwibW9kZSIsImZpbmQiLCJ2YWx1ZSIsInN0YXR1cyIsImNoYW5uZWxJZCIsInVuZGVmaW5lZCIsImFzc2lnbmVkVXNlcklkIiwibGlzdEN1cnNvclBhcmFtIiwiY3Vyc29yIiwibWV0YWRhdGEiLCJsaXN0IiwicXVlcnkiLCJsaW1pdCIsInVwZGF0ZUZpbHRlciIsImtleSIsIm5leHQiLCJVUkxTZWFyY2hQYXJhbXMiLCJzZXQiLCJkZWxldGUiLCJkZXRhaWxIcmVmIiwiaWQiLCJsaXN0Q3Vyc29yIiwidG9TdHJpbmciLCJ4cyIsImxnIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsInNtIiwiZXZlbnQiLCJ0YXJnZXQiLCJmbGV4IiwibWluV2lkdGgiLCJkYXRhIiwiY2hhbm5lbHMiLCJtYXAiLCJjaGFubmVsIiwiZGlzcGxheU5hbWUiLCJhc3NpZ25lZXMiLCJhc3NpZ25lZSIsInVzZXJJZCIsImMiLCJpbmJveCIsImxpc3RJbnNldCIsImxpc3RDb250ZW50R2FwIiwiYWxpZ25JdGVtcyIsImJvcmRlckJvdHRvbSIsImJvcmRlckNvbG9yIiwiYmdjb2xvciIsInJhaXNlZCIsImNvbG9yIiwid2lkdGgiLCJoZWlnaHQiLCJzbGljZSIsInN1cmZhY2UiLCJjb21wYWN0Q29udGVudEdhcCIsInR5cG9ncmFwaHkiLCJmb250V2VpZ2h0Iiwic3Ryb25nIiwidW5yZWFkQ291bnQiLCJ1bnJlYWRDb3VudEluc2V0Iiwib25BY2NlbnQiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJsYXJnZSIsImZvbnRTaXplIiwiZm9udFNpemVzIiwibWV0YSIsInRpdGxlRGVzY3JpcHRpb25HYXAiLCJsYXN0TWVzc2FnZVByZXZpZXciLCJsaXN0U3RhdHVzQmVmb3JlR2FwIiwibGVuZ3RoIiwicGFnZSIsIkNvbnZlcnNhdGlvblBhbmVsIiwiX3MyIiwicGF0aCIsIm1lc3NhZ2VDdXJzb3IiLCJtZXNzYWdlcyIsInRha2VvdmVyIiwicmVsZWFzZSIsInJlc29sdmUiLCJmZWVkYmFjayIsImFjdGlvbiIsInNldEFjdGlvbiIsInJhdGluZ01lc3NhZ2UiLCJzZXRSYXRpbmdNZXNzYWdlIiwiY29ycmVjdGlvbiIsInNldENvcnJlY3Rpb24iLCJyYXRpbmciLCJzZXRSYXRpbmciLCJlbmQiLCJjdXJyZW50Iiwic2Nyb2xsSW50b1ZpZXciLCJibG9jayIsImJlaGF2aW9yIiwiaW5ib3hIcmVmIiwiY29udmVyc2F0aW9uIiwieGwiLCJmbGV4RGlyZWN0aW9uIiwiZmxleFdyYXAiLCJzZWxlY3RlZCIsInNlbmRFbGlnaWJpbGl0eSIsInN0YXRlIiwicGFuZUluc2V0IiwicmVhc29uQ29kZSIsIm1heEhlaWdodCIsIm92ZXJmbG93WSIsImJhY2tncm91bmQiLCJjYW52YXMiLCJtZXNzYWdlR3JvdXBHYXAiLCJ0aW1lem9uZSIsIm1lc3NhZ2UiLCJfX01PQ0tfXyIsImN1c3RvbWVySWQiLCJwZW5kaW5nIiwiZXJyb3IiLCJyZWFzb24iLCJvcGVyYXRpb24iLCJleGVjdXRlIiwidmVyc2lvbiIsImJvZHkiLCJleHBlY3RlZFZlcnNpb24iLCJtZXNzYWdlSWQiLCJ3aGl0ZVNwYWNlIiwidGV4dCIsInNhbXBsZVNhbGVzU2NyaXB0cyIsImZhc2hpb24iLCJsYWJlbCIsInF1ZXN0aW9ucyIsImJvdW5kYXJ5IiwiYmVhdXR5IiwiaG9tZSIsIk1vY2tTYWxlc0Zsb3dQcmV2aWV3IiwiX3MzIiwiY2FuUmVhZENhdGFsb2ciLCJjYW5SZWFkSW52ZW50b3J5IiwicHJvZHVjdHMiLCJzdG9jayIsInRhYiIsInNldFRhYiIsImluZHVzdHJ5Iiwic2V0SW5kdXN0cnkiLCJzY3JpcHQiLCJzb3VyY2VSb3dzIiwiZmlsdGVyIiwicHJvZHVjdCIsImZsYXRNYXAiLCJ2YXJpYW50cyIsInZhcmlhbnQiLCJhY3RpdmUiLCJwcmljZSIsInNuYXBzaG90IiwidmFyaWFudElkIiwid2FyZWhvdXNlSWQiLCJfIiwiT2JqZWN0IiwiZW50cmllcyIsInF1ZXN0aW9uIiwiaW5kZXgiLCJyb3ciLCJyZW5kZXIiLCJuYW1lIiwic2t1IiwiYWxpZ24iLCJhdmFpbGFibGUiLCJhc09mIiwiTW9ja1Vwc2VsbFByZXZpZXciLCJfczQiLCJvcGVuIiwic2V0T3BlbiIsImNvbXBhY3RJbnNldCIsImJvcmRlciIsImNvbnRyb2wiLCJfYyIsIl9jMiIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZpZWxkR3JvdXAsIEZvcm1GaWVsZHMsIFNlY3Rpb25HcmlkLCBTdXJmYWNlQ29udGVudCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQgeyBMaW5rIGFzIFJvdXRlckxpbmssIHVzZVBhcmFtcywgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEFsZXJ0LCBBdmF0YXIsIEJveCwgQnV0dG9uLCBMaXN0LCBMaXN0SXRlbSwgTGlzdEl0ZW1CdXR0b24sIE1lbnVJdGVtLCBTdGFjaywgVGFiLCBUYWJzLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcclxuaW1wb3J0IEFycm93QmFja1JvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd0JhY2tSb3VuZGVkJztcclxuaW1wb3J0IHR5cGUgeyBNZXNzYWdlLCBQcm9kdWN0LCBTdG9ja1NuYXBzaG90IH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7IGNvbG9ycywgdG9rZW5zIH0gZnJvbSAnQGJvdHNhbGVzL3Rva2Vucyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZVNjb3BlLCB1c2VDYW4gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgUGFnZUhlYWRlciwgUGFuZWwsIFF1ZXJ5U3RhdGUsIFRvb2xiYXIsIFBhZ2VyLCBTdGF0dXMsIE11dGF0aW9uQnV0dG9uLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgQ29uZmlybURpYWxvZywgUm91dGVMaW5rLCBFbXB0eSwgRGF0YVRhYmxlLCBBbW91bnQgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcclxuaW1wb3J0IHsgbGF5b3V0U3ggfSBmcm9tICdAL3NoYXJlZC91aS9sYXlvdXQnO1xyXG5pbXBvcnQgeyBDb252ZXJzYXRpb25Db21wb3NlciwgQ29udmVyc2F0aW9uQ29udGV4dFBhbmVsLCBDb252ZXJzYXRpb25NZXNzYWdlTGlzdCB9IGZyb20gJy4vY29udmVyc2F0aW9uLWNvbXBvbmVudHMnO1xyXG5leHBvcnQgZnVuY3Rpb24gSW5ib3hQYWdlKCkge1xyXG4gICAgY29uc3QgeyBjb252ZXJzYXRpb25JZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBbcGFyYW1zLCBzZXRQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XHJcbiAgICBjb25zdCBxID0gcGFyYW1zLmdldCgncScpIHx8ICcnO1xyXG4gICAgY29uc3QgcmF3TW9kZSA9IHBhcmFtcy5nZXQoJ21vZGUnKTtcclxuICAgIGNvbnN0IG1vZGUgPSAoWydib3QnLCAnaHVtYW4nLCAncGF1c2VkJ10gYXMgY29uc3QpLmZpbmQodmFsdWUgPT4gdmFsdWUgPT09IHJhd01vZGUpO1xyXG4gICAgY29uc3Qgc3RhdHVzID0gKFsnb3BlbicsICdyZXNvbHZlZCddIGFzIGNvbnN0KS5maW5kKHZhbHVlID0+IHZhbHVlID09PSBwYXJhbXMuZ2V0KCdzdGF0dXMnKSk7XHJcbiAgICBjb25zdCBjaGFubmVsSWQgPSBwYXJhbXMuZ2V0KCdjaGFubmVsSWQnKSB8fCB1bmRlZmluZWQ7XHJcbiAgICBjb25zdCBhc3NpZ25lZFVzZXJJZCA9IHBhcmFtcy5nZXQoJ2Fzc2lnbmVkVXNlcklkJykgfHwgdW5kZWZpbmVkO1xyXG4gICAgY29uc3QgbGlzdEN1cnNvclBhcmFtID0gY29udmVyc2F0aW9uSWQgPyAnbGlzdEN1cnNvcicgOiAnY3Vyc29yJztcclxuICAgIGNvbnN0IGN1cnNvciA9IHBhcmFtcy5nZXQobGlzdEN1cnNvclBhcmFtKSB8fCB1bmRlZmluZWQ7XHJcbiAgICBjb25zdCBtZXRhZGF0YSA9IHVzZUFwaSgnZ2V0SW5ib3hNZXRhZGF0YScpO1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdENvbnZlcnNhdGlvbnMnLCB7IHF1ZXJ5OiB7IHE6IHEgfHwgdW5kZWZpbmVkLCBzdGF0dXMsIG1vZGUsIGNoYW5uZWxJZCwgYXNzaWduZWRVc2VySWQsIGN1cnNvciwgbGltaXQ6IDQwIH0gfSk7XHJcbiAgICBjb25zdCB1cGRhdGVGaWx0ZXIgPSAoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpO1xyXG4gICAgICAgIGlmICh2YWx1ZSlcclxuICAgICAgICAgICAgbmV4dC5zZXQoa2V5LCB2YWx1ZSk7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICBuZXh0LmRlbGV0ZShrZXkpO1xyXG4gICAgICAgIG5leHQuZGVsZXRlKGxpc3RDdXJzb3JQYXJhbSk7XHJcbiAgICAgICAgc2V0UGFyYW1zKG5leHQpO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IGRldGFpbEhyZWYgPSAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7XHJcbiAgICAgICAgY29uc3QgbGlzdEN1cnNvciA9IG5leHQuZ2V0KGxpc3RDdXJzb3JQYXJhbSk7XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2N1cnNvcicpO1xyXG4gICAgICAgIG5leHQuZGVsZXRlKCdsaXN0Q3Vyc29yJyk7XHJcbiAgICAgICAgaWYgKGxpc3RDdXJzb3IpXHJcbiAgICAgICAgICAgIG5leHQuc2V0KCdsaXN0Q3Vyc29yJywgbGlzdEN1cnNvcik7XHJcbiAgICAgICAgY29uc3QgcXVlcnkgPSBuZXh0LnRvU3RyaW5nKCk7XHJcbiAgICAgICAgcmV0dXJuIGAvcy8ke3Nob3AuaWR9L2luYm94LyR7aWR9JHtxdWVyeSA/IGA/JHtxdWVyeX1gIDogJyd9YDtcclxuICAgIH07XHJcbiAgICByZXR1cm4gPD5cclxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkjhu5lwIHRoxrAga2jDoWNoIGjDoG5nXCIgc3VidGl0bGU9XCJBSSB2w6AgbmjDom4gdmnDqm4gdGnhur9wIHF14bqjbiByw7UgcsOgbmc7IGNo4buJIGfhu61pIGtoaSBjaMOtbmggc8OhY2gga8OqbmggY2hvIHBow6lwLlwiIC8+XHJcbiAgICAgICAgPFNlY3Rpb25HcmlkIGNvbHVtbnM9e3sgeHM6ICcxZnInLCBsZzogJzMwMHB4IG1pbm1heCgwLDFmciknIH19IGdlb21ldHJ5PXt7bWluSGVpZ2h0OiA2NTB9fT5cclxuICAgICAgICAgICAgPFBhbmVsIGdlb21ldHJ5PXt7IGRpc3BsYXk6IHsgeHM6IGNvbnZlcnNhdGlvbklkID8gJ25vbmUnIDogJ2Jsb2NrJywgbGc6ICdibG9jaycgfSB9fT5cclxuICAgICAgICAgICAgICAgIDxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RDb252ZXJzYXRpb25zXCIgcGxhY2Vob2xkZXI9XCJUw6xtIGjhu5lpIHRob+G6oWnigKZcIiBjdXJzb3JQYXJhbT17bGlzdEN1cnNvclBhcmFtfSBmaWx0ZXJzPXtcclxuICAgICAgICAgICAgICAgIDxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBmbGV4V3JhcD1cIndyYXBcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQuG7mSBs4buNYyBo4buZaSB0aG/huqFpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3Qgc2l6ZT1cInNtYWxsXCIgbGFiZWw9XCJUcuG6oW5nIHRow6FpXCIgdmFsdWU9e3N0YXR1cyB8fCAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHVwZGF0ZUZpbHRlcignc3RhdHVzJywgZXZlbnQudGFyZ2V0LnZhbHVlKX0gc3g9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwiXCI+VOG6pXQgY+G6oyB0cuG6oW5nIHRow6FpPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJvcGVuXCI+xJBhbmcgbeG7nzwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwicmVzb2x2ZWRcIj7EkMOjIGdp4bqjaSBxdXnhur90PC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBzaXplPVwic21hbGxcIiBsYWJlbD1cIkNo4bq/IMSR4buZXCIgdmFsdWU9e21vZGUgfHwgJyd9IG9uQ2hhbmdlPXtldmVudCA9PiB1cGRhdGVGaWx0ZXIoJ21vZGUnLCBldmVudC50YXJnZXQudmFsdWUpfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTQwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJcIj5U4bqldCBj4bqjIGNo4bq/IMSR4buZPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJib3RcIj5Cb3Q8L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cImh1bWFuXCI+TmjDom4gdmnDqm48L01lbnVJdGVtPjxNZW51SXRlbSB2YWx1ZT1cInBhdXNlZFwiPlThuqFtIGThu6tuZzwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3Qgc2l6ZT1cInNtYWxsXCIgbGFiZWw9XCJLw6puaFwiIHZhbHVlPXtjaGFubmVsSWQgfHwgJyd9IG9uQ2hhbmdlPXtldmVudCA9PiB1cGRhdGVGaWx0ZXIoJ2NoYW5uZWxJZCcsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAxNjAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPlThuqV0IGPhuqMga8Oqbmg8L01lbnVJdGVtPnttZXRhZGF0YS5kYXRhPy5kYXRhLmNoYW5uZWxzLm1hcChjaGFubmVsID0+IDxNZW51SXRlbSBrZXk9e2NoYW5uZWwuaWR9IHZhbHVlPXtjaGFubmVsLmlkfT57Y2hhbm5lbC5kaXNwbGF5TmFtZX08L01lbnVJdGVtPil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3Qgc2l6ZT1cInNtYWxsXCIgbGFiZWw9XCJOaMOibiB2acOqblwiIHZhbHVlPXthc3NpZ25lZFVzZXJJZCB8fCAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHVwZGF0ZUZpbHRlcignYXNzaWduZWRVc2VySWQnLCBldmVudC50YXJnZXQudmFsdWUpfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMTYwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJcIj5U4bqldCBj4bqjIG5ow6JuIHZpw6puPC9NZW51SXRlbT57bWV0YWRhdGEuZGF0YT8uZGF0YS5hc3NpZ25lZXMubWFwKGFzc2lnbmVlID0+IDxNZW51SXRlbSBrZXk9e2Fzc2lnbmVlLnVzZXJJZH0gdmFsdWU9e2Fzc2lnbmVlLnVzZXJJZH0+e2Fzc2lnbmVlLmRpc3BsYXlOYW1lfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgIDwvRmllbGRHcm91cD59IC8+XHJcbiAgICAgICAgICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpc3QgZGlzYWJsZVBhZGRpbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaXN0LmRhdGE/LmRhdGEubWFwKGMgPT4gPExpc3RJdGVtIGtleT17Yy5pZH0gZGlzYWJsZVBhZGRpbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlzdEl0ZW1CdXR0b24gc2VsZWN0ZWQ9e2MuaWQgPT09IGNvbnZlcnNhdGlvbklkfSBjb21wb25lbnQ9e1JvdXRlckxpbmt9IHRvPXtkZXRhaWxIcmVmKGMuaWQpfSBzeD17W2xheW91dFN4LmluYm94Lmxpc3RJbnNldCwgbGF5b3V0U3guaW5ib3gubGlzdENvbnRlbnRHYXAsIHsgYWxpZ25JdGVtczogJ3N0YXJ0JywgYm9yZGVyQm90dG9tOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIHN4PXt7IGJnY29sb3I6IGNvbG9ycy5yYWlzZWQsIGNvbG9yOiAndGV4dC5wcmltYXJ5Jywgd2lkdGg6IDM4LCBoZWlnaHQ6IDM4IH19PntjLmRpc3BsYXlOYW1lLnNsaWNlKDAsIDEpfTwvQXZhdGFyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggc3g9e3sgbWluV2lkdGg6IDAsIGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiBzeD17W2xheW91dFN4LnN1cmZhY2UuY29tcGFjdENvbnRlbnRHYXAsIHsgYWxpZ25JdGVtczogJ2NlbnRlcicgfV19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30gbm9XcmFwPntjLmRpc3BsYXlOYW1lfTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjLnVucmVhZENvdW50ID4gMCAmJiA8Qm94IGRhdGEtdGVzdGlkPVwiaW5ib3gtdW5yZWFkLWNvdW50XCIgc3g9e1tsYXlvdXRTeC5pbmJveC51bnJlYWRDb3VudEluc2V0LCB7IGJnY29sb3I6ICdwcmltYXJ5Lm1haW4nLCBjb2xvcjogY29sb3JzLm9uQWNjZW50LCBib3JkZXJSYWRpdXM6IHZpc3VhbFN4LnJhZGl1cy5sYXJnZSwgZm9udFNpemU6IHRva2Vucy5mb250U2l6ZXMubWV0YSB9XX0+e2MudW5yZWFkQ291bnR9PC9Cb3g+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBub1dyYXAgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtbbGF5b3V0U3guc3VyZmFjZS50aXRsZURlc2NyaXB0aW9uR2FwLCB7IGRpc3BsYXk6ICdibG9jaycgfV19PntjLmxhc3RNZXNzYWdlUHJldmlldyB8fCAnQ2jGsGEgY8OzIHRpbiBuaOG6r24nfTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBzeD17bGF5b3V0U3guaW5ib3gubGlzdFN0YXR1c0JlZm9yZUdhcH0+PFN0YXR1cyB2YWx1ZT17Yy5tb2RlfSAvPjwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaXN0SXRlbUJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaXN0SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGlzdD5cclxuICAgICAgICAgICAgICAgICAgICB7IWxpc3QuZGF0YT8uZGF0YS5sZW5ndGggJiYgPEVtcHR5IHRleHQ9XCJDaMawYSBjw7MgaOG7mWkgdGhv4bqhaSBwaMO5IGjhu6NwLlwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlciBwYWdlPXtsaXN0LmRhdGE/LnBhZ2V9IGN1cnNvclBhcmFtPXtsaXN0Q3Vyc29yUGFyYW19IC8+XHJcbiAgICAgICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+XHJcbiAgICAgICAgICAgIDwvUGFuZWw+XHJcbiAgICAgICAgICAgIHtjb252ZXJzYXRpb25JZCA/IDxDb252ZXJzYXRpb25QYW5lbCBrZXk9e2NvbnZlcnNhdGlvbklkfSBjb252ZXJzYXRpb25JZD17Y29udmVyc2F0aW9uSWR9IC8+IDogPFBhbmVsPjxFbXB0eSB0ZXh0PVwiQ2jhu41uIG3hu5l0IGN14buZYyB0csOyIGNodXnhu4duIMSR4buDIHhlbSBs4buLY2ggc+G7rSwgdGnhur9wIHF14bqjbiB2w6AgdOG6oW8gxJHGoW4uXCIgLz48L1BhbmVsPn1cclxuICAgICAgICA8L1NlY3Rpb25HcmlkPlxyXG4gICAgPC8+O1xyXG59XHJcbmZ1bmN0aW9uIENvbnZlcnNhdGlvblBhbmVsKHsgY29udmVyc2F0aW9uSWQgfToge1xyXG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcclxufSkge1xyXG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICAgIGNvbnN0IGMgPSB1c2VBcGkoJ2dldENvbnZlcnNhdGlvbicsIHsgcGF0aDogeyBjb252ZXJzYXRpb25JZCB9IH0pO1xyXG4gICAgY29uc3QgbWVzc2FnZUN1cnNvciA9IHBhcmFtcy5nZXQoJ2N1cnNvcicpIHx8IHVuZGVmaW5lZDtcclxuICAgIGNvbnN0IG1lc3NhZ2VzID0gdXNlQXBpKCdsaXN0TWVzc2FnZXMnLCB7IHBhdGg6IHsgY29udmVyc2F0aW9uSWQgfSwgcXVlcnk6IHsgY3Vyc29yOiBtZXNzYWdlQ3Vyc29yLCBsaW1pdDogMTAwIH0gfSk7XHJcbiAgICBjb25zdCB0YWtlb3ZlciA9IHVzZUNvbW1hbmQoJ3Rha2VvdmVyQ29udmVyc2F0aW9uJywgWydnZXRDb252ZXJzYXRpb24nLCAnbGlzdENvbnZlcnNhdGlvbnMnXSk7XHJcbiAgICBjb25zdCByZWxlYXNlID0gdXNlQ29tbWFuZCgncmVsZWFzZUNvbnZlcnNhdGlvbicsIFsnZ2V0Q29udmVyc2F0aW9uJywgJ2xpc3RDb252ZXJzYXRpb25zJ10pO1xyXG4gICAgY29uc3QgcmVzb2x2ZSA9IHVzZUNvbW1hbmQoJ3Jlc29sdmVDb252ZXJzYXRpb24nLCBbJ2dldENvbnZlcnNhdGlvbicsICdsaXN0Q29udmVyc2F0aW9ucyddKTtcclxuICAgIGNvbnN0IGZlZWRiYWNrID0gdXNlQ29tbWFuZCgnY3JlYXRlRmVlZGJhY2snLCBbJ2xpc3RGZWVkYmFjayddKTtcclxuICAgIGNvbnN0IFthY3Rpb24sIHNldEFjdGlvbl0gPSB1c2VTdGF0ZTwndGFrZW92ZXInIHwgJ3JlbGVhc2UnIHwgJ3Jlc29sdmUnIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbcmF0aW5nTWVzc2FnZSwgc2V0UmF0aW5nTWVzc2FnZV0gPSB1c2VTdGF0ZTxNZXNzYWdlIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbY29ycmVjdGlvbiwgc2V0Q29ycmVjdGlvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbcmF0aW5nLCBzZXRSYXRpbmddID0gdXNlU3RhdGU8J3Bvc2l0aXZlJyB8ICduZWdhdGl2ZSc+KCduZWdhdGl2ZScpO1xyXG4gICAgY29uc3QgZW5kID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICghbWVzc2FnZUN1cnNvcikgZW5kLmN1cnJlbnQ/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6ICduZWFyZXN0JywgYmVoYXZpb3I6ICdhdXRvJyB9KTtcclxuICAgIH0sIFttZXNzYWdlcy5kYXRhLCBtZXNzYWdlQ3Vyc29yXSk7XHJcblxyXG4gICAgY29uc3QgaW5ib3hIcmVmID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7XHJcbiAgICAgICAgY29uc3QgbGlzdEN1cnNvciA9IG5leHQuZ2V0KCdsaXN0Q3Vyc29yJyk7XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2xpc3RDdXJzb3InKTtcclxuICAgICAgICBuZXh0LmRlbGV0ZSgnY3Vyc29yJyk7XHJcbiAgICAgICAgaWYgKGxpc3RDdXJzb3IpIG5leHQuc2V0KCdjdXJzb3InLCBsaXN0Q3Vyc29yKTtcclxuICAgICAgICBjb25zdCBxdWVyeSA9IG5leHQudG9TdHJpbmcoKTtcclxuICAgICAgICByZXR1cm4gYC9zLyR7c2hvcC5pZH0vaW5ib3gke3F1ZXJ5ID8gYD8ke3F1ZXJ5fWAgOiAnJ31gO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBjb252ZXJzYXRpb24gPSBjLmRhdGE/LmRhdGE7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtjfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAge2NvbnZlcnNhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U2VjdGlvbkdyaWQgZGF0YS10ZXN0aWQ9XCJpbmJveC1jb252ZXJzYXRpb24tbGF5b3V0XCIgY29sdW1ucz17eyB4czogJzFmcicsIHhsOiAnbWlubWF4KDAsMWZyKSAyNjBweCcgfX0gZ2VvbWV0cnk9e3ttaW5XaWR0aDogMH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGF0YS10ZXN0aWQ9XCJpbmJveC10aHJlYWRcIiBjb21wb25lbnQ9XCJzZWN0aW9uXCIgYXJpYS1sYWJlbD1cIk7hu5lpIGR1bmcgaOG7mWkgdGhv4bqhaVwiIHN4PXt7IG1pbldpZHRoOiAwLCBoZWlnaHQ6IHsgeGw6IDY1MCB9IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFuZWwgZ2VvbWV0cnk9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgaGVpZ2h0OiAnMTAwJScgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIGJvZHlNb2RlPVwiaGVhZGVyXCIgZ2VvbWV0cnk9e3sgZmxleDogJzAgMCBhdXRvJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIHN4PXtbbGF5b3V0U3guc3VyZmFjZS5jb21wYWN0Q29udGVudEdhcCwgeyBmbGV4V3JhcDogJ3dyYXAnIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBjb21wb25lbnQ9e1JvdXRlckxpbmt9IHRvPXtpbmJveEhyZWYoKX0gc3g9e3sgZGlzcGxheTogeyBsZzogJ25vbmUnIH0sIG1pbldpZHRoOiA0NCB9fSBhcmlhLWxhYmVsPVwiRGFuaCBzw6FjaCBo4buZaSB0aG/huqFpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dCYWNrUm91bmRlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBzeD17eyBiZ2NvbG9yOiBjb2xvcnMuc2VsZWN0ZWQsIGNvbG9yOiAncHJpbWFyeS5tYWluJyB9fT57Y29udmVyc2F0aW9uLmRpc3BsYXlOYW1lLnNsaWNlKDAsIDEpfTwvQXZhdGFyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIj57Y29udmVyc2F0aW9uLmRpc3BsYXlOYW1lfTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb252ZXJzYXRpb24ubW9kZSA9PT0gJ2h1bWFuJyA/ICdOaMOibiB2acOqbiDEkWFuZyB0aeG6v3AgcXXhuqNuJyA6ICdUcuG7oyBsw70gdOG7sSDEkeG7mW5nJ30gwrcge2NvbnZlcnNhdGlvbi5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImNvbnZlcnNhdGlvbnMuYXNzaWduXCIgdmFyaWFudD1cIm91dGxpbmVkXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aW9uKGNvbnZlcnNhdGlvbi5tb2RlID09PSAnaHVtYW4nID8gJ3JlbGVhc2UnIDogJ3Rha2VvdmVyJyl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbnZlcnNhdGlvbi5tb2RlID09PSAnaHVtYW4nID8gJ1Ry4bqjIGzhuqFpIGJvdCcgOiAnVGnhur9wIHF14bqjbid9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiY29udmVyc2F0aW9ucy5hc3NpZ25cIiBkaXNhYmxlZD17Y29udmVyc2F0aW9uLnN0YXR1cyA9PT0gJ3Jlc29sdmVkJ30gb25DbGljaz17KCkgPT4gc2V0QWN0aW9uKCdyZXNvbHZlJyl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2nhuqNpIHF1eeG6v3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9NdXRhdGlvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0FjdGlvbkdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9BY3Rpb25Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb252ZXJzYXRpb24uc2VuZEVsaWdpYmlsaXR5LnN0YXRlICE9PSAnYWxsb3dlZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggc3g9e2xheW91dFN4LmluYm94LnBhbmVJbnNldH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEtow7RuZyDEkcaw4bujYyBn4butaSB0aW46IHtjb252ZXJzYXRpb24uc2VuZEVsaWdpYmlsaXR5LnJlYXNvbkNvZGUgfHwgJ0NoxrBhIHjDoWMgbWluaCBxdXnhu4FuIGfhu61pJ30uIEtow7RuZyB04buxIHbGsOG7o3QgY+G7rWEgc+G7lS9jaMOtbmggc8OhY2gga8OqbmguXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkYXRhLXRlc3RpZD1cImluYm94LW1lc3NhZ2UtbGlzdFwiIHN4PXtbbGF5b3V0U3guaW5ib3gucGFuZUluc2V0LCB7IGZsZXg6IDEsIG1pbkhlaWdodDogeyB4czogMzUwLCB4bDogJzZlbScgfSwgbWF4SGVpZ2h0OiA1NTAsIG92ZXJmbG93WTogJ2F1dG8nLCBiYWNrZ3JvdW5kOiBjb2xvcnMuY2FudmFzIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17bWVzc2FnZXN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgZGF0YS10ZXN0aWQ9XCJpbmJveC1tZXNzYWdlLWdyb3Vwc1wiIHN4PXtsYXlvdXRTeC5pbmJveC5tZXNzYWdlR3JvdXBHYXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbnZlcnNhdGlvbk1lc3NhZ2VMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXM9e21lc3NhZ2VzLmRhdGE/LmRhdGEgfHwgW119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZXpvbmU9e3Nob3AudGltZXpvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25SYXRlPXttZXNzYWdlID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UmF0aW5nTWVzc2FnZShtZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29ycmVjdGlvbignJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHJlZj17ZW5kfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IW1lc3NhZ2VzLmRhdGE/LmRhdGEubGVuZ3RoICYmIDxFbXB0eSB0ZXh0PVwiQ2jGsGEgY8OzIHRpbiBuaOG6r24uXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdlciBwYWdlPXttZXNzYWdlcy5kYXRhPy5wYWdlfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbnZlcnNhdGlvbkNvbXBvc2VyIGNvbnZlcnNhdGlvbj17Y29udmVyc2F0aW9ufSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb252ZXJzYXRpb25Db250ZXh0UGFuZWwgY29udmVyc2F0aW9uPXtjb252ZXJzYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7X19NT0NLX18gJiYgPE1vY2tTYWxlc0Zsb3dQcmV2aWV3IGN1c3RvbWVySWQ9e2NvbnZlcnNhdGlvbi5jdXN0b21lcklkfSBjb252ZXJzYXRpb25JZD17Y29udmVyc2F0aW9uLmlkfSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAge19fTU9DS19fICYmIDxNb2NrVXBzZWxsUHJldmlldyAvPn1cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbnZlcnNhdGlvbkNvbnRleHRQYW5lbD5cclxuICAgICAgICAgICAgICAgICAgICA8Q29uZmlybURpYWxvZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGVuPXshIWFjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2FjdGlvbiA9PT0gJ3Rha2VvdmVyJyA/ICdUaeG6v3AgcXXhuqNuIGN14buZYyB0csOyIGNodXnhu4duJyA6IGFjdGlvbiA9PT0gJ3JlbGVhc2UnID8gJ1Ry4bqjIGN14buZYyB0csOyIGNodXnhu4duIHbhu4EgYm90JyA6ICfEkMOhbmggZOG6pXUgxJHDoyBnaeG6o2kgcXV54bq/dCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpcm1MYWJlbD17YWN0aW9uID09PSAndGFrZW92ZXInID8gJ1Rp4bq/cCBxdeG6o24nIDogYWN0aW9uID09PSAncmVsZWFzZScgPyAnVHLhuqMgduG7gSBBSScgOiAnxJDDoW5oIGThuqV1IMSRw6MgZ2nhuqNpIHF1eeG6v3QnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj17YCR7Y29udmVyc2F0aW9uLmRpc3BsYXlOYW1lfSAoJHtjb252ZXJzYXRpb25JZH0pOiAke2FjdGlvbiA9PT0gJ3Rha2VvdmVyJyA/ICdjaHV54buDbiB0csOhY2ggbmhp4buHbSB0cuG6oyBs4budaSBzYW5nIG5ow6JuIHZpw6puIHbDoCBjaOG6t24gY8OidSB0cuG6oyBs4budaSBBSSDEkWFuZyBjaOG7nSB0csaw4bubYyBraGkgZ+G7rWkuJyA6IGFjdGlvbiA9PT0gJ3JlbGVhc2UnID8gJ3Ry4bqjIHRyw6FjaCBuaGnhu4dtIHRy4bqjIGzhu51pIHbhu4EgQUkgc2F1IGtoaSBraeG7g20gcXV54buBbiB2w6AgxJFp4buBdSBraeG7h24gZ+G7rWkgaGnhu4duIHThuqFpLicgOiAnxJHDoW5oIGThuqV1IGjhu5lpIHRob+G6oWkgxJHDoyBnaeG6o2kgcXV54bq/dDsgbOG7i2NoIHPhu60gdGluIG5o4bqvbiDEkcaw4bujYyBnaeG7ry4nfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVSZWFzb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWN0aW9uKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBidXN5PXt0YWtlb3Zlci5wZW5kaW5nIHx8IHJlbGVhc2UucGVuZGluZyB8fCByZXNvbHZlLnBlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXt0YWtlb3Zlci5lcnJvciB8fCByZWxlYXNlLmVycm9yIHx8IHJlc29sdmUuZXJyb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17cmVhc29uID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9IGFjdGlvbiA9PT0gJ3Rha2VvdmVyJyA/IHRha2VvdmVyIDogYWN0aW9uID09PSAncmVsZWFzZScgPyByZWxlYXNlIDogcmVzb2x2ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcGVyYXRpb24uZXhlY3V0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogeyBjb252ZXJzYXRpb25JZCB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZlcnNpb246IGNvbnZlcnNhdGlvbi52ZXJzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBjb252ZXJzYXRpb24udmVyc2lvbiwgcmVhc29uIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxFZGl0RGlhbG9nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wZW49eyEhcmF0aW5nTWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCLEkMOhbmggZ2nDoSBjw6J1IHRy4bqjIGzhu51pXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UmF0aW5nTWVzc2FnZShudWxsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYnVzeT17ZmVlZGJhY2sucGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9ucz17KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtmZWVkYmFjay5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyYXRpbmdNZXNzYWdlKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBmZWVkYmFjay5leGVjdXRlKHsgYm9keTogeyBjb252ZXJzYXRpb25JZCwgbWVzc2FnZUlkOiByYXRpbmdNZXNzYWdlLmlkLCByYXRpbmcsIGNvcnJlY3Rpb24gfSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJhdGluZ01lc3NhZ2UobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVGhlIHZpc2libGUgZXJyb3IgcmVtYWlucyBhdmFpbGFibGUgZm9yIHJldHJ5LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMxrB1IHBo4bqjbiBo4buTaVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2ZlZWRiYWNrLmVycm9yfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBzeD17eyB3aGl0ZVNwYWNlOiAncHJlLXdyYXAnIH19PntyYXRpbmdNZXNzYWdlPy50ZXh0fTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCLEkMOhbmggZ2nDoVwiIHNlbGVjdCB2YWx1ZT17cmF0aW5nfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmF0aW5nKGV2ZW50LnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgcmF0aW5nKX0gYXV0b0ZvY3VzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cInBvc2l0aXZlXCI+SOG7r3Ugw61jaDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwibmVnYXRpdmVcIj5D4bqnbiBz4butYTwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJO4buZaSBkdW5nIMSR4buBIHh14bqldCBz4butYVwiIG11bHRpbGluZSBtaW5Sb3dzPXs0fSB2YWx1ZT17Y29ycmVjdGlvbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldENvcnJlY3Rpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5QaOG6o24gaOG7k2kga2jDtG5nIHThu7EgdHLhu58gdGjDoG5oIGtp4bq/biB0aOG7qWMgxJHDoyB4deG6pXQgYuG6o24uIEPhuqduIG5nxrDhu51pIGR1eeG7h3QgdsOgIGtp4buDbSB0aOG7rS48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgICAgICAgICAgICAgPC9TZWN0aW9uR3JpZD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L1F1ZXJ5U3RhdGU+XHJcbiAgICApO1xyXG59XHJcbnR5cGUgU2FsZXNQcmV2aWV3VGFiID0gJ3NjcmlwdCcgfCAnc291cmNlcycgfCAnb3JkZXInIHwgJ2NvbmZpcm1hdGlvbic7XHJcbnR5cGUgU2FsZXNTb3VyY2VSb3cgPSB7XHJcbiAgICBrZXk6IHN0cmluZztcclxuICAgIHByb2R1Y3Q6IFByb2R1Y3Q7XHJcbiAgICB2YXJpYW50OiBQcm9kdWN0Wyd2YXJpYW50cyddW251bWJlcl07XHJcbiAgICBzbmFwc2hvdDogU3RvY2tTbmFwc2hvdDtcclxufTtcclxuY29uc3Qgc2FtcGxlU2FsZXNTY3JpcHRzID0ge1xyXG4gICAgZmFzaGlvbjoge1xyXG4gICAgICAgIGxhYmVsOiAnVGjhu51pIHRyYW5nJyxcclxuICAgICAgICBxdWVzdGlvbnM6IFsnQuG6oW4gxJFhbmcgdMOsbSBraeG7g3UgZMOhbmcgdsOgIGThu4twIHPhu60gZOG7pW5nIG7DoG8/JywgJ0LhuqFuIG114buRbiB4ZW0gbcOgdSB2w6Aga8OtY2ggY+G7oSBuw6BvPycsICdDaG8gbcOsbmggeGluIGtodSB24buxYyBnaWFvIGjDoG5nIMSR4buDIGtp4buDbSB0cmEgcGjDrS4nXSxcclxuICAgICAgICBib3VuZGFyeTogJ0No4buJIHTGsCB24bqlbiBjaOG6pXQgbGnhu4d1LCBrw61jaCBj4buhIHbDoCBjaMOtbmggc8OhY2ggxJHDoyBjw7Mgbmd14buTbjsgdGhp4bq/dSB0aMO0bmcgdGluIHRow6wgaOG7j2kgbOG6oWkgaG/hurdjIGNodXnhu4NuIG5ow6JuIHZpw6puLicsXHJcbiAgICB9LFxyXG4gICAgYmVhdXR5OiB7XHJcbiAgICAgICAgbGFiZWw6ICdN4bu5IHBo4bqpbScsXHJcbiAgICAgICAgcXVlc3Rpb25zOiBbJ0LhuqFuIMSRYW5nIHTDrG0gc+G6o24gcGjhuqltIGNobyBuaHUgY+G6p3UgbsOgbz8nLCAnQuG6oW4gY8OzIGThu4sg4bupbmcgaG/hurdjIHRow6BuaCBwaOG6p24gY+G6p24gdHLDoW5oIGtow7RuZz8nLCAnQuG6oW4gbXXhu5FuIG5ow6JuIHZpw6puIHTGsCB24bqlbiB0aMOqbSB0csaw4bubYyBraGkgY2jhu41uPyddLFxyXG4gICAgICAgIGJvdW5kYXJ5OiAnS2jDtG5nIGNo4bqpbiDEkW/DoW4sIGjhu6lhIGhp4buHdSBxdeG6oyDEkWnhu4F1IHRy4buLIGhv4bq3YyBraOG6s25nIMSR4buLbmggcGjDuSBo4bujcCBraGkgY2jGsGEgY8OzIHRow7RuZyB0aW4gbmd14buTbi4nLFxyXG4gICAgfSxcclxuICAgIGhvbWU6IHtcclxuICAgICAgICBsYWJlbDogJ0dpYSBk4bulbmcnLFxyXG4gICAgICAgIHF1ZXN0aW9uczogWydC4bqhbiBj4bqnbiBkw7luZyBz4bqjbiBwaOG6qW0gdHJvbmcga2jDtG5nIGdpYW4gbsOgbz8nLCAnS8OtY2ggdGjGsOG7m2MgaG/hurdjIGPDtG5nIHN14bqldCBtb25nIG114buRbiBsw6AgYmFvIG5oacOqdT8nLCAnQuG6oW4gY+G6p24ga2nhu4NtIHRyYSBi4bqjbyBow6BuaCBoYXkgY8OhY2ggbOG6r3AgxJHhurd0PyddLFxyXG4gICAgICAgIGJvdW5kYXJ5OiAnVGhp4bq/dSBrw61jaCB0aMaw4bubYywgYuG6o28gaMOgbmggaG/hurdjIGjGsOG7m25nIGThuqtuIGPDsyBuZ3Xhu5NuIHRow6wga2jDtG5nIHThu7Egc3V5IGRp4buFbjsgY2h1eeG7g24gbmjDom4gdmnDqm4geMOhYyBtaW5oLicsXHJcbiAgICB9LFxyXG59IGFzIGNvbnN0O1xyXG5cclxuZnVuY3Rpb24gTW9ja1NhbGVzRmxvd1ByZXZpZXcoeyBjdXN0b21lcklkLCBjb252ZXJzYXRpb25JZCB9OiB7IGN1c3RvbWVySWQ6IHN0cmluZzsgY29udmVyc2F0aW9uSWQ6IHN0cmluZyB9KSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBjYW5SZWFkQ2F0YWxvZyA9IHVzZUNhbignY2F0YWxvZy5yZWFkJyk7XHJcbiAgICBjb25zdCBjYW5SZWFkSW52ZW50b3J5ID0gdXNlQ2FuKCdpbnZlbnRvcnkucmVhZCcpO1xyXG4gICAgY29uc3QgcHJvZHVjdHMgPSB1c2VBcGkoJ2xpc3RQcm9kdWN0cycsIHsgcXVlcnk6IHsgbGltaXQ6IDEwMCB9IH0sIGNhblJlYWRDYXRhbG9nKTtcclxuICAgIGNvbnN0IHN0b2NrID0gdXNlQXBpKCdsaXN0U3RvY2tTbmFwc2hvdHMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAxMDAgfSB9LCBjYW5SZWFkSW52ZW50b3J5KTtcclxuICAgIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZTxTYWxlc1ByZXZpZXdUYWI+KCdzY3JpcHQnKTtcclxuICAgIGNvbnN0IFtpbmR1c3RyeSwgc2V0SW5kdXN0cnldID0gdXNlU3RhdGU8a2V5b2YgdHlwZW9mIHNhbXBsZVNhbGVzU2NyaXB0cz4oJ2Zhc2hpb24nKTtcclxuICAgIGNvbnN0IHNjcmlwdCA9IHNhbXBsZVNhbGVzU2NyaXB0c1tpbmR1c3RyeV07XHJcbiAgICBjb25zdCBzb3VyY2VSb3dzID0gKHByb2R1Y3RzLmRhdGE/LmRhdGEgfHwgW10pLmZpbHRlcihwcm9kdWN0ID0+IHByb2R1Y3Quc3RhdHVzID09PSAnYWN0aXZlJylcclxuICAgICAgICAuZmxhdE1hcDxTYWxlc1NvdXJjZVJvdz4ocHJvZHVjdCA9PiBwcm9kdWN0LnZhcmlhbnRzLmZpbHRlcih2YXJpYW50ID0+IHZhcmlhbnQuYWN0aXZlICYmIHZhcmlhbnQucHJpY2UpXHJcbiAgICAgICAgICAgIC5mbGF0TWFwKHZhcmlhbnQgPT4gKHN0b2NrLmRhdGE/LmRhdGEgfHwgW10pLmZpbHRlcihzbmFwc2hvdCA9PiBzbmFwc2hvdC52YXJpYW50SWQgPT09IHZhcmlhbnQuaWQpXHJcbiAgICAgICAgICAgICAgICAubWFwKHNuYXBzaG90ID0+ICh7IGtleTogYCR7dmFyaWFudC5pZH06JHtzbmFwc2hvdC53YXJlaG91c2VJZH1gLCBwcm9kdWN0LCB2YXJpYW50LCBzbmFwc2hvdCB9KSkpKTtcclxuXHJcbiAgICByZXR1cm4gPFBhbmVsIHRpdGxlPVwiTHXhu5NuZyB0xrAgduG6pW4gYsOhbiBow6BuZyDCtyBi4bqjbiB4ZW0gdHLGsOG7m2NcIiBzdWJ0aXRsZT1cIk3huqt1IHTGsMahbmcgdMOhYyBj4bulYyBi4buZOyBraMO0bmcgZ+G7jWkgQUkgdsOgIGtow7RuZyBn4butaSB0aW4gY2hvIGtow6FjaC5cIiBiZWZvcmVHYXA9XCJzdXJmYWNlXCIgYm9keU1vZGU9XCJpbnNldFwiPlxyXG4gICAgICAgIDxTdXJmYWNlQ29udGVudCA+XHJcbiAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5O4buZaSBkdW5nIGTGsOG7m2kgxJHDonkgY2jhu4kgbWluaCBo4buNYSBnaWFvIGRp4buHbi4gQuG6o24gZGVtbyBraMO0bmcgdOG7sSB04bqhbyBjw6J1IHRy4bqjIGzhu51pIEFJIGhv4bq3YyBsxrB1IGvhu4tjaCBi4bqjbiBsw6puIG3DoXkgY2jhu6cuPC9BbGVydD5cclxuICAgICAgICAgICAgPFRhYnMgdmFsdWU9e3RhYn0gb25DaGFuZ2U9eyhfLCB2YWx1ZTogU2FsZXNQcmV2aWV3VGFiKSA9PiBzZXRUYWIodmFsdWUpfSB2YXJpYW50PVwic2Nyb2xsYWJsZVwiIHNjcm9sbEJ1dHRvbnM9XCJhdXRvXCIgYXJpYS1sYWJlbD1cIkPDoWMgYsaw4bubYyB0xrAgduG6pW4gYsOhbiBow6BuZyBt4bqrdVwiPlxyXG4gICAgICAgICAgICAgICAgPFRhYiB2YWx1ZT1cInNjcmlwdFwiIGxhYmVsPVwiS+G7i2NoIGLhuqNuXCIgLz5cclxuICAgICAgICAgICAgICAgIDxUYWIgdmFsdWU9XCJzb3VyY2VzXCIgbGFiZWw9XCJHacOhICYgdOG7k25cIiAvPlxyXG4gICAgICAgICAgICAgICAgPFRhYiB2YWx1ZT1cIm9yZGVyXCIgbGFiZWw9XCJU4bqhbyDEkcahblwiIC8+XHJcbiAgICAgICAgICAgICAgICA8VGFiIHZhbHVlPVwiY29uZmlybWF0aW9uXCIgbGFiZWw9XCJYw6FjIG5o4bqtblwiIC8+XHJcbiAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgICAge3RhYiA9PT0gJ3NjcmlwdCcgJiYgPFN1cmZhY2VDb250ZW50ICByb2xlPVwidGFicGFuZWxcIiBhcmlhLWxhYmVsPVwiS+G7i2NoIGLhuqNuIHTGsCB24bqlbiBt4bqrdVwiPlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJOZ8OgbmggaMOgbmcgbeG6q3VcIiB2YWx1ZT17aW5kdXN0cnl9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRJbmR1c3RyeShldmVudC50YXJnZXQudmFsdWUgYXMga2V5b2YgdHlwZW9mIHNhbXBsZVNhbGVzU2NyaXB0cyl9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhzYW1wbGVTYWxlc1NjcmlwdHMpLm1hcCgoW2tleSwgdmFsdWVdKSA9PiA8TWVudUl0ZW0ga2V5PXtrZXl9IHZhbHVlPXtrZXl9Pnt2YWx1ZS5sYWJlbH08L01lbnVJdGVtPil9XHJcbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgzXCIgdmFyaWFudD1cInN1YnRpdGxlMlwiPkPDonUgaOG7j2kgZ+G7o2kgw708L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICB7c2NyaXB0LnF1ZXN0aW9ucy5tYXAoKHF1ZXN0aW9uLCBpbmRleCkgPT4gPFR5cG9ncmFwaHkga2V5PXtxdWVzdGlvbn0gdmFyaWFudD1cImJvZHkyXCI+e2luZGV4ICsgMX0uIHtxdWVzdGlvbn08L1R5cG9ncmFwaHk+KX1cclxuICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5SYW5oIGdp4bubaSBt4bqrdToge3NjcmlwdC5ib3VuZGFyeX08L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+QuG6o24gbmjDoXAgbeG6q3UgcmnDqm5nIHbhu5tpIGPhuqV1IGjDrG5oIGJvdCDEkWFuZyBkw7luZzsga2jDtG5nIGPDsyB0aGFvIHTDoWMgeHXhuqV0IGLhuqNuIOG7nyDEkcOieS48L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvU3VyZmFjZUNvbnRlbnQ+fVxyXG4gICAgICAgICAgICB7dGFiID09PSAnc291cmNlcycgJiYgPFN1cmZhY2VDb250ZW50ICByb2xlPVwidGFicGFuZWxcIiBhcmlhLWxhYmVsPVwiTmd14buTbiBnacOhIHbDoCB04buTbiB0cm9uZyBo4buZcCB0aMawXCI+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+R2nDoSBs4bqleSB04burIGNhdGFsb2cgdsOgIHThu5NuIHThu6sgc25hcHNob3QgY8OzIHRo4budaSDEkWnhu4NtLiBE4buvIGxp4buHdSBjaOG7iSBsw6AgbW9jazsgY+G6p24gdHJ1eSB24bqlbiBs4bqhaSB0csaw4bubYyBraGkgeMOhYyBuaOG6rW4gxJHGoW4uPC9BbGVydD5cclxuICAgICAgICAgICAgICAgIHshY2FuUmVhZENhdGFsb2cgfHwgIWNhblJlYWRJbnZlbnRvcnlcclxuICAgICAgICAgICAgICAgICAgICA/IDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5D4bqnbiBxdXnhu4FuIHhlbSBz4bqjbiBwaOG6qW0gdsOgIHThu5NuIGtobyDEkeG7gyDEkeG7kWkgY2hp4bq/dSBuZ3Xhu5NuLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgOiA8UXVlcnlTdGF0ZSBxdWVyeT17cHJvZHVjdHN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntwcm9kdWN0cy5kYXRhICYmIDxRdWVyeVN0YXRlIHF1ZXJ5PXtzdG9ja30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e3N0b2NrLmRhdGEgJiYgPD5cclxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiTmd14buTbiBnacOhIHbDoCB04buTbiB0cm9uZyBo4buZcCB0aMawXCIgcm93cz17c291cmNlUm93c30gcm93S2V5PXtyb3cgPT4gcm93LmtleX0gZW1wdHk9XCJDaMawYSBjw7Mgc+G6o24gcGjhuqltIMSR4bunIGThu68gbGnhu4d1IMSR4buDIMSR4buRaSBjaGnhur91LlwiIGNvbHVtbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwcm9kdWN0JywgbGFiZWw6ICdT4bqjbiBwaOG6qW0nLCByZW5kZXI6IHJvdyA9PiByb3cucHJvZHVjdC5uYW1lIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnc2t1JywgbGFiZWw6ICdTS1UnLCByZW5kZXI6IHJvdyA9PiByb3cudmFyaWFudC5za3UgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwcmljZScsIGxhYmVsOiAnR2nDoScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHJvdyA9PiA8QW1vdW50IHZhbHVlPXtyb3cudmFyaWFudC5wcmljZX0gLz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhdmFpbGFibGUnLCBsYWJlbDogJ0PDsyB0aOG7gyBiw6FuJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcm93ID0+IHJvdy5zbmFwc2hvdC5hdmFpbGFibGUgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhc09mJywgbGFiZWw6ICdTbmFwc2hvdCBsw7pjJywgcmVuZGVyOiByb3cgPT4gZGF0ZVRpbWUocm93LnNuYXBzaG90LmFzT2YsIHNob3AudGltZXpvbmUpIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5QcmV2aWV3IGdp4bubaSBo4bqhbiDhu58gMTAwIHPhuqNuIHBo4bqpbSB2w6AgMTAwIHNuYXBzaG90IMSR4bqndSB0acOqbjsga2jDtG5nIHBo4bqjaSBkYW5oIHPDoWNoIMSR4bqneSDEkeG7py48L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiIGRlbnNpdHk9XCJjb21mb3J0YWJsZVwiPjxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L3Byb2R1Y3RzYH0+TeG7nyBkYW5oIHPDoWNoIHPhuqNuIHBo4bqpbTwvUm91dGVMaW5rPjxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ludmVudG9yeWB9Pk3hu58gZGFuaCBzw6FjaCB04buTbiBraG88L1JvdXRlTGluaz48L0FjdGlvbkdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPn08L1F1ZXJ5U3RhdGU+fTwvUXVlcnlTdGF0ZT59XHJcbiAgICAgICAgICAgIDwvU3VyZmFjZUNvbnRlbnQ+fVxyXG4gICAgICAgICAgICB7dGFiID09PSAnb3JkZXInICYmIDxTdXJmYWNlQ29udGVudCAgcm9sZT1cInRhYnBhbmVsXCIgYXJpYS1sYWJlbD1cIlThuqFvIMSRxqFuIHThu6sgaOG7mWkgdGhv4bqhaVwiPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+Q2h1eeG7g24gc2FuZyBiaeG7g3UgbeG6q3UgxJHGoW4gxJHhu4MgbmjDom4gdmnDqm4ga2nhu4NtIHRyYSBraMOhY2gsIHPhuqNuIHBo4bqpbSwgc+G7kSBsxrDhu6NuZyB2w6AgYsOhbyBnacOhLjwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy9uZXc/Y3VzdG9tZXJJZD0ke2N1c3RvbWVySWR9JmNvbnZlcnNhdGlvbklkPSR7Y29udmVyc2F0aW9uSWR9YH0+TeG7nyBiaeG7g3UgbeG6q3UgdOG6oW8gxJHGoW4gdOG7qyBo4buZaSB0aG/huqFpPC9Sb3V0ZUxpbms+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+xJDGoW4gdHJvbmcgZGVtbyDEkcaw4bujYyBsxrB1IHbDoG8gTVNXIGPhu6VjIGLhu5kgY+G7p2EgdGFiOyDEkcOieSBraMO0bmcgcGjhuqNpIMSRxqFuIHRyw6puIG3DoXkgY2jhu6cuPC9BbGVydD5cclxuICAgICAgICAgICAgPC9TdXJmYWNlQ29udGVudD59XHJcbiAgICAgICAgICAgIHt0YWIgPT09ICdjb25maXJtYXRpb24nICYmIDxTdXJmYWNlQ29udGVudCAgcm9sZT1cInRhYnBhbmVsXCIgYXJpYS1sYWJlbD1cIsSQaeG7gXUga2nhu4duIHjDoWMgbmjhuq1uIMSRxqFuXCI+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+S2jDtG5nIHThu7EgY2jhu5F0IMSRxqFuIHRyb25nIGdpYW8gZGnhu4duIG7DoHkuIELhurFuZyBjaOG7qW5nIHjDoWMgbmjhuq1uIGPhu6dhIGtow6FjaCwgYsOhbyBnacOhIGhp4buHbiBow6BuaCB2w6AgxJFp4buBdSBraeG7h24gZ2lhbyBuaOG6rW4gcGjhuqNpIMSRxrDhu6NjIGtp4buDbSB0cmEgdHLGsOG7m2Mga2hpIG5ow6JuIHZpw6puIHjDoWMgbmjhuq1uLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGRpc2FibGVkPlThu7EgxJHhu5luZyB4w6FjIG5o4bqtbiDEkcahbiBjaMawYSDEkcaw4bujYyBo4buXIHRy4bujPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5D4bqnbiBi4buVIHN1bmcgY2FwYWJpbGl0eSB2w6AgcG9saWN5IHRyb25nIGNvbnRyYWN0IHRyxrDhu5tjIGtoaSBi4bqtdCB04buxIMSR4buZbmcgeMOhYyBuaOG6rW4uPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8L1N1cmZhY2VDb250ZW50Pn1cclxuICAgICAgICA8L1N1cmZhY2VDb250ZW50PlxyXG4gICAgPC9QYW5lbD47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE1vY2tVcHNlbGxQcmV2aWV3KCkge1xyXG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgcmV0dXJuIDxTdXJmYWNlQ29udGVudCBiZWZvcmVHYXA9XCJzdXJmYWNlXCI+XHJcbiAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDNcIiB2YXJpYW50PVwic3VidGl0bGUyXCI+R+G7o2kgw70gYsOhbiBrw6htIG3huqt1IMK3IERFTU8tUFJPTU8tMDE8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkNvbWJvIMOhbyB0aHVuICsgdMO6aSB0b3RlIGNo4buJIG1pbmggaOG7jWEgZ2lhbyBkaeG7h24uIEtow7RuZyBjw7MgQVBJIGtodXnhur9uIG3huqFpOyBnacOhLCBs4bujaSBuaHXhuq1uLCBTS1UgdsOgIHThu5NuIGtobyBjaMawYSDEkcaw4bujYyB4w6FjIHRo4buxYy48L0FsZXJ0PlxyXG4gICAgICAgIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgdmFyaWFudD1cIm91dGxpbmVkXCIgb25DbGljaz17KCkgPT4gc2V0T3Blbih2YWx1ZSA9PiAhdmFsdWUpfT57b3BlbiA/ICfhuqhuIMSRaeG7gXUga2nhu4duIG3huqt1JyA6ICdYZW0gxJFp4buBdSBraeG7h24gY29tYm8gbeG6q3UnfTwvQnV0dG9uPlxyXG4gICAgICAgIHtvcGVuICYmIDxTdGFjayByb2xlPVwic3RhdHVzXCIgZGF0YS10ZXN0aWQ9XCJtb2NrLXByb21vdGlvbi1wcmV2aWV3XCIgc3g9e1tsYXlvdXRTeC5zdXJmYWNlLmNvbXBhY3RDb250ZW50R2FwLCBsYXlvdXRTeC5zdXJmYWNlLmNvbXBhY3RJbnNldCwgeyBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wgfV19PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoM1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIj5Db21ibyBt4bqrdSDCtyBERU1PLVBST01PLTAxPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj7EkGnhu4F1IGtp4buHbiBtaW5oIGjhu41hOiBjw7Mgw610IG5o4bqldCBt4buZdCDDoW8gdsOgIG3hu5l0IHBo4bulIGtp4buHbiB0cm9uZyDEkcahbiBuaMOhcC48L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPktow7RuZyDDoXAgZOG7pW5nIGdp4bqjbSBnacOhLCBraMO0bmcgc+G7rWEgxJHGoW4gdsOgIGtow7RuZyBraOG6s25nIMSR4buLbmggxJHhuqF0IGJpw6puIGzhu6NpIG5odeG6rW4uPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDwvU3RhY2s+fVxyXG4gICAgPC9TdXJmYWNlQ29udGVudD47XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvaW5ib3gvaW5kZXgudHN4In0=