"use client";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-TJQ5SMJY.js?v=f9568e8d";
import {
  createSvgIcon
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-BYBKOQBC.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-LTFVV63V.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-UAZB53LO.js?v=f9568e8d";
import {
  require_jsx_runtime
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-YMMUPFRD.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-GAYUPZDI.js?v=f9568e8d";
import {
  __toESM
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5574-aaebc51c-502c-41be-aa47-4e52607c15d6/deps/chunk-PX6F3LHL.js?v=f9568e8d";

// ../../node_modules/@mui/icons-material/esm/AddRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var AddRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M18 13h-5v5c0 .55-.45 1-1 1s-1-.45-1-1v-5H6c-.55 0-1-.45-1-1s.45-1 1-1h5V6c0-.55.45-1 1-1s1 .45 1 1v5h5c.55 0 1 .45 1 1s-.45 1-1 1"
}), "AddRounded");
export {
  AddRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_AddRounded.js.map
