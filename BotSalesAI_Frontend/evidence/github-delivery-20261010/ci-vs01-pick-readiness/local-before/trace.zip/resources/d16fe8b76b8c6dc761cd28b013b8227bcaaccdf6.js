import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/fulfillment/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-72984-e67bd5ce-e237-4e3b-8b0a-1515a189a968/deps/react_jsx-dev-runtime.js?v=e2db2bbf"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { ActionGroup, FieldGroup, FormFields, PageSections } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-72984-e67bd5ce-e237-4e3b-8b0a-1515a189a968/deps/react.js?v=e2db2bbf"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-72984-e67bd5ce-e237-4e3b-8b0a-1515a189a968/deps/react-router-dom.js?v=363cd221";
import { Alert, Box, Button, Checkbox, FormControlLabel, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-72984-e67bd5ce-e237-4e3b-8b0a-1515a189a968/deps/@mui_material.js?v=2ead1294";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { limitCodePoints, codePointLength, dateTime, dateTimeLocalInput, dateTimeLocalToISOString } from "/src/shared/model/format.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { Amount, PageHeader, Panel, DataTable, QueryState, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, DetailLine, LookupLoadMore } from "/src/shared/ui/components.tsx";
const shipmentEventOptions = [
  { value: "in_transit", label: "Đang vận chuyển" },
  { value: "delivered", label: "Khách đã nhận hàng" },
  { value: "failed", label: "Giao thất bại" },
  { value: "returning", label: "Đang hoàn về" },
  { value: "returned", label: "Đã hoàn về" }
];
export function FulfillmentPage() {
  _s();
  const { shop } = useScope();
  const query = useListQuery("listPrepJobs");
  const list = useApi("listPrepJobs", { query });
  const [selected, setSelected] = useState(null);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Chuẩn bị hàng", subtitle: "Nhận việc, lấy đúng SKU, kiểm đủ số lượng rồi đóng gói.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/shipments`, children: "Vận đơn & bàn giao" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 50,
      columnNumber: 119
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listPrepJobs" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Công việc chuẩn bị đơn", rows: list.data.data, rowKey: (prep) => prep.id, columns: [
          { key: "order", label: "Đơn hàng", render: (prep) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${prep.orderId}`, children: [
            "Mã đơn: ",
            prep.orderId
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 56,
            columnNumber: 64
          }, this) },
          { key: "state", label: "Giai đoạn", render: (prep) => /* @__PURE__ */ jsxDEV(Status, { value: prep.state }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 57,
            columnNumber: 65
          }, this) },
          { key: "items", label: "Dòng hàng", render: (prep) => `${prep.lines.filter((line) => line.requiredQuantity === line.pickedQuantity && !line.hasIssue).length}/${prep.lines.length} đã kiểm đủ` },
          { key: "assigned", label: "Người nhận", render: (prep) => prep.assigneeUserId || "Chưa có" },
          { key: "action", label: "", render: (prep) => /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", onClick: () => setSelected(prep.id), children: "Mở phiếu lấy hàng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 60,
            columnNumber: 57
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 55,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 62,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 54,
        columnNumber: 31
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 53,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this),
    selected && /* @__PURE__ */ jsxDEV(PrepDialog, { resourceId: selected, onClose: () => setSelected(null) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 66,
      columnNumber: 22
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
    lineNumber: 49,
    columnNumber: 10
  }, this);
}
_s(FulfillmentPage, "ctsDIgHoEVk5OZn+RlZN/o/puLc=", false, function() {
  return [useScope, useListQuery, useApi];
});
_c = FulfillmentPage;
function PrepDialog({ resourceId, onClose }) {
  _s2();
  const { shop, session, membership } = useScope();
  const get = useApi("getPrepJob", { path: { resourceId } });
  const prep = get.data?.data;
  const task = useApi("getWorkItem", { path: { resourceId: prep?.workItemId || "pending" } }, !!prep);
  const workItem = task.data?.data;
  const claim = useCommand("claimWorkItem", ["getWorkItem", "getPrepJob", "listWorkItems", "listPrepJobs"]);
  const pick = useCommand("pickPrepLine", ["getPrepJob", "listPrepJobs"]);
  const pack = useCommand("packPrepJob", ["getPrepJob", "listPrepJobs", "getOrder", "listOrders"]);
  const [scans, setScans] = useState({});
  const [quantities, setQuantities] = useState({});
  const [issues, setIssues] = useState({});
  const [packing, setPacking] = useState(false);
  const [draftCommit, setDraftCommit] = useState();
  const assigned = workItem?.assigneeUserId === session.user.id;
  const mayClaim = membership.permissions.includes("operations.claim");
  async function refreshAssignment() {
    await Promise.all([get.refetch(), task.refetch()]);
    claim.resetAfterReconcile();
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(EditDialog, { open: true, title: `Phiếu chuẩn bị ${prep?.orderId || ""}`, onClose, busy: pick.pending || claim.pending, draftCommit, actions: ({ requestClose, busy }) => /* @__PURE__ */ jsxDEV(Button, { disabled: busy, onClick: requestClose, children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 93,
      columnNumber: 192
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: claim.error || pick.error || task.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: get, children: prep && /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Stack, { direction: "row", justifyContent: "space-between", alignItems: "center", children: [
          /* @__PURE__ */ jsxDEV(Status, { value: prep.state }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 98,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${prep.orderId}`, children: "Chi tiết đơn" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 99,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 97,
          columnNumber: 21
        }, this),
        prep.state === "queued" && mayClaim && workItem?.allowedActions.includes("claim") && /* @__PURE__ */ jsxDEV(
          MutationButton,
          {
            permission: "operations.claim",
            allowedActions: workItem.allowedActions,
            action: "claim",
            variant: "contained",
            busy: claim.pending,
            disabled: !workItem || workItem.state !== "queued" || !!workItem.assigneeUserId,
            onClick: () => {
              if (!workItem) return;
              void claim.execute({ path: { resourceId: prep.workItemId }, body: { expectedVersion: workItem.version } }).catch(() => void 0);
            },
            children: "Tôi nhận chuẩn bị đơn"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 101,
            columnNumber: 107
          },
          this
        ),
        prep.state === "queued" && !mayClaim && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có quyền nhận công việc chuẩn bị này." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 114,
          columnNumber: 62
        }, this),
        prep.state === "queued" && mayClaim && workItem && !workItem.allowedActions.includes("claim") && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Công việc đã đổi trạng thái hoặc đã có người nhận. Tải lại phiếu để xem người phụ trách mới." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 115,
          columnNumber: 119
        }, this),
        prep.state === "queued" && claim.error && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => void refreshAssignment(), children: "Tải lại trạng thái" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 116,
          columnNumber: 64
        }, this),
        !assigned && prep.state !== "queued" && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          "Phiếu đang do ",
          workItem?.assigneeUserId || prep.assigneeUserId || "nhân viên khác",
          " phụ trách."
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 117,
          columnNumber: 62
        }, this),
        prep.lines.map((line) => {
          const scan = scans[line.orderLineId] || "";
          const quantity = quantities[line.orderLineId] ?? String(line.pickedQuantity);
          const quantityIsValid = /^\d+$/.test(quantity) && Number.isInteger(Number(quantity)) && Number(quantity) >= 0 && Number(quantity) <= line.requiredQuantity;
          const issue = issues[line.orderLineId] || "";
          const canEdit = assigned && ["claimed", "picking"].includes(prep.state);
          return /* @__PURE__ */ jsxDEV(Box, { "data-draft-scope": line.orderLineId, sx: { ...layoutSx.surface.inset, border: 1, borderColor: "divider", borderRadius: visualSx.radius.dialog }, children: [
            /* @__PURE__ */ jsxDEV(Stack, { direction: "row", justifyContent: "space-between", sx: layoutSx.surface.headerFlowGap, children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: line.sku }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 130,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { children: [
                line.pickedQuantity,
                "/",
                line.requiredQuantity
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 131,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 129,
              columnNumber: 29
            }, this),
            line.hasIssue && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.contentGap, children: "Dòng hàng còn vấn đề cần xử lý." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 133,
              columnNumber: 47
            }, this),
            /* @__PURE__ */ jsxDEV(FormFields, { beforeGap: "surface", children: [
              /* @__PURE__ */ jsxDEV(TextField, { label: "Nhập/quét SKU thực tế", value: scan, onChange: (event) => setScans((current) => ({ ...current, [line.orderLineId]: limitCodePoints(event.target.value, 100) })), disabled: !canEdit }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 135,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                TextField,
                {
                  label: "Số lượng đã lấy",
                  type: "number",
                  inputProps: { min: 0, max: line.requiredQuantity, step: 1 },
                  value: quantity,
                  error: !quantityIsValid,
                  helperText: !quantityIsValid ? `Nhập số nguyên từ 0 đến ${line.requiredQuantity}.` : void 0,
                  onChange: (event) => setQuantities((current) => ({ ...current, [line.orderLineId]: event.target.value })),
                  disabled: !canEdit
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                  lineNumber: 136,
                  columnNumber: 33
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Vấn đề phát hiện (để trống khi đạt)", value: issue, onChange: (event) => setIssues((current) => ({ ...current, [line.orderLineId]: limitCodePoints(event.target.value, 1e3) })), disabled: !canEdit }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 146,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                MutationButton,
                {
                  permission: "fulfillment.write",
                  busy: pick.pending,
                  disabled: !canEdit || !scan.trim() || !quantityIsValid || codePointLength(issue) > 1e3,
                  onClick: () => void pick.execute({ path: { resourceId }, body: {
                    expectedVersion: prep.version,
                    orderLineId: line.orderLineId,
                    scannedSku: scan.trim(),
                    pickedQuantity: Number(quantity),
                    issueReason: issue.trim() || null
                  } }).then(() => setDraftCommit((current) => ({ scope: line.orderLineId, sequence: (current?.sequence || 0) + 1 }))).catch(() => void 0),
                  children: "Xác nhận dòng đã kiểm"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                  lineNumber: 147,
                  columnNumber: 33
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 134,
              columnNumber: 29
            }, this)
          ] }, line.orderLineId, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 128,
            columnNumber: 20
          }, this);
        }),
        /* @__PURE__ */ jsxDEV(
          MutationButton,
          {
            permission: "fulfillment.write",
            variant: "contained",
            disabled: !assigned || prep.state !== "picking" || !prep.lines.every((line) => line.pickedQuantity === line.requiredQuantity && !line.hasIssue),
            onClick: () => setPacking(true),
            children: "Xác nhận đã đóng gói"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 162,
            columnNumber: 21
          },
          this
        ),
        prep.state === "picking" && !prep.lines.every((line) => line.pickedQuantity === line.requiredQuantity && !line.hasIssue) && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chưa thể đóng gói: cần lấy đủ từng dòng và xử lý mọi vấn đề trước." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 168,
          columnNumber: 146
        }, this),
        prep.state === "packed" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/shipments?orderId=${prep.orderId}`, children: "Tạo vận đơn để bàn giao" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 169,
          columnNumber: 49
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Các nút lấy/đóng gói là xác nhận của người thật. Hệ thống không tự nhận công việc vật lý đã hoàn tất." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 170,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 96,
        columnNumber: 26
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 95,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 93,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      ConfirmDialog,
      {
        open: packing,
        title: "Hoàn tất đóng gói",
        confirmLabel: "Xác nhận đã đóng gói",
        description: `Công việc ${resourceId}, đơn ${prep?.orderId || ""}: xác nhận đã kiểm đủ SKU, số lượng và đóng gói thực tế. Bước tiếp theo là bàn giao kiện; chưa xác nhận đã giao cho khách.`,
        onClose: () => setPacking(false),
        busy: pack.pending,
        error: pack.error,
        onConfirm: () => pack.execute({ path: { resourceId }, body: { expectedVersion: prep?.version || 1 } })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 174,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
    lineNumber: 92,
    columnNumber: 10
  }, this);
}
_s2(PrepDialog, "1yTrJqokyfHDYJ68HVGOK6mOGEk=", false, function() {
  return [useScope, useApi, useApi, useCommand, useCommand, useCommand];
});
_c2 = PrepDialog;
export function ShipmentsPage() {
  _s3();
  const { shop } = useScope();
  const [searchParams] = useSearchParams();
  const list = useApi("listShipments", { query: useListQuery("listShipments") });
  const [previewOpen, setPreviewOpen] = useState(false);
  const [orderSearchInput, setOrderSearchInput] = useState("");
  const [orderSearch, setOrderSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setOrderSearch(orderSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [orderSearchInput]);
  const orders = usePagedApi("listOrders", { query: { q: orderSearch || void 0 } });
  const create = useCommand("createShipment", ["listShipments", "listOrders"]);
  const handover = useCommand("handoverShipment", ["getShipment", "listShipments", "listOrders", "listStockSnapshots", "listStockMovements", "listPrepJobs", "listWorkItems"]);
  const event = useCommand("recordShipmentEvent", ["getShipment", "listShipments", "listOrders", "listDebtItems", "getProfitLoss", "getDashboard"]);
  const [open, setOpen] = useState(false);
  const [orderId, setOrderId] = useState(() => searchParams.get("orderId") || "");
  const selectedOrderDetail = useApi("getOrder", { path: { orderId } }, !!orderId);
  const selectedOrder = orders.data?.data.find((order) => order.id === orderId) || selectedOrderDetail.data?.data;
  const [carrierId, setCarrierId] = useState("");
  const [selectedShipmentId, setSelectedShipmentId] = useState(null);
  const [dialogMode, setDialogMode] = useState("view");
  const [eventType, setEventType] = useState("in_transit");
  const [externalEventId, setExternalEventId] = useState("");
  const [evidenceRef, setEvidenceRef] = useState("");
  const [occurredAt, setOccurredAt] = useState(() => dateTimeLocalInput(/* @__PURE__ */ new Date(), shop.timezone));
  const detail = useApi("getShipment", { path: { resourceId: selectedShipmentId || "pending" } }, !!selectedShipmentId);
  const shipment = detail.data?.data;
  function openShipment(id, mode) {
    setSelectedShipmentId(id);
    setDialogMode(mode);
    setEventType("in_transit");
    setExternalEventId("");
    setEvidenceRef("");
    setOccurredAt(dateTimeLocalInput(/* @__PURE__ */ new Date(), shop.timezone));
  }
  function closeShipment() {
    setSelectedShipmentId(null);
    setDialogMode("view");
  }
  const occurredAtInstant = dateTimeLocalToISOString(occurredAt, shop.timezone);
  const validOccurrence = occurredAtInstant !== null;
  const duplicateEventId = !!shipment?.events.some((item) => item.externalEventId === externalEventId.trim());
  const canRecordEvent = !!shipment && !["planned", "cancelled", "returned"].includes(shipment.state) && externalEventId.trim().length > 0 && codePointLength(externalEventId.trim()) <= 160 && evidenceRef.trim().length > 0 && validOccurrence && !duplicateEventId;
  async function submitEvent() {
    if (!shipment || !canRecordEvent || !occurredAtInstant) return;
    await event.execute({ path: { resourceId: shipment.id }, body: {
      expectedVersion: shipment.version,
      externalEventId: externalEventId.trim(),
      eventType,
      occurredAt: occurredAtInstant,
      evidenceRef: evidenceRef.trim()
    } });
    closeShipment();
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Vận đơn & giao hàng", subtitle: "Bàn giao hàng, khách nhận hàng và tiền về là ba sự kiện khác nhau.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.write", variant: "contained", onClick: () => setOpen(true), children: "Tạo vận đơn" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 253,
      columnNumber: 136
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 253,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(Panel, { children: [
        /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listShipments" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 256,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh sách vận đơn", rows: list.data.data, rowKey: (item) => item.id, columns: [
            { key: "id", label: "Vận đơn", render: (item) => /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: item.trackingCode || item.id }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 260,
                columnNumber: 69
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: item.carrierId ? `Mã đơn vị vận chuyển: ${item.carrierId}` : "Giao thủ công" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 260,
                columnNumber: 175
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 260,
              columnNumber: 62
            }, this) },
            { key: "order", label: "Đơn", render: (item) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${item.orderId}`, children: [
              "Mã đơn: ",
              item.orderId
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 261,
              columnNumber: 61
            }, this) },
            { key: "state", label: "Trạng thái", render: (item) => /* @__PURE__ */ jsxDEV(Status, { value: item.state }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 262,
              columnNumber: 68
            }, this) },
            { key: "quote", label: "Phí báo giá", render: (item) => /* @__PURE__ */ jsxDEV(Amount, { value: item.shippingFeeQuote }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 263,
              columnNumber: 69
            }, this) },
            { key: "actual", label: "Phí thực tế", render: (item) => /* @__PURE__ */ jsxDEV(Amount, { value: item.shippingFeeActual }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 264,
              columnNumber: 70
            }, this) },
            { key: "actions", label: "", render: (item) => /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => openShipment(item.id, "view"), children: "Chi tiết" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 266,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.handover", disabled: !["planned", "label_ready"].includes(item.state), onClick: () => openShipment(item.id, "handover"), children: "Bàn giao" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 267,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.write", disabled: ["planned", "cancelled", "returned"].includes(item.state), onClick: () => openShipment(item.id, "event"), children: "Cập nhật hành trình" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 268,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 265,
              columnNumber: 60
            }, this) }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 259,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 271,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 258,
          columnNumber: 35
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 257,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 255,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Xem thử phí và vùng giao hàng", subtitle: "Mở khi cần kiểm tra giao diện mẫu; nội dung này không xác nhận khả năng giao hoặc tạo vận đơn.", bodyMode: "inset", children: [
        /* @__PURE__ */ jsxDEV(Button, { "aria-expanded": previewOpen, "aria-controls": "shipment-fee-preview", onClick: () => setPreviewOpen((value) => !value), children: previewOpen ? "Ẩn bản xem thử phí giao hàng" : "Mở bản xem thử phí giao hàng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 276,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { id: "shipment-fee-preview", role: "region", "aria-label": "Bản xem thử phí giao hàng", "data-testid": "shipment-fee-preview", hidden: !previewOpen, children: __MOCK__ ? /* @__PURE__ */ jsxDEV(ShippingQuotePreview, {}, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 278,
          columnNumber: 33
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "API hiện chỉ trả phí báo giá/thực tế nếu đã có trên vận đơn; chưa có thao tác kiểm tra vùng giao hoặc xin báo giá mới." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 278,
          columnNumber: 60
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 277,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 275,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 254,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      EditDialog,
      {
        open,
        title: "Tạo vận đơn",
        onClose: () => setOpen(false),
        busy: create.pending,
        actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !orderId || create.pending || selectedOrder?.fulfillmentState !== "packed", onClick: async () => {
          const order = selectedOrder?.fulfillmentState === "packed" ? selectedOrder : void 0;
          if (!order) return;
          try {
            await create.execute({ body: { orderId: order.id, warehouseId: order.warehouseId, carrierId: carrierId.trim() || null, orderLineIds: order.lines.map((line) => line.id) } });
            setOpen(false);
          } catch {
          }
        }, children: "Tạo bản vận chuyển" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 288,
          columnNumber: 16
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 298,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { children: [
            /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm đơn hàng", value: orderSearchInput, onChange: (event2) => setOrderSearchInput(event2.target.value), helperText: "Tìm theo mã đơn; kết quả tải theo cursor từ API." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 300,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Đơn đã đóng gói", value: orderId, onChange: (event2) => setOrderId(event2.target.value), disabled: orders.isPending && !orders.data, children: [
              orderId && !orders.data?.data.some((order) => order.id === orderId) && /* @__PURE__ */ jsxDEV(MenuItem, { value: orderId, children: selectedOrder?.id || (selectedOrderDetail.isPending ? "Đang tải đơn đã chọn…" : orderId) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 302,
                columnNumber: 93
              }, this),
              orders.data?.data.filter((order) => order.fulfillmentState === "packed").map((order) => /* @__PURE__ */ jsxDEV(MenuItem, { value: order.id, children: order.id }, order.id, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 303,
                columnNumber: 110
              }, this))
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 301,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "đơn hàng", loadedCount: orders.loadedCount, hasMore: orders.hasMore, busy: orders.isLoadingMore, onLoadMore: orders.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 305,
              columnNumber: 17
            }, this),
            orders.isError && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "column", children: [
              /* @__PURE__ */ jsxDEV(ErrorNotice, { error: orders.error }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 306,
                columnNumber: 68
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (orders.isFetchNextPageError ? orders.loadMore() : orders.refetch());
              }, children: "Thử lại danh sách đơn" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 306,
                columnNumber: 104
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 306,
              columnNumber: 36
            }, this),
            selectedOrderDetail.isError && /* @__PURE__ */ jsxDEV(ErrorNotice, { error: selectedOrderDetail.error }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 307,
              columnNumber: 49
            }, this),
            selectedOrder && selectedOrder.fulfillmentState !== "packed" && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Đơn đã chọn chưa ở trạng thái đã đóng gói nên chưa thể tạo vận đơn." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 308,
              columnNumber: 82
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Mã đơn vị vận chuyển (trống = thủ công)", value: carrierId, onChange: (event2) => setCarrierId(limitCodePoints(event2.target.value, 160)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 309,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vận đơn/nhãn in của nhà vận chuyển chỉ xuất hiện khi backend có adapter đã được cấp quyền. Không tự tạo mã giao hàng thật." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 310,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 299,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 283,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      EditDialog,
      {
        open: !!selectedShipmentId,
        title: dialogMode === "handover" ? "Xác nhận bàn giao kiện hàng" : dialogMode === "event" ? "Cập nhật hành trình có bằng chứng" : "Chi tiết vận đơn",
        description: dialogMode === "handover" ? "Xác nhận đã bàn giao cho người vận chuyển. Việc này xuất lượng hàng đang giữ; không đồng nghĩa khách đã nhận hoặc đã thanh toán." : void 0,
        onClose: closeShipment,
        busy: handover.pending || event.pending,
        actions: /* @__PURE__ */ jsxDEV(Stack, { direction: "row", sx: layoutSx.dialog.actionsGap, children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: dialogMode === "view" ? closeShipment : () => setDialogMode("view"), children: dialogMode === "view" ? "Đóng" : "Quay lại" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 321,
            columnNumber: 17
          }, this),
          dialogMode === "view" && shipment && ["planned", "label_ready"].includes(shipment.state) && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.handover", variant: "contained", disabled: detail.isLoading, onClick: () => setDialogMode("handover"), children: "Bàn giao" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 322,
            columnNumber: 110
          }, this),
          dialogMode === "view" && shipment && !["planned", "cancelled", "returned"].includes(shipment.state) && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.write", onClick: () => setDialogMode("event"), children: "Cập nhật hành trình" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 323,
            columnNumber: 121
          }, this),
          dialogMode === "handover" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.handover", variant: "contained", busy: handover.pending, disabled: !shipment || !["planned", "label_ready"].includes(shipment.state), onClick: () => {
            if (!shipment) return;
            void handover.execute({ path: { resourceId: shipment.id }, body: { expectedVersion: shipment.version } }).then(() => setDialogMode("view")).catch(() => void 0);
          }, children: "Xác nhận bàn giao" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 324,
            columnNumber: 47
          }, this),
          dialogMode === "event" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "fulfillment.write", variant: "contained", busy: event.pending, disabled: !canRecordEvent, onClick: () => void submitEvent().catch(() => void 0), children: "Ghi sự kiện" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 330,
            columnNumber: 44
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
          lineNumber: 320,
          columnNumber: 16
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: detail.error || handover.error || event.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 333,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: shipment && /* @__PURE__ */ jsxDEV(Stack, { children: [
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Mã vận đơn", children: shipment.trackingCode || shipment.id }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 336,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đơn hàng", children: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${shipment.orderId}`, children: shipment.orderId }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 337,
              columnNumber: 50
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 337,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đơn vị vận chuyển", children: shipment.carrierId || "Giao thủ công" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 338,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Trạng thái", children: /* @__PURE__ */ jsxDEV(Status, { value: shipment.state }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 339,
              columnNumber: 52
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 339,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phí báo giá", children: shipment.shippingFeeQuote ? `${shipment.shippingFeeQuote.amount} ${shipment.shippingFeeQuote.currency}` : "Chưa có" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 340,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phí thực tế", children: shipment.shippingFeeActual ? `${shipment.shippingFeeActual.amount} ${shipment.shippingFeeActual.currency}` : "Chưa có" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 341,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: layoutSx.surface.sectionBefore, children: "Sự kiện vận chuyển" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 342,
              columnNumber: 21
            }, this),
            shipment.events.length ? shipment.events.map((item) => /* @__PURE__ */ jsxDEV(DetailLine, { label: `${item.type} · ${item.externalEventId}`, children: /* @__PURE__ */ jsxDEV(Stack, { alignItems: "flex-end", children: [
              /* @__PURE__ */ jsxDEV(Typography, { children: dateTime(item.occurredAt, shop.timezone) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 344,
                columnNumber: 54
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
                "Bằng chứng: ",
                item.evidenceRef || "Chưa có"
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 344,
                columnNumber: 121
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 344,
              columnNumber: 25
            }, this) }, item.externalEventId, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 343,
              columnNumber: 77
            }, this)) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Chưa có sự kiện." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 345,
              columnNumber: 38
            }, this),
            dialogMode === "handover" && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Hệ thống ghi nhận bàn giao và xuất hàng đang giữ một lần. Trạng thái giao hàng sẽ chỉ đổi khi có sự kiện vận chuyển riêng." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 346,
              columnNumber: 51
            }, this),
            dialogMode === "event" && /* @__PURE__ */ jsxDEV(FormFields, { beforeGap: "surface", children: [
              /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Sự kiện", value: eventType, onChange: (change) => setEventType(change.target.value), children: shipmentEventOptions.map((option) => /* @__PURE__ */ jsxDEV(MenuItem, { value: option.value, children: option.label }, option.value, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 349,
                columnNumber: 67
              }, this)) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 348,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Mã sự kiện bên vận chuyển", value: externalEventId, onChange: (change) => setExternalEventId(limitCodePoints(change.target.value, 160)), error: codePointLength(externalEventId) > 160 || duplicateEventId, helperText: duplicateEventId ? "Mã sự kiện này đã được ghi nhận." : codePointLength(externalEventId) > 160 ? "Tối đa 160 ký tự." : void 0 }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 351,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Thời gian sự kiện", type: "datetime-local", value: occurredAt, onChange: (change) => setOccurredAt(change.target.value), error: !!occurredAt && !validOccurrence, helperText: !!occurredAt && !validOccurrence ? "Nhập giờ tồn tại trong múi giờ cửa hàng." : `Giờ địa phương theo ${shop.timezone}; sẽ chuyển thành instant ISO khi gửi.` }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 352,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(TextField, { label: "Mã bằng chứng", value: evidenceRef, onChange: (change) => setEvidenceRef(limitCodePoints(change.target.value, 160)) }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 353,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Giao thành công, thất bại, hoàn về và thu tiền là các trạng thái riêng. Mỗi sự kiện cần mã chống trùng và bằng chứng do người xác minh cung cấp." }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
                lineNumber: 354,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
              lineNumber: 347,
              columnNumber: 48
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 335,
            columnNumber: 30
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
            lineNumber: 334,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 314,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
    lineNumber: 252,
    columnNumber: 10
  }, this);
}
_s3(ShipmentsPage, "aRgJ2+QM62lkEiH8ZeNQM3j7dfk=", false, function() {
  return [useScope, useSearchParams, useApi, useListQuery, usePagedApi, useCommand, useCommand, useCommand, useApi, useApi];
});
_c3 = ShipmentsPage;
const shippingZones = [
  { id: "city", label: "Nội thành (mẫu)", serviceable: true, baseFees: { small: 18e3, medium: 24e3, large: 32e3 } },
  { id: "regional", label: "Ngoại tỉnh (mẫu)", serviceable: true, baseFees: { small: 32e3, medium: 42e3, large: 56e3 } },
  { id: "outside", label: "Ngoài vùng phục vụ (mẫu)", serviceable: false, baseFees: null }
];
const packageSizes = [
  { id: "small", label: "Gọn · 1–2 kg" },
  { id: "medium", label: "Vừa · 2–5 kg" },
  { id: "large", label: "Lớn · 5–10 kg" }
];
function ShippingQuotePreview() {
  _s4();
  const [zoneId, setZoneId] = useState("city");
  const [sizeId, setSizeId] = useState("small");
  const [addressReady, setAddressReady] = useState(true);
  const [quoteCurrent, setQuoteCurrent] = useState(true);
  const zone = shippingZones.find((item) => item.id === zoneId);
  const amount = zone.baseFees?.[sizeId];
  return /* @__PURE__ */ jsxDEV(FormFields, { children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "DỮ LIỆU MÔ PHỎNG · Phí dưới đây chỉ minh họa trạng thái giao diện, không phải báo giá cho địa chỉ hoặc hãng vận chuyển thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 383,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Vùng giao thử", value: zoneId, onChange: (event) => setZoneId(event.target.value), sx: { flex: 1, minWidth: 0 }, children: shippingZones.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.label }, item.id, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 386,
        columnNumber: 50
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 385,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kích cỡ kiện thử", value: sizeId, onChange: (event) => setSizeId(event.target.value), sx: { flex: 1, minWidth: 0 }, children: packageSizes.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.label }, item.id, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 389,
        columnNumber: 49
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
        lineNumber: 388,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 384,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Có địa chỉ giao hàng mẫu", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: addressReady, onChange: (event) => setAddressReady(event.target.checked) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 392,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 392,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Báo giá mẫu còn hiệu lực", control: /* @__PURE__ */ jsxDEV(Checkbox, { checked: quoteCurrent, onChange: (event) => setQuoteCurrent(event.target.checked) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 393,
      columnNumber: 73
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 393,
      columnNumber: 13
    }, this),
    !addressReady ? /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Thiếu địa chỉ giao hàng; chưa thể xác định vùng hoặc hiển thị phí." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 395,
      columnNumber: 5
    }, this) : !zone.serviceable ? /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vùng mẫu này không được phục vụ; không hiển thị báo giá và không hứa ngày giao." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 397,
      columnNumber: 5
    }, this) : !quoteCurrent ? /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Báo giá mẫu đã hết hiệu lực; cần lấy báo giá mới trước khi xác nhận." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 399,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "success", children: [
      "Ước tính mẫu: ",
      amount?.toLocaleString("vi-VN"),
      " VND · ",
      zone.label,
      " · ",
      packageSizes.find((item) => item.id === sizeId)?.label
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 400,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Trong dữ liệu vận đơn, phí báo giá và phí thực tế được trình bày riêng. Bản xem trước này không lưu cấu hình vùng, không xác nhận khả năng giao và không tạo vận đơn." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
      lineNumber: 401,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx",
    lineNumber: 382,
    columnNumber: 10
  }, this);
}
_s4(ShippingQuotePreview, "hqChFGG8BEcKcSYbO44vVT7xZCY=");
_c4 = ShippingQuotePreview;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "FulfillmentPage");
$RefreshReg$(_c2, "PrepDialog");
$RefreshReg$(_c3, "ShipmentsPage");
$RefreshReg$(_c4, "ShippingQuotePreview");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/fulfillment/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJzSCxTQUl4RixVQUp3Rjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5QnRILFNBQVNBLGFBQWFDLFlBQVlDLFlBQVlDLG9CQUFvQjtBQUNsRSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxVQUFVQyxrQkFBa0JDLFVBQVVDLE9BQU9DLFdBQVdDLGtCQUFrQjtBQUV2RyxTQUFTQyxRQUFRQyxhQUFhQyxrQkFBa0I7QUFDaEQsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxpQkFBaUJDLGlCQUFpQkMsVUFBVUMsb0JBQW9CQyxnQ0FBZ0M7QUFDekcsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFFBQVFDLFlBQVlDLE9BQU9DLFdBQVdDLFlBQVlDLFNBQVNDLE9BQU9DLFFBQVFDLGdCQUFnQkMsWUFBWUMsYUFBYUMsZUFBZUMsV0FBV0MsWUFBWUMsc0JBQXNCO0FBSXhMLE1BQU1DLHVCQUF5RjtBQUFBLEVBQzNGLEVBQUVDLE9BQU8sY0FBY0MsT0FBTyxrQkFBa0I7QUFBQSxFQUNoRCxFQUFFRCxPQUFPLGFBQWFDLE9BQU8scUJBQXFCO0FBQUEsRUFDbEQsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLGdCQUFnQjtBQUFBLEVBQzFDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxlQUFlO0FBQUEsRUFDNUMsRUFBRUQsT0FBTyxZQUFZQyxPQUFPLGFBQWE7QUFBQztBQUd2QyxnQkFBU0Msa0JBQWtCO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxFQUFFQyxLQUFLLElBQUk1QixTQUFTO0FBQzFCLFFBQU02QixRQUFRNUIsYUFBYSxjQUFjO0FBQ3pDLFFBQU02QixPQUFPakMsT0FBTyxnQkFBZ0IsRUFBRWdDLE1BQU0sQ0FBQztBQUM3QyxRQUFNLENBQUNFLFVBQVVDLFdBQVcsSUFBSS9DLFNBQXdCLElBQUk7QUFFNUQsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSxpQkFBZ0IsVUFBUywyREFBMEQsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTTJDLEtBQUtLLEVBQUUsY0FBYyxrQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RCxLQUExSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVMO0FBQUEsSUFDdkwsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFdBQVEsV0FBVSxrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ2pDLHVCQUFDLGNBQVcsT0FBT0gsTUFBTSxnQkFBZSxXQUNuQ0EsZUFBS0ksUUFBUSxtQ0FDVjtBQUFBLCtCQUFDLGFBQVUsT0FBTSwwQkFBeUIsTUFBTUosS0FBS0ksS0FBS0EsTUFBTSxRQUFRLENBQUFDLFNBQVFBLEtBQUtGLElBQUksU0FBUztBQUFBLFVBQzlGLEVBQUVHLEtBQUssU0FBU1gsT0FBTyxZQUFZWSxRQUFRQSxDQUFBRixTQUFRLHVCQUFDLGFBQVUsSUFBSSxNQUFNUCxLQUFLSyxFQUFFLFdBQVdFLEtBQUtHLE9BQU8sSUFBSTtBQUFBO0FBQUEsWUFBU0gsS0FBS0c7QUFBQUEsZUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkUsRUFBYTtBQUFBLFVBQzdJLEVBQUVGLEtBQUssU0FBU1gsT0FBTyxhQUFhWSxRQUFRQSxDQUFBRixTQUFRLHVCQUFDLFVBQU8sT0FBT0EsS0FBS0ksU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsRUFBSTtBQUFBLFVBQ2xGLEVBQUVILEtBQUssU0FBU1gsT0FBTyxhQUFhWSxRQUFRQSxDQUFBRixTQUFRLEdBQUdBLEtBQUtLLE1BQU1DLE9BQU8sQ0FBQUMsU0FBUUEsS0FBS0MscUJBQXFCRCxLQUFLRSxrQkFBa0IsQ0FBQ0YsS0FBS0csUUFBUSxFQUFFQyxNQUFNLElBQUlYLEtBQUtLLE1BQU1NLE1BQU0sY0FBYztBQUFBLFVBQzNMLEVBQUVWLEtBQUssWUFBWVgsT0FBTyxjQUFjWSxRQUFRQSxDQUFBRixTQUFRQSxLQUFLWSxrQkFBa0IsVUFBVTtBQUFBLFVBQ3pGLEVBQUVYLEtBQUssVUFBVVgsT0FBTyxJQUFJWSxRQUFRQSxDQUFBRixTQUFRLHVCQUFDLFVBQU8sU0FBUSxZQUFXLFNBQVMsTUFBTUgsWUFBWUcsS0FBS0YsRUFBRSxHQUFHLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRixFQUFVO0FBQUEsUUFBQyxLQUw1STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUU7QUFBQSxRQUNGLHVCQUFDLFNBQU0sTUFBTUgsS0FBS0ksS0FBS2MsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTZCxLQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFDQ2pCLFlBQVksdUJBQUMsY0FBVyxZQUFZQSxVQUFVLFNBQVMsTUFBTUMsWUFBWSxJQUFJLEtBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxPQWpCN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCUDtBQUNKO0FBQUNMLEdBekJlRCxpQkFBZTtBQUFBLFVBQ1YxQixVQUNIQyxjQUNESixNQUFNO0FBQUE7QUFBQSxLQUhQNkI7QUEyQmhCLFNBQVN1QixXQUFXLEVBQUVDLFlBQVlDLFFBQXFELEdBQUc7QUFBQUMsTUFBQTtBQUN0RixRQUFNLEVBQUV4QixNQUFNeUIsU0FBU0MsV0FBVyxJQUFJdEQsU0FBUztBQUMvQyxRQUFNdUQsTUFBTTFELE9BQU8sY0FBYyxFQUFFMkQsTUFBTSxFQUFFTixXQUFXLEVBQUUsQ0FBQztBQUN6RCxRQUFNZixPQUFPb0IsSUFBSXJCLE1BQU1BO0FBQ3ZCLFFBQU11QixPQUFPNUQsT0FBTyxlQUFlLEVBQUUyRCxNQUFNLEVBQUVOLFlBQVlmLE1BQU11QixjQUFjLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQ3ZCLElBQUk7QUFDbEcsUUFBTXdCLFdBQVdGLEtBQUt2QixNQUFNQTtBQUM1QixRQUFNMEIsUUFBUTdELFdBQVcsaUJBQWlCLENBQUMsZUFBZSxjQUFjLGlCQUFpQixjQUFjLENBQUM7QUFDeEcsUUFBTThELE9BQU85RCxXQUFXLGdCQUFnQixDQUFDLGNBQWMsY0FBYyxDQUFDO0FBQ3RFLFFBQU0rRCxPQUFPL0QsV0FBVyxlQUFlLENBQUMsY0FBYyxnQkFBZ0IsWUFBWSxZQUFZLENBQUM7QUFDL0YsUUFBTSxDQUFDZ0UsT0FBT0MsUUFBUSxJQUFJL0UsU0FBaUMsQ0FBQyxDQUFDO0FBQzdELFFBQU0sQ0FBQ2dGLFlBQVlDLGFBQWEsSUFBSWpGLFNBQWlDLENBQUMsQ0FBQztBQUN2RSxRQUFNLENBQUNrRixRQUFRQyxTQUFTLElBQUluRixTQUFpQyxDQUFDLENBQUM7QUFDL0QsUUFBTSxDQUFDb0YsU0FBU0MsVUFBVSxJQUFJckYsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3NGLGFBQWFDLGNBQWMsSUFBSXZGLFNBQThDO0FBQ3BGLFFBQU13RixXQUFXZCxVQUFVWixtQkFBbUJNLFFBQVFxQixLQUFLekM7QUFDM0QsUUFBTTBDLFdBQVdyQixXQUFXc0IsWUFBWUMsU0FBUyxrQkFBa0I7QUFFbkUsaUJBQWVDLG9CQUFvQjtBQUMvQixVQUFNQyxRQUFRQyxJQUFJLENBQUN6QixJQUFJMEIsUUFBUSxHQUFHeEIsS0FBS3dCLFFBQVEsQ0FBQyxDQUFDO0FBQ2pEckIsVUFBTXNCLG9CQUFvQjtBQUFBLEVBQzlCO0FBRUEsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsTUFBSSxNQUFDLE9BQU8sa0JBQWtCL0MsTUFBTUcsV0FBVyxFQUFFLElBQUksU0FBa0IsTUFBTXVCLEtBQUtzQixXQUFXdkIsTUFBTXVCLFNBQVMsYUFBMEIsU0FBUyxDQUFDLEVBQUVDLGNBQWNDLEtBQUssTUFBTSx1QkFBQyxVQUFPLFVBQVVBLE1BQU0sU0FBU0QsY0FBYyxvQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRCxHQUN0TztBQUFBLDZCQUFDLGVBQVksT0FBT3hCLE1BQU0wQixTQUFTekIsS0FBS3lCLFNBQVM3QixLQUFLNkIsU0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLGNBQVcsT0FBTy9CLEtBQ2RwQixrQkFBUSx1QkFBQyxjQUNOO0FBQUEsK0JBQUMsU0FBTSxXQUFVLE9BQU0sZ0JBQWUsaUJBQWdCLFlBQVcsVUFDN0Q7QUFBQSxpQ0FBQyxVQUFPLE9BQU9BLEtBQUtJLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFDMUIsdUJBQUMsYUFBVSxJQUFJLE1BQU1YLEtBQUtLLEVBQUUsV0FBV0UsS0FBS0csT0FBTyxJQUFJLDRCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLGFBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0NILEtBQUtJLFVBQVUsWUFBWW9DLFlBQVloQixVQUFVNEIsZUFBZVYsU0FBUyxPQUFPLEtBQUs7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNuRixZQUFXO0FBQUEsWUFDWCxnQkFBZ0JsQixTQUFTNEI7QUFBQUEsWUFDekIsUUFBTztBQUFBLFlBQ1AsU0FBUTtBQUFBLFlBQ1IsTUFBTTNCLE1BQU11QjtBQUFBQSxZQUNaLFVBQVUsQ0FBQ3hCLFlBQVlBLFNBQVNwQixVQUFVLFlBQVksQ0FBQyxDQUFDb0IsU0FBU1o7QUFBQUEsWUFDakUsU0FBUyxNQUFNO0FBQ1gsa0JBQUksQ0FBQ1ksU0FBVTtBQUNmLG1CQUFLQyxNQUFNNEIsUUFBUSxFQUFFaEMsTUFBTSxFQUFFTixZQUFZZixLQUFLdUIsV0FBVyxHQUFHK0IsTUFBTSxFQUFFQyxpQkFBaUIvQixTQUFTZ0MsUUFBUSxFQUFFLENBQUMsRUFDcEdDLE1BQU0sTUFBTUMsTUFBUztBQUFBLFlBQzlCO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFYZ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWWhFO0FBQUEsUUFDckIxRCxLQUFLSSxVQUFVLFlBQVksQ0FBQ29DLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sNEVBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUMzSHhDLEtBQUtJLFVBQVUsWUFBWW9DLFlBQVloQixZQUFZLENBQUNBLFNBQVM0QixlQUFlVixTQUFTLE9BQU8sS0FBSyx1QkFBQyxTQUFNLFVBQVMsUUFBTyw0R0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSDtBQUFBLFFBQ3BOMUMsS0FBS0ksVUFBVSxZQUFZcUIsTUFBTTBCLFNBQVMsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNLEtBQUtSLGtCQUFrQixHQUFHLGtDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsUUFDMUgsQ0FBQ0wsWUFBWXRDLEtBQUtJLFVBQVUsWUFBWSx1QkFBQyxTQUFNLFVBQVMsUUFBTztBQUFBO0FBQUEsVUFBZW9CLFVBQVVaLGtCQUFrQlosS0FBS1ksa0JBQWtCO0FBQUEsVUFBaUI7QUFBQSxhQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFIO0FBQUEsUUFDN0paLEtBQUtLLE1BQU1zRCxJQUFJLENBQUFwRCxTQUFRO0FBQ3BCLGdCQUFNcUQsT0FBT2hDLE1BQU1yQixLQUFLc0QsV0FBVyxLQUFLO0FBQ3hDLGdCQUFNQyxXQUFXaEMsV0FBV3ZCLEtBQUtzRCxXQUFXLEtBQUtFLE9BQU94RCxLQUFLRSxjQUFjO0FBQzNFLGdCQUFNdUQsa0JBQWtCLFFBQVFDLEtBQUtILFFBQVEsS0FDdENJLE9BQU9DLFVBQVVELE9BQU9KLFFBQVEsQ0FBQyxLQUNqQ0ksT0FBT0osUUFBUSxLQUFLLEtBQ3BCSSxPQUFPSixRQUFRLEtBQUt2RCxLQUFLQztBQUNoQyxnQkFBTTRELFFBQVFwQyxPQUFPekIsS0FBS3NELFdBQVcsS0FBSztBQUMxQyxnQkFBTVEsVUFBVS9CLFlBQVksQ0FBQyxXQUFXLFNBQVMsRUFBRUksU0FBUzFDLEtBQUtJLEtBQUs7QUFFdEUsaUJBQU8sdUJBQUMsT0FBMkIsb0JBQWtCRyxLQUFLc0QsYUFBYSxJQUFJLEVBQUUsR0FBR3pGLFNBQVNrRyxRQUFRQyxPQUFPQyxRQUFRLEdBQUdDLGFBQWEsV0FBV0MsY0FBYzNILFNBQVM0SCxPQUFPQyxPQUFPLEdBQzVLO0FBQUEsbUNBQUMsU0FBTSxXQUFVLE9BQU0sZ0JBQWUsaUJBQWdCLElBQUl4RyxTQUFTa0csUUFBUU8sZUFDdkU7QUFBQSxxQ0FBQyxjQUFXLFlBQVk5SCxTQUFTK0gsV0FBV0MsV0FBV0MsUUFBU3pFLGVBQUswRSxPQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLGNBQVkxRTtBQUFBQSxxQkFBS0U7QUFBQUEsZ0JBQWU7QUFBQSxnQkFBRUYsS0FBS0M7QUFBQUEsbUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNDRCxLQUFLRyxZQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLElBQUl0QyxTQUFTOEcsT0FBT0MsWUFBWSwrQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQSxZQUMzRyx1QkFBQyxjQUFXLFdBQVUsV0FDbEI7QUFBQSxxQ0FBQyxhQUFVLE9BQU0seUJBQXdCLE9BQU92QixNQUFNLFVBQVUsQ0FBQXdCLFVBQVN2RCxTQUFTLENBQUF3RCxhQUFZLEVBQUUsR0FBR0EsU0FBUyxDQUFDOUUsS0FBS3NELFdBQVcsR0FBRzlGLGdCQUFnQnFILE1BQU1FLE9BQU9qRyxPQUFPLEdBQUcsRUFBRSxFQUFFLEdBQUcsVUFBVSxDQUFDZ0YsV0FBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaU07QUFBQSxjQUNqTTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxPQUFNO0FBQUEsa0JBQ04sTUFBSztBQUFBLGtCQUNMLFlBQVksRUFBRWtCLEtBQUssR0FBR0MsS0FBS2pGLEtBQUtDLGtCQUFrQmlGLE1BQU0sRUFBRTtBQUFBLGtCQUMxRCxPQUFPM0I7QUFBQUEsa0JBQ1AsT0FBTyxDQUFDRTtBQUFBQSxrQkFDUixZQUFZLENBQUNBLGtCQUFrQiwyQkFBMkJ6RCxLQUFLQyxnQkFBZ0IsTUFBTWtEO0FBQUFBLGtCQUNyRixVQUFVLENBQUEwQixVQUFTckQsY0FBYyxDQUFBc0QsYUFBWSxFQUFFLEdBQUdBLFNBQVMsQ0FBQzlFLEtBQUtzRCxXQUFXLEdBQUd1QixNQUFNRSxPQUFPakcsTUFBTSxFQUFFO0FBQUEsa0JBQ3BHLFVBQVUsQ0FBQ2dGO0FBQUFBO0FBQUFBLGdCQVJmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVF1QjtBQUFBLGNBRXZCLHVCQUFDLGFBQVUsT0FBTSx1Q0FBc0MsT0FBT0QsT0FBTyxVQUFVLENBQUFnQixVQUFTbkQsVUFBVSxDQUFBb0QsYUFBWSxFQUFFLEdBQUdBLFNBQVMsQ0FBQzlFLEtBQUtzRCxXQUFXLEdBQUc5RixnQkFBZ0JxSCxNQUFNRSxPQUFPakcsT0FBTyxHQUFJLEVBQUUsRUFBRSxHQUFHLFVBQVUsQ0FBQ2dGLFdBQTFNO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtOO0FBQUEsY0FDbE47QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csWUFBVztBQUFBLGtCQUNYLE1BQU0zQyxLQUFLc0I7QUFBQUEsa0JBQ1gsVUFBVSxDQUFDcUIsV0FBVyxDQUFDVCxLQUFLOEIsS0FBSyxLQUFLLENBQUMxQixtQkFBbUJoRyxnQkFBZ0JvRyxLQUFLLElBQUk7QUFBQSxrQkFDbkYsU0FBUyxNQUFNLEtBQUsxQyxLQUFLMkIsUUFBUSxFQUFFaEMsTUFBTSxFQUFFTixXQUFXLEdBQUd1QyxNQUFNO0FBQUEsb0JBQzNEQyxpQkFBaUJ2RCxLQUFLd0Q7QUFBQUEsb0JBQ3RCSyxhQUFhdEQsS0FBS3NEO0FBQUFBLG9CQUNsQjhCLFlBQVkvQixLQUFLOEIsS0FBSztBQUFBLG9CQUN0QmpGLGdCQUFnQnlELE9BQU9KLFFBQVE7QUFBQSxvQkFDL0I4QixhQUFheEIsTUFBTXNCLEtBQUssS0FBSztBQUFBLGtCQUNqQyxFQUFFLENBQUMsRUFBRUcsS0FBSyxNQUFNeEQsZUFBZSxDQUFBZ0QsYUFBWSxFQUFFUyxPQUFPdkYsS0FBS3NELGFBQWFrQyxXQUFXVixTQUFTVSxZQUFZLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRXRDLE1BQU0sTUFBTUMsTUFBUztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFWN0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV3NCO0FBQUEsaUJBeEIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLGVBL0JhbkQsS0FBS3NELGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ1A7QUFBQSxRQUNKLENBQUM7QUFBQSxRQUNEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxZQUFXO0FBQUEsWUFDWCxTQUFRO0FBQUEsWUFDUixVQUFVLENBQUN2QixZQUFZdEMsS0FBS0ksVUFBVSxhQUFhLENBQUNKLEtBQUtLLE1BQU0yRixNQUFNLENBQUF6RixTQUFRQSxLQUFLRSxtQkFBbUJGLEtBQUtDLG9CQUFvQixDQUFDRCxLQUFLRyxRQUFRO0FBQUEsWUFDNUksU0FBUyxNQUFNeUIsV0FBVyxJQUFJO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3FCO0FBQUEsUUFDcEJuQyxLQUFLSSxVQUFVLGFBQWEsQ0FBQ0osS0FBS0ssTUFBTTJGLE1BQU0sQ0FBQXpGLFNBQVFBLEtBQUtFLG1CQUFtQkYsS0FBS0Msb0JBQW9CLENBQUNELEtBQUtHLFFBQVEsS0FBSyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxrRkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFFBQ25OVixLQUFLSSxVQUFVLFlBQVksdUJBQUMsYUFBVSxJQUFJLE1BQU1YLEtBQUtLLEVBQUUsc0JBQXNCRSxLQUFLRyxPQUFPLElBQUksdUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUNySCx1QkFBQyxTQUFNLFVBQVMsUUFBTyxxSEFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0SDtBQUFBLFdBMUV2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkVULEtBNUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2RUE7QUFBQSxTQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0ZBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTStCO0FBQUFBLFFBQ04sT0FBTTtBQUFBLFFBQ04sY0FBYTtBQUFBLFFBQXVCLGFBQWEsYUFBYW5CLFVBQVUsU0FBU2YsTUFBTUcsV0FBVyxFQUFFO0FBQUEsUUFDcEcsU0FBUyxNQUFNZ0MsV0FBVyxLQUFLO0FBQUEsUUFDL0IsTUFBTVIsS0FBS3FCO0FBQUFBLFFBQ1gsT0FBT3JCLEtBQUt3QjtBQUFBQSxRQUNaLFdBQVcsTUFBTXhCLEtBQUswQixRQUFRLEVBQUVoQyxNQUFNLEVBQUVOLFdBQVcsR0FBR3VDLE1BQU0sRUFBRUMsaUJBQWlCdkQsTUFBTXdELFdBQVcsRUFBRSxFQUFFLENBQUM7QUFBQTtBQUFBLE1BUHpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU8yRztBQUFBLE9BekZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkZQO0FBQ0o7QUFBQ3ZDLElBbEhRSCxZQUFVO0FBQUEsVUFDdUJqRCxVQUMxQkgsUUFFQ0EsUUFFQ0UsWUFDREEsWUFDQUEsVUFBVTtBQUFBO0FBQUEsTUFSbEJrRDtBQW9IRixnQkFBU21GLGdCQUFnQjtBQUFBQyxNQUFBO0FBQzVCLFFBQU0sRUFBRXpHLEtBQUssSUFBSTVCLFNBQVM7QUFDMUIsUUFBTSxDQUFDc0ksWUFBWSxJQUFJbkosZ0JBQWdCO0FBQ3ZDLFFBQU0yQyxPQUFPakMsT0FBTyxpQkFBaUIsRUFBRWdDLE9BQU81QixhQUFhLGVBQWUsRUFBRSxDQUFDO0FBQzdFLFFBQU0sQ0FBQ3NJLGFBQWFDLGNBQWMsSUFBSXZKLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN3SixrQkFBa0JDLG1CQUFtQixJQUFJekosU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzBKLGFBQWFDLGNBQWMsSUFBSTNKLFNBQVMsRUFBRTtBQUNqREQsWUFBVSxNQUFNO0FBQ1osVUFBTTZKLFFBQVFDLE9BQU9DLFdBQVcsTUFBTUgsZUFBZUgsaUJBQWlCWixLQUFLLENBQUMsR0FBRyxHQUFHO0FBQ2xGLFdBQU8sTUFBTWlCLE9BQU9FLGFBQWFILEtBQUs7QUFBQSxFQUMxQyxHQUFHLENBQUNKLGdCQUFnQixDQUFDO0FBQ3JCLFFBQU1RLFNBQVNuSixZQUFZLGNBQWMsRUFBRStCLE9BQU8sRUFBRXFILEdBQUdQLGVBQWU5QyxPQUFVLEVBQUUsQ0FBQztBQUNuRixRQUFNc0QsU0FBU3BKLFdBQVcsa0JBQWtCLENBQUMsaUJBQWlCLFlBQVksQ0FBQztBQUMzRSxRQUFNcUosV0FBV3JKLFdBQVcsb0JBQW9CLENBQUMsZUFBZSxpQkFBaUIsY0FBYyxzQkFBc0Isc0JBQXNCLGdCQUFnQixlQUFlLENBQUM7QUFDM0ssUUFBTXdILFFBQVF4SCxXQUFXLHVCQUF1QixDQUFDLGVBQWUsaUJBQWlCLGNBQWMsaUJBQWlCLGlCQUFpQixjQUFjLENBQUM7QUFDaEosUUFBTSxDQUFDc0osTUFBTUMsT0FBTyxJQUFJckssU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ3FELFNBQVNpSCxVQUFVLElBQUl0SyxTQUFTLE1BQU1xSixhQUFhL0UsSUFBSSxTQUFTLEtBQUssRUFBRTtBQUM5RSxRQUFNaUcsc0JBQXNCM0osT0FBTyxZQUFZLEVBQUUyRCxNQUFNLEVBQUVsQixRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU87QUFDL0UsUUFBTW1ILGdCQUFnQlIsT0FBTy9HLE1BQU1BLEtBQUt3SCxLQUFLLENBQUFDLFVBQVNBLE1BQU0xSCxPQUFPSyxPQUFPLEtBQUtrSCxvQkFBb0J0SCxNQUFNQTtBQUN6RyxRQUFNLENBQUMwSCxXQUFXQyxZQUFZLElBQUk1SyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNkssb0JBQW9CQyxxQkFBcUIsSUFBSTlLLFNBQXdCLElBQUk7QUFDaEYsUUFBTSxDQUFDK0ssWUFBWUMsYUFBYSxJQUFJaEwsU0FBNkIsTUFBTTtBQUN2RSxRQUFNLENBQUNpTCxXQUFXQyxZQUFZLElBQUlsTCxTQUEwQyxZQUFZO0FBQ3hGLFFBQU0sQ0FBQ21MLGlCQUFpQkMsa0JBQWtCLElBQUlwTCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDcUwsYUFBYUMsY0FBYyxJQUFJdEwsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VMLFlBQVlDLGFBQWEsSUFBSXhMLFNBQVMsTUFBTW9CLG1CQUFtQixvQkFBSXFLLEtBQUssR0FBRzlJLEtBQUsrSSxRQUFRLENBQUM7QUFDaEcsUUFBTUMsU0FBUy9LLE9BQU8sZUFBZSxFQUFFMkQsTUFBTSxFQUFFTixZQUFZNEcsc0JBQXNCLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQ0Esa0JBQWtCO0FBQ3BILFFBQU1lLFdBQVdELE9BQU8xSSxNQUFNQTtBQUU5QixXQUFTNEksYUFBYTdJLElBQVk4SSxNQUEwQjtBQUN4RGhCLDBCQUFzQjlILEVBQUU7QUFDeEJnSSxrQkFBY2MsSUFBSTtBQUNsQlosaUJBQWEsWUFBWTtBQUN6QkUsdUJBQW1CLEVBQUU7QUFDckJFLG1CQUFlLEVBQUU7QUFDakJFLGtCQUFjcEssbUJBQW1CLG9CQUFJcUssS0FBSyxHQUFHOUksS0FBSytJLFFBQVEsQ0FBQztBQUFBLEVBQy9EO0FBRUEsV0FBU0ssZ0JBQWdCO0FBQ3JCakIsMEJBQXNCLElBQUk7QUFDMUJFLGtCQUFjLE1BQU07QUFBQSxFQUN4QjtBQUVBLFFBQU1nQixvQkFBb0IzSyx5QkFBeUJrSyxZQUFZNUksS0FBSytJLFFBQVE7QUFDNUUsUUFBTU8sa0JBQWtCRCxzQkFBc0I7QUFDOUMsUUFBTUUsbUJBQW1CLENBQUMsQ0FBQ04sVUFBVU8sT0FBT0MsS0FBSyxDQUFBQyxTQUFRQSxLQUFLbEIsb0JBQW9CQSxnQkFBZ0J2QyxLQUFLLENBQUM7QUFDeEcsUUFBTTBELGlCQUFpQixDQUFDLENBQUNWLFlBQ2xCLENBQUMsQ0FBQyxXQUFXLGFBQWEsVUFBVSxFQUFFaEcsU0FBU2dHLFNBQVN0SSxLQUFLLEtBQzdENkgsZ0JBQWdCdkMsS0FBSyxFQUFFL0UsU0FBUyxLQUNoQzNDLGdCQUFnQmlLLGdCQUFnQnZDLEtBQUssQ0FBQyxLQUFLLE9BQzNDeUMsWUFBWXpDLEtBQUssRUFBRS9FLFNBQVMsS0FDNUJvSSxtQkFDQSxDQUFDQztBQUVSLGlCQUFlSyxjQUFjO0FBQ3pCLFFBQUksQ0FBQ1gsWUFBWSxDQUFDVSxrQkFBa0IsQ0FBQ04sa0JBQW1CO0FBQ3hELFVBQU0xRCxNQUFNL0IsUUFBUSxFQUFFaEMsTUFBTSxFQUFFTixZQUFZMkgsU0FBUzVJLEdBQUcsR0FBR3dELE1BQU07QUFBQSxNQUMzREMsaUJBQWlCbUYsU0FBU2xGO0FBQUFBLE1BQzFCeUUsaUJBQWlCQSxnQkFBZ0J2QyxLQUFLO0FBQUEsTUFDdENxQztBQUFBQSxNQUNBTSxZQUFZUztBQUFBQSxNQUNaWCxhQUFhQSxZQUFZekMsS0FBSztBQUFBLElBQ2xDLEVBQUUsQ0FBQztBQUNIbUQsa0JBQWM7QUFBQSxFQUNsQjtBQUVBLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0sdUJBQXNCLFVBQVMsc0VBQXFFLFNBQVMsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUSxhQUFZLFNBQVMsTUFBTTFCLFFBQVEsSUFBSSxHQUFHLDJCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRHLEtBQTNPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNlA7QUFBQSxJQUM3UCx1QkFBQyxnQkFDRztBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFRLFdBQVUsbUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxjQUFXLE9BQU94SCxNQUFNLGdCQUFlLFdBQ25DQSxlQUFLSSxRQUFRLG1DQUNWO0FBQUEsaUNBQUMsYUFBVSxPQUFNLHFCQUFvQixNQUFNSixLQUFLSSxLQUFLQSxNQUFNLFFBQVEsQ0FBQW9KLFNBQVFBLEtBQUtySixJQUFJLFNBQVM7QUFBQSxZQUM3RixFQUFFRyxLQUFLLE1BQU1YLE9BQU8sV0FBV1ksUUFBUUEsQ0FBQWlKLFNBQVEsdUJBQUMsU0FBTTtBQUFBLHFDQUFDLGNBQVcsWUFBWXBNLFNBQVMrSCxXQUFXQyxXQUFXQyxRQUFTbUUsZUFBS0csZ0JBQWdCSCxLQUFLckosTUFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkY7QUFBQSxjQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFXcUosZUFBSzFCLFlBQVkseUJBQXlCMEIsS0FBSzFCLFNBQVMsS0FBSyxtQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEc7QUFBQSxpQkFBN047QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBME8sRUFBUztBQUFBLFlBQ2xTLEVBQUV4SCxLQUFLLFNBQVNYLE9BQU8sT0FBT1ksUUFBUUEsQ0FBQWlKLFNBQVEsdUJBQUMsYUFBVSxJQUFJLE1BQU0xSixLQUFLSyxFQUFFLFdBQVdxSixLQUFLaEosT0FBTyxJQUFJO0FBQUE7QUFBQSxjQUFTZ0osS0FBS2hKO0FBQUFBLGlCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RSxFQUFhO0FBQUEsWUFDeEksRUFBRUYsS0FBSyxTQUFTWCxPQUFPLGNBQWNZLFFBQVFBLENBQUFpSixTQUFRLHVCQUFDLFVBQU8sT0FBT0EsS0FBSy9JLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCLEVBQUk7QUFBQSxZQUNuRixFQUFFSCxLQUFLLFNBQVNYLE9BQU8sZUFBZVksUUFBUUEsQ0FBQWlKLFNBQVEsdUJBQUMsVUFBTyxPQUFPQSxLQUFLSSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUMsRUFBRztBQUFBLFlBQzlGLEVBQUV0SixLQUFLLFVBQVVYLE9BQU8sZUFBZVksUUFBUUEsQ0FBQWlKLFNBQVEsdUJBQUMsVUFBTyxPQUFPQSxLQUFLSyxxQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0MsRUFBRztBQUFBLFlBQ2hHLEVBQUV2SixLQUFLLFdBQVdYLE9BQU8sSUFBSVksUUFBUUEsQ0FBQWlKLFNBQVEsdUJBQUMsZUFBWSxXQUFVLE9BQ2hFO0FBQUEscUNBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNUixhQUFhUSxLQUFLckosSUFBSSxNQUFNLEdBQUcsd0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsY0FDM0UsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsVUFBVSxDQUFDLENBQUMsV0FBVyxhQUFhLEVBQUU0QyxTQUFTeUcsS0FBSy9JLEtBQUssR0FBRyxTQUFTLE1BQU11SSxhQUFhUSxLQUFLckosSUFBSSxVQUFVLEdBQUcsd0JBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdLO0FBQUEsY0FDeEssdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsVUFBVSxDQUFDLFdBQVcsYUFBYSxVQUFVLEVBQUU0QyxTQUFTeUcsS0FBSy9JLEtBQUssR0FBRyxTQUFTLE1BQU11SSxhQUFhUSxLQUFLckosSUFBSSxPQUFPLEdBQUcsbUNBQW5LO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNMO0FBQUEsaUJBSDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSTdDLEVBQWU7QUFBQSxVQUFDLEtBVmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0U7QUFBQSxVQUNGLHVCQUFDLFNBQU0sTUFBTUgsS0FBS0ksS0FBS2MsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQWJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY2QsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxPQUFNLGlDQUFnQyxVQUFTLGtHQUFpRyxVQUFTLFNBQzVKO0FBQUEsK0JBQUMsVUFBTyxpQkFBZXVGLGFBQWEsaUJBQWMsd0JBQXVCLFNBQVMsTUFBTUMsZUFBZSxDQUFBaEgsVUFBUyxDQUFDQSxLQUFLLEdBQUkrRyx3QkFBYyxpQ0FBaUMsa0NBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd007QUFBQSxRQUN4TSx1QkFBQyxPQUFJLElBQUcsd0JBQXVCLE1BQUssVUFBUyxjQUFXLDZCQUE0QixlQUFZLHdCQUF1QixRQUFRLENBQUNBLGFBQzNIcUQscUJBQVcsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQixJQUFNLHVCQUFDLFNBQU0sVUFBUyxRQUFPLHNJQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZJLEtBRHhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHO0FBQUEsUUFDQSxPQUFNO0FBQUEsUUFDTixTQUFTLE1BQU10QyxRQUFRLEtBQUs7QUFBQSxRQUM1QixNQUFNSCxPQUFPaEU7QUFBQUEsUUFDYixTQUFTLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFVBQVUsQ0FBQzdDLFdBQVc2RyxPQUFPaEUsV0FBV3NFLGVBQWVvQyxxQkFBcUIsVUFBVSxTQUFTLFlBQVk7QUFDNUksZ0JBQU1sQyxRQUFRRixlQUFlb0MscUJBQXFCLFdBQVdwQyxnQkFBZ0I1RDtBQUM3RSxjQUFJLENBQUM4RCxNQUFPO0FBQ1osY0FBSTtBQUNBLGtCQUFNUixPQUFPM0QsUUFBUSxFQUFFQyxNQUFNLEVBQUVuRCxTQUFTcUgsTUFBTTFILElBQUk2SixhQUFhbkMsTUFBTW1DLGFBQWFsQyxXQUFXQSxVQUFVL0IsS0FBSyxLQUFLLE1BQU1rRSxjQUFjcEMsTUFBTW5ILE1BQU1zRCxJQUFJLENBQUFwRCxTQUFRQSxLQUFLVCxFQUFFLEVBQUUsRUFBRSxDQUFDO0FBQ3pLcUgsb0JBQVEsS0FBSztBQUFBLFVBQ2pCLFFBQ007QUFBQSxVQUFFO0FBQUEsUUFDWixHQUFHLGtDQVJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRWTtBQUFBLFFBRXJCO0FBQUEsaUNBQUMsZUFBWSxPQUFPSCxPQUFPN0QsU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUM7QUFBQSxVQUNqQyx1QkFBQyxjQUNHO0FBQUEsbUNBQUMsYUFBVSxPQUFNLGdCQUFlLE9BQU9tRCxrQkFBa0IsVUFBVSxDQUFBbEIsV0FBU21CLG9CQUFvQm5CLE9BQU1FLE9BQU9qRyxLQUFLLEdBQUcsWUFBVyxzREFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0w7QUFBQSxZQUNsTCx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLG1CQUFrQixPQUFPYyxTQUFTLFVBQVUsQ0FBQWlGLFdBQVNnQyxXQUFXaEMsT0FBTUUsT0FBT2pHLEtBQUssR0FBRyxVQUFVeUgsT0FBTytDLGFBQWEsQ0FBQy9DLE9BQU8vRyxNQUM5SUk7QUFBQUEseUJBQVcsQ0FBQzJHLE9BQU8vRyxNQUFNQSxLQUFLbUosS0FBSyxDQUFBMUIsVUFBU0EsTUFBTTFILE9BQU9LLE9BQU8sS0FBSyx1QkFBQyxZQUFTLE9BQU9BLFNBQVVtSCx5QkFBZXhILE9BQU91SCxvQkFBb0J3QyxZQUFZLDBCQUEwQjFKLFlBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9IO0FBQUEsY0FDekwyRyxPQUFPL0csTUFBTUEsS0FBS08sT0FBTyxDQUFBa0gsVUFBU0EsTUFBTWtDLHFCQUFxQixRQUFRLEVBQUUvRixJQUFJLENBQUE2RCxVQUFTLHVCQUFDLFlBQXdCLE9BQU9BLE1BQU0xSCxJQUFLMEgsZ0JBQU0xSCxNQUFsQzBILE1BQU0xSCxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRCxDQUFXO0FBQUEsaUJBRnhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLGtCQUFlLE9BQU0sWUFBVyxhQUFhZ0gsT0FBT2dELGFBQWEsU0FBU2hELE9BQU9pRCxTQUFTLE1BQU1qRCxPQUFPa0QsZUFBZSxZQUFZbEQsT0FBT21ELFlBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1KO0FBQUEsWUFDbEpuRCxPQUFPb0QsV0FBVyx1QkFBQyxlQUFZLFdBQVUsVUFBUztBQUFBLHFDQUFDLGVBQVksT0FBT3BELE9BQU8zRCxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQUUsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsc0JBQU0yRCxPQUFPcUQsdUJBQXVCckQsT0FBT21ELFNBQVMsSUFBSW5ELE9BQU9oRSxRQUFRO0FBQUEsY0FBSSxHQUFHLHFDQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5STtBQUFBLGlCQUE1TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxTjtBQUFBLFlBQ3ZPdUUsb0JBQW9CNkMsV0FBVyx1QkFBQyxlQUFZLE9BQU83QyxvQkFBb0JsRSxTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzdFbUUsaUJBQWlCQSxjQUFjb0MscUJBQXFCLFlBQVksdUJBQUMsU0FBTSxVQUFTLFdBQVUsbUZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDOUosdUJBQUMsYUFBVSxPQUFNLDJDQUEwQyxPQUFPakMsV0FBVyxVQUFVLENBQUFyQyxXQUFTc0MsYUFBYTNKLGdCQUFnQnFILE9BQU1FLE9BQU9qRyxPQUFPLEdBQUcsQ0FBQyxLQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1SjtBQUFBLFlBQ3ZKLHVCQUFDLFNBQU0sVUFBUyxRQUFPLDBJQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSjtBQUFBLGVBWHJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQTtBQUFBO0FBQUEsTUE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNkJBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTSxDQUFDLENBQUNzSTtBQUFBQSxRQUNSLE9BQU9FLGVBQWUsYUFBYSxnQ0FBZ0NBLGVBQWUsVUFBVSxzQ0FBc0M7QUFBQSxRQUNsSSxhQUFhQSxlQUFlLGFBQWEscUlBQXFJbkU7QUFBQUEsUUFDOUssU0FBU21GO0FBQUFBLFFBQ1QsTUFBTTVCLFNBQVNqRSxXQUFXb0MsTUFBTXBDO0FBQUFBLFFBQ2hDLFNBQVMsdUJBQUMsU0FBTSxXQUFVLE9BQU0sSUFBSTVFLFNBQVN3RyxPQUFPd0YsWUFDaEQ7QUFBQSxpQ0FBQyxVQUFPLFNBQVN2QyxlQUFlLFNBQVNnQixnQkFBZ0IsTUFBTWYsY0FBYyxNQUFNLEdBQUlELHlCQUFlLFNBQVMsU0FBUyxjQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSTtBQUFBLFVBQ2xJQSxlQUFlLFVBQVVhLFlBQVksQ0FBQyxXQUFXLGFBQWEsRUFBRWhHLFNBQVNnRyxTQUFTdEksS0FBSyxLQUFLLHVCQUFDLGtCQUFlLFlBQVcsd0JBQXVCLFNBQVEsYUFBWSxVQUFVcUksT0FBTzRCLFdBQVcsU0FBUyxNQUFNdkMsY0FBYyxVQUFVLEdBQUcsd0JBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9KO0FBQUEsVUFDaFBELGVBQWUsVUFBVWEsWUFBWSxDQUFDLENBQUMsV0FBVyxhQUFhLFVBQVUsRUFBRWhHLFNBQVNnRyxTQUFTdEksS0FBSyxLQUFLLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVMsTUFBTTBILGNBQWMsT0FBTyxHQUFHLG1DQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RztBQUFBLFVBQ2hORCxlQUFlLGNBQWMsdUJBQUMsa0JBQWUsWUFBVyx3QkFBdUIsU0FBUSxhQUFZLE1BQU1aLFNBQVNqRSxTQUFTLFVBQVUsQ0FBQzBGLFlBQVksQ0FBQyxDQUFDLFdBQVcsYUFBYSxFQUFFaEcsU0FBU2dHLFNBQVN0SSxLQUFLLEdBQUcsU0FBUyxNQUFNO0FBQ3BOLGdCQUFJLENBQUNzSSxTQUFVO0FBQ2YsaUJBQUt6QixTQUFTNUQsUUFBUSxFQUFFaEMsTUFBTSxFQUFFTixZQUFZMkgsU0FBUzVJLEdBQUcsR0FBR3dELE1BQU0sRUFBRUMsaUJBQWlCbUYsU0FBU2xGLFFBQVEsRUFBRSxDQUFDLEVBQ25HcUMsS0FBSyxNQUFNaUMsY0FBYyxNQUFNLENBQUMsRUFDaENyRSxNQUFNLE1BQU1DLE1BQVM7QUFBQSxVQUM5QixHQUFHLGlDQUwyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtWO0FBQUEsVUFDbkJtRSxlQUFlLFdBQVcsdUJBQUMsa0JBQWUsWUFBVyxxQkFBb0IsU0FBUSxhQUFZLE1BQU16QyxNQUFNcEMsU0FBUyxVQUFVLENBQUNvRyxnQkFBZ0IsU0FBUyxNQUFNLEtBQUtDLFlBQVksRUFBRTVGLE1BQU0sTUFBTUMsTUFBUyxHQUFHLDJCQUE3SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3TDtBQUFBLGFBVjlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXVDtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxlQUFZLE9BQU8rRSxPQUFPdEYsU0FBUzhELFNBQVM5RCxTQUFTaUMsTUFBTWpDLFNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsVUFDbEUsdUJBQUMsY0FBVyxPQUFPc0YsUUFDZEMsc0JBQVksdUJBQUMsU0FDVjtBQUFBLG1DQUFDLGNBQVcsT0FBTSxjQUFjQSxtQkFBU1ksZ0JBQWdCWixTQUFTNUksTUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRSx1QkFBQyxjQUFXLE9BQU0sWUFBVyxpQ0FBQyxhQUFVLElBQUksTUFBTUwsS0FBS0ssRUFBRSxXQUFXNEksU0FBU3ZJLE9BQU8sSUFBS3VJLG1CQUFTdkksV0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkUsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxZQUN0SCx1QkFBQyxjQUFXLE9BQU0scUJBQXFCdUksbUJBQVNqQixhQUFhLG1CQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQzdFLHVCQUFDLGNBQVcsT0FBTSxjQUFhLGlDQUFDLFVBQU8sT0FBT2lCLFNBQVN0SSxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFLHVCQUFDLGNBQVcsT0FBTSxlQUFlc0ksbUJBQVNhLG1CQUFtQixHQUFHYixTQUFTYSxpQkFBaUJlLE1BQU0sSUFBSTVCLFNBQVNhLGlCQUFpQmdCLFFBQVEsS0FBSyxhQUEzSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSjtBQUFBLFlBQ3JKLHVCQUFDLGNBQVcsT0FBTSxlQUFlN0IsbUJBQVNjLG9CQUFvQixHQUFHZCxTQUFTYyxrQkFBa0JjLE1BQU0sSUFBSTVCLFNBQVNjLGtCQUFrQmUsUUFBUSxLQUFLLGFBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdKO0FBQUEsWUFDeEosdUJBQUMsY0FBVyxTQUFRLGFBQVksSUFBSW5NLFNBQVNrRyxRQUFRa0csZUFBZSxrQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUNyRjlCLFNBQVNPLE9BQU90SSxTQUFTK0gsU0FBU08sT0FBT3RGLElBQUksQ0FBQXdGLFNBQVEsdUJBQUMsY0FBc0MsT0FBTyxHQUFHQSxLQUFLc0IsSUFBSSxNQUFNdEIsS0FBS2xCLGVBQWUsSUFDdEksaUNBQUMsU0FBTSxZQUFXLFlBQVc7QUFBQSxxQ0FBQyxjQUFZaEssbUJBQVNrTCxLQUFLZCxZQUFZNUksS0FBSytJLFFBQVEsS0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUFhLHVCQUFDLGNBQVcsU0FBUSxXQUFVO0FBQUE7QUFBQSxnQkFBYVcsS0FBS2hCLGVBQWU7QUFBQSxtQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUU7QUFBQSxpQkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0wsS0FEbkhnQixLQUFLbEIsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRXRELENBQWEsSUFBSSx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLGdDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25FSixlQUFlLGNBQWMsdUJBQUMsU0FBTSxVQUFTLFdBQVUsMElBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9KO0FBQUEsWUFDakxBLGVBQWUsV0FBVyx1QkFBQyxjQUFXLFdBQVUsV0FDN0M7QUFBQSxxQ0FBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLFdBQVUsT0FBT0UsV0FBVyxVQUFVLENBQUEyQyxXQUFVMUMsYUFBYTBDLE9BQU9wRixPQUFPakcsS0FBd0MsR0FDdElELCtCQUFxQnVFLElBQUksQ0FBQWdILFdBQVUsdUJBQUMsWUFBNEIsT0FBT0EsT0FBT3RMLE9BQVFzTCxpQkFBT3JMLFNBQTNDcUwsT0FBT3RMLE9BQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFLENBQVcsS0FEbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsYUFBVSxPQUFNLDZCQUE0QixPQUFPNEksaUJBQWlCLFVBQVUsQ0FBQXlDLFdBQVV4QyxtQkFBbUJuSyxnQkFBZ0IyTSxPQUFPcEYsT0FBT2pHLE9BQU8sR0FBRyxDQUFDLEdBQUksT0FBT3JCLGdCQUFnQmlLLGVBQWUsSUFBSSxPQUFPZSxrQkFBa0IsWUFBWUEsbUJBQW1CLHFDQUFxQ2hMLGdCQUFnQmlLLGVBQWUsSUFBSSxNQUFNLHNCQUFzQnZFLFVBQS9WO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlXO0FBQUEsY0FDelcsdUJBQUMsYUFBVSxPQUFNLHFCQUFvQixNQUFLLGtCQUFpQixPQUFPMkUsWUFBWSxVQUFVLENBQUFxQyxXQUFVcEMsY0FBY29DLE9BQU9wRixPQUFPakcsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDZ0osY0FBYyxDQUFDVSxpQkFBaUIsWUFBWSxDQUFDLENBQUNWLGNBQWMsQ0FBQ1Usa0JBQWtCLDZDQUE2Qyx1QkFBdUJ0SixLQUFLK0ksUUFBUSw0Q0FBL1M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd1Y7QUFBQSxjQUN4Vix1QkFBQyxhQUFVLE9BQU0saUJBQWdCLE9BQU9MLGFBQWEsVUFBVSxDQUFBdUMsV0FBVXRDLGVBQWVySyxnQkFBZ0IyTSxPQUFPcEYsT0FBT2pHLE9BQU8sR0FBRyxDQUFDLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1JO0FBQUEsY0FDbkksdUJBQUMsU0FBTSxVQUFTLFFBQU8sZ0tBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVLO0FBQUEsaUJBUGhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUTNCO0FBQUEsZUFwQlM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQmIsS0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQTtBQUFBO0FBQUEsTUEzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNENBO0FBQUEsT0ExR0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJHUDtBQUNKO0FBQUM2RyxJQTlLZUQsZUFBYTtBQUFBLFVBQ1JwSSxVQUNNYixpQkFDVlUsUUFBaUNJLGNBUS9CSCxhQUNBQyxZQUNFQSxZQUNIQSxZQUdjRixRQVNiQSxNQUFNO0FBQUE7QUFBQSxNQTFCVHVJO0FBZ0xoQixNQUFNMkUsZ0JBQWdCO0FBQUEsRUFDbEIsRUFBRTlLLElBQUksUUFBUVIsT0FBTyxtQkFBbUJ1TCxhQUFhLE1BQU1DLFVBQVUsRUFBRUMsT0FBTyxNQUFPQyxRQUFRLE1BQU9DLE9BQU8sS0FBTSxFQUFFO0FBQUEsRUFDbkgsRUFBRW5MLElBQUksWUFBWVIsT0FBTyxvQkFBb0J1TCxhQUFhLE1BQU1DLFVBQVUsRUFBRUMsT0FBTyxNQUFPQyxRQUFRLE1BQU9DLE9BQU8sS0FBTSxFQUFFO0FBQUEsRUFDeEgsRUFBRW5MLElBQUksV0FBV1IsT0FBTyw0QkFBNEJ1TCxhQUFhLE9BQU9DLFVBQVUsS0FBSztBQUFDO0FBRzVGLE1BQU1JLGVBQWU7QUFBQSxFQUNqQixFQUFFcEwsSUFBSSxTQUFTUixPQUFPLGVBQWU7QUFBQSxFQUNyQyxFQUFFUSxJQUFJLFVBQVVSLE9BQU8sZUFBZTtBQUFBLEVBQ3RDLEVBQUVRLElBQUksU0FBU1IsT0FBTyxnQkFBZ0I7QUFBQztBQUczQyxTQUFTNkwsdUJBQXVCO0FBQUFDLE1BQUE7QUFDNUIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl4TyxTQUErQyxNQUFNO0FBQ2pGLFFBQU0sQ0FBQ3lPLFFBQVFDLFNBQVMsSUFBSTFPLFNBQThDLE9BQU87QUFDakYsUUFBTSxDQUFDMk8sY0FBY0MsZUFBZSxJQUFJNU8sU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzZPLGNBQWNDLGVBQWUsSUFBSTlPLFNBQVMsSUFBSTtBQUNyRCxRQUFNK08sT0FBT2pCLGNBQWNyRCxLQUFLLENBQUE0QixTQUFRQSxLQUFLckosT0FBT3VMLE1BQU07QUFDMUQsUUFBTWYsU0FBU3VCLEtBQUtmLFdBQVdTLE1BQU07QUFFckMsU0FBTyx1QkFBQyxjQUNBO0FBQUEsMkJBQUMsU0FBTSxVQUFTLFFBQU8sNElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUo7QUFBQSxJQUNuSix1QkFBQyxjQUFXLFdBQVcsRUFBRU8sSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxZQUFZLEVBQUVELElBQUksV0FBV0MsSUFBSSxRQUFRLEdBQ3pGO0FBQUEsNkJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxpQkFBZ0IsT0FBT1YsUUFBUSxVQUFVLENBQUFqRyxVQUFTa0csVUFBVWxHLE1BQU1FLE9BQU9qRyxLQUFzQixHQUFHLElBQUksRUFBRTJNLE1BQU0sR0FBR0MsVUFBVSxFQUFFLEdBQ2hKckIsd0JBQWNqSCxJQUFJLENBQUF3RixTQUFRLHVCQUFDLFlBQXVCLE9BQU9BLEtBQUtySixJQUFLcUosZUFBSzdKLFNBQS9CNkosS0FBS3JKLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0QsQ0FBVyxLQUQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sb0JBQW1CLE9BQU95TCxRQUFRLFVBQVUsQ0FBQW5HLFVBQVNvRyxVQUFVcEcsTUFBTUUsT0FBT2pHLEtBQXNCLEdBQUcsSUFBSSxFQUFFMk0sTUFBTSxHQUFHQyxVQUFVLEVBQUUsR0FDbkpmLHVCQUFhdkgsSUFBSSxDQUFBd0YsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLckosSUFBS3FKLGVBQUs3SixTQUEvQjZKLEtBQUtySixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9ELENBQVcsS0FEN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLG9CQUFpQixPQUFNLDRCQUEyQixTQUFTLHVCQUFDLFlBQVMsU0FBUzJMLGNBQWMsVUFBVSxDQUFBckcsVUFBU3NHLGdCQUFnQnRHLE1BQU1FLE9BQU80RyxPQUFPLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEYsS0FBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSjtBQUFBLElBQzFKLHVCQUFDLG9CQUFpQixPQUFNLDRCQUEyQixTQUFTLHVCQUFDLFlBQVMsU0FBU1AsY0FBYyxVQUFVLENBQUF2RyxVQUFTd0csZ0JBQWdCeEcsTUFBTUUsT0FBTzRHLE9BQU8sS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRixLQUF0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBKO0FBQUEsSUFDekosQ0FBQ1QsZUFDSSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxrRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RixJQUM1RixDQUFDSSxLQUFLaEIsY0FDRix1QkFBQyxTQUFNLFVBQVMsV0FBVSwrRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RyxJQUN6RyxDQUFDYyxlQUNHLHVCQUFDLFNBQU0sVUFBUyxXQUFVLG9GQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThGLElBQzlGLHVCQUFDLFNBQU0sVUFBUyxXQUFVO0FBQUE7QUFBQSxNQUFlckIsUUFBUTZCLGVBQWUsT0FBTztBQUFBLE1BQUU7QUFBQSxNQUFRTixLQUFLdk07QUFBQUEsTUFBTTtBQUFBLE1BQUk0TCxhQUFhM0QsS0FBSyxDQUFBNEIsU0FBUUEsS0FBS3JKLE9BQU95TCxNQUFNLEdBQUdqTTtBQUFBQSxTQUEvSTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFKO0FBQUEsSUFDbkssdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUIscUxBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBME47QUFBQSxPQW5CM047QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9CUDtBQUNKO0FBQUM4TCxJQTdCUUQsc0JBQW9CO0FBQUEsTUFBcEJBO0FBQW9CLElBQUFpQixJQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFILElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJBY3Rpb25Hcm91cCIsIkZpZWxkR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiQ2hlY2tib3giLCJGb3JtQ29udHJvbExhYmVsIiwiTWVudUl0ZW0iLCJTdGFjayIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJ1c2VBcGkiLCJ1c2VQYWdlZEFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsInVzZUxpc3RRdWVyeSIsImxpbWl0Q29kZVBvaW50cyIsImNvZGVQb2ludExlbmd0aCIsImRhdGVUaW1lIiwiZGF0ZVRpbWVMb2NhbElucHV0IiwiZGF0ZVRpbWVMb2NhbFRvSVNPU3RyaW5nIiwibGF5b3V0U3giLCJBbW91bnQiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJEYXRhVGFibGUiLCJRdWVyeVN0YXRlIiwiVG9vbGJhciIsIlBhZ2VyIiwiU3RhdHVzIiwiTXV0YXRpb25CdXR0b24iLCJFZGl0RGlhbG9nIiwiRXJyb3JOb3RpY2UiLCJDb25maXJtRGlhbG9nIiwiUm91dGVMaW5rIiwiRGV0YWlsTGluZSIsIkxvb2t1cExvYWRNb3JlIiwic2hpcG1lbnRFdmVudE9wdGlvbnMiLCJ2YWx1ZSIsImxhYmVsIiwiRnVsZmlsbG1lbnRQYWdlIiwiX3MiLCJzaG9wIiwicXVlcnkiLCJsaXN0Iiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImlkIiwiZGF0YSIsInByZXAiLCJrZXkiLCJyZW5kZXIiLCJvcmRlcklkIiwic3RhdGUiLCJsaW5lcyIsImZpbHRlciIsImxpbmUiLCJyZXF1aXJlZFF1YW50aXR5IiwicGlja2VkUXVhbnRpdHkiLCJoYXNJc3N1ZSIsImxlbmd0aCIsImFzc2lnbmVlVXNlcklkIiwicGFnZSIsIlByZXBEaWFsb2ciLCJyZXNvdXJjZUlkIiwib25DbG9zZSIsIl9zMiIsInNlc3Npb24iLCJtZW1iZXJzaGlwIiwiZ2V0IiwicGF0aCIsInRhc2siLCJ3b3JrSXRlbUlkIiwid29ya0l0ZW0iLCJjbGFpbSIsInBpY2siLCJwYWNrIiwic2NhbnMiLCJzZXRTY2FucyIsInF1YW50aXRpZXMiLCJzZXRRdWFudGl0aWVzIiwiaXNzdWVzIiwic2V0SXNzdWVzIiwicGFja2luZyIsInNldFBhY2tpbmciLCJkcmFmdENvbW1pdCIsInNldERyYWZ0Q29tbWl0IiwiYXNzaWduZWQiLCJ1c2VyIiwibWF5Q2xhaW0iLCJwZXJtaXNzaW9ucyIsImluY2x1ZGVzIiwicmVmcmVzaEFzc2lnbm1lbnQiLCJQcm9taXNlIiwiYWxsIiwicmVmZXRjaCIsInJlc2V0QWZ0ZXJSZWNvbmNpbGUiLCJwZW5kaW5nIiwicmVxdWVzdENsb3NlIiwiYnVzeSIsImVycm9yIiwiYWxsb3dlZEFjdGlvbnMiLCJleGVjdXRlIiwiYm9keSIsImV4cGVjdGVkVmVyc2lvbiIsInZlcnNpb24iLCJjYXRjaCIsInVuZGVmaW5lZCIsIm1hcCIsInNjYW4iLCJvcmRlckxpbmVJZCIsInF1YW50aXR5IiwiU3RyaW5nIiwicXVhbnRpdHlJc1ZhbGlkIiwidGVzdCIsIk51bWJlciIsImlzSW50ZWdlciIsImlzc3VlIiwiY2FuRWRpdCIsInN1cmZhY2UiLCJpbnNldCIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYm9yZGVyUmFkaXVzIiwicmFkaXVzIiwiZGlhbG9nIiwiaGVhZGVyRmxvd0dhcCIsInR5cG9ncmFwaHkiLCJmb250V2VpZ2h0Iiwic3Ryb25nIiwic2t1Iiwibm90aWNlIiwiY29udGVudEdhcCIsImV2ZW50IiwiY3VycmVudCIsInRhcmdldCIsIm1pbiIsIm1heCIsInN0ZXAiLCJ0cmltIiwic2Nhbm5lZFNrdSIsImlzc3VlUmVhc29uIiwidGhlbiIsInNjb3BlIiwic2VxdWVuY2UiLCJldmVyeSIsIlNoaXBtZW50c1BhZ2UiLCJfczMiLCJzZWFyY2hQYXJhbXMiLCJwcmV2aWV3T3BlbiIsInNldFByZXZpZXdPcGVuIiwib3JkZXJTZWFyY2hJbnB1dCIsInNldE9yZGVyU2VhcmNoSW5wdXQiLCJvcmRlclNlYXJjaCIsInNldE9yZGVyU2VhcmNoIiwidGltZXIiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwiY2xlYXJUaW1lb3V0Iiwib3JkZXJzIiwicSIsImNyZWF0ZSIsImhhbmRvdmVyIiwib3BlbiIsInNldE9wZW4iLCJzZXRPcmRlcklkIiwic2VsZWN0ZWRPcmRlckRldGFpbCIsInNlbGVjdGVkT3JkZXIiLCJmaW5kIiwib3JkZXIiLCJjYXJyaWVySWQiLCJzZXRDYXJyaWVySWQiLCJzZWxlY3RlZFNoaXBtZW50SWQiLCJzZXRTZWxlY3RlZFNoaXBtZW50SWQiLCJkaWFsb2dNb2RlIiwic2V0RGlhbG9nTW9kZSIsImV2ZW50VHlwZSIsInNldEV2ZW50VHlwZSIsImV4dGVybmFsRXZlbnRJZCIsInNldEV4dGVybmFsRXZlbnRJZCIsImV2aWRlbmNlUmVmIiwic2V0RXZpZGVuY2VSZWYiLCJvY2N1cnJlZEF0Iiwic2V0T2NjdXJyZWRBdCIsIkRhdGUiLCJ0aW1lem9uZSIsImRldGFpbCIsInNoaXBtZW50Iiwib3BlblNoaXBtZW50IiwibW9kZSIsImNsb3NlU2hpcG1lbnQiLCJvY2N1cnJlZEF0SW5zdGFudCIsInZhbGlkT2NjdXJyZW5jZSIsImR1cGxpY2F0ZUV2ZW50SWQiLCJldmVudHMiLCJzb21lIiwiaXRlbSIsImNhblJlY29yZEV2ZW50Iiwic3VibWl0RXZlbnQiLCJ0cmFja2luZ0NvZGUiLCJzaGlwcGluZ0ZlZVF1b3RlIiwic2hpcHBpbmdGZWVBY3R1YWwiLCJfX01PQ0tfXyIsImZ1bGZpbGxtZW50U3RhdGUiLCJ3YXJlaG91c2VJZCIsIm9yZGVyTGluZUlkcyIsImlzUGVuZGluZyIsImxvYWRlZENvdW50IiwiaGFzTW9yZSIsImlzTG9hZGluZ01vcmUiLCJsb2FkTW9yZSIsImlzRXJyb3IiLCJpc0ZldGNoTmV4dFBhZ2VFcnJvciIsImFjdGlvbnNHYXAiLCJpc0xvYWRpbmciLCJhbW91bnQiLCJjdXJyZW5jeSIsInNlY3Rpb25CZWZvcmUiLCJ0eXBlIiwiY2hhbmdlIiwib3B0aW9uIiwic2hpcHBpbmdab25lcyIsInNlcnZpY2VhYmxlIiwiYmFzZUZlZXMiLCJzbWFsbCIsIm1lZGl1bSIsImxhcmdlIiwicGFja2FnZVNpemVzIiwiU2hpcHBpbmdRdW90ZVByZXZpZXciLCJfczQiLCJ6b25lSWQiLCJzZXRab25lSWQiLCJzaXplSWQiLCJzZXRTaXplSWQiLCJhZGRyZXNzUmVhZHkiLCJzZXRBZGRyZXNzUmVhZHkiLCJxdW90ZUN1cnJlbnQiLCJzZXRRdW90ZUN1cnJlbnQiLCJ6b25lIiwieHMiLCJzbSIsImZsZXgiLCJtaW5XaWR0aCIsImNoZWNrZWQiLCJ0b0xvY2FsZVN0cmluZyIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpb25Hcm91cCwgRmllbGRHcm91cCwgRm9ybUZpZWxkcywgUGFnZVNlY3Rpb25zIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBDaGVja2JveCwgRm9ybUNvbnRyb2xMYWJlbCwgTWVudUl0ZW0sIFN0YWNrLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcclxuaW1wb3J0IHR5cGUgeyBTaGlwbWVudEV2ZW50V3JpdGUgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcclxuaW1wb3J0IHsgdXNlQXBpLCB1c2VQYWdlZEFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZVNjb3BlIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xyXG5pbXBvcnQgeyB1c2VMaXN0UXVlcnkgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcclxuaW1wb3J0IHsgbGltaXRDb2RlUG9pbnRzLCBjb2RlUG9pbnRMZW5ndGgsIGRhdGVUaW1lLCBkYXRlVGltZUxvY2FsSW5wdXQsIGRhdGVUaW1lTG9jYWxUb0lTT1N0cmluZyB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XHJcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcclxuaW1wb3J0IHsgQW1vdW50LCBQYWdlSGVhZGVyLCBQYW5lbCwgRGF0YVRhYmxlLCBRdWVyeVN0YXRlLCBUb29sYmFyLCBQYWdlciwgU3RhdHVzLCBNdXRhdGlvbkJ1dHRvbiwgRWRpdERpYWxvZywgRXJyb3JOb3RpY2UsIENvbmZpcm1EaWFsb2csIFJvdXRlTGluaywgRGV0YWlsTGluZSwgTG9va3VwTG9hZE1vcmUgfSBmcm9tICdAL3NoYXJlZC91aS9jb21wb25lbnRzJztcclxuXHJcbnR5cGUgU2hpcG1lbnREaWFsb2dNb2RlID0gJ3ZpZXcnIHwgJ2hhbmRvdmVyJyB8ICdldmVudCc7XHJcblxyXG5jb25zdCBzaGlwbWVudEV2ZW50T3B0aW9uczogQXJyYXk8eyB2YWx1ZTogU2hpcG1lbnRFdmVudFdyaXRlWydldmVudFR5cGUnXTsgbGFiZWw6IHN0cmluZyB9PiA9IFtcclxuICAgIHsgdmFsdWU6ICdpbl90cmFuc2l0JywgbGFiZWw6ICfEkGFuZyB24bqtbiBjaHV54buDbicgfSxcclxuICAgIHsgdmFsdWU6ICdkZWxpdmVyZWQnLCBsYWJlbDogJ0tow6FjaCDEkcOjIG5o4bqtbiBow6BuZycgfSxcclxuICAgIHsgdmFsdWU6ICdmYWlsZWQnLCBsYWJlbDogJ0dpYW8gdGjhuqV0IGLhuqFpJyB9LFxyXG4gICAgeyB2YWx1ZTogJ3JldHVybmluZycsIGxhYmVsOiAnxJBhbmcgaG/DoG4gduG7gScgfSxcclxuICAgIHsgdmFsdWU6ICdyZXR1cm5lZCcsIGxhYmVsOiAnxJDDoyBob8OgbiB24buBJyB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEZ1bGZpbGxtZW50UGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IHF1ZXJ5ID0gdXNlTGlzdFF1ZXJ5KCdsaXN0UHJlcEpvYnMnKTtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RQcmVwSm9icycsIHsgcXVlcnkgfSk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiQ2h14bqpbiBi4buLIGjDoG5nXCIgc3VidGl0bGU9XCJOaOG6rW4gdmnhu4djLCBs4bqleSDEkcO6bmcgU0tVLCBraeG7g20gxJHhu6cgc+G7kSBsxrDhu6NuZyBy4buTaSDEkcOzbmcgZ8OzaS5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9zaGlwbWVudHNgfT5W4bqtbiDEkcahbiAmIGLDoG4gZ2lhbzwvUm91dGVMaW5rPn0gLz5cclxuICAgICAgICA8UGFuZWw+XHJcbiAgICAgICAgICAgIDxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RQcmVwSm9ic1wiIC8+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIHtsaXN0LmRhdGEgJiYgPD5cclxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiQ8O0bmcgdmnhu4djIGNodeG6qW4gYuG7iyDEkcahblwiIHJvd3M9e2xpc3QuZGF0YS5kYXRhfSByb3dLZXk9e3ByZXAgPT4gcHJlcC5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ29yZGVyJywgbGFiZWw6ICfEkMahbiBow6BuZycsIHJlbmRlcjogcHJlcCA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9vcmRlcnMvJHtwcmVwLm9yZGVySWR9YH0+TcOjIMSRxqFuOiB7cHJlcC5vcmRlcklkfTwvUm91dGVMaW5rPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdHaWFpIMSRb+G6oW4nLCByZW5kZXI6IHByZXAgPT4gPFN0YXR1cyB2YWx1ZT17cHJlcC5zdGF0ZX0gLz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdpdGVtcycsIGxhYmVsOiAnRMOybmcgaMOgbmcnLCByZW5kZXI6IHByZXAgPT4gYCR7cHJlcC5saW5lcy5maWx0ZXIobGluZSA9PiBsaW5lLnJlcXVpcmVkUXVhbnRpdHkgPT09IGxpbmUucGlja2VkUXVhbnRpdHkgJiYgIWxpbmUuaGFzSXNzdWUpLmxlbmd0aH0vJHtwcmVwLmxpbmVzLmxlbmd0aH0gxJHDoyBraeG7g20gxJHhu6dgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnYXNzaWduZWQnLCBsYWJlbDogJ05nxrDhu51pIG5o4bqtbicsIHJlbmRlcjogcHJlcCA9PiBwcmVwLmFzc2lnbmVlVXNlcklkIHx8ICdDaMawYSBjw7MnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHByZXAgPT4gPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZChwcmVwLmlkKX0+TeG7nyBwaGnhur91IGzhuqV5IGjDoG5nPC9CdXR0b24+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICA8Lz59XHJcbiAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgIHtzZWxlY3RlZCAmJiA8UHJlcERpYWxvZyByZXNvdXJjZUlkPXtzZWxlY3RlZH0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IC8+fVxyXG4gICAgPC8+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBQcmVwRGlhbG9nKHsgcmVzb3VyY2VJZCwgb25DbG9zZSB9OiB7IHJlc291cmNlSWQ6IHN0cmluZzsgb25DbG9zZTogKCkgPT4gdm9pZCB9KSB7XHJcbiAgICBjb25zdCB7IHNob3AsIHNlc3Npb24sIG1lbWJlcnNoaXAgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBnZXQgPSB1c2VBcGkoJ2dldFByZXBKb2InLCB7IHBhdGg6IHsgcmVzb3VyY2VJZCB9IH0pO1xyXG4gICAgY29uc3QgcHJlcCA9IGdldC5kYXRhPy5kYXRhO1xyXG4gICAgY29uc3QgdGFzayA9IHVzZUFwaSgnZ2V0V29ya0l0ZW0nLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogcHJlcD8ud29ya0l0ZW1JZCB8fCAncGVuZGluZycgfSB9LCAhIXByZXApO1xyXG4gICAgY29uc3Qgd29ya0l0ZW0gPSB0YXNrLmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBjbGFpbSA9IHVzZUNvbW1hbmQoJ2NsYWltV29ya0l0ZW0nLCBbJ2dldFdvcmtJdGVtJywgJ2dldFByZXBKb2InLCAnbGlzdFdvcmtJdGVtcycsICdsaXN0UHJlcEpvYnMnXSk7XHJcbiAgICBjb25zdCBwaWNrID0gdXNlQ29tbWFuZCgncGlja1ByZXBMaW5lJywgWydnZXRQcmVwSm9iJywgJ2xpc3RQcmVwSm9icyddKTtcclxuICAgIGNvbnN0IHBhY2sgPSB1c2VDb21tYW5kKCdwYWNrUHJlcEpvYicsIFsnZ2V0UHJlcEpvYicsICdsaXN0UHJlcEpvYnMnLCAnZ2V0T3JkZXInLCAnbGlzdE9yZGVycyddKTtcclxuICAgIGNvbnN0IFtzY2Fucywgc2V0U2NhbnNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xyXG4gICAgY29uc3QgW3F1YW50aXRpZXMsIHNldFF1YW50aXRpZXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xyXG4gICAgY29uc3QgW2lzc3Vlcywgc2V0SXNzdWVzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcclxuICAgIGNvbnN0IFtwYWNraW5nLCBzZXRQYWNraW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtkcmFmdENvbW1pdCwgc2V0RHJhZnRDb21taXRdID0gdXNlU3RhdGU8eyBzY29wZTogc3RyaW5nOyBzZXF1ZW5jZTogbnVtYmVyIH0+KCk7XHJcbiAgICBjb25zdCBhc3NpZ25lZCA9IHdvcmtJdGVtPy5hc3NpZ25lZVVzZXJJZCA9PT0gc2Vzc2lvbi51c2VyLmlkO1xyXG4gICAgY29uc3QgbWF5Q2xhaW0gPSBtZW1iZXJzaGlwLnBlcm1pc3Npb25zLmluY2x1ZGVzKCdvcGVyYXRpb25zLmNsYWltJyk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFzc2lnbm1lbnQoKSB7XHJcbiAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW2dldC5yZWZldGNoKCksIHRhc2sucmVmZXRjaCgpXSk7XHJcbiAgICAgICAgY2xhaW0ucmVzZXRBZnRlclJlY29uY2lsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxFZGl0RGlhbG9nIG9wZW4gdGl0bGU9e2BQaGnhur91IGNodeG6qW4gYuG7iyAke3ByZXA/Lm9yZGVySWQgfHwgJyd9YH0gb25DbG9zZT17b25DbG9zZX0gYnVzeT17cGljay5wZW5kaW5nIHx8IGNsYWltLnBlbmRpbmd9IGRyYWZ0Q29tbWl0PXtkcmFmdENvbW1pdH0gYWN0aW9ucz17KHsgcmVxdWVzdENsb3NlLCBidXN5IH0pID0+IDxCdXR0b24gZGlzYWJsZWQ9e2J1c3l9IG9uQ2xpY2s9e3JlcXVlc3RDbG9zZX0+xJDDs25nPC9CdXR0b24+fT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjbGFpbS5lcnJvciB8fCBwaWNrLmVycm9yIHx8IHRhc2suZXJyb3J9IC8+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtnZXR9PlxyXG4gICAgICAgICAgICAgICAge3ByZXAgJiYgPEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXMgdmFsdWU9e3ByZXAuc3RhdGV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy8ke3ByZXAub3JkZXJJZH1gfT5DaGkgdGnhur90IMSRxqFuPC9Sb3V0ZUxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgICAgICB7cHJlcC5zdGF0ZSA9PT0gJ3F1ZXVlZCcgJiYgbWF5Q2xhaW0gJiYgd29ya0l0ZW0/LmFsbG93ZWRBY3Rpb25zLmluY2x1ZGVzKCdjbGFpbScpICYmIDxNdXRhdGlvbkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uPVwib3BlcmF0aW9ucy5jbGFpbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93ZWRBY3Rpb25zPXt3b3JrSXRlbS5hbGxvd2VkQWN0aW9uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uPVwiY2xhaW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnVzeT17Y2xhaW0ucGVuZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF3b3JrSXRlbSB8fCB3b3JrSXRlbS5zdGF0ZSAhPT0gJ3F1ZXVlZCcgfHwgISF3b3JrSXRlbS5hc3NpZ25lZVVzZXJJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF3b3JrSXRlbSkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm9pZCBjbGFpbS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBwcmVwLndvcmtJdGVtSWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHdvcmtJdGVtLnZlcnNpb24gfSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5Uw7RpIG5o4bqtbiBjaHXhuqluIGLhu4sgxJHGoW48L011dGF0aW9uQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgICAgICB7cHJlcC5zdGF0ZSA9PT0gJ3F1ZXVlZCcgJiYgIW1heUNsYWltICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5WYWkgdHLDsiBoaeG7h24gdOG6oWkga2jDtG5nIGPDsyBxdXnhu4FuIG5o4bqtbiBjw7RuZyB2aeG7h2MgY2h14bqpbiBi4buLIG7DoHkuPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICAgICAge3ByZXAuc3RhdGUgPT09ICdxdWV1ZWQnICYmIG1heUNsYWltICYmIHdvcmtJdGVtICYmICF3b3JrSXRlbS5hbGxvd2VkQWN0aW9ucy5pbmNsdWRlcygnY2xhaW0nKSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+Q8O0bmcgdmnhu4djIMSRw6MgxJHhu5VpIHRy4bqhbmcgdGjDoWkgaG/hurdjIMSRw6MgY8OzIG5nxrDhu51pIG5o4bqtbi4gVOG6o2kgbOG6oWkgcGhp4bq/dSDEkeG7gyB4ZW0gbmfGsOG7nWkgcGjhu6UgdHLDoWNoIG3hu5tpLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtwcmVwLnN0YXRlID09PSAncXVldWVkJyAmJiBjbGFpbS5lcnJvciAmJiA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVmcmVzaEFzc2lnbm1lbnQoKX0+VOG6o2kgbOG6oWkgdHLhuqFuZyB0aMOhaTwvQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgICAgICB7IWFzc2lnbmVkICYmIHByZXAuc3RhdGUgIT09ICdxdWV1ZWQnICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5QaGnhur91IMSRYW5nIGRvIHt3b3JrSXRlbT8uYXNzaWduZWVVc2VySWQgfHwgcHJlcC5hc3NpZ25lZVVzZXJJZCB8fCAnbmjDom4gdmnDqm4ga2jDoWMnfSBwaOG7pSB0csOhY2guPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICAgICAge3ByZXAubGluZXMubWFwKGxpbmUgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzY2FuID0gc2NhbnNbbGluZS5vcmRlckxpbmVJZF0gfHwgJyc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHF1YW50aXR5ID0gcXVhbnRpdGllc1tsaW5lLm9yZGVyTGluZUlkXSA/PyBTdHJpbmcobGluZS5waWNrZWRRdWFudGl0eSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHF1YW50aXR5SXNWYWxpZCA9IC9eXFxkKyQvLnRlc3QocXVhbnRpdHkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmJiBOdW1iZXIuaXNJbnRlZ2VyKE51bWJlcihxdWFudGl0eSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmJiBOdW1iZXIocXVhbnRpdHkpID49IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmIE51bWJlcihxdWFudGl0eSkgPD0gbGluZS5yZXF1aXJlZFF1YW50aXR5O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc3N1ZSA9IGlzc3Vlc1tsaW5lLm9yZGVyTGluZUlkXSB8fCAnJztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FuRWRpdCA9IGFzc2lnbmVkICYmIFsnY2xhaW1lZCcsICdwaWNraW5nJ10uaW5jbHVkZXMocHJlcC5zdGF0ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPEJveCBrZXk9e2xpbmUub3JkZXJMaW5lSWR9IGRhdGEtZHJhZnQtc2NvcGU9e2xpbmUub3JkZXJMaW5lSWR9IHN4PXt7IC4uLmxheW91dFN4LnN1cmZhY2UuaW5zZXQsIGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6ICdkaXZpZGVyJywgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuZGlhbG9nIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIHN4PXtsYXlvdXRTeC5zdXJmYWNlLmhlYWRlckZsb3dHYXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmd9PntsaW5lLnNrdX08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHk+e2xpbmUucGlja2VkUXVhbnRpdHl9L3tsaW5lLnJlcXVpcmVkUXVhbnRpdHl9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5lLmhhc0lzc3VlICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIiBzeD17bGF5b3V0U3gubm90aWNlLmNvbnRlbnRHYXB9PkTDsm5nIGjDoG5nIGPDsm4gduG6pW4gxJHhu4EgY+G6p24geOG7rSBsw70uPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyBiZWZvcmVHYXA9XCJzdXJmYWNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk5o4bqtcC9xdcOpdCBTS1UgdGjhu7FjIHThur9cIiB2YWx1ZT17c2Nhbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFNjYW5zKGN1cnJlbnQgPT4gKHsgLi4uY3VycmVudCwgW2xpbmUub3JkZXJMaW5lSWRdOiBsaW1pdENvZGVQb2ludHMoZXZlbnQudGFyZ2V0LnZhbHVlLCAxMDApIH0pKX0gZGlzYWJsZWQ9eyFjYW5FZGl0fSAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiU+G7kSBsxrDhu6NuZyDEkcOjIGzhuqV5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0UHJvcHM9e3sgbWluOiAwLCBtYXg6IGxpbmUucmVxdWlyZWRRdWFudGl0eSwgc3RlcDogMSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cXVhbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yPXshcXVhbnRpdHlJc1ZhbGlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXshcXVhbnRpdHlJc1ZhbGlkID8gYE5o4bqtcCBz4buRIG5ndXnDqm4gdOG7qyAwIMSR4bq/biAke2xpbmUucmVxdWlyZWRRdWFudGl0eX0uYCA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2V2ZW50ID0+IHNldFF1YW50aXRpZXMoY3VycmVudCA9PiAoeyAuLi5jdXJyZW50LCBbbGluZS5vcmRlckxpbmVJZF06IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuRWRpdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJW4bqlbiDEkeG7gSBwaMOhdCBoaeG7h24gKMSR4buDIHRy4buRbmcga2hpIMSR4bqhdClcIiB2YWx1ZT17aXNzdWV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRJc3N1ZXMoY3VycmVudCA9PiAoeyAuLi5jdXJyZW50LCBbbGluZS5vcmRlckxpbmVJZF06IGxpbWl0Q29kZVBvaW50cyhldmVudC50YXJnZXQudmFsdWUsIDEwMDApIH0pKX0gZGlzYWJsZWQ9eyFjYW5FZGl0fSAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbj1cImZ1bGZpbGxtZW50LndyaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVzeT17cGljay5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbkVkaXQgfHwgIXNjYW4udHJpbSgpIHx8ICFxdWFudGl0eUlzVmFsaWQgfHwgY29kZVBvaW50TGVuZ3RoKGlzc3VlKSA+IDEwMDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgcGljay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkIH0sIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkVmVyc2lvbjogcHJlcC52ZXJzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXJMaW5lSWQ6IGxpbmUub3JkZXJMaW5lSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzY2FubmVkU2t1OiBzY2FuLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpY2tlZFF1YW50aXR5OiBOdW1iZXIocXVhbnRpdHkpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNzdWVSZWFzb246IGlzc3VlLnRyaW0oKSB8fCBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IH0pLnRoZW4oKCkgPT4gc2V0RHJhZnRDb21taXQoY3VycmVudCA9PiAoeyBzY29wZTogbGluZS5vcmRlckxpbmVJZCwgc2VxdWVuY2U6IChjdXJyZW50Py5zZXF1ZW5jZSB8fCAwKSArIDEgfSkpKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5Yw6FjIG5o4bqtbiBkw7JuZyDEkcOjIGtp4buDbTwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PjtcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbj1cImZ1bGZpbGxtZW50LndyaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshYXNzaWduZWQgfHwgcHJlcC5zdGF0ZSAhPT0gJ3BpY2tpbmcnIHx8ICFwcmVwLmxpbmVzLmV2ZXJ5KGxpbmUgPT4gbGluZS5waWNrZWRRdWFudGl0eSA9PT0gbGluZS5yZXF1aXJlZFF1YW50aXR5ICYmICFsaW5lLmhhc0lzc3VlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFja2luZyh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+WMOhYyBuaOG6rW4gxJHDoyDEkcOzbmcgZ8OzaTwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAge3ByZXAuc3RhdGUgPT09ICdwaWNraW5nJyAmJiAhcHJlcC5saW5lcy5ldmVyeShsaW5lID0+IGxpbmUucGlja2VkUXVhbnRpdHkgPT09IGxpbmUucmVxdWlyZWRRdWFudGl0eSAmJiAhbGluZS5oYXNJc3N1ZSkgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkNoxrBhIHRo4buDIMSRw7NuZyBnw7NpOiBj4bqnbiBs4bqleSDEkeG7pyB04burbmcgZMOybmcgdsOgIHjhu60gbMO9IG3hu41pIHbhuqVuIMSR4buBIHRyxrDhu5tjLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtwcmVwLnN0YXRlID09PSAncGFja2VkJyAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9zaGlwbWVudHM/b3JkZXJJZD0ke3ByZXAub3JkZXJJZH1gfT5U4bqhbyB24bqtbiDEkcahbiDEkeG7gyBiw6BuIGdpYW88L1JvdXRlTGluaz59XHJcbiAgICAgICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkPDoWMgbsO6dCBs4bqleS/EkcOzbmcgZ8OzaSBsw6AgeMOhYyBuaOG6rW4gY+G7p2EgbmfGsOG7nWkgdGjhuq10LiBI4buHIHRo4buRbmcga2jDtG5nIHThu7Egbmjhuq1uIGPDtG5nIHZp4buHYyB24bqtdCBsw70gxJHDoyBob8OgbiB04bqldC48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPn1cclxuICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxyXG4gICAgICAgIDwvRWRpdERpYWxvZz5cclxuICAgICAgICA8Q29uZmlybURpYWxvZ1xyXG4gICAgICAgICAgICBvcGVuPXtwYWNraW5nfVxyXG4gICAgICAgICAgICB0aXRsZT1cIkhvw6BuIHThuqV0IMSRw7NuZyBnw7NpXCJcclxuICAgICAgICAgICAgY29uZmlybUxhYmVsPVwiWMOhYyBuaOG6rW4gxJHDoyDEkcOzbmcgZ8OzaVwiIGRlc2NyaXB0aW9uPXtgQ8O0bmcgdmnhu4djICR7cmVzb3VyY2VJZH0sIMSRxqFuICR7cHJlcD8ub3JkZXJJZCB8fCBcIlwifTogeMOhYyBuaOG6rW4gxJHDoyBraeG7g20gxJHhu6cgU0tVLCBz4buRIGzGsOG7o25nIHbDoCDEkcOzbmcgZ8OzaSB0aOG7sWMgdOG6vy4gQsaw4bubYyB0aeG6v3AgdGhlbyBsw6AgYsOgbiBnaWFvIGtp4buHbjsgY2jGsGEgeMOhYyBuaOG6rW4gxJHDoyBnaWFvIGNobyBraMOhY2guYH1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UGFja2luZyhmYWxzZSl9XHJcbiAgICAgICAgICAgIGJ1c3k9e3BhY2sucGVuZGluZ31cclxuICAgICAgICAgICAgZXJyb3I9e3BhY2suZXJyb3J9XHJcbiAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gcGFjay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBwcmVwPy52ZXJzaW9uIHx8IDEgfSB9KX1cclxuICAgICAgICAvPlxyXG4gICAgPC8+O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2hpcG1lbnRzUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XHJcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0U2hpcG1lbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0U2hpcG1lbnRzJykgfSk7XHJcbiAgICBjb25zdCBbcHJldmlld09wZW4sIHNldFByZXZpZXdPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtvcmRlclNlYXJjaElucHV0LCBzZXRPcmRlclNlYXJjaElucHV0XSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtvcmRlclNlYXJjaCwgc2V0T3JkZXJTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldE9yZGVyU2VhcmNoKG9yZGVyU2VhcmNoSW5wdXQudHJpbSgpKSwgMjUwKTtcclxuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9LCBbb3JkZXJTZWFyY2hJbnB1dF0pO1xyXG4gICAgY29uc3Qgb3JkZXJzID0gdXNlUGFnZWRBcGkoJ2xpc3RPcmRlcnMnLCB7IHF1ZXJ5OiB7IHE6IG9yZGVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0pO1xyXG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlU2hpcG1lbnQnLCBbJ2xpc3RTaGlwbWVudHMnLCAnbGlzdE9yZGVycyddKTtcclxuICAgIGNvbnN0IGhhbmRvdmVyID0gdXNlQ29tbWFuZCgnaGFuZG92ZXJTaGlwbWVudCcsIFsnZ2V0U2hpcG1lbnQnLCAnbGlzdFNoaXBtZW50cycsICdsaXN0T3JkZXJzJywgJ2xpc3RTdG9ja1NuYXBzaG90cycsICdsaXN0U3RvY2tNb3ZlbWVudHMnLCAnbGlzdFByZXBKb2JzJywgJ2xpc3RXb3JrSXRlbXMnXSk7XHJcbiAgICBjb25zdCBldmVudCA9IHVzZUNvbW1hbmQoJ3JlY29yZFNoaXBtZW50RXZlbnQnLCBbJ2dldFNoaXBtZW50JywgJ2xpc3RTaGlwbWVudHMnLCAnbGlzdE9yZGVycycsICdsaXN0RGVidEl0ZW1zJywgJ2dldFByb2ZpdExvc3MnLCAnZ2V0RGFzaGJvYXJkJ10pO1xyXG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW29yZGVySWQsIHNldE9yZGVySWRdID0gdXNlU3RhdGUoKCkgPT4gc2VhcmNoUGFyYW1zLmdldCgnb3JkZXJJZCcpIHx8ICcnKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkT3JkZXJEZXRhaWwgPSB1c2VBcGkoJ2dldE9yZGVyJywgeyBwYXRoOiB7IG9yZGVySWQgfSB9LCAhIW9yZGVySWQpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRPcmRlciA9IG9yZGVycy5kYXRhPy5kYXRhLmZpbmQob3JkZXIgPT4gb3JkZXIuaWQgPT09IG9yZGVySWQpIHx8IHNlbGVjdGVkT3JkZXJEZXRhaWwuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IFtjYXJyaWVySWQsIHNldENhcnJpZXJJZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRTaGlwbWVudElkLCBzZXRTZWxlY3RlZFNoaXBtZW50SWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbZGlhbG9nTW9kZSwgc2V0RGlhbG9nTW9kZV0gPSB1c2VTdGF0ZTxTaGlwbWVudERpYWxvZ01vZGU+KCd2aWV3Jyk7XHJcbiAgICBjb25zdCBbZXZlbnRUeXBlLCBzZXRFdmVudFR5cGVdID0gdXNlU3RhdGU8U2hpcG1lbnRFdmVudFdyaXRlWydldmVudFR5cGUnXT4oJ2luX3RyYW5zaXQnKTtcclxuICAgIGNvbnN0IFtleHRlcm5hbEV2ZW50SWQsIHNldEV4dGVybmFsRXZlbnRJZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbZXZpZGVuY2VSZWYsIHNldEV2aWRlbmNlUmVmXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtvY2N1cnJlZEF0LCBzZXRPY2N1cnJlZEF0XSA9IHVzZVN0YXRlKCgpID0+IGRhdGVUaW1lTG9jYWxJbnB1dChuZXcgRGF0ZSgpLCBzaG9wLnRpbWV6b25lKSk7XHJcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldFNoaXBtZW50JywgeyBwYXRoOiB7IHJlc291cmNlSWQ6IHNlbGVjdGVkU2hpcG1lbnRJZCB8fCAncGVuZGluZycgfSB9LCAhIXNlbGVjdGVkU2hpcG1lbnRJZCk7XHJcbiAgICBjb25zdCBzaGlwbWVudCA9IGRldGFpbC5kYXRhPy5kYXRhO1xyXG5cclxuICAgIGZ1bmN0aW9uIG9wZW5TaGlwbWVudChpZDogc3RyaW5nLCBtb2RlOiBTaGlwbWVudERpYWxvZ01vZGUpIHtcclxuICAgICAgICBzZXRTZWxlY3RlZFNoaXBtZW50SWQoaWQpO1xyXG4gICAgICAgIHNldERpYWxvZ01vZGUobW9kZSk7XHJcbiAgICAgICAgc2V0RXZlbnRUeXBlKCdpbl90cmFuc2l0Jyk7XHJcbiAgICAgICAgc2V0RXh0ZXJuYWxFdmVudElkKCcnKTtcclxuICAgICAgICBzZXRFdmlkZW5jZVJlZignJyk7XHJcbiAgICAgICAgc2V0T2NjdXJyZWRBdChkYXRlVGltZUxvY2FsSW5wdXQobmV3IERhdGUoKSwgc2hvcC50aW1lem9uZSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGNsb3NlU2hpcG1lbnQoKSB7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRTaGlwbWVudElkKG51bGwpO1xyXG4gICAgICAgIHNldERpYWxvZ01vZGUoJ3ZpZXcnKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBvY2N1cnJlZEF0SW5zdGFudCA9IGRhdGVUaW1lTG9jYWxUb0lTT1N0cmluZyhvY2N1cnJlZEF0LCBzaG9wLnRpbWV6b25lKTtcclxuICAgIGNvbnN0IHZhbGlkT2NjdXJyZW5jZSA9IG9jY3VycmVkQXRJbnN0YW50ICE9PSBudWxsO1xyXG4gICAgY29uc3QgZHVwbGljYXRlRXZlbnRJZCA9ICEhc2hpcG1lbnQ/LmV2ZW50cy5zb21lKGl0ZW0gPT4gaXRlbS5leHRlcm5hbEV2ZW50SWQgPT09IGV4dGVybmFsRXZlbnRJZC50cmltKCkpO1xyXG4gICAgY29uc3QgY2FuUmVjb3JkRXZlbnQgPSAhIXNoaXBtZW50XHJcbiAgICAgICAgJiYgIVsncGxhbm5lZCcsICdjYW5jZWxsZWQnLCAncmV0dXJuZWQnXS5pbmNsdWRlcyhzaGlwbWVudC5zdGF0ZSlcclxuICAgICAgICAmJiBleHRlcm5hbEV2ZW50SWQudHJpbSgpLmxlbmd0aCA+IDBcclxuICAgICAgICAmJiBjb2RlUG9pbnRMZW5ndGgoZXh0ZXJuYWxFdmVudElkLnRyaW0oKSkgPD0gMTYwXHJcbiAgICAgICAgJiYgZXZpZGVuY2VSZWYudHJpbSgpLmxlbmd0aCA+IDBcclxuICAgICAgICAmJiB2YWxpZE9jY3VycmVuY2VcclxuICAgICAgICAmJiAhZHVwbGljYXRlRXZlbnRJZDtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzdWJtaXRFdmVudCgpIHtcclxuICAgICAgICBpZiAoIXNoaXBtZW50IHx8ICFjYW5SZWNvcmRFdmVudCB8fCAhb2NjdXJyZWRBdEluc3RhbnQpIHJldHVybjtcclxuICAgICAgICBhd2FpdCBldmVudC5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBzaGlwbWVudC5pZCB9LCBib2R5OiB7XHJcbiAgICAgICAgICAgIGV4cGVjdGVkVmVyc2lvbjogc2hpcG1lbnQudmVyc2lvbixcclxuICAgICAgICAgICAgZXh0ZXJuYWxFdmVudElkOiBleHRlcm5hbEV2ZW50SWQudHJpbSgpLFxyXG4gICAgICAgICAgICBldmVudFR5cGUsXHJcbiAgICAgICAgICAgIG9jY3VycmVkQXQ6IG9jY3VycmVkQXRJbnN0YW50LFxyXG4gICAgICAgICAgICBldmlkZW5jZVJlZjogZXZpZGVuY2VSZWYudHJpbSgpLFxyXG4gICAgICAgIH0gfSk7XHJcbiAgICAgICAgY2xvc2VTaGlwbWVudCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiVuG6rW4gxJHGoW4gJiBnaWFvIGjDoG5nXCIgc3VidGl0bGU9XCJCw6BuIGdpYW8gaMOgbmcsIGtow6FjaCBuaOG6rW4gaMOgbmcgdsOgIHRp4buBbiB24buBIGzDoCBiYSBz4buxIGtp4buHbiBraMOhYyBuaGF1LlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZnVsZmlsbG1lbnQud3JpdGVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0+VOG6oW8gduG6rW4gxJHGoW48L011dGF0aW9uQnV0dG9uPn0gLz5cclxuICAgICAgICA8UGFnZVNlY3Rpb25zPlxyXG4gICAgICAgICAgICA8UGFuZWw+XHJcbiAgICAgICAgICAgICAgICA8VG9vbGJhciBvcGVyYXRpb249XCJsaXN0U2hpcG1lbnRzXCIgLz5cclxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICB7bGlzdC5kYXRhICYmIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJEYW5oIHPDoWNoIHbhuq1uIMSRxqFuXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17aXRlbSA9PiBpdGVtLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ1bhuq1uIMSRxqFuJywgcmVuZGVyOiBpdGVtID0+IDxTdGFjaz48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT57aXRlbS50cmFja2luZ0NvZGUgfHwgaXRlbS5pZH08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57aXRlbS5jYXJyaWVySWQgPyBgTcOjIMSRxqFuIHbhu4sgduG6rW4gY2h1eeG7g246ICR7aXRlbS5jYXJyaWVySWR9YCA6ICdHaWFvIHRo4bunIGPDtG5nJ308L1R5cG9ncmFwaHk+PC9TdGFjaz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdvcmRlcicsIGxhYmVsOiAnxJDGoW4nLCByZW5kZXI6IGl0ZW0gPT4gPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vb3JkZXJzLyR7aXRlbS5vcmRlcklkfWB9Pk3DoyDEkcahbjoge2l0ZW0ub3JkZXJJZH08L1JvdXRlTGluaz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogaXRlbSA9PiA8U3RhdHVzIHZhbHVlPXtpdGVtLnN0YXRlfSAvPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3F1b3RlJywgbGFiZWw6ICdQaMOtIGLDoW8gZ2nDoScsIHJlbmRlcjogaXRlbSA9PiA8QW1vdW50IHZhbHVlPXtpdGVtLnNoaXBwaW5nRmVlUXVvdGV9Lz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhY3R1YWwnLCBsYWJlbDogJ1Bow60gdGjhu7FjIHThur8nLCByZW5kZXI6IGl0ZW0gPT4gPEFtb3VudCB2YWx1ZT17aXRlbS5zaGlwcGluZ0ZlZUFjdHVhbH0vPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdGlvbnMnLCBsYWJlbDogJycsIHJlbmRlcjogaXRlbSA9PiA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiBvcGVuU2hpcG1lbnQoaXRlbS5pZCwgJ3ZpZXcnKX0+Q2hpIHRp4bq/dDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmdWxmaWxsbWVudC5oYW5kb3ZlclwiIGRpc2FibGVkPXshWydwbGFubmVkJywgJ2xhYmVsX3JlYWR5J10uaW5jbHVkZXMoaXRlbS5zdGF0ZSl9IG9uQ2xpY2s9eygpID0+IG9wZW5TaGlwbWVudChpdGVtLmlkLCAnaGFuZG92ZXInKX0+QsOgbiBnaWFvPC9NdXRhdGlvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZnVsZmlsbG1lbnQud3JpdGVcIiBkaXNhYmxlZD17WydwbGFubmVkJywgJ2NhbmNlbGxlZCcsICdyZXR1cm5lZCddLmluY2x1ZGVzKGl0ZW0uc3RhdGUpfSBvbkNsaWNrPXsoKSA9PiBvcGVuU2hpcG1lbnQoaXRlbS5pZCwgJ2V2ZW50Jyl9PkPhuq1wIG5o4bqtdCBow6BuaCB0csOsbmg8L011dGF0aW9uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0FjdGlvbkdyb3VwPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC8+fVxyXG4gICAgICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxyXG4gICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJYZW0gdGjhu60gcGjDrSB2w6AgdsO5bmcgZ2lhbyBow6BuZ1wiIHN1YnRpdGxlPVwiTeG7nyBraGkgY+G6p24ga2nhu4NtIHRyYSBnaWFvIGRp4buHbiBt4bqrdTsgbuG7mWkgZHVuZyBuw6B5IGtow7RuZyB4w6FjIG5o4bqtbiBraOG6oyBuxINuZyBnaWFvIGhv4bq3YyB04bqhbyB24bqtbiDEkcahbi5cIiBib2R5TW9kZT1cImluc2V0XCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIGFyaWEtZXhwYW5kZWQ9e3ByZXZpZXdPcGVufSBhcmlhLWNvbnRyb2xzPVwic2hpcG1lbnQtZmVlLXByZXZpZXdcIiBvbkNsaWNrPXsoKSA9PiBzZXRQcmV2aWV3T3Blbih2YWx1ZSA9PiAhdmFsdWUpfT57cHJldmlld09wZW4gPyAn4bqobiBi4bqjbiB4ZW0gdGjhu60gcGjDrSBnaWFvIGjDoG5nJyA6ICdN4bufIGLhuqNuIHhlbSB0aOG7rSBwaMOtIGdpYW8gaMOgbmcnfTwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJveCBpZD1cInNoaXBtZW50LWZlZS1wcmV2aWV3XCIgcm9sZT1cInJlZ2lvblwiIGFyaWEtbGFiZWw9XCJC4bqjbiB4ZW0gdGjhu60gcGjDrSBnaWFvIGjDoG5nXCIgZGF0YS10ZXN0aWQ9XCJzaGlwbWVudC1mZWUtcHJldmlld1wiIGhpZGRlbj17IXByZXZpZXdPcGVufT5cclxuICAgICAgICAgICAgICAgICAgICB7X19NT0NLX18gPyA8U2hpcHBpbmdRdW90ZVByZXZpZXcgLz4gOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+QVBJIGhp4buHbiBjaOG7iSB0cuG6oyBwaMOtIGLDoW8gZ2nDoS90aOG7sWMgdOG6vyBu4bq/dSDEkcOjIGPDsyB0csOqbiB24bqtbiDEkcahbjsgY2jGsGEgY8OzIHRoYW8gdMOhYyBraeG7g20gdHJhIHbDuW5nIGdpYW8gaG/hurdjIHhpbiBiw6FvIGdpw6EgbeG7m2kuPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICA8L1BhZ2VTZWN0aW9ucz5cclxuXHJcbiAgICAgICAgPEVkaXREaWFsb2dcclxuICAgICAgICAgICAgb3Blbj17b3Blbn1cclxuICAgICAgICAgICAgdGl0bGU9XCJU4bqhbyB24bqtbiDEkcahblwiXHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgICBidXN5PXtjcmVhdGUucGVuZGluZ31cclxuICAgICAgICAgICAgYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFvcmRlcklkIHx8IGNyZWF0ZS5wZW5kaW5nIHx8IHNlbGVjdGVkT3JkZXI/LmZ1bGZpbGxtZW50U3RhdGUgIT09ICdwYWNrZWQnfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvcmRlciA9IHNlbGVjdGVkT3JkZXI/LmZ1bGZpbGxtZW50U3RhdGUgPT09ICdwYWNrZWQnID8gc2VsZWN0ZWRPcmRlciA6IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgIGlmICghb3JkZXIpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7IG9yZGVySWQ6IG9yZGVyLmlkLCB3YXJlaG91c2VJZDogb3JkZXIud2FyZWhvdXNlSWQsIGNhcnJpZXJJZDogY2FycmllcklkLnRyaW0oKSB8fCBudWxsLCBvcmRlckxpbmVJZHM6IG9yZGVyLmxpbmVzLm1hcChsaW5lID0+IGxpbmUuaWQpIH0gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYXRjaCB7IC8qIHRoZSBzaGFyZWQgZXJyb3IgcmVtYWlucyB2aXNpYmxlIGFuZCB0aGUgc2VsZWN0aW9uIGlzIHJldGFpbmVkICovIH1cclxuICAgICAgICAgICAgfX0+VOG6oW8gYuG6o24gduG6rW4gY2h1eeG7g248L0J1dHRvbj59XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0gLz5cclxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgPlxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlTDrG0gxJHGoW4gaMOgbmdcIiB2YWx1ZT17b3JkZXJTZWFyY2hJbnB1dH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldE9yZGVyU2VhcmNoSW5wdXQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gaGVscGVyVGV4dD1cIlTDrG0gdGhlbyBtw6MgxJHGoW47IGvhur90IHF14bqjIHThuqNpIHRoZW8gY3Vyc29yIHThu6sgQVBJLlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIsSQxqFuIMSRw6MgxJHDs25nIGfDs2lcIiB2YWx1ZT17b3JkZXJJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldE9yZGVySWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9e29yZGVycy5pc1BlbmRpbmcgJiYgIW9yZGVycy5kYXRhfT5cclxuICAgICAgICAgICAgICAgICAgICB7b3JkZXJJZCAmJiAhb3JkZXJzLmRhdGE/LmRhdGEuc29tZShvcmRlciA9PiBvcmRlci5pZCA9PT0gb3JkZXJJZCkgJiYgPE1lbnVJdGVtIHZhbHVlPXtvcmRlcklkfT57c2VsZWN0ZWRPcmRlcj8uaWQgfHwgKHNlbGVjdGVkT3JkZXJEZXRhaWwuaXNQZW5kaW5nID8gJ8SQYW5nIHThuqNpIMSRxqFuIMSRw6MgY2jhu41u4oCmJyA6IG9yZGVySWQpfTwvTWVudUl0ZW0+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtvcmRlcnMuZGF0YT8uZGF0YS5maWx0ZXIob3JkZXIgPT4gb3JkZXIuZnVsZmlsbG1lbnRTdGF0ZSA9PT0gJ3BhY2tlZCcpLm1hcChvcmRlciA9PiA8TWVudUl0ZW0ga2V5PXtvcmRlci5pZH0gdmFsdWU9e29yZGVyLmlkfT57b3JkZXIuaWR9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICA8TG9va3VwTG9hZE1vcmUgbGFiZWw9XCLEkcahbiBow6BuZ1wiIGxvYWRlZENvdW50PXtvcmRlcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e29yZGVycy5oYXNNb3JlfSBidXN5PXtvcmRlcnMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17b3JkZXJzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgICAgICB7b3JkZXJzLmlzRXJyb3IgJiYgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cImNvbHVtblwiPjxFcnJvck5vdGljZSBlcnJvcj17b3JkZXJzLmVycm9yfS8+PEJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgKG9yZGVycy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IG9yZGVycy5sb2FkTW9yZSgpIDogb3JkZXJzLnJlZmV0Y2goKSk7IH19PlRo4butIGzhuqFpIGRhbmggc8OhY2ggxJHGoW48L0J1dHRvbj48L0FjdGlvbkdyb3VwPn1cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZE9yZGVyRGV0YWlsLmlzRXJyb3IgJiYgPEVycm9yTm90aWNlIGVycm9yPXtzZWxlY3RlZE9yZGVyRGV0YWlsLmVycm9yfS8+fVxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkT3JkZXIgJiYgc2VsZWN0ZWRPcmRlci5mdWxmaWxsbWVudFN0YXRlICE9PSAncGFja2VkJyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+xJDGoW4gxJHDoyBjaOG7jW4gY2jGsGEg4bufIHRy4bqhbmcgdGjDoWkgxJHDoyDEkcOzbmcgZ8OzaSBuw6puIGNoxrBhIHRo4buDIHThuqFvIHbhuq1uIMSRxqFuLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk3DoyDEkcahbiB24buLIHbhuq1uIGNodXnhu4NuICh0cuG7kW5nID0gdGjhu6cgY8O0bmcpXCIgdmFsdWU9e2NhcnJpZXJJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldENhcnJpZXJJZChsaW1pdENvZGVQb2ludHMoZXZlbnQudGFyZ2V0LnZhbHVlLCAxNjApKX0gIC8+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VuG6rW4gxJHGoW4vbmjDo24gaW4gY+G7p2EgbmjDoCB24bqtbiBjaHV54buDbiBjaOG7iSB4deG6pXQgaGnhu4duIGtoaSBiYWNrZW5kIGPDsyBhZGFwdGVyIMSRw6MgxJHGsOG7o2MgY+G6pXAgcXV54buBbi4gS2jDtG5nIHThu7EgdOG6oW8gbcOjIGdpYW8gaMOgbmcgdGjhuq10LjwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cclxuICAgICAgICA8L0VkaXREaWFsb2c+XHJcblxyXG4gICAgICAgIDxFZGl0RGlhbG9nXHJcbiAgICAgICAgICAgIG9wZW49eyEhc2VsZWN0ZWRTaGlwbWVudElkfVxyXG4gICAgICAgICAgICB0aXRsZT17ZGlhbG9nTW9kZSA9PT0gJ2hhbmRvdmVyJyA/ICdYw6FjIG5o4bqtbiBiw6BuIGdpYW8ga2nhu4duIGjDoG5nJyA6IGRpYWxvZ01vZGUgPT09ICdldmVudCcgPyAnQ+G6rXAgbmjhuq10IGjDoG5oIHRyw6xuaCBjw7MgYuG6sW5nIGNo4bupbmcnIDogJ0NoaSB0aeG6v3QgduG6rW4gxJHGoW4nfVxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj17ZGlhbG9nTW9kZSA9PT0gJ2hhbmRvdmVyJyA/ICdYw6FjIG5o4bqtbiDEkcOjIGLDoG4gZ2lhbyBjaG8gbmfGsOG7nWkgduG6rW4gY2h1eeG7g24uIFZp4buHYyBuw6B5IHh14bqldCBsxrDhu6NuZyBow6BuZyDEkWFuZyBnaeG7rzsga2jDtG5nIMSR4buTbmcgbmdoxKlhIGtow6FjaCDEkcOjIG5o4bqtbiBob+G6t2MgxJHDoyB0aGFuaCB0b8Ohbi4nIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXtjbG9zZVNoaXBtZW50fVxyXG4gICAgICAgICAgICBidXN5PXtoYW5kb3Zlci5wZW5kaW5nIHx8IGV2ZW50LnBlbmRpbmd9XHJcbiAgICAgICAgICAgIGFjdGlvbnM9ezxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBzeD17bGF5b3V0U3guZGlhbG9nLmFjdGlvbnNHYXB9PlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtkaWFsb2dNb2RlID09PSAndmlldycgPyBjbG9zZVNoaXBtZW50IDogKCkgPT4gc2V0RGlhbG9nTW9kZSgndmlldycpfT57ZGlhbG9nTW9kZSA9PT0gJ3ZpZXcnID8gJ8SQw7NuZycgOiAnUXVheSBs4bqhaSd9PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICB7ZGlhbG9nTW9kZSA9PT0gJ3ZpZXcnICYmIHNoaXBtZW50ICYmIFsncGxhbm5lZCcsICdsYWJlbF9yZWFkeSddLmluY2x1ZGVzKHNoaXBtZW50LnN0YXRlKSAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZ1bGZpbGxtZW50LmhhbmRvdmVyXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtkZXRhaWwuaXNMb2FkaW5nfSBvbkNsaWNrPXsoKSA9PiBzZXREaWFsb2dNb2RlKCdoYW5kb3ZlcicpfT5Cw6BuIGdpYW88L011dGF0aW9uQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgIHtkaWFsb2dNb2RlID09PSAndmlldycgJiYgc2hpcG1lbnQgJiYgIVsncGxhbm5lZCcsICdjYW5jZWxsZWQnLCAncmV0dXJuZWQnXS5pbmNsdWRlcyhzaGlwbWVudC5zdGF0ZSkgJiYgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmdWxmaWxsbWVudC53cml0ZVwiIG9uQ2xpY2s9eygpID0+IHNldERpYWxvZ01vZGUoJ2V2ZW50Jyl9PkPhuq1wIG5o4bqtdCBow6BuaCB0csOsbmg8L011dGF0aW9uQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgIHtkaWFsb2dNb2RlID09PSAnaGFuZG92ZXInICYmIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZnVsZmlsbG1lbnQuaGFuZG92ZXJcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17aGFuZG92ZXIucGVuZGluZ30gZGlzYWJsZWQ9eyFzaGlwbWVudCB8fCAhWydwbGFubmVkJywgJ2xhYmVsX3JlYWR5J10uaW5jbHVkZXMoc2hpcG1lbnQuc3RhdGUpfSBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzaGlwbWVudCkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIHZvaWQgaGFuZG92ZXIuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2hpcG1lbnQuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNoaXBtZW50LnZlcnNpb24gfSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoKSA9PiBzZXREaWFsb2dNb2RlKCd2aWV3JykpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgICAgICAgfX0+WMOhYyBuaOG6rW4gYsOgbiBnaWFvPC9NdXRhdGlvbkJ1dHRvbj59XHJcbiAgICAgICAgICAgICAgICB7ZGlhbG9nTW9kZSA9PT0gJ2V2ZW50JyAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZ1bGZpbGxtZW50LndyaXRlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e2V2ZW50LnBlbmRpbmd9IGRpc2FibGVkPXshY2FuUmVjb3JkRXZlbnR9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3VibWl0RXZlbnQoKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpfT5HaGkgc+G7sSBraeG7h248L011dGF0aW9uQnV0dG9uPn1cclxuICAgICAgICAgICAgPC9TdGFjaz59XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2RldGFpbC5lcnJvciB8fCBoYW5kb3Zlci5lcnJvciB8fCBldmVudC5lcnJvcn0gLz5cclxuICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2RldGFpbH0+XHJcbiAgICAgICAgICAgICAgICB7c2hpcG1lbnQgJiYgPFN0YWNrPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiTcOjIHbhuq1uIMSRxqFuXCI+e3NoaXBtZW50LnRyYWNraW5nQ29kZSB8fCBzaGlwbWVudC5pZH08L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCLEkMahbiBow6BuZ1wiPjxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy8ke3NoaXBtZW50Lm9yZGVySWR9YH0+e3NoaXBtZW50Lm9yZGVySWR9PC9Sb3V0ZUxpbms+PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwixJDGoW4gduG7iyB24bqtbiBjaHV54buDblwiPntzaGlwbWVudC5jYXJyaWVySWQgfHwgJ0dpYW8gdGjhu6cgY8O0bmcnfTwvRGV0YWlsTGluZT5cclxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlRy4bqhbmcgdGjDoWlcIj48U3RhdHVzIHZhbHVlPXtzaGlwbWVudC5zdGF0ZX0gLz48L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJQaMOtIGLDoW8gZ2nDoVwiPntzaGlwbWVudC5zaGlwcGluZ0ZlZVF1b3RlID8gYCR7c2hpcG1lbnQuc2hpcHBpbmdGZWVRdW90ZS5hbW91bnR9ICR7c2hpcG1lbnQuc2hpcHBpbmdGZWVRdW90ZS5jdXJyZW5jeX1gIDogJ0NoxrBhIGPDsyd9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiUGjDrSB0aOG7sWMgdOG6v1wiPntzaGlwbWVudC5zaGlwcGluZ0ZlZUFjdHVhbCA/IGAke3NoaXBtZW50LnNoaXBwaW5nRmVlQWN0dWFsLmFtb3VudH0gJHtzaGlwbWVudC5zaGlwcGluZ0ZlZUFjdHVhbC5jdXJyZW5jeX1gIDogJ0NoxrBhIGPDsyd9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIiBzeD17bGF5b3V0U3guc3VyZmFjZS5zZWN0aW9uQmVmb3JlfT5T4buxIGtp4buHbiB24bqtbiBjaHV54buDbjwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICB7c2hpcG1lbnQuZXZlbnRzLmxlbmd0aCA/IHNoaXBtZW50LmV2ZW50cy5tYXAoaXRlbSA9PiA8RGV0YWlsTGluZSBrZXk9e2l0ZW0uZXh0ZXJuYWxFdmVudElkfSBsYWJlbD17YCR7aXRlbS50eXBlfSDCtyAke2l0ZW0uZXh0ZXJuYWxFdmVudElkfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgYWxpZ25JdGVtcz1cImZsZXgtZW5kXCI+PFR5cG9ncmFwaHk+e2RhdGVUaW1lKGl0ZW0ub2NjdXJyZWRBdCwgc2hvcC50aW1lem9uZSl9PC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCI+QuG6sW5nIGNo4bupbmc6IHtpdGVtLmV2aWRlbmNlUmVmIHx8ICdDaMawYSBjw7MnfTwvVHlwb2dyYXBoeT48L1N0YWNrPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRGV0YWlsTGluZT4pIDogPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkNoxrBhIGPDsyBz4buxIGtp4buHbi48L1R5cG9ncmFwaHk+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtkaWFsb2dNb2RlID09PSAnaGFuZG92ZXInICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5I4buHIHRo4buRbmcgZ2hpIG5o4bqtbiBiw6BuIGdpYW8gdsOgIHh14bqldCBow6BuZyDEkWFuZyBnaeG7ryBt4buZdCBs4bqnbi4gVHLhuqFuZyB0aMOhaSBnaWFvIGjDoG5nIHPhur0gY2jhu4kgxJHhu5VpIGtoaSBjw7Mgc+G7sSBraeG7h24gduG6rW4gY2h1eeG7g24gcmnDqm5nLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtkaWFsb2dNb2RlID09PSAnZXZlbnQnICYmIDxGb3JtRmllbGRzIGJlZm9yZUdhcD1cInN1cmZhY2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJT4buxIGtp4buHblwiIHZhbHVlPXtldmVudFR5cGV9IG9uQ2hhbmdlPXtjaGFuZ2UgPT4gc2V0RXZlbnRUeXBlKGNoYW5nZS50YXJnZXQudmFsdWUgYXMgU2hpcG1lbnRFdmVudFdyaXRlWydldmVudFR5cGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NoaXBtZW50RXZlbnRPcHRpb25zLm1hcChvcHRpb24gPT4gPE1lbnVJdGVtIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT57b3B0aW9uLmxhYmVsfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJNw6Mgc+G7sSBraeG7h24gYsOqbiB24bqtbiBjaHV54buDblwiIHZhbHVlPXtleHRlcm5hbEV2ZW50SWR9IG9uQ2hhbmdlPXtjaGFuZ2UgPT4gc2V0RXh0ZXJuYWxFdmVudElkKGxpbWl0Q29kZVBvaW50cyhjaGFuZ2UudGFyZ2V0LnZhbHVlLCAxNjApKX0gIGVycm9yPXtjb2RlUG9pbnRMZW5ndGgoZXh0ZXJuYWxFdmVudElkKSA+IDE2MCB8fCBkdXBsaWNhdGVFdmVudElkfSBoZWxwZXJUZXh0PXtkdXBsaWNhdGVFdmVudElkID8gJ03DoyBz4buxIGtp4buHbiBuw6B5IMSRw6MgxJHGsOG7o2MgZ2hpIG5o4bqtbi4nIDogY29kZVBvaW50TGVuZ3RoKGV4dGVybmFsRXZlbnRJZCkgPiAxNjAgPyAnVOG7kWkgxJFhIDE2MCBrw70gdOG7sS4nIDogdW5kZWZpbmVkfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVGjhu51pIGdpYW4gc+G7sSBraeG7h25cIiB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIiB2YWx1ZT17b2NjdXJyZWRBdH0gb25DaGFuZ2U9e2NoYW5nZSA9PiBzZXRPY2N1cnJlZEF0KGNoYW5nZS50YXJnZXQudmFsdWUpfSBlcnJvcj17ISFvY2N1cnJlZEF0ICYmICF2YWxpZE9jY3VycmVuY2V9IGhlbHBlclRleHQ9eyEhb2NjdXJyZWRBdCAmJiAhdmFsaWRPY2N1cnJlbmNlID8gJ05o4bqtcCBnaeG7nSB04buTbiB04bqhaSB0cm9uZyBtw7ppIGdp4budIGPhu61hIGjDoG5nLicgOiBgR2nhu50gxJHhu4thIHBoxrDGoW5nIHRoZW8gJHtzaG9wLnRpbWV6b25lfTsgc+G6vSBjaHV54buDbiB0aMOgbmggaW5zdGFudCBJU08ga2hpIGfhu61pLmB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJNw6MgYuG6sW5nIGNo4bupbmdcIiB2YWx1ZT17ZXZpZGVuY2VSZWZ9IG9uQ2hhbmdlPXtjaGFuZ2UgPT4gc2V0RXZpZGVuY2VSZWYobGltaXRDb2RlUG9pbnRzKGNoYW5nZS50YXJnZXQudmFsdWUsIDE2MCkpfSAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkdpYW8gdGjDoG5oIGPDtG5nLCB0aOG6pXQgYuG6oWksIGhvw6BuIHbhu4EgdsOgIHRodSB0aeG7gW4gbMOgIGPDoWMgdHLhuqFuZyB0aMOhaSByacOqbmcuIE3hu5dpIHPhu7Ega2nhu4duIGPhuqduIG3DoyBjaOG7kW5nIHRyw7luZyB2w6AgYuG6sW5nIGNo4bupbmcgZG8gbmfGsOG7nWkgeMOhYyBtaW5oIGN1bmcgY+G6pXAuPC9BbGVydD5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+fVxyXG4gICAgICAgICAgICAgICAgPC9TdGFjaz59XHJcbiAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICA8L0VkaXREaWFsb2c+XHJcbiAgICA8Lz47XHJcbn1cclxuXHJcbmNvbnN0IHNoaXBwaW5nWm9uZXMgPSBbXHJcbiAgICB7IGlkOiAnY2l0eScsIGxhYmVsOiAnTuG7mWkgdGjDoG5oICht4bqrdSknLCBzZXJ2aWNlYWJsZTogdHJ1ZSwgYmFzZUZlZXM6IHsgc21hbGw6IDE4MDAwLCBtZWRpdW06IDI0MDAwLCBsYXJnZTogMzIwMDAgfSB9LFxyXG4gICAgeyBpZDogJ3JlZ2lvbmFsJywgbGFiZWw6ICdOZ2/huqFpIHThu4luaCAobeG6q3UpJywgc2VydmljZWFibGU6IHRydWUsIGJhc2VGZWVzOiB7IHNtYWxsOiAzMjAwMCwgbWVkaXVtOiA0MjAwMCwgbGFyZ2U6IDU2MDAwIH0gfSxcclxuICAgIHsgaWQ6ICdvdXRzaWRlJywgbGFiZWw6ICdOZ2/DoGkgdsO5bmcgcGjhu6VjIHbhu6UgKG3huqt1KScsIHNlcnZpY2VhYmxlOiBmYWxzZSwgYmFzZUZlZXM6IG51bGwgfSxcclxuXSBhcyBjb25zdDtcclxuXHJcbmNvbnN0IHBhY2thZ2VTaXplcyA9IFtcclxuICAgIHsgaWQ6ICdzbWFsbCcsIGxhYmVsOiAnR+G7jW4gwrcgMeKAkzIga2cnIH0sXHJcbiAgICB7IGlkOiAnbWVkaXVtJywgbGFiZWw6ICdW4burYSDCtyAy4oCTNSBrZycgfSxcclxuICAgIHsgaWQ6ICdsYXJnZScsIGxhYmVsOiAnTOG7m24gwrcgNeKAkzEwIGtnJyB9LFxyXG5dIGFzIGNvbnN0O1xyXG5cclxuZnVuY3Rpb24gU2hpcHBpbmdRdW90ZVByZXZpZXcoKSB7XHJcbiAgICBjb25zdCBbem9uZUlkLCBzZXRab25lSWRdID0gdXNlU3RhdGU8KHR5cGVvZiBzaGlwcGluZ1pvbmVzKVtudW1iZXJdWydpZCddPignY2l0eScpO1xyXG4gICAgY29uc3QgW3NpemVJZCwgc2V0U2l6ZUlkXSA9IHVzZVN0YXRlPCh0eXBlb2YgcGFja2FnZVNpemVzKVtudW1iZXJdWydpZCddPignc21hbGwnKTtcclxuICAgIGNvbnN0IFthZGRyZXNzUmVhZHksIHNldEFkZHJlc3NSZWFkeV0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICAgIGNvbnN0IFtxdW90ZUN1cnJlbnQsIHNldFF1b3RlQ3VycmVudF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICAgIGNvbnN0IHpvbmUgPSBzaGlwcGluZ1pvbmVzLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSB6b25lSWQpITtcclxuICAgIGNvbnN0IGFtb3VudCA9IHpvbmUuYmFzZUZlZXM/LltzaXplSWRdO1xyXG5cclxuICAgIHJldHVybiA8Rm9ybUZpZWxkcz5cclxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkThu64gTEnhu4ZVIE3DlCBQSOG7jk5HIMK3IFBow60gZMaw4bubaSDEkcOieSBjaOG7iSBtaW5oIGjhu41hIHRy4bqhbmcgdGjDoWkgZ2lhbyBkaeG7h24sIGtow7RuZyBwaOG6o2kgYsOhbyBnacOhIGNobyDEkeG7i2EgY2jhu4kgaG/hurdjIGjDo25nIHbhuq1uIGNodXnhu4NuIHRo4bqtdC48L0FsZXJ0PlxyXG4gICAgICAgICAgICA8RmllbGRHcm91cCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ3N0YXJ0JyB9fT5cclxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiVsO5bmcgZ2lhbyB0aOG7rVwiIHZhbHVlPXt6b25lSWR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRab25lSWQoZXZlbnQudGFyZ2V0LnZhbHVlIGFzIHR5cGVvZiB6b25lSWQpfSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7c2hpcHBpbmdab25lcy5tYXAoaXRlbSA9PiA8TWVudUl0ZW0ga2V5PXtpdGVtLmlkfSB2YWx1ZT17aXRlbS5pZH0+e2l0ZW0ubGFiZWx9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkvDrWNoIGPhu6Ega2nhu4duIHRo4butXCIgdmFsdWU9e3NpemVJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFNpemVJZChldmVudC50YXJnZXQudmFsdWUgYXMgdHlwZW9mIHNpemVJZCl9IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYWNrYWdlU2l6ZXMubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmxhYmVsfTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICA8L0ZpZWxkR3JvdXA+XHJcbiAgICAgICAgICAgIDxGb3JtQ29udHJvbExhYmVsIGxhYmVsPVwiQ8OzIMSR4buLYSBjaOG7iSBnaWFvIGjDoG5nIG3huqt1XCIgY29udHJvbD17PENoZWNrYm94IGNoZWNrZWQ9e2FkZHJlc3NSZWFkeX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEFkZHJlc3NSZWFkeShldmVudC50YXJnZXQuY2hlY2tlZCl9IC8+fSAvPlxyXG4gICAgICAgICAgICA8Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIkLDoW8gZ2nDoSBt4bqrdSBjw7JuIGhp4buHdSBs4buxY1wiIGNvbnRyb2w9ezxDaGVja2JveCBjaGVja2VkPXtxdW90ZUN1cnJlbnR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRRdW90ZUN1cnJlbnQoZXZlbnQudGFyZ2V0LmNoZWNrZWQpfSAvPn0gLz5cclxuICAgICAgICAgICAgeyFhZGRyZXNzUmVhZHlcclxuICAgICAgICAgICAgICAgID8gPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlRoaeG6v3UgxJHhu4thIGNo4buJIGdpYW8gaMOgbmc7IGNoxrBhIHRo4buDIHjDoWMgxJHhu4tuaCB2w7luZyBob+G6t2MgaGnhu4NuIHRo4buLIHBow60uPC9BbGVydD5cclxuICAgICAgICAgICAgICAgIDogIXpvbmUuc2VydmljZWFibGVcclxuICAgICAgICAgICAgICAgICAgICA/IDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5Ww7luZyBt4bqrdSBuw6B5IGtow7RuZyDEkcaw4bujYyBwaOG7pWMgduG7pTsga2jDtG5nIGhp4buDbiB0aOG7iyBiw6FvIGdpw6EgdsOgIGtow7RuZyBo4bupYSBuZ8OgeSBnaWFvLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgOiAhcXVvdGVDdXJyZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkLDoW8gZ2nDoSBt4bqrdSDEkcOjIGjhur90IGhp4buHdSBs4buxYzsgY+G6p24gbOG6pXkgYsOhbyBnacOhIG3hu5tpIHRyxrDhu5tjIGtoaSB4w6FjIG5o4bqtbi48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IDxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIj7Gr+G7m2MgdMOtbmggbeG6q3U6IHthbW91bnQ/LnRvTG9jYWxlU3RyaW5nKCd2aS1WTicpfSBWTkQgwrcge3pvbmUubGFiZWx9IMK3IHtwYWNrYWdlU2l6ZXMuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHNpemVJZCk/LmxhYmVsfTwvQWxlcnQ+fVxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5Ucm9uZyBk4buvIGxp4buHdSB24bqtbiDEkcahbiwgcGjDrSBiw6FvIGdpw6EgdsOgIHBow60gdGjhu7FjIHThur8gxJHGsOG7o2MgdHLDrG5oIGLDoHkgcmnDqm5nLiBC4bqjbiB4ZW0gdHLGsOG7m2MgbsOgeSBraMO0bmcgbMawdSBj4bqldSBow6xuaCB2w7luZywga2jDtG5nIHjDoWMgbmjhuq1uIGto4bqjIG7Eg25nIGdpYW8gdsOgIGtow7RuZyB04bqhbyB24bqtbiDEkcahbi48L1R5cG9ncmFwaHk+XHJcbiAgICA8L0Zvcm1GaWVsZHM+O1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2Z1bGZpbGxtZW50L2luZGV4LnRzeCJ9