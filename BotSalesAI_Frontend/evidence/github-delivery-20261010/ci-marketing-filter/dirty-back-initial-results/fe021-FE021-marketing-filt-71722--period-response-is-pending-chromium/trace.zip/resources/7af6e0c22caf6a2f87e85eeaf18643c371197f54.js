import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/reports/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-69432-fdca83c1-1b99-4651-a770-72ad9086f1a5/deps/react_jsx-dev-runtime.js?v=83cfadd6"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-69432-fdca83c1-1b99-4651-a770-72ad9086f1a5/deps/react.js?v=83cfadd6"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-69432-fdca83c1-1b99-4651-a770-72ad9086f1a5/deps/react-router-dom.js?v=ec048eec";
import { Alert, Box, Button, Link, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-69432-fdca83c1-1b99-4651-a770-72ad9086f1a5/deps/@mui_material.js?v=eccf0f41";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Text, Tooltip, XAxis, YAxis } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-69432-fdca83c1-1b99-4651-a770-72ad9086f1a5/deps/recharts.js?v=b214284d";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime, formatDateOnly, isValidDateOnly } from "/src/shared/model/format.ts";
import { Amount, DataTable, DetailLine, ErrorNotice, PageHeader, Panel, Pager, QueryState, RouteLink, Stat, Stats, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { authorizedDownloadHref, dateInTimezone, reportDateBoundary, reportFilename } from "/src/modules/reports/report-utils.ts";
const reportLabels = {
  inventory: "Tồn kho",
  orders: "Đơn hàng",
  cashflow: "Dòng tiền",
  profit_loss: "Lợi nhuận"
};
const sourcePermissions = {
  inventory: "inventory.read",
  orders: "orders.read",
  cashflow: "finance.read",
  profit_loss: "finance.read"
};
function MarketingReasonTick({ x = 0, y = 0, width = 0, visibleTicksCount = 1, payload }) {
  const value = typeof payload?.value === "string" ? payload.value.trim() : "";
  const categoryLabelInset = 8;
  const labelWidth = Math.max(1, width / Math.max(1, visibleTicksCount) - categoryLabelInset);
  return /* @__PURE__ */ jsxDEV(
    Text,
    {
      x,
      y,
      dy: 12,
      width: labelWidth,
      breakAll: true,
      verticalAnchor: "start",
      textAnchor: "middle",
      fill: colors.textSecondary,
      style: { fontSize: tokens.fontSizes.body, fontFamily: tokens.fontFamily },
      children: value
    },
    void 0,
    false,
    {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 47,
      columnNumber: 10
    },
    this
  );
}
_c = MarketingReasonTick;
export function ReportsPage() {
  _s();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const latestParams = useRef(new URLSearchParams(params));
  const pendingSearch = useRef(null);
  useEffect(() => {
    const committedSearch = params.toString();
    if (pendingSearch.current !== null && pendingSearch.current !== committedSearch) return;
    latestParams.current = new URLSearchParams(params);
    pendingSearch.current = null;
  }, [params]);
  const summary = useApi("getReportSummary");
  const canReadJobs = useCan("jobs.read");
  const jobs = useApi("listJobs", { query: { limit: 10, cursor: params.get("cursor") || void 0 } }, canReadJobs);
  const run = useCommand("createExport", ["listJobs"]);
  const requestedType = params.get("reportType");
  const type = requestedType === "inventory" || requestedType === "cashflow" || requestedType === "profit_loss" ? requestedType : "orders";
  const snapshotAsOf = summary.data?.data.asOf;
  const defaultRange = useMemo(() => {
    if (!snapshotAsOf) return null;
    try {
      const currentDate = dateInTimezone(snapshotAsOf, shop.timezone);
      return { fromDate: `${currentDate.slice(0, 7)}-01`, toDate: currentDate };
    } catch {
      return null;
    }
  }, [shop.timezone, snapshotAsOf]);
  const fromValue = params.get("fromDate");
  const toValue = params.get("toDate");
  const readReportDate = (key, value) => {
    if (isValidDateOnly(value)) return value;
    if (params.has(key) && value === "") return "";
    return defaultRange?.[key] || "";
  };
  const from = readReportDate("fromDate", fromValue);
  const to = readReportDate("toDate", toValue);
  const setReportParam = (key, value) => {
    const next = new URLSearchParams(latestParams.current);
    if (key === "reportType") next.set(key, value);
    else
      next.set(key, isValidDateOnly(value) ? value : "");
    latestParams.current = next;
    pendingSearch.current = next.toString();
    setParams(next, { flushSync: true });
  };
  const [rangeError, setRangeError] = useState("");
  const [lastExport, setLastExport] = useState(null);
  const canExportReports = useCan("reports.export");
  const canExportSource = useCan(sourcePermissions[type]);
  const availableReports = summary.data?.data.availableReports || [];
  const reportAvailable = availableReports.includes(type);
  useEffect(() => {
    if (!snapshotAsOf) return;
    if (!defaultRange) {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
      return;
    }
    try {
      const next = new URLSearchParams(latestParams.current);
      let changed = false;
      if (requestedType !== "inventory" && requestedType !== "cashflow" && requestedType !== "profit_loss" && requestedType !== "orders") {
        next.set("reportType", "orders");
        changed = true;
      }
      if (!params.has("fromDate") || fromValue && !isValidDateOnly(fromValue)) {
        next.set("fromDate", defaultRange.fromDate);
        changed = true;
      }
      if (!params.has("toDate") || toValue && !isValidDateOnly(toValue)) {
        next.set("toDate", defaultRange.toDate);
        changed = true;
      }
      if (changed) {
        latestParams.current = next;
        pendingSearch.current = next.toString();
        setParams(next, { replace: true, flushSync: true });
      }
    } catch {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
    }
  }, [defaultRange, params, requestedType, fromValue, toValue, setParams, snapshotAsOf]);
  const submit = async () => {
    setRangeError("");
    try {
      if (!snapshotAsOf || !from || !to) throw new RangeError("Chưa có snapshot hoặc khoảng ngày đầy đủ.");
      const request = {
        reportType: type,
        format: "csv",
        from: reportDateBoundary(from, "start", shop.timezone),
        to: reportDateBoundary(to, "end", shop.timezone),
        timezone: shop.timezone,
        snapshotAsOf
      };
      setLastExport(null);
      const response = await run.execute({ body: request });
      setLastExport({ job: response.data, type, from, to });
    } catch (error) {
      if (error instanceof RangeError) setRangeError(error.message);
    }
  };
  const handleExport = () => {
    void submit();
  };
  const lastDownload = lastExport?.job.status === "succeeded" && lastExport.job.downloadUrl ? authorizedDownloadHref(lastExport.job.downloadUrl, location.origin, __MOCK__) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Báo cáo & xuất dữ liệu", subtitle: "Xuất snapshot do API tạo; số liệu tổng hợp không được tính từ một trang danh sách." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 158,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "reports-main-layout", columns: { xs: "minmax(0, 1fr)", xl: "minmax(0, 1.2fr) minmax(0, .8fr)" }, alignItems: "start", geometry: { minWidth: 0 }, children: [
      /* @__PURE__ */ jsxDEV(PageSections, { "data-testid": "reports-page-sections", children: [
        /* @__PURE__ */ jsxDEV(QueryState, { query: summary, pendingProfile: "section", children: summary.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Tạo tệp báo cáo", subtitle: "Ngày được hiểu theo múi giờ cửa hàng và gửi thành mốc thời gian rõ ràng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-export-form-layout", geometry: { maxWidth: 760 }, children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: run.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 164,
            columnNumber: 29
          }, this),
          rangeError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: rangeError }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 165,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Báo cáo", select: true, value: type, onChange: (event) => {
            const value = event.target.value;
            if (value === "orders" || value === "inventory" || value === "cashflow" || value === "profit_loss") setReportParam("reportType", value);
            setLastExport(null);
          }, children: availableReports.map((report) => /* @__PURE__ */ jsxDEV(MenuItem, { value: report, children: reportLabels[report] }, report, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 171,
            columnNumber: 67
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 166,
            columnNumber: 29
          }, this),
          availableReports.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại chưa có loại báo cáo khả dụng." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 173,
            columnNumber: 63
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-date-filters", direction: { xs: "column", sm: "row" }, children: [
            /* @__PURE__ */ jsxDEV(TextField, { label: "Từ ngày", type: "date", value: from, onChange: (event) => setReportParam("fromDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 175,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Đến ngày", type: "date", value: to, onChange: (event) => setReportParam("toDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 176,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 174,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Múi giờ", children: shop.timezone }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 178,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Snapshot API", children: snapshotAsOf ? dateTime(snapshotAsOf, shop.timezone) : "Chưa có snapshot" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 179,
            columnNumber: 29
          }, this),
          !canExportReports && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vai trò hiện tại không có quyền reports.export." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 180,
            columnNumber: 51
          }, this),
          canExportReports && !canExportSource && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
            "Quyền xuất không thay thế quyền đọc nguồn ",
            sourcePermissions[type],
            "; loại báo cáo này chưa thể xuất."
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 181,
            columnNumber: 70
          }, this),
          canExportReports && canExportSource && !reportAvailable && availableReports.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "API không liệt kê loại báo cáo này cho vai trò hiện tại." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 182,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: handleExport, disabled: !canExportReports || !canExportSource || !reportAvailable || !snapshotAsOf || !from || !to || from > to || run.pending, children: run.pending ? "Đang tạo snapshot…" : "Tạo tệp báo cáo CSV" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 183,
            columnNumber: 29
          }, this),
          lastExport && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "center" }, children: [
            /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${lastExport.job.id}`, children: [
              "Theo dõi công việc ",
              lastExport.job.id
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 187,
              columnNumber: 33
            }, this),
            lastDownload && /* @__PURE__ */ jsxDEV(Link, { "data-testid": "reports-export-download", component: "a", href: lastDownload, download: reportFilename(lastExport.type, lastExport.from, lastExport.to), underline: "none", sx: [layoutSx.actions.linkTarget, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control, color: "text.primary", fontWeight: visualSx.typography.fontWeight.semibold, "&:hover": { bgcolor: "action.hover", textDecoration: "none" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: "Tải CSV" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 188,
              columnNumber: 50
            }, this),
            lastExport.job.status !== "succeeded" && /* @__PURE__ */ jsxDEV(Alert, { severity: lastExport.job.status === "partial" || lastExport.job.status === "failed" ? "warning" : "info", children: "Tệp chỉ được tải khi công việc xác nhận succeeded." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 189,
              columnNumber: 75
            }, this),
            lastExport.job.status === "succeeded" && lastExport.job.downloadUrl && !lastDownload && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không hợp lệ hoặc chưa thuộc HTTPS/nguồn hiện tại." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 190,
              columnNumber: 122
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 186,
            columnNumber: 44
          }, this),
          summary.data.data.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: warning }, `${index}-${warning}`, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 192,
            columnNumber: 81
          }, this)),
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "API hiện chỉ trả danh sách loại báo cáo và thời điểm snapshot; bộ lọc ngày áp dụng cho lệnh xuất. Không có series hoặc tổng số liệu để giao diện tự suy ra." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 193,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 163,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 162,
          columnNumber: 38
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 161,
          columnNumber: 17
        }, this),
        canReadJobs ? /* @__PURE__ */ jsxDEV(QueryState, { query: jobs, pendingProfile: "section", children: jobs.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Công việc gần đây", subtitle: "Trạng thái và tiến độ lấy từ API; trang hiện tại có thể chứa nhiều loại công việc.", children: [
          /* @__PURE__ */ jsxDEV(DataTable, { rows: jobs.data.data, rowKey: (job) => job.id, label: "Công việc gần đây", empty: "Chưa có công việc trong trang này.", columns: [
            { key: "id", label: "Mã công việc", render: (job) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${job.id}`, children: job.id }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 200,
              columnNumber: 66
            }, this) },
            { key: "kind", label: "Loại", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.kind }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 201,
              columnNumber: 60
            }, this) },
            { key: "status", label: "Trạng thái", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 202,
              columnNumber: 68
            }, this) },
            { key: "progress", label: "Tiến độ", align: "right", render: (job) => `${job.completed} / ${job.total ?? "Chưa biết"}` },
            { key: "updatedAt", label: "Cập nhật", render: (job) => dateTime(job.updatedAt, shop.timezone) }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 199,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: jobs.data.page }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 206,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 198,
          columnNumber: 35
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 197,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có jobs.read; trạng thái công việc được ẩn theo quyền." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 208,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 160,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Phạm vi dữ liệu", subtitle: "Chỉ những gì API cung cấp mới được trình bày như số liệu.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.report.contextGap, children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Báo cáo dòng, biểu đồ và tổng hợp theo khoảng ngày chưa có trong getReportSummary. Frontend không cộng dữ liệu phân trang để tạo KPI thay thế." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 212,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Trạng thái export được lấy riêng từ listJobs; URL tải chỉ được mở sau khi API trả về công việc hoàn tất." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 213,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/reports/marketing`, children: "Xem thông tin marketing" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 214,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 211,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 210,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 159,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 157,
    columnNumber: 10
  }, this);
}
_s(ReportsPage, "DFyE6kGn/WrimxAHqu/xbuEgHPg=", false, function() {
  return [useScope, useSearchParams, useApi, useCan, useApi, useCommand, useCan, useCan];
});
_c2 = ReportsPage;
export function MarketingPage() {
  _s2();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const search = params.toString();
  const fromParam = params.get("fromDate") || "";
  const toParam = params.get("toDate") || "";
  const bucketParam = params.get("bucket") || "day";
  const hasDateFilter = params.has("fromDate") || params.has("toDate");
  const appliedError = marketingRangeError(fromParam, toParam, bucketParam, !hasDateFilter);
  const query = appliedError ? void 0 : {
    ...params.has("fromDate") ? { fromDate: fromParam } : {},
    ...params.has("toDate") ? { toDate: toParam } : {},
    ...params.has("bucket") ? { bucket: bucketParam } : {}
  };
  const data = useApi("getMarketingSummary", query && Object.keys(query).length ? { query } : void 0, !appliedError);
  const m = data.data?.data;
  const marketingPeriod = m?.period;
  const [draft, setDraft] = useState({ fromDate: fromParam, toDate: toParam, bucket: bucketParam });
  const draftTouched = useRef(false);
  const [showFilterError, setShowFilterError] = useState(false);
  const fromRef = useRef(null);
  const toRef = useRef(null);
  const bucketRef = useRef(null);
  const draftError = marketingRangeError(draft.fromDate, draft.toDate, draft.bucket, false);
  const visibleFilterError = showFilterError ? draftError : appliedError;
  useEffect(() => {
    if (marketingPeriod && !hasDateFilter && !draftTouched.current) {
      const next = new URLSearchParams({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      if (next.toString() !== search) setParams(next, { replace: true });
    }
  }, [marketingPeriod, hasDateFilter, search, setParams]);
  useEffect(() => {
    draftTouched.current = false;
    const current = new URLSearchParams(search);
    if (!current.has("fromDate") && !current.has("toDate")) return;
    setDraft({ fromDate: current.get("fromDate") || "", toDate: current.get("toDate") || "", bucket: current.get("bucket") || "day" });
    setShowFilterError(false);
  }, [search]);
  const applyFilter = (event) => {
    event.preventDefault();
    setShowFilterError(true);
    if (draftError) {
      const target = draftError.field === "fromDate" ? fromRef.current : draftError.field === "toDate" ? toRef.current : bucketRef.current;
      target?.focus();
      return;
    }
    const next = new URLSearchParams({ fromDate: draft.fromDate, toDate: draft.toDate, bucket: draft.bucket });
    setShowFilterError(false);
    draftTouched.current = false;
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thông tin cho marketing", subtitle: "Đề xuất chỉ đọc; trang không tự đăng nội dung hoặc thay đổi ngân sách." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 278,
      columnNumber: 9
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Số liệu mẫu do API mô phỏng tổng hợp; chưa kết nối tài khoản quảng cáo hoặc nguồn phân bổ thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 279,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Khoảng thời gian báo cáo", subtitle: `Ngày được tính theo lịch ${shop.timezone} của cửa hàng.`, bodyMode: "inset", afterGap: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", onSubmit: applyFilter, "data-testid": "marketing-range-form", children: [
      /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "flex-end" }, sx: layoutSx.toolbar.controlGap, children: [
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: fromRef, type: "date", label: "Từ ngày", value: draft.fromDate, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, fromDate: event.target.value }));
        }, slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "fromDate", helperText: visibleFilterError?.field === "fromDate" ? visibleFilterError.message : "Ngày bắt đầu, tính cả ngày đã chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 283,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: toRef, type: "date", label: "Đến ngày", value: draft.toDate, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, toDate: event.target.value }));
        }, slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "toDate", helperText: visibleFilterError?.field === "toDate" ? visibleFilterError.message : "Tối đa 366 ngày, tính cả hai đầu." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 284,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: bucketRef, select: true, label: "Gộp theo", value: draft.bucket, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, bucket: event.target.value }));
        }, error: visibleFilterError?.field === "bucket", helperText: visibleFilterError?.field === "bucket" ? visibleFilterError.message : "Chọn ngày, tuần hoặc tháng.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "day", children: "Ngày" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 286,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "week", children: "Tuần" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 286,
            columnNumber: 62
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "month", children: "Tháng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 286,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 285,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", children: "Áp dụng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 288,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 282,
        columnNumber: 17
      }, this),
      showFilterError && draftError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: draftError.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 290,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 281,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 280,
      columnNumber: 9
    }, this),
    appliedError ? /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Bộ lọc trên đường dẫn không hợp lệ." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 293,
        columnNumber: 62
      }, this),
      " Hãy sửa trường được đánh dấu trước khi áp dụng."
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 293,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: m && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn có nguồn xác định", value: m.knownAttributedOrders, note: "Được API tổng hợp trong kỳ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 295,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn chưa rõ nguồn", value: m.unknownAttributionOrders, note: "Giữ riêng, không tự gán nguồn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 296,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo thực tế", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.actualSpend }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 297,
          columnNumber: 60
        }, this), note: m.actualSpend ? "API cung cấp số thực tế" : "Kỳ này chưa có số thực tế từ API" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 297,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo ước tính", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.estimatedSpend }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 298,
          columnNumber: 61
        }, this), note: "Ước tính không phải số ghi sổ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 298,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 294,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "marketing-as-of", sx: [layoutSx.report.contextGap, layoutSx.page.sectionAfter], children: [
        m.period && /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
          "Kỳ ",
          formatDateOnly(m.period.fromDate),
          " – ",
          formatDateOnly(m.period.toDate),
          " · gộp theo ",
          m.period.bucket === "day" ? "ngày" : m.period.bucket === "week" ? "tuần" : "tháng"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 301,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Cập nhật ",
          dateTime(m.asOf, m.period?.timezone || shop.timezone),
          " · ",
          shop.name,
          " · múi giờ ",
          m.period?.timezone || shop.timezone
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 302,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 300,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "marketing-sections-grid", columns: { xs: "1fr", lg: "1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV(Panel, { title: "Đơn theo thời gian", subtitle: "Số đơn có nguồn xác định và chưa rõ nguồn do API tổng hợp.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Số đơn theo ${m.period?.bucket || "kỳ"} trong khoảng đã chọn`, "data-testid": "marketing-trend-chart", sx: [{ height: 280 }, layoutSx.report.chartViewportInset], children: m.trend?.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.trend, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 308,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "fromDate", stroke: colors.textSecondary, interval: Math.max(0, Math.ceil(m.trend.length / 7) - 1), tickFormatter: (value) => formatDateOnly(String(value)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 309,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 310,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { labelFormatter: (value) => formatDateOnly(String(value)), contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 311,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 312,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "knownAttributedOrders", name: "Có nguồn xác định", fill: colors.accent, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 313,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "unknownAttributionOrders", name: "Chưa rõ nguồn", fill: colors.textSecondary, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 314,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 307,
            columnNumber: 92
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 307,
            columnNumber: 44
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "API chưa có bucket dữ liệu trong kỳ đã chọn." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 315,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 306,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Tổng hợp marketing theo kỳ", rows: m.trend || [], rowKey: (point) => point.fromDate, empty: "Chưa có dữ liệu theo kỳ trong khoảng này.", columns: [
            { key: "range", label: "Khoảng ngày", render: (point) => `${formatDateOnly(point.fromDate)} – ${formatDateOnly(point.toDate)}` },
            { key: "known", label: "Có nguồn", align: "right", render: (point) => point.knownAttributedOrders },
            { key: "unknown", label: "Chưa rõ nguồn", align: "right", render: (point) => point.unknownAttributionOrders },
            { key: "estimated", label: "Chi ước tính", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.estimatedSpend }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 321,
              columnNumber: 91
            }, this) },
            { key: "actual", label: "Chi thực tế", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.actualSpend }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 322,
              columnNumber: 87
            }, this) }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 317,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 305,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Câu hỏi khách thường hỏi", subtitle: "Các mục do API tổng hợp cung cấp.", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "marketing-question-surface", sx: layoutSx.report.listSurfaceInset, children: /* @__PURE__ */ jsxDEV(Stack, { component: "ul", "data-testid": "marketing-top-questions", sx: [{ m: 0, p: 0 }, layoutSx.report.listMarkerInset, layoutSx.report.listItemGap], children: m.topQuestions.length ? m.topQuestions.map((question, index) => /* @__PURE__ */ jsxDEV(Typography, { component: "li", children: question }, `${index}-${question}`, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 328,
          columnNumber: 94
        }, this)) : /* @__PURE__ */ jsxDEV(Typography, { component: "li", color: "text.secondary", children: "Chưa có thống kê câu hỏi trong kỳ đã chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 328,
          columnNumber: 177
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 327,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 326,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 325,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Lý do không chốt đơn", subtitle: "Biểu đồ và bảng dùng cùng một payload API.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Biểu đồ lý do không chốt đơn, ${m.lostSaleReasons.length} nhóm`, "data-testid": "marketing-loss-chart", sx: [{ height: 260 }, layoutSx.report.chartViewportInset], children: m.lostSaleReasons.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.lostSaleReasons, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 335,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "reason", stroke: colors.textSecondary, interval: 0, height: 64, tick: /* @__PURE__ */ jsxDEV(MarketingReasonTick, {}, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 336,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 336,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 337,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 338,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "count", name: "Số trường hợp", fill: colors.accent, radius: [4, 4, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 339,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 334,
            columnNumber: 101
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 334,
            columnNumber: 53
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "Chưa có lý do mất đơn trong kỳ này." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 340,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 333,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { rows: m.lostSaleReasons, rowKey: (reason) => reason.reason, label: "Lý do không chốt đơn", empty: "Chưa có lý do mất đơn trong kỳ đã chọn.", columns: [
            { key: "reason", label: "Lý do", render: (reason) => reason.reason },
            { key: "count", label: "Số trường hợp", align: "right", render: (reason) => reason.count }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 342,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 332,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 304,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.page.sectionBefore, children: "Không tự gán nguồn cho đơn thiếu dữ liệu, không ghi chi ước tính thành chi thực tế và không tự đăng nội dung hoặc tăng ngân sách." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 348,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 293,
      columnNumber: 229
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 293,
      columnNumber: 173
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 277,
    columnNumber: 10
  }, this);
}
_s2(MarketingPage, "D1j9U3eMueXqAljpDZxSom2Peys=", false, function() {
  return [useScope, useSearchParams, useApi];
});
_c3 = MarketingPage;
function marketingRangeError(fromDate, toDate, bucket, allowDefault) {
  if (!["day", "week", "month"].includes(bucket)) return { field: "bucket", message: "Chọn nhóm ngày, tuần hoặc tháng." };
  if (allowDefault && !fromDate && !toDate) return null;
  if (!isValidDateOnly(fromDate)) return { field: "fromDate", message: "Nhập ngày bắt đầu hợp lệ." };
  if (!isValidDateOnly(toDate)) return { field: "toDate", message: "Nhập ngày kết thúc hợp lệ." };
  if (fromDate > toDate) return { field: "fromDate", message: "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc." };
  const days = Math.floor((Date.parse(`${toDate}T00:00:00.000Z`) - Date.parse(`${fromDate}T00:00:00.000Z`)) / (24 * 60 * 60 * 1e3)) + 1;
  if (days > 366) return { field: "toDate", message: "Khoảng báo cáo không được vượt quá 366 ngày." };
  return null;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "MarketingReasonTick");
$RefreshReg$(_c2, "ReportsPage");
$RefreshReg$(_c3, "MarketingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJXLFNBOEdBLFVBOUdBOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCWCxTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxtQkFBbUI7QUFDbkUsU0FBU0MsV0FBV0MsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBRXJELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsTUFBTUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQ2pGLFNBQVNDLEtBQUtDLFVBQVVDLGVBQWVDLFFBQVFDLHFCQUFxQkMsTUFBTUMsU0FBU0MsT0FBT0MsYUFBYTtBQUV2RyxTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLGdCQUFnQkMsdUJBQXVCO0FBQzFELFNBQVNDLFFBQVFDLFdBQVdDLFlBQVlDLGFBQWFDLFlBQVlDLE9BQU9DLE9BQU9DLFlBQVlDLFdBQVdDLE1BQU1DLE9BQU9DLGNBQWM7QUFDakksU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHdCQUF3QkMsZ0JBQWdCQyxvQkFBb0JDLHNCQUFzQjtBQUUzRixNQUFNQyxlQUE0RDtBQUFBLEVBQzlEQyxXQUFXO0FBQUEsRUFBV0MsUUFBUTtBQUFBLEVBQVlDLFVBQVU7QUFBQSxFQUFhQyxhQUFhO0FBQ2xGO0FBQ0EsTUFBTUMsb0JBQWlFO0FBQUEsRUFDbkVKLFdBQVc7QUFBQSxFQUFrQkMsUUFBUTtBQUFBLEVBQWVDLFVBQVU7QUFBQSxFQUFnQkMsYUFBYTtBQUMvRjtBQUVBLFNBQVNFLG9CQUFvQixFQUFFQyxJQUFJLEdBQUdDLElBQUksR0FBR0MsUUFBUSxHQUFHQyxvQkFBb0IsR0FBR0MsUUFBK0csR0FBRztBQUM3TCxRQUFNQyxRQUFRLE9BQU9ELFNBQVNDLFVBQVUsV0FBV0QsUUFBUUMsTUFBTUMsS0FBSyxJQUFJO0FBQzFFLFFBQU1DLHFCQUFxQjtBQUMzQixRQUFNQyxhQUFhQyxLQUFLQyxJQUFJLEdBQUdSLFFBQVFPLEtBQUtDLElBQUksR0FBR1AsaUJBQWlCLElBQUlJLGtCQUFrQjtBQUMxRixTQUFPO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFBSztBQUFBLE1BQU07QUFBQSxNQUFNLElBQUk7QUFBQSxNQUFJLE9BQU9DO0FBQUFBLE1BQVksVUFBUTtBQUFBLE1BQUMsZ0JBQWU7QUFBQSxNQUFRLFlBQVc7QUFBQSxNQUFTLE1BQU16QyxPQUFPNEM7QUFBQUEsTUFDakgsT0FBTyxFQUFFQyxVQUFVNUMsT0FBTzZDLFVBQVVDLE1BQU1DLFlBQVkvQyxPQUFPK0MsV0FBVztBQUFBLE1BQUlWO0FBQUFBO0FBQUFBLElBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUMrRTtBQUMxRjtBQUFDVyxLQU5RakI7QUFRRixnQkFBU2tCLGNBQWM7QUFBQUMsS0FBQTtBQUMxQixRQUFNLEVBQUVDLEtBQUssSUFBSWhELFNBQVM7QUFDMUIsUUFBTSxDQUFDaUQsUUFBUUMsU0FBUyxJQUFJeEUsZ0JBQWdCO0FBQzVDLFFBQU15RSxlQUFlNUUsT0FBTyxJQUFJNkUsZ0JBQWdCSCxNQUFNLENBQUM7QUFDdkQsUUFBTUksZ0JBQWdCOUUsT0FBc0IsSUFBSTtBQUNoREYsWUFBVSxNQUFNO0FBQ1osVUFBTWlGLGtCQUFrQkwsT0FBT00sU0FBUztBQUN4QyxRQUFJRixjQUFjRyxZQUFZLFFBQVFILGNBQWNHLFlBQVlGLGdCQUFpQjtBQUNqRkgsaUJBQWFLLFVBQVUsSUFBSUosZ0JBQWdCSCxNQUFNO0FBQ2pESSxrQkFBY0csVUFBVTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ1AsTUFBTSxDQUFDO0FBQ1gsUUFBTVEsVUFBVTNELE9BQU8sa0JBQWtCO0FBQ3pDLFFBQU00RCxjQUFjekQsT0FBTyxXQUFXO0FBQ3RDLFFBQU0wRCxPQUFPN0QsT0FBTyxZQUFZLEVBQUU4RCxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsUUFBUWIsT0FBT2MsSUFBSSxRQUFRLEtBQUtDLE9BQVUsRUFBRSxHQUFHTixXQUFXO0FBQ2hILFFBQU1PLE1BQU1sRSxXQUFXLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztBQUNuRCxRQUFNbUUsZ0JBQWdCakIsT0FBT2MsSUFBSSxZQUFZO0FBQzdDLFFBQU1JLE9BQW9DRCxrQkFBa0IsZUFBZUEsa0JBQWtCLGNBQWNBLGtCQUFrQixnQkFBZ0JBLGdCQUFnQjtBQUM3SixRQUFNRSxlQUFlWCxRQUFRWSxNQUFNQSxLQUFLQztBQUN4QyxRQUFNQyxlQUFlakcsUUFBUSxNQUFNO0FBQy9CLFFBQUksQ0FBQzhGLGFBQWMsUUFBTztBQUMxQixRQUFJO0FBQ0EsWUFBTUksY0FBY3JELGVBQWVpRCxjQUFjcEIsS0FBS3lCLFFBQVE7QUFDOUQsYUFBTyxFQUFFQyxVQUFVLEdBQUdGLFlBQVlHLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBT0MsUUFBUUosWUFBWTtBQUFBLElBQzVFLFFBQ007QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3hCLEtBQUt5QixVQUFVTCxZQUFZLENBQUM7QUFDaEMsUUFBTVMsWUFBWTVCLE9BQU9jLElBQUksVUFBVTtBQUN2QyxRQUFNZSxVQUFVN0IsT0FBT2MsSUFBSSxRQUFRO0FBQ25DLFFBQU1nQixpQkFBaUJBLENBQUNDLEtBQTRCOUMsVUFBeUI7QUFDekUsUUFBSTlCLGdCQUFnQjhCLEtBQUssRUFBRyxRQUFPQTtBQUNuQyxRQUFJZSxPQUFPZ0MsSUFBSUQsR0FBRyxLQUFLOUMsVUFBVSxHQUFJLFFBQU87QUFDNUMsV0FBT3FDLGVBQWVTLEdBQUcsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsUUFBTUUsT0FBT0gsZUFBZSxZQUFZRixTQUFTO0FBQ2pELFFBQU1NLEtBQUtKLGVBQWUsVUFBVUQsT0FBTztBQUMzQyxRQUFNTSxpQkFBaUJBLENBQUNKLEtBQTJDOUMsVUFBa0I7QUFDakYsVUFBTW1ELE9BQU8sSUFBSWpDLGdCQUFnQkQsYUFBYUssT0FBTztBQUNyRCxRQUFJd0IsUUFBUSxhQUFjSyxNQUFLQyxJQUFJTixLQUFLOUMsS0FBSztBQUFBO0FBQ3hDbUQsV0FBS0MsSUFBSU4sS0FBSzVFLGdCQUFnQjhCLEtBQUssSUFBSUEsUUFBUSxFQUFFO0FBQ3REaUIsaUJBQWFLLFVBQVU2QjtBQUN2QmhDLGtCQUFjRyxVQUFVNkIsS0FBSzlCLFNBQVM7QUFDdENMLGNBQVVtQyxNQUFNLEVBQUVFLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDdkM7QUFDQSxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWpILFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrSCxZQUFZQyxhQUFhLElBQUluSCxTQUEyRixJQUFJO0FBQ25JLFFBQU1vSCxtQkFBbUIzRixPQUFPLGdCQUFnQjtBQUNoRCxRQUFNNEYsa0JBQWtCNUYsT0FBTzBCLGtCQUFrQndDLElBQUksQ0FBQztBQUN0RCxRQUFNMkIsbUJBQW1CckMsUUFBUVksTUFBTUEsS0FBS3lCLG9CQUFvQjtBQUNoRSxRQUFNQyxrQkFBa0JELGlCQUFpQkUsU0FBUzdCLElBQUk7QUFFdEQ5RixZQUFVLE1BQU07QUFDWixRQUFJLENBQUMrRixhQUFjO0FBQ25CLFFBQUksQ0FBQ0csY0FBYztBQUNma0Isb0JBQWMsMkRBQTJEO0FBQ3pFO0FBQUEsSUFDSjtBQUNBLFFBQUk7QUFDQSxZQUFNSixPQUFPLElBQUlqQyxnQkFBZ0JELGFBQWFLLE9BQU87QUFDckQsVUFBSXlDLFVBQVU7QUFDZCxVQUFJL0Isa0JBQWtCLGVBQWVBLGtCQUFrQixjQUFjQSxrQkFBa0IsaUJBQWlCQSxrQkFBa0IsVUFBVTtBQUNoSW1CLGFBQUtDLElBQUksY0FBYyxRQUFRO0FBQy9CVyxrQkFBVTtBQUFBLE1BQ2Q7QUFDQSxVQUFJLENBQUNoRCxPQUFPZ0MsSUFBSSxVQUFVLEtBQU1KLGFBQWEsQ0FBQ3pFLGdCQUFnQnlFLFNBQVMsR0FBSTtBQUN2RVEsYUFBS0MsSUFBSSxZQUFZZixhQUFhRyxRQUFRO0FBQzFDdUIsa0JBQVU7QUFBQSxNQUNkO0FBQ0EsVUFBSSxDQUFDaEQsT0FBT2dDLElBQUksUUFBUSxLQUFNSCxXQUFXLENBQUMxRSxnQkFBZ0IwRSxPQUFPLEdBQUk7QUFDakVPLGFBQUtDLElBQUksVUFBVWYsYUFBYUssTUFBTTtBQUN0Q3FCLGtCQUFVO0FBQUEsTUFDZDtBQUNBLFVBQUlBLFNBQVM7QUFDVDlDLHFCQUFhSyxVQUFVNkI7QUFDdkJoQyxzQkFBY0csVUFBVTZCLEtBQUs5QixTQUFTO0FBQ3RDTCxrQkFBVW1DLE1BQU0sRUFBRWEsU0FBUyxNQUFNWCxXQUFXLEtBQUssQ0FBQztBQUFBLE1BQ3REO0FBQUEsSUFDSixRQUNNO0FBQUVFLG9CQUFjLDJEQUEyRDtBQUFBLElBQUc7QUFBQSxFQUN4RixHQUFHLENBQUNsQixjQUFjdEIsUUFBUWlCLGVBQWVXLFdBQVdDLFNBQVM1QixXQUFXa0IsWUFBWSxDQUFDO0FBRXJGLFFBQU0rQixTQUFTLFlBQVk7QUFDdkJWLGtCQUFjLEVBQUU7QUFDaEIsUUFBSTtBQUNBLFVBQUksQ0FBQ3JCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLEdBQUksT0FBTSxJQUFJaUIsV0FBVywyQ0FBMkM7QUFDbkcsWUFBTUMsVUFBVTtBQUFBLFFBQ1pDLFlBQVluQztBQUFBQSxRQUNab0MsUUFBUTtBQUFBLFFBQ1JyQixNQUFNOUQsbUJBQW1COEQsTUFBTSxTQUFTbEMsS0FBS3lCLFFBQVE7QUFBQSxRQUNyRFUsSUFBSS9ELG1CQUFtQitELElBQUksT0FBT25DLEtBQUt5QixRQUFRO0FBQUEsUUFDL0NBLFVBQVV6QixLQUFLeUI7QUFBQUEsUUFDZkw7QUFBQUEsTUFDSjtBQUNBdUIsb0JBQWMsSUFBSTtBQUNsQixZQUFNYSxXQUFXLE1BQU12QyxJQUFJd0MsUUFBUSxFQUFFOUQsTUFBTTBELFFBQVEsQ0FBQztBQUNwRFYsb0JBQWMsRUFBRWUsS0FBS0YsU0FBU25DLE1BQU1GLE1BQU1lLE1BQU1DLEdBQUcsQ0FBQztBQUFBLElBQ3hELFNBQ093QixPQUFPO0FBQ1YsVUFBSUEsaUJBQWlCUCxXQUFZWCxlQUFja0IsTUFBTUMsT0FBTztBQUFBLElBQ2hFO0FBQUEsRUFDSjtBQUNBLFFBQU1DLGVBQWVBLE1BQU07QUFBRSxTQUFLVixPQUFPO0FBQUEsRUFBRztBQUU1QyxRQUFNVyxlQUFlcEIsWUFBWWdCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxjQUN4RTlGLHVCQUF1QndFLFdBQVdnQixJQUFJTSxhQUFhQyxTQUFTQyxRQUFRQyxRQUFRLElBQzVFO0FBRU4sU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSwwQkFBeUIsVUFBUyx3RkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3STtBQUFBLElBQ3hJLHVCQUFDLGVBQVksZUFBWSx1QkFBc0IsU0FBUyxFQUFFQyxJQUFJLGtCQUFrQkMsSUFBSSxtQ0FBbUMsR0FBRyxZQUFZLFNBQVMsVUFBVSxFQUFDQyxVQUFVLEVBQUMsR0FDaks7QUFBQSw2QkFBQyxnQkFBYSxlQUFZLHlCQUN0QjtBQUFBLCtCQUFDLGNBQVcsT0FBTzdELFNBQVMsZ0JBQWUsV0FDdENBLGtCQUFRWSxRQUFRLHVCQUFDLFNBQU0sT0FBTSxtQkFBa0IsVUFBUyw0RUFBMkUsVUFBUyxTQUN6SSxpQ0FBQyxjQUFXLGVBQVksOEJBQTZCLFVBQVUsRUFBQ2tELFVBQVUsSUFBRyxHQUN6RTtBQUFBLGlDQUFDLGVBQVksT0FBT3RELElBQUkwQyxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzdCbkIsY0FBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2hFLHVCQUFDLGFBQVUsT0FBTSxXQUFVLFFBQU0sTUFBQyxPQUFPckIsTUFBTSxVQUFVLENBQUFxRCxVQUFTO0FBQzlELGtCQUFNdEYsUUFBUXNGLE1BQU1DLE9BQU92RjtBQUMzQixnQkFBSUEsVUFBVSxZQUFZQSxVQUFVLGVBQWVBLFVBQVUsY0FBY0EsVUFBVSxjQUFla0QsZ0JBQWUsY0FBY2xELEtBQUs7QUFDdEl5RCwwQkFBYyxJQUFJO0FBQUEsVUFDdEIsR0FDS0csMkJBQWlCNEIsSUFBSSxDQUFBQyxXQUFVLHVCQUFDLFlBQVMsT0FBT0EsUUFBc0JyRyx1QkFBYXFHLE1BQU0sS0FBNUJBLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELENBQVcsS0FMM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0M3QixpQkFBaUI4QixXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sK0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDeEcsdUJBQUMsY0FBVyxlQUFZLHdCQUF1QixXQUFXLEVBQUVSLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQ2hGO0FBQUEsbUNBQUMsYUFBVSxPQUFNLFdBQVUsTUFBSyxRQUFPLE9BQU8zQyxNQUFNLFVBQVUsQ0FBQXNDLFVBQVNwQyxlQUFlLFlBQVlvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZLO0FBQUEsWUFDN0ssdUJBQUMsYUFBVSxPQUFNLFlBQVcsTUFBSyxRQUFPLE9BQU81QyxJQUFJLFVBQVUsQ0FBQXFDLFVBQVNwQyxlQUFlLFVBQVVvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBLO0FBQUEsZUFGOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsY0FBVyxPQUFNLFdBQVcvRSxlQUFLeUIsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxjQUFXLE9BQU0sZ0JBQWdCTCx5QkFBZWxFLFNBQVNrRSxjQUFjcEIsS0FBS3lCLFFBQVEsSUFBSSxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxVQUMzRyxDQUFDbUIsb0JBQW9CLHVCQUFDLFNBQU0sVUFBUyxXQUFVLCtEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQzlGQSxvQkFBb0IsQ0FBQ0MsbUJBQW1CLHVCQUFDLFNBQU0sVUFBUyxXQUFVO0FBQUE7QUFBQSxZQUEyQ2xFLGtCQUFrQndDLElBQUk7QUFBQSxZQUFFO0FBQUEsZUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEg7QUFBQSxVQUN0S3lCLG9CQUFvQkMsbUJBQW1CLENBQUNFLG1CQUFtQkQsaUJBQWlCOEIsU0FBUyxLQUFLLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHdFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQzdLLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVNmLGNBQWMsVUFBVSxDQUFDakIsb0JBQW9CLENBQUNDLG1CQUFtQixDQUFDRSxtQkFBbUIsQ0FBQzNCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLE1BQU1ELE9BQU9DLE1BQU1sQixJQUFJK0QsU0FDdksvRCxjQUFJK0QsVUFBVSx1QkFBdUIseUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDdEMsY0FBYyx1QkFBQyxlQUFZLFdBQVcsRUFBRTBCLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQUksWUFBWSxFQUFFVCxJQUFJLFdBQVdTLElBQUksU0FBUyxHQUMzRztBQUFBLG1DQUFDLGFBQVUsSUFBSSxNQUFNN0UsS0FBS2lGLEVBQUUsU0FBU3ZDLFdBQVdnQixJQUFJdUIsRUFBRSxJQUFJO0FBQUE7QUFBQSxjQUFvQnZDLFdBQVdnQixJQUFJdUI7QUFBQUEsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsWUFDL0ZuQixnQkFBZ0IsdUJBQUMsUUFBSyxlQUFZLDJCQUEwQixXQUFVLEtBQUksTUFBTUEsY0FBYyxVQUFVekYsZUFBZXFFLFdBQVd2QixNQUFNdUIsV0FBV1IsTUFBTVEsV0FBV1AsRUFBRSxHQUFHLFdBQVUsUUFBTyxJQUFJLENBQUNsRSxTQUFTaUgsUUFBUUMsWUFBWSxFQUFFQyxRQUFRLEdBQUdDLGFBQWEsV0FBV0MsY0FBYzdKLFNBQVM4SixPQUFPQyxTQUFTQyxPQUFPLGdCQUFnQkMsWUFBWWpLLFNBQVNrSyxXQUFXRCxXQUFXRSxVQUFVLFdBQVcsRUFBRUMsU0FBUyxnQkFBZ0JDLGdCQUFnQixPQUFPLEdBQUcsbUJBQW1CLEVBQUVDLFNBQVMsR0FBR2xKLE9BQU9tSixVQUFVakgsS0FBSyxZQUFZa0gsY0FBYyxpQkFBaUJDLGVBQWVySixPQUFPbUosVUFBVUcsY0FBYyxFQUFFLENBQUMsR0FBRyx1QkFBMWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlrQjtBQUFBLFlBQ2psQnpELFdBQVdnQixJQUFJSyxXQUFXLGVBQWUsdUJBQUMsU0FBTSxVQUFVckIsV0FBV2dCLElBQUlLLFdBQVcsYUFBYXJCLFdBQVdnQixJQUFJSyxXQUFXLFdBQVcsWUFBWSxRQUFRLGtFQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSztBQUFBLFlBQzVNckIsV0FBV2dCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxlQUFlLENBQUNGLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSwwRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUpsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtmO0FBQUEsVUFDQ3JELFFBQVFZLEtBQUtBLEtBQUsrRSxTQUFTMUIsSUFBSSxDQUFDMkIsU0FBU0MsVUFBVSx1QkFBQyxTQUFrQyxVQUFTLFFBQVFELHFCQUF4QyxHQUFHQyxLQUFLLElBQUlELE9BQU8sSUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQsQ0FBUTtBQUFBLFVBQ3hILHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrTDtBQUFBLGFBOUJ0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBLEtBaENhO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ2pCLEtBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxRQUNDM0YsY0FBYyx1QkFBQyxjQUFXLE9BQU9DLE1BQU0sZ0JBQWUsV0FDbERBLGVBQUtVLFFBQVEsdUJBQUMsU0FBTSxPQUFNLHFCQUFvQixVQUFTLHNGQUNwRDtBQUFBLGlDQUFDLGFBQVUsTUFBTVYsS0FBS1UsS0FBS0EsTUFBTSxRQUFRLENBQUFxQyxRQUFPQSxJQUFJdUIsSUFBSSxPQUFNLHFCQUFvQixPQUFNLHNDQUFxQyxTQUFTO0FBQUEsWUFDbEksRUFBRWpELEtBQUssTUFBTXVFLE9BQU8sZ0JBQWdCQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxhQUFVLElBQUksTUFBTTFELEtBQUtpRixFQUFFLFNBQVN2QixJQUFJdUIsRUFBRSxJQUFLdkIsY0FBSXVCLE1BQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVELEVBQWE7QUFBQSxZQUN2SCxFQUFFakQsS0FBSyxRQUFRdUUsT0FBTyxRQUFRQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUkrQyxRQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QixFQUFJO0FBQUEsWUFDekUsRUFBRXpFLEtBQUssVUFBVXVFLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQTlDLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJSyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQixFQUFJO0FBQUEsWUFDbkYsRUFBRS9CLEtBQUssWUFBWXVFLE9BQU8sV0FBV0csT0FBTyxTQUFTRixRQUFRQSxDQUFBOUMsUUFBTyxHQUFHQSxJQUFJaUQsU0FBUyxNQUFNakQsSUFBSWtELFNBQVMsV0FBVyxHQUFHO0FBQUEsWUFDckgsRUFBRTVFLEtBQUssYUFBYXVFLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQTlDLFFBQU94RyxTQUFTd0csSUFBSW1ELFdBQVc3RyxLQUFLeUIsUUFBUSxFQUFFO0FBQUEsVUFBQyxLQUxsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1FO0FBQUEsVUFDRix1QkFBQyxTQUFNLE1BQU1kLEtBQUtVLEtBQUt5RixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLGFBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTZCxLQVZXO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXZixJQUFnQix1QkFBQyxTQUFNLFVBQVMsUUFBTyw2RkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFdBaER4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sbUJBQWtCLFVBQVMsNkRBQTRELFVBQVMsU0FDekcsaUNBQUMsU0FBTSxJQUFJN0ksU0FBUzBHLE9BQU9vQyxZQUN2QjtBQUFBLCtCQUFDLGNBQVcsT0FBTSxrQkFBaUIsOEpBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxRQUNqTCx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLHdIQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFDM0ksdUJBQUMsYUFBVSxJQUFJLE1BQU0vRyxLQUFLaUYsRUFBRSxzQkFBc0IsdUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0E1REc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEUDtBQUNKO0FBQUNsRixHQXhLZUQsYUFBVztBQUFBLFVBQ045QyxVQUNXdEIsaUJBU1pvQixRQUNJRyxRQUNQSCxRQUNEQyxZQStCYUUsUUFDREEsTUFBTTtBQUFBO0FBQUEsTUE5Q2xCNkM7QUEwS1QsZ0JBQVNrSCxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUVqSCxLQUFLLElBQUloRCxTQUFTO0FBQzFCLFFBQU0sQ0FBQ2lELFFBQVFDLFNBQVMsSUFBSXhFLGdCQUFnQjtBQUM1QyxRQUFNd0wsU0FBU2pILE9BQU9NLFNBQVM7QUFDL0IsUUFBTTRHLFlBQVlsSCxPQUFPYyxJQUFJLFVBQVUsS0FBSztBQUM1QyxRQUFNcUcsVUFBVW5ILE9BQU9jLElBQUksUUFBUSxLQUFLO0FBQ3hDLFFBQU1zRyxjQUFjcEgsT0FBT2MsSUFBSSxRQUFRLEtBQUs7QUFDNUMsUUFBTXVHLGdCQUFnQnJILE9BQU9nQyxJQUFJLFVBQVUsS0FBS2hDLE9BQU9nQyxJQUFJLFFBQVE7QUFDbkUsUUFBTXNGLGVBQWVDLG9CQUFvQkwsV0FBV0MsU0FBU0MsYUFBYSxDQUFDQyxhQUFhO0FBQ3hGLFFBQU0xRyxRQUFRMkcsZUFBZXZHLFNBQVk7QUFBQSxJQUNyQyxHQUFJZixPQUFPZ0MsSUFBSSxVQUFVLElBQUksRUFBRVAsVUFBVXlGLFVBQVUsSUFBSSxDQUFDO0FBQUEsSUFDeEQsR0FBSWxILE9BQU9nQyxJQUFJLFFBQVEsSUFBSSxFQUFFTCxRQUFRd0YsUUFBUSxJQUFJLENBQUM7QUFBQSxJQUNsRCxHQUFJbkgsT0FBT2dDLElBQUksUUFBUSxJQUFJLEVBQUV3RixRQUFRSixZQUErQixJQUFJLENBQUM7QUFBQSxFQUM3RTtBQUNBLFFBQU1oRyxPQUFPdkUsT0FBTyx1QkFBdUI4RCxTQUFTOEcsT0FBT0MsS0FBSy9HLEtBQUssRUFBRWdFLFNBQVMsRUFBRWhFLE1BQU0sSUFBSUksUUFBVyxDQUFDdUcsWUFBWTtBQUNwSCxRQUFNSyxJQUFJdkcsS0FBS0EsTUFBTUE7QUFDckIsUUFBTXdHLGtCQUFrQkQsR0FBR0U7QUFDM0IsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl4TSxTQUFTLEVBQUVrRyxVQUFVeUYsV0FBV3ZGLFFBQVF3RixTQUFTSyxRQUFRSixZQUFZLENBQUM7QUFDaEcsUUFBTVksZUFBZTFNLE9BQU8sS0FBSztBQUNqQyxRQUFNLENBQUMyTSxpQkFBaUJDLGtCQUFrQixJQUFJM00sU0FBUyxLQUFLO0FBQzVELFFBQU00TSxVQUFVN00sT0FBeUIsSUFBSTtBQUM3QyxRQUFNOE0sUUFBUTlNLE9BQXlCLElBQUk7QUFDM0MsUUFBTStNLFlBQVkvTSxPQUF5QixJQUFJO0FBQy9DLFFBQU1nTixhQUFhZixvQkFBb0JPLE1BQU1yRyxVQUFVcUcsTUFBTW5HLFFBQVFtRyxNQUFNTixRQUFRLEtBQUs7QUFDeEYsUUFBTWUscUJBQXFCTixrQkFBa0JLLGFBQWFoQjtBQUUxRGxNLFlBQVUsTUFBTTtBQUVaLFFBQUl3TSxtQkFBbUIsQ0FBQ1AsaUJBQWlCLENBQUNXLGFBQWF6SCxTQUFTO0FBQzVELFlBQU02QixPQUFPLElBQUlqQyxnQkFBZ0IsRUFBRXNCLFVBQVVtRyxnQkFBZ0JuRyxVQUFVRSxRQUFRaUcsZ0JBQWdCakcsUUFBUTZGLFFBQVFJLGdCQUFnQkosT0FBTyxDQUFDO0FBQ3ZJLFVBQUlwRixLQUFLOUIsU0FBUyxNQUFNMkcsT0FBUWhILFdBQVVtQyxNQUFNLEVBQUVhLFNBQVMsS0FBSyxDQUFDO0FBQUEsSUFDckU7QUFBQSxFQUNKLEdBQUcsQ0FBQzJFLGlCQUFpQlAsZUFBZUosUUFBUWhILFNBQVMsQ0FBQztBQUV0RDdFLFlBQVUsTUFBTTtBQUNaNE0saUJBQWF6SCxVQUFVO0FBQ3ZCLFVBQU1BLFVBQVUsSUFBSUosZ0JBQWdCOEcsTUFBTTtBQUMxQyxRQUFJLENBQUMxRyxRQUFReUIsSUFBSSxVQUFVLEtBQUssQ0FBQ3pCLFFBQVF5QixJQUFJLFFBQVEsRUFBRztBQUN4RCtGLGFBQVMsRUFBRXRHLFVBQVVsQixRQUFRTyxJQUFJLFVBQVUsS0FBSyxJQUFJYSxRQUFRcEIsUUFBUU8sSUFBSSxRQUFRLEtBQUssSUFBSTBHLFFBQVFqSCxRQUFRTyxJQUFJLFFBQVEsS0FBSyxNQUFNLENBQUM7QUFDaklvSCx1QkFBbUIsS0FBSztBQUFBLEVBQzVCLEdBQUcsQ0FBQ2pCLE1BQU0sQ0FBQztBQUVYLFFBQU11QixjQUFjQSxDQUFDakUsVUFBc0M7QUFDdkRBLFVBQU1rRSxlQUFlO0FBQ3JCUCx1QkFBbUIsSUFBSTtBQUN2QixRQUFJSSxZQUFZO0FBQ1osWUFBTTlELFNBQVM4RCxXQUFXSSxVQUFVLGFBQWFQLFFBQVE1SCxVQUFVK0gsV0FBV0ksVUFBVSxXQUFXTixNQUFNN0gsVUFBVThILFVBQVU5SDtBQUM3SGlFLGNBQVFtRSxNQUFNO0FBQ2Q7QUFBQSxJQUNKO0FBQ0EsVUFBTXZHLE9BQU8sSUFBSWpDLGdCQUFnQixFQUFFc0IsVUFBVXFHLE1BQU1yRyxVQUFVRSxRQUFRbUcsTUFBTW5HLFFBQVE2RixRQUFRTSxNQUFNTixPQUFPLENBQUM7QUFDekdVLHVCQUFtQixLQUFLO0FBQ3hCRixpQkFBYXpILFVBQVU7QUFDdkJOLGNBQVVtQyxJQUFJO0FBQUEsRUFDbEI7QUFFQSxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLDJCQUEwQixVQUFTLDRFQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZIO0FBQUEsSUFDNUg4QixZQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLElBQUlsRyxTQUFTNEssT0FBT0MsVUFBVSwrR0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SjtBQUFBLElBQ3BLLHVCQUFDLFNBQU0sT0FBTSw0QkFBMkIsVUFBVSw0QkFBNEI5SSxLQUFLeUIsUUFBUSxrQkFBa0IsVUFBUyxTQUFRLFVBQVMsV0FDbkksaUNBQUMsY0FBVyxXQUFVLFFBQU8sVUFBVWdILGFBQWEsZUFBWSx3QkFDNUQ7QUFBQSw2QkFBQyxTQUFNLFdBQVcsRUFBRXJFLElBQUksVUFBVTJFLElBQUksTUFBTSxHQUFHLFlBQVksRUFBRTNFLElBQUksV0FBVzJFLElBQUksV0FBVyxHQUFHLElBQUk5SyxTQUFTK0ssUUFBUUMsWUFDL0c7QUFBQSwrQkFBQyxhQUFVLFVBQVViLFNBQVMsTUFBSyxRQUFPLE9BQU0sV0FBVSxPQUFPTCxNQUFNckcsVUFBVSxVQUFVLENBQUE4QyxVQUFTO0FBQUV5RCx1QkFBYXpILFVBQVU7QUFBTXdILG1CQUFTLENBQUE5SSxXQUFVLEVBQUUsR0FBR0EsT0FBT3dDLFVBQVU4QyxNQUFNQyxPQUFPdkYsTUFBTSxFQUFFO0FBQUEsUUFBRyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxPQUFPeUQsb0JBQW9CRyxVQUFVLFlBQVksWUFBWUgsb0JBQW9CRyxVQUFVLGFBQWFILG1CQUFtQjVFLFVBQVUseUNBQXpYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK1o7QUFBQSxRQUMvWix1QkFBQyxhQUFVLFVBQVV5RSxPQUFPLE1BQUssUUFBTyxPQUFNLFlBQVcsT0FBT04sTUFBTW5HLFFBQVEsVUFBVSxDQUFBNEMsVUFBUztBQUFFeUQsdUJBQWF6SCxVQUFVO0FBQU13SCxtQkFBUyxDQUFBOUksV0FBVSxFQUFFLEdBQUdBLE9BQU8wQyxRQUFRNEMsTUFBTUMsT0FBT3ZGLE1BQU0sRUFBRTtBQUFBLFFBQUcsR0FBRyxXQUFXLEVBQUU0RixZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFFLEdBQUcsT0FBT3lELG9CQUFvQkcsVUFBVSxVQUFVLFlBQVlILG9CQUFvQkcsVUFBVSxXQUFXSCxtQkFBbUI1RSxVQUFVLHVDQUFoWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9aO0FBQUEsUUFDcFosdUJBQUMsYUFBVSxVQUFVMEUsV0FBVyxRQUFNLE1BQUMsT0FBTSxZQUFXLE9BQU9QLE1BQU1OLFFBQVEsVUFBVSxDQUFBakQsVUFBUztBQUFFeUQsdUJBQWF6SCxVQUFVO0FBQU13SCxtQkFBUyxDQUFBOUksV0FBVSxFQUFFLEdBQUdBLE9BQU91SSxRQUFRakQsTUFBTUMsT0FBT3ZGLE1BQU0sRUFBRTtBQUFBLFFBQUcsR0FBRyxPQUFPc0osb0JBQW9CRyxVQUFVLFVBQVUsWUFBWUgsb0JBQW9CRyxVQUFVLFdBQVdILG1CQUFtQjVFLFVBQVUsK0JBQzlUO0FBQUEsaUNBQUMsWUFBUyxPQUFNLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sUUFBTyxvQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxTQUFRLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLGFBRDVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxhQUFZLHVCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsV0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQ3NFLG1CQUFtQkssY0FBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHFCQUFXM0UsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLFNBVC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0MyRCxlQUFlLHVCQUFDLFNBQU0sVUFBUyxTQUFRLE1BQUssU0FBUTtBQUFBLDZCQUFDLFlBQU8sbURBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLE1BQVM7QUFBQSxTQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlJLElBQVcsdUJBQUMsY0FBVyxPQUFPbEcsTUFBTSxnQkFBZSxXQUFXdUcsZUFBSyxtQ0FDeE47QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBSyxPQUFNLHlCQUF3QixPQUFPQSxFQUFFc0IsdUJBQXVCLE1BQUssZ0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxRQUNyRyx1QkFBQyxRQUFLLE9BQU0scUJBQW9CLE9BQU90QixFQUFFdUIsMEJBQTBCLE1BQUssbUNBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxRQUN2Ryx1QkFBQyxRQUFLLE9BQU0seUJBQXdCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT3ZCLEVBQUV3QixlQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEdBQUssTUFBTXhCLEVBQUV3QixjQUFjLDRCQUE0QixzQ0FBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SztBQUFBLFFBQ3ZLLHVCQUFDLFFBQUssT0FBTSwwQkFBeUIsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPeEIsRUFBRXlCLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLEdBQUssTUFBSyxtQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBSjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxlQUFZLG1CQUFrQixJQUFJLENBQUNwTCxTQUFTMEcsT0FBT29DLFlBQVk5SSxTQUFTNkksS0FBS3dDLFlBQVksR0FDM0YxQjtBQUFBQSxVQUFFRSxVQUFVLHVCQUFDLGNBQVcsU0FBUSxTQUFRO0FBQUE7QUFBQSxVQUFJM0ssZUFBZXlLLEVBQUVFLE9BQU9wRyxRQUFRO0FBQUEsVUFBRTtBQUFBLFVBQUl2RSxlQUFleUssRUFBRUUsT0FBT2xHLE1BQU07QUFBQSxVQUFFO0FBQUEsVUFBYWdHLEVBQUVFLE9BQU9MLFdBQVcsUUFBUSxTQUFTRyxFQUFFRSxPQUFPTCxXQUFXLFNBQVMsU0FBUztBQUFBLGFBQTlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc007QUFBQSxRQUNuTix1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQjtBQUFBO0FBQUEsVUFBVXZLLFNBQVMwSyxFQUFFdEcsTUFBTXNHLEVBQUVFLFFBQVFyRyxZQUFZekIsS0FBS3lCLFFBQVE7QUFBQSxVQUFFO0FBQUEsVUFBSXpCLEtBQUt1SjtBQUFBQSxVQUFLO0FBQUEsVUFBWTNCLEVBQUVFLFFBQVFyRyxZQUFZekIsS0FBS3lCO0FBQUFBLGFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUw7QUFBQSxXQUZ2TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGVBQVksZUFBWSwyQkFBMEIsU0FBUyxFQUFFMkMsSUFBSSxPQUFPb0YsSUFBSSxVQUFVLEdBQ25GO0FBQUEsK0JBQUMsU0FBTSxPQUFNLHNCQUFxQixVQUFTLDhEQUN2QztBQUFBLGlDQUFDLE9BQUksTUFBSyxPQUFNLGNBQVksZUFBZTVCLEVBQUVFLFFBQVFMLFVBQVUsSUFBSSx5QkFBeUIsZUFBWSx5QkFBd0IsSUFBSSxDQUFDLEVBQUVnQyxRQUFRLElBQUksR0FBR3hMLFNBQVMwRyxPQUFPK0Usa0JBQWtCLEdBQ25MOUIsWUFBRStCLE9BQU8vRSxTQUFTLHVCQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUFPLGlDQUFDLFlBQVMsTUFBTWdELEVBQUUrQixPQUFPLG9CQUFrQixNQUMxRztBQUFBLG1DQUFDLGlCQUFjLFFBQVEvTSxPQUFPZ04sa0JBQWtCLFVBQVUsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFNLFNBQVEsWUFBVyxRQUFRaE4sT0FBTzRDLGVBQWUsVUFBVUYsS0FBS0MsSUFBSSxHQUFHRCxLQUFLdUssS0FBS2pDLEVBQUUrQixNQUFNL0UsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLGVBQWUsQ0FBQTFGLFVBQVMvQixlQUFlMk0sT0FBTzVLLEtBQUssQ0FBQyxLQUF0SztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3SztBQUFBLFlBQ3hLLHVCQUFDLFNBQU0sZUFBZSxPQUFPLFFBQVF0QyxPQUFPNEMsaUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsV0FBUSxnQkFBZ0IsQ0FBQU4sVUFBUy9CLGVBQWUyTSxPQUFPNUssS0FBSyxDQUFDLEdBQUcsY0FBYyxFQUFFNkssWUFBWW5OLE9BQU9vTixRQUFRdkUsT0FBTzdJLE9BQU9xTixhQUFhNUUsYUFBYXpJLE9BQU9nTixpQkFBaUIsS0FBNUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEs7QUFBQSxZQUM5Syx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQU87QUFBQSxZQUNQLHVCQUFDLE9BQUksU0FBUSx5QkFBd0IsTUFBSyxxQkFBb0IsTUFBTWhOLE9BQU9zTixRQUFRLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsT0FBSSxTQUFRLDRCQUEyQixNQUFLLGlCQUFnQixNQUFNdE4sT0FBTzRDLGVBQWUsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEc7QUFBQSxlQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFuRSxLQVJtQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFSLElBQXlCLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSXZCLFNBQVMwRyxPQUFPd0YsaUJBQWlCLDREQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSCxLQVQ1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLE9BQU0sOEJBQTZCLE1BQU12QyxFQUFFK0IsU0FBUyxJQUFJLFFBQVEsQ0FBQVMsVUFBU0EsTUFBTTFJLFVBQVUsT0FBTSw2Q0FBNEMsU0FBUztBQUFBLFlBQzNKLEVBQUVNLEtBQUssU0FBU3VFLE9BQU8sZUFBZUMsUUFBUUEsQ0FBQTRELFVBQVMsR0FBR2pOLGVBQWVpTixNQUFNMUksUUFBUSxDQUFDLE1BQU12RSxlQUFlaU4sTUFBTXhJLE1BQU0sQ0FBQyxHQUFHO0FBQUEsWUFDN0gsRUFBRUksS0FBSyxTQUFTdUUsT0FBTyxZQUFZRyxPQUFPLFNBQVNGLFFBQVFBLENBQUE0RCxVQUFTQSxNQUFNbEIsc0JBQXNCO0FBQUEsWUFDaEcsRUFBRWxILEtBQUssV0FBV3VFLE9BQU8saUJBQWlCRyxPQUFPLFNBQVNGLFFBQVFBLENBQUE0RCxVQUFTQSxNQUFNakIseUJBQXlCO0FBQUEsWUFDMUcsRUFBRW5ILEtBQUssYUFBYXVFLE9BQU8sZ0JBQWdCRyxPQUFPLFNBQVNGLFFBQVFBLENBQUE0RCxVQUFTLHVCQUFDLFVBQU8sT0FBT0EsTUFBTWYsa0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DLEVBQUk7QUFBQSxZQUNwSCxFQUFFckgsS0FBSyxVQUFVdUUsT0FBTyxlQUFlRyxPQUFPLFNBQVNGLFFBQVFBLENBQUE0RCxVQUFTLHVCQUFDLFVBQU8sT0FBT0EsTUFBTWhCLGVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDLEVBQUk7QUFBQSxVQUFDLEtBTGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUU7QUFBQSxhQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE9BQU0sNEJBQTJCLFVBQVMscUNBQzdDLGlDQUFDLE9BQUksZUFBWSw4QkFBNkIsSUFBSW5MLFNBQVMwRyxPQUFPMEYsa0JBQzlELGlDQUFDLFNBQU0sV0FBVSxNQUFLLGVBQVksMkJBQTBCLElBQUksQ0FBQyxFQUFFekMsR0FBRyxHQUFHMEMsR0FBRyxFQUFFLEdBQUdyTSxTQUFTMEcsT0FBTzRGLGlCQUFpQnRNLFNBQVMwRyxPQUFPNkYsV0FBVyxHQUN4STVDLFlBQUU2QyxhQUFhN0YsU0FBU2dELEVBQUU2QyxhQUFhL0YsSUFBSSxDQUFDZ0csVUFBVXBFLFVBQVUsdUJBQUMsY0FBVyxXQUFVLE1BQW1Db0Usc0JBQXpCLEdBQUdwRSxLQUFLLElBQUlvRSxRQUFRLElBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0UsQ0FBYSxJQUFJLHVCQUFDLGNBQVcsV0FBVSxNQUFLLE9BQU0sa0JBQWlCLDBEQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGLEtBRHBQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxPQUFNLHdCQUF1QixVQUFTLDhDQUN6QztBQUFBLGlDQUFDLE9BQUksTUFBSyxPQUFNLGNBQVksaUNBQWlDOUMsRUFBRStDLGdCQUFnQi9GLE1BQU0sU0FBUyxlQUFZLHdCQUF1QixJQUFJLENBQUMsRUFBRTZFLFFBQVEsSUFBSSxHQUFHeEwsU0FBUzBHLE9BQU8rRSxrQkFBa0IsR0FDcEw5QixZQUFFK0MsZ0JBQWdCL0YsU0FBUyx1QkFBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFBTyxpQ0FBQyxZQUFTLE1BQU1nRCxFQUFFK0MsaUJBQWlCLG9CQUFrQixNQUM3SDtBQUFBLG1DQUFDLGlCQUFjLFFBQVEvTixPQUFPZ04sa0JBQWtCLFVBQVUsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxTQUFNLFNBQVEsVUFBUyxRQUFRaE4sT0FBTzRDLGVBQWUsVUFBVSxHQUFHLFFBQVEsSUFBSSxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsWUFDN0csdUJBQUMsU0FBTSxlQUFlLE9BQU8sUUFBUTVDLE9BQU80QyxpQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxXQUFRLGNBQWMsRUFBRXVLLFlBQVluTixPQUFPb04sUUFBUXZFLE9BQU83SSxPQUFPcU4sYUFBYTVFLGFBQWF6SSxPQUFPZ04saUJBQWlCLEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNIO0FBQUEsWUFDdEgsdUJBQUMsT0FBSSxTQUFRLFNBQVEsTUFBSyxpQkFBZ0IsTUFBTWhOLE9BQU9zTixRQUFRLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsZUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU01RSxLQU40QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1qQixJQUF5Qix1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUlqTSxTQUFTMEcsT0FBT3dGLGlCQUFpQixtREFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkcsS0FQbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxNQUFNdkMsRUFBRStDLGlCQUFpQixRQUFRLENBQUFDLFdBQVVBLE9BQU9BLFFBQVEsT0FBTSx3QkFBdUIsT0FBTSwyQ0FBMEMsU0FBUztBQUFBLFlBQ3ZKLEVBQUU1SSxLQUFLLFVBQVV1RSxPQUFPLFNBQVNDLFFBQVFBLENBQUFvRSxXQUFVQSxPQUFPQSxPQUFPO0FBQUEsWUFDakUsRUFBRTVJLEtBQUssU0FBU3VFLE9BQU8saUJBQWlCRyxPQUFPLFNBQVNGLFFBQVFBLENBQUFvRSxXQUFVQSxPQUFPQyxNQUFNO0FBQUEsVUFBQyxLQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdFO0FBQUEsYUFiTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkNBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJNU0sU0FBUzZJLEtBQUtnRSxlQUFlLGlKQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlMO0FBQUEsU0F2RCtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RDVOLEtBeERvSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RoSztBQUFBLE9BeEVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RVA7QUFDSjtBQUFDN0QsSUFsSWVELGVBQWE7QUFBQSxVQUNSaEssVUFDV3RCLGlCQVlmb0IsTUFBTTtBQUFBO0FBQUEsTUFkUGtLO0FBb0loQixTQUFTUSxvQkFBb0I5RixVQUFrQkUsUUFBZ0I2RixRQUFnQnNELGNBQTRGO0FBQ3ZLLE1BQUksQ0FBQyxDQUFDLE9BQU8sUUFBUSxPQUFPLEVBQUUvSCxTQUFTeUUsTUFBTSxFQUFHLFFBQU8sRUFBRWtCLE9BQU8sVUFBVS9FLFNBQVMsbUNBQW1DO0FBQ3RILE1BQUltSCxnQkFBZ0IsQ0FBQ3JKLFlBQVksQ0FBQ0UsT0FBUSxRQUFPO0FBQ2pELE1BQUksQ0FBQ3hFLGdCQUFnQnNFLFFBQVEsRUFBRyxRQUFPLEVBQUVpSCxPQUFPLFlBQVkvRSxTQUFTLDRCQUE0QjtBQUNqRyxNQUFJLENBQUN4RyxnQkFBZ0J3RSxNQUFNLEVBQUcsUUFBTyxFQUFFK0csT0FBTyxVQUFVL0UsU0FBUyw2QkFBNkI7QUFDOUYsTUFBSWxDLFdBQVdFLE9BQVEsUUFBTyxFQUFFK0csT0FBTyxZQUFZL0UsU0FBUyxtREFBbUQ7QUFDL0csUUFBTW9ILE9BQU8xTCxLQUFLMkwsT0FBT0MsS0FBS0MsTUFBTSxHQUFHdkosTUFBTSxnQkFBZ0IsSUFBSXNKLEtBQUtDLE1BQU0sR0FBR3pKLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLEtBQUssSUFBSyxJQUFJO0FBQ3JJLE1BQUlzSixPQUFPLElBQUssUUFBTyxFQUFFckMsT0FBTyxVQUFVL0UsU0FBUywrQ0FBK0M7QUFDbEcsU0FBTztBQUNYO0FBQUMsSUFBQS9ELElBQUF1TCxLQUFBQztBQUFBLGFBQUF4TCxJQUFBO0FBQUEsYUFBQXVMLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU2VjdGlvbkdyaWQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlU3RhdGUiLCJ2aXN1YWxTeCIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiTGluayIsIk1lbnVJdGVtIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwiQmFyIiwiQmFyQ2hhcnQiLCJDYXJ0ZXNpYW5HcmlkIiwiTGVnZW5kIiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsIlRleHQiLCJUb29sdGlwIiwiWEF4aXMiLCJZQXhpcyIsImNvbG9ycyIsInRva2VucyIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsInVzZUNhbiIsImRhdGVUaW1lIiwiZm9ybWF0RGF0ZU9ubHkiLCJpc1ZhbGlkRGF0ZU9ubHkiLCJBbW91bnQiLCJEYXRhVGFibGUiLCJEZXRhaWxMaW5lIiwiRXJyb3JOb3RpY2UiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJQYWdlciIsIlF1ZXJ5U3RhdGUiLCJSb3V0ZUxpbmsiLCJTdGF0IiwiU3RhdHMiLCJTdGF0dXMiLCJsYXlvdXRTeCIsImF1dGhvcml6ZWREb3dubG9hZEhyZWYiLCJkYXRlSW5UaW1lem9uZSIsInJlcG9ydERhdGVCb3VuZGFyeSIsInJlcG9ydEZpbGVuYW1lIiwicmVwb3J0TGFiZWxzIiwiaW52ZW50b3J5Iiwib3JkZXJzIiwiY2FzaGZsb3ciLCJwcm9maXRfbG9zcyIsInNvdXJjZVBlcm1pc3Npb25zIiwiTWFya2V0aW5nUmVhc29uVGljayIsIngiLCJ5Iiwid2lkdGgiLCJ2aXNpYmxlVGlja3NDb3VudCIsInBheWxvYWQiLCJ2YWx1ZSIsInRyaW0iLCJjYXRlZ29yeUxhYmVsSW5zZXQiLCJsYWJlbFdpZHRoIiwiTWF0aCIsIm1heCIsInRleHRTZWNvbmRhcnkiLCJmb250U2l6ZSIsImZvbnRTaXplcyIsImJvZHkiLCJmb250RmFtaWx5IiwiX2MiLCJSZXBvcnRzUGFnZSIsIl9zIiwic2hvcCIsInBhcmFtcyIsInNldFBhcmFtcyIsImxhdGVzdFBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInBlbmRpbmdTZWFyY2giLCJjb21taXR0ZWRTZWFyY2giLCJ0b1N0cmluZyIsImN1cnJlbnQiLCJzdW1tYXJ5IiwiY2FuUmVhZEpvYnMiLCJqb2JzIiwicXVlcnkiLCJsaW1pdCIsImN1cnNvciIsImdldCIsInVuZGVmaW5lZCIsInJ1biIsInJlcXVlc3RlZFR5cGUiLCJ0eXBlIiwic25hcHNob3RBc09mIiwiZGF0YSIsImFzT2YiLCJkZWZhdWx0UmFuZ2UiLCJjdXJyZW50RGF0ZSIsInRpbWV6b25lIiwiZnJvbURhdGUiLCJzbGljZSIsInRvRGF0ZSIsImZyb21WYWx1ZSIsInRvVmFsdWUiLCJyZWFkUmVwb3J0RGF0ZSIsImtleSIsImhhcyIsImZyb20iLCJ0byIsInNldFJlcG9ydFBhcmFtIiwibmV4dCIsInNldCIsImZsdXNoU3luYyIsInJhbmdlRXJyb3IiLCJzZXRSYW5nZUVycm9yIiwibGFzdEV4cG9ydCIsInNldExhc3RFeHBvcnQiLCJjYW5FeHBvcnRSZXBvcnRzIiwiY2FuRXhwb3J0U291cmNlIiwiYXZhaWxhYmxlUmVwb3J0cyIsInJlcG9ydEF2YWlsYWJsZSIsImluY2x1ZGVzIiwiY2hhbmdlZCIsInJlcGxhY2UiLCJzdWJtaXQiLCJSYW5nZUVycm9yIiwicmVxdWVzdCIsInJlcG9ydFR5cGUiLCJmb3JtYXQiLCJyZXNwb25zZSIsImV4ZWN1dGUiLCJqb2IiLCJlcnJvciIsIm1lc3NhZ2UiLCJoYW5kbGVFeHBvcnQiLCJsYXN0RG93bmxvYWQiLCJzdGF0dXMiLCJkb3dubG9hZFVybCIsImxvY2F0aW9uIiwib3JpZ2luIiwiX19NT0NLX18iLCJ4cyIsInhsIiwibWluV2lkdGgiLCJtYXhXaWR0aCIsImV2ZW50IiwidGFyZ2V0IiwibWFwIiwicmVwb3J0IiwibGVuZ3RoIiwic20iLCJpbnB1dExhYmVsIiwic2hyaW5rIiwicGVuZGluZyIsImlkIiwiYWN0aW9ucyIsImxpbmtUYXJnZXQiLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImJvcmRlclJhZGl1cyIsInJhZGl1cyIsImNvbnRyb2wiLCJjb2xvciIsImZvbnRXZWlnaHQiLCJ0eXBvZ3JhcGh5Iiwic2VtaWJvbGQiLCJiZ2NvbG9yIiwidGV4dERlY29yYXRpb24iLCJvdXRsaW5lIiwiZm9jdXNSaW5nIiwib3V0bGluZUNvbG9yIiwib3V0bGluZU9mZnNldCIsImNvbnRyb2xPZmZzZXQiLCJ3YXJuaW5ncyIsIndhcm5pbmciLCJpbmRleCIsImxhYmVsIiwicmVuZGVyIiwia2luZCIsImFsaWduIiwiY29tcGxldGVkIiwidG90YWwiLCJ1cGRhdGVkQXQiLCJwYWdlIiwiY29udGV4dEdhcCIsIk1hcmtldGluZ1BhZ2UiLCJfczIiLCJzZWFyY2giLCJmcm9tUGFyYW0iLCJ0b1BhcmFtIiwiYnVja2V0UGFyYW0iLCJoYXNEYXRlRmlsdGVyIiwiYXBwbGllZEVycm9yIiwibWFya2V0aW5nUmFuZ2VFcnJvciIsImJ1Y2tldCIsIk9iamVjdCIsImtleXMiLCJtIiwibWFya2V0aW5nUGVyaW9kIiwicGVyaW9kIiwiZHJhZnQiLCJzZXREcmFmdCIsImRyYWZ0VG91Y2hlZCIsInNob3dGaWx0ZXJFcnJvciIsInNldFNob3dGaWx0ZXJFcnJvciIsImZyb21SZWYiLCJ0b1JlZiIsImJ1Y2tldFJlZiIsImRyYWZ0RXJyb3IiLCJ2aXNpYmxlRmlsdGVyRXJyb3IiLCJhcHBseUZpbHRlciIsInByZXZlbnREZWZhdWx0IiwiZmllbGQiLCJmb2N1cyIsIm5vdGljZSIsImFmdGVyR2FwIiwibWQiLCJ0b29sYmFyIiwiY29udHJvbEdhcCIsImtub3duQXR0cmlidXRlZE9yZGVycyIsInVua25vd25BdHRyaWJ1dGlvbk9yZGVycyIsImFjdHVhbFNwZW5kIiwiZXN0aW1hdGVkU3BlbmQiLCJzZWN0aW9uQWZ0ZXIiLCJuYW1lIiwibGciLCJoZWlnaHQiLCJjaGFydFZpZXdwb3J0SW5zZXQiLCJ0cmVuZCIsImJvcmRlckRlY29yYXRpdmUiLCJjZWlsIiwiU3RyaW5nIiwiYmFja2dyb3VuZCIsInJhaXNlZCIsInRleHRQcmltYXJ5IiwiYWNjZW50IiwiZW1wdHlTdGF0ZUluc2V0IiwicG9pbnQiLCJsaXN0U3VyZmFjZUluc2V0IiwicCIsImxpc3RNYXJrZXJJbnNldCIsImxpc3RJdGVtR2FwIiwidG9wUXVlc3Rpb25zIiwicXVlc3Rpb24iLCJsb3N0U2FsZVJlYXNvbnMiLCJyZWFzb24iLCJjb3VudCIsInNlY3Rpb25CZWZvcmUiLCJhbGxvd0RlZmF1bHQiLCJkYXlzIiwiZmxvb3IiLCJEYXRlIiwicGFyc2UiLCJfYzIiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFjdGlvbkdyb3VwLCBGb3JtRmllbGRzLCBQYWdlU2VjdGlvbnMsIFNlY3Rpb25HcmlkIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xuaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIExpbmssIE1lbnVJdGVtLCBTdGFjaywgVGV4dEZpZWxkLCBUeXBvZ3JhcGh5IH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgeyBCYXIsIEJhckNoYXJ0LCBDYXJ0ZXNpYW5HcmlkLCBMZWdlbmQsIFJlc3BvbnNpdmVDb250YWluZXIsIFRleHQsIFRvb2x0aXAsIFhBeGlzLCBZQXhpcyB9IGZyb20gJ3JlY2hhcnRzJztcbmltcG9ydCB0eXBlIHsgRXhwb3J0UmVxdWVzdCwgSm9iLCBNYXJrZXRpbmdCdWNrZXQgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IGNvbG9ycywgdG9rZW5zIH0gZnJvbSAnQGJvdHNhbGVzL3Rva2Vucyc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICcuLi8uLi9zaGFyZWQvYXBpL2hvb2tzJztcbmltcG9ydCB7IHVzZVNjb3BlLCB1c2VDYW4gfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvc2NvcGUnO1xuaW1wb3J0IHsgZGF0ZVRpbWUsIGZvcm1hdERhdGVPbmx5LCBpc1ZhbGlkRGF0ZU9ubHkgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvZm9ybWF0JztcbmltcG9ydCB7IEFtb3VudCwgRGF0YVRhYmxlLCBEZXRhaWxMaW5lLCBFcnJvck5vdGljZSwgUGFnZUhlYWRlciwgUGFuZWwsIFBhZ2VyLCBRdWVyeVN0YXRlLCBSb3V0ZUxpbmssIFN0YXQsIFN0YXRzLCBTdGF0dXMgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9sYXlvdXQnO1xuaW1wb3J0IHsgYXV0aG9yaXplZERvd25sb2FkSHJlZiwgZGF0ZUluVGltZXpvbmUsIHJlcG9ydERhdGVCb3VuZGFyeSwgcmVwb3J0RmlsZW5hbWUgfSBmcm9tICcuL3JlcG9ydC11dGlscyc7XG5cbmNvbnN0IHJlcG9ydExhYmVsczogUmVjb3JkPEV4cG9ydFJlcXVlc3RbJ3JlcG9ydFR5cGUnXSwgc3RyaW5nPiA9IHtcbiAgICBpbnZlbnRvcnk6ICdU4buTbiBraG8nLCBvcmRlcnM6ICfEkMahbiBow6BuZycsIGNhc2hmbG93OiAnRMOybmcgdGnhu4FuJywgcHJvZml0X2xvc3M6ICdM4bujaSBuaHXhuq1uJyxcbn07XG5jb25zdCBzb3VyY2VQZXJtaXNzaW9uczogUmVjb3JkPEV4cG9ydFJlcXVlc3RbJ3JlcG9ydFR5cGUnXSwgc3RyaW5nPiA9IHtcbiAgICBpbnZlbnRvcnk6ICdpbnZlbnRvcnkucmVhZCcsIG9yZGVyczogJ29yZGVycy5yZWFkJywgY2FzaGZsb3c6ICdmaW5hbmNlLnJlYWQnLCBwcm9maXRfbG9zczogJ2ZpbmFuY2UucmVhZCcsXG59O1xuXG5mdW5jdGlvbiBNYXJrZXRpbmdSZWFzb25UaWNrKHsgeCA9IDAsIHkgPSAwLCB3aWR0aCA9IDAsIHZpc2libGVUaWNrc0NvdW50ID0gMSwgcGF5bG9hZCB9OiB7IHg/OiBudW1iZXI7IHk/OiBudW1iZXI7IHdpZHRoPzogbnVtYmVyOyB2aXNpYmxlVGlja3NDb3VudD86IG51bWJlcjsgcGF5bG9hZD86IHsgdmFsdWU/OiB1bmtub3duIH0gfSkge1xuICAgIGNvbnN0IHZhbHVlID0gdHlwZW9mIHBheWxvYWQ/LnZhbHVlID09PSAnc3RyaW5nJyA/IHBheWxvYWQudmFsdWUudHJpbSgpIDogJyc7XG4gICAgY29uc3QgY2F0ZWdvcnlMYWJlbEluc2V0ID0gODtcbiAgICBjb25zdCBsYWJlbFdpZHRoID0gTWF0aC5tYXgoMSwgd2lkdGggLyBNYXRoLm1heCgxLCB2aXNpYmxlVGlja3NDb3VudCkgLSBjYXRlZ29yeUxhYmVsSW5zZXQpO1xuICAgIHJldHVybiA8VGV4dCB4PXt4fSB5PXt5fSBkeT17MTJ9IHdpZHRoPXtsYWJlbFdpZHRofSBicmVha0FsbCB2ZXJ0aWNhbEFuY2hvcj1cInN0YXJ0XCIgdGV4dEFuY2hvcj1cIm1pZGRsZVwiIGZpbGw9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fVxuICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogdG9rZW5zLmZvbnRTaXplcy5ib2R5LCBmb250RmFtaWx5OiB0b2tlbnMuZm9udEZhbWlseSB9fT57dmFsdWV9PC9UZXh0Pjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlcG9ydHNQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBbcGFyYW1zLCBzZXRQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gICAgY29uc3QgbGF0ZXN0UGFyYW1zID0gdXNlUmVmKG5ldyBVUkxTZWFyY2hQYXJhbXMocGFyYW1zKSk7XG4gICAgY29uc3QgcGVuZGluZ1NlYXJjaCA9IHVzZVJlZjxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBjb21taXR0ZWRTZWFyY2ggPSBwYXJhbXMudG9TdHJpbmcoKTtcbiAgICAgICAgaWYgKHBlbmRpbmdTZWFyY2guY3VycmVudCAhPT0gbnVsbCAmJiBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgIT09IGNvbW1pdHRlZFNlYXJjaCkgcmV0dXJuO1xuICAgICAgICBsYXRlc3RQYXJhbXMuY3VycmVudCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMocGFyYW1zKTtcbiAgICAgICAgcGVuZGluZ1NlYXJjaC5jdXJyZW50ID0gbnVsbDtcbiAgICB9LCBbcGFyYW1zXSk7XG4gICAgY29uc3Qgc3VtbWFyeSA9IHVzZUFwaSgnZ2V0UmVwb3J0U3VtbWFyeScpO1xuICAgIGNvbnN0IGNhblJlYWRKb2JzID0gdXNlQ2FuKCdqb2JzLnJlYWQnKTtcbiAgICBjb25zdCBqb2JzID0gdXNlQXBpKCdsaXN0Sm9icycsIHsgcXVlcnk6IHsgbGltaXQ6IDEwLCBjdXJzb3I6IHBhcmFtcy5nZXQoJ2N1cnNvcicpIHx8IHVuZGVmaW5lZCB9IH0sIGNhblJlYWRKb2JzKTtcbiAgICBjb25zdCBydW4gPSB1c2VDb21tYW5kKCdjcmVhdGVFeHBvcnQnLCBbJ2xpc3RKb2JzJ10pO1xuICAgIGNvbnN0IHJlcXVlc3RlZFR5cGUgPSBwYXJhbXMuZ2V0KCdyZXBvcnRUeXBlJyk7XG4gICAgY29uc3QgdHlwZTogRXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddID0gcmVxdWVzdGVkVHlwZSA9PT0gJ2ludmVudG9yeScgfHwgcmVxdWVzdGVkVHlwZSA9PT0gJ2Nhc2hmbG93JyB8fCByZXF1ZXN0ZWRUeXBlID09PSAncHJvZml0X2xvc3MnID8gcmVxdWVzdGVkVHlwZSA6ICdvcmRlcnMnO1xuICAgIGNvbnN0IHNuYXBzaG90QXNPZiA9IHN1bW1hcnkuZGF0YT8uZGF0YS5hc09mO1xuICAgIGNvbnN0IGRlZmF1bHRSYW5nZSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIXNuYXBzaG90QXNPZikgcmV0dXJuIG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50RGF0ZSA9IGRhdGVJblRpbWV6b25lKHNuYXBzaG90QXNPZiwgc2hvcC50aW1lem9uZSk7XG4gICAgICAgICAgICByZXR1cm4geyBmcm9tRGF0ZTogYCR7Y3VycmVudERhdGUuc2xpY2UoMCwgNyl9LTAxYCwgdG9EYXRlOiBjdXJyZW50RGF0ZSB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHsgcmV0dXJuIG51bGw7IH1cbiAgICB9LCBbc2hvcC50aW1lem9uZSwgc25hcHNob3RBc09mXSk7XG4gICAgY29uc3QgZnJvbVZhbHVlID0gcGFyYW1zLmdldCgnZnJvbURhdGUnKTtcbiAgICBjb25zdCB0b1ZhbHVlID0gcGFyYW1zLmdldCgndG9EYXRlJyk7XG4gICAgY29uc3QgcmVhZFJlcG9ydERhdGUgPSAoa2V5OiAnZnJvbURhdGUnIHwgJ3RvRGF0ZScsIHZhbHVlOiBzdHJpbmcgfCBudWxsKSA9PiB7XG4gICAgICAgIGlmIChpc1ZhbGlkRGF0ZU9ubHkodmFsdWUpKSByZXR1cm4gdmFsdWU7XG4gICAgICAgIGlmIChwYXJhbXMuaGFzKGtleSkgJiYgdmFsdWUgPT09ICcnKSByZXR1cm4gJyc7XG4gICAgICAgIHJldHVybiBkZWZhdWx0UmFuZ2U/LltrZXldIHx8ICcnO1xuICAgIH07XG4gICAgY29uc3QgZnJvbSA9IHJlYWRSZXBvcnREYXRlKCdmcm9tRGF0ZScsIGZyb21WYWx1ZSk7XG4gICAgY29uc3QgdG8gPSByZWFkUmVwb3J0RGF0ZSgndG9EYXRlJywgdG9WYWx1ZSk7XG4gICAgY29uc3Qgc2V0UmVwb3J0UGFyYW0gPSAoa2V5OiAncmVwb3J0VHlwZScgfCAnZnJvbURhdGUnIHwgJ3RvRGF0ZScsIHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobGF0ZXN0UGFyYW1zLmN1cnJlbnQpO1xuICAgICAgICBpZiAoa2V5ID09PSAncmVwb3J0VHlwZScpIG5leHQuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgICBlbHNlIG5leHQuc2V0KGtleSwgaXNWYWxpZERhdGVPbmx5KHZhbHVlKSA/IHZhbHVlIDogJycpO1xuICAgICAgICBsYXRlc3RQYXJhbXMuY3VycmVudCA9IG5leHQ7XG4gICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG5leHQudG9TdHJpbmcoKTtcbiAgICAgICAgc2V0UGFyYW1zKG5leHQsIHsgZmx1c2hTeW5jOiB0cnVlIH0pO1xuICAgIH07XG4gICAgY29uc3QgW3JhbmdlRXJyb3IsIHNldFJhbmdlRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtsYXN0RXhwb3J0LCBzZXRMYXN0RXhwb3J0XSA9IHVzZVN0YXRlPHsgam9iOiBKb2I7IHR5cGU6IEV4cG9ydFJlcXVlc3RbJ3JlcG9ydFR5cGUnXTsgZnJvbTogc3RyaW5nOyB0bzogc3RyaW5nIH0gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBjYW5FeHBvcnRSZXBvcnRzID0gdXNlQ2FuKCdyZXBvcnRzLmV4cG9ydCcpO1xuICAgIGNvbnN0IGNhbkV4cG9ydFNvdXJjZSA9IHVzZUNhbihzb3VyY2VQZXJtaXNzaW9uc1t0eXBlXSk7XG4gICAgY29uc3QgYXZhaWxhYmxlUmVwb3J0cyA9IHN1bW1hcnkuZGF0YT8uZGF0YS5hdmFpbGFibGVSZXBvcnRzIHx8IFtdO1xuICAgIGNvbnN0IHJlcG9ydEF2YWlsYWJsZSA9IGF2YWlsYWJsZVJlcG9ydHMuaW5jbHVkZXModHlwZSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIXNuYXBzaG90QXNPZikgcmV0dXJuO1xuICAgICAgICBpZiAoIWRlZmF1bHRSYW5nZSkge1xuICAgICAgICAgICAgc2V0UmFuZ2VFcnJvcignTcO6aSBnaeG7nSBj4butYSBow6BuZyBob+G6t2MgbeG7kWMgdGjhu51pIGdpYW4gYsOhbyBjw6FvIGtow7RuZyBo4bujcCBs4buHLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsYXRlc3RQYXJhbXMuY3VycmVudCk7XG4gICAgICAgICAgICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICAgICAgICAgICAgaWYgKHJlcXVlc3RlZFR5cGUgIT09ICdpbnZlbnRvcnknICYmIHJlcXVlc3RlZFR5cGUgIT09ICdjYXNoZmxvdycgJiYgcmVxdWVzdGVkVHlwZSAhPT0gJ3Byb2ZpdF9sb3NzJyAmJiByZXF1ZXN0ZWRUeXBlICE9PSAnb3JkZXJzJykge1xuICAgICAgICAgICAgICAgIG5leHQuc2V0KCdyZXBvcnRUeXBlJywgJ29yZGVycycpO1xuICAgICAgICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFwYXJhbXMuaGFzKCdmcm9tRGF0ZScpIHx8IChmcm9tVmFsdWUgJiYgIWlzVmFsaWREYXRlT25seShmcm9tVmFsdWUpKSkge1xuICAgICAgICAgICAgICAgIG5leHQuc2V0KCdmcm9tRGF0ZScsIGRlZmF1bHRSYW5nZS5mcm9tRGF0ZSk7XG4gICAgICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXBhcmFtcy5oYXMoJ3RvRGF0ZScpIHx8ICh0b1ZhbHVlICYmICFpc1ZhbGlkRGF0ZU9ubHkodG9WYWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgbmV4dC5zZXQoJ3RvRGF0ZScsIGRlZmF1bHRSYW5nZS50b0RhdGUpO1xuICAgICAgICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNoYW5nZWQpIHtcbiAgICAgICAgICAgICAgICBsYXRlc3RQYXJhbXMuY3VycmVudCA9IG5leHQ7XG4gICAgICAgICAgICAgICAgcGVuZGluZ1NlYXJjaC5jdXJyZW50ID0gbmV4dC50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgIHNldFBhcmFtcyhuZXh0LCB7IHJlcGxhY2U6IHRydWUsIGZsdXNoU3luYzogdHJ1ZSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7IHNldFJhbmdlRXJyb3IoJ03DumkgZ2nhu50gY+G7rWEgaMOgbmcgaG/hurdjIG3hu5FjIHRo4budaSBnaWFuIGLDoW8gY8OhbyBraMO0bmcgaOG7o3AgbOG7hy4nKTsgfVxuICAgIH0sIFtkZWZhdWx0UmFuZ2UsIHBhcmFtcywgcmVxdWVzdGVkVHlwZSwgZnJvbVZhbHVlLCB0b1ZhbHVlLCBzZXRQYXJhbXMsIHNuYXBzaG90QXNPZl0pO1xuXG4gICAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRSYW5nZUVycm9yKCcnKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICghc25hcHNob3RBc09mIHx8ICFmcm9tIHx8ICF0bykgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0NoxrBhIGPDsyBzbmFwc2hvdCBob+G6t2Mga2hv4bqjbmcgbmfDoHkgxJHhuqd5IMSR4bunLicpO1xuICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICByZXBvcnRUeXBlOiB0eXBlLFxuICAgICAgICAgICAgICAgIGZvcm1hdDogJ2NzdicsXG4gICAgICAgICAgICAgICAgZnJvbTogcmVwb3J0RGF0ZUJvdW5kYXJ5KGZyb20sICdzdGFydCcsIHNob3AudGltZXpvbmUpLFxuICAgICAgICAgICAgICAgIHRvOiByZXBvcnREYXRlQm91bmRhcnkodG8sICdlbmQnLCBzaG9wLnRpbWV6b25lKSxcbiAgICAgICAgICAgICAgICB0aW1lem9uZTogc2hvcC50aW1lem9uZSxcbiAgICAgICAgICAgICAgICBzbmFwc2hvdEFzT2YsXG4gICAgICAgICAgICB9IHNhdGlzZmllcyBFeHBvcnRSZXF1ZXN0O1xuICAgICAgICAgICAgc2V0TGFzdEV4cG9ydChudWxsKTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcnVuLmV4ZWN1dGUoeyBib2R5OiByZXF1ZXN0IH0pO1xuICAgICAgICAgICAgc2V0TGFzdEV4cG9ydCh7IGpvYjogcmVzcG9uc2UuZGF0YSwgdHlwZSwgZnJvbSwgdG8gfSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBSYW5nZUVycm9yKSBzZXRSYW5nZUVycm9yKGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVFeHBvcnQgPSAoKSA9PiB7IHZvaWQgc3VibWl0KCk7IH07XG5cbiAgICBjb25zdCBsYXN0RG93bmxvYWQgPSBsYXN0RXhwb3J0Py5qb2Iuc3RhdHVzID09PSAnc3VjY2VlZGVkJyAmJiBsYXN0RXhwb3J0LmpvYi5kb3dubG9hZFVybFxuICAgICAgICA/IGF1dGhvcml6ZWREb3dubG9hZEhyZWYobGFzdEV4cG9ydC5qb2IuZG93bmxvYWRVcmwsIGxvY2F0aW9uLm9yaWdpbiwgX19NT0NLX18pXG4gICAgICAgIDogbnVsbDtcblxuICAgIHJldHVybiA8PlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkLDoW8gY8OhbyAmIHh14bqldCBk4buvIGxp4buHdVwiIHN1YnRpdGxlPVwiWHXhuqV0IHNuYXBzaG90IGRvIEFQSSB04bqhbzsgc+G7kSBsaeG7h3UgdOG7lW5nIGjhu6NwIGtow7RuZyDEkcaw4bujYyB0w61uaCB04burIG3hu5l0IHRyYW5nIGRhbmggc8OhY2guXCIgLz5cbiAgICAgICAgPFNlY3Rpb25HcmlkIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1tYWluLWxheW91dFwiIGNvbHVtbnM9e3sgeHM6ICdtaW5tYXgoMCwgMWZyKScsIHhsOiAnbWlubWF4KDAsIDEuMmZyKSBtaW5tYXgoMCwgLjhmciknIH19IGFsaWduSXRlbXM9eydzdGFydCd9IGdlb21ldHJ5PXt7bWluV2lkdGg6IDB9fT5cbiAgICAgICAgICAgIDxQYWdlU2VjdGlvbnMgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLXBhZ2Utc2VjdGlvbnNcIiA+XG4gICAgICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e3N1bW1hcnl9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICB7c3VtbWFyeS5kYXRhICYmIDxQYW5lbCB0aXRsZT1cIlThuqFvIHThu4dwIGLDoW8gY8Ohb1wiIHN1YnRpdGxlPVwiTmfDoHkgxJHGsOG7o2MgaGnhu4N1IHRoZW8gbcO6aSBnaeG7nSBj4butYSBow6BuZyB2w6AgZ+G7rWkgdGjDoG5oIG3hu5FjIHRo4budaSBnaWFuIHLDtSByw6BuZy5cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyBkYXRhLXRlc3RpZD1cInJlcG9ydHMtZXhwb3J0LWZvcm0tbGF5b3V0XCIgZ2VvbWV0cnk9e3ttYXhXaWR0aDogNzYwfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtydW4uZXJyb3J9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JhbmdlRXJyb3IgJiYgPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57cmFuZ2VFcnJvcn08L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiQsOhbyBjw6FvXCIgc2VsZWN0IHZhbHVlPXt0eXBlfSBvbkNoYW5nZT17ZXZlbnQgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGV2ZW50LnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSAnb3JkZXJzJyB8fCB2YWx1ZSA9PT0gJ2ludmVudG9yeScgfHwgdmFsdWUgPT09ICdjYXNoZmxvdycgfHwgdmFsdWUgPT09ICdwcm9maXRfbG9zcycpIHNldFJlcG9ydFBhcmFtKCdyZXBvcnRUeXBlJywgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRMYXN0RXhwb3J0KG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXZhaWxhYmxlUmVwb3J0cy5tYXAocmVwb3J0ID0+IDxNZW51SXRlbSB2YWx1ZT17cmVwb3J0fSBrZXk9e3JlcG9ydH0+e3JlcG9ydExhYmVsc1tyZXBvcnRdfTwvTWVudUl0ZW0+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXZhaWxhYmxlUmVwb3J0cy5sZW5ndGggPT09IDAgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBjaMawYSBjw7MgbG/huqFpIGLDoW8gY8OhbyBraOG6oyBk4bulbmcuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1GaWVsZHMgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLWRhdGUtZmlsdGVyc1wiIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJU4burIG5nw6B5XCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17ZnJvbX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJlcG9ydFBhcmFtKCdmcm9tRGF0ZScsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwixJDhur9uIG5nw6B5XCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17dG99IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRSZXBvcnRQYXJhbSgndG9EYXRlJywgZXZlbnQudGFyZ2V0LnZhbHVlKX0gc2xvdFByb3BzPXt7IGlucHV0TGFiZWw6IHsgc2hyaW5rOiB0cnVlIH0gfX0gZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiTcO6aSBnaeG7nVwiPntzaG9wLnRpbWV6b25lfTwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIlNuYXBzaG90IEFQSVwiPntzbmFwc2hvdEFzT2YgPyBkYXRlVGltZShzbmFwc2hvdEFzT2YsIHNob3AudGltZXpvbmUpIDogJ0NoxrBhIGPDsyBzbmFwc2hvdCd9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshY2FuRXhwb3J0UmVwb3J0cyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VmFpIHRyw7IgaGnhu4duIHThuqFpIGtow7RuZyBjw7MgcXV54buBbiByZXBvcnRzLmV4cG9ydC48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FuRXhwb3J0UmVwb3J0cyAmJiAhY2FuRXhwb3J0U291cmNlICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5RdXnhu4FuIHh14bqldCBraMO0bmcgdGhheSB0aOG6vyBxdXnhu4FuIMSR4buNYyBuZ3Xhu5NuIHtzb3VyY2VQZXJtaXNzaW9uc1t0eXBlXX07IGxv4bqhaSBiw6FvIGPDoW8gbsOgeSBjaMawYSB0aOG7gyB4deG6pXQuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbkV4cG9ydFJlcG9ydHMgJiYgY2FuRXhwb3J0U291cmNlICYmICFyZXBvcnRBdmFpbGFibGUgJiYgYXZhaWxhYmxlUmVwb3J0cy5sZW5ndGggPiAwICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5BUEkga2jDtG5nIGxp4buHdCBrw6ogbG/huqFpIGLDoW8gY8OhbyBuw6B5IGNobyB2YWkgdHLDsiBoaeG7h24gdOG6oWkuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17aGFuZGxlRXhwb3J0fSBkaXNhYmxlZD17IWNhbkV4cG9ydFJlcG9ydHMgfHwgIWNhbkV4cG9ydFNvdXJjZSB8fCAhcmVwb3J0QXZhaWxhYmxlIHx8ICFzbmFwc2hvdEFzT2YgfHwgIWZyb20gfHwgIXRvIHx8IGZyb20gPiB0byB8fCBydW4ucGVuZGluZ30+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtydW4ucGVuZGluZyA/ICfEkGFuZyB04bqhbyBzbmFwc2hvdOKApicgOiAnVOG6oW8gdOG7h3AgYsOhbyBjw6FvIENTVid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RFeHBvcnQgJiYgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSAgYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2pvYnMvJHtsYXN0RXhwb3J0LmpvYi5pZH1gfT5UaGVvIGTDtWkgY8O0bmcgdmnhu4djIHtsYXN0RXhwb3J0LmpvYi5pZH08L1JvdXRlTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3REb3dubG9hZCAmJiA8TGluayBkYXRhLXRlc3RpZD1cInJlcG9ydHMtZXhwb3J0LWRvd25sb2FkXCIgY29tcG9uZW50PVwiYVwiIGhyZWY9e2xhc3REb3dubG9hZH0gZG93bmxvYWQ9e3JlcG9ydEZpbGVuYW1lKGxhc3RFeHBvcnQudHlwZSwgbGFzdEV4cG9ydC5mcm9tLCBsYXN0RXhwb3J0LnRvKX0gdW5kZXJsaW5lPVwibm9uZVwiIHN4PXtbbGF5b3V0U3guYWN0aW9ucy5saW5rVGFyZ2V0LCB7IGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6ICdkaXZpZGVyJywgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuY29udHJvbCwgY29sb3I6ICd0ZXh0LnByaW1hcnknLCBmb250V2VpZ2h0OiB2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc2VtaWJvbGQsICcmOmhvdmVyJzogeyBiZ2NvbG9yOiAnYWN0aW9uLmhvdmVyJywgdGV4dERlY29yYXRpb246ICdub25lJyB9LCAnJjpmb2N1cy12aXNpYmxlJzogeyBvdXRsaW5lOiBgJHt0b2tlbnMuZm9jdXNSaW5nLndpZHRofXB4IHNvbGlkYCwgb3V0bGluZUNvbG9yOiAncHJpbWFyeS5saWdodCcsIG91dGxpbmVPZmZzZXQ6IHRva2Vucy5mb2N1c1JpbmcuY29udHJvbE9mZnNldCB9IH1dfT5U4bqjaSBDU1Y8L0xpbms+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFzdEV4cG9ydC5qb2Iuc3RhdHVzICE9PSAnc3VjY2VlZGVkJyAmJiA8QWxlcnQgc2V2ZXJpdHk9e2xhc3RFeHBvcnQuam9iLnN0YXR1cyA9PT0gJ3BhcnRpYWwnIHx8IGxhc3RFeHBvcnQuam9iLnN0YXR1cyA9PT0gJ2ZhaWxlZCcgPyAnd2FybmluZycgOiAnaW5mbyd9PlThu4dwIGNo4buJIMSRxrDhu6NjIHThuqNpIGtoaSBjw7RuZyB2aeG7h2MgeMOhYyBuaOG6rW4gc3VjY2VlZGVkLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFzdEV4cG9ydC5qb2Iuc3RhdHVzID09PSAnc3VjY2VlZGVkJyAmJiBsYXN0RXhwb3J0LmpvYi5kb3dubG9hZFVybCAmJiAhbGFzdERvd25sb2FkICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5VUkwgdOG6o2kga2jDtG5nIGjhu6NwIGzhu4cgaG/hurdjIGNoxrBhIHRodeG7mWMgSFRUUFMvbmd14buTbiBoaeG7h24gdOG6oWkuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9BY3Rpb25Hcm91cD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1bW1hcnkuZGF0YS5kYXRhLndhcm5pbmdzLm1hcCgod2FybmluZywgaW5kZXgpID0+IDxBbGVydCBrZXk9e2Ake2luZGV4fS0ke3dhcm5pbmd9YH0gc2V2ZXJpdHk9XCJpbmZvXCI+e3dhcm5pbmd9PC9BbGVydD4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5BUEkgaGnhu4duIGNo4buJIHRy4bqjIGRhbmggc8OhY2ggbG/huqFpIGLDoW8gY8OhbyB2w6AgdGjhu51pIMSRaeG7g20gc25hcHNob3Q7IGLhu5kgbOG7jWMgbmfDoHkgw6FwIGThu6VuZyBjaG8gbOG7h25oIHh14bqldC4gS2jDtG5nIGPDsyBzZXJpZXMgaG/hurdjIHThu5VuZyBz4buRIGxp4buHdSDEkeG7gyBnaWFvIGRp4buHbiB04buxIHN1eSByYS48L0FsZXJ0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxuICAgICAgICAgICAgICAgICAgICA8L1BhbmVsPn1cbiAgICAgICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+XG4gICAgICAgICAgICAgICAge2NhblJlYWRKb2JzID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e2pvYnN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICB7am9icy5kYXRhICYmIDxQYW5lbCB0aXRsZT1cIkPDtG5nIHZp4buHYyBn4bqnbiDEkcOieVwiIHN1YnRpdGxlPVwiVHLhuqFuZyB0aMOhaSB2w6AgdGnhur9uIMSR4buZIGzhuqV5IHThu6sgQVBJOyB0cmFuZyBoaeG7h24gdOG6oWkgY8OzIHRo4buDIGNo4bupYSBuaGnhu4F1IGxv4bqhaSBjw7RuZyB2aeG7h2MuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIHJvd3M9e2pvYnMuZGF0YS5kYXRhfSByb3dLZXk9e2pvYiA9PiBqb2IuaWR9IGxhYmVsPVwiQ8O0bmcgdmnhu4djIGfhuqduIMSRw6J5XCIgZW1wdHk9XCJDaMawYSBjw7MgY8O0bmcgdmnhu4djIHRyb25nIHRyYW5nIG7DoHkuXCIgY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ03DoyBjw7RuZyB2aeG7h2MnLCByZW5kZXI6IGpvYiA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7am9iLmlkfWB9Pntqb2IuaWR9PC9Sb3V0ZUxpbms+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdraW5kJywgbGFiZWw6ICdMb+G6oWknLCByZW5kZXI6IGpvYiA9PiA8U3RhdHVzIHZhbHVlPXtqb2Iua2luZH0gLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogam9iID0+IDxTdGF0dXMgdmFsdWU9e2pvYi5zdGF0dXN9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdwcm9ncmVzcycsIGxhYmVsOiAnVGnhur9uIMSR4buZJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogam9iID0+IGAke2pvYi5jb21wbGV0ZWR9IC8gJHtqb2IudG90YWwgPz8gJ0NoxrBhIGJp4bq/dCd9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAndXBkYXRlZEF0JywgbGFiZWw6ICdD4bqtcCBuaOG6rXQnLCByZW5kZXI6IGpvYiA9PiBkYXRlVGltZShqb2IudXBkYXRlZEF0LCBzaG9wLnRpbWV6b25lKSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdlciBwYWdlPXtqb2JzLmRhdGEucGFnZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD59XG4gICAgICAgICAgICAgICAgPC9RdWVyeVN0YXRlPiA6IDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5WYWkgdHLDsiBoaeG7h24gdOG6oWkga2jDtG5nIGPDsyBqb2JzLnJlYWQ7IHRy4bqhbmcgdGjDoWkgY8O0bmcgdmnhu4djIMSRxrDhu6NjIOG6qW4gdGhlbyBxdXnhu4FuLjwvQWxlcnQ+fVxuICAgICAgICAgICAgPC9QYWdlU2VjdGlvbnM+XG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJQaOG6oW0gdmkgZOG7ryBsaeG7h3VcIiBzdWJ0aXRsZT1cIkNo4buJIG5o4buvbmcgZ8OsIEFQSSBjdW5nIGPhuqVwIG3hu5tpIMSRxrDhu6NjIHRyw6xuaCBiw6B5IG5oxrAgc+G7kSBsaeG7h3UuXCIgYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgIDxTdGFjayBzeD17bGF5b3V0U3gucmVwb3J0LmNvbnRleHRHYXB9PlxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+QsOhbyBjw6FvIGTDsm5nLCBiaeG7g3UgxJHhu5MgdsOgIHThu5VuZyBo4bujcCB0aGVvIGtob+G6o25nIG5nw6B5IGNoxrBhIGPDsyB0cm9uZyBnZXRSZXBvcnRTdW1tYXJ5LiBGcm9udGVuZCBraMO0bmcgY+G7mW5nIGThu68gbGnhu4d1IHBow6JuIHRyYW5nIMSR4buDIHThuqFvIEtQSSB0aGF5IHRo4bq/LjwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlRy4bqhbmcgdGjDoWkgZXhwb3J0IMSRxrDhu6NjIGzhuqV5IHJpw6puZyB04burIGxpc3RKb2JzOyBVUkwgdOG6o2kgY2jhu4kgxJHGsOG7o2MgbeG7nyBzYXUga2hpIEFQSSB0cuG6oyB24buBIGPDtG5nIHZp4buHYyBob8OgbiB04bqldC48L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L3JlcG9ydHMvbWFya2V0aW5nYH0+WGVtIHRow7RuZyB0aW4gbWFya2V0aW5nPC9Sb3V0ZUxpbms+XG4gICAgICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgIDwvU2VjdGlvbkdyaWQ+XG4gICAgPC8+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gTWFya2V0aW5nUGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgW3BhcmFtcywgc2V0UGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IHNlYXJjaCA9IHBhcmFtcy50b1N0cmluZygpO1xuICAgIGNvbnN0IGZyb21QYXJhbSA9IHBhcmFtcy5nZXQoJ2Zyb21EYXRlJykgfHwgJyc7XG4gICAgY29uc3QgdG9QYXJhbSA9IHBhcmFtcy5nZXQoJ3RvRGF0ZScpIHx8ICcnO1xuICAgIGNvbnN0IGJ1Y2tldFBhcmFtID0gcGFyYW1zLmdldCgnYnVja2V0JykgfHwgJ2RheSc7XG4gICAgY29uc3QgaGFzRGF0ZUZpbHRlciA9IHBhcmFtcy5oYXMoJ2Zyb21EYXRlJykgfHwgcGFyYW1zLmhhcygndG9EYXRlJyk7XG4gICAgY29uc3QgYXBwbGllZEVycm9yID0gbWFya2V0aW5nUmFuZ2VFcnJvcihmcm9tUGFyYW0sIHRvUGFyYW0sIGJ1Y2tldFBhcmFtLCAhaGFzRGF0ZUZpbHRlcik7XG4gICAgY29uc3QgcXVlcnkgPSBhcHBsaWVkRXJyb3IgPyB1bmRlZmluZWQgOiB7XG4gICAgICAgIC4uLihwYXJhbXMuaGFzKCdmcm9tRGF0ZScpID8geyBmcm9tRGF0ZTogZnJvbVBhcmFtIH0gOiB7fSksXG4gICAgICAgIC4uLihwYXJhbXMuaGFzKCd0b0RhdGUnKSA/IHsgdG9EYXRlOiB0b1BhcmFtIH0gOiB7fSksXG4gICAgICAgIC4uLihwYXJhbXMuaGFzKCdidWNrZXQnKSA/IHsgYnVja2V0OiBidWNrZXRQYXJhbSBhcyBNYXJrZXRpbmdCdWNrZXQgfSA6IHt9KSxcbiAgICB9O1xuICAgIGNvbnN0IGRhdGEgPSB1c2VBcGkoJ2dldE1hcmtldGluZ1N1bW1hcnknLCBxdWVyeSAmJiBPYmplY3Qua2V5cyhxdWVyeSkubGVuZ3RoID8geyBxdWVyeSB9IDogdW5kZWZpbmVkLCAhYXBwbGllZEVycm9yKTtcbiAgICBjb25zdCBtID0gZGF0YS5kYXRhPy5kYXRhO1xuICAgIGNvbnN0IG1hcmtldGluZ1BlcmlvZCA9IG0/LnBlcmlvZDtcbiAgICBjb25zdCBbZHJhZnQsIHNldERyYWZ0XSA9IHVzZVN0YXRlKHsgZnJvbURhdGU6IGZyb21QYXJhbSwgdG9EYXRlOiB0b1BhcmFtLCBidWNrZXQ6IGJ1Y2tldFBhcmFtIH0pO1xuICAgIGNvbnN0IGRyYWZ0VG91Y2hlZCA9IHVzZVJlZihmYWxzZSk7XG4gICAgY29uc3QgW3Nob3dGaWx0ZXJFcnJvciwgc2V0U2hvd0ZpbHRlckVycm9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBmcm9tUmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IHRvUmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGJ1Y2tldFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBkcmFmdEVycm9yID0gbWFya2V0aW5nUmFuZ2VFcnJvcihkcmFmdC5mcm9tRGF0ZSwgZHJhZnQudG9EYXRlLCBkcmFmdC5idWNrZXQsIGZhbHNlKTtcbiAgICBjb25zdCB2aXNpYmxlRmlsdGVyRXJyb3IgPSBzaG93RmlsdGVyRXJyb3IgPyBkcmFmdEVycm9yIDogYXBwbGllZEVycm9yO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgLy8gQVBJIGRlZmF1bHRzIG1heSBpbml0aWFsaXplIHRoZSBVUkw7IGxhdGVyIHJlc3BvbnNlcyBtdXN0IG5vdCByZXBsYWNlIGFuIGVkaXRlZCBmaWx0ZXIuXG4gICAgICAgIGlmIChtYXJrZXRpbmdQZXJpb2QgJiYgIWhhc0RhdGVGaWx0ZXIgJiYgIWRyYWZ0VG91Y2hlZC5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7IGZyb21EYXRlOiBtYXJrZXRpbmdQZXJpb2QuZnJvbURhdGUsIHRvRGF0ZTogbWFya2V0aW5nUGVyaW9kLnRvRGF0ZSwgYnVja2V0OiBtYXJrZXRpbmdQZXJpb2QuYnVja2V0IH0pO1xuICAgICAgICAgICAgaWYgKG5leHQudG9TdHJpbmcoKSAhPT0gc2VhcmNoKSBzZXRQYXJhbXMobmV4dCwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgfSwgW21hcmtldGluZ1BlcmlvZCwgaGFzRGF0ZUZpbHRlciwgc2VhcmNoLCBzZXRQYXJhbXNdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGRyYWZ0VG91Y2hlZC5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHNlYXJjaCk7XG4gICAgICAgIGlmICghY3VycmVudC5oYXMoJ2Zyb21EYXRlJykgJiYgIWN1cnJlbnQuaGFzKCd0b0RhdGUnKSkgcmV0dXJuO1xuICAgICAgICBzZXREcmFmdCh7IGZyb21EYXRlOiBjdXJyZW50LmdldCgnZnJvbURhdGUnKSB8fCAnJywgdG9EYXRlOiBjdXJyZW50LmdldCgndG9EYXRlJykgfHwgJycsIGJ1Y2tldDogY3VycmVudC5nZXQoJ2J1Y2tldCcpIHx8ICdkYXknIH0pO1xuICAgICAgICBzZXRTaG93RmlsdGVyRXJyb3IoZmFsc2UpO1xuICAgIH0sIFtzZWFyY2hdKTtcblxuICAgIGNvbnN0IGFwcGx5RmlsdGVyID0gKGV2ZW50OiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PikgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRTaG93RmlsdGVyRXJyb3IodHJ1ZSk7XG4gICAgICAgIGlmIChkcmFmdEVycm9yKSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBkcmFmdEVycm9yLmZpZWxkID09PSAnZnJvbURhdGUnID8gZnJvbVJlZi5jdXJyZW50IDogZHJhZnRFcnJvci5maWVsZCA9PT0gJ3RvRGF0ZScgPyB0b1JlZi5jdXJyZW50IDogYnVja2V0UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICB0YXJnZXQ/LmZvY3VzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyBmcm9tRGF0ZTogZHJhZnQuZnJvbURhdGUsIHRvRGF0ZTogZHJhZnQudG9EYXRlLCBidWNrZXQ6IGRyYWZ0LmJ1Y2tldCB9KTtcbiAgICAgICAgc2V0U2hvd0ZpbHRlckVycm9yKGZhbHNlKTtcbiAgICAgICAgZHJhZnRUb3VjaGVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgc2V0UGFyYW1zKG5leHQpO1xuICAgIH07XG5cbiAgICByZXR1cm4gPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJUaMO0bmcgdGluIGNobyBtYXJrZXRpbmdcIiBzdWJ0aXRsZT1cIsSQ4buBIHh14bqldCBjaOG7iSDEkeG7jWM7IHRyYW5nIGtow7RuZyB04buxIMSRxINuZyBu4buZaSBkdW5nIGhv4bq3YyB0aGF5IMSR4buVaSBuZ8OibiBzw6FjaC5cIiAvPlxuICAgICAgICB7X19NT0NLX18gJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIHN4PXtsYXlvdXRTeC5ub3RpY2UuYWZ0ZXJHYXB9PlPhu5EgbGnhu4d1IG3huqt1IGRvIEFQSSBtw7QgcGjhu49uZyB04buVbmcgaOG7o3A7IGNoxrBhIGvhur90IG7hu5FpIHTDoGkga2hv4bqjbiBxdeG6o25nIGPDoW8gaG/hurdjIG5ndeG7k24gcGjDom4gYuG7lSB0aOG6rXQuPC9BbGVydD59XG4gICAgICAgIDxQYW5lbCB0aXRsZT1cIktob+G6o25nIHRo4budaSBnaWFuIGLDoW8gY8Ohb1wiIHN1YnRpdGxlPXtgTmfDoHkgxJHGsOG7o2MgdMOtbmggdGhlbyBs4buLY2ggJHtzaG9wLnRpbWV6b25lfSBj4bunYSBj4butYSBow6BuZy5gfSBib2R5TW9kZT1cImluc2V0XCIgYWZ0ZXJHYXA9XCJzZWN0aW9uXCI+XG4gICAgICAgICAgICA8Rm9ybUZpZWxkcyBjb21wb25lbnQ9XCJmb3JtXCIgb25TdWJtaXQ9e2FwcGx5RmlsdGVyfSBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1yYW5nZS1mb3JtXCI+XG4gICAgICAgICAgICAgICAgPFN0YWNrIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIG1kOiAncm93JyB9fSBhbGlnbkl0ZW1zPXt7IHhzOiAnc3RyZXRjaCcsIG1kOiAnZmxleC1lbmQnIH19IHN4PXtsYXlvdXRTeC50b29sYmFyLmNvbnRyb2xHYXB9PlxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGlucHV0UmVmPXtmcm9tUmVmfSB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwiVOG7qyBuZ8OgeVwiIHZhbHVlPXtkcmFmdC5mcm9tRGF0ZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgZHJhZnRUb3VjaGVkLmN1cnJlbnQgPSB0cnVlOyBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgZnJvbURhdGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSk7IH19IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGVycm9yPXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnZnJvbURhdGUnfSBoZWxwZXJUZXh0PXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnZnJvbURhdGUnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnTmfDoHkgYuG6r3QgxJHhuqd1LCB0w61uaCBj4bqjIG5nw6B5IMSRw6MgY2jhu41uLid9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e3RvUmVmfSB0eXBlPVwiZGF0ZVwiIGxhYmVsPVwixJDhur9uIG5nw6B5XCIgdmFsdWU9e2RyYWZ0LnRvRGF0ZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgZHJhZnRUb3VjaGVkLmN1cnJlbnQgPSB0cnVlOyBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgdG9EYXRlOiBldmVudC50YXJnZXQudmFsdWUgfSkpOyB9fSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBlcnJvcj17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ3RvRGF0ZSd9IGhlbHBlclRleHQ9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICd0b0RhdGUnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnVOG7kWkgxJFhIDM2NiBuZ8OgeSwgdMOtbmggY+G6oyBoYWkgxJHhuqd1Lid9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e2J1Y2tldFJlZn0gc2VsZWN0IGxhYmVsPVwiR+G7mXAgdGhlb1wiIHZhbHVlPXtkcmFmdC5idWNrZXR9IG9uQ2hhbmdlPXtldmVudCA9PiB7IGRyYWZ0VG91Y2hlZC5jdXJyZW50ID0gdHJ1ZTsgc2V0RHJhZnQodmFsdWUgPT4gKHsgLi4udmFsdWUsIGJ1Y2tldDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pKTsgfX0gZXJyb3I9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICdidWNrZXQnfSBoZWxwZXJUZXh0PXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAnYnVja2V0JyA/IHZpc2libGVGaWx0ZXJFcnJvci5tZXNzYWdlIDogJ0No4buNbiBuZ8OgeSwgdHXhuqduIGhv4bq3YyB0aMOhbmcuJ30+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJkYXlcIj5OZ8OgeTwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwid2Vla1wiPlR14bqnbjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwibW9udGhcIj5UaMOhbmc8L01lbnVJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPsOBcCBk4bulbmc8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgIHtzaG93RmlsdGVyRXJyb3IgJiYgZHJhZnRFcnJvciAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPntkcmFmdEVycm9yLm1lc3NhZ2V9PC9BbGVydD59XG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgICAgIDwvUGFuZWw+XG4gICAgICAgIHthcHBsaWVkRXJyb3IgPyA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPjxzdHJvbmc+QuG7mSBs4buNYyB0csOqbiDEkcaw4budbmcgZOG6q24ga2jDtG5nIGjhu6NwIGzhu4cuPC9zdHJvbmc+IEjDo3kgc+G7rWEgdHLGsOG7nW5nIMSRxrDhu6NjIMSRw6FuaCBk4bqldSB0csaw4bubYyBraGkgw6FwIGThu6VuZy48L0FsZXJ0PiA6IDxRdWVyeVN0YXRlIHF1ZXJ5PXtkYXRhfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bSAmJiA8PlxuICAgICAgICAgICAgPFN0YXRzPlxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwixJDGoW4gY8OzIG5ndeG7k24geMOhYyDEkeG7i25oXCIgdmFsdWU9e20ua25vd25BdHRyaWJ1dGVkT3JkZXJzfSBub3RlPVwixJDGsOG7o2MgQVBJIHThu5VuZyBo4bujcCB0cm9uZyBr4buzXCIgLz5cbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIsSQxqFuIGNoxrBhIHLDtSBuZ3Xhu5NuXCIgdmFsdWU9e20udW5rbm93bkF0dHJpYnV0aW9uT3JkZXJzfSBub3RlPVwiR2nhu68gcmnDqm5nLCBraMO0bmcgdOG7sSBnw6FuIG5ndeG7k25cIiAvPlxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiQ2hpIHF14bqjbmcgY8OhbyB0aOG7sWMgdOG6v1wiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e20uYWN0dWFsU3BlbmR9IC8+fSBub3RlPXttLmFjdHVhbFNwZW5kID8gJ0FQSSBjdW5nIGPhuqVwIHPhu5EgdGjhu7FjIHThur8nIDogJ0vhu7MgbsOgeSBjaMawYSBjw7Mgc+G7kSB0aOG7sWMgdOG6vyB04burIEFQSSd9IC8+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCJDaGkgcXXhuqNuZyBjw6FvIMaw4bubYyB0w61uaFwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e20uZXN0aW1hdGVkU3BlbmR9IC8+fSBub3RlPVwixq/hu5tjIHTDrW5oIGtow7RuZyBwaOG6o2kgc+G7kSBnaGkgc+G7lVwiIC8+XG4gICAgICAgICAgICA8L1N0YXRzPlxuICAgICAgICAgICAgPFN0YWNrIGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLWFzLW9mXCIgc3g9e1tsYXlvdXRTeC5yZXBvcnQuY29udGV4dEdhcCwgbGF5b3V0U3gucGFnZS5zZWN0aW9uQWZ0ZXJdfT5cbiAgICAgICAgICAgICAgICB7bS5wZXJpb2QgJiYgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+S+G7syB7Zm9ybWF0RGF0ZU9ubHkobS5wZXJpb2QuZnJvbURhdGUpfSDigJMge2Zvcm1hdERhdGVPbmx5KG0ucGVyaW9kLnRvRGF0ZSl9IMK3IGfhu5lwIHRoZW8ge20ucGVyaW9kLmJ1Y2tldCA9PT0gJ2RheScgPyAnbmfDoHknIDogbS5wZXJpb2QuYnVja2V0ID09PSAnd2VlaycgPyAndHXhuqduJyA6ICd0aMOhbmcnfTwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+Q+G6rXAgbmjhuq10IHtkYXRlVGltZShtLmFzT2YsIG0ucGVyaW9kPy50aW1lem9uZSB8fCBzaG9wLnRpbWV6b25lKX0gwrcge3Nob3AubmFtZX0gwrcgbcO6aSBnaeG7nSB7bS5wZXJpb2Q/LnRpbWV6b25lIHx8IHNob3AudGltZXpvbmV9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgPC9TdGFjaz5cbiAgICAgICAgICAgIDxTZWN0aW9uR3JpZCBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1zZWN0aW9ucy1ncmlkXCIgY29sdW1ucz17eyB4czogJzFmcicsIGxnOiAnMWZyIDFmcicgfX0+XG4gICAgICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwixJDGoW4gdGhlbyB0aOG7nWkgZ2lhblwiIHN1YnRpdGxlPVwiU+G7kSDEkcahbiBjw7Mgbmd14buTbiB4w6FjIMSR4buLbmggdsOgIGNoxrBhIHLDtSBuZ3Xhu5NuIGRvIEFQSSB04buVbmcgaOG7o3AuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCb3ggcm9sZT1cImltZ1wiIGFyaWEtbGFiZWw9e2BT4buRIMSRxqFuIHRoZW8gJHttLnBlcmlvZD8uYnVja2V0IHx8ICdr4buzJ30gdHJvbmcga2hv4bqjbmcgxJHDoyBjaOG7jW5gfSBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy10cmVuZC1jaGFydFwiIHN4PXtbeyBoZWlnaHQ6IDI4MCB9LCBsYXlvdXRTeC5yZXBvcnQuY2hhcnRWaWV3cG9ydEluc2V0XX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bS50cmVuZD8ubGVuZ3RoID8gPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPjxCYXJDaGFydCBkYXRhPXttLnRyZW5kfSBhY2Nlc3NpYmlsaXR5TGF5ZXI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlPXtjb2xvcnMuYm9yZGVyRGVjb3JhdGl2ZX0gdmVydGljYWw9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwiZnJvbURhdGVcIiBzdHJva2U9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSBpbnRlcnZhbD17TWF0aC5tYXgoMCwgTWF0aC5jZWlsKG0udHJlbmQubGVuZ3RoIC8gNykgLSAxKX0gdGlja0Zvcm1hdHRlcj17dmFsdWUgPT4gZm9ybWF0RGF0ZU9ubHkoU3RyaW5nKHZhbHVlKSl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFlBeGlzIGFsbG93RGVjaW1hbHM9e2ZhbHNlfSBzdHJva2U9e2NvbG9ycy50ZXh0U2Vjb25kYXJ5fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIGxhYmVsRm9ybWF0dGVyPXt2YWx1ZSA9PiBmb3JtYXREYXRlT25seShTdHJpbmcodmFsdWUpKX0gY29udGVudFN0eWxlPXt7IGJhY2tncm91bmQ6IGNvbG9ycy5yYWlzZWQsIGNvbG9yOiBjb2xvcnMudGV4dFByaW1hcnksIGJvcmRlckNvbG9yOiBjb2xvcnMuYm9yZGVyRGVjb3JhdGl2ZSB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJrbm93bkF0dHJpYnV0ZWRPcmRlcnNcIiBuYW1lPVwiQ8OzIG5ndeG7k24geMOhYyDEkeG7i25oXCIgZmlsbD17Y29sb3JzLmFjY2VudH0gcmFkaXVzPXtbMywgMywgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwidW5rbm93bkF0dHJpYnV0aW9uT3JkZXJzXCIgbmFtZT1cIkNoxrBhIHLDtSBuZ3Xhu5NuXCIgZmlsbD17Y29sb3JzLnRleHRTZWNvbmRhcnl9IHJhZGl1cz17WzMsIDMsIDAsIDBdfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD48L1Jlc3BvbnNpdmVDb250YWluZXI+IDogPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXtsYXlvdXRTeC5yZXBvcnQuZW1wdHlTdGF0ZUluc2V0fT5BUEkgY2jGsGEgY8OzIGJ1Y2tldCBk4buvIGxp4buHdSB0cm9uZyBr4buzIMSRw6MgY2jhu41uLjwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiVOG7lW5nIGjhu6NwIG1hcmtldGluZyB0aGVvIGvhu7NcIiByb3dzPXttLnRyZW5kIHx8IFtdfSByb3dLZXk9e3BvaW50ID0+IHBvaW50LmZyb21EYXRlfSBlbXB0eT1cIkNoxrBhIGPDsyBk4buvIGxp4buHdSB0aGVvIGvhu7MgdHJvbmcga2hv4bqjbmcgbsOgeS5cIiBjb2x1bW5zPXtbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3JhbmdlJywgbGFiZWw6ICdLaG/huqNuZyBuZ8OgeScsIHJlbmRlcjogcG9pbnQgPT4gYCR7Zm9ybWF0RGF0ZU9ubHkocG9pbnQuZnJvbURhdGUpfSDigJMgJHtmb3JtYXREYXRlT25seShwb2ludC50b0RhdGUpfWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAna25vd24nLCBsYWJlbDogJ0PDsyBuZ3Xhu5NuJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gcG9pbnQua25vd25BdHRyaWJ1dGVkT3JkZXJzIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3Vua25vd24nLCBsYWJlbDogJ0NoxrBhIHLDtSBuZ3Xhu5NuJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gcG9pbnQudW5rbm93bkF0dHJpYnV0aW9uT3JkZXJzIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2VzdGltYXRlZCcsIGxhYmVsOiAnQ2hpIMaw4bubYyB0w61uaCcsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHBvaW50ID0+IDxBbW91bnQgdmFsdWU9e3BvaW50LmVzdGltYXRlZFNwZW5kfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhY3R1YWwnLCBsYWJlbDogJ0NoaSB0aOG7sWMgdOG6vycsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IHBvaW50ID0+IDxBbW91bnQgdmFsdWU9e3BvaW50LmFjdHVhbFNwZW5kfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICBdfSAvPlxuICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiQ8OidSBo4buPaSBraMOhY2ggdGjGsOG7nW5nIGjhu49pXCIgc3VidGl0bGU9XCJDw6FjIG3hu6VjIGRvIEFQSSB04buVbmcgaOG7o3AgY3VuZyBj4bqlcC5cIj5cbiAgICAgICAgICAgICAgICAgICAgPEJveCBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1xdWVzdGlvbi1zdXJmYWNlXCIgc3g9e2xheW91dFN4LnJlcG9ydC5saXN0U3VyZmFjZUluc2V0fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjayBjb21wb25lbnQ9XCJ1bFwiIGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXRvcC1xdWVzdGlvbnNcIiBzeD17W3sgbTogMCwgcDogMCB9LCBsYXlvdXRTeC5yZXBvcnQubGlzdE1hcmtlckluc2V0LCBsYXlvdXRTeC5yZXBvcnQubGlzdEl0ZW1HYXBdfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS50b3BRdWVzdGlvbnMubGVuZ3RoID8gbS50b3BRdWVzdGlvbnMubWFwKChxdWVzdGlvbiwgaW5kZXgpID0+IDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImxpXCIga2V5PXtgJHtpbmRleH0tJHtxdWVzdGlvbn1gfT57cXVlc3Rpb259PC9UeXBvZ3JhcGh5PikgOiA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJsaVwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5DaMawYSBjw7MgdGjhu5FuZyBrw6ogY8OidSBo4buPaSB0cm9uZyBr4buzIMSRw6MgY2jhu41uLjwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIkzDvSBkbyBraMO0bmcgY2jhu5F0IMSRxqFuXCIgc3VidGl0bGU9XCJCaeG7g3UgxJHhu5MgdsOgIGLhuqNuZyBkw7luZyBjw7luZyBt4buZdCBwYXlsb2FkIEFQSS5cIj5cbiAgICAgICAgICAgICAgICAgICAgPEJveCByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17YEJp4buDdSDEkeG7kyBsw70gZG8ga2jDtG5nIGNo4buRdCDEkcahbiwgJHttLmxvc3RTYWxlUmVhc29ucy5sZW5ndGh9IG5ow7NtYH0gZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctbG9zcy1jaGFydFwiIHN4PXtbeyBoZWlnaHQ6IDI2MCB9LCBsYXlvdXRTeC5yZXBvcnQuY2hhcnRWaWV3cG9ydEluc2V0XX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bS5sb3N0U2FsZVJlYXNvbnMubGVuZ3RoID8gPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPjxCYXJDaGFydCBkYXRhPXttLmxvc3RTYWxlUmVhc29uc30gYWNjZXNzaWJpbGl0eUxheWVyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZT17Y29sb3JzLmJvcmRlckRlY29yYXRpdmV9IHZlcnRpY2FsPXtmYWxzZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cInJlYXNvblwiIHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IGludGVydmFsPXswfSBoZWlnaHQ9ezY0fSB0aWNrPXs8TWFya2V0aW5nUmVhc29uVGljayAvPn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WUF4aXMgYWxsb3dEZWNpbWFscz17ZmFsc2V9IHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgY29udGVudFN0eWxlPXt7IGJhY2tncm91bmQ6IGNvbG9ycy5yYWlzZWQsIGNvbG9yOiBjb2xvcnMudGV4dFByaW1hcnksIGJvcmRlckNvbG9yOiBjb2xvcnMuYm9yZGVyRGVjb3JhdGl2ZSB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImNvdW50XCIgbmFtZT1cIlPhu5EgdHLGsOG7nW5nIGjhu6NwXCIgZmlsbD17Y29sb3JzLmFjY2VudH0gcmFkaXVzPXtbNCwgNCwgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhckNoYXJ0PjwvUmVzcG9uc2l2ZUNvbnRhaW5lcj4gOiA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LnJlcG9ydC5lbXB0eVN0YXRlSW5zZXR9PkNoxrBhIGPDsyBsw70gZG8gbeG6pXQgxJHGoW4gdHJvbmcga+G7syBuw6B5LjwvVHlwb2dyYXBoeT59XG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIHJvd3M9e20ubG9zdFNhbGVSZWFzb25zfSByb3dLZXk9e3JlYXNvbiA9PiByZWFzb24ucmVhc29ufSBsYWJlbD1cIkzDvSBkbyBraMO0bmcgY2jhu5F0IMSRxqFuXCIgZW1wdHk9XCJDaMawYSBjw7MgbMO9IGRvIG3huqV0IMSRxqFuIHRyb25nIGvhu7MgxJHDoyBjaOG7jW4uXCIgY29sdW1ucz17W1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyZWFzb24nLCBsYWJlbDogJ0zDvSBkbycsIHJlbmRlcjogcmVhc29uID0+IHJlYXNvbi5yZWFzb24gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnY291bnQnLCBsYWJlbDogJ1Phu5EgdHLGsOG7nW5nIGjhu6NwJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcmVhc29uID0+IHJlYXNvbi5jb3VudCB9LFxuICAgICAgICAgICAgICAgICAgICBdfSAvPlxuICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICA8L1NlY3Rpb25HcmlkPlxuICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHN4PXtsYXlvdXRTeC5wYWdlLnNlY3Rpb25CZWZvcmV9Pktow7RuZyB04buxIGfDoW4gbmd14buTbiBjaG8gxJHGoW4gdGhp4bq/dSBk4buvIGxp4buHdSwga2jDtG5nIGdoaSBjaGkgxrDhu5tjIHTDrW5oIHRow6BuaCBjaGkgdGjhu7FjIHThur8gdsOgIGtow7RuZyB04buxIMSRxINuZyBu4buZaSBkdW5nIGhv4bq3YyB0xINuZyBuZ8OibiBzw6FjaC48L0FsZXJ0PlxuICAgICAgICA8Lz59PC9RdWVyeVN0YXRlPn1cbiAgICA8Lz47XG59XG5cbmZ1bmN0aW9uIG1hcmtldGluZ1JhbmdlRXJyb3IoZnJvbURhdGU6IHN0cmluZywgdG9EYXRlOiBzdHJpbmcsIGJ1Y2tldDogc3RyaW5nLCBhbGxvd0RlZmF1bHQ6IGJvb2xlYW4pOiB7IGZpZWxkOiAnZnJvbURhdGUnIHwgJ3RvRGF0ZScgfCAnYnVja2V0JzsgbWVzc2FnZTogc3RyaW5nIH0gfCBudWxsIHtcbiAgICBpZiAoIVsnZGF5JywgJ3dlZWsnLCAnbW9udGgnXS5pbmNsdWRlcyhidWNrZXQpKSByZXR1cm4geyBmaWVsZDogJ2J1Y2tldCcsIG1lc3NhZ2U6ICdDaOG7jW4gbmjDs20gbmfDoHksIHR14bqnbiBob+G6t2MgdGjDoW5nLicgfTtcbiAgICBpZiAoYWxsb3dEZWZhdWx0ICYmICFmcm9tRGF0ZSAmJiAhdG9EYXRlKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIWlzVmFsaWREYXRlT25seShmcm9tRGF0ZSkpIHJldHVybiB7IGZpZWxkOiAnZnJvbURhdGUnLCBtZXNzYWdlOiAnTmjhuq1wIG5nw6B5IGLhuq90IMSR4bqndSBo4bujcCBs4buHLicgfTtcbiAgICBpZiAoIWlzVmFsaWREYXRlT25seSh0b0RhdGUpKSByZXR1cm4geyBmaWVsZDogJ3RvRGF0ZScsIG1lc3NhZ2U6ICdOaOG6rXAgbmfDoHkga+G6v3QgdGjDumMgaOG7o3AgbOG7hy4nIH07XG4gICAgaWYgKGZyb21EYXRlID4gdG9EYXRlKSByZXR1cm4geyBmaWVsZDogJ2Zyb21EYXRlJywgbWVzc2FnZTogJ05nw6B5IGLhuq90IMSR4bqndSBwaOG6o2kgdHLGsOG7m2MgaG/hurdjIGLhurFuZyBuZ8OgeSBr4bq/dCB0aMO6Yy4nIH07XG4gICAgY29uc3QgZGF5cyA9IE1hdGguZmxvb3IoKERhdGUucGFyc2UoYCR7dG9EYXRlfVQwMDowMDowMC4wMDBaYCkgLSBEYXRlLnBhcnNlKGAke2Zyb21EYXRlfVQwMDowMDowMC4wMDBaYCkpIC8gKDI0ICogNjAgKiA2MCAqIDEwMDApKSArIDE7XG4gICAgaWYgKGRheXMgPiAzNjYpIHJldHVybiB7IGZpZWxkOiAndG9EYXRlJywgbWVzc2FnZTogJ0tob+G6o25nIGLDoW8gY8OhbyBraMO0bmcgxJHGsOG7o2Mgdsaw4bujdCBxdcOhIDM2NiBuZ8OgeS4nIH07XG4gICAgcmV0dXJuIG51bGw7XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9yZXBvcnRzL2luZGV4LnRzeCJ9