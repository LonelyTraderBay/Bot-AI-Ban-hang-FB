import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/reports/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-26604-24633e2d-1aae-4dac-a9a9-b6b23035d786/deps/react_jsx-dev-runtime.js?v=dc25b6d8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-26604-24633e2d-1aae-4dac-a9a9-b6b23035d786/deps/react.js?v=dc25b6d8"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-26604-24633e2d-1aae-4dac-a9a9-b6b23035d786/deps/react-router-dom.js?v=9087dfb3";
import { Alert, Box, Button, Link, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-26604-24633e2d-1aae-4dac-a9a9-b6b23035d786/deps/@mui_material.js?v=d9f34ec2";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Text, Tooltip, XAxis, YAxis } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-26604-24633e2d-1aae-4dac-a9a9-b6b23035d786/deps/recharts.js?v=35ea3825";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime, formatDateOnly, isValidDateOnly } from "/src/shared/model/format.ts";
import { Amount, DataTable, DetailLine, ErrorNotice, PageHeader, Panel, Pager, QueryState, RouteLink, Stat, Stats, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { authorizedDownloadHref, dateInTimezone, reportDateBoundary, reportFilename } from "/src/modules/reports/report-utils.ts";
const reportLabels = {
  inventory: "Tồn kho",
  orders: "Đơn hàng",
  cashflow: "Dòng tiền",
  profit_loss: "Lợi nhuận"
};
const sourcePermissions = {
  inventory: "inventory.read",
  orders: "orders.read",
  cashflow: "finance.read",
  profit_loss: "finance.read"
};
function MarketingReasonTick({ x = 0, y = 0, width = 0, visibleTicksCount = 1, payload }) {
  const value = typeof payload?.value === "string" ? payload.value.trim() : "";
  const categoryLabelInset = 8;
  const labelWidth = Math.max(1, width / Math.max(1, visibleTicksCount) - categoryLabelInset);
  return /* @__PURE__ */ jsxDEV(
    Text,
    {
      x,
      y,
      dy: 12,
      width: labelWidth,
      breakAll: true,
      verticalAnchor: "start",
      textAnchor: "middle",
      fill: colors.textSecondary,
      style: { fontSize: tokens.fontSizes.body, fontFamily: tokens.fontFamily },
      children: value
    },
    void 0,
    false,
    {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 47,
      columnNumber: 10
    },
    this
  );
}
_c = MarketingReasonTick;
export function ReportsPage() {
  _s();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const latestParams = useRef(new URLSearchParams(params));
  const pendingSearch = useRef(null);
  useEffect(() => {
    const committedSearch = params.toString();
    if (pendingSearch.current !== null && pendingSearch.current !== committedSearch) return;
    latestParams.current = new URLSearchParams(params);
    pendingSearch.current = null;
  }, [params]);
  const summary = useApi("getReportSummary");
  const canReadJobs = useCan("jobs.read");
  const jobs = useApi("listJobs", { query: { limit: 10, cursor: params.get("cursor") || void 0 } }, canReadJobs);
  const run = useCommand("createExport", ["listJobs"]);
  const requestedType = params.get("reportType");
  const type = requestedType === "inventory" || requestedType === "cashflow" || requestedType === "profit_loss" ? requestedType : "orders";
  const snapshotAsOf = summary.data?.data.asOf;
  const defaultRange = useMemo(() => {
    if (!snapshotAsOf) return null;
    try {
      const currentDate = dateInTimezone(snapshotAsOf, shop.timezone);
      return { fromDate: `${currentDate.slice(0, 7)}-01`, toDate: currentDate };
    } catch {
      return null;
    }
  }, [shop.timezone, snapshotAsOf]);
  const fromValue = params.get("fromDate");
  const toValue = params.get("toDate");
  const readReportDate = (key, value) => {
    if (isValidDateOnly(value)) return value;
    if (params.has(key) && value === "") return "";
    return defaultRange?.[key] || "";
  };
  const from = readReportDate("fromDate", fromValue);
  const to = readReportDate("toDate", toValue);
  const setReportParam = (key, value) => {
    const next = new URLSearchParams(latestParams.current);
    if (key === "reportType") next.set(key, value);
    else
      next.set(key, isValidDateOnly(value) ? value : "");
    latestParams.current = next;
    pendingSearch.current = next.toString();
    setParams(next, { flushSync: true });
  };
  const [rangeError, setRangeError] = useState("");
  const [lastExport, setLastExport] = useState(null);
  const canExportReports = useCan("reports.export");
  const canExportSource = useCan(sourcePermissions[type]);
  const availableReports = summary.data?.data.availableReports || [];
  const reportAvailable = availableReports.includes(type);
  useEffect(() => {
    if (!snapshotAsOf) return;
    if (!defaultRange) {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
      return;
    }
    try {
      const next = new URLSearchParams(latestParams.current);
      let changed = false;
      if (requestedType !== "inventory" && requestedType !== "cashflow" && requestedType !== "profit_loss" && requestedType !== "orders") {
        next.set("reportType", "orders");
        changed = true;
      }
      if (!params.has("fromDate") || fromValue && !isValidDateOnly(fromValue)) {
        next.set("fromDate", defaultRange.fromDate);
        changed = true;
      }
      if (!params.has("toDate") || toValue && !isValidDateOnly(toValue)) {
        next.set("toDate", defaultRange.toDate);
        changed = true;
      }
      if (changed) {
        latestParams.current = next;
        pendingSearch.current = next.toString();
        setParams(next, { replace: true, flushSync: true });
      }
    } catch {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
    }
  }, [defaultRange, params, requestedType, fromValue, toValue, setParams, snapshotAsOf]);
  const submit = async () => {
    setRangeError("");
    try {
      if (!snapshotAsOf || !from || !to) throw new RangeError("Chưa có snapshot hoặc khoảng ngày đầy đủ.");
      const request = {
        reportType: type,
        format: "csv",
        from: reportDateBoundary(from, "start", shop.timezone),
        to: reportDateBoundary(to, "end", shop.timezone),
        timezone: shop.timezone,
        snapshotAsOf
      };
      setLastExport(null);
      const response = await run.execute({ body: request });
      setLastExport({ job: response.data, type, from, to });
    } catch (error) {
      if (error instanceof RangeError) setRangeError(error.message);
    }
  };
  const handleExport = () => {
    void submit();
  };
  const lastDownload = lastExport?.job.status === "succeeded" && lastExport.job.downloadUrl ? authorizedDownloadHref(lastExport.job.downloadUrl, location.origin, __MOCK__) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Báo cáo & xuất dữ liệu", subtitle: "Xuất snapshot do API tạo; số liệu tổng hợp không được tính từ một trang danh sách." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 158,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "reports-main-layout", columns: { xs: "minmax(0, 1fr)", xl: "minmax(0, 1.2fr) minmax(0, .8fr)" }, alignItems: "start", geometry: { minWidth: 0 }, children: [
      /* @__PURE__ */ jsxDEV(PageSections, { "data-testid": "reports-page-sections", children: [
        /* @__PURE__ */ jsxDEV(QueryState, { query: summary, pendingProfile: "section", children: summary.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Tạo tệp báo cáo", subtitle: "Ngày được hiểu theo múi giờ cửa hàng và gửi thành mốc thời gian rõ ràng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-export-form-layout", geometry: { maxWidth: 760 }, children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: run.error }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 164,
            columnNumber: 29
          }, this),
          rangeError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: rangeError }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 165,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Báo cáo", select: true, value: type, onChange: (event) => {
            const value = event.target.value;
            if (value === "orders" || value === "inventory" || value === "cashflow" || value === "profit_loss") setReportParam("reportType", value);
            setLastExport(null);
          }, children: availableReports.map((report) => /* @__PURE__ */ jsxDEV(MenuItem, { value: report, children: reportLabels[report] }, report, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 171,
            columnNumber: 67
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 166,
            columnNumber: 29
          }, this),
          availableReports.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại chưa có loại báo cáo khả dụng." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 173,
            columnNumber: 63
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-date-filters", direction: { xs: "column", sm: "row" }, children: [
            /* @__PURE__ */ jsxDEV(TextField, { label: "Từ ngày", type: "date", value: from, onChange: (event) => setReportParam("fromDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 175,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Đến ngày", type: "date", value: to, onChange: (event) => setReportParam("toDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 176,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 174,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Múi giờ", children: shop.timezone }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 178,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Snapshot API", children: snapshotAsOf ? dateTime(snapshotAsOf, shop.timezone) : "Chưa có snapshot" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 179,
            columnNumber: 29
          }, this),
          !canExportReports && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vai trò hiện tại không có quyền reports.export." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 180,
            columnNumber: 51
          }, this),
          canExportReports && !canExportSource && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
            "Quyền xuất không thay thế quyền đọc nguồn ",
            sourcePermissions[type],
            "; loại báo cáo này chưa thể xuất."
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 181,
            columnNumber: 70
          }, this),
          canExportReports && canExportSource && !reportAvailable && availableReports.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "API không liệt kê loại báo cáo này cho vai trò hiện tại." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 182,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: handleExport, disabled: !canExportReports || !canExportSource || !reportAvailable || !snapshotAsOf || !from || !to || from > to || run.pending, children: run.pending ? "Đang tạo snapshot…" : "Tạo tệp báo cáo CSV" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 183,
            columnNumber: 29
          }, this),
          lastExport && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "center" }, children: [
            /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${lastExport.job.id}`, children: [
              "Theo dõi công việc ",
              lastExport.job.id
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 187,
              columnNumber: 33
            }, this),
            lastDownload && /* @__PURE__ */ jsxDEV(Link, { "data-testid": "reports-export-download", component: "a", href: lastDownload, download: reportFilename(lastExport.type, lastExport.from, lastExport.to), underline: "none", sx: [layoutSx.actions.linkTarget, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control, color: "text.primary", fontWeight: visualSx.typography.fontWeight.semibold, "&:hover": { bgcolor: "action.hover", textDecoration: "none" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: "Tải CSV" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 188,
              columnNumber: 50
            }, this),
            lastExport.job.status !== "succeeded" && /* @__PURE__ */ jsxDEV(Alert, { severity: lastExport.job.status === "partial" || lastExport.job.status === "failed" ? "warning" : "info", children: "Tệp chỉ được tải khi công việc xác nhận succeeded." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 189,
              columnNumber: 75
            }, this),
            lastExport.job.status === "succeeded" && lastExport.job.downloadUrl && !lastDownload && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không hợp lệ hoặc chưa thuộc HTTPS/nguồn hiện tại." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 190,
              columnNumber: 122
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 186,
            columnNumber: 44
          }, this),
          summary.data.data.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: warning }, `${index}-${warning}`, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 192,
            columnNumber: 81
          }, this)),
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "API hiện chỉ trả danh sách loại báo cáo và thời điểm snapshot; bộ lọc ngày áp dụng cho lệnh xuất. Không có series hoặc tổng số liệu để giao diện tự suy ra." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 193,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 163,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 162,
          columnNumber: 38
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 161,
          columnNumber: 17
        }, this),
        canReadJobs ? /* @__PURE__ */ jsxDEV(QueryState, { query: jobs, pendingProfile: "section", children: jobs.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Công việc gần đây", subtitle: "Trạng thái và tiến độ lấy từ API; trang hiện tại có thể chứa nhiều loại công việc.", children: [
          /* @__PURE__ */ jsxDEV(DataTable, { rows: jobs.data.data, rowKey: (job) => job.id, label: "Công việc gần đây", empty: "Chưa có công việc trong trang này.", columns: [
            { key: "id", label: "Mã công việc", render: (job) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${job.id}`, children: job.id }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 200,
              columnNumber: 66
            }, this) },
            { key: "kind", label: "Loại", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.kind }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 201,
              columnNumber: 60
            }, this) },
            { key: "status", label: "Trạng thái", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 202,
              columnNumber: 68
            }, this) },
            { key: "progress", label: "Tiến độ", align: "right", render: (job) => `${job.completed} / ${job.total ?? "Chưa biết"}` },
            { key: "updatedAt", label: "Cập nhật", render: (job) => dateTime(job.updatedAt, shop.timezone) }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 199,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: jobs.data.page }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 206,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 198,
          columnNumber: 35
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 197,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có jobs.read; trạng thái công việc được ẩn theo quyền." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 208,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 160,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Phạm vi dữ liệu", subtitle: "Chỉ những gì API cung cấp mới được trình bày như số liệu.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.report.contextGap, children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Báo cáo dòng, biểu đồ và tổng hợp theo khoảng ngày chưa có trong getReportSummary. Frontend không cộng dữ liệu phân trang để tạo KPI thay thế." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 212,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Trạng thái export được lấy riêng từ listJobs; URL tải chỉ được mở sau khi API trả về công việc hoàn tất." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 213,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/reports/marketing`, children: "Xem thông tin marketing" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 214,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 211,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 210,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 159,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 157,
    columnNumber: 10
  }, this);
}
_s(ReportsPage, "DFyE6kGn/WrimxAHqu/xbuEgHPg=", false, function() {
  return [useScope, useSearchParams, useApi, useCan, useApi, useCommand, useCan, useCan];
});
_c2 = ReportsPage;
export function MarketingPage() {
  _s2();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const search = params.toString();
  const fromParam = params.get("fromDate") || "";
  const toParam = params.get("toDate") || "";
  const bucketParam = params.get("bucket") || "day";
  const hasDateFilter = params.has("fromDate") || params.has("toDate");
  const appliedError = marketingRangeError(fromParam, toParam, bucketParam, !hasDateFilter);
  const query = appliedError ? void 0 : {
    ...params.has("fromDate") ? { fromDate: fromParam } : {},
    ...params.has("toDate") ? { toDate: toParam } : {},
    ...params.has("bucket") ? { bucket: bucketParam } : {}
  };
  const data = useApi("getMarketingSummary", query && Object.keys(query).length ? { query } : void 0, !appliedError);
  const m = data.data?.data;
  const marketingPeriod = m?.period;
  const [draft, setDraft] = useState({ fromDate: fromParam, toDate: toParam, bucket: bucketParam });
  const [showFilterError, setShowFilterError] = useState(false);
  const fromRef = useRef(null);
  const toRef = useRef(null);
  const bucketRef = useRef(null);
  const draftError = marketingRangeError(draft.fromDate, draft.toDate, draft.bucket, false);
  const visibleFilterError = showFilterError ? draftError : appliedError;
  useEffect(() => {
    if (marketingPeriod) {
      setDraft({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      const next = new URLSearchParams({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      if (next.toString() !== search) setParams(next, { replace: true });
    }
  }, [marketingPeriod, search, setParams]);
  useEffect(() => {
    const current = new URLSearchParams(search);
    if (!current.has("fromDate") && !current.has("toDate")) return;
    setDraft({ fromDate: current.get("fromDate") || "", toDate: current.get("toDate") || "", bucket: current.get("bucket") || "day" });
    setShowFilterError(false);
  }, [search]);
  const applyFilter = (event) => {
    event.preventDefault();
    setShowFilterError(true);
    if (draftError) {
      const target = draftError.field === "fromDate" ? fromRef.current : draftError.field === "toDate" ? toRef.current : bucketRef.current;
      target?.focus();
      return;
    }
    const next = new URLSearchParams({ fromDate: draft.fromDate, toDate: draft.toDate, bucket: draft.bucket });
    setShowFilterError(false);
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thông tin cho marketing", subtitle: "Đề xuất chỉ đọc; trang không tự đăng nội dung hoặc thay đổi ngân sách." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 275,
      columnNumber: 9
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Số liệu mẫu do API mô phỏng tổng hợp; chưa kết nối tài khoản quảng cáo hoặc nguồn phân bổ thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 276,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Khoảng thời gian báo cáo", subtitle: `Ngày được tính theo lịch ${shop.timezone} của cửa hàng.`, bodyMode: "inset", afterGap: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", onSubmit: applyFilter, "data-testid": "marketing-range-form", children: [
      /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "flex-end" }, sx: layoutSx.toolbar.controlGap, children: [
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: fromRef, type: "date", label: "Từ ngày", value: draft.fromDate, onChange: (event) => setDraft((value) => ({ ...value, fromDate: event.target.value })), slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "fromDate", helperText: visibleFilterError?.field === "fromDate" ? visibleFilterError.message : "Ngày bắt đầu, tính cả ngày đã chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 280,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: toRef, type: "date", label: "Đến ngày", value: draft.toDate, onChange: (event) => setDraft((value) => ({ ...value, toDate: event.target.value })), slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "toDate", helperText: visibleFilterError?.field === "toDate" ? visibleFilterError.message : "Tối đa 366 ngày, tính cả hai đầu." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 281,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: bucketRef, select: true, label: "Gộp theo", value: draft.bucket, onChange: (event) => setDraft((value) => ({ ...value, bucket: event.target.value })), error: visibleFilterError?.field === "bucket", helperText: visibleFilterError?.field === "bucket" ? visibleFilterError.message : "Chọn ngày, tuần hoặc tháng.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "day", children: "Ngày" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 283,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "week", children: "Tuần" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 283,
            columnNumber: 62
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "month", children: "Tháng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 283,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 282,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", children: "Áp dụng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 285,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 279,
        columnNumber: 17
      }, this),
      showFilterError && draftError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: draftError.message }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 287,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 278,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 277,
      columnNumber: 9
    }, this),
    appliedError ? /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Bộ lọc trên đường dẫn không hợp lệ." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 290,
        columnNumber: 62
      }, this),
      " Hãy sửa trường được đánh dấu trước khi áp dụng."
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 290,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: m && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn có nguồn xác định", value: m.knownAttributedOrders, note: "Được API tổng hợp trong kỳ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 292,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn chưa rõ nguồn", value: m.unknownAttributionOrders, note: "Giữ riêng, không tự gán nguồn" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 293,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo thực tế", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.actualSpend }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 294,
          columnNumber: 60
        }, this), note: m.actualSpend ? "API cung cấp số thực tế" : "Kỳ này chưa có số thực tế từ API" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 294,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo ước tính", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.estimatedSpend }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 295,
          columnNumber: 61
        }, this), note: "Ước tính không phải số ghi sổ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 295,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 291,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "marketing-as-of", sx: [layoutSx.report.contextGap, layoutSx.page.sectionAfter], children: [
        m.period && /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
          "Kỳ ",
          formatDateOnly(m.period.fromDate),
          " – ",
          formatDateOnly(m.period.toDate),
          " · gộp theo ",
          m.period.bucket === "day" ? "ngày" : m.period.bucket === "week" ? "tuần" : "tháng"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 298,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Cập nhật ",
          dateTime(m.asOf, m.period?.timezone || shop.timezone),
          " · ",
          shop.name,
          " · múi giờ ",
          m.period?.timezone || shop.timezone
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 299,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 297,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "marketing-sections-grid", columns: { xs: "1fr", lg: "1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV(Panel, { title: "Đơn theo thời gian", subtitle: "Số đơn có nguồn xác định và chưa rõ nguồn do API tổng hợp.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Số đơn theo ${m.period?.bucket || "kỳ"} trong khoảng đã chọn`, "data-testid": "marketing-trend-chart", sx: [{ height: 280 }, layoutSx.report.chartViewportInset], children: m.trend?.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.trend, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 305,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "fromDate", stroke: colors.textSecondary, interval: Math.max(0, Math.ceil(m.trend.length / 7) - 1), tickFormatter: (value) => formatDateOnly(String(value)) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 306,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 307,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { labelFormatter: (value) => formatDateOnly(String(value)), contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 308,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 309,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "knownAttributedOrders", name: "Có nguồn xác định", fill: colors.accent, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 310,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "unknownAttributionOrders", name: "Chưa rõ nguồn", fill: colors.textSecondary, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 311,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 304,
            columnNumber: 92
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 304,
            columnNumber: 44
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "API chưa có bucket dữ liệu trong kỳ đã chọn." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 312,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 303,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Tổng hợp marketing theo kỳ", rows: m.trend || [], rowKey: (point) => point.fromDate, empty: "Chưa có dữ liệu theo kỳ trong khoảng này.", columns: [
            { key: "range", label: "Khoảng ngày", render: (point) => `${formatDateOnly(point.fromDate)} – ${formatDateOnly(point.toDate)}` },
            { key: "known", label: "Có nguồn", align: "right", render: (point) => point.knownAttributedOrders },
            { key: "unknown", label: "Chưa rõ nguồn", align: "right", render: (point) => point.unknownAttributionOrders },
            { key: "estimated", label: "Chi ước tính", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.estimatedSpend }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 318,
              columnNumber: 91
            }, this) },
            { key: "actual", label: "Chi thực tế", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.actualSpend }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 319,
              columnNumber: 87
            }, this) }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 314,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 302,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Câu hỏi khách thường hỏi", subtitle: "Các mục do API tổng hợp cung cấp.", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "marketing-question-surface", sx: layoutSx.report.listSurfaceInset, children: /* @__PURE__ */ jsxDEV(Stack, { component: "ul", "data-testid": "marketing-top-questions", sx: [{ m: 0, p: 0 }, layoutSx.report.listMarkerInset, layoutSx.report.listItemGap], children: m.topQuestions.length ? m.topQuestions.map((question, index) => /* @__PURE__ */ jsxDEV(Typography, { component: "li", children: question }, `${index}-${question}`, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 325,
          columnNumber: 94
        }, this)) : /* @__PURE__ */ jsxDEV(Typography, { component: "li", color: "text.secondary", children: "Chưa có thống kê câu hỏi trong kỳ đã chọn." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 325,
          columnNumber: 177
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 324,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 323,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 322,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Lý do không chốt đơn", subtitle: "Biểu đồ và bảng dùng cùng một payload API.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Biểu đồ lý do không chốt đơn, ${m.lostSaleReasons.length} nhóm`, "data-testid": "marketing-loss-chart", sx: [{ height: 260 }, layoutSx.report.chartViewportInset], children: m.lostSaleReasons.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.lostSaleReasons, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 332,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "reason", stroke: colors.textSecondary, interval: 0, height: 64, tick: /* @__PURE__ */ jsxDEV(MarketingReasonTick, {}, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 333,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 333,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 334,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 335,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "count", name: "Số trường hợp", fill: colors.accent, radius: [4, 4, 0, 0] }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 336,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 331,
            columnNumber: 101
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 331,
            columnNumber: 53
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "Chưa có lý do mất đơn trong kỳ này." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 337,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 330,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { rows: m.lostSaleReasons, rowKey: (reason) => reason.reason, label: "Lý do không chốt đơn", empty: "Chưa có lý do mất đơn trong kỳ đã chọn.", columns: [
            { key: "reason", label: "Lý do", render: (reason) => reason.reason },
            { key: "count", label: "Số trường hợp", align: "right", render: (reason) => reason.count }
          ] }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 339,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 329,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 301,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.page.sectionBefore, children: "Không tự gán nguồn cho đơn thiếu dữ liệu, không ghi chi ước tính thành chi thực tế và không tự đăng nội dung hoặc tăng ngân sách." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 345,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 290,
      columnNumber: 229
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 290,
      columnNumber: 173
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 274,
    columnNumber: 10
  }, this);
}
_s2(MarketingPage, "XHRcSz0e7gB/5wuA5gDL5DvZ7FM=", false, function() {
  return [useScope, useSearchParams, useApi];
});
_c3 = MarketingPage;
function marketingRangeError(fromDate, toDate, bucket, allowDefault) {
  if (!["day", "week", "month"].includes(bucket)) return { field: "bucket", message: "Chọn nhóm ngày, tuần hoặc tháng." };
  if (allowDefault && !fromDate && !toDate) return null;
  if (!isValidDateOnly(fromDate)) return { field: "fromDate", message: "Nhập ngày bắt đầu hợp lệ." };
  if (!isValidDateOnly(toDate)) return { field: "toDate", message: "Nhập ngày kết thúc hợp lệ." };
  if (fromDate > toDate) return { field: "fromDate", message: "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc." };
  const days = Math.floor((Date.parse(`${toDate}T00:00:00.000Z`) - Date.parse(`${fromDate}T00:00:00.000Z`)) / (24 * 60 * 60 * 1e3)) + 1;
  if (days > 366) return { field: "toDate", message: "Khoảng báo cáo không được vượt quá 366 ngày." };
  return null;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "MarketingReasonTick");
$RefreshReg$(_c2, "ReportsPage");
$RefreshReg$(_c3, "MarketingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJXLFNBOEdBLFVBOUdBOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCWCxTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxtQkFBbUI7QUFDbkUsU0FBU0MsV0FBV0MsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBRXJELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsTUFBTUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQ2pGLFNBQVNDLEtBQUtDLFVBQVVDLGVBQWVDLFFBQVFDLHFCQUFxQkMsTUFBTUMsU0FBU0MsT0FBT0MsYUFBYTtBQUV2RyxTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLGdCQUFnQkMsdUJBQXVCO0FBQzFELFNBQVNDLFFBQVFDLFdBQVdDLFlBQVlDLGFBQWFDLFlBQVlDLE9BQU9DLE9BQU9DLFlBQVlDLFdBQVdDLE1BQU1DLE9BQU9DLGNBQWM7QUFDakksU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHdCQUF3QkMsZ0JBQWdCQyxvQkFBb0JDLHNCQUFzQjtBQUUzRixNQUFNQyxlQUE0RDtBQUFBLEVBQzlEQyxXQUFXO0FBQUEsRUFBV0MsUUFBUTtBQUFBLEVBQVlDLFVBQVU7QUFBQSxFQUFhQyxhQUFhO0FBQ2xGO0FBQ0EsTUFBTUMsb0JBQWlFO0FBQUEsRUFDbkVKLFdBQVc7QUFBQSxFQUFrQkMsUUFBUTtBQUFBLEVBQWVDLFVBQVU7QUFBQSxFQUFnQkMsYUFBYTtBQUMvRjtBQUVBLFNBQVNFLG9CQUFvQixFQUFFQyxJQUFJLEdBQUdDLElBQUksR0FBR0MsUUFBUSxHQUFHQyxvQkFBb0IsR0FBR0MsUUFBK0csR0FBRztBQUM3TCxRQUFNQyxRQUFRLE9BQU9ELFNBQVNDLFVBQVUsV0FBV0QsUUFBUUMsTUFBTUMsS0FBSyxJQUFJO0FBQzFFLFFBQU1DLHFCQUFxQjtBQUMzQixRQUFNQyxhQUFhQyxLQUFLQyxJQUFJLEdBQUdSLFFBQVFPLEtBQUtDLElBQUksR0FBR1AsaUJBQWlCLElBQUlJLGtCQUFrQjtBQUMxRixTQUFPO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFBSztBQUFBLE1BQU07QUFBQSxNQUFNLElBQUk7QUFBQSxNQUFJLE9BQU9DO0FBQUFBLE1BQVksVUFBUTtBQUFBLE1BQUMsZ0JBQWU7QUFBQSxNQUFRLFlBQVc7QUFBQSxNQUFTLE1BQU16QyxPQUFPNEM7QUFBQUEsTUFDakgsT0FBTyxFQUFFQyxVQUFVNUMsT0FBTzZDLFVBQVVDLE1BQU1DLFlBQVkvQyxPQUFPK0MsV0FBVztBQUFBLE1BQUlWO0FBQUFBO0FBQUFBLElBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUMrRTtBQUMxRjtBQUFDVyxLQU5RakI7QUFRRixnQkFBU2tCLGNBQWM7QUFBQUMsS0FBQTtBQUMxQixRQUFNLEVBQUVDLEtBQUssSUFBSWhELFNBQVM7QUFDMUIsUUFBTSxDQUFDaUQsUUFBUUMsU0FBUyxJQUFJeEUsZ0JBQWdCO0FBQzVDLFFBQU15RSxlQUFlNUUsT0FBTyxJQUFJNkUsZ0JBQWdCSCxNQUFNLENBQUM7QUFDdkQsUUFBTUksZ0JBQWdCOUUsT0FBc0IsSUFBSTtBQUNoREYsWUFBVSxNQUFNO0FBQ1osVUFBTWlGLGtCQUFrQkwsT0FBT00sU0FBUztBQUN4QyxRQUFJRixjQUFjRyxZQUFZLFFBQVFILGNBQWNHLFlBQVlGLGdCQUFpQjtBQUNqRkgsaUJBQWFLLFVBQVUsSUFBSUosZ0JBQWdCSCxNQUFNO0FBQ2pESSxrQkFBY0csVUFBVTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ1AsTUFBTSxDQUFDO0FBQ1gsUUFBTVEsVUFBVTNELE9BQU8sa0JBQWtCO0FBQ3pDLFFBQU00RCxjQUFjekQsT0FBTyxXQUFXO0FBQ3RDLFFBQU0wRCxPQUFPN0QsT0FBTyxZQUFZLEVBQUU4RCxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsUUFBUWIsT0FBT2MsSUFBSSxRQUFRLEtBQUtDLE9BQVUsRUFBRSxHQUFHTixXQUFXO0FBQ2hILFFBQU1PLE1BQU1sRSxXQUFXLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztBQUNuRCxRQUFNbUUsZ0JBQWdCakIsT0FBT2MsSUFBSSxZQUFZO0FBQzdDLFFBQU1JLE9BQW9DRCxrQkFBa0IsZUFBZUEsa0JBQWtCLGNBQWNBLGtCQUFrQixnQkFBZ0JBLGdCQUFnQjtBQUM3SixRQUFNRSxlQUFlWCxRQUFRWSxNQUFNQSxLQUFLQztBQUN4QyxRQUFNQyxlQUFlakcsUUFBUSxNQUFNO0FBQy9CLFFBQUksQ0FBQzhGLGFBQWMsUUFBTztBQUMxQixRQUFJO0FBQ0EsWUFBTUksY0FBY3JELGVBQWVpRCxjQUFjcEIsS0FBS3lCLFFBQVE7QUFDOUQsYUFBTyxFQUFFQyxVQUFVLEdBQUdGLFlBQVlHLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBT0MsUUFBUUosWUFBWTtBQUFBLElBQzVFLFFBQ007QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3hCLEtBQUt5QixVQUFVTCxZQUFZLENBQUM7QUFDaEMsUUFBTVMsWUFBWTVCLE9BQU9jLElBQUksVUFBVTtBQUN2QyxRQUFNZSxVQUFVN0IsT0FBT2MsSUFBSSxRQUFRO0FBQ25DLFFBQU1nQixpQkFBaUJBLENBQUNDLEtBQTRCOUMsVUFBeUI7QUFDekUsUUFBSTlCLGdCQUFnQjhCLEtBQUssRUFBRyxRQUFPQTtBQUNuQyxRQUFJZSxPQUFPZ0MsSUFBSUQsR0FBRyxLQUFLOUMsVUFBVSxHQUFJLFFBQU87QUFDNUMsV0FBT3FDLGVBQWVTLEdBQUcsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsUUFBTUUsT0FBT0gsZUFBZSxZQUFZRixTQUFTO0FBQ2pELFFBQU1NLEtBQUtKLGVBQWUsVUFBVUQsT0FBTztBQUMzQyxRQUFNTSxpQkFBaUJBLENBQUNKLEtBQTJDOUMsVUFBa0I7QUFDakYsVUFBTW1ELE9BQU8sSUFBSWpDLGdCQUFnQkQsYUFBYUssT0FBTztBQUNyRCxRQUFJd0IsUUFBUSxhQUFjSyxNQUFLQyxJQUFJTixLQUFLOUMsS0FBSztBQUFBO0FBQ3hDbUQsV0FBS0MsSUFBSU4sS0FBSzVFLGdCQUFnQjhCLEtBQUssSUFBSUEsUUFBUSxFQUFFO0FBQ3REaUIsaUJBQWFLLFVBQVU2QjtBQUN2QmhDLGtCQUFjRyxVQUFVNkIsS0FBSzlCLFNBQVM7QUFDdENMLGNBQVVtQyxNQUFNLEVBQUVFLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDdkM7QUFDQSxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWpILFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrSCxZQUFZQyxhQUFhLElBQUluSCxTQUEyRixJQUFJO0FBQ25JLFFBQU1vSCxtQkFBbUIzRixPQUFPLGdCQUFnQjtBQUNoRCxRQUFNNEYsa0JBQWtCNUYsT0FBTzBCLGtCQUFrQndDLElBQUksQ0FBQztBQUN0RCxRQUFNMkIsbUJBQW1CckMsUUFBUVksTUFBTUEsS0FBS3lCLG9CQUFvQjtBQUNoRSxRQUFNQyxrQkFBa0JELGlCQUFpQkUsU0FBUzdCLElBQUk7QUFFdEQ5RixZQUFVLE1BQU07QUFDWixRQUFJLENBQUMrRixhQUFjO0FBQ25CLFFBQUksQ0FBQ0csY0FBYztBQUNma0Isb0JBQWMsMkRBQTJEO0FBQ3pFO0FBQUEsSUFDSjtBQUNBLFFBQUk7QUFDQSxZQUFNSixPQUFPLElBQUlqQyxnQkFBZ0JELGFBQWFLLE9BQU87QUFDckQsVUFBSXlDLFVBQVU7QUFDZCxVQUFJL0Isa0JBQWtCLGVBQWVBLGtCQUFrQixjQUFjQSxrQkFBa0IsaUJBQWlCQSxrQkFBa0IsVUFBVTtBQUNoSW1CLGFBQUtDLElBQUksY0FBYyxRQUFRO0FBQy9CVyxrQkFBVTtBQUFBLE1BQ2Q7QUFDQSxVQUFJLENBQUNoRCxPQUFPZ0MsSUFBSSxVQUFVLEtBQU1KLGFBQWEsQ0FBQ3pFLGdCQUFnQnlFLFNBQVMsR0FBSTtBQUN2RVEsYUFBS0MsSUFBSSxZQUFZZixhQUFhRyxRQUFRO0FBQzFDdUIsa0JBQVU7QUFBQSxNQUNkO0FBQ0EsVUFBSSxDQUFDaEQsT0FBT2dDLElBQUksUUFBUSxLQUFNSCxXQUFXLENBQUMxRSxnQkFBZ0IwRSxPQUFPLEdBQUk7QUFDakVPLGFBQUtDLElBQUksVUFBVWYsYUFBYUssTUFBTTtBQUN0Q3FCLGtCQUFVO0FBQUEsTUFDZDtBQUNBLFVBQUlBLFNBQVM7QUFDVDlDLHFCQUFhSyxVQUFVNkI7QUFDdkJoQyxzQkFBY0csVUFBVTZCLEtBQUs5QixTQUFTO0FBQ3RDTCxrQkFBVW1DLE1BQU0sRUFBRWEsU0FBUyxNQUFNWCxXQUFXLEtBQUssQ0FBQztBQUFBLE1BQ3REO0FBQUEsSUFDSixRQUNNO0FBQUVFLG9CQUFjLDJEQUEyRDtBQUFBLElBQUc7QUFBQSxFQUN4RixHQUFHLENBQUNsQixjQUFjdEIsUUFBUWlCLGVBQWVXLFdBQVdDLFNBQVM1QixXQUFXa0IsWUFBWSxDQUFDO0FBRXJGLFFBQU0rQixTQUFTLFlBQVk7QUFDdkJWLGtCQUFjLEVBQUU7QUFDaEIsUUFBSTtBQUNBLFVBQUksQ0FBQ3JCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLEdBQUksT0FBTSxJQUFJaUIsV0FBVywyQ0FBMkM7QUFDbkcsWUFBTUMsVUFBVTtBQUFBLFFBQ1pDLFlBQVluQztBQUFBQSxRQUNab0MsUUFBUTtBQUFBLFFBQ1JyQixNQUFNOUQsbUJBQW1COEQsTUFBTSxTQUFTbEMsS0FBS3lCLFFBQVE7QUFBQSxRQUNyRFUsSUFBSS9ELG1CQUFtQitELElBQUksT0FBT25DLEtBQUt5QixRQUFRO0FBQUEsUUFDL0NBLFVBQVV6QixLQUFLeUI7QUFBQUEsUUFDZkw7QUFBQUEsTUFDSjtBQUNBdUIsb0JBQWMsSUFBSTtBQUNsQixZQUFNYSxXQUFXLE1BQU12QyxJQUFJd0MsUUFBUSxFQUFFOUQsTUFBTTBELFFBQVEsQ0FBQztBQUNwRFYsb0JBQWMsRUFBRWUsS0FBS0YsU0FBU25DLE1BQU1GLE1BQU1lLE1BQU1DLEdBQUcsQ0FBQztBQUFBLElBQ3hELFNBQ093QixPQUFPO0FBQ1YsVUFBSUEsaUJBQWlCUCxXQUFZWCxlQUFja0IsTUFBTUMsT0FBTztBQUFBLElBQ2hFO0FBQUEsRUFDSjtBQUNBLFFBQU1DLGVBQWVBLE1BQU07QUFBRSxTQUFLVixPQUFPO0FBQUEsRUFBRztBQUU1QyxRQUFNVyxlQUFlcEIsWUFBWWdCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxjQUN4RTlGLHVCQUF1QndFLFdBQVdnQixJQUFJTSxhQUFhQyxTQUFTQyxRQUFRQyxRQUFRLElBQzVFO0FBRU4sU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSwwQkFBeUIsVUFBUyx3RkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3STtBQUFBLElBQ3hJLHVCQUFDLGVBQVksZUFBWSx1QkFBc0IsU0FBUyxFQUFFQyxJQUFJLGtCQUFrQkMsSUFBSSxtQ0FBbUMsR0FBRyxZQUFZLFNBQVMsVUFBVSxFQUFDQyxVQUFVLEVBQUMsR0FDaks7QUFBQSw2QkFBQyxnQkFBYSxlQUFZLHlCQUN0QjtBQUFBLCtCQUFDLGNBQVcsT0FBTzdELFNBQVMsZ0JBQWUsV0FDdENBLGtCQUFRWSxRQUFRLHVCQUFDLFNBQU0sT0FBTSxtQkFBa0IsVUFBUyw0RUFBMkUsVUFBUyxTQUN6SSxpQ0FBQyxjQUFXLGVBQVksOEJBQTZCLFVBQVUsRUFBQ2tELFVBQVUsSUFBRyxHQUN6RTtBQUFBLGlDQUFDLGVBQVksT0FBT3RELElBQUkwQyxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzdCbkIsY0FBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2hFLHVCQUFDLGFBQVUsT0FBTSxXQUFVLFFBQU0sTUFBQyxPQUFPckIsTUFBTSxVQUFVLENBQUFxRCxVQUFTO0FBQzlELGtCQUFNdEYsUUFBUXNGLE1BQU1DLE9BQU92RjtBQUMzQixnQkFBSUEsVUFBVSxZQUFZQSxVQUFVLGVBQWVBLFVBQVUsY0FBY0EsVUFBVSxjQUFla0QsZ0JBQWUsY0FBY2xELEtBQUs7QUFDdEl5RCwwQkFBYyxJQUFJO0FBQUEsVUFDdEIsR0FDS0csMkJBQWlCNEIsSUFBSSxDQUFBQyxXQUFVLHVCQUFDLFlBQVMsT0FBT0EsUUFBc0JyRyx1QkFBYXFHLE1BQU0sS0FBNUJBLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELENBQVcsS0FMM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0M3QixpQkFBaUI4QixXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sK0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDeEcsdUJBQUMsY0FBVyxlQUFZLHdCQUF1QixXQUFXLEVBQUVSLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQ2hGO0FBQUEsbUNBQUMsYUFBVSxPQUFNLFdBQVUsTUFBSyxRQUFPLE9BQU8zQyxNQUFNLFVBQVUsQ0FBQXNDLFVBQVNwQyxlQUFlLFlBQVlvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZLO0FBQUEsWUFDN0ssdUJBQUMsYUFBVSxPQUFNLFlBQVcsTUFBSyxRQUFPLE9BQU81QyxJQUFJLFVBQVUsQ0FBQXFDLFVBQVNwQyxlQUFlLFVBQVVvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBLO0FBQUEsZUFGOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsY0FBVyxPQUFNLFdBQVcvRSxlQUFLeUIsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxjQUFXLE9BQU0sZ0JBQWdCTCx5QkFBZWxFLFNBQVNrRSxjQUFjcEIsS0FBS3lCLFFBQVEsSUFBSSxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxVQUMzRyxDQUFDbUIsb0JBQW9CLHVCQUFDLFNBQU0sVUFBUyxXQUFVLCtEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQzlGQSxvQkFBb0IsQ0FBQ0MsbUJBQW1CLHVCQUFDLFNBQU0sVUFBUyxXQUFVO0FBQUE7QUFBQSxZQUEyQ2xFLGtCQUFrQndDLElBQUk7QUFBQSxZQUFFO0FBQUEsZUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEg7QUFBQSxVQUN0S3lCLG9CQUFvQkMsbUJBQW1CLENBQUNFLG1CQUFtQkQsaUJBQWlCOEIsU0FBUyxLQUFLLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHdFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQzdLLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVNmLGNBQWMsVUFBVSxDQUFDakIsb0JBQW9CLENBQUNDLG1CQUFtQixDQUFDRSxtQkFBbUIsQ0FBQzNCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLE1BQU1ELE9BQU9DLE1BQU1sQixJQUFJK0QsU0FDdksvRCxjQUFJK0QsVUFBVSx1QkFBdUIseUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDdEMsY0FBYyx1QkFBQyxlQUFZLFdBQVcsRUFBRTBCLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQUksWUFBWSxFQUFFVCxJQUFJLFdBQVdTLElBQUksU0FBUyxHQUMzRztBQUFBLG1DQUFDLGFBQVUsSUFBSSxNQUFNN0UsS0FBS2lGLEVBQUUsU0FBU3ZDLFdBQVdnQixJQUFJdUIsRUFBRSxJQUFJO0FBQUE7QUFBQSxjQUFvQnZDLFdBQVdnQixJQUFJdUI7QUFBQUEsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsWUFDL0ZuQixnQkFBZ0IsdUJBQUMsUUFBSyxlQUFZLDJCQUEwQixXQUFVLEtBQUksTUFBTUEsY0FBYyxVQUFVekYsZUFBZXFFLFdBQVd2QixNQUFNdUIsV0FBV1IsTUFBTVEsV0FBV1AsRUFBRSxHQUFHLFdBQVUsUUFBTyxJQUFJLENBQUNsRSxTQUFTaUgsUUFBUUMsWUFBWSxFQUFFQyxRQUFRLEdBQUdDLGFBQWEsV0FBV0MsY0FBYzdKLFNBQVM4SixPQUFPQyxTQUFTQyxPQUFPLGdCQUFnQkMsWUFBWWpLLFNBQVNrSyxXQUFXRCxXQUFXRSxVQUFVLFdBQVcsRUFBRUMsU0FBUyxnQkFBZ0JDLGdCQUFnQixPQUFPLEdBQUcsbUJBQW1CLEVBQUVDLFNBQVMsR0FBR2xKLE9BQU9tSixVQUFVakgsS0FBSyxZQUFZa0gsY0FBYyxpQkFBaUJDLGVBQWVySixPQUFPbUosVUFBVUcsY0FBYyxFQUFFLENBQUMsR0FBRyx1QkFBMWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlrQjtBQUFBLFlBQ2psQnpELFdBQVdnQixJQUFJSyxXQUFXLGVBQWUsdUJBQUMsU0FBTSxVQUFVckIsV0FBV2dCLElBQUlLLFdBQVcsYUFBYXJCLFdBQVdnQixJQUFJSyxXQUFXLFdBQVcsWUFBWSxRQUFRLGtFQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSztBQUFBLFlBQzVNckIsV0FBV2dCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxlQUFlLENBQUNGLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSwwRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUpsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtmO0FBQUEsVUFDQ3JELFFBQVFZLEtBQUtBLEtBQUsrRSxTQUFTMUIsSUFBSSxDQUFDMkIsU0FBU0MsVUFBVSx1QkFBQyxTQUFrQyxVQUFTLFFBQVFELHFCQUF4QyxHQUFHQyxLQUFLLElBQUlELE9BQU8sSUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQsQ0FBUTtBQUFBLFVBQ3hILHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrTDtBQUFBLGFBOUJ0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBLEtBaENhO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ2pCLEtBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxRQUNDM0YsY0FBYyx1QkFBQyxjQUFXLE9BQU9DLE1BQU0sZ0JBQWUsV0FDbERBLGVBQUtVLFFBQVEsdUJBQUMsU0FBTSxPQUFNLHFCQUFvQixVQUFTLHNGQUNwRDtBQUFBLGlDQUFDLGFBQVUsTUFBTVYsS0FBS1UsS0FBS0EsTUFBTSxRQUFRLENBQUFxQyxRQUFPQSxJQUFJdUIsSUFBSSxPQUFNLHFCQUFvQixPQUFNLHNDQUFxQyxTQUFTO0FBQUEsWUFDbEksRUFBRWpELEtBQUssTUFBTXVFLE9BQU8sZ0JBQWdCQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxhQUFVLElBQUksTUFBTTFELEtBQUtpRixFQUFFLFNBQVN2QixJQUFJdUIsRUFBRSxJQUFLdkIsY0FBSXVCLE1BQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVELEVBQWE7QUFBQSxZQUN2SCxFQUFFakQsS0FBSyxRQUFRdUUsT0FBTyxRQUFRQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUkrQyxRQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QixFQUFJO0FBQUEsWUFDekUsRUFBRXpFLEtBQUssVUFBVXVFLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQTlDLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJSyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQixFQUFJO0FBQUEsWUFDbkYsRUFBRS9CLEtBQUssWUFBWXVFLE9BQU8sV0FBV0csT0FBTyxTQUFTRixRQUFRQSxDQUFBOUMsUUFBTyxHQUFHQSxJQUFJaUQsU0FBUyxNQUFNakQsSUFBSWtELFNBQVMsV0FBVyxHQUFHO0FBQUEsWUFDckgsRUFBRTVFLEtBQUssYUFBYXVFLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQTlDLFFBQU94RyxTQUFTd0csSUFBSW1ELFdBQVc3RyxLQUFLeUIsUUFBUSxFQUFFO0FBQUEsVUFBQyxLQUxsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1FO0FBQUEsVUFDRix1QkFBQyxTQUFNLE1BQU1kLEtBQUtVLEtBQUt5RixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLGFBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTZCxLQVZXO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXZixJQUFnQix1QkFBQyxTQUFNLFVBQVMsUUFBTyw2RkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFdBaER4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sbUJBQWtCLFVBQVMsNkRBQTRELFVBQVMsU0FDekcsaUNBQUMsU0FBTSxJQUFJN0ksU0FBUzBHLE9BQU9vQyxZQUN2QjtBQUFBLCtCQUFDLGNBQVcsT0FBTSxrQkFBaUIsOEpBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxRQUNqTCx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLHdIQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFDM0ksdUJBQUMsYUFBVSxJQUFJLE1BQU0vRyxLQUFLaUYsRUFBRSxzQkFBc0IsdUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0E1REc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEUDtBQUNKO0FBQUNsRixHQXhLZUQsYUFBVztBQUFBLFVBQ045QyxVQUNXdEIsaUJBU1pvQixRQUNJRyxRQUNQSCxRQUNEQyxZQStCYUUsUUFDREEsTUFBTTtBQUFBO0FBQUEsTUE5Q2xCNkM7QUEwS1QsZ0JBQVNrSCxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUVqSCxLQUFLLElBQUloRCxTQUFTO0FBQzFCLFFBQU0sQ0FBQ2lELFFBQVFDLFNBQVMsSUFBSXhFLGdCQUFnQjtBQUM1QyxRQUFNd0wsU0FBU2pILE9BQU9NLFNBQVM7QUFDL0IsUUFBTTRHLFlBQVlsSCxPQUFPYyxJQUFJLFVBQVUsS0FBSztBQUM1QyxRQUFNcUcsVUFBVW5ILE9BQU9jLElBQUksUUFBUSxLQUFLO0FBQ3hDLFFBQU1zRyxjQUFjcEgsT0FBT2MsSUFBSSxRQUFRLEtBQUs7QUFDNUMsUUFBTXVHLGdCQUFnQnJILE9BQU9nQyxJQUFJLFVBQVUsS0FBS2hDLE9BQU9nQyxJQUFJLFFBQVE7QUFDbkUsUUFBTXNGLGVBQWVDLG9CQUFvQkwsV0FBV0MsU0FBU0MsYUFBYSxDQUFDQyxhQUFhO0FBQ3hGLFFBQU0xRyxRQUFRMkcsZUFBZXZHLFNBQVk7QUFBQSxJQUNyQyxHQUFJZixPQUFPZ0MsSUFBSSxVQUFVLElBQUksRUFBRVAsVUFBVXlGLFVBQVUsSUFBSSxDQUFDO0FBQUEsSUFDeEQsR0FBSWxILE9BQU9nQyxJQUFJLFFBQVEsSUFBSSxFQUFFTCxRQUFRd0YsUUFBUSxJQUFJLENBQUM7QUFBQSxJQUNsRCxHQUFJbkgsT0FBT2dDLElBQUksUUFBUSxJQUFJLEVBQUV3RixRQUFRSixZQUErQixJQUFJLENBQUM7QUFBQSxFQUM3RTtBQUNBLFFBQU1oRyxPQUFPdkUsT0FBTyx1QkFBdUI4RCxTQUFTOEcsT0FBT0MsS0FBSy9HLEtBQUssRUFBRWdFLFNBQVMsRUFBRWhFLE1BQU0sSUFBSUksUUFBVyxDQUFDdUcsWUFBWTtBQUNwSCxRQUFNSyxJQUFJdkcsS0FBS0EsTUFBTUE7QUFDckIsUUFBTXdHLGtCQUFrQkQsR0FBR0U7QUFDM0IsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl4TSxTQUFTLEVBQUVrRyxVQUFVeUYsV0FBV3ZGLFFBQVF3RixTQUFTSyxRQUFRSixZQUFZLENBQUM7QUFDaEcsUUFBTSxDQUFDWSxpQkFBaUJDLGtCQUFrQixJQUFJMU0sU0FBUyxLQUFLO0FBQzVELFFBQU0yTSxVQUFVNU0sT0FBeUIsSUFBSTtBQUM3QyxRQUFNNk0sUUFBUTdNLE9BQXlCLElBQUk7QUFDM0MsUUFBTThNLFlBQVk5TSxPQUF5QixJQUFJO0FBQy9DLFFBQU0rTSxhQUFhZCxvQkFBb0JPLE1BQU1yRyxVQUFVcUcsTUFBTW5HLFFBQVFtRyxNQUFNTixRQUFRLEtBQUs7QUFDeEYsUUFBTWMscUJBQXFCTixrQkFBa0JLLGFBQWFmO0FBRTFEbE0sWUFBVSxNQUFNO0FBQ1osUUFBSXdNLGlCQUFpQjtBQUNqQkcsZUFBUyxFQUFFdEcsVUFBVW1HLGdCQUFnQm5HLFVBQVVFLFFBQVFpRyxnQkFBZ0JqRyxRQUFRNkYsUUFBUUksZ0JBQWdCSixPQUFPLENBQUM7QUFDL0csWUFBTXBGLE9BQU8sSUFBSWpDLGdCQUFnQixFQUFFc0IsVUFBVW1HLGdCQUFnQm5HLFVBQVVFLFFBQVFpRyxnQkFBZ0JqRyxRQUFRNkYsUUFBUUksZ0JBQWdCSixPQUFPLENBQUM7QUFDdkksVUFBSXBGLEtBQUs5QixTQUFTLE1BQU0yRyxPQUFRaEgsV0FBVW1DLE1BQU0sRUFBRWEsU0FBUyxLQUFLLENBQUM7QUFBQSxJQUNyRTtBQUFBLEVBQ0osR0FBRyxDQUFDMkUsaUJBQWlCWCxRQUFRaEgsU0FBUyxDQUFDO0FBRXZDN0UsWUFBVSxNQUFNO0FBQ1osVUFBTW1GLFVBQVUsSUFBSUosZ0JBQWdCOEcsTUFBTTtBQUMxQyxRQUFJLENBQUMxRyxRQUFReUIsSUFBSSxVQUFVLEtBQUssQ0FBQ3pCLFFBQVF5QixJQUFJLFFBQVEsRUFBRztBQUN4RCtGLGFBQVMsRUFBRXRHLFVBQVVsQixRQUFRTyxJQUFJLFVBQVUsS0FBSyxJQUFJYSxRQUFRcEIsUUFBUU8sSUFBSSxRQUFRLEtBQUssSUFBSTBHLFFBQVFqSCxRQUFRTyxJQUFJLFFBQVEsS0FBSyxNQUFNLENBQUM7QUFDakltSCx1QkFBbUIsS0FBSztBQUFBLEVBQzVCLEdBQUcsQ0FBQ2hCLE1BQU0sQ0FBQztBQUVYLFFBQU1zQixjQUFjQSxDQUFDaEUsVUFBc0M7QUFDdkRBLFVBQU1pRSxlQUFlO0FBQ3JCUCx1QkFBbUIsSUFBSTtBQUN2QixRQUFJSSxZQUFZO0FBQ1osWUFBTTdELFNBQVM2RCxXQUFXSSxVQUFVLGFBQWFQLFFBQVEzSCxVQUFVOEgsV0FBV0ksVUFBVSxXQUFXTixNQUFNNUgsVUFBVTZILFVBQVU3SDtBQUM3SGlFLGNBQVFrRSxNQUFNO0FBQ2Q7QUFBQSxJQUNKO0FBQ0EsVUFBTXRHLE9BQU8sSUFBSWpDLGdCQUFnQixFQUFFc0IsVUFBVXFHLE1BQU1yRyxVQUFVRSxRQUFRbUcsTUFBTW5HLFFBQVE2RixRQUFRTSxNQUFNTixPQUFPLENBQUM7QUFDekdTLHVCQUFtQixLQUFLO0FBQ3hCaEksY0FBVW1DLElBQUk7QUFBQSxFQUNsQjtBQUVBLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0sMkJBQTBCLFVBQVMsNEVBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkg7QUFBQSxJQUM1SDhCLFlBQVksdUJBQUMsU0FBTSxVQUFTLFdBQVUsSUFBSWxHLFNBQVMySyxPQUFPQyxVQUFVLCtHQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVKO0FBQUEsSUFDcEssdUJBQUMsU0FBTSxPQUFNLDRCQUEyQixVQUFVLDRCQUE0QjdJLEtBQUt5QixRQUFRLGtCQUFrQixVQUFTLFNBQVEsVUFBUyxXQUNuSSxpQ0FBQyxjQUFXLFdBQVUsUUFBTyxVQUFVK0csYUFBYSxlQUFZLHdCQUM1RDtBQUFBLDZCQUFDLFNBQU0sV0FBVyxFQUFFcEUsSUFBSSxVQUFVMEUsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFMUUsSUFBSSxXQUFXMEUsSUFBSSxXQUFXLEdBQUcsSUFBSTdLLFNBQVM4SyxRQUFRQyxZQUMvRztBQUFBLCtCQUFDLGFBQVUsVUFBVWIsU0FBUyxNQUFLLFFBQU8sT0FBTSxXQUFVLE9BQU9KLE1BQU1yRyxVQUFVLFVBQVUsQ0FBQThDLFVBQVN3RCxTQUFTLENBQUE5SSxXQUFVLEVBQUUsR0FBR0EsT0FBT3dDLFVBQVU4QyxNQUFNQyxPQUFPdkYsTUFBTSxFQUFFLEdBQUcsV0FBVyxFQUFFNEYsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxHQUFHLE9BQU93RCxvQkFBb0JHLFVBQVUsWUFBWSxZQUFZSCxvQkFBb0JHLFVBQVUsYUFBYUgsbUJBQW1CM0UsVUFBVSx5Q0FBdlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2WDtBQUFBLFFBQzdYLHVCQUFDLGFBQVUsVUFBVXdFLE9BQU8sTUFBSyxRQUFPLE9BQU0sWUFBVyxPQUFPTCxNQUFNbkcsUUFBUSxVQUFVLENBQUE0QyxVQUFTd0QsU0FBUyxDQUFBOUksV0FBVSxFQUFFLEdBQUdBLE9BQU8wQyxRQUFRNEMsTUFBTUMsT0FBT3ZGLE1BQU0sRUFBRSxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxPQUFPd0Qsb0JBQW9CRyxVQUFVLFVBQVUsWUFBWUgsb0JBQW9CRyxVQUFVLFdBQVdILG1CQUFtQjNFLFVBQVUsdUNBQTlVO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa1g7QUFBQSxRQUNsWCx1QkFBQyxhQUFVLFVBQVV5RSxXQUFXLFFBQU0sTUFBQyxPQUFNLFlBQVcsT0FBT04sTUFBTU4sUUFBUSxVQUFVLENBQUFqRCxVQUFTd0QsU0FBUyxDQUFBOUksV0FBVSxFQUFFLEdBQUdBLE9BQU91SSxRQUFRakQsTUFBTUMsT0FBT3ZGLE1BQU0sRUFBRSxHQUFHLE9BQU9xSixvQkFBb0JHLFVBQVUsVUFBVSxZQUFZSCxvQkFBb0JHLFVBQVUsV0FBV0gsbUJBQW1CM0UsVUFBVSwrQkFDNVI7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEI7QUFBQSxVQUFXLHVCQUFDLFlBQVMsT0FBTSxRQUFPLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQVcsdUJBQUMsWUFBUyxPQUFNLFNBQVEscUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsYUFENUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksdUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQU5yRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNDcUUsbUJBQW1CSyxjQUFjLHVCQUFDLFNBQU0sVUFBUyxTQUFRLE1BQUssU0FBU0EscUJBQVcxRSxXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsU0FUL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQzJELGVBQWUsdUJBQUMsU0FBTSxVQUFTLFNBQVEsTUFBSyxTQUFRO0FBQUEsNkJBQUMsWUFBTyxtREFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDO0FBQUEsTUFBUztBQUFBLFNBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUksSUFBVyx1QkFBQyxjQUFXLE9BQU9sRyxNQUFNLGdCQUFlLFdBQVd1RyxlQUFLLG1DQUN4TjtBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFLLE9BQU0seUJBQXdCLE9BQU9BLEVBQUVxQix1QkFBdUIsTUFBSyxnQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFFBQ3JHLHVCQUFDLFFBQUssT0FBTSxxQkFBb0IsT0FBT3JCLEVBQUVzQiwwQkFBMEIsTUFBSyxtQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFFBQ3ZHLHVCQUFDLFFBQUssT0FBTSx5QkFBd0IsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPdEIsRUFBRXVCLGVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0MsR0FBSyxNQUFNdkIsRUFBRXVCLGNBQWMsNEJBQTRCLHNDQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVLO0FBQUEsUUFDdkssdUJBQUMsUUFBSyxPQUFNLDBCQUF5QixPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU92QixFQUFFd0Isa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUMsR0FBSyxNQUFLLG1DQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsV0FKOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLGVBQVksbUJBQWtCLElBQUksQ0FBQ25MLFNBQVMwRyxPQUFPb0MsWUFBWTlJLFNBQVM2SSxLQUFLdUMsWUFBWSxHQUMzRnpCO0FBQUFBLFVBQUVFLFVBQVUsdUJBQUMsY0FBVyxTQUFRLFNBQVE7QUFBQTtBQUFBLFVBQUkzSyxlQUFleUssRUFBRUUsT0FBT3BHLFFBQVE7QUFBQSxVQUFFO0FBQUEsVUFBSXZFLGVBQWV5SyxFQUFFRSxPQUFPbEcsTUFBTTtBQUFBLFVBQUU7QUFBQSxVQUFhZ0csRUFBRUUsT0FBT0wsV0FBVyxRQUFRLFNBQVNHLEVBQUVFLE9BQU9MLFdBQVcsU0FBUyxTQUFTO0FBQUEsYUFBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzTTtBQUFBLFFBQ25OLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCO0FBQUE7QUFBQSxVQUFVdkssU0FBUzBLLEVBQUV0RyxNQUFNc0csRUFBRUUsUUFBUXJHLFlBQVl6QixLQUFLeUIsUUFBUTtBQUFBLFVBQUU7QUFBQSxVQUFJekIsS0FBS3NKO0FBQUFBLFVBQUs7QUFBQSxVQUFZMUIsRUFBRUUsUUFBUXJHLFlBQVl6QixLQUFLeUI7QUFBQUEsYUFBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTDtBQUFBLFdBRnZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsZUFBWSxlQUFZLDJCQUEwQixTQUFTLEVBQUUyQyxJQUFJLE9BQU9tRixJQUFJLFVBQVUsR0FDbkY7QUFBQSwrQkFBQyxTQUFNLE9BQU0sc0JBQXFCLFVBQVMsOERBQ3ZDO0FBQUEsaUNBQUMsT0FBSSxNQUFLLE9BQU0sY0FBWSxlQUFlM0IsRUFBRUUsUUFBUUwsVUFBVSxJQUFJLHlCQUF5QixlQUFZLHlCQUF3QixJQUFJLENBQUMsRUFBRStCLFFBQVEsSUFBSSxHQUFHdkwsU0FBUzBHLE9BQU84RSxrQkFBa0IsR0FDbkw3QixZQUFFOEIsT0FBTzlFLFNBQVMsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQU8saUNBQUMsWUFBUyxNQUFNZ0QsRUFBRThCLE9BQU8sb0JBQWtCLE1BQzFHO0FBQUEsbUNBQUMsaUJBQWMsUUFBUTlNLE9BQU8rTSxrQkFBa0IsVUFBVSxTQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFLHVCQUFDLFNBQU0sU0FBUSxZQUFXLFFBQVEvTSxPQUFPNEMsZUFBZSxVQUFVRixLQUFLQyxJQUFJLEdBQUdELEtBQUtzSyxLQUFLaEMsRUFBRThCLE1BQU05RSxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsZUFBZSxDQUFBMUYsVUFBUy9CLGVBQWUwTSxPQUFPM0ssS0FBSyxDQUFDLEtBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdLO0FBQUEsWUFDeEssdUJBQUMsU0FBTSxlQUFlLE9BQU8sUUFBUXRDLE9BQU80QyxpQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxXQUFRLGdCQUFnQixDQUFBTixVQUFTL0IsZUFBZTBNLE9BQU8zSyxLQUFLLENBQUMsR0FBRyxjQUFjLEVBQUU0SyxZQUFZbE4sT0FBT21OLFFBQVF0RSxPQUFPN0ksT0FBT29OLGFBQWEzRSxhQUFhekksT0FBTytNLGlCQUFpQixLQUE1SztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SztBQUFBLFlBQzlLLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBTztBQUFBLFlBQ1AsdUJBQUMsT0FBSSxTQUFRLHlCQUF3QixNQUFLLHFCQUFvQixNQUFNL00sT0FBT3FOLFFBQVEsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxZQUN4Ryx1QkFBQyxPQUFJLFNBQVEsNEJBQTJCLE1BQUssaUJBQWdCLE1BQU1yTixPQUFPNEMsZUFBZSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RztBQUFBLGVBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUW5FLEtBUm1CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUVIsSUFBeUIsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixJQUFJdkIsU0FBUzBHLE9BQU91RixpQkFBaUIsNERBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9ILEtBVDVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsT0FBTSw4QkFBNkIsTUFBTXRDLEVBQUU4QixTQUFTLElBQUksUUFBUSxDQUFBUyxVQUFTQSxNQUFNekksVUFBVSxPQUFNLDZDQUE0QyxTQUFTO0FBQUEsWUFDM0osRUFBRU0sS0FBSyxTQUFTdUUsT0FBTyxlQUFlQyxRQUFRQSxDQUFBMkQsVUFBUyxHQUFHaE4sZUFBZWdOLE1BQU16SSxRQUFRLENBQUMsTUFBTXZFLGVBQWVnTixNQUFNdkksTUFBTSxDQUFDLEdBQUc7QUFBQSxZQUM3SCxFQUFFSSxLQUFLLFNBQVN1RSxPQUFPLFlBQVlHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTJELFVBQVNBLE1BQU1sQixzQkFBc0I7QUFBQSxZQUNoRyxFQUFFakgsS0FBSyxXQUFXdUUsT0FBTyxpQkFBaUJHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTJELFVBQVNBLE1BQU1qQix5QkFBeUI7QUFBQSxZQUMxRyxFQUFFbEgsS0FBSyxhQUFhdUUsT0FBTyxnQkFBZ0JHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTJELFVBQVMsdUJBQUMsVUFBTyxPQUFPQSxNQUFNZixrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0MsRUFBSTtBQUFBLFlBQ3BILEVBQUVwSCxLQUFLLFVBQVV1RSxPQUFPLGVBQWVHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQTJELFVBQVMsdUJBQUMsVUFBTyxPQUFPQSxNQUFNaEIsZUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUMsRUFBSTtBQUFBLFVBQUMsS0FMbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNRTtBQUFBLGFBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sT0FBTSw0QkFBMkIsVUFBUyxxQ0FDN0MsaUNBQUMsT0FBSSxlQUFZLDhCQUE2QixJQUFJbEwsU0FBUzBHLE9BQU95RixrQkFDOUQsaUNBQUMsU0FBTSxXQUFVLE1BQUssZUFBWSwyQkFBMEIsSUFBSSxDQUFDLEVBQUV4QyxHQUFHLEdBQUd5QyxHQUFHLEVBQUUsR0FBR3BNLFNBQVMwRyxPQUFPMkYsaUJBQWlCck0sU0FBUzBHLE9BQU80RixXQUFXLEdBQ3hJM0MsWUFBRTRDLGFBQWE1RixTQUFTZ0QsRUFBRTRDLGFBQWE5RixJQUFJLENBQUMrRixVQUFVbkUsVUFBVSx1QkFBQyxjQUFXLFdBQVUsTUFBbUNtRSxzQkFBekIsR0FBR25FLEtBQUssSUFBSW1FLFFBQVEsSUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRSxDQUFhLElBQUksdUJBQUMsY0FBVyxXQUFVLE1BQUssT0FBTSxrQkFBaUIsMERBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEYsS0FEcFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE9BQU0sd0JBQXVCLFVBQVMsOENBQ3pDO0FBQUEsaUNBQUMsT0FBSSxNQUFLLE9BQU0sY0FBWSxpQ0FBaUM3QyxFQUFFOEMsZ0JBQWdCOUYsTUFBTSxTQUFTLGVBQVksd0JBQXVCLElBQUksQ0FBQyxFQUFFNEUsUUFBUSxJQUFJLEdBQUd2TCxTQUFTMEcsT0FBTzhFLGtCQUFrQixHQUNwTDdCLFlBQUU4QyxnQkFBZ0I5RixTQUFTLHVCQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUFPLGlDQUFDLFlBQVMsTUFBTWdELEVBQUU4QyxpQkFBaUIsb0JBQWtCLE1BQzdIO0FBQUEsbUNBQUMsaUJBQWMsUUFBUTlOLE9BQU8rTSxrQkFBa0IsVUFBVSxTQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFLHVCQUFDLFNBQU0sU0FBUSxVQUFTLFFBQVEvTSxPQUFPNEMsZUFBZSxVQUFVLEdBQUcsUUFBUSxJQUFJLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0IsS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkc7QUFBQSxZQUM3Ryx1QkFBQyxTQUFNLGVBQWUsT0FBTyxRQUFRNUMsT0FBTzRDLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFdBQVEsY0FBYyxFQUFFc0ssWUFBWWxOLE9BQU9tTixRQUFRdEUsT0FBTzdJLE9BQU9vTixhQUFhM0UsYUFBYXpJLE9BQU8rTSxpQkFBaUIsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxZQUN0SCx1QkFBQyxPQUFJLFNBQVEsU0FBUSxNQUFLLGlCQUFnQixNQUFNL00sT0FBT3FOLFFBQVEsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTTVFLEtBTjRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTWpCLElBQXlCLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSWhNLFNBQVMwRyxPQUFPdUYsaUJBQWlCLG1EQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRyxLQVBuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLE1BQU10QyxFQUFFOEMsaUJBQWlCLFFBQVEsQ0FBQUMsV0FBVUEsT0FBT0EsUUFBUSxPQUFNLHdCQUF1QixPQUFNLDJDQUEwQyxTQUFTO0FBQUEsWUFDdkosRUFBRTNJLEtBQUssVUFBVXVFLE9BQU8sU0FBU0MsUUFBUUEsQ0FBQW1FLFdBQVVBLE9BQU9BLE9BQU87QUFBQSxZQUNqRSxFQUFFM0ksS0FBSyxTQUFTdUUsT0FBTyxpQkFBaUJHLE9BQU8sU0FBU0YsUUFBUUEsQ0FBQW1FLFdBQVVBLE9BQU9DLE1BQU07QUFBQSxVQUFDLEtBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0U7QUFBQSxhQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxNQUNBLHVCQUFDLFNBQU0sVUFBUyxRQUFPLElBQUkzTSxTQUFTNkksS0FBSytELGVBQWUsaUpBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUw7QUFBQSxTQXZEK0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdENU4sS0F4RG9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RGhLO0FBQUEsT0F4RUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlFUDtBQUNKO0FBQUM1RCxJQS9IZUQsZUFBYTtBQUFBLFVBQ1JoSyxVQUNXdEIsaUJBWWZvQixNQUFNO0FBQUE7QUFBQSxNQWRQa0s7QUFpSWhCLFNBQVNRLG9CQUFvQjlGLFVBQWtCRSxRQUFnQjZGLFFBQWdCcUQsY0FBNEY7QUFDdkssTUFBSSxDQUFDLENBQUMsT0FBTyxRQUFRLE9BQU8sRUFBRTlILFNBQVN5RSxNQUFNLEVBQUcsUUFBTyxFQUFFaUIsT0FBTyxVQUFVOUUsU0FBUyxtQ0FBbUM7QUFDdEgsTUFBSWtILGdCQUFnQixDQUFDcEosWUFBWSxDQUFDRSxPQUFRLFFBQU87QUFDakQsTUFBSSxDQUFDeEUsZ0JBQWdCc0UsUUFBUSxFQUFHLFFBQU8sRUFBRWdILE9BQU8sWUFBWTlFLFNBQVMsNEJBQTRCO0FBQ2pHLE1BQUksQ0FBQ3hHLGdCQUFnQndFLE1BQU0sRUFBRyxRQUFPLEVBQUU4RyxPQUFPLFVBQVU5RSxTQUFTLDZCQUE2QjtBQUM5RixNQUFJbEMsV0FBV0UsT0FBUSxRQUFPLEVBQUU4RyxPQUFPLFlBQVk5RSxTQUFTLG1EQUFtRDtBQUMvRyxRQUFNbUgsT0FBT3pMLEtBQUswTCxPQUFPQyxLQUFLQyxNQUFNLEdBQUd0SixNQUFNLGdCQUFnQixJQUFJcUosS0FBS0MsTUFBTSxHQUFHeEosUUFBUSxnQkFBZ0IsTUFBTSxLQUFLLEtBQUssS0FBSyxJQUFLLElBQUk7QUFDckksTUFBSXFKLE9BQU8sSUFBSyxRQUFPLEVBQUVyQyxPQUFPLFVBQVU5RSxTQUFTLCtDQUErQztBQUNsRyxTQUFPO0FBQ1g7QUFBQyxJQUFBL0QsSUFBQXNMLEtBQUFDO0FBQUEsYUFBQXZMLElBQUE7QUFBQSxhQUFBc0wsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJBY3Rpb25Hcm91cCIsIkZvcm1GaWVsZHMiLCJQYWdlU2VjdGlvbnMiLCJTZWN0aW9uR3JpZCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInZpc3VhbFN4IiwidXNlU2VhcmNoUGFyYW1zIiwiQWxlcnQiLCJCb3giLCJCdXR0b24iLCJMaW5rIiwiTWVudUl0ZW0iLCJTdGFjayIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJCYXIiLCJCYXJDaGFydCIsIkNhcnRlc2lhbkdyaWQiLCJMZWdlbmQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiVGV4dCIsIlRvb2x0aXAiLCJYQXhpcyIsIllBeGlzIiwiY29sb3JzIiwidG9rZW5zIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlQ2FuIiwiZGF0ZVRpbWUiLCJmb3JtYXREYXRlT25seSIsImlzVmFsaWREYXRlT25seSIsIkFtb3VudCIsIkRhdGFUYWJsZSIsIkRldGFpbExpbmUiLCJFcnJvck5vdGljZSIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIlBhZ2VyIiwiUXVlcnlTdGF0ZSIsIlJvdXRlTGluayIsIlN0YXQiLCJTdGF0cyIsIlN0YXR1cyIsImxheW91dFN4IiwiYXV0aG9yaXplZERvd25sb2FkSHJlZiIsImRhdGVJblRpbWV6b25lIiwicmVwb3J0RGF0ZUJvdW5kYXJ5IiwicmVwb3J0RmlsZW5hbWUiLCJyZXBvcnRMYWJlbHMiLCJpbnZlbnRvcnkiLCJvcmRlcnMiLCJjYXNoZmxvdyIsInByb2ZpdF9sb3NzIiwic291cmNlUGVybWlzc2lvbnMiLCJNYXJrZXRpbmdSZWFzb25UaWNrIiwieCIsInkiLCJ3aWR0aCIsInZpc2libGVUaWNrc0NvdW50IiwicGF5bG9hZCIsInZhbHVlIiwidHJpbSIsImNhdGVnb3J5TGFiZWxJbnNldCIsImxhYmVsV2lkdGgiLCJNYXRoIiwibWF4IiwidGV4dFNlY29uZGFyeSIsImZvbnRTaXplIiwiZm9udFNpemVzIiwiYm9keSIsImZvbnRGYW1pbHkiLCJfYyIsIlJlcG9ydHNQYWdlIiwiX3MiLCJzaG9wIiwicGFyYW1zIiwic2V0UGFyYW1zIiwibGF0ZXN0UGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwicGVuZGluZ1NlYXJjaCIsImNvbW1pdHRlZFNlYXJjaCIsInRvU3RyaW5nIiwiY3VycmVudCIsInN1bW1hcnkiLCJjYW5SZWFkSm9icyIsImpvYnMiLCJxdWVyeSIsImxpbWl0IiwiY3Vyc29yIiwiZ2V0IiwidW5kZWZpbmVkIiwicnVuIiwicmVxdWVzdGVkVHlwZSIsInR5cGUiLCJzbmFwc2hvdEFzT2YiLCJkYXRhIiwiYXNPZiIsImRlZmF1bHRSYW5nZSIsImN1cnJlbnREYXRlIiwidGltZXpvbmUiLCJmcm9tRGF0ZSIsInNsaWNlIiwidG9EYXRlIiwiZnJvbVZhbHVlIiwidG9WYWx1ZSIsInJlYWRSZXBvcnREYXRlIiwia2V5IiwiaGFzIiwiZnJvbSIsInRvIiwic2V0UmVwb3J0UGFyYW0iLCJuZXh0Iiwic2V0IiwiZmx1c2hTeW5jIiwicmFuZ2VFcnJvciIsInNldFJhbmdlRXJyb3IiLCJsYXN0RXhwb3J0Iiwic2V0TGFzdEV4cG9ydCIsImNhbkV4cG9ydFJlcG9ydHMiLCJjYW5FeHBvcnRTb3VyY2UiLCJhdmFpbGFibGVSZXBvcnRzIiwicmVwb3J0QXZhaWxhYmxlIiwiaW5jbHVkZXMiLCJjaGFuZ2VkIiwicmVwbGFjZSIsInN1Ym1pdCIsIlJhbmdlRXJyb3IiLCJyZXF1ZXN0IiwicmVwb3J0VHlwZSIsImZvcm1hdCIsInJlc3BvbnNlIiwiZXhlY3V0ZSIsImpvYiIsImVycm9yIiwibWVzc2FnZSIsImhhbmRsZUV4cG9ydCIsImxhc3REb3dubG9hZCIsInN0YXR1cyIsImRvd25sb2FkVXJsIiwibG9jYXRpb24iLCJvcmlnaW4iLCJfX01PQ0tfXyIsInhzIiwieGwiLCJtaW5XaWR0aCIsIm1heFdpZHRoIiwiZXZlbnQiLCJ0YXJnZXQiLCJtYXAiLCJyZXBvcnQiLCJsZW5ndGgiLCJzbSIsImlucHV0TGFiZWwiLCJzaHJpbmsiLCJwZW5kaW5nIiwiaWQiLCJhY3Rpb25zIiwibGlua1RhcmdldCIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYm9yZGVyUmFkaXVzIiwicmFkaXVzIiwiY29udHJvbCIsImNvbG9yIiwiZm9udFdlaWdodCIsInR5cG9ncmFwaHkiLCJzZW1pYm9sZCIsImJnY29sb3IiLCJ0ZXh0RGVjb3JhdGlvbiIsIm91dGxpbmUiLCJmb2N1c1JpbmciLCJvdXRsaW5lQ29sb3IiLCJvdXRsaW5lT2Zmc2V0IiwiY29udHJvbE9mZnNldCIsIndhcm5pbmdzIiwid2FybmluZyIsImluZGV4IiwibGFiZWwiLCJyZW5kZXIiLCJraW5kIiwiYWxpZ24iLCJjb21wbGV0ZWQiLCJ0b3RhbCIsInVwZGF0ZWRBdCIsInBhZ2UiLCJjb250ZXh0R2FwIiwiTWFya2V0aW5nUGFnZSIsIl9zMiIsInNlYXJjaCIsImZyb21QYXJhbSIsInRvUGFyYW0iLCJidWNrZXRQYXJhbSIsImhhc0RhdGVGaWx0ZXIiLCJhcHBsaWVkRXJyb3IiLCJtYXJrZXRpbmdSYW5nZUVycm9yIiwiYnVja2V0IiwiT2JqZWN0Iiwia2V5cyIsIm0iLCJtYXJrZXRpbmdQZXJpb2QiLCJwZXJpb2QiLCJkcmFmdCIsInNldERyYWZ0Iiwic2hvd0ZpbHRlckVycm9yIiwic2V0U2hvd0ZpbHRlckVycm9yIiwiZnJvbVJlZiIsInRvUmVmIiwiYnVja2V0UmVmIiwiZHJhZnRFcnJvciIsInZpc2libGVGaWx0ZXJFcnJvciIsImFwcGx5RmlsdGVyIiwicHJldmVudERlZmF1bHQiLCJmaWVsZCIsImZvY3VzIiwibm90aWNlIiwiYWZ0ZXJHYXAiLCJtZCIsInRvb2xiYXIiLCJjb250cm9sR2FwIiwia25vd25BdHRyaWJ1dGVkT3JkZXJzIiwidW5rbm93bkF0dHJpYnV0aW9uT3JkZXJzIiwiYWN0dWFsU3BlbmQiLCJlc3RpbWF0ZWRTcGVuZCIsInNlY3Rpb25BZnRlciIsIm5hbWUiLCJsZyIsImhlaWdodCIsImNoYXJ0Vmlld3BvcnRJbnNldCIsInRyZW5kIiwiYm9yZGVyRGVjb3JhdGl2ZSIsImNlaWwiLCJTdHJpbmciLCJiYWNrZ3JvdW5kIiwicmFpc2VkIiwidGV4dFByaW1hcnkiLCJhY2NlbnQiLCJlbXB0eVN0YXRlSW5zZXQiLCJwb2ludCIsImxpc3RTdXJmYWNlSW5zZXQiLCJwIiwibGlzdE1hcmtlckluc2V0IiwibGlzdEl0ZW1HYXAiLCJ0b3BRdWVzdGlvbnMiLCJxdWVzdGlvbiIsImxvc3RTYWxlUmVhc29ucyIsInJlYXNvbiIsImNvdW50Iiwic2VjdGlvbkJlZm9yZSIsImFsbG93RGVmYXVsdCIsImRheXMiLCJmbG9vciIsIkRhdGUiLCJwYXJzZSIsIl9jMiIsIl9jMyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU2VjdGlvbkdyaWQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBGb3JtRXZlbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB2aXN1YWxTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL3Zpc3VhbCc7XG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEFsZXJ0LCBCb3gsIEJ1dHRvbiwgTGluaywgTWVudUl0ZW0sIFN0YWNrLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCB7IEJhciwgQmFyQ2hhcnQsIENhcnRlc2lhbkdyaWQsIExlZ2VuZCwgUmVzcG9uc2l2ZUNvbnRhaW5lciwgVGV4dCwgVG9vbHRpcCwgWEF4aXMsIFlBeGlzIH0gZnJvbSAncmVjaGFydHMnO1xuaW1wb3J0IHR5cGUgeyBFeHBvcnRSZXF1ZXN0LCBKb2IsIE1hcmtldGluZ0J1Y2tldCB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgY29sb3JzLCB0b2tlbnMgfSBmcm9tICdAYm90c2FsZXMvdG9rZW5zJztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJy4uLy4uL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlU2NvcGUsIHVzZUNhbiB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9zY29wZSc7XG5pbXBvcnQgeyBkYXRlVGltZSwgZm9ybWF0RGF0ZU9ubHksIGlzVmFsaWREYXRlT25seSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgQW1vdW50LCBEYXRhVGFibGUsIERldGFpbExpbmUsIEVycm9yTm90aWNlLCBQYWdlSGVhZGVyLCBQYW5lbCwgUGFnZXIsIFF1ZXJ5U3RhdGUsIFJvdXRlTGluaywgU3RhdCwgU3RhdHMsIFN0YXR1cyB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb25lbnRzJztcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2xheW91dCc7XG5pbXBvcnQgeyBhdXRob3JpemVkRG93bmxvYWRIcmVmLCBkYXRlSW5UaW1lem9uZSwgcmVwb3J0RGF0ZUJvdW5kYXJ5LCByZXBvcnRGaWxlbmFtZSB9IGZyb20gJy4vcmVwb3J0LXV0aWxzJztcblxuY29uc3QgcmVwb3J0TGFiZWxzOiBSZWNvcmQ8RXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddLCBzdHJpbmc+ID0ge1xuICAgIGludmVudG9yeTogJ1Thu5NuIGtobycsIG9yZGVyczogJ8SQxqFuIGjDoG5nJywgY2FzaGZsb3c6ICdEw7JuZyB0aeG7gW4nLCBwcm9maXRfbG9zczogJ0zhu6NpIG5odeG6rW4nLFxufTtcbmNvbnN0IHNvdXJjZVBlcm1pc3Npb25zOiBSZWNvcmQ8RXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddLCBzdHJpbmc+ID0ge1xuICAgIGludmVudG9yeTogJ2ludmVudG9yeS5yZWFkJywgb3JkZXJzOiAnb3JkZXJzLnJlYWQnLCBjYXNoZmxvdzogJ2ZpbmFuY2UucmVhZCcsIHByb2ZpdF9sb3NzOiAnZmluYW5jZS5yZWFkJyxcbn07XG5cbmZ1bmN0aW9uIE1hcmtldGluZ1JlYXNvblRpY2soeyB4ID0gMCwgeSA9IDAsIHdpZHRoID0gMCwgdmlzaWJsZVRpY2tzQ291bnQgPSAxLCBwYXlsb2FkIH06IHsgeD86IG51bWJlcjsgeT86IG51bWJlcjsgd2lkdGg/OiBudW1iZXI7IHZpc2libGVUaWNrc0NvdW50PzogbnVtYmVyOyBwYXlsb2FkPzogeyB2YWx1ZT86IHVua25vd24gfSB9KSB7XG4gICAgY29uc3QgdmFsdWUgPSB0eXBlb2YgcGF5bG9hZD8udmFsdWUgPT09ICdzdHJpbmcnID8gcGF5bG9hZC52YWx1ZS50cmltKCkgOiAnJztcbiAgICBjb25zdCBjYXRlZ29yeUxhYmVsSW5zZXQgPSA4O1xuICAgIGNvbnN0IGxhYmVsV2lkdGggPSBNYXRoLm1heCgxLCB3aWR0aCAvIE1hdGgubWF4KDEsIHZpc2libGVUaWNrc0NvdW50KSAtIGNhdGVnb3J5TGFiZWxJbnNldCk7XG4gICAgcmV0dXJuIDxUZXh0IHg9e3h9IHk9e3l9IGR5PXsxMn0gd2lkdGg9e2xhYmVsV2lkdGh9IGJyZWFrQWxsIHZlcnRpY2FsQW5jaG9yPVwic3RhcnRcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCIgZmlsbD17Y29sb3JzLnRleHRTZWNvbmRhcnl9XG4gICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiB0b2tlbnMuZm9udFNpemVzLmJvZHksIGZvbnRGYW1pbHk6IHRva2Vucy5mb250RmFtaWx5IH19Pnt2YWx1ZX08L1RleHQ+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUmVwb3J0c1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBsYXRlc3RQYXJhbXMgPSB1c2VSZWYobmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpKTtcbiAgICBjb25zdCBwZW5kaW5nU2VhcmNoID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbW1pdHRlZFNlYXJjaCA9IHBhcmFtcy50b1N0cmluZygpO1xuICAgICAgICBpZiAocGVuZGluZ1NlYXJjaC5jdXJyZW50ICE9PSBudWxsICYmIHBlbmRpbmdTZWFyY2guY3VycmVudCAhPT0gY29tbWl0dGVkU2VhcmNoKSByZXR1cm47XG4gICAgICAgIGxhdGVzdFBhcmFtcy5jdXJyZW50ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMpO1xuICAgICAgICBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgPSBudWxsO1xuICAgIH0sIFtwYXJhbXNdKTtcbiAgICBjb25zdCBzdW1tYXJ5ID0gdXNlQXBpKCdnZXRSZXBvcnRTdW1tYXJ5Jyk7XG4gICAgY29uc3QgY2FuUmVhZEpvYnMgPSB1c2VDYW4oJ2pvYnMucmVhZCcpO1xuICAgIGNvbnN0IGpvYnMgPSB1c2VBcGkoJ2xpc3RKb2JzJywgeyBxdWVyeTogeyBsaW1pdDogMTAsIGN1cnNvcjogcGFyYW1zLmdldCgnY3Vyc29yJykgfHwgdW5kZWZpbmVkIH0gfSwgY2FuUmVhZEpvYnMpO1xuICAgIGNvbnN0IHJ1biA9IHVzZUNvbW1hbmQoJ2NyZWF0ZUV4cG9ydCcsIFsnbGlzdEpvYnMnXSk7XG4gICAgY29uc3QgcmVxdWVzdGVkVHlwZSA9IHBhcmFtcy5nZXQoJ3JlcG9ydFR5cGUnKTtcbiAgICBjb25zdCB0eXBlOiBFeHBvcnRSZXF1ZXN0WydyZXBvcnRUeXBlJ10gPSByZXF1ZXN0ZWRUeXBlID09PSAnaW52ZW50b3J5JyB8fCByZXF1ZXN0ZWRUeXBlID09PSAnY2FzaGZsb3cnIHx8IHJlcXVlc3RlZFR5cGUgPT09ICdwcm9maXRfbG9zcycgPyByZXF1ZXN0ZWRUeXBlIDogJ29yZGVycyc7XG4gICAgY29uc3Qgc25hcHNob3RBc09mID0gc3VtbWFyeS5kYXRhPy5kYXRhLmFzT2Y7XG4gICAgY29uc3QgZGVmYXVsdFJhbmdlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICghc25hcHNob3RBc09mKSByZXR1cm4gbnVsbDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREYXRlID0gZGF0ZUluVGltZXpvbmUoc25hcHNob3RBc09mLCBzaG9wLnRpbWV6b25lKTtcbiAgICAgICAgICAgIHJldHVybiB7IGZyb21EYXRlOiBgJHtjdXJyZW50RGF0ZS5zbGljZSgwLCA3KX0tMDFgLCB0b0RhdGU6IGN1cnJlbnREYXRlIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxuICAgIH0sIFtzaG9wLnRpbWV6b25lLCBzbmFwc2hvdEFzT2ZdKTtcbiAgICBjb25zdCBmcm9tVmFsdWUgPSBwYXJhbXMuZ2V0KCdmcm9tRGF0ZScpO1xuICAgIGNvbnN0IHRvVmFsdWUgPSBwYXJhbXMuZ2V0KCd0b0RhdGUnKTtcbiAgICBjb25zdCByZWFkUmVwb3J0RGF0ZSA9IChrZXk6ICdmcm9tRGF0ZScgfCAndG9EYXRlJywgdmFsdWU6IHN0cmluZyB8IG51bGwpID0+IHtcbiAgICAgICAgaWYgKGlzVmFsaWREYXRlT25seSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcbiAgICAgICAgaWYgKHBhcmFtcy5oYXMoa2V5KSAmJiB2YWx1ZSA9PT0gJycpIHJldHVybiAnJztcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRSYW5nZT8uW2tleV0gfHwgJyc7XG4gICAgfTtcbiAgICBjb25zdCBmcm9tID0gcmVhZFJlcG9ydERhdGUoJ2Zyb21EYXRlJywgZnJvbVZhbHVlKTtcbiAgICBjb25zdCB0byA9IHJlYWRSZXBvcnREYXRlKCd0b0RhdGUnLCB0b1ZhbHVlKTtcbiAgICBjb25zdCBzZXRSZXBvcnRQYXJhbSA9IChrZXk6ICdyZXBvcnRUeXBlJyB8ICdmcm9tRGF0ZScgfCAndG9EYXRlJywgdmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsYXRlc3RQYXJhbXMuY3VycmVudCk7XG4gICAgICAgIGlmIChrZXkgPT09ICdyZXBvcnRUeXBlJykgbmV4dC5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICAgIGVsc2UgbmV4dC5zZXQoa2V5LCBpc1ZhbGlkRGF0ZU9ubHkodmFsdWUpID8gdmFsdWUgOiAnJyk7XG4gICAgICAgIGxhdGVzdFBhcmFtcy5jdXJyZW50ID0gbmV4dDtcbiAgICAgICAgcGVuZGluZ1NlYXJjaC5jdXJyZW50ID0gbmV4dC50b1N0cmluZygpO1xuICAgICAgICBzZXRQYXJhbXMobmV4dCwgeyBmbHVzaFN5bmM6IHRydWUgfSk7XG4gICAgfTtcbiAgICBjb25zdCBbcmFuZ2VFcnJvciwgc2V0UmFuZ2VFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2xhc3RFeHBvcnQsIHNldExhc3RFeHBvcnRdID0gdXNlU3RhdGU8eyBqb2I6IEpvYjsgdHlwZTogRXhwb3J0UmVxdWVzdFsncmVwb3J0VHlwZSddOyBmcm9tOiBzdHJpbmc7IHRvOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGNhbkV4cG9ydFJlcG9ydHMgPSB1c2VDYW4oJ3JlcG9ydHMuZXhwb3J0Jyk7XG4gICAgY29uc3QgY2FuRXhwb3J0U291cmNlID0gdXNlQ2FuKHNvdXJjZVBlcm1pc3Npb25zW3R5cGVdKTtcbiAgICBjb25zdCBhdmFpbGFibGVSZXBvcnRzID0gc3VtbWFyeS5kYXRhPy5kYXRhLmF2YWlsYWJsZVJlcG9ydHMgfHwgW107XG4gICAgY29uc3QgcmVwb3J0QXZhaWxhYmxlID0gYXZhaWxhYmxlUmVwb3J0cy5pbmNsdWRlcyh0eXBlKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghc25hcHNob3RBc09mKSByZXR1cm47XG4gICAgICAgIGlmICghZGVmYXVsdFJhbmdlKSB7XG4gICAgICAgICAgICBzZXRSYW5nZUVycm9yKCdNw7ppIGdp4budIGPhu61hIGjDoG5nIGhv4bq3YyBt4buRYyB0aOG7nWkgZ2lhbiBiw6FvIGPDoW8ga2jDtG5nIGjhu6NwIGzhu4cuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxhdGVzdFBhcmFtcy5jdXJyZW50KTtcbiAgICAgICAgICAgIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gICAgICAgICAgICBpZiAocmVxdWVzdGVkVHlwZSAhPT0gJ2ludmVudG9yeScgJiYgcmVxdWVzdGVkVHlwZSAhPT0gJ2Nhc2hmbG93JyAmJiByZXF1ZXN0ZWRUeXBlICE9PSAncHJvZml0X2xvc3MnICYmIHJlcXVlc3RlZFR5cGUgIT09ICdvcmRlcnMnKSB7XG4gICAgICAgICAgICAgICAgbmV4dC5zZXQoJ3JlcG9ydFR5cGUnLCAnb3JkZXJzJyk7XG4gICAgICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXBhcmFtcy5oYXMoJ2Zyb21EYXRlJykgfHwgKGZyb21WYWx1ZSAmJiAhaXNWYWxpZERhdGVPbmx5KGZyb21WYWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgbmV4dC5zZXQoJ2Zyb21EYXRlJywgZGVmYXVsdFJhbmdlLmZyb21EYXRlKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFyYW1zLmhhcygndG9EYXRlJykgfHwgKHRvVmFsdWUgJiYgIWlzVmFsaWREYXRlT25seSh0b1ZhbHVlKSkpIHtcbiAgICAgICAgICAgICAgICBuZXh0LnNldCgndG9EYXRlJywgZGVmYXVsdFJhbmdlLnRvRGF0ZSk7XG4gICAgICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2hhbmdlZCkge1xuICAgICAgICAgICAgICAgIGxhdGVzdFBhcmFtcy5jdXJyZW50ID0gbmV4dDtcbiAgICAgICAgICAgICAgICBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgPSBuZXh0LnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgc2V0UGFyYW1zKG5leHQsIHsgcmVwbGFjZTogdHJ1ZSwgZmx1c2hTeW5jOiB0cnVlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHsgc2V0UmFuZ2VFcnJvcignTcO6aSBnaeG7nSBj4butYSBow6BuZyBob+G6t2MgbeG7kWMgdGjhu51pIGdpYW4gYsOhbyBjw6FvIGtow7RuZyBo4bujcCBs4buHLicpOyB9XG4gICAgfSwgW2RlZmF1bHRSYW5nZSwgcGFyYW1zLCByZXF1ZXN0ZWRUeXBlLCBmcm9tVmFsdWUsIHRvVmFsdWUsIHNldFBhcmFtcywgc25hcHNob3RBc09mXSk7XG5cbiAgICBjb25zdCBzdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHNldFJhbmdlRXJyb3IoJycpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKCFzbmFwc2hvdEFzT2YgfHwgIWZyb20gfHwgIXRvKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignQ2jGsGEgY8OzIHNuYXBzaG90IGhv4bq3YyBraG/huqNuZyBuZ8OgeSDEkeG6p3kgxJHhu6cuJyk7XG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgIHJlcG9ydFR5cGU6IHR5cGUsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiAnY3N2JyxcbiAgICAgICAgICAgICAgICBmcm9tOiByZXBvcnREYXRlQm91bmRhcnkoZnJvbSwgJ3N0YXJ0Jywgc2hvcC50aW1lem9uZSksXG4gICAgICAgICAgICAgICAgdG86IHJlcG9ydERhdGVCb3VuZGFyeSh0bywgJ2VuZCcsIHNob3AudGltZXpvbmUpLFxuICAgICAgICAgICAgICAgIHRpbWV6b25lOiBzaG9wLnRpbWV6b25lLFxuICAgICAgICAgICAgICAgIHNuYXBzaG90QXNPZixcbiAgICAgICAgICAgIH0gc2F0aXNmaWVzIEV4cG9ydFJlcXVlc3Q7XG4gICAgICAgICAgICBzZXRMYXN0RXhwb3J0KG51bGwpO1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBydW4uZXhlY3V0ZSh7IGJvZHk6IHJlcXVlc3QgfSk7XG4gICAgICAgICAgICBzZXRMYXN0RXhwb3J0KHsgam9iOiByZXNwb25zZS5kYXRhLCB0eXBlLCBmcm9tLCB0byB9KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFJhbmdlRXJyb3IpIHNldFJhbmdlRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZUV4cG9ydCA9ICgpID0+IHsgdm9pZCBzdWJtaXQoKTsgfTtcblxuICAgIGNvbnN0IGxhc3REb3dubG9hZCA9IGxhc3RFeHBvcnQ/LmpvYi5zdGF0dXMgPT09ICdzdWNjZWVkZWQnICYmIGxhc3RFeHBvcnQuam9iLmRvd25sb2FkVXJsXG4gICAgICAgID8gYXV0aG9yaXplZERvd25sb2FkSHJlZihsYXN0RXhwb3J0LmpvYi5kb3dubG9hZFVybCwgbG9jYXRpb24ub3JpZ2luLCBfX01PQ0tfXylcbiAgICAgICAgOiBudWxsO1xuXG4gICAgcmV0dXJuIDw+XG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiQsOhbyBjw6FvICYgeHXhuqV0IGThu68gbGnhu4d1XCIgc3VidGl0bGU9XCJYdeG6pXQgc25hcHNob3QgZG8gQVBJIHThuqFvOyBz4buRIGxp4buHdSB04buVbmcgaOG7o3Aga2jDtG5nIMSRxrDhu6NjIHTDrW5oIHThu6sgbeG7mXQgdHJhbmcgZGFuaCBzw6FjaC5cIiAvPlxuICAgICAgICA8U2VjdGlvbkdyaWQgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLW1haW4tbGF5b3V0XCIgY29sdW1ucz17eyB4czogJ21pbm1heCgwLCAxZnIpJywgeGw6ICdtaW5tYXgoMCwgMS4yZnIpIG1pbm1heCgwLCAuOGZyKScgfX0gYWxpZ25JdGVtcz17J3N0YXJ0J30gZ2VvbWV0cnk9e3ttaW5XaWR0aDogMH19PlxuICAgICAgICAgICAgPFBhZ2VTZWN0aW9ucyBkYXRhLXRlc3RpZD1cInJlcG9ydHMtcGFnZS1zZWN0aW9uc1wiID5cbiAgICAgICAgICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17c3VtbWFyeX0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5LmRhdGEgJiYgPFBhbmVsIHRpdGxlPVwiVOG6oW8gdOG7h3AgYsOhbyBjw6FvXCIgc3VidGl0bGU9XCJOZ8OgeSDEkcaw4bujYyBoaeG7g3UgdGhlbyBtw7ppIGdp4budIGPhu61hIGjDoG5nIHbDoCBn4butaSB0aMOgbmggbeG7kWMgdGjhu51pIGdpYW4gcsO1IHLDoG5nLlwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtRmllbGRzIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1leHBvcnQtZm9ybS1sYXlvdXRcIiBnZW9tZXRyeT17e21heFdpZHRoOiA3NjB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e3J1bi5lcnJvcn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmFuZ2VFcnJvciAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPntyYW5nZUVycm9yfTwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJCw6FvIGPDoW9cIiBzZWxlY3QgdmFsdWU9e3R5cGV9IG9uQ2hhbmdlPXtldmVudCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT09ICdvcmRlcnMnIHx8IHZhbHVlID09PSAnaW52ZW50b3J5JyB8fCB2YWx1ZSA9PT0gJ2Nhc2hmbG93JyB8fCB2YWx1ZSA9PT0gJ3Byb2ZpdF9sb3NzJykgc2V0UmVwb3J0UGFyYW0oJ3JlcG9ydFR5cGUnLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldExhc3RFeHBvcnQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthdmFpbGFibGVSZXBvcnRzLm1hcChyZXBvcnQgPT4gPE1lbnVJdGVtIHZhbHVlPXtyZXBvcnR9IGtleT17cmVwb3J0fT57cmVwb3J0TGFiZWxzW3JlcG9ydF19PC9NZW51SXRlbT4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthdmFpbGFibGVSZXBvcnRzLmxlbmd0aCA9PT0gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VmFpIHRyw7IgaGnhu4duIHThuqFpIGNoxrBhIGPDsyBsb+G6oWkgYsOhbyBjw6FvIGto4bqjIGThu6VuZy48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcyBkYXRhLXRlc3RpZD1cInJlcG9ydHMtZGF0ZS1maWx0ZXJzXCIgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19ID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlThu6sgbmfDoHlcIiB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmcm9tfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVwb3J0UGFyYW0oJ2Zyb21EYXRlJywgZXZlbnQudGFyZ2V0LnZhbHVlKX0gc2xvdFByb3BzPXt7IGlucHV0TGFiZWw6IHsgc2hyaW5rOiB0cnVlIH0gfX0gZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCLEkOG6v24gbmfDoHlcIiB0eXBlPVwiZGF0ZVwiIHZhbHVlPXt0b30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJlcG9ydFBhcmFtKCd0b0RhdGUnLCBldmVudC50YXJnZXQudmFsdWUpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBmdWxsV2lkdGggLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJNw7ppIGdp4budXCI+e3Nob3AudGltZXpvbmV9PC9EZXRhaWxMaW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiU25hcHNob3QgQVBJXCI+e3NuYXBzaG90QXNPZiA/IGRhdGVUaW1lKHNuYXBzaG90QXNPZiwgc2hvcC50aW1lem9uZSkgOiAnQ2jGsGEgY8OzIHNuYXBzaG90J308L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFjYW5FeHBvcnRSZXBvcnRzICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5WYWkgdHLDsiBoaeG7h24gdOG6oWkga2jDtG5nIGPDsyBxdXnhu4FuIHJlcG9ydHMuZXhwb3J0LjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5FeHBvcnRSZXBvcnRzICYmICFjYW5FeHBvcnRTb3VyY2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlF1eeG7gW4geHXhuqV0IGtow7RuZyB0aGF5IHRo4bq/IHF1eeG7gW4gxJHhu41jIG5ndeG7k24ge3NvdXJjZVBlcm1pc3Npb25zW3R5cGVdfTsgbG/huqFpIGLDoW8gY8OhbyBuw6B5IGNoxrBhIHRo4buDIHh14bqldC48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FuRXhwb3J0UmVwb3J0cyAmJiBjYW5FeHBvcnRTb3VyY2UgJiYgIXJlcG9ydEF2YWlsYWJsZSAmJiBhdmFpbGFibGVSZXBvcnRzLmxlbmd0aCA+IDAgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPkFQSSBraMO0bmcgbGnhu4d0IGvDqiBsb+G6oWkgYsOhbyBjw6FvIG7DoHkgY2hvIHZhaSB0csOyIGhp4buHbiB04bqhaS48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXtoYW5kbGVFeHBvcnR9IGRpc2FibGVkPXshY2FuRXhwb3J0UmVwb3J0cyB8fCAhY2FuRXhwb3J0U291cmNlIHx8ICFyZXBvcnRBdmFpbGFibGUgfHwgIXNuYXBzaG90QXNPZiB8fCAhZnJvbSB8fCAhdG8gfHwgZnJvbSA+IHRvIHx8IHJ1bi5wZW5kaW5nfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3J1bi5wZW5kaW5nID8gJ8SQYW5nIHThuqFvIHNuYXBzaG904oCmJyA6ICdU4bqhbyB04buHcCBiw6FvIGPDoW8gQ1NWJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFzdEV4cG9ydCAmJiA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19ICBhbGlnbkl0ZW1zPXt7IHhzOiAnc3RyZXRjaCcsIHNtOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2xhc3RFeHBvcnQuam9iLmlkfWB9PlRoZW8gZMO1aSBjw7RuZyB2aeG7h2Mge2xhc3RFeHBvcnQuam9iLmlkfTwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFzdERvd25sb2FkICYmIDxMaW5rIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1leHBvcnQtZG93bmxvYWRcIiBjb21wb25lbnQ9XCJhXCIgaHJlZj17bGFzdERvd25sb2FkfSBkb3dubG9hZD17cmVwb3J0RmlsZW5hbWUobGFzdEV4cG9ydC50eXBlLCBsYXN0RXhwb3J0LmZyb20sIGxhc3RFeHBvcnQudG8pfSB1bmRlcmxpbmU9XCJub25lXCIgc3g9e1tsYXlvdXRTeC5hY3Rpb25zLmxpbmtUYXJnZXQsIHsgYm9yZGVyOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInLCBib3JkZXJSYWRpdXM6IHZpc3VhbFN4LnJhZGl1cy5jb250cm9sLCBjb2xvcjogJ3RleHQucHJpbWFyeScsIGZvbnRXZWlnaHQ6IHZpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zZW1pYm9sZCwgJyY6aG92ZXInOiB7IGJnY29sb3I6ICdhY3Rpb24uaG92ZXInLCB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH0sICcmOmZvY3VzLXZpc2libGUnOiB7IG91dGxpbmU6IGAke3Rva2Vucy5mb2N1c1Jpbmcud2lkdGh9cHggc29saWRgLCBvdXRsaW5lQ29sb3I6ICdwcmltYXJ5LmxpZ2h0Jywgb3V0bGluZU9mZnNldDogdG9rZW5zLmZvY3VzUmluZy5jb250cm9sT2Zmc2V0IH0gfV19PlThuqNpIENTVjwvTGluaz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RXhwb3J0LmpvYi5zdGF0dXMgIT09ICdzdWNjZWVkZWQnICYmIDxBbGVydCBzZXZlcml0eT17bGFzdEV4cG9ydC5qb2Iuc3RhdHVzID09PSAncGFydGlhbCcgfHwgbGFzdEV4cG9ydC5qb2Iuc3RhdHVzID09PSAnZmFpbGVkJyA/ICd3YXJuaW5nJyA6ICdpbmZvJ30+VOG7h3AgY2jhu4kgxJHGsOG7o2MgdOG6o2kga2hpIGPDtG5nIHZp4buHYyB4w6FjIG5o4bqtbiBzdWNjZWVkZWQuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RXhwb3J0LmpvYi5zdGF0dXMgPT09ICdzdWNjZWVkZWQnICYmIGxhc3RFeHBvcnQuam9iLmRvd25sb2FkVXJsICYmICFsYXN0RG93bmxvYWQgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlVSTCB04bqjaSBraMO0bmcgaOG7o3AgbOG7hyBob+G6t2MgY2jGsGEgdGh14buZYyBIVFRQUy9uZ3Xhu5NuIGhp4buHbiB04bqhaS48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0FjdGlvbkdyb3VwPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VtbWFyeS5kYXRhLmRhdGEud2FybmluZ3MubWFwKCh3YXJuaW5nLCBpbmRleCkgPT4gPEFsZXJ0IGtleT17YCR7aW5kZXh9LSR7d2FybmluZ31gfSBzZXZlcml0eT1cImluZm9cIj57d2FybmluZ308L0FsZXJ0Pil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkFQSSBoaeG7h24gY2jhu4kgdHLhuqMgZGFuaCBzw6FjaCBsb+G6oWkgYsOhbyBjw6FvIHbDoCB0aOG7nWkgxJFp4buDbSBzbmFwc2hvdDsgYuG7mSBs4buNYyBuZ8OgeSDDoXAgZOG7pW5nIGNobyBs4buHbmggeHXhuqV0LiBLaMO0bmcgY8OzIHNlcmllcyBob+G6t2MgdOG7lW5nIHPhu5EgbGnhu4d1IMSR4buDIGdpYW8gZGnhu4duIHThu7Egc3V5IHJhLjwvQWxlcnQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgICAgICAgICAgICAgICAgIDwvUGFuZWw+fVxuICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cbiAgICAgICAgICAgICAgICB7Y2FuUmVhZEpvYnMgPyA8UXVlcnlTdGF0ZSBxdWVyeT17am9ic30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgIHtqb2JzLmRhdGEgJiYgPFBhbmVsIHRpdGxlPVwiQ8O0bmcgdmnhu4djIGfhuqduIMSRw6J5XCIgc3VidGl0bGU9XCJUcuG6oW5nIHRow6FpIHbDoCB0aeG6v24gxJHhu5kgbOG6pXkgdOG7qyBBUEk7IHRyYW5nIGhp4buHbiB04bqhaSBjw7MgdGjhu4MgY2jhu6lhIG5oaeG7gXUgbG/huqFpIGPDtG5nIHZp4buHYy5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgcm93cz17am9icy5kYXRhLmRhdGF9IHJvd0tleT17am9iID0+IGpvYi5pZH0gbGFiZWw9XCJDw7RuZyB2aeG7h2MgZ+G6p24gxJHDonlcIiBlbXB0eT1cIkNoxrBhIGPDsyBjw7RuZyB2aeG7h2MgdHJvbmcgdHJhbmcgbsOgeS5cIiBjb2x1bW5zPXtbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnTcOjIGPDtG5nIHZp4buHYycsIHJlbmRlcjogam9iID0+IDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2pvYnMvJHtqb2IuaWR9YH0+e2pvYi5pZH08L1JvdXRlTGluaz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2tpbmQnLCBsYWJlbDogJ0xv4bqhaScsIHJlbmRlcjogam9iID0+IDxTdGF0dXMgdmFsdWU9e2pvYi5raW5kfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnc3RhdHVzJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBqb2IgPT4gPFN0YXR1cyB2YWx1ZT17am9iLnN0YXR1c30gLz4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3Byb2dyZXNzJywgbGFiZWw6ICdUaeG6v24gxJHhu5knLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBqb2IgPT4gYCR7am9iLmNvbXBsZXRlZH0gLyAke2pvYi50b3RhbCA/PyAnQ2jGsGEgYmnhur90J31gIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICd1cGRhdGVkQXQnLCBsYWJlbDogJ0Phuq1wIG5o4bqtdCcsIHJlbmRlcjogam9iID0+IGRhdGVUaW1lKGpvYi51cGRhdGVkQXQsIHNob3AudGltZXpvbmUpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2VyIHBhZ2U9e2pvYnMuZGF0YS5wYWdlfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L1BhbmVsPn1cbiAgICAgICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+IDogPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBraMO0bmcgY8OzIGpvYnMucmVhZDsgdHLhuqFuZyB0aMOhaSBjw7RuZyB2aeG7h2MgxJHGsOG7o2Mg4bqpbiB0aGVvIHF1eeG7gW4uPC9BbGVydD59XG4gICAgICAgICAgICA8L1BhZ2VTZWN0aW9ucz5cbiAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIlBo4bqhbSB2aSBk4buvIGxp4buHdVwiIHN1YnRpdGxlPVwiQ2jhu4kgbmjhu69uZyBnw6wgQVBJIGN1bmcgY+G6pXAgbeG7m2kgxJHGsOG7o2MgdHLDrG5oIGLDoHkgbmjGsCBz4buRIGxp4buHdS5cIiBib2R5TW9kZT1cImluc2V0XCI+XG4gICAgICAgICAgICAgICAgPFN0YWNrIHN4PXtsYXlvdXRTeC5yZXBvcnQuY29udGV4dEdhcH0+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5Cw6FvIGPDoW8gZMOybmcsIGJp4buDdSDEkeG7kyB2w6AgdOG7lW5nIGjhu6NwIHRoZW8ga2hv4bqjbmcgbmfDoHkgY2jGsGEgY8OzIHRyb25nIGdldFJlcG9ydFN1bW1hcnkuIEZyb250ZW5kIGtow7RuZyBj4buZbmcgZOG7ryBsaeG7h3UgcGjDom4gdHJhbmcgxJHhu4MgdOG6oW8gS1BJIHRoYXkgdGjhur8uPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+VHLhuqFuZyB0aMOhaSBleHBvcnQgxJHGsOG7o2MgbOG6pXkgcmnDqm5nIHThu6sgbGlzdEpvYnM7IFVSTCB04bqjaSBjaOG7iSDEkcaw4bujYyBt4bufIHNhdSBraGkgQVBJIHRy4bqjIHbhu4EgY8O0bmcgdmnhu4djIGhvw6BuIHThuqV0LjwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vcmVwb3J0cy9tYXJrZXRpbmdgfT5YZW0gdGjDtG5nIHRpbiBtYXJrZXRpbmc8L1JvdXRlTGluaz5cbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgPC9TZWN0aW9uR3JpZD5cbiAgICA8Lz47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBNYXJrZXRpbmdQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBbcGFyYW1zLCBzZXRQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gICAgY29uc3Qgc2VhcmNoID0gcGFyYW1zLnRvU3RyaW5nKCk7XG4gICAgY29uc3QgZnJvbVBhcmFtID0gcGFyYW1zLmdldCgnZnJvbURhdGUnKSB8fCAnJztcbiAgICBjb25zdCB0b1BhcmFtID0gcGFyYW1zLmdldCgndG9EYXRlJykgfHwgJyc7XG4gICAgY29uc3QgYnVja2V0UGFyYW0gPSBwYXJhbXMuZ2V0KCdidWNrZXQnKSB8fCAnZGF5JztcbiAgICBjb25zdCBoYXNEYXRlRmlsdGVyID0gcGFyYW1zLmhhcygnZnJvbURhdGUnKSB8fCBwYXJhbXMuaGFzKCd0b0RhdGUnKTtcbiAgICBjb25zdCBhcHBsaWVkRXJyb3IgPSBtYXJrZXRpbmdSYW5nZUVycm9yKGZyb21QYXJhbSwgdG9QYXJhbSwgYnVja2V0UGFyYW0sICFoYXNEYXRlRmlsdGVyKTtcbiAgICBjb25zdCBxdWVyeSA9IGFwcGxpZWRFcnJvciA/IHVuZGVmaW5lZCA6IHtcbiAgICAgICAgLi4uKHBhcmFtcy5oYXMoJ2Zyb21EYXRlJykgPyB7IGZyb21EYXRlOiBmcm9tUGFyYW0gfSA6IHt9KSxcbiAgICAgICAgLi4uKHBhcmFtcy5oYXMoJ3RvRGF0ZScpID8geyB0b0RhdGU6IHRvUGFyYW0gfSA6IHt9KSxcbiAgICAgICAgLi4uKHBhcmFtcy5oYXMoJ2J1Y2tldCcpID8geyBidWNrZXQ6IGJ1Y2tldFBhcmFtIGFzIE1hcmtldGluZ0J1Y2tldCB9IDoge30pLFxuICAgIH07XG4gICAgY29uc3QgZGF0YSA9IHVzZUFwaSgnZ2V0TWFya2V0aW5nU3VtbWFyeScsIHF1ZXJ5ICYmIE9iamVjdC5rZXlzKHF1ZXJ5KS5sZW5ndGggPyB7IHF1ZXJ5IH0gOiB1bmRlZmluZWQsICFhcHBsaWVkRXJyb3IpO1xuICAgIGNvbnN0IG0gPSBkYXRhLmRhdGE/LmRhdGE7XG4gICAgY29uc3QgbWFya2V0aW5nUGVyaW9kID0gbT8ucGVyaW9kO1xuICAgIGNvbnN0IFtkcmFmdCwgc2V0RHJhZnRdID0gdXNlU3RhdGUoeyBmcm9tRGF0ZTogZnJvbVBhcmFtLCB0b0RhdGU6IHRvUGFyYW0sIGJ1Y2tldDogYnVja2V0UGFyYW0gfSk7XG4gICAgY29uc3QgW3Nob3dGaWx0ZXJFcnJvciwgc2V0U2hvd0ZpbHRlckVycm9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBmcm9tUmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IHRvUmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGJ1Y2tldFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBkcmFmdEVycm9yID0gbWFya2V0aW5nUmFuZ2VFcnJvcihkcmFmdC5mcm9tRGF0ZSwgZHJhZnQudG9EYXRlLCBkcmFmdC5idWNrZXQsIGZhbHNlKTtcbiAgICBjb25zdCB2aXNpYmxlRmlsdGVyRXJyb3IgPSBzaG93RmlsdGVyRXJyb3IgPyBkcmFmdEVycm9yIDogYXBwbGllZEVycm9yO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1hcmtldGluZ1BlcmlvZCkge1xuICAgICAgICAgICAgc2V0RHJhZnQoeyBmcm9tRGF0ZTogbWFya2V0aW5nUGVyaW9kLmZyb21EYXRlLCB0b0RhdGU6IG1hcmtldGluZ1BlcmlvZC50b0RhdGUsIGJ1Y2tldDogbWFya2V0aW5nUGVyaW9kLmJ1Y2tldCB9KTtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHsgZnJvbURhdGU6IG1hcmtldGluZ1BlcmlvZC5mcm9tRGF0ZSwgdG9EYXRlOiBtYXJrZXRpbmdQZXJpb2QudG9EYXRlLCBidWNrZXQ6IG1hcmtldGluZ1BlcmlvZC5idWNrZXQgfSk7XG4gICAgICAgICAgICBpZiAobmV4dC50b1N0cmluZygpICE9PSBzZWFyY2gpIHNldFBhcmFtcyhuZXh0LCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbbWFya2V0aW5nUGVyaW9kLCBzZWFyY2gsIHNldFBhcmFtc10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgY3VycmVudCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoc2VhcmNoKTtcbiAgICAgICAgaWYgKCFjdXJyZW50LmhhcygnZnJvbURhdGUnKSAmJiAhY3VycmVudC5oYXMoJ3RvRGF0ZScpKSByZXR1cm47XG4gICAgICAgIHNldERyYWZ0KHsgZnJvbURhdGU6IGN1cnJlbnQuZ2V0KCdmcm9tRGF0ZScpIHx8ICcnLCB0b0RhdGU6IGN1cnJlbnQuZ2V0KCd0b0RhdGUnKSB8fCAnJywgYnVja2V0OiBjdXJyZW50LmdldCgnYnVja2V0JykgfHwgJ2RheScgfSk7XG4gICAgICAgIHNldFNob3dGaWx0ZXJFcnJvcihmYWxzZSk7XG4gICAgfSwgW3NlYXJjaF0pO1xuXG4gICAgY29uc3QgYXBwbHlGaWx0ZXIgPSAoZXZlbnQ6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldFNob3dGaWx0ZXJFcnJvcih0cnVlKTtcbiAgICAgICAgaWYgKGRyYWZ0RXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGRyYWZ0RXJyb3IuZmllbGQgPT09ICdmcm9tRGF0ZScgPyBmcm9tUmVmLmN1cnJlbnQgOiBkcmFmdEVycm9yLmZpZWxkID09PSAndG9EYXRlJyA/IHRvUmVmLmN1cnJlbnQgOiBidWNrZXRSZWYuY3VycmVudDtcbiAgICAgICAgICAgIHRhcmdldD8uZm9jdXMoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7IGZyb21EYXRlOiBkcmFmdC5mcm9tRGF0ZSwgdG9EYXRlOiBkcmFmdC50b0RhdGUsIGJ1Y2tldDogZHJhZnQuYnVja2V0IH0pO1xuICAgICAgICBzZXRTaG93RmlsdGVyRXJyb3IoZmFsc2UpO1xuICAgICAgICBzZXRQYXJhbXMobmV4dCk7XG4gICAgfTtcblxuICAgIHJldHVybiA8PlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIlRow7RuZyB0aW4gY2hvIG1hcmtldGluZ1wiIHN1YnRpdGxlPVwixJDhu4EgeHXhuqV0IGNo4buJIMSR4buNYzsgdHJhbmcga2jDtG5nIHThu7EgxJHEg25nIG7hu5lpIGR1bmcgaG/hurdjIHRoYXkgxJHhu5VpIG5nw6JuIHPDoWNoLlwiIC8+XG4gICAgICAgIHtfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+U+G7kSBsaeG7h3UgbeG6q3UgZG8gQVBJIG3DtCBwaOG7j25nIHThu5VuZyBo4bujcDsgY2jGsGEga+G6v3QgbuG7kWkgdMOgaSBraG/huqNuIHF14bqjbmcgY8OhbyBob+G6t2Mgbmd14buTbiBwaMOibiBi4buVIHRo4bqtdC48L0FsZXJ0Pn1cbiAgICAgICAgPFBhbmVsIHRpdGxlPVwiS2hv4bqjbmcgdGjhu51pIGdpYW4gYsOhbyBjw6FvXCIgc3VidGl0bGU9e2BOZ8OgeSDEkcaw4bujYyB0w61uaCB0aGVvIGzhu4tjaCAke3Nob3AudGltZXpvbmV9IGPhu6dhIGPhu61hIGjDoG5nLmB9IGJvZHlNb2RlPVwiaW5zZXRcIiBhZnRlckdhcD1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgIDxGb3JtRmllbGRzIGNvbXBvbmVudD1cImZvcm1cIiBvblN1Ym1pdD17YXBwbHlGaWx0ZXJ9IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXJhbmdlLWZvcm1cIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgbWQ6ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgbWQ6ICdmbGV4LWVuZCcgfX0gc3g9e2xheW91dFN4LnRvb2xiYXIuY29udHJvbEdhcH0+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e2Zyb21SZWZ9IHR5cGU9XCJkYXRlXCIgbGFiZWw9XCJU4burIG5nw6B5XCIgdmFsdWU9e2RyYWZ0LmZyb21EYXRlfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0RHJhZnQodmFsdWUgPT4gKHsgLi4udmFsdWUsIGZyb21EYXRlOiBldmVudC50YXJnZXQudmFsdWUgfSkpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBlcnJvcj17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ2Zyb21EYXRlJ30gaGVscGVyVGV4dD17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ2Zyb21EYXRlJyA/IHZpc2libGVGaWx0ZXJFcnJvci5tZXNzYWdlIDogJ05nw6B5IGLhuq90IMSR4bqndSwgdMOtbmggY+G6oyBuZ8OgeSDEkcOjIGNo4buNbi4nfSAvPlxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGlucHV0UmVmPXt0b1JlZn0gdHlwZT1cImRhdGVcIiBsYWJlbD1cIsSQ4bq/biBuZ8OgeVwiIHZhbHVlPXtkcmFmdC50b0RhdGV9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgdG9EYXRlOiBldmVudC50YXJnZXQudmFsdWUgfSkpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBlcnJvcj17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ3RvRGF0ZSd9IGhlbHBlclRleHQ9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICd0b0RhdGUnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnVOG7kWkgxJFhIDM2NiBuZ8OgeSwgdMOtbmggY+G6oyBoYWkgxJHhuqd1Lid9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e2J1Y2tldFJlZn0gc2VsZWN0IGxhYmVsPVwiR+G7mXAgdGhlb1wiIHZhbHVlPXtkcmFmdC5idWNrZXR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgYnVja2V0OiBldmVudC50YXJnZXQudmFsdWUgfSkpfSBlcnJvcj17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ2J1Y2tldCd9IGhlbHBlclRleHQ9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICdidWNrZXQnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnQ2jhu41uIG5nw6B5LCB0deG6p24gaG/hurdjIHRow6FuZy4nfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cImRheVwiPk5nw6B5PC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJ3ZWVrXCI+VHXhuqduPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJtb250aFwiPlRow6FuZzwvTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwiY29udGFpbmVkXCI+w4FwIGThu6VuZzwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAge3Nob3dGaWx0ZXJFcnJvciAmJiBkcmFmdEVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2RyYWZ0RXJyb3IubWVzc2FnZX08L0FsZXJ0Pn1cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9QYW5lbD5cbiAgICAgICAge2FwcGxpZWRFcnJvciA/IDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+PHN0cm9uZz5C4buZIGzhu41jIHRyw6puIMSRxrDhu51uZyBk4bqrbiBraMO0bmcgaOG7o3AgbOG7hy48L3N0cm9uZz4gSMOjeSBz4butYSB0csaw4budbmcgxJHGsOG7o2MgxJHDoW5oIGThuqV1IHRyxrDhu5tjIGtoaSDDoXAgZOG7pW5nLjwvQWxlcnQ+IDogPFF1ZXJ5U3RhdGUgcXVlcnk9e2RhdGF9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPnttICYmIDw+XG4gICAgICAgICAgICA8U3RhdHM+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCLEkMahbiBjw7Mgbmd14buTbiB4w6FjIMSR4buLbmhcIiB2YWx1ZT17bS5rbm93bkF0dHJpYnV0ZWRPcmRlcnN9IG5vdGU9XCLEkMaw4bujYyBBUEkgdOG7lW5nIGjhu6NwIHRyb25nIGvhu7NcIiAvPlxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwixJDGoW4gY2jGsGEgcsO1IG5ndeG7k25cIiB2YWx1ZT17bS51bmtub3duQXR0cmlidXRpb25PcmRlcnN9IG5vdGU9XCJHaeG7ryByacOqbmcsIGtow7RuZyB04buxIGfDoW4gbmd14buTblwiIC8+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCJDaGkgcXXhuqNuZyBjw6FvIHRo4buxYyB04bq/XCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17bS5hY3R1YWxTcGVuZH0gLz59IG5vdGU9e20uYWN0dWFsU3BlbmQgPyAnQVBJIGN1bmcgY+G6pXAgc+G7kSB0aOG7sWMgdOG6vycgOiAnS+G7syBuw6B5IGNoxrBhIGPDsyBz4buRIHRo4buxYyB04bq/IHThu6sgQVBJJ30gLz5cbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkNoaSBxdeG6o25nIGPDoW8gxrDhu5tjIHTDrW5oXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17bS5lc3RpbWF0ZWRTcGVuZH0gLz59IG5vdGU9XCLGr+G7m2MgdMOtbmgga2jDtG5nIHBo4bqjaSBz4buRIGdoaSBz4buVXCIgLz5cbiAgICAgICAgICAgIDwvU3RhdHM+XG4gICAgICAgICAgICA8U3RhY2sgZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctYXMtb2ZcIiBzeD17W2xheW91dFN4LnJlcG9ydC5jb250ZXh0R2FwLCBsYXlvdXRTeC5wYWdlLnNlY3Rpb25BZnRlcl19PlxuICAgICAgICAgICAgICAgIHttLnBlcmlvZCAmJiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5L4buzIHtmb3JtYXREYXRlT25seShtLnBlcmlvZC5mcm9tRGF0ZSl9IOKAkyB7Zm9ybWF0RGF0ZU9ubHkobS5wZXJpb2QudG9EYXRlKX0gwrcgZ+G7mXAgdGhlbyB7bS5wZXJpb2QuYnVja2V0ID09PSAnZGF5JyA/ICduZ8OgeScgOiBtLnBlcmlvZC5idWNrZXQgPT09ICd3ZWVrJyA/ICd0deG6p24nIDogJ3Row6FuZyd9PC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5D4bqtcCBuaOG6rXQge2RhdGVUaW1lKG0uYXNPZiwgbS5wZXJpb2Q/LnRpbWV6b25lIHx8IHNob3AudGltZXpvbmUpfSDCtyB7c2hvcC5uYW1lfSDCtyBtw7ppIGdp4budIHttLnBlcmlvZD8udGltZXpvbmUgfHwgc2hvcC50aW1lem9uZX08L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPFNlY3Rpb25HcmlkIGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXNlY3Rpb25zLWdyaWRcIiBjb2x1bW5zPXt7IHhzOiAnMWZyJywgbGc6ICcxZnIgMWZyJyB9fT5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCLEkMahbiB0aGVvIHRo4budaSBnaWFuXCIgc3VidGl0bGU9XCJT4buRIMSRxqFuIGPDsyBuZ3Xhu5NuIHjDoWMgxJHhu4tuaCB2w6AgY2jGsGEgcsO1IG5ndeG7k24gZG8gQVBJIHThu5VuZyBo4bujcC5cIj5cbiAgICAgICAgICAgICAgICAgICAgPEJveCByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17YFPhu5EgxJHGoW4gdGhlbyAke20ucGVyaW9kPy5idWNrZXQgfHwgJ2vhu7MnfSB0cm9uZyBraG/huqNuZyDEkcOjIGNo4buNbmB9IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXRyZW5kLWNoYXJ0XCIgc3g9e1t7IGhlaWdodDogMjgwIH0sIGxheW91dFN4LnJlcG9ydC5jaGFydFZpZXdwb3J0SW5zZXRdfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttLnRyZW5kPy5sZW5ndGggPyA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+PEJhckNoYXJ0IGRhdGE9e20udHJlbmR9IGFjY2Vzc2liaWxpdHlMYXllcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2U9e2NvbG9ycy5ib3JkZXJEZWNvcmF0aXZlfSB2ZXJ0aWNhbD17ZmFsc2V9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJmcm9tRGF0ZVwiIHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IGludGVydmFsPXtNYXRoLm1heCgwLCBNYXRoLmNlaWwobS50cmVuZC5sZW5ndGggLyA3KSAtIDEpfSB0aWNrRm9ybWF0dGVyPXt2YWx1ZSA9PiBmb3JtYXREYXRlT25seShTdHJpbmcodmFsdWUpKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WUF4aXMgYWxsb3dEZWNpbWFscz17ZmFsc2V9IHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgbGFiZWxGb3JtYXR0ZXI9e3ZhbHVlID0+IGZvcm1hdERhdGVPbmx5KFN0cmluZyh2YWx1ZSkpfSBjb250ZW50U3R5bGU9e3sgYmFja2dyb3VuZDogY29sb3JzLnJhaXNlZCwgY29sb3I6IGNvbG9ycy50ZXh0UHJpbWFyeSwgYm9yZGVyQ29sb3I6IGNvbG9ycy5ib3JkZXJEZWNvcmF0aXZlIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImtub3duQXR0cmlidXRlZE9yZGVyc1wiIG5hbWU9XCJDw7Mgbmd14buTbiB4w6FjIMSR4buLbmhcIiBmaWxsPXtjb2xvcnMuYWNjZW50fSByYWRpdXM9e1szLCAzLCAwLCAwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJ1bmtub3duQXR0cmlidXRpb25PcmRlcnNcIiBuYW1lPVwiQ2jGsGEgcsO1IG5ndeG7k25cIiBmaWxsPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gcmFkaXVzPXtbMywgMywgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhckNoYXJ0PjwvUmVzcG9uc2l2ZUNvbnRhaW5lcj4gOiA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LnJlcG9ydC5lbXB0eVN0YXRlSW5zZXR9PkFQSSBjaMawYSBjw7MgYnVja2V0IGThu68gbGnhu4d1IHRyb25nIGvhu7MgxJHDoyBjaOG7jW4uPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJU4buVbmcgaOG7o3AgbWFya2V0aW5nIHRoZW8ga+G7s1wiIHJvd3M9e20udHJlbmQgfHwgW119IHJvd0tleT17cG9pbnQgPT4gcG9pbnQuZnJvbURhdGV9IGVtcHR5PVwiQ2jGsGEgY8OzIGThu68gbGnhu4d1IHRoZW8ga+G7syB0cm9uZyBraG/huqNuZyBuw6B5LlwiIGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncmFuZ2UnLCBsYWJlbDogJ0tob+G6o25nIG5nw6B5JywgcmVuZGVyOiBwb2ludCA9PiBgJHtmb3JtYXREYXRlT25seShwb2ludC5mcm9tRGF0ZSl9IOKAkyAke2Zvcm1hdERhdGVPbmx5KHBvaW50LnRvRGF0ZSl9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdrbm93bicsIGxhYmVsOiAnQ8OzIG5ndeG7k24nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiBwb2ludC5rbm93bkF0dHJpYnV0ZWRPcmRlcnMgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAndW5rbm93bicsIGxhYmVsOiAnQ2jGsGEgcsO1IG5ndeG7k24nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiBwb2ludC51bmtub3duQXR0cmlidXRpb25PcmRlcnMgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXN0aW1hdGVkJywgbGFiZWw6ICdDaGkgxrDhu5tjIHTDrW5oJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gPEFtb3VudCB2YWx1ZT17cG9pbnQuZXN0aW1hdGVkU3BlbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdHVhbCcsIGxhYmVsOiAnQ2hpIHRo4buxYyB04bq/JywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gPEFtb3VudCB2YWx1ZT17cG9pbnQuYWN0dWFsU3BlbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJDw6J1IGjhu49pIGtow6FjaCB0aMaw4budbmcgaOG7j2lcIiBzdWJ0aXRsZT1cIkPDoWMgbeG7pWMgZG8gQVBJIHThu5VuZyBo4bujcCBjdW5nIGPhuqVwLlwiPlxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXF1ZXN0aW9uLXN1cmZhY2VcIiBzeD17bGF5b3V0U3gucmVwb3J0Lmxpc3RTdXJmYWNlSW5zZXR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGNvbXBvbmVudD1cInVsXCIgZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctdG9wLXF1ZXN0aW9uc1wiIHN4PXtbeyBtOiAwLCBwOiAwIH0sIGxheW91dFN4LnJlcG9ydC5saXN0TWFya2VySW5zZXQsIGxheW91dFN4LnJlcG9ydC5saXN0SXRlbUdhcF19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttLnRvcFF1ZXN0aW9ucy5sZW5ndGggPyBtLnRvcFF1ZXN0aW9ucy5tYXAoKHF1ZXN0aW9uLCBpbmRleCkgPT4gPFR5cG9ncmFwaHkgY29tcG9uZW50PVwibGlcIiBrZXk9e2Ake2luZGV4fS0ke3F1ZXN0aW9ufWB9PntxdWVzdGlvbn08L1R5cG9ncmFwaHk+KSA6IDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImxpXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkNoxrBhIGPDsyB0aOG7kW5nIGvDqiBjw6J1IGjhu49pIHRyb25nIGvhu7MgxJHDoyBjaOG7jW4uPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiTMO9IGRvIGtow7RuZyBjaOG7kXQgxJHGoW5cIiBzdWJ0aXRsZT1cIkJp4buDdSDEkeG7kyB2w6AgYuG6o25nIGTDuW5nIGPDuW5nIG3hu5l0IHBheWxvYWQgQVBJLlwiPlxuICAgICAgICAgICAgICAgICAgICA8Qm94IHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPXtgQmnhu4N1IMSR4buTIGzDvSBkbyBraMO0bmcgY2jhu5F0IMSRxqFuLCAke20ubG9zdFNhbGVSZWFzb25zLmxlbmd0aH0gbmjDs21gfSBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1sb3NzLWNoYXJ0XCIgc3g9e1t7IGhlaWdodDogMjYwIH0sIGxheW91dFN4LnJlcG9ydC5jaGFydFZpZXdwb3J0SW5zZXRdfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttLmxvc3RTYWxlUmVhc29ucy5sZW5ndGggPyA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+PEJhckNoYXJ0IGRhdGE9e20ubG9zdFNhbGVSZWFzb25zfSBhY2Nlc3NpYmlsaXR5TGF5ZXI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlPXtjb2xvcnMuYm9yZGVyRGVjb3JhdGl2ZX0gdmVydGljYWw9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwicmVhc29uXCIgc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gaW50ZXJ2YWw9ezB9IGhlaWdodD17NjR9IHRpY2s9ezxNYXJrZXRpbmdSZWFzb25UaWNrIC8+fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBhbGxvd0RlY2ltYWxzPXtmYWxzZX0gc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50U3R5bGU9e3sgYmFja2dyb3VuZDogY29sb3JzLnJhaXNlZCwgY29sb3I6IGNvbG9ycy50ZXh0UHJpbWFyeSwgYm9yZGVyQ29sb3I6IGNvbG9ycy5ib3JkZXJEZWNvcmF0aXZlIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiY291bnRcIiBuYW1lPVwiU+G7kSB0csaw4budbmcgaOG7o3BcIiBmaWxsPXtjb2xvcnMuYWNjZW50fSByYWRpdXM9e1s0LCA0LCAwLCAwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+PC9SZXNwb25zaXZlQ29udGFpbmVyPiA6IDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17bGF5b3V0U3gucmVwb3J0LmVtcHR5U3RhdGVJbnNldH0+Q2jGsGEgY8OzIGzDvSBkbyBt4bqldCDEkcahbiB0cm9uZyBr4buzIG7DoHkuPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgcm93cz17bS5sb3N0U2FsZVJlYXNvbnN9IHJvd0tleT17cmVhc29uID0+IHJlYXNvbi5yZWFzb259IGxhYmVsPVwiTMO9IGRvIGtow7RuZyBjaOG7kXQgxJHGoW5cIiBlbXB0eT1cIkNoxrBhIGPDsyBsw70gZG8gbeG6pXQgxJHGoW4gdHJvbmcga+G7syDEkcOjIGNo4buNbi5cIiBjb2x1bW5zPXtbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiByZWFzb24gPT4gcmVhc29uLnJlYXNvbiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjb3VudCcsIGxhYmVsOiAnU+G7kSB0csaw4budbmcgaOG7o3AnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByZWFzb24gPT4gcmVhc29uLmNvdW50IH0sXG4gICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgIDwvU2VjdGlvbkdyaWQ+XG4gICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4LnBhZ2Uuc2VjdGlvbkJlZm9yZX0+S2jDtG5nIHThu7EgZ8OhbiBuZ3Xhu5NuIGNobyDEkcahbiB0aGnhur91IGThu68gbGnhu4d1LCBraMO0bmcgZ2hpIGNoaSDGsOG7m2MgdMOtbmggdGjDoG5oIGNoaSB0aOG7sWMgdOG6vyB2w6Aga2jDtG5nIHThu7EgxJHEg25nIG7hu5lpIGR1bmcgaG/hurdjIHTEg25nIG5nw6JuIHPDoWNoLjwvQWxlcnQ+XG4gICAgICAgIDwvPn08L1F1ZXJ5U3RhdGU+fVxuICAgIDwvPjtcbn1cblxuZnVuY3Rpb24gbWFya2V0aW5nUmFuZ2VFcnJvcihmcm9tRGF0ZTogc3RyaW5nLCB0b0RhdGU6IHN0cmluZywgYnVja2V0OiBzdHJpbmcsIGFsbG93RGVmYXVsdDogYm9vbGVhbik6IHsgZmllbGQ6ICdmcm9tRGF0ZScgfCAndG9EYXRlJyB8ICdidWNrZXQnOyBtZXNzYWdlOiBzdHJpbmcgfSB8IG51bGwge1xuICAgIGlmICghWydkYXknLCAnd2VlaycsICdtb250aCddLmluY2x1ZGVzKGJ1Y2tldCkpIHJldHVybiB7IGZpZWxkOiAnYnVja2V0JywgbWVzc2FnZTogJ0No4buNbiBuaMOzbSBuZ8OgeSwgdHXhuqduIGhv4bq3YyB0aMOhbmcuJyB9O1xuICAgIGlmIChhbGxvd0RlZmF1bHQgJiYgIWZyb21EYXRlICYmICF0b0RhdGUpIHJldHVybiBudWxsO1xuICAgIGlmICghaXNWYWxpZERhdGVPbmx5KGZyb21EYXRlKSkgcmV0dXJuIHsgZmllbGQ6ICdmcm9tRGF0ZScsIG1lc3NhZ2U6ICdOaOG6rXAgbmfDoHkgYuG6r3QgxJHhuqd1IGjhu6NwIGzhu4cuJyB9O1xuICAgIGlmICghaXNWYWxpZERhdGVPbmx5KHRvRGF0ZSkpIHJldHVybiB7IGZpZWxkOiAndG9EYXRlJywgbWVzc2FnZTogJ05o4bqtcCBuZ8OgeSBr4bq/dCB0aMO6YyBo4bujcCBs4buHLicgfTtcbiAgICBpZiAoZnJvbURhdGUgPiB0b0RhdGUpIHJldHVybiB7IGZpZWxkOiAnZnJvbURhdGUnLCBtZXNzYWdlOiAnTmfDoHkgYuG6r3QgxJHhuqd1IHBo4bqjaSB0csaw4bubYyBob+G6t2MgYuG6sW5nIG5nw6B5IGvhur90IHRow7pjLicgfTtcbiAgICBjb25zdCBkYXlzID0gTWF0aC5mbG9vcigoRGF0ZS5wYXJzZShgJHt0b0RhdGV9VDAwOjAwOjAwLjAwMFpgKSAtIERhdGUucGFyc2UoYCR7ZnJvbURhdGV9VDAwOjAwOjAwLjAwMFpgKSkgLyAoMjQgKiA2MCAqIDYwICogMTAwMCkpICsgMTtcbiAgICBpZiAoZGF5cyA+IDM2NikgcmV0dXJuIHsgZmllbGQ6ICd0b0RhdGUnLCBtZXNzYWdlOiAnS2hv4bqjbmcgYsOhbyBjw6FvIGtow7RuZyDEkcaw4bujYyB2xrDhu6N0IHF1w6EgMzY2IG5nw6B5LicgfTtcbiAgICByZXR1cm4gbnVsbDtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL3JlcG9ydHMvaW5kZXgudHN4In0=