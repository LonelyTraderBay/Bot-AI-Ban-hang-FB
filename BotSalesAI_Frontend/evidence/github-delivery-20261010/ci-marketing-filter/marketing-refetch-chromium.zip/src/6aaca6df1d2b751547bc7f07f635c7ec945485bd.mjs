import fs from 'node:fs';
import path from 'node:path';
import { chromium, firefox, expect } from '../../BotSalesAI_Frontend/node_modules/@playwright/test/index.mjs';
import { startDemoServer } from '../../BotSalesAI_Frontend/tests/session/demo-server.mjs';

const server = await startDemoServer({cacheIsolationKey:'marketing-canonical-probe'});
const output = import.meta.dirname;
let failures = 0;
try {
    for (const [name, engine] of Object.entries({chromium,firefox})) {
        const browser = await engine.launch();
        const context = await browser.newContext();
        await context.tracing.start({snapshots:true,screenshots:true,sources:true});
        const page = await context.newPage();
        const requests = [];
        page.on('request', request => {if(new URL(request.url()).pathname.endsWith('/marketing-summary')) requests.push(request.url());});
        await page.addInitScript(() => {
            const nativeFetch = window.fetch.bind(window);
            const gate = new Promise(resolve => {window.marketingProbeRelease = resolve;});
            window.fetch = async (...args) => {
                const raw = typeof args[0] === 'string' ? args[0] : args[0] instanceof URL ? args[0].href : args[0].url;
                const url = new URL(raw, location.href);
                const response = await nativeFetch(...args);
                if(url.pathname.endsWith('/marketing-summary') && url.searchParams.get('fromDate')==='2026-08-31') {
                    window.marketingProbePending = true;
                    await gate;
                }
                return response;
            };
        });
        await page.goto(server.url+'/s/shop-demo/reports/marketing');
        await page.waitForFunction(()=>window.marketingProbePending===true);
        const from = page.getByLabel('Từ ngày',{exact:true});
        const to = page.getByLabel('Đến ngày',{exact:true});
        await from.fill('2026-09-18');
        await to.fill('2026-09-24');
        await page.getByRole('combobox',{name:'Gộp theo'}).click();
        await page.getByRole('option',{name:'Tuần',exact:true}).click();
        const before={fromDate:await from.inputValue(),toDate:await to.inputValue(),bucket:await page.getByRole('combobox',{name:'Gộp theo'}).innerText()};
        await page.evaluate(()=>window.marketingProbeRelease());
        await expect(page.getByTestId('marketing-loss-chart')).toBeVisible();
        const after={fromDate:await from.inputValue(),toDate:await to.inputValue(),bucket:await page.getByRole('combobox',{name:'Gộp theo'}).innerText()};
        const preserved=JSON.stringify(before)===JSON.stringify(after);
        if(!preserved) failures++;
        const report={engine:name,sourceSha:'ca5d9d8a2bdfcf0464d669ed333786e4c90d810f',before,after,preserved,requests};
        fs.writeFileSync(path.join(output,'marketing-refetch-'+name+'.json'),JSON.stringify(report,null,2)+'\n');
        await page.screenshot({path:path.join(output,'marketing-refetch-'+name+'.png'),fullPage:true});
        await context.tracing.stop({path:path.join(output,'marketing-refetch-'+name+'.zip')});
        console.log(JSON.stringify(report));
        await browser.close();
    }
} finally {await server.close();}
process.exitCode=failures?1:0;
