import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/dashboard/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/react_jsx-dev-runtime.js?v=58ce4f3f"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { ActionGroup, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/react.js?v=58ce4f3f"; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Link as RouterLink } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/react-router-dom.js?v=f23023c7";
import { Alert, Avatar, Box, Button, Link, Stack, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_material.js?v=05f52198";
import ForumRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_icons-material_ForumRounded.js?v=b84e9834";
import ReceiptLongRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_icons-material_ReceiptLongRounded.js?v=3c41a75e";
import Inventory2Rounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_icons-material_Inventory2Rounded.js?v=ab33cf03";
import SmartToyRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_icons-material_SmartToyRounded.js?v=fa595c87";
import ArrowForwardRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-68104-cb3e5546-b44c-4bbf-b4ea-afdcd600eb61-dashboard-isolation-probe/deps/@mui_icons-material_ArrowForwardRounded.js?v=4df68bec";
import { colors, tokens } from "/@fs/C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime } from "/src/shared/model/format.ts";
import { Amount, ConfirmDialog, CopyableCode, DataTable, Empty, MutationButton, Panel, QueryState, RouteLink, Stat, Stats, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
const agentRoleNames = {
  sales_admin: "Admin bán hàng",
  accountant: "Kế toán",
  warehouse_buyer: "Kho & mua hàng",
  supervisor: "Trưởng nhóm"
};
export function dashboardGreetingName(displayName) {
  return displayName?.split(" · ")[0]?.trim() || "bạn";
}
export function dashboardAgentRoleLabel(kind) {
  return kind ? agentRoleNames[kind] || "Vai trò chưa có nhãn" : "Vai trò chưa có nhãn";
}
export function DashboardPage() {
  _s();
  const { shop, session } = useScope();
  const dashboard = useApi("getDashboard");
  const canFinance = useCan("finance.read");
  const canOps = useCan("operations.read");
  const operations = useApi("getOperationsSummary", {}, canOps);
  const canOrders = useCan("orders.read");
  const canCreateOrder = useCan("orders.write");
  const orders = useApi("listOrders", { query: { limit: 5 } }, canOrders);
  const canPauseBot = useCan("bot.publish");
  const bot = useApi("getBotConfig", {}, canPauseBot);
  const pause = useCommand("pauseBot", ["getDashboard", "getBotConfig"]);
  const [pauseOpen, setPauseOpen] = useState(false);
  const data = dashboard.data?.data;
  const botConfig = bot.data?.data;
  const greetingName = dashboardGreetingName(session.user.displayName);
  const primaryAction = canOps ? { label: "Xem việc cần làm", to: `/s/${shop.id}/operations` } : canOrders ? { label: "Xem đơn hàng", to: `/s/${shop.id}/orders` } : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.dashboard.groupInset, layoutSx.pageHeader.afterGap, { border: 1, borderColor: colors.heroBorder, borderRadius: visualSx.radius.hero, background: `linear-gradient(115deg, ${colors.heroStart}, ${colors.heroEnd})` }], children: /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", md: "row" }, justifyContent: "space-between", sx: layoutSx.dashboard.sectionGap, children: [
      /* @__PURE__ */ jsxDEV(Box, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "overline", sx: { letterSpacing: visualSx.typography.letterSpacing.dashboardOverline, color: "primary.main" }, children: "KHÔNG GIAN ĐIỀU HÀNH" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 76,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h3", sx: [layoutSx.dashboard.heroTitleFlow, { fontSize: visualSx.typography.dashboardTitle.fontSize, overflowWrap: "anywhere" }], children: [
          "Chào ",
          greetingName,
          ",",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 77,
            columnNumber: 206
          }, this),
          /* @__PURE__ */ jsxDEV(Box, { component: "span", color: "text.secondary", sx: { fontWeight: visualSx.typography.fontWeight.regular }, children: "cửa hàng của bạn hôm nay." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 77,
            columnNumber: 212
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 77,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: [layoutSx.dashboard.heroDescriptionGap, { maxWidth: 620 }], children: "Theo dõi việc cần xử lý, tiến độ đơn hàng và đội ngũ AI — tập trung vào những quyết định quan trọng." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 78,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 75,
        columnNumber: 17
      }, this),
      (canOps || canOrders || canCreateOrder) && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "column", density: "comfortable", justifyContent: "center", children: [
        primaryAction && /* @__PURE__ */ jsxDEV(Link, { component: RouterLink, to: primaryAction.to, underline: "none", sx: [layoutSx.dashboard.actionTarget, { display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: visualSx.radius.dialog, bgcolor: "primary.main", color: "primary.contrastText", fontWeight: visualSx.typography.fontWeight.strong, "&:hover": { bgcolor: "primary.light", textDecoration: "none" }, "&:active": { bgcolor: "primary.dark" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: [
          primaryAction.label,
          " ",
          /* @__PURE__ */ jsxDEV(ArrowForwardRounded, { fontSize: "small" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 81,
            columnNumber: 642
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 81,
          columnNumber: 39
        }, this),
        canCreateOrder && /* @__PURE__ */ jsxDEV(Link, { component: RouterLink, to: `/s/${shop.id}/orders/new`, underline: "none", sx: [layoutSx.dashboard.actionTarget, { display: "inline-flex", alignItems: "center", justifyContent: "center", border: 1, borderColor: "divider", borderRadius: visualSx.radius.dialog, color: "text.primary", fontWeight: visualSx.typography.fontWeight.strong, "&:hover": { bgcolor: "action.hover", textDecoration: "none" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: "Tạo đơn hàng" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 82,
          columnNumber: 40
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 80,
        columnNumber: 61
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 74,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 73,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Tình hình hiện tại", subtitle: "Các KPI là trạng thái hiện tại do API trả về, không phải dự báo.", afterGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: dashboard, pendingProfile: "section", children: data && /* @__PURE__ */ jsxDEV(Stats, { children: [
      /* @__PURE__ */ jsxDEV(Stat, { title: "Hội thoại đang mở", value: /* @__PURE__ */ jsxDEV(Link, { component: RouterLink, to: `/s/${shop.id}/inbox`, underline: "hover", color: "inherit", children: data.openConversations }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 90,
        columnNumber: 60
      }, this), note: "Trạng thái hiện tại", icon: /* @__PURE__ */ jsxDEV(ForumRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 90,
        columnNumber: 216
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 90,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn chờ xử lý", value: /* @__PURE__ */ jsxDEV(Link, { component: RouterLink, to: `/s/${shop.id}/orders`, underline: "hover", color: "inherit", children: data.pendingOrders }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 91,
        columnNumber: 56
      }, this), note: "Theo trạng thái hiện tại của API", icon: /* @__PURE__ */ jsxDEV(ReceiptLongRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 91,
        columnNumber: 222
      }, this), accent: true }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 91,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Sản phẩm gần hết", value: /* @__PURE__ */ jsxDEV(Link, { component: RouterLink, to: `/s/${shop.id}/inventory`, underline: "hover", color: "inherit", children: data.lowStockVariants }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 92,
        columnNumber: 59
      }, this), note: "Theo ngưỡng tồn trong API", icon: /* @__PURE__ */ jsxDEV(Inventory2Rounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 92,
        columnNumber: 224
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 92,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Trợ lý bán hàng", value: /* @__PURE__ */ jsxDEV(Status, { value: data.botStatus }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 93,
        columnNumber: 58
      }, this), note: "Trạng thái do API cung cấp", icon: /* @__PURE__ */ jsxDEV(SmartToyRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 93,
        columnNumber: 133
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 93,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 89,
      columnNumber: 26
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 88,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 87,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.dashboard.sectionGap, { display: "grid", gridTemplateColumns: { xs: "1fr", xl: "1.6fr 1fr" }, alignItems: "start" }], children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Dòng tiền và doanh thu", subtitle: "Doanh thu ghi nhận và tiền đã thu là hai chỉ số khác nhau.", bodyMode: "inset", children: canFinance ? data ? /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
        /* @__PURE__ */ jsxDEV(Box, { children: [
          /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", variant: "body2", children: "Doanh thu đã ghi nhận" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 102,
            columnNumber: 26
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", sx: layoutSx.dashboard.metricValueGap, children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: data.recognizedRevenue }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 102,
            columnNumber: 175
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 102,
            columnNumber: 111
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 102,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { children: [
          /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", variant: "body2", children: "Tiền đã thu" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 103,
            columnNumber: 26
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", sx: [layoutSx.dashboard.metricValueGap, { color: "primary.main" }], children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: data.cashReceived }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 103,
            columnNumber: 194
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 103,
            columnNumber: 101
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 103,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/profit-loss`, children: "Xem lợi nhuận" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 104,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 101,
        columnNumber: 38
      }, this) : dashboard.isPending ? /* @__PURE__ */ jsxDEV(Box, { role: "status", children: "Đang tải số liệu tài chính…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 105,
        columnNumber: 59
      }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", action: /* @__PURE__ */ jsxDEV(Button, { onClick: () => void dashboard.refetch(), children: "Thử lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 105,
        columnNumber: 148
      }, this), children: "Không thể tải số liệu tài chính. Dữ liệu của các khu vực khác vẫn dùng được." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 105,
        columnNumber: 114
      }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chỉ hiển thị khi vai trò có finance.read." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 100,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Đơn hàng gần đây", subtitle: "Mở đơn để xem trạng thái chuẩn bị, giao hàng và thanh toán.", action: canOrders ? /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders`, children: "Tất cả đơn" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 109,
        columnNumber: 136
      }, this) : void 0, bodyMode: canOrders ? "flush" : "inset", geometry: { gridColumn: { xs: "auto", xl: "1 / -1" } }, children: canOrders ? /* @__PURE__ */ jsxDEV(QueryState, { query: orders, pendingProfile: "section", children: orders.data && /* @__PURE__ */ jsxDEV(DataTable, { rows: orders.data.data, rowKey: (order) => order.id, label: "Đơn hàng gần đây", columns: [
        { key: "id", label: "Đơn hàng", render: (order) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", alignItems: "center", sx: layoutSx.code.inlineGap, flexWrap: "wrap", children: [
          /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/orders/${order.id}`, children: order.id }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 111,
            columnNumber: 150
          }, this),
          /* @__PURE__ */ jsxDEV(CopyableCode, { value: order.id, label: "mã đơn hàng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 111,
            columnNumber: 223
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 111,
          columnNumber: 62
        }, this) },
        { key: "total", label: "Giá trị", align: "right", render: (order) => /* @__PURE__ */ jsxDEV(Amount, { value: order.total }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 112,
          columnNumber: 80
        }, this) },
        { key: "status", label: "Đơn", render: (order) => /* @__PURE__ */ jsxDEV(Status, { value: order.orderState }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 113,
          columnNumber: 61
        }, this) },
        { key: "delivery", label: "Giao", render: (order) => /* @__PURE__ */ jsxDEV(Status, { value: order.fulfillmentState }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 114,
          columnNumber: 64
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 110,
        columnNumber: 98
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 110,
        columnNumber: 30
      }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có orders.read." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 115,
        columnNumber: 32
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 109,
        columnNumber: 13
      }, this),
      canOps && /* @__PURE__ */ jsxDEV(Panel, { title: "Đội ngũ AI của cửa hàng", subtitle: "Trạng thái vai trò lấy từ API; trạng thái kết nối bên ngoài chưa được xác minh.", action: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/bot/team`, children: "Quản lý đội ngũ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 118,
        columnNumber: 162
      }, this), bodyMode: "inset", geometry: { gridColumn: { xs: "auto", xl: "1 / -1" } }, children: /* @__PURE__ */ jsxDEV(QueryState, { query: operations, pendingProfile: "section", children: operations.data?.data.roles.length ? /* @__PURE__ */ jsxDEV(SectionGrid, { rhythm: "content", columns: { xs: "1fr", sm: "repeat(2,1fr)", lg: "repeat(4,1fr)" }, children: operations.data.data.roles.map((role, index) => /* @__PURE__ */ jsxDEV(SurfaceContent, { alignItems: "flex-start", bodyMode: "compactOutlined", children: [
        /* @__PURE__ */ jsxDEV(Avatar, { sx: { bgcolor: [colors.selected, colors.infoSurface, colors.successSurface, colors.violetSurface][index % 4], color: [colors.accent, colors.info, colors.success, colors.violet][index % 4] }, children: /* @__PURE__ */ jsxDEV(SmartToyRounded, {}, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 120,
          columnNumber: 220
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 120,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { children: [
          /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: dashboardAgentRoleLabel(role.kind) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 121,
            columnNumber: 26
          }, this),
          !agentRoleNames[role.kind] && role.kind && /* @__PURE__ */ jsxDEV(CopyableCode, { value: role.kind, label: "mã vai trò" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 121,
            columnNumber: 182
          }, this),
          !role.kind && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "API chưa cung cấp mã vai trò." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
            lineNumber: 121,
            columnNumber: 251
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 121,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Status, { value: role.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 122,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          role.allowedToolIds.length,
          " công cụ được giao"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 123,
          columnNumber: 21
        }, this)
      ] }, role.id, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 119,
        columnNumber: 256
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 119,
        columnNumber: 111
      }, this) : /* @__PURE__ */ jsxDEV(Empty, { text: "API chưa trả vai trò điều hành." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 124,
        columnNumber: 53
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 119,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 118,
        columnNumber: 24
      }, this),
      canPauseBot && /* @__PURE__ */ jsxDEV(Panel, { title: "Điều khiển trợ lý", subtitle: "Tạm dừng là thao tác có tác động; cần xác nhận và lý do.", bodyMode: "inset", geometry: { gridColumn: { xs: "auto", xl: "1 / -1" } }, children: /* @__PURE__ */ jsxDEV(QueryState, { query: bot, children: botConfig && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: { xs: "column", sm: "row" }, density: "comfortable", alignItems: { xs: "stretch", sm: "center" }, children: [
        /* @__PURE__ */ jsxDEV(Status, { value: botConfig.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 129,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.publish", variant: "outlined", color: "error", busy: pause.pending, disabled: botConfig.status === "paused", onClick: () => setPauseOpen(true), children: botConfig.status === "paused" ? "Bot đã tạm dừng" : "Tạm dừng bot" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 130,
          columnNumber: 21
        }, this),
        pause.error && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: pause.error.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
          lineNumber: 131,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 128,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 128,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 127,
        columnNumber: 29
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 98,
      columnNumber: 9
    }, this),
    data && /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.dashboard.footerFlow, children: [
      data.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: warning }, `${index}-${warning}`, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 137,
        columnNumber: 52
      }, this)),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: { display: "block" }, children: [
        "Dữ liệu cập nhật ",
        dateTime(data.asOf, shop.timezone),
        " · ",
        shop.name
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
        lineNumber: 138,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 136,
      columnNumber: 18
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: pauseOpen, title: "Tạm dừng trợ lý bán hàng", confirmLabel: "Tạm dừng trợ lý", description: `Trợ lý bán hàng ${botConfig?.id || ""} trong ${shop.name}: các tác động chưa gửi sẽ dừng. Tin nhắn nhà cung cấp đã nhận không thể thu hồi.`, requireReason: true, busy: pause.pending, error: pause.error, onClose: () => setPauseOpen(false), onConfirm: (reason) => pause.execute({ body: { expectedVersion: botConfig?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
}
_s(DashboardPage, "16nMVC2svStObCI45xAMcmvj97I=", false, function() {
  return [useScope, useApi, useCan, useCan, useApi, useCan, useCan, useApi, useCan, useApi, useCommand];
});
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/dashboard/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RXLG1CQUlTLGNBSlQ7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcERYLFNBQVNBLGFBQWFDLGFBQWFDLHNCQUFzQjtBQUN6RCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxPQUFPQyxRQUFRQyxLQUFLQyxRQUFRTCxNQUFNTSxPQUFPQyxrQkFBa0I7QUFDcEUsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHlCQUF5QjtBQUNoQyxTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxRQUFRQyxlQUFlQyxjQUFjQyxXQUFXQyxPQUFPQyxnQkFBZ0JDLE9BQU9DLFlBQVlDLFdBQVdDLE1BQU1DLE9BQU9DLGNBQWM7QUFDekksU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGlCQUF5QztBQUFBLEVBQzNDQyxhQUFhO0FBQUEsRUFDYkMsWUFBWTtBQUFBLEVBQ1pDLGlCQUFpQjtBQUFBLEVBQ2pCQyxZQUFZO0FBQ2hCO0FBRU8sZ0JBQVNDLHNCQUFzQkMsYUFBd0M7QUFDMUUsU0FBT0EsYUFBYUMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHQyxLQUFLLEtBQUs7QUFDbkQ7QUFFTyxnQkFBU0Msd0JBQXdCQyxNQUFpQztBQUNyRSxTQUFPQSxPQUFPVixlQUFlVSxJQUFJLEtBQUsseUJBQXlCO0FBQ25FO0FBRU8sZ0JBQVNDLGdCQUFnQjtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sRUFBRUMsTUFBTUMsUUFBUSxJQUFJOUIsU0FBUztBQUNuQyxRQUFNK0IsWUFBWWpDLE9BQU8sY0FBYztBQUN2QyxRQUFNa0MsYUFBYS9CLE9BQU8sY0FBYztBQUN4QyxRQUFNZ0MsU0FBU2hDLE9BQU8saUJBQWlCO0FBQ3ZDLFFBQU1pQyxhQUFhcEMsT0FBTyx3QkFBd0IsQ0FBQyxHQUFHbUMsTUFBTTtBQUM1RCxRQUFNRSxZQUFZbEMsT0FBTyxhQUFhO0FBQ3RDLFFBQU1tQyxpQkFBaUJuQyxPQUFPLGNBQWM7QUFDNUMsUUFBTW9DLFNBQVN2QyxPQUFPLGNBQWMsRUFBRXdDLE9BQU8sRUFBRUMsT0FBTyxFQUFFLEVBQUUsR0FBR0osU0FBUztBQUN0RSxRQUFNSyxjQUFjdkMsT0FBTyxhQUFhO0FBQ3hDLFFBQU13QyxNQUFNM0MsT0FBTyxnQkFBZ0IsQ0FBQyxHQUFHMEMsV0FBVztBQUNsRCxRQUFNRSxRQUFRM0MsV0FBVyxZQUFZLENBQUMsZ0JBQWdCLGNBQWMsQ0FBQztBQUNyRSxRQUFNLENBQUM0QyxXQUFXQyxZQUFZLElBQUkvRCxTQUFTLEtBQUs7QUFDaEQsUUFBTWdFLE9BQU9kLFVBQVVjLE1BQU1BO0FBQzdCLFFBQU1DLFlBQVlMLElBQUlJLE1BQU1BO0FBQzVCLFFBQU1FLGVBQWUxQixzQkFBc0JTLFFBQVFrQixLQUFLMUIsV0FBVztBQUNuRSxRQUFNMkIsZ0JBQWdCaEIsU0FDaEIsRUFBRWlCLE9BQU8sb0JBQW9CQyxJQUFJLE1BQU10QixLQUFLdUIsRUFBRSxjQUFjLElBQzVEakIsWUFBWSxFQUFFZSxPQUFPLGdCQUFnQkMsSUFBSSxNQUFNdEIsS0FBS3VCLEVBQUUsVUFBVSxJQUFJO0FBRTFFLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxPQUFJLElBQUksQ0FBQ3JDLFNBQVNnQixVQUFVc0IsWUFBWXRDLFNBQVN1QyxXQUFXQyxVQUFVLEVBQUVDLFFBQVEsR0FBR0MsYUFBYTdELE9BQU84RCxZQUFZQyxjQUFjN0UsU0FBUzhFLE9BQU9DLE1BQU1DLFlBQVksMkJBQTJCbEUsT0FBT21FLFNBQVMsS0FBS25FLE9BQU9vRSxPQUFPLElBQUksQ0FBQyxHQUNuTyxpQ0FBQyxTQUFNLFdBQVcsRUFBRUMsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxnQkFBZSxpQkFBZ0IsSUFBSW5ELFNBQVNnQixVQUFVb0MsWUFDakc7QUFBQSw2QkFBQyxPQUNHO0FBQUEsK0JBQUMsY0FBVyxTQUFRLFlBQVcsSUFBSSxFQUFFQyxlQUFldEYsU0FBU3VGLFdBQVdELGNBQWNFLG1CQUFtQkMsT0FBTyxlQUFlLEdBQUcsb0NBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0o7QUFBQSxRQUN0Six1QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssSUFBSSxDQUFDeEQsU0FBU2dCLFVBQVV5QyxlQUFlLEVBQUVDLFVBQVUzRixTQUFTdUYsV0FBV0ssZUFBZUQsVUFBVUUsY0FBYyxXQUFXLENBQUMsR0FBRztBQUFBO0FBQUEsVUFBTTVCO0FBQUFBLFVBQWE7QUFBQSxVQUFDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQUcsdUJBQUMsT0FBSSxXQUFVLFFBQU8sT0FBTSxrQkFBaUIsSUFBSSxFQUFFNkIsWUFBWTlGLFNBQVN1RixXQUFXTyxXQUFXQyxRQUFRLEdBQUcseUNBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtJO0FBQUEsYUFBalU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1VTtBQUFBLFFBQ3ZVLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSSxDQUFDOUQsU0FBU2dCLFVBQVUrQyxvQkFBb0IsRUFBRUMsVUFBVSxJQUFJLENBQUMsR0FBRyxvSEFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TTtBQUFBLFdBSDNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE9BQ0U5QyxVQUFVRSxhQUFhQyxtQkFBbUIsdUJBQUMsZUFBWSxXQUFVLFVBQVMsU0FBUSxlQUFjLGdCQUFlLFVBQzVHYTtBQUFBQSx5QkFBaUIsdUJBQUMsUUFBSyxXQUFXakUsWUFBWSxJQUFJaUUsY0FBY0UsSUFBSSxXQUFVLFFBQU8sSUFBSSxDQUFDcEMsU0FBU2dCLFVBQVVpRCxjQUFjLEVBQUVDLFNBQVMsZUFBZUMsWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVXhCLGNBQWM3RSxTQUFTOEUsT0FBT3dCLFFBQVFDLFNBQVMsZ0JBQWdCZCxPQUFPLHdCQUF3QkssWUFBWTlGLFNBQVN1RixXQUFXTyxXQUFXVSxRQUFRLFdBQVcsRUFBRUQsU0FBUyxpQkFBaUJFLGdCQUFnQixPQUFPLEdBQUcsWUFBWSxFQUFFRixTQUFTLGVBQWUsR0FBRyxtQkFBbUIsRUFBRUcsU0FBUyxHQUFHM0YsT0FBTzRGLFVBQVVDLEtBQUssWUFBWUMsY0FBYyxpQkFBaUJDLGVBQWUvRixPQUFPNEYsVUFBVUksY0FBYyxFQUFFLENBQUMsR0FBSTVDO0FBQUFBLHdCQUFjQztBQUFBQSxVQUFNO0FBQUEsVUFBQyx1QkFBQyx1QkFBb0IsVUFBUyxXQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLGFBQWhvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1vQjtBQUFBLFFBQ3BwQmQsa0JBQWtCLHVCQUFDLFFBQUssV0FBV3BELFlBQVksSUFBSSxNQUFNNkMsS0FBS3VCLEVBQUUsZUFBZSxXQUFVLFFBQU8sSUFBSSxDQUFDckMsU0FBU2dCLFVBQVVpRCxjQUFjLEVBQUVDLFNBQVMsZUFBZUMsWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVTNCLFFBQVEsR0FBR0MsYUFBYSxXQUFXRSxjQUFjN0UsU0FBUzhFLE9BQU93QixRQUFRYixPQUFPLGdCQUFnQkssWUFBWTlGLFNBQVN1RixXQUFXTyxXQUFXVSxRQUFRLFdBQVcsRUFBRUQsU0FBUyxnQkFBZ0JFLGdCQUFnQixPQUFPLEdBQUcsbUJBQW1CLEVBQUVDLFNBQVMsR0FBRzNGLE9BQU80RixVQUFVQyxLQUFLLFlBQVlDLGNBQWMsaUJBQWlCQyxlQUFlL0YsT0FBTzRGLFVBQVVJLGNBQWMsRUFBRSxDQUFDLEdBQUcsNEJBQXZpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1qQjtBQUFBLFdBRjloQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzVDO0FBQUEsU0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFNBQU0sT0FBTSxzQkFBcUIsVUFBUyxvRUFBbUUsVUFBVSxXQUNwSCxpQ0FBQyxjQUFXLE9BQU85RCxXQUFXLGdCQUFlLFdBQ3hDYyxrQkFBUSx1QkFBQyxTQUNOO0FBQUEsNkJBQUMsUUFBSyxPQUFNLHFCQUFvQixPQUFPLHVCQUFDLFFBQUssV0FBVzdELFlBQVksSUFBSSxNQUFNNkMsS0FBS3VCLEVBQUUsVUFBVSxXQUFVLFNBQVEsT0FBTSxXQUFXUCxlQUFLaUQscUJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0gsR0FBUyxNQUFLLHVCQUFzQixNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYSxLQUFoTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9OO0FBQUEsTUFDcE4sdUJBQUMsUUFBSyxPQUFNLGlCQUFnQixPQUFPLHVCQUFDLFFBQUssV0FBVzlHLFlBQVksSUFBSSxNQUFNNkMsS0FBS3VCLEVBQUUsV0FBVyxXQUFVLFNBQVEsT0FBTSxXQUFXUCxlQUFLa0QsaUJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0csR0FBUyxNQUFLLG9DQUFtQyxNQUFNLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsR0FBSyxRQUFNLFFBQXZPO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdU87QUFBQSxNQUN2Tyx1QkFBQyxRQUFLLE9BQU0sb0JBQW1CLE9BQU8sdUJBQUMsUUFBSyxXQUFXL0csWUFBWSxJQUFJLE1BQU02QyxLQUFLdUIsRUFBRSxjQUFjLFdBQVUsU0FBUSxPQUFNLFdBQVdQLGVBQUttRCxvQkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxSCxHQUFTLE1BQUssNkJBQTRCLE1BQU0sdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQixLQUE3TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlPO0FBQUEsTUFDak8sdUJBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPLHVCQUFDLFVBQU8sT0FBT25ELEtBQUtvRCxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCLEdBQUssTUFBSyw4QkFBNkIsTUFBTSx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0k7QUFBQSxTQUovSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS1QsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLE9BQUksSUFBSSxDQUFDbEYsU0FBU2dCLFVBQVVvQyxZQUFZLEVBQUVjLFNBQVMsUUFBUWlCLHFCQUFxQixFQUFFakMsSUFBSSxPQUFPa0MsSUFBSSxZQUFZLEdBQUdqQixZQUFZLFFBQVEsQ0FBQyxHQUVsSTtBQUFBLDZCQUFDLFNBQU0sT0FBTSwwQkFBeUIsVUFBUyw4REFBNkQsVUFBUyxTQUNoSGxELHVCQUFhYSxPQUFPLHVCQUFDLGtCQUNsQjtBQUFBLCtCQUFDLE9BQUk7QUFBQSxpQ0FBQyxjQUFXLE9BQU0sa0JBQWlCLFNBQVEsU0FBUSxxQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUFhLHVCQUFDLGNBQVcsU0FBUSxNQUFLLElBQUk5QixTQUFTZ0IsVUFBVXFFLGdCQUFnQixpQ0FBQyxVQUFPLE1BQUksTUFBQyxPQUFPdkQsS0FBS3dELHFCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RztBQUFBLGFBQXhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcU47QUFBQSxRQUNyTix1QkFBQyxPQUFJO0FBQUEsaUNBQUMsY0FBVyxPQUFNLGtCQUFpQixTQUFRLFNBQVEsMkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsVUFBYSx1QkFBQyxjQUFXLFNBQVEsTUFBSyxJQUFJLENBQUN0RixTQUFTZ0IsVUFBVXFFLGdCQUFnQixFQUFFN0IsT0FBTyxlQUFlLENBQUMsR0FBRyxpQ0FBQyxVQUFPLE1BQUksTUFBQyxPQUFPMUIsS0FBS3lELGdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQyxLQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSTtBQUFBLGFBQXROO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbU87QUFBQSxRQUNuTyx1QkFBQyxhQUFVLElBQUksTUFBTXpFLEtBQUt1QixFQUFFLHdCQUF3Qiw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFdBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJckIsSUFBb0JyQixVQUFVd0UsWUFBWSx1QkFBQyxPQUFJLE1BQUssVUFBUywyQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QyxJQUFTLHVCQUFDLFNBQU0sVUFBUyxXQUFVLFFBQVEsdUJBQUMsVUFBTyxTQUFTLE1BQU0sS0FBS3hFLFVBQVV5RSxRQUFRLEdBQUcsdUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0QsR0FBVyw0RkFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpTCxJQUM1USx1QkFBQyxTQUFNLFVBQVMsUUFBTyx5REFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRSxLQU4xRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQU0sT0FBTSxvQkFBbUIsVUFBUywrREFBOEQsUUFBUXJFLFlBQVksdUJBQUMsYUFBVSxJQUFJLE1BQU1OLEtBQUt1QixFQUFFLFdBQVcsMEJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQsSUFBZXFELFFBQVcsVUFBVXRFLFlBQVksVUFBVSxTQUFTLFVBQVUsRUFBRXVFLFlBQVksRUFBRXpDLElBQUksUUFBUWtDLElBQUksU0FBUyxFQUFFLEdBQy9SaEUsc0JBQVksdUJBQUMsY0FBVyxPQUFPRSxRQUFRLGdCQUFlLFdBQVdBLGlCQUFPUSxRQUFRLHVCQUFDLGFBQVUsTUFBTVIsT0FBT1EsS0FBS0EsTUFBTSxRQUFRLENBQUE4RCxVQUFTQSxNQUFNdkQsSUFBSSxPQUFNLG9CQUFtQixTQUFTO0FBQUEsUUFDN0ssRUFBRXdELEtBQUssTUFBTTFELE9BQU8sWUFBWTJELFFBQVFBLENBQUFGLFVBQVMsdUJBQUMsU0FBTSxXQUFVLE9BQU0sWUFBVyxVQUFTLElBQUk1RixTQUFTK0YsS0FBS0MsV0FBVyxVQUFTLFFBQU87QUFBQSxpQ0FBQyxhQUFVLElBQUksTUFBTWxGLEtBQUt1QixFQUFFLFdBQVd1RCxNQUFNdkQsRUFBRSxJQUFLdUQsZ0JBQU12RCxNQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQVksdUJBQUMsZ0JBQWEsT0FBT3VELE1BQU12RCxJQUFJLE9BQU0saUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFBbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzTixFQUFTO0FBQUEsUUFDaFIsRUFBRXdELEtBQUssU0FBUzFELE9BQU8sV0FBVzhELE9BQU8sU0FBU0gsUUFBUUEsQ0FBQUYsVUFBUyx1QkFBQyxVQUFPLE9BQU9BLE1BQU1NLFNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsRUFBSTtBQUFBLFFBQ2xHLEVBQUVMLEtBQUssVUFBVTFELE9BQU8sT0FBTzJELFFBQVFBLENBQUFGLFVBQVMsdUJBQUMsVUFBTyxPQUFPQSxNQUFNTyxjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLEVBQUk7QUFBQSxRQUNwRixFQUFFTixLQUFLLFlBQVkxRCxPQUFPLFFBQVEyRCxRQUFRQSxDQUFBRixVQUFTLHVCQUFDLFVBQU8sT0FBT0EsTUFBTVEsb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsRUFBSTtBQUFBLE1BQUMsS0FKakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUsvRSxLQUxXO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLUCxJQUFnQix1QkFBQyxTQUFNLFVBQVMsUUFBTyxzREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RCxLQU52RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVDbEYsVUFBVSx1QkFBQyxTQUFNLE9BQU0sMkJBQTBCLFVBQVMsbUZBQWtGLFFBQVEsdUJBQUMsYUFBVSxJQUFJLE1BQU1KLEtBQUt1QixFQUFFLGFBQWEsK0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0QsR0FBYyxVQUFTLFNBQVEsVUFBVSxFQUFFc0QsWUFBWSxFQUFFekMsSUFBSSxRQUFRa0MsSUFBSSxTQUFTLEVBQUUsR0FDN1IsaUNBQUMsY0FBVyxPQUFPakUsWUFBWSxnQkFBZSxXQUFXQSxxQkFBV1csTUFBTUEsS0FBS3VFLE1BQU1DLFNBQVMsdUJBQUMsZUFBWSxRQUFPLFdBQVUsU0FBUyxFQUFFcEQsSUFBSSxPQUFPcUQsSUFBSSxpQkFBaUJDLElBQUksZ0JBQWdCLEdBQUlyRixxQkFBV1csS0FBS0EsS0FBS3VFLE1BQU1JLElBQUksQ0FBQ0MsTUFBTUMsVUFBVSx1QkFBQyxrQkFBNkIsWUFBVyxjQUFhLFVBQVMsbUJBQzFTO0FBQUEsK0JBQUMsVUFBTyxJQUFJLEVBQUVyQyxTQUFTLENBQUN6RixPQUFPK0gsVUFBVS9ILE9BQU9nSSxhQUFhaEksT0FBT2lJLGdCQUFnQmpJLE9BQU9rSSxhQUFhLEVBQUVKLFFBQVEsQ0FBQyxHQUFHbkQsT0FBTyxDQUFDM0UsT0FBT21JLFFBQVFuSSxPQUFPb0ksTUFBTXBJLE9BQU9xSSxTQUFTckksT0FBT3NJLE1BQU0sRUFBRVIsUUFBUSxDQUFDLEVBQUUsR0FBRyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCLEtBQXZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBME47QUFBQSxRQUMxTix1QkFBQyxPQUFJO0FBQUEsaUNBQUMsY0FBVyxZQUFZNUksU0FBU3VGLFdBQVdPLFdBQVdVLFFBQVM3RCxrQ0FBd0JnRyxLQUFLL0YsSUFBSSxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLFVBQWMsQ0FBQ1YsZUFBZXlHLEtBQUsvRixJQUFJLEtBQUsrRixLQUFLL0YsUUFBUSx1QkFBQyxnQkFBYSxPQUFPK0YsS0FBSy9GLE1BQU0sT0FBTSxnQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUFLLENBQUMrRixLQUFLL0YsUUFBUSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQiw2Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxhQUF4VDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNVO0FBQUEsUUFDdFUsdUJBQUMsVUFBTyxPQUFPK0YsS0FBS1UsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFFBQzNCLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWtCVjtBQUFBQSxlQUFLVyxlQUFlZjtBQUFBQSxVQUFPO0FBQUEsYUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRztBQUFBLFdBSjZKSSxLQUFLckUsSUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUsvTyxDQUFpQixLQUw2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzNFLElBQWlCLHVCQUFDLFNBQU0sTUFBSyxxQ0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDLEtBTGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLcUYsS0FOOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9YO0FBQUEsTUFFQ1osZUFBZSx1QkFBQyxTQUFNLE9BQU0scUJBQW9CLFVBQVMsNERBQTJELFVBQVMsU0FBUSxVQUFVLEVBQUVrRSxZQUFZLEVBQUV6QyxJQUFJLFFBQVFrQyxJQUFJLFNBQVMsRUFBRSxHQUN2TCxpQ0FBQyxjQUFXLE9BQU8xRCxLQUFNSyx1QkFBYSx1QkFBQyxlQUFZLFdBQVcsRUFBRW1CLElBQUksVUFBVXFELElBQUksTUFBTSxHQUFHLFNBQVEsZUFBYyxZQUFZLEVBQUVyRCxJQUFJLFdBQVdxRCxJQUFJLFNBQVMsR0FDdko7QUFBQSwrQkFBQyxVQUFPLE9BQU94RSxVQUFVcUYsVUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBQ2hDLHVCQUFDLGtCQUFlLFlBQVcsZUFBYyxTQUFRLFlBQVcsT0FBTSxTQUFRLE1BQU16RixNQUFNMkYsU0FBUyxVQUFVdkYsVUFBVXFGLFdBQVcsVUFBVSxTQUFTLE1BQU12RixhQUFhLElBQUksR0FBSUUsb0JBQVVxRixXQUFXLFdBQVcsb0JBQW9CLGtCQUFoTztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStPO0FBQUEsUUFDOU96RixNQUFNNEYsU0FBUyx1QkFBQyxTQUFNLFVBQVMsU0FBUzVGLGdCQUFNNEYsTUFBTUMsV0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFdBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJdEMsS0FKQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSWUsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTWhCO0FBQUEsU0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9DQTtBQUFBLElBRUMxRixRQUFRLHVCQUFDLFNBQU0sSUFBSTlCLFNBQVNnQixVQUFVeUcsWUFDbEMzRjtBQUFBQSxXQUFLNEYsU0FBU2pCLElBQUksQ0FBQ2tCLFNBQVNoQixVQUFVLHVCQUFDLFNBQWtDLFVBQVMsUUFBUWdCLHFCQUF4QyxHQUFHaEIsS0FBSyxJQUFJZ0IsT0FBTyxJQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRELENBQVE7QUFBQSxNQUMzRyx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQixJQUFJLEVBQUV6RCxTQUFTLFFBQVEsR0FBRztBQUFBO0FBQUEsUUFBa0IvRSxTQUFTMkMsS0FBSzhGLE1BQU05RyxLQUFLK0csUUFBUTtBQUFBLFFBQUU7QUFBQSxRQUFJL0csS0FBS2dIO0FBQUFBLFdBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0o7QUFBQSxTQUY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR1Q7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLE1BQU1sRyxXQUFXLE9BQU0sNEJBQTJCLGNBQWEsbUJBQWtCLGFBQWEsbUJBQW1CRyxXQUFXTSxNQUFNLEVBQUUsVUFBVXZCLEtBQUtnSCxJQUFJLHFGQUFxRixlQUFhLE1BQUMsTUFBTW5HLE1BQU0yRixTQUFTLE9BQU8zRixNQUFNNEYsT0FBTyxTQUFTLE1BQU0xRixhQUFhLEtBQUssR0FBRyxXQUFXLENBQUFrRyxXQUFVcEcsTUFBTXFHLFFBQVEsRUFBRUMsTUFBTSxFQUFFQyxpQkFBaUJuRyxXQUFXb0csV0FBVyxHQUFHSixPQUFPLEVBQUUsQ0FBQyxLQUF2YjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXliO0FBQUEsT0FwRXRiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxRVA7QUFDSjtBQUFDbEgsR0ExRmVELGVBQWE7QUFBQSxVQUNDM0IsVUFDUkYsUUFDQ0csUUFDSkEsUUFDSUgsUUFDREcsUUFDS0EsUUFDUkgsUUFDS0csUUFDUkgsUUFDRUMsVUFBVTtBQUFBO0FBQUEsS0FYWjRCO0FBQWEsSUFBQXdIO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFjdGlvbkdyb3VwIiwiU2VjdGlvbkdyaWQiLCJTdXJmYWNlQ29udGVudCIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJMaW5rIiwiUm91dGVyTGluayIsIkFsZXJ0IiwiQXZhdGFyIiwiQm94IiwiQnV0dG9uIiwiU3RhY2siLCJUeXBvZ3JhcGh5IiwiRm9ydW1Sb3VuZGVkIiwiUmVjZWlwdExvbmdSb3VuZGVkIiwiSW52ZW50b3J5MlJvdW5kZWQiLCJTbWFydFRveVJvdW5kZWQiLCJBcnJvd0ZvcndhcmRSb3VuZGVkIiwiY29sb3JzIiwidG9rZW5zIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwidXNlQ2FuIiwiZGF0ZVRpbWUiLCJBbW91bnQiLCJDb25maXJtRGlhbG9nIiwiQ29weWFibGVDb2RlIiwiRGF0YVRhYmxlIiwiRW1wdHkiLCJNdXRhdGlvbkJ1dHRvbiIsIlBhbmVsIiwiUXVlcnlTdGF0ZSIsIlJvdXRlTGluayIsIlN0YXQiLCJTdGF0cyIsIlN0YXR1cyIsImxheW91dFN4IiwiYWdlbnRSb2xlTmFtZXMiLCJzYWxlc19hZG1pbiIsImFjY291bnRhbnQiLCJ3YXJlaG91c2VfYnV5ZXIiLCJzdXBlcnZpc29yIiwiZGFzaGJvYXJkR3JlZXRpbmdOYW1lIiwiZGlzcGxheU5hbWUiLCJzcGxpdCIsInRyaW0iLCJkYXNoYm9hcmRBZ2VudFJvbGVMYWJlbCIsImtpbmQiLCJEYXNoYm9hcmRQYWdlIiwiX3MiLCJzaG9wIiwic2Vzc2lvbiIsImRhc2hib2FyZCIsImNhbkZpbmFuY2UiLCJjYW5PcHMiLCJvcGVyYXRpb25zIiwiY2FuT3JkZXJzIiwiY2FuQ3JlYXRlT3JkZXIiLCJvcmRlcnMiLCJxdWVyeSIsImxpbWl0IiwiY2FuUGF1c2VCb3QiLCJib3QiLCJwYXVzZSIsInBhdXNlT3BlbiIsInNldFBhdXNlT3BlbiIsImRhdGEiLCJib3RDb25maWciLCJncmVldGluZ05hbWUiLCJ1c2VyIiwicHJpbWFyeUFjdGlvbiIsImxhYmVsIiwidG8iLCJpZCIsImdyb3VwSW5zZXQiLCJwYWdlSGVhZGVyIiwiYWZ0ZXJHYXAiLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImhlcm9Cb3JkZXIiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJoZXJvIiwiYmFja2dyb3VuZCIsImhlcm9TdGFydCIsImhlcm9FbmQiLCJ4cyIsIm1kIiwic2VjdGlvbkdhcCIsImxldHRlclNwYWNpbmciLCJ0eXBvZ3JhcGh5IiwiZGFzaGJvYXJkT3ZlcmxpbmUiLCJjb2xvciIsImhlcm9UaXRsZUZsb3ciLCJmb250U2l6ZSIsImRhc2hib2FyZFRpdGxlIiwib3ZlcmZsb3dXcmFwIiwiZm9udFdlaWdodCIsInJlZ3VsYXIiLCJoZXJvRGVzY3JpcHRpb25HYXAiLCJtYXhXaWR0aCIsImFjdGlvblRhcmdldCIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJkaWFsb2ciLCJiZ2NvbG9yIiwic3Ryb25nIiwidGV4dERlY29yYXRpb24iLCJvdXRsaW5lIiwiZm9jdXNSaW5nIiwid2lkdGgiLCJvdXRsaW5lQ29sb3IiLCJvdXRsaW5lT2Zmc2V0IiwiY29udHJvbE9mZnNldCIsIm9wZW5Db252ZXJzYXRpb25zIiwicGVuZGluZ09yZGVycyIsImxvd1N0b2NrVmFyaWFudHMiLCJib3RTdGF0dXMiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwieGwiLCJtZXRyaWNWYWx1ZUdhcCIsInJlY29nbml6ZWRSZXZlbnVlIiwiY2FzaFJlY2VpdmVkIiwiaXNQZW5kaW5nIiwicmVmZXRjaCIsInVuZGVmaW5lZCIsImdyaWRDb2x1bW4iLCJvcmRlciIsImtleSIsInJlbmRlciIsImNvZGUiLCJpbmxpbmVHYXAiLCJhbGlnbiIsInRvdGFsIiwib3JkZXJTdGF0ZSIsImZ1bGZpbGxtZW50U3RhdGUiLCJyb2xlcyIsImxlbmd0aCIsInNtIiwibGciLCJtYXAiLCJyb2xlIiwiaW5kZXgiLCJzZWxlY3RlZCIsImluZm9TdXJmYWNlIiwic3VjY2Vzc1N1cmZhY2UiLCJ2aW9sZXRTdXJmYWNlIiwiYWNjZW50IiwiaW5mbyIsInN1Y2Nlc3MiLCJ2aW9sZXQiLCJzdGF0dXMiLCJhbGxvd2VkVG9vbElkcyIsInBlbmRpbmciLCJlcnJvciIsIm1lc3NhZ2UiLCJmb290ZXJGbG93Iiwid2FybmluZ3MiLCJ3YXJuaW5nIiwiYXNPZiIsInRpbWV6b25lIiwibmFtZSIsInJlYXNvbiIsImV4ZWN1dGUiLCJib2R5IiwiZXhwZWN0ZWRWZXJzaW9uIiwidmVyc2lvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpb25Hcm91cCwgU2VjdGlvbkdyaWQsIFN1cmZhY2VDb250ZW50IH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcclxuaW1wb3J0IHsgTGluayBhcyBSb3V0ZXJMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEFsZXJ0LCBBdmF0YXIsIEJveCwgQnV0dG9uLCBMaW5rLCBTdGFjaywgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgRm9ydW1Sb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvRm9ydW1Sb3VuZGVkJztcclxuaW1wb3J0IFJlY2VpcHRMb25nUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL1JlY2VpcHRMb25nUm91bmRlZCc7XHJcbmltcG9ydCBJbnZlbnRvcnkyUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL0ludmVudG9yeTJSb3VuZGVkJztcclxuaW1wb3J0IFNtYXJ0VG95Um91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL1NtYXJ0VG95Um91bmRlZCc7XHJcbmltcG9ydCBBcnJvd0ZvcndhcmRSb3VuZGVkIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvQXJyb3dGb3J3YXJkUm91bmRlZCc7XHJcbmltcG9ydCB7IGNvbG9ycywgdG9rZW5zIH0gZnJvbSAnQGJvdHNhbGVzL3Rva2Vucyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZVNjb3BlLCB1c2VDYW4gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgQW1vdW50LCBDb25maXJtRGlhbG9nLCBDb3B5YWJsZUNvZGUsIERhdGFUYWJsZSwgRW1wdHksIE11dGF0aW9uQnV0dG9uLCBQYW5lbCwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0LCBTdGF0cywgU3RhdHVzIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmltcG9ydCB7IGxheW91dFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvbGF5b3V0JztcclxuXHJcbmNvbnN0IGFnZW50Um9sZU5hbWVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gICAgc2FsZXNfYWRtaW46ICdBZG1pbiBiw6FuIGjDoG5nJyxcclxuICAgIGFjY291bnRhbnQ6ICdL4bq/IHRvw6FuJyxcclxuICAgIHdhcmVob3VzZV9idXllcjogJ0tobyAmIG11YSBow6BuZycsXHJcbiAgICBzdXBlcnZpc29yOiAnVHLGsOG7n25nIG5ow7NtJyxcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkYXNoYm9hcmRHcmVldGluZ05hbWUoZGlzcGxheU5hbWU6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBkaXNwbGF5TmFtZT8uc3BsaXQoJyDCtyAnKVswXT8udHJpbSgpIHx8ICdi4bqhbic7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkYXNoYm9hcmRBZ2VudFJvbGVMYWJlbChraW5kOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4ga2luZCA/IGFnZW50Um9sZU5hbWVzW2tpbmRdIHx8ICdWYWkgdHLDsiBjaMawYSBjw7MgbmjDo24nIDogJ1ZhaSB0csOyIGNoxrBhIGPDsyBuaMOjbic7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEYXNoYm9hcmRQYWdlKCkge1xyXG4gICAgY29uc3QgeyBzaG9wLCBzZXNzaW9uIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgZGFzaGJvYXJkID0gdXNlQXBpKCdnZXREYXNoYm9hcmQnKTtcclxuICAgIGNvbnN0IGNhbkZpbmFuY2UgPSB1c2VDYW4oJ2ZpbmFuY2UucmVhZCcpO1xyXG4gICAgY29uc3QgY2FuT3BzID0gdXNlQ2FuKCdvcGVyYXRpb25zLnJlYWQnKTtcclxuICAgIGNvbnN0IG9wZXJhdGlvbnMgPSB1c2VBcGkoJ2dldE9wZXJhdGlvbnNTdW1tYXJ5Jywge30sIGNhbk9wcyk7XHJcbiAgICBjb25zdCBjYW5PcmRlcnMgPSB1c2VDYW4oJ29yZGVycy5yZWFkJyk7XHJcbiAgICBjb25zdCBjYW5DcmVhdGVPcmRlciA9IHVzZUNhbignb3JkZXJzLndyaXRlJyk7XHJcbiAgICBjb25zdCBvcmRlcnMgPSB1c2VBcGkoJ2xpc3RPcmRlcnMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiA1IH0gfSwgY2FuT3JkZXJzKTtcclxuICAgIGNvbnN0IGNhblBhdXNlQm90ID0gdXNlQ2FuKCdib3QucHVibGlzaCcpO1xyXG4gICAgY29uc3QgYm90ID0gdXNlQXBpKCdnZXRCb3RDb25maWcnLCB7fSwgY2FuUGF1c2VCb3QpO1xyXG4gICAgY29uc3QgcGF1c2UgPSB1c2VDb21tYW5kKCdwYXVzZUJvdCcsIFsnZ2V0RGFzaGJvYXJkJywgJ2dldEJvdENvbmZpZyddKTtcclxuICAgIGNvbnN0IFtwYXVzZU9wZW4sIHNldFBhdXNlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBkYXRhID0gZGFzaGJvYXJkLmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBib3RDb25maWcgPSBib3QuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IGdyZWV0aW5nTmFtZSA9IGRhc2hib2FyZEdyZWV0aW5nTmFtZShzZXNzaW9uLnVzZXIuZGlzcGxheU5hbWUpO1xyXG4gICAgY29uc3QgcHJpbWFyeUFjdGlvbiA9IGNhbk9wc1xyXG4gICAgICAgID8geyBsYWJlbDogJ1hlbSB2aeG7h2MgY+G6p24gbMOgbScsIHRvOiBgL3MvJHtzaG9wLmlkfS9vcGVyYXRpb25zYCB9XHJcbiAgICAgICAgOiBjYW5PcmRlcnMgPyB7IGxhYmVsOiAnWGVtIMSRxqFuIGjDoG5nJywgdG86IGAvcy8ke3Nob3AuaWR9L29yZGVyc2AgfSA6IG51bGw7XHJcblxyXG4gICAgcmV0dXJuIDw+XHJcbiAgICAgICAgPEJveCBzeD17W2xheW91dFN4LmRhc2hib2FyZC5ncm91cEluc2V0LCBsYXlvdXRTeC5wYWdlSGVhZGVyLmFmdGVyR2FwLCB7IGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6IGNvbG9ycy5oZXJvQm9yZGVyLCBib3JkZXJSYWRpdXM6IHZpc3VhbFN4LnJhZGl1cy5oZXJvLCBiYWNrZ3JvdW5kOiBgbGluZWFyLWdyYWRpZW50KDExNWRlZywgJHtjb2xvcnMuaGVyb1N0YXJ0fSwgJHtjb2xvcnMuaGVyb0VuZH0pYCB9XX0+XHJcbiAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBtZDogJ3JvdycgfX0ganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgc3g9e2xheW91dFN4LmRhc2hib2FyZC5zZWN0aW9uR2FwfT5cclxuICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cIm92ZXJsaW5lXCIgc3g9e3sgbGV0dGVyU3BhY2luZzogdmlzdWFsU3gudHlwb2dyYXBoeS5sZXR0ZXJTcGFjaW5nLmRhc2hib2FyZE92ZXJsaW5lLCBjb2xvcjogJ3ByaW1hcnkubWFpbicgfX0+S0jDlE5HIEdJQU4gxJBJ4buAVSBIw4BOSDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoM1wiIHN4PXtbbGF5b3V0U3guZGFzaGJvYXJkLmhlcm9UaXRsZUZsb3csIHsgZm9udFNpemU6IHZpc3VhbFN4LnR5cG9ncmFwaHkuZGFzaGJvYXJkVGl0bGUuZm9udFNpemUsIG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9XX0+Q2jDoG8ge2dyZWV0aW5nTmFtZX0sPGJyIC8+PEJveCBjb21wb25lbnQ9XCJzcGFuXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXt7IGZvbnRXZWlnaHQ6IHZpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5yZWd1bGFyIH19PmPhu61hIGjDoG5nIGPhu6dhIGLhuqFuIGjDtG0gbmF5LjwvQm94PjwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e1tsYXlvdXRTeC5kYXNoYm9hcmQuaGVyb0Rlc2NyaXB0aW9uR2FwLCB7IG1heFdpZHRoOiA2MjAgfV19PlRoZW8gZMO1aSB2aeG7h2MgY+G6p24geOG7rSBsw70sIHRp4bq/biDEkeG7mSDEkcahbiBow6BuZyB2w6AgxJHhu5lpIG5nxakgQUkg4oCUIHThuq1wIHRydW5nIHbDoG8gbmjhu69uZyBxdXnhur90IMSR4buLbmggcXVhbiB0cuG7jW5nLjwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgeyhjYW5PcHMgfHwgY2FuT3JkZXJzIHx8IGNhbkNyZWF0ZU9yZGVyKSAmJiA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwiY29sdW1uXCIgZGVuc2l0eT1cImNvbWZvcnRhYmxlXCIganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cHJpbWFyeUFjdGlvbiAmJiA8TGluayBjb21wb25lbnQ9e1JvdXRlckxpbmt9IHRvPXtwcmltYXJ5QWN0aW9uLnRvfSB1bmRlcmxpbmU9XCJub25lXCIgc3g9e1tsYXlvdXRTeC5kYXNoYm9hcmQuYWN0aW9uVGFyZ2V0LCB7IGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmRpYWxvZywgYmdjb2xvcjogJ3ByaW1hcnkubWFpbicsIGNvbG9yOiAncHJpbWFyeS5jb250cmFzdFRleHQnLCBmb250V2VpZ2h0OiB2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nLCAnJjpob3Zlcic6IHsgYmdjb2xvcjogJ3ByaW1hcnkubGlnaHQnLCB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH0sICcmOmFjdGl2ZSc6IHsgYmdjb2xvcjogJ3ByaW1hcnkuZGFyaycgfSwgJyY6Zm9jdXMtdmlzaWJsZSc6IHsgb3V0bGluZTogYCR7dG9rZW5zLmZvY3VzUmluZy53aWR0aH1weCBzb2xpZGAsIG91dGxpbmVDb2xvcjogJ3ByaW1hcnkubGlnaHQnLCBvdXRsaW5lT2Zmc2V0OiB0b2tlbnMuZm9jdXNSaW5nLmNvbnRyb2xPZmZzZXQgfSB9XX0+e3ByaW1hcnlBY3Rpb24ubGFiZWx9IDxBcnJvd0ZvcndhcmRSb3VuZGVkIGZvbnRTaXplPVwic21hbGxcIiAvPjwvTGluaz59XHJcbiAgICAgICAgICAgICAgICAgICAge2NhbkNyZWF0ZU9yZGVyICYmIDxMaW5rIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89e2Avcy8ke3Nob3AuaWR9L29yZGVycy9uZXdgfSB1bmRlcmxpbmU9XCJub25lXCIgc3g9e1tsYXlvdXRTeC5kYXNoYm9hcmQuYWN0aW9uVGFyZ2V0LCB7IGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGJvcmRlcjogMSwgYm9yZGVyQ29sb3I6ICdkaXZpZGVyJywgYm9yZGVyUmFkaXVzOiB2aXN1YWxTeC5yYWRpdXMuZGlhbG9nLCBjb2xvcjogJ3RleHQucHJpbWFyeScsIGZvbnRXZWlnaHQ6IHZpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmcsICcmOmhvdmVyJzogeyBiZ2NvbG9yOiAnYWN0aW9uLmhvdmVyJywgdGV4dERlY29yYXRpb246ICdub25lJyB9LCAnJjpmb2N1cy12aXNpYmxlJzogeyBvdXRsaW5lOiBgJHt0b2tlbnMuZm9jdXNSaW5nLndpZHRofXB4IHNvbGlkYCwgb3V0bGluZUNvbG9yOiAncHJpbWFyeS5saWdodCcsIG91dGxpbmVPZmZzZXQ6IHRva2Vucy5mb2N1c1JpbmcuY29udHJvbE9mZnNldCB9IH1dfT5U4bqhbyDEkcahbiBow6BuZzwvTGluaz59XHJcbiAgICAgICAgICAgICAgICA8L0FjdGlvbkdyb3VwPn1cclxuICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgPFBhbmVsIHRpdGxlPVwiVMOsbmggaMOsbmggaGnhu4duIHThuqFpXCIgc3VidGl0bGU9XCJDw6FjIEtQSSBsw6AgdHLhuqFuZyB0aMOhaSBoaeG7h24gdOG6oWkgZG8gQVBJIHRy4bqjIHbhu4EsIGtow7RuZyBwaOG6o2kgZOG7sSBiw6FvLlwiIGFmdGVyR2FwPXtcInNlY3Rpb25cIn0+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkYXNoYm9hcmR9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAge2RhdGEgJiYgPFN0YXRzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiSOG7mWkgdGhv4bqhaSDEkWFuZyBt4bufXCIgdmFsdWU9ezxMaW5rIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89e2Avcy8ke3Nob3AuaWR9L2luYm94YH0gdW5kZXJsaW5lPVwiaG92ZXJcIiBjb2xvcj1cImluaGVyaXRcIj57ZGF0YS5vcGVuQ29udmVyc2F0aW9uc308L0xpbms+fSBub3RlPVwiVHLhuqFuZyB0aMOhaSBoaeG7h24gdOG6oWlcIiBpY29uPXs8Rm9ydW1Sb3VuZGVkIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwixJDGoW4gY2jhu50geOG7rSBsw71cIiB2YWx1ZT17PExpbmsgY29tcG9uZW50PXtSb3V0ZXJMaW5rfSB0bz17YC9zLyR7c2hvcC5pZH0vb3JkZXJzYH0gdW5kZXJsaW5lPVwiaG92ZXJcIiBjb2xvcj1cImluaGVyaXRcIj57ZGF0YS5wZW5kaW5nT3JkZXJzfTwvTGluaz59IG5vdGU9XCJUaGVvIHRy4bqhbmcgdGjDoWkgaGnhu4duIHThuqFpIGPhu6dhIEFQSVwiIGljb249ezxSZWNlaXB0TG9uZ1JvdW5kZWQgLz59IGFjY2VudCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiU+G6o24gcGjhuqltIGfhuqduIGjhur90XCIgdmFsdWU9ezxMaW5rIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89e2Avcy8ke3Nob3AuaWR9L2ludmVudG9yeWB9IHVuZGVybGluZT1cImhvdmVyXCIgY29sb3I9XCJpbmhlcml0XCI+e2RhdGEubG93U3RvY2tWYXJpYW50c308L0xpbms+fSBub3RlPVwiVGhlbyBuZ8aw4buhbmcgdOG7k24gdHJvbmcgQVBJXCIgaWNvbj17PEludmVudG9yeTJSb3VuZGVkIC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiVHLhu6MgbMO9IGLDoW4gaMOgbmdcIiB2YWx1ZT17PFN0YXR1cyB2YWx1ZT17ZGF0YS5ib3RTdGF0dXN9IC8+fSBub3RlPVwiVHLhuqFuZyB0aMOhaSBkbyBBUEkgY3VuZyBj4bqlcFwiIGljb249ezxTbWFydFRveVJvdW5kZWQgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8L1N0YXRzPn1cclxuICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxyXG4gICAgICAgIDwvUGFuZWw+XHJcblxyXG4gICAgICAgIDxCb3ggc3g9e1tsYXlvdXRTeC5kYXNoYm9hcmQuc2VjdGlvbkdhcCwgeyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IHsgeHM6ICcxZnInLCB4bDogJzEuNmZyIDFmcicgfSwgYWxpZ25JdGVtczogJ3N0YXJ0JyB9XX0+XHJcblxyXG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJEw7JuZyB0aeG7gW4gdsOgIGRvYW5oIHRodVwiIHN1YnRpdGxlPVwiRG9hbmggdGh1IGdoaSBuaOG6rW4gdsOgIHRp4buBbiDEkcOjIHRodSBsw6AgaGFpIGNo4buJIHPhu5Ega2jDoWMgbmhhdS5cIiBib2R5TW9kZT1cImluc2V0XCI+XHJcbiAgICAgICAgICAgICAgICB7Y2FuRmluYW5jZSA/IGRhdGEgPyA8U3VyZmFjZUNvbnRlbnQgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3g+PFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHZhcmlhbnQ9XCJib2R5MlwiPkRvYW5oIHRodSDEkcOjIGdoaSBuaOG6rW48L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImg0XCIgc3g9e2xheW91dFN4LmRhc2hib2FyZC5tZXRyaWNWYWx1ZUdhcH0+PEFtb3VudCB3cmFwIHZhbHVlPXtkYXRhLnJlY29nbml6ZWRSZXZlbnVlfSAvPjwvVHlwb2dyYXBoeT48L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PjxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiB2YXJpYW50PVwiYm9keTJcIj5UaeG7gW4gxJHDoyB0aHU8L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImg0XCIgc3g9e1tsYXlvdXRTeC5kYXNoYm9hcmQubWV0cmljVmFsdWVHYXAsIHsgY29sb3I6ICdwcmltYXJ5Lm1haW4nIH1dfT48QW1vdW50IHdyYXAgdmFsdWU9e2RhdGEuY2FzaFJlY2VpdmVkfSAvPjwvVHlwb2dyYXBoeT48L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9maW5hbmNlL3Byb2ZpdC1sb3NzYH0+WGVtIGzhu6NpIG5odeG6rW48L1JvdXRlTGluaz5cclxuICAgICAgICAgICAgICAgIDwvU3VyZmFjZUNvbnRlbnQ+IDogZGFzaGJvYXJkLmlzUGVuZGluZyA/IDxCb3ggcm9sZT1cInN0YXR1c1wiPsSQYW5nIHThuqNpIHPhu5EgbGnhu4d1IHTDoGkgY2jDrW5o4oCmPC9Cb3g+IDogPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIGFjdGlvbj17PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b2lkIGRhc2hib2FyZC5yZWZldGNoKCl9PlRo4butIGzhuqFpPC9CdXR0b24+fT5LaMO0bmcgdGjhu4MgdOG6o2kgc+G7kSBsaeG7h3UgdMOgaSBjaMOtbmguIEThu68gbGnhu4d1IGPhu6dhIGPDoWMga2h1IHbhu7FjIGtow6FjIHbhuqtuIGTDuW5nIMSRxrDhu6NjLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+Q2jhu4kgaGnhu4NuIHRo4buLIGtoaSB2YWkgdHLDsiBjw7MgZmluYW5jZS5yZWFkLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICA8L1BhbmVsPlxyXG5cclxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwixJDGoW4gaMOgbmcgZ+G6p24gxJHDonlcIiBzdWJ0aXRsZT1cIk3hu58gxJHGoW4gxJHhu4MgeGVtIHRy4bqhbmcgdGjDoWkgY2h14bqpbiBi4buLLCBnaWFvIGjDoG5nIHbDoCB0aGFuaCB0b8Ohbi5cIiBhY3Rpb249e2Nhbk9yZGVycyA/IDxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L29yZGVyc2B9PlThuqV0IGPhuqMgxJHGoW48L1JvdXRlTGluaz4gOiB1bmRlZmluZWR9IGJvZHlNb2RlPXtjYW5PcmRlcnMgPyAnZmx1c2gnIDogJ2luc2V0J30gZ2VvbWV0cnk9e3sgZ3JpZENvbHVtbjogeyB4czogJ2F1dG8nLCB4bDogJzEgLyAtMScgfSB9fT5cclxuICAgICAgICAgICAgICAgIHtjYW5PcmRlcnMgPyA8UXVlcnlTdGF0ZSBxdWVyeT17b3JkZXJzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57b3JkZXJzLmRhdGEgJiYgPERhdGFUYWJsZSByb3dzPXtvcmRlcnMuZGF0YS5kYXRhfSByb3dLZXk9e29yZGVyID0+IG9yZGVyLmlkfSBsYWJlbD1cIsSQxqFuIGjDoG5nIGfhuqduIMSRw6J5XCIgY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ8SQxqFuIGjDoG5nJywgcmVuZGVyOiBvcmRlciA9PiA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIHN4PXtsYXlvdXRTeC5jb2RlLmlubGluZUdhcH0gZmxleFdyYXA9XCJ3cmFwXCI+PFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vb3JkZXJzLyR7b3JkZXIuaWR9YH0+e29yZGVyLmlkfTwvUm91dGVMaW5rPjxDb3B5YWJsZUNvZGUgdmFsdWU9e29yZGVyLmlkfSBsYWJlbD1cIm3DoyDEkcahbiBow6BuZ1wiIC8+PC9TdGFjaz4gfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3RvdGFsJywgbGFiZWw6ICdHacOhIHRy4buLJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogb3JkZXIgPT4gPEFtb3VudCB2YWx1ZT17b3JkZXIudG90YWx9IC8+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0dXMnLCBsYWJlbDogJ8SQxqFuJywgcmVuZGVyOiBvcmRlciA9PiA8U3RhdHVzIHZhbHVlPXtvcmRlci5vcmRlclN0YXRlfSAvPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZGVsaXZlcnknLCBsYWJlbDogJ0dpYW8nLCByZW5kZXI6IG9yZGVyID0+IDxTdGF0dXMgdmFsdWU9e29yZGVyLmZ1bGZpbGxtZW50U3RhdGV9IC8+IH0sXHJcbiAgICAgICAgICAgICAgICBdfSAvPn08L1F1ZXJ5U3RhdGU+IDogPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBraMO0bmcgY8OzIG9yZGVycy5yZWFkLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICA8L1BhbmVsPlxyXG5cclxuICAgICAgICAgICAge2Nhbk9wcyAmJiA8UGFuZWwgdGl0bGU9XCLEkOG7mWkgbmfFqSBBSSBj4bunYSBj4butYSBow6BuZ1wiIHN1YnRpdGxlPVwiVHLhuqFuZyB0aMOhaSB2YWkgdHLDsiBs4bqleSB04burIEFQSTsgdHLhuqFuZyB0aMOhaSBr4bq/dCBu4buRaSBiw6puIG5nb8OgaSBjaMawYSDEkcaw4bujYyB4w6FjIG1pbmguXCIgYWN0aW9uPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9ib3QvdGVhbWB9PlF14bqjbiBsw70gxJHhu5lpIG5nxak8L1JvdXRlTGluaz59IGJvZHlNb2RlPVwiaW5zZXRcIiBnZW9tZXRyeT17eyBncmlkQ29sdW1uOiB7IHhzOiAnYXV0bycsIHhsOiAnMSAvIC0xJyB9IH19PlxyXG4gICAgICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e29wZXJhdGlvbnN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntvcGVyYXRpb25zLmRhdGE/LmRhdGEucm9sZXMubGVuZ3RoID8gPFNlY3Rpb25HcmlkIHJoeXRobT1cImNvbnRlbnRcIiBjb2x1bW5zPXt7IHhzOiAnMWZyJywgc206ICdyZXBlYXQoMiwxZnIpJywgbGc6ICdyZXBlYXQoNCwxZnIpJyB9fT57b3BlcmF0aW9ucy5kYXRhLmRhdGEucm9sZXMubWFwKChyb2xlLCBpbmRleCkgPT4gPFN1cmZhY2VDb250ZW50IGtleT17cm9sZS5pZH0gYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIiBib2R5TW9kZT1cImNvbXBhY3RPdXRsaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxBdmF0YXIgc3g9e3sgYmdjb2xvcjogW2NvbG9ycy5zZWxlY3RlZCwgY29sb3JzLmluZm9TdXJmYWNlLCBjb2xvcnMuc3VjY2Vzc1N1cmZhY2UsIGNvbG9ycy52aW9sZXRTdXJmYWNlXVtpbmRleCAlIDRdLCBjb2xvcjogW2NvbG9ycy5hY2NlbnQsIGNvbG9ycy5pbmZvLCBjb2xvcnMuc3VjY2VzcywgY29sb3JzLnZpb2xldF1baW5kZXggJSA0XSB9fT48U21hcnRUb3lSb3VuZGVkIC8+PC9BdmF0YXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT57ZGFzaGJvYXJkQWdlbnRSb2xlTGFiZWwocm9sZS5raW5kKX08L1R5cG9ncmFwaHk+eyFhZ2VudFJvbGVOYW1lc1tyb2xlLmtpbmRdICYmIHJvbGUua2luZCAmJiA8Q29weWFibGVDb2RlIHZhbHVlPXtyb2xlLmtpbmR9IGxhYmVsPVwibcOjIHZhaSB0csOyXCIgLz59eyFyb2xlLmtpbmQgJiYgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+QVBJIGNoxrBhIGN1bmcgY+G6pXAgbcOjIHZhaSB0csOyLjwvVHlwb2dyYXBoeT59PC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN0YXR1cyB2YWx1ZT17cm9sZS5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3JvbGUuYWxsb3dlZFRvb2xJZHMubGVuZ3RofSBjw7RuZyBj4bulIMSRxrDhu6NjIGdpYW88L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICA8L1N1cmZhY2VDb250ZW50Pil9PC9TZWN0aW9uR3JpZD4gOiA8RW1wdHkgdGV4dD1cIkFQSSBjaMawYSB0cuG6oyB2YWkgdHLDsiDEkWnhu4F1IGjDoG5oLlwiIC8+fTwvUXVlcnlTdGF0ZT5cclxuICAgICAgICAgICAgPC9QYW5lbD59XHJcblxyXG4gICAgICAgICAgICB7Y2FuUGF1c2VCb3QgJiYgPFBhbmVsIHRpdGxlPVwixJBp4buBdSBraGnhu4NuIHRy4bujIGzDvVwiIHN1YnRpdGxlPVwiVOG6oW0gZOG7q25nIGzDoCB0aGFvIHTDoWMgY8OzIHTDoWMgxJHhu5luZzsgY+G6p24geMOhYyBuaOG6rW4gdsOgIGzDvSBkby5cIiBib2R5TW9kZT1cImluc2V0XCIgZ2VvbWV0cnk9e3sgZ3JpZENvbHVtbjogeyB4czogJ2F1dG8nLCB4bDogJzEgLyAtMScgfSB9fT5cclxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtib3R9Pntib3RDb25maWcgJiYgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSBkZW5zaXR5PVwiY29tZm9ydGFibGVcIiBhbGlnbkl0ZW1zPXt7IHhzOiAnc3RyZXRjaCcsIHNtOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8U3RhdHVzIHZhbHVlPXtib3RDb25maWcuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiYm90LnB1Ymxpc2hcIiB2YXJpYW50PVwib3V0bGluZWRcIiBjb2xvcj1cImVycm9yXCIgYnVzeT17cGF1c2UucGVuZGluZ30gZGlzYWJsZWQ9e2JvdENvbmZpZy5zdGF0dXMgPT09ICdwYXVzZWQnfSBvbkNsaWNrPXsoKSA9PiBzZXRQYXVzZU9wZW4odHJ1ZSl9Pntib3RDb25maWcuc3RhdHVzID09PSAncGF1c2VkJyA/ICdCb3QgxJHDoyB04bqhbSBk4burbmcnIDogJ1ThuqFtIGThu6tuZyBib3QnfTwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhdXNlLmVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCI+e3BhdXNlLmVycm9yLm1lc3NhZ2V9PC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICA8L0FjdGlvbkdyb3VwPn08L1F1ZXJ5U3RhdGU+XHJcbiAgICAgICAgICAgIDwvUGFuZWw+fVxyXG4gICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICB7ZGF0YSAmJiA8U3RhY2sgc3g9e2xheW91dFN4LmRhc2hib2FyZC5mb290ZXJGbG93fT5cclxuICAgICAgICAgICAge2RhdGEud2FybmluZ3MubWFwKCh3YXJuaW5nLCBpbmRleCkgPT4gPEFsZXJ0IGtleT17YCR7aW5kZXh9LSR7d2FybmluZ31gfSBzZXZlcml0eT1cImluZm9cIj57d2FybmluZ308L0FsZXJ0Pil9XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIHN4PXt7IGRpc3BsYXk6ICdibG9jaycgfX0+ROG7ryBsaeG7h3UgY+G6rXAgbmjhuq10IHtkYXRlVGltZShkYXRhLmFzT2YsIHNob3AudGltZXpvbmUpfSDCtyB7c2hvcC5uYW1lfTwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L1N0YWNrPn1cclxuICAgICAgICA8Q29uZmlybURpYWxvZyBvcGVuPXtwYXVzZU9wZW59IHRpdGxlPVwiVOG6oW0gZOG7q25nIHRy4bujIGzDvSBiw6FuIGjDoG5nXCIgY29uZmlybUxhYmVsPVwiVOG6oW0gZOG7q25nIHRy4bujIGzDvVwiIGRlc2NyaXB0aW9uPXtgVHLhu6MgbMO9IGLDoW4gaMOgbmcgJHtib3RDb25maWc/LmlkIHx8IFwiXCJ9IHRyb25nICR7c2hvcC5uYW1lfTogY8OhYyB0w6FjIMSR4buZbmcgY2jGsGEgZ+G7rWkgc+G6vSBk4burbmcuIFRpbiBuaOG6r24gbmjDoCBjdW5nIGPhuqVwIMSRw6Mgbmjhuq1uIGtow7RuZyB0aOG7gyB0aHUgaOG7k2kuYH0gcmVxdWlyZVJlYXNvbiBidXN5PXtwYXVzZS5wZW5kaW5nfSBlcnJvcj17cGF1c2UuZXJyb3J9IG9uQ2xvc2U9eygpID0+IHNldFBhdXNlT3BlbihmYWxzZSl9IG9uQ29uZmlybT17cmVhc29uID0+IHBhdXNlLmV4ZWN1dGUoeyBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogYm90Q29uZmlnPy52ZXJzaW9uIHx8IDEsIHJlYXNvbiB9IH0pfSAvPlxyXG4gICAgPC8+O1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2Rhc2hib2FyZC9pbmRleC50c3gifQ==