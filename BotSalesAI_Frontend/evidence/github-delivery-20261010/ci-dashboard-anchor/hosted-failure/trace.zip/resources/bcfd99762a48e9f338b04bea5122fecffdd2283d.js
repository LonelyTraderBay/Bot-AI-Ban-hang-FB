import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/operations/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5831-503ecf70-8112-4322-a776-5d9e68ae9717/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { label as businessLabel } from "/src/shared/model/labels.ts";
import { PageSections } from "/src/shared/ui/composition.tsx";
import { ActionGroup, FormFields, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport6_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5831-503ecf70-8112-4322-a776-5d9e68ae9717/deps/react.js?v=f9568e8d"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useState = __vite__cjsImport6_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { Alert, Box, Button, MenuItem, Stack, TextField, Typography } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5831-503ecf70-8112-4322-a776-5d9e68ae9717/deps/@mui_material.js?v=f9568e8d";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { useApi, usePagedApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { codePointLength, dateTime } from "/src/shared/model/format.ts";
import { PageHeader, Panel, Stats, Stat, DataTable, QueryState, Toolbar, Pager, Status, MutationButton, EditDialog, ErrorNotice, RouteLink, Amount, DetailLine, ConfirmDialog, LookupLoadMore } from "/src/shared/ui/components.tsx";
const workItemActions = ["begin", "complete", "block", "reassign"];
const roleNames = {
  sales_admin: "Admin bán hàng",
  accountant: "Kế toán",
  warehouse_buyer: "Kho & mua hàng",
  supervisor: "Trưởng nhóm"
};
export function OperationsPage() {
  _s();
  const { shop, session } = useScope();
  const list = useApi("listWorkItems", { query: useListQuery("listWorkItems") });
  const summary = useApi("getOperationsSummary");
  const claim = useCommand("claimWorkItem", ["listWorkItems", "listPrepJobs", "getOperationsSummary"]);
  const update = useCommand("updateWorkItem", ["listWorkItems", "getOperationsSummary"]);
  const [item, setItem] = useState(null);
  const [action, setAction] = useState("begin");
  const [reason, setReason] = useState("");
  const [assignee, setAssignee] = useState("");
  const [exceptionsOnly, setExceptionsOnly] = useState(false);
  const canManageMembers = useCan("members.manage");
  const [memberSearchInput, setMemberSearchInput] = useState(""), [memberSearch, setMemberSearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setMemberSearch(memberSearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [memberSearchInput]);
  const members = usePagedApi("listMembers", { query: { status: "active", q: memberSearch || void 0 } }, canManageMembers);
  const availableActions = item?.allowedActions.filter((candidate) => workItemActions.includes(candidate) && (candidate !== "reassign" || Boolean(members.data?.data.length || members.hasMore))) || [];
  const workItems = list.data?.data || [];
  const asOf = list.data?.meta.asOf;
  const isException = (task) => {
    if (task.state === "completed" || task.state === "cancelled") return false;
    const overdue = Boolean(task.dueAt && asOf && Date.parse(task.dueAt) <= Date.parse(asOf));
    const unclaimed = task.state === "queued" && !task.assigneeUserId;
    return task.state === "blocked" || overdue || unclaimed || task.kind === "payment_mismatch";
  };
  const exceptionItems = workItems.filter(isException);
  const visibleItems = exceptionsOnly ? exceptionItems : workItems;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Công việc hôm nay", subtitle: "Giao việc → nhận việc → hoàn thành → kiểm tra kết quả." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 74,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Dữ liệu vận hành và trạng thái dịch vụ đang được mô phỏng; chưa xác minh worker hoặc backend thật." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 75,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: summary, pendingProfile: "section", children: summary.data && /* @__PURE__ */ jsxDEV(Stats, { children: [
      /* @__PURE__ */ jsxDEV(Stat, { title: "Chưa có người nhận", value: summary.data.data.queuedTasks, accent: true }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 78,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Quá hạn", value: summary.data.data.overdueTasks }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 79,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Chờ phê duyệt", value: summary.data.data.pendingApprovals }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 80,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { title: "Kết quả chưa rõ", value: summary.data.data.unknownCommands }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 81,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 77,
      columnNumber: 30
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 76,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: claim.error }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(SurfaceContent, { bodyMode: "insetDivider", "data-testid": "operation-exceptions", children: [
        /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", sm: "row" }, justifyContent: "space-between", alignItems: { xs: "stretch", sm: "center" }, sx: layoutSx.surface.headerFlowGap, children: [
          /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: "Giám sát ngoại lệ" }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 89,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Quá hạn theo thời điểm API; gồm việc bị chặn, chưa nhận, đến hạn hoặc sai lệch thanh toán. Chỉ lọc trang dữ liệu hiện đang tải." }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 90,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 88,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: exceptionsOnly ? "contained" : "outlined", "aria-pressed": exceptionsOnly, onClick: () => setExceptionsOnly((value) => !value), children: exceptionsOnly ? `Hiện mọi công việc (${workItems.length})` : `Chỉ xem ngoại lệ (${exceptionItems.length})` }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 92,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 87,
          columnNumber: 17
        }, this),
        exceptionsOnly && exceptionItems.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", children: "Không có ngoại lệ trong trang dữ liệu hiện tại." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 96,
          columnNumber: 67
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 86,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listWorkItems" }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 98,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Công việc vận hành", rows: visibleItems, rowKey: (task) => task.id, columns: [
          {
            key: "task",
            label: "Công việc",
            render: (task) => /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: task.kind === "prepare_order" ? "Chuẩn bị đơn hàng" : task.kind === "customer_handoff" ? "Tiếp quản khách hàng" : task.kind === "payment_mismatch" ? "Sai lệch thanh toán" : task.kind === "late_shipment" ? "Vận đơn quá hạn" : businessLabel(task.kind) }, void 0, false, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 104,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
                task.source.type,
                " · ",
                task.source.id
              ] }, void 0, true, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 105,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 103,
              columnNumber: 64
            }, this)
          },
          { key: "status", label: "Trạng thái", render: (task) => /* @__PURE__ */ jsxDEV(Status, { value: task.state }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 108,
            columnNumber: 67
          }, this) },
          { key: "assigned", label: "Người nhận", render: (task) => task.assigneeUserId === session.user.id ? "Bạn" : task.assigneeUserId || "Chưa có" },
          { key: "due", label: "Hạn xử lý", render: (task) => task.dueAt ? dateTime(task.dueAt, shop.timezone) : "Chưa đặt lịch" },
          { key: "reason", label: "Vướng mắc", render: (task) => task.blockedReason || "—" },
          {
            key: "actions",
            label: "",
            render: (task) => {
              const updateActions = task.allowedActions.filter((candidate) => workItemActions.includes(candidate));
              return /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
                /* @__PURE__ */ jsxDEV(MutationButton, { permission: "operations.claim", allowedActions: task.allowedActions, action: "claim", busy: claim.pending, onClick: () => void claim.execute({ path: { resourceId: task.id }, body: { expectedVersion: task.version } }).catch(() => void 0), children: "Tôi nhận việc" }, void 0, false, {
                  fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                  lineNumber: 116,
                  columnNumber: 37
                }, this),
                task.kind === "prepare_order" && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/fulfillment`, children: "Chuẩn bị hàng" }, void 0, false, {
                  fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                  lineNumber: 117,
                  columnNumber: 71
                }, this),
                task.kind !== "prepare_order" && updateActions.length > 0 && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "operations.manage", onClick: () => {
                  setItem(task);
                  setReason("");
                  setAssignee("");
                  setAction(updateActions[0]);
                  update.clearError();
                }, children: "Cập nhật" }, void 0, false, {
                  fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                  lineNumber: 118,
                  columnNumber: 99
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", sx: { alignSelf: "center" }, children: [
                  "Được phép: ",
                  task.allowedActions.length ? task.allowedActions.join(" · ") : "Không có hành động"
                ] }, void 0, true, {
                  fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                  lineNumber: 125,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 115,
                columnNumber: 22
              }, this);
            }
          }
        ] }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 101,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 130,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 100,
        columnNumber: 31
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 99,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 85,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!item, title: "Cập nhật công việc", onClose: () => setItem(null), busy: update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !item || !availableActions.includes(action) || codePointLength(reason.trim()) < 5 || action === "reassign" && !assignee || update.pending, onClick: async () => {
      if (!item || !availableActions.includes(action)) return;
      try {
        await update.execute({ path: { resourceId: item.id }, body: { expectedVersion: item.version, action, reason, ...action === "reassign" ? { assigneeUserId: assignee || null } : {} } });
        setItem(null);
      } catch {
      }
    }, children: "Lưu kết quả" }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 134,
      columnNumber: 123
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: update.error }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 142,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { children: item?.source.id }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 144,
          columnNumber: 17
        }, this),
        availableActions.length > 0 && /* @__PURE__ */ jsxDEV(TextField, { label: "Hành động được phép", select: true, value: availableActions.includes(action) ? action : availableActions[0], onChange: (event) => setAction(event.target.value), children: availableActions.map((value) => /* @__PURE__ */ jsxDEV(MenuItem, { value, children: value === "begin" ? "Bắt đầu xử lý" : value === "complete" ? "Hoàn thành" : value === "block" ? "Báo đang bị chặn" : "Chuyển người phụ trách" }, value, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 146,
          columnNumber: 54
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 145,
          columnNumber: 49
        }, this),
        action === "reassign" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm thành viên đang hoạt động", value: memberSearchInput, onChange: (event) => setMemberSearchInput(event.target.value), disabled: !canManageMembers, helperText: "Tìm kiếm dùng q của listMembers; trang tiếp dùng cursor." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 149,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Người phụ trách", value: assignee, onChange: (event) => setAssignee(event.target.value), disabled: !canManageMembers || members.isPending && !members.data, children: [
            assignee && !members.data?.data.some((member) => member.userId === assignee) && /* @__PURE__ */ jsxDEV(MenuItem, { value: assignee, children: assignee }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 151,
              columnNumber: 106
            }, this),
            members.data?.data.filter((member) => member.status === "active").map((member) => /* @__PURE__ */ jsxDEV(MenuItem, { value: member.userId, children: member.userId }, member.id, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 152,
              columnNumber: 108
            }, this))
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 150,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "thành viên", loadedCount: members.loadedCount, hasMore: members.hasMore, busy: members.isLoadingMore, onLoadMore: members.loadMore }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 154,
            columnNumber: 21
          }, this),
          members.isError && /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
            /* @__PURE__ */ jsxDEV(ErrorNotice, { error: members.error }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 155,
              columnNumber: 57
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
              void (members.isFetchNextPageError ? members.loadMore() : members.refetch());
            }, children: "Thử lại danh sách thành viên" }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 155,
              columnNumber: 94
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 155,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 148,
          columnNumber: 43
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Kết quả / lý do", multiline: true, minRows: 3, value: reason, onChange: (event) => setReason(event.target.value) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 157,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 143,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 134,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
    lineNumber: 73,
    columnNumber: 10
  }, this);
}
_s(OperationsPage, "g6vHu5+fjjm2Eu6pVv9CYOY5d8o=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand, useCommand, useCan, usePagedApi];
});
_c = OperationsPage;
export function ApprovalsPage() {
  _s2();
  const { shop } = useScope();
  const list = useApi("listApprovals", { query: useListQuery("listApprovals") });
  const [approvalId, setApprovalId] = useState(null);
  const detail = useApi("getApproval", { path: { resourceId: approvalId || "" } }, Boolean(approvalId));
  const decide = useCommand("decideApproval", ["getApproval", "listApprovals", "listPurchaseOrders", "getOperationsSummary"]);
  const [decision, setDecision] = useState("approve");
  const [reason, setReason] = useState("");
  const approval = detail.data?.data;
  const simulatedNow = detail.data?.meta.asOf;
  const expiryVerified = Boolean(simulatedNow);
  const expired = approval ? !simulatedNow || Date.parse(approval.expiresAt) <= Date.parse(simulatedNow) : true;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Cần phê duyệt", subtitle: "Quyết định gắn với đúng nội dung, phiên bản và hạn hiệu lực — không phải một nút đồng ý chung." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 177,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PageSections, { children: [
      /* @__PURE__ */ jsxDEV(Panel, { children: [
        /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listApprovals" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 180,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Yêu cầu phê duyệt", rows: list.data.data, rowKey: (entry) => entry.id, columns: [
            { key: "action", label: "Nội dung", render: (entry) => /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: businessLabel(entry.action) }, void 0, false, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 184,
                columnNumber: 75
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
                businessLabel(entry.resource.type),
                " · ",
                entry.action,
                " · Mã đối tượng: ",
                entry.resource.id
              ] }, void 0, true, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 184,
                columnNumber: 180
              }, this)
            ] }, void 0, true, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 184,
              columnNumber: 68
            }, this) },
            { key: "amount", label: "Số tiền", render: (entry) => /* @__PURE__ */ jsxDEV(Amount, { value: entry.amount }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 185,
              columnNumber: 67
            }, this) },
            { key: "state", label: "Trạng thái", render: (entry) => /* @__PURE__ */ jsxDEV(Status, { value: entry.status }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 186,
              columnNumber: 69
            }, this) },
            { key: "due", label: "Hết hạn", render: (entry) => dateTime(entry.expiresAt, shop.timezone) },
            {
              key: "actions",
              label: "",
              render: (entry) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "approvals.decide", disabled: entry.status !== "pending", onClick: () => {
                setApprovalId(entry.id);
                setReason("");
                setDecision("approve");
                decide.clearError();
              }, children: "Xem & quyết định" }, void 0, false, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 189,
                columnNumber: 61
              }, this)
            }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 183,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 197,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 182,
          columnNumber: 31
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 181,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 179,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(PurchaseDelegationsPanel, {}, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 201,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 178,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: Boolean(approvalId), title: "Xem xét phê duyệt", onClose: () => setApprovalId(null), busy: decide.pending, actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "approvals.decide", variant: "contained", busy: decide.pending, disabled: !approval || detail.isPending || approval.status !== "pending" || expired || codePointLength(reason.trim()) < 5, onClick: async () => {
      if (!approval || approval.status !== "pending" || expired) return;
      try {
        await decide.execute({ path: { resourceId: approval.id }, body: { expectedVersion: approval.version, intentHash: approval.intentHash, decision, reason } });
        setApprovalId(null);
      } catch {
      }
    }, children: decision === "approve" ? "Duyệt đúng nội dung này" : "Từ chối" }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 203,
      columnNumber: 141
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: decide.error }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 211,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: approval && /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Thay đổi giá, số lượng, đối tượng hoặc quyền có thể làm phê duyệt hết hiệu lực. Im lặng không được coi là đồng ý." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 214,
          columnNumber: 21
        }, this),
        !expiryVerified && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Không xác minh được thời điểm hiện tại từ API; không thể gửi quyết định an toàn." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 215,
          columnNumber: 41
        }, this),
        expired && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Phê duyệt đã hết hạn; cần xin phê duyệt mới trước khi tiếp tục." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 216,
          columnNumber: 33
        }, this),
        approval.status !== "pending" && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: [
          "Phê duyệt hiện ở trạng thái “",
          businessLabel(approval.status),
          "”; không thể quyết định lại."
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 217,
          columnNumber: 55
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Hành động", children: businessLabel(approval.action) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 218,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đối tượng", children: [
          approval.resource.type,
          " · Mã đối tượng: ",
          approval.resource.id,
          " · phiên bản ",
          approval.resourceVersion
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 219,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: approval.policyVersion }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 220,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Người yêu cầu", children: [
          "Mã nhân sự: ",
          approval.requestedBy
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Giá trị", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: approval.amount }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 222,
          columnNumber: 49
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 222,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Hạn hiệu lực", children: dateTime(approval.expiresAt, shop.timezone) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 223,
          columnNumber: 21
        }, this),
        approval.decidedBy && /* @__PURE__ */ jsxDEV(DetailLine, { label: "Người quyết định", children: [
          "Mã nhân sự: ",
          approval.decidedBy
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 224,
          columnNumber: 44
        }, this),
        approval.decisionReason && /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lý do đã ghi nhận", children: approval.decisionReason }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 225,
          columnNumber: 49
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", sx: { overflowWrap: "anywhere" }, children: [
          "Hash nội dung: ",
          approval.intentHash
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 226,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Quyết định", select: true, value: decision, onChange: (event) => setDecision(event.target.value), disabled: approval.status !== "pending" || expired, children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "approve", children: "Duyệt" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 228,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "reject", children: "Từ chối" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 229,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 227,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do quyết định", multiline: true, minRows: 3, value: reason, onChange: (event) => setReason(event.target.value), disabled: approval.status !== "pending" || expired }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 231,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 213,
        columnNumber: 30
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 212,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 203,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
    lineNumber: 176,
    columnNumber: 10
  }, this);
}
_s2(ApprovalsPage, "QGvE1pSYro4vfvTDRqmr/uvERCc=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand];
});
_c2 = ApprovalsPage;
function PurchaseDelegationsPanel() {
  _s3();
  const { shop, session } = useScope();
  const canRead = useCan("procurement.read");
  const canManage = useCan("procurement.delegation.manage");
  const grants = useApi("listPurchaseDelegations", { query: { limit: 20 } }, canRead);
  const reservations = useApi("listPurchaseDelegationReservations", { query: { limit: 20 } }, canManage);
  const agents = usePagedApi("listAgentRoles", {}, canManage);
  const suppliers = usePagedApi("listSuppliers", {}, canManage);
  const warehouses = usePagedApi("listWarehouses", { query: { status: "active" } }, canManage);
  const offers = usePagedApi("listSupplierOffers", {}, canManage);
  const budgets = usePagedApi("listBudgetPolicies", {}, canManage);
  const budgetApprovals = useApi("listApprovals", { query: { limit: 100 } }, canManage);
  const create = useCommand("createPurchaseDelegation", ["listPurchaseDelegations"]);
  const update = useCommand("updatePurchaseDelegation", ["listPurchaseDelegations", "listPurchaseDelegationReservations", "listReorderRules", "listPurchaseSuggestions"]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [agentId, setAgentId] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [warehouseId, setWarehouseId] = useState("");
  const [offerIds, setOfferIds] = useState([]);
  const [budgetId, setBudgetId] = useState("");
  const [maxPerOrder, setMaxPerOrder] = useState("");
  const [expiresAt, setExpiresAt] = useState(() => localDateTimeInput(Date.now() + 7 * 24 * 60 * 60 * 1e3));
  const [actionGrant, setActionGrant] = useState(null);
  const [actionStatus, setActionStatus] = useState("paused");
  const readyAgents = agents.data?.data.filter((agent) => agent.kind === "warehouse_buyer" && agent.humanOwnerId === session.user.id) || [];
  const approvedSuppliers = suppliers.data?.data.filter((supplier) => supplier.status === "approved") || [];
  const eligibleOffers = offers.data?.data.filter((offer) => offer.supplierId === supplierId) || [];
  const procurementBudgets = budgets.data?.data.filter((budget) => budget.kind === "procurement" && budget.enabled && !!budget.limitAmount && !!budget.approvalId && !!budgetApprovals.data?.meta.asOf && budgetApprovals.data.data.some((approval) => approval.id === budget.approvalId && approval.status === "approved" && approval.resource.type === "budget_policy" && approval.resource.id === budget.id && approval.resourceVersion === budget.version && Date.parse(approval.expiresAt) > Date.parse(budgetApprovals.data?.meta.asOf || ""))) || [];
  const selectedBudget = procurementBudgets.find((budget) => budget.id === budgetId);
  const validAmount = /^\d+$/.test(maxPerOrder) && Number(maxPerOrder) > 0 && !!selectedBudget?.limitAmount && Number(maxPerOrder) <= Number(selectedBudget.limitAmount.amount);
  const expiryValid = Number.isFinite(Date.parse(expiresAt)) && Date.parse(expiresAt) > Date.now();
  const canCreate = !!agentId && !!supplierId && !!warehouseId && offerIds.length > 0 && !!selectedBudget && validAmount && expiryValid && !create.pending;
  const openCreate = () => {
    setAgentId(readyAgents[0]?.id || "");
    setSupplierId("");
    setWarehouseId(warehouses.data?.data[0]?.id || "");
    setOfferIds([]);
    setBudgetId(procurementBudgets[0]?.id || "");
    setMaxPerOrder("300000");
    setExpiresAt(localDateTimeInput(Date.now() + 7 * 24 * 60 * 60 * 1e3));
    create.clearError();
    setDialogOpen(true);
  };
  const saveGrant = async () => {
    if (!canCreate || !selectedBudget) return;
    try {
      await create.execute({ body: {
        agentId,
        supplierId,
        warehouseId,
        offerIds,
        maxPerOrder: { amount: maxPerOrder, currency: shop.currency },
        budgetPolicyId: budgetId,
        expiresAt: new Date(expiresAt).toISOString()
      } });
      setDialogOpen(false);
    } catch {
    }
  };
  const grantLabel = (grant) => {
    const agent = agents.data?.data.find((row) => row.id === grant.agentId);
    const supplier = suppliers.data?.data.find((row) => row.id === grant.supplierId);
    const warehouse = warehouses.data?.data.find((row) => row.id === grant.warehouseId);
    return `${agent?.kind ? roleNames[agent.kind] : `Mã vai trò: ${grant.agentId}`} · ${supplier?.name || `Mã nhà cung cấp: ${grant.supplierId}`} · ${warehouse?.name || `Mã kho: ${grant.warehouseId}`}`;
  };
  if (!canRead) return null;
  return /* @__PURE__ */ jsxDEV(Panel, { title: "Ủy quyền gửi đơn mua", subtitle: "Chỉ owner cấp quyền; mỗi ủy quyền giới hạn theo người phụ trách, nhà cung cấp, kho, báo giá, ngân sách, hạn mức và thời hạn.", children: [
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Đây là worker MSW local xác định. Không gọi AI, nhà cung cấp hoặc thanh toán; trạng thái “đã gửi” chỉ là kết quả mô phỏng." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 302,
      columnNumber: 9
    }, this),
    canManage && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "form", children: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.delegation.manage", onClick: openCreate, children: "Tạo ủy quyền có giới hạn" }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 303,
      columnNumber: 69
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 303,
      columnNumber: 23
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: grants, pendingProfile: "section", children: grants.data && /* @__PURE__ */ jsxDEV(DataTable, { label: "Ủy quyền gửi đơn mua", rows: grants.data.data, rowKey: (grant) => grant.id, columns: [
      { key: "scope", label: "Phạm vi", render: (grant) => /* @__PURE__ */ jsxDEV(Stack, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: grantLabel(grant) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 305,
          columnNumber: 67
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
          grant.offerSnapshots.length,
          " báo giá · tối đa ",
          grant.maxPerOrder.amount,
          " ",
          grant.maxPerOrder.currency,
          " / đơn"
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 305,
          columnNumber: 162
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: [
          "Ngân sách · mã chính sách ",
          grant.budgetPolicyId,
          " · ",
          grant.budgetPeriod,
          " · đến ",
          dateTime(grant.expiresAt, shop.timezone)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 305,
          columnNumber: 313
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 305,
        columnNumber: 60
      }, this) },
      { key: "state", label: "Trạng thái", render: (grant) => /* @__PURE__ */ jsxDEV(Status, { value: Date.parse(grant.expiresAt) <= Date.now() && grant.status === "active" ? "expired" : grant.status }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 306,
        columnNumber: 63
      }, this) },
      { key: "reason", label: "Lý do gần nhất", render: (grant) => grant.lastReason || "—" },
      { key: "actions", label: "", render: (grant) => /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        grant.status !== "revoked" && Date.parse(grant.expiresAt) > Date.now() && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.delegation.manage", disabled: update.pending, onClick: () => {
          setActionGrant(grant);
          setActionStatus(grant.status === "active" ? "paused" : "active");
        }, children: grant.status === "active" ? "Tạm dừng" : "Kích hoạt" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 309,
          columnNumber: 92
        }, this),
        grant.status !== "revoked" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "procurement.delegation.manage", color: "error", disabled: update.pending, onClick: () => {
          setActionGrant(grant);
          setActionStatus("revoked");
        }, children: "Thu hồi" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 310,
          columnNumber: 48
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 308,
        columnNumber: 55
      }, this) }
    ] }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 304,
      columnNumber: 77
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 304,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: reservations, pendingProfile: "section", children: reservations.data && /* @__PURE__ */ jsxDEV(DataTable, { label: "Lịch sử hạn mức mua tự động", rows: reservations.data.data, rowKey: (row) => row.id, columns: [
      { key: "purchase", label: "Đơn mua", render: (row) => row.purchaseOrderId },
      { key: "amount", label: "Số tiền", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.amount }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 315,
        columnNumber: 59
      }, this) },
      { key: "period", label: "Kỳ ngân sách", render: (row) => row.periodKey },
      { key: "status", label: "Đối chiếu", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.status }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 317,
        columnNumber: 61
      }, this) }
    ] }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 313,
      columnNumber: 89
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 313,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 319,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: dialogOpen, title: "Tạo ủy quyền mua hàng", description: "Ủy quyền tạo ở trạng thái tạm dừng. Kích hoạt chỉ khả dụng sau khi vai trò, báo giá và ngân sách được kiểm tra lại.", onClose: () => setDialogOpen(false), busy: create.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !canCreate, onClick: () => void saveGrant(), children: "Tạo ở trạng thái tạm dừng" }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 320,
      columnNumber: 267
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 321,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Vai trò mua hàng chịu trách nhiệm", value: agentId, onChange: (event) => setAgentId(event.target.value), children: readyAgents.map((agent) => /* @__PURE__ */ jsxDEV(MenuItem, { value: agent.id, children: [
          roleNames[agent.kind],
          " · ",
          agent.id,
          " · ",
          agent.status === "paused" ? "đang tạm dừng" : agent.status
        ] }, agent.id, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 323,
          columnNumber: 174
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 323,
          columnNumber: 17
        }, this),
        readyAgents.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Không có vai trò warehouse_buyer do tài khoản hiện tại phụ trách." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 324,
          columnNumber: 46
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Nhà cung cấp đã duyệt", value: supplierId, onChange: (event) => {
          setSupplierId(event.target.value);
          setOfferIds([]);
        }, children: approvedSuppliers.map((supplier) => /* @__PURE__ */ jsxDEV(MenuItem, { value: supplier.id, children: supplier.name }, supplier.id, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 325,
          columnNumber: 196
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 325,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Kho đang hoạt động", value: warehouseId, onChange: (event) => setWarehouseId(event.target.value), children: warehouses.data?.data.map((warehouse) => /* @__PURE__ */ jsxDEV(MenuItem, { value: warehouse.id, children: [
          warehouse.code,
          " · ",
          warehouse.name
        ] }, warehouse.id, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 326,
          columnNumber: 181
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 326,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Báo giá nằm trong phạm vi", value: offerIds, slotProps: { select: { multiple: true } }, onChange: (event) => setOfferIds(typeof event.target.value === "string" ? event.target.value.split(",") : event.target.value), children: eligibleOffers.map((offer) => /* @__PURE__ */ jsxDEV(MenuItem, { value: offer.id, children: [
          offer.id,
          " · Mã biến thể: ",
          offer.variantId,
          " · ",
          offer.unitCost.amount,
          " ",
          offer.unitCost.currency,
          " · MOQ ",
          offer.minimumQuantity,
          "/",
          offer.packSize
        ] }, offer.id, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 327,
          columnNumber: 302
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 327,
          columnNumber: 17
        }, this),
        budgetApprovals.isPending && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Đang đối chiếu phê duyệt ngân sách…" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 328,
          columnNumber: 47
        }, this),
        budgetApprovals.isError && /* @__PURE__ */ jsxDEV(ErrorNotice, { error: budgetApprovals.error }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 328,
          columnNumber: 150
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Ngân sách mua hàng đã bật và được duyệt", value: budgetId, onChange: (event) => setBudgetId(event.target.value), children: procurementBudgets.map((budget) => /* @__PURE__ */ jsxDEV(MenuItem, { value: budget.id, children: [
          budget.id,
          " · ",
          budget.limitAmount?.amount,
          " ",
          budget.limitAmount?.currency,
          " · ",
          budget.period
        ] }, budget.id, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 328,
          columnNumber: 369
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 328,
          columnNumber: 196
        }, this),
        !budgetApprovals.isPending && !budgetApprovals.isError && procurementBudgets.length === 0 && /* @__PURE__ */ jsxDEV(Typography, { role: "status", children: "Không có ngân sách mua hàng đang bật, còn hiệu lực phê duyệt và khớp phiên bản." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 328,
          columnNumber: 623
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Hạn mức mỗi đơn", type: "number", value: maxPerOrder, onChange: (event) => setMaxPerOrder(event.target.value), inputProps: { min: 1, step: 1 }, error: maxPerOrder !== "" && !validAmount, helperText: selectedBudget ? `Không vượt ${selectedBudget.limitAmount?.amount} ${shop.currency}.` : "Chọn ngân sách đã bật trước." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 329,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Hết hạn vào", type: "datetime-local", value: expiresAt, onChange: (event) => setExpiresAt(event.target.value), error: expiresAt !== "" && !expiryValid }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 330,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: "Bản ghi lưu snapshot giá/MOQ/quy cách và phiên bản ngân sách. Mọi thay đổi trong scope sẽ chặn lần gửi tiếp theo." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 331,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 322,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 320,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!actionGrant, title: actionStatus === "revoked" ? "Thu hồi ủy quyền gửi đơn" : actionStatus === "active" ? "Kích hoạt ủy quyền gửi đơn" : "Tạm dừng ủy quyền gửi đơn", description: `${actionGrant ? grantLabel(actionGrant) : ""}. Hạn mức ${actionGrant?.maxPerOrder.amount || ""} ${actionGrant?.maxPerOrder.currency || ""}/đơn; hành động áp dụng cho ${actionGrant?.toolId || "purchase.send"}. Lệnh đã được tiếp nhận không thể bị thu hồi.`, confirmLabel: actionStatus === "revoked" ? "Thu hồi ủy quyền" : actionStatus === "active" ? "Kích hoạt ủy quyền" : "Tạm dừng ủy quyền", requireReason: true, busy: update.pending, error: update.error, onClose: () => setActionGrant(null), onConfirm: async (reason) => {
      if (!actionGrant) return;
      try {
        await update.execute({ path: { resourceId: actionGrant.id }, body: { expectedVersion: actionGrant.version, status: actionStatus, reason } });
        setActionGrant(null);
      } catch {
      }
    } }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 334,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
    lineNumber: 301,
    columnNumber: 10
  }, this);
}
_s3(PurchaseDelegationsPanel, "v+8YKDgE0+fULAst95tMiAIiwd0=", false, function() {
  return [useScope, useCan, useCan, useApi, useApi, usePagedApi, usePagedApi, usePagedApi, usePagedApi, usePagedApi, useApi, useCommand, useCommand];
});
_c3 = PurchaseDelegationsPanel;
function localDateTimeInput(timestamp) {
  const local = new Date(timestamp - new Date(timestamp).getTimezoneOffset() * 6e4);
  return local.toISOString().slice(0, 16);
}
export function DigestsPage() {
  _s4();
  const { shop } = useScope();
  const list = useApi("listDigests", { query: useListQuery("listDigests") });
  const health = useApi("getOperationsSummary");
  const control = useCommand("controlAutomation", ["listAgentRoles", "getBotConfig", "getOperationsSummary"]);
  const [stop, setStop] = useState(null);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Bản tin & sức khỏe hệ thống", subtitle: "Những việc quan trọng cần chủ shop quyết định; không thay thế người trực thực tế." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 355,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Đây là dữ liệu mô phỏng. Trạng thái “chưa xác minh” không chứng minh backend, provider hoặc worker đã sẵn sàng." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 356,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "1fr", lg: "1.5fr 1fr" }, children: [
      /* @__PURE__ */ jsxDEV(Panel, { title: "Bản tin điều hành", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(QueryState, { query: list, children: /* @__PURE__ */ jsxDEV(SurfaceContent, { children: [
        list.data?.data.map((digest) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.detail.relatedItemInset, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.dialog }], children: [
          /* @__PURE__ */ jsxDEV(Stack, { direction: "row", justifyContent: "space-between", sx: layoutSx.surface.headerFlowGap, children: [
            /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", children: [
                dateTime(digest.periodStart, shop.timezone),
                " → ",
                dateTime(digest.periodEnd, shop.timezone)
              ] }, void 0, true, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 362,
                columnNumber: 126
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
                digest.id,
                " · phiên bản ",
                digest.version
              ] }, void 0, true, {
                fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
                lineNumber: 362,
                columnNumber: 262
              }, this)
            ] }, void 0, true, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 362,
              columnNumber: 119
            }, this),
            /* @__PURE__ */ jsxDEV(Status, { value: digest.status }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 362,
              columnNumber: 376
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 362,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { sx: [layoutSx.surface.sectionBefore, { whiteSpace: "pre-wrap" }], children: digest.text }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 363,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Thời điểm tạo / cập nhật", children: [
            dateTime(digest.createdAt, shop.timezone),
            " / ",
            dateTime(digest.updatedAt, shop.timezone)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 364,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nguồn công việc", children: digest.workItemIds.length ? digest.workItemIds.join(" · ") : "Không có mục công việc được tham chiếu" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 365,
            columnNumber: 29
          }, this)
        ] }, digest.id, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 361,
          columnNumber: 58
        }, this)),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data?.page }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 367,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 360,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 359,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 358,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Trạng thái phụ thuộc", bodyMode: "inset", children: [
        /* @__PURE__ */ jsxDEV(QueryState, { query: health, children: /* @__PURE__ */ jsxDEV(Stack, { children: health.data?.data.health.map((check) => /* @__PURE__ */ jsxDEV(Box, { sx: layoutSx.page.sectionAfter, children: [
          /* @__PURE__ */ jsxDEV(Stack, { direction: "row", justifyContent: "space-between", children: [
            /* @__PURE__ */ jsxDEV(Typography, { children: check.component }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 375,
              columnNumber: 83
            }, this),
            /* @__PURE__ */ jsxDEV(Status, { value: check.status }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
              lineNumber: 375,
              columnNumber: 125
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 375,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", sx: layoutSx.detail.relatedContentGap, children: check.reason || "Không có ghi chú" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 376,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: check.checkedAt ? dateTime(check.checkedAt, shop.timezone) : "Chưa kiểm tra thực tế" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 377,
            columnNumber: 29
          }, this)
        ] }, check.component, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 374,
          columnNumber: 66
        }, this)) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 373,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 372,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.surface.sectionBefore, children: "Chỉ hiển thị lịch sử bản tin theo hợp đồng hiện hành. Chưa có API tạo/sửa lịch bản tin; không dựng nút lưu lịch giả." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 381,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 371,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 357,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Phục hồi & sẵn sàng triển khai", subtitle: "Bảng kiểm hiển thị rõ những điều chưa được xác minh trong bản frontend demo.", beforeGap: "section", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(SurfaceContent, { "data-testid": "readiness-preview", children: [
      /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Chưa có nguồn readiness/restore trong API hiện hành. Các mục bên dưới giữ trạng thái chưa xác minh và không thể cấp tín hiệu cho phép phát hành." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 386,
        columnNumber: 17
      }, this),
      [
        ["Diễn tập khôi phục bản sao lưu", "Chưa xác minh"],
        ["Kiểm tra freshness của artifact và revision", "Chưa xác minh"],
        ["Gates triển khai và kết quả CI", "Chưa xác minh"],
        ["Môi trường/provider sau khi khôi phục", "Chưa xác minh"]
      ].map(([criterion, status]) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.detail.valueGap, layoutSx.detail.rowInsetBlock, { display: "flex", justifyContent: "space-between", flexWrap: "wrap", borderBottom: 1, borderColor: "divider" }], children: [
        /* @__PURE__ */ jsxDEV(Typography, { children: criterion }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 393,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "warning.main", children: status }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 394,
          columnNumber: 21
        }, this)
      ] }, criterion, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 392,
        columnNumber: 38
      }, this)),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: "Có bản sao lưu không chứng minh đã khôi phục thành công. Không có nút “sẵn sàng” trong chế độ mô phỏng." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 396,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 385,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 384,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Quyền dừng vai trò AI", subtitle: "Lệnh được mô phỏng theo version của từng vai trò; tiếp tục không đồng nghĩa hệ thống đã sẵn sàng.", beforeGap: "section", bodyMode: "inset", children: [
      /* @__PURE__ */ jsxDEV(QueryState, { query: health, children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.detail.relatedItemGap, children: health.data?.data.roles.map((role) => /* @__PURE__ */ jsxDEV(Box, { sx: [layoutSx.detail.valueGap, layoutSx.detail.rowInsetBlock, { display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", borderBottom: 1, borderColor: "divider" }], children: [
        /* @__PURE__ */ jsxDEV(Stack, { children: [
          /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.semibold, children: roleNames[role.kind] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 403,
            columnNumber: 32
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
            "Thế hệ ",
            role.generation,
            " · ",
            role.status === "paused" ? "Đang tạm dừng" : role.status === "not_configured" ? "Chưa cấu hình" : role.status
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
            lineNumber: 403,
            columnNumber: 132
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 403,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "bot.pause", color: role.status === "paused" ? "primary" : "error", onClick: () => setStop({ role, action: role.status === "paused" ? "resume" : "pause" }), children: role.status === "paused" ? "Kiểm tra điều kiện tiếp tục" : "Tạm dừng vai trò" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
          lineNumber: 404,
          columnNumber: 25
        }, this)
      ] }, role.id, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 402,
        columnNumber: 60
      }, this)) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 401,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 400,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: control.error }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
        lineNumber: 408,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 399,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: Boolean(stop), title: stop?.action === "pause" ? "Tạm dừng vai trò AI" : "Kiểm tra điều kiện tiếp tục", confirmLabel: stop?.action === "pause" ? "Tạm dừng vai trò" : "Kiểm tra để tiếp tục", description: `${stop ? roleNames[stop.role.kind] : ""} (${stop?.role.id || ""}) trong ${shop.name}: ${stop?.action === "pause" ? "dừng các tác động chưa được tiếp nhận." : "kiểm điều kiện và chính sách trước khi cho phép tác động mới."} Tác động bên ngoài đã được nhận không thể thu hồi.`, requireReason: true, onClose: () => setStop(null), error: control.error, busy: control.pending, onConfirm: (reason) => control.execute({ body: { expectedVersion: stop?.role.version || 1, scope: "role", resourceId: stop?.role.id || null, action: stop?.action || "pause", reason } }) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
      lineNumber: 410,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx",
    lineNumber: 354,
    columnNumber: 10
  }, this);
}
_s4(DigestsPage, "f/DV1rPVitGbYIaoblZHJHbiYEs=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand];
});
_c4 = DigestsPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "OperationsPage");
$RefreshReg$(_c2, "ApprovalsPage");
$RefreshReg$(_c3, "PurchaseDelegationsPanel");
$RefreshReg$(_c4, "DigestsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/operations/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RRLFNBMEJzQixVQTFCdEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdERSLFNBQVFBLFNBQVNDLHFCQUFvQjtBQUNyQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsYUFBYUMsWUFBWUMsYUFBYUMsc0JBQXNCO0FBQ3JFLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQzNFLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxRQUFRQyxhQUFhQyxrQkFBa0I7QUFDaEQsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUMsU0FBU0MsWUFBWUMsT0FBT0MsT0FBT0MsTUFBTUMsV0FBV0MsWUFBWUMsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxZQUFZQyxhQUFhQyxXQUFXQyxRQUFRQyxZQUFZQyxlQUFlQyxzQkFBc0I7QUFFck0sTUFBTUMsa0JBQWtCLENBQUMsU0FBUyxZQUFZLFNBQVMsVUFBVTtBQUVqRSxNQUFNQyxZQUErQztBQUFBLEVBQ2pEQyxhQUFhO0FBQUEsRUFDYkMsWUFBWTtBQUFBLEVBQ1pDLGlCQUFpQjtBQUFBLEVBQ2pCQyxZQUFZO0FBQ2hCO0FBRU8sZ0JBQVNDLGlCQUFpQjtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sRUFBRUMsTUFBTUMsUUFBUSxJQUFJL0IsU0FBUztBQUNuQyxRQUFNZ0MsT0FBT25DLE9BQU8saUJBQWlCLEVBQUVvQyxPQUFPL0IsYUFBYSxlQUFlLEVBQUUsQ0FBQztBQUM3RSxRQUFNZ0MsVUFBVXJDLE9BQU8sc0JBQXNCO0FBQzdDLFFBQU1zQyxRQUFRcEMsV0FBVyxpQkFBaUIsQ0FBQyxpQkFBaUIsZ0JBQWdCLHNCQUFzQixDQUFDO0FBQ25HLFFBQU1xQyxTQUFTckMsV0FBVyxrQkFBa0IsQ0FBQyxpQkFBaUIsc0JBQXNCLENBQUM7QUFDckYsUUFBTSxDQUFDc0MsTUFBTUMsT0FBTyxJQUFJbkQsU0FBMEIsSUFBSTtBQUN0RCxRQUFNLENBQUNvRCxRQUFRQyxTQUFTLElBQUlyRCxTQUF5QixPQUFPO0FBQzVELFFBQU0sQ0FBQ3NELFFBQVFDLFNBQVMsSUFBSXZELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN3RCxVQUFVQyxXQUFXLElBQUl6RCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDMEQsZ0JBQWdCQyxpQkFBaUIsSUFBSTNELFNBQVMsS0FBSztBQUMxRCxRQUFNNEQsbUJBQW1COUMsT0FBTyxnQkFBZ0I7QUFDaEQsUUFBTSxDQUFDK0MsbUJBQW1CQyxvQkFBb0IsSUFBSTlELFNBQVMsRUFBRSxHQUFHLENBQUMrRCxjQUFjQyxlQUFlLElBQUloRSxTQUFTLEVBQUU7QUFDN0dELFlBQVUsTUFBTTtBQUNaLFVBQU1rRSxRQUFRQyxPQUFPQyxXQUFXLE1BQU1ILGdCQUFnQkgsa0JBQWtCTyxLQUFLLENBQUMsR0FBRyxHQUFHO0FBQ3BGLFdBQU8sTUFBTUYsT0FBT0csYUFBYUosS0FBSztBQUFBLEVBQzFDLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUM7QUFDdEIsUUFBTVMsVUFBVTNELFlBQVksZUFBZSxFQUFFbUMsT0FBTyxFQUFFeUIsUUFBUSxVQUFVQyxHQUFHVCxnQkFBZ0JVLE9BQVUsRUFBRSxHQUFHYixnQkFBZ0I7QUFDMUgsUUFBTWMsbUJBQW1CeEIsTUFBTXlCLGVBQWVDLE9BQU8sQ0FBQ0MsY0FBMkMxQyxnQkFBZ0IyQyxTQUFTRCxTQUEyQixNQUFNQSxjQUFjLGNBQWNFLFFBQVFULFFBQVFVLE1BQU1BLEtBQUtDLFVBQVVYLFFBQVFZLE9BQU8sRUFBRSxLQUFLO0FBQ2xQLFFBQU1DLFlBQVl0QyxLQUFLbUMsTUFBTUEsUUFBUTtBQUNyQyxRQUFNSSxPQUFPdkMsS0FBS21DLE1BQU1LLEtBQUtEO0FBQzdCLFFBQU1FLGNBQWNBLENBQUNDLFNBQW1CO0FBQ3BDLFFBQUlBLEtBQUtDLFVBQVUsZUFBZUQsS0FBS0MsVUFBVSxZQUFhLFFBQU87QUFDckUsVUFBTUMsVUFBVVYsUUFBUVEsS0FBS0csU0FBU04sUUFBUU8sS0FBS0MsTUFBTUwsS0FBS0csS0FBSyxLQUFLQyxLQUFLQyxNQUFNUixJQUFJLENBQUM7QUFDeEYsVUFBTVMsWUFBWU4sS0FBS0MsVUFBVSxZQUFZLENBQUNELEtBQUtPO0FBQ25ELFdBQU9QLEtBQUtDLFVBQVUsYUFBYUMsV0FBV0ksYUFBYU4sS0FBS1EsU0FBUztBQUFBLEVBQzdFO0FBQ0EsUUFBTUMsaUJBQWlCYixVQUFVUCxPQUFPVSxXQUFXO0FBQ25ELFFBQU1XLGVBQWV2QyxpQkFBaUJzQyxpQkFBaUJiO0FBRXZELFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0scUJBQW9CLFVBQVMsNERBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUc7QUFBQSxJQUN2Ryx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJMUUsU0FBU3lGLE9BQU9DLFVBQVUsa0hBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUo7QUFBQSxJQUN2Six1QkFBQyxjQUFXLE9BQU9wRCxTQUFTLGdCQUFlLFdBQ3RDQSxrQkFBUWlDLFFBQVEsdUJBQUMsU0FDZDtBQUFBLDZCQUFDLFFBQUssT0FBTSxzQkFBcUIsT0FBT2pDLFFBQVFpQyxLQUFLQSxLQUFLb0IsYUFBYSxRQUFNLFFBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkU7QUFBQSxNQUM3RSx1QkFBQyxRQUFLLE9BQU0sV0FBVSxPQUFPckQsUUFBUWlDLEtBQUtBLEtBQUtxQixnQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFFBQUssT0FBTSxpQkFBZ0IsT0FBT3RELFFBQVFpQyxLQUFLQSxLQUFLc0Isb0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxRQUFLLE9BQU0sbUJBQWtCLE9BQU92RCxRQUFRaUMsS0FBS0EsS0FBS3VCLG1CQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsU0FKMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtqQixLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsZUFBWSxPQUFPdkQsTUFBTXdELFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0M7QUFBQSxJQUNoQyx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsa0JBQWUsVUFBUyxnQkFBZSxlQUFZLHdCQUNoRDtBQUFBLCtCQUFDLFNBQU0sV0FBVyxFQUFFQyxJQUFJLFVBQVVDLElBQUksTUFBTSxHQUFHLGdCQUFlLGlCQUFnQixZQUFZLEVBQUVELElBQUksV0FBV0MsSUFBSSxTQUFTLEdBQUcsSUFBSWpHLFNBQVNrRyxRQUFRQyxlQUM1STtBQUFBLGlDQUFDLE9BQ0c7QUFBQSxtQ0FBQyxjQUFXLFlBQVkzRyxTQUFTNEcsV0FBV0MsV0FBV0MsUUFBUSxpQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRix1QkFBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGtCQUFpQiwrSUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0w7QUFBQSxlQUZ0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFNBQVNyRCxpQkFBaUIsY0FBYyxZQUFZLGdCQUFjQSxnQkFBZ0IsU0FBUyxNQUFNQyxrQkFBa0IsQ0FBQXFELFVBQVMsQ0FBQ0EsS0FBSyxHQUNySXRELDJCQUFpQix1QkFBdUJ5QixVQUFVRixNQUFNLE1BQU0scUJBQXFCZSxlQUFlZixNQUFNLE9BRDdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0N2QixrQkFBa0JzQyxlQUFlZixXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFdBQVUsK0RBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQVYvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFdBQVEsV0FBVSxtQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2xDLHVCQUFDLGNBQVcsT0FBT3BDLE1BQU0sZ0JBQWUsV0FDbkNBLGVBQUttQyxRQUFRLG1DQUNWO0FBQUEsK0JBQUMsYUFBVSxPQUFNLHNCQUFxQixNQUFNaUIsY0FBYyxRQUFRLENBQUFWLFNBQVFBLEtBQUswQixJQUFJLFNBQVM7QUFBQSxVQUN4RjtBQUFBLFlBQ0lDLEtBQUs7QUFBQSxZQUFRMUgsT0FBTztBQUFBLFlBQWEySCxRQUFRQSxDQUFBNUIsU0FBUSx1QkFBQyxTQUM5QztBQUFBLHFDQUFDLGNBQVcsWUFBWXRGLFNBQVM0RyxXQUFXQyxXQUFXQyxRQUFTeEIsZUFBS1EsU0FBUyxrQkFBa0Isc0JBQXNCUixLQUFLUSxTQUFTLHFCQUFxQix5QkFBeUJSLEtBQUtRLFNBQVMscUJBQXFCLHdCQUF3QlIsS0FBS1EsU0FBUyxrQkFBa0Isb0JBQW9CdEcsY0FBYzhGLEtBQUtRLElBQUksS0FBeFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMFQ7QUFBQSxjQUMxVCx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFrQlI7QUFBQUEscUJBQUs2QixPQUFPQztBQUFBQSxnQkFBSztBQUFBLGdCQUFJOUIsS0FBSzZCLE9BQU9IO0FBQUFBLG1CQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRjtBQUFBLGlCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdqRDtBQUFBLFVBQ0o7QUFBQSxVQUNBLEVBQUVDLEtBQUssVUFBVTFILE9BQU8sY0FBYzJILFFBQVFBLENBQUE1QixTQUFRLHVCQUFDLFVBQU8sT0FBT0EsS0FBS0MsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsRUFBSTtBQUFBLFVBQ3BGLEVBQUUwQixLQUFLLFlBQVkxSCxPQUFPLGNBQWMySCxRQUFRQSxDQUFBNUIsU0FBUUEsS0FBS08sbUJBQW1CbEQsUUFBUTBFLEtBQUtMLEtBQUssUUFBUTFCLEtBQUtPLGtCQUFrQixVQUFVO0FBQUEsVUFDM0ksRUFBRW9CLEtBQUssT0FBTzFILE9BQU8sYUFBYTJILFFBQVFBLENBQUE1QixTQUFRQSxLQUFLRyxRQUFRekUsU0FBU3NFLEtBQUtHLE9BQU8vQyxLQUFLNEUsUUFBUSxJQUFJLGdCQUFnQjtBQUFBLFVBQ3JILEVBQUVMLEtBQUssVUFBVTFILE9BQU8sYUFBYTJILFFBQVFBLENBQUE1QixTQUFRQSxLQUFLaUMsaUJBQWlCLElBQUk7QUFBQSxVQUMvRTtBQUFBLFlBQ0lOLEtBQUs7QUFBQSxZQUFXMUgsT0FBTztBQUFBLFlBQUkySCxRQUFRQSxDQUFBNUIsU0FBUTtBQUN2QyxvQkFBTWtDLGdCQUFnQmxDLEtBQUtaLGVBQWVDLE9BQU8sQ0FBQUMsY0FBYTFDLGdCQUFnQjJDLFNBQVNELFNBQTJCLENBQUM7QUFDbkgscUJBQU8sdUJBQUMsZUFBWSxXQUFVLE9BQzFCO0FBQUEsdUNBQUMsa0JBQWUsWUFBVyxvQkFBbUIsZ0JBQWdCVSxLQUFLWixnQkFBZ0IsUUFBTyxTQUFRLE1BQU0zQixNQUFNMEUsU0FBUyxTQUFTLE1BQU0sS0FBSzFFLE1BQU0yRSxRQUFRLEVBQUVDLE1BQU0sRUFBRUMsWUFBWXRDLEtBQUswQixHQUFHLEdBQUdhLE1BQU0sRUFBRUMsaUJBQWlCeEMsS0FBS3lDLFFBQVEsRUFBRSxDQUFDLEVBQUVDLE1BQU0sTUFBTXhELE1BQVMsR0FBRyw2QkFBN1A7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMFE7QUFBQSxnQkFDelFjLEtBQUtRLFNBQVMsbUJBQW1CLHVCQUFDLGFBQVUsSUFBSSxNQUFNcEQsS0FBS3NFLEVBQUUsZ0JBQWdCLDZCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUMxRjFCLEtBQUtRLFNBQVMsbUJBQW1CMEIsY0FBY3hDLFNBQVMsS0FBSyx1QkFBQyxrQkFBZSxZQUFXLHFCQUFvQixTQUFTLE1BQU07QUFDeEg5QiwwQkFBUW9DLElBQUk7QUFDWmhDLDRCQUFVLEVBQUU7QUFDWkUsOEJBQVksRUFBRTtBQUNkSiw0QkFBVW9FLGNBQWMsQ0FBQyxDQUFtQjtBQUM1Q3hFLHlCQUFPaUYsV0FBVztBQUFBLGdCQUN0QixHQUFHLHdCQU4yRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1uRDtBQUFBLGdCQUNYLHVCQUFDLGNBQVcsU0FBUSxXQUFVLE9BQU0sa0JBQWlCLElBQUksRUFBRUMsV0FBVyxTQUFTLEdBQUc7QUFBQTtBQUFBLGtCQUFZNUMsS0FBS1osZUFBZU0sU0FBU00sS0FBS1osZUFBZXlELEtBQUssS0FBSyxJQUFJO0FBQUEscUJBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtMO0FBQUEsbUJBVi9LO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV1A7QUFBQSxZQUNKO0FBQUEsVUFDSjtBQUFBLFFBQUMsS0EzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCRTtBQUFBLFFBQ0YsdUJBQUMsU0FBTSxNQUFNdkYsS0FBS21DLEtBQUtxRCxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0E5QmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQmQsS0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUNuRixNQUFNLE9BQU0sc0JBQXFCLFNBQVMsTUFBTUMsUUFBUSxJQUFJLEdBQUcsTUFBTUYsT0FBT3lFLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUN4RSxRQUFRLENBQUN3QixpQkFBaUJJLFNBQVMxQixNQUFNLEtBQUtwQyxnQkFBZ0JzQyxPQUFPYyxLQUFLLENBQUMsSUFBSSxLQUFNaEIsV0FBVyxjQUFjLENBQUNJLFlBQWFQLE9BQU95RSxTQUFTLFNBQVMsWUFBWTtBQUN0VCxVQUFJLENBQUN4RSxRQUFRLENBQUN3QixpQkFBaUJJLFNBQVMxQixNQUFNLEVBQUc7QUFDakQsVUFBSTtBQUNBLGNBQU1ILE9BQU8wRSxRQUFRLEVBQUVDLE1BQU0sRUFBRUMsWUFBWTNFLEtBQUsrRCxHQUFHLEdBQUdhLE1BQU0sRUFBRUMsaUJBQWlCN0UsS0FBSzhFLFNBQVM1RSxRQUFRRSxRQUFRLEdBQUlGLFdBQVcsYUFBYSxFQUFFMEMsZ0JBQWdCdEMsWUFBWSxLQUFLLElBQUksQ0FBQyxFQUFHLEVBQUUsQ0FBQztBQUN2TEwsZ0JBQVEsSUFBSTtBQUFBLE1BQ2hCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFDWixHQUFHLDJCQVArRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT3BHLEdBQ1Y7QUFBQSw2QkFBQyxlQUFZLE9BQU9GLE9BQU91RCxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsY0FDRztBQUFBLCtCQUFDLGNBQVl0RCxnQkFBTWtFLE9BQU9ILE1BQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUM1QnZDLGlCQUFpQk8sU0FBUyxLQUFLLHVCQUFDLGFBQVUsT0FBTSx1QkFBc0IsUUFBTSxNQUFDLE9BQU9QLGlCQUFpQkksU0FBUzFCLE1BQU0sSUFBSUEsU0FBU3NCLGlCQUFpQixDQUFDLEdBQUcsVUFBVSxDQUFBNEQsVUFBU2pGLFVBQVVpRixNQUFNQyxPQUFPdkIsS0FBdUIsR0FDbk50QywyQkFBaUI4RCxJQUFJLENBQUF4QixVQUFTLHVCQUFDLFlBQXFCLE9BQWVBLG9CQUFVLFVBQVUsa0JBQWtCQSxVQUFVLGFBQWEsZUFBZUEsVUFBVSxVQUFVLHFCQUFxQiw0QkFBM0lBLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTCxDQUFXLEtBRGpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFaEM7QUFBQSxRQUNDNUQsV0FBVyxjQUFjLG1DQUN0QjtBQUFBLGlDQUFDLGFBQVUsT0FBTSxpQ0FBZ0MsT0FBT1MsbUJBQW1CLFVBQVUsQ0FBQXlFLFVBQVN4RSxxQkFBcUJ3RSxNQUFNQyxPQUFPdkIsS0FBSyxHQUFHLFVBQVUsQ0FBQ3BELGtCQUFrQixZQUFXLDhEQUFoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwTztBQUFBLFVBQzFPLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sbUJBQWtCLE9BQU9KLFVBQVUsVUFBVSxDQUFBOEUsVUFBUzdFLFlBQVk2RSxNQUFNQyxPQUFPdkIsS0FBSyxHQUFHLFVBQVUsQ0FBQ3BELG9CQUFxQlUsUUFBUW1FLGFBQWEsQ0FBQ25FLFFBQVFVLE1BQ3hLeEI7QUFBQUEsd0JBQVksQ0FBQ2MsUUFBUVUsTUFBTUEsS0FBSzBELEtBQUssQ0FBQUMsV0FBVUEsT0FBT0MsV0FBV3BGLFFBQVEsS0FBSyx1QkFBQyxZQUFTLE9BQU9BLFVBQVdBLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ25IYyxRQUFRVSxNQUFNQSxLQUFLSixPQUFPLENBQUErRCxXQUFVQSxPQUFPcEUsV0FBVyxRQUFRLEVBQUVpRSxJQUFJLENBQUFHLFdBQVUsdUJBQUMsWUFBeUIsT0FBT0EsT0FBT0MsUUFBU0QsaUJBQU9DLFVBQXpDRCxPQUFPMUIsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0QsQ0FBVztBQUFBLGVBRjdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLGtCQUFlLE9BQU0sY0FBYSxhQUFhM0MsUUFBUXVFLGFBQWEsU0FBU3ZFLFFBQVFZLFNBQVMsTUFBTVosUUFBUXdFLGVBQWUsWUFBWXhFLFFBQVF5RSxZQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SjtBQUFBLFVBQ3hKekUsUUFBUTBFLFdBQVcsdUJBQUMsa0JBQWdCO0FBQUEsbUNBQUMsZUFBWSxPQUFPMUUsUUFBUWtDLFNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFBRSx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU07QUFBRSxvQkFBTWxDLFFBQVEyRSx1QkFBdUIzRSxRQUFReUUsU0FBUyxJQUFJekUsUUFBUTRFLFFBQVE7QUFBQSxZQUFJLEdBQUcsNENBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1KO0FBQUEsZUFBeE07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaU47QUFBQSxhQVAvTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUTFCO0FBQUEsUUFDQSx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBTzVGLFFBQVEsVUFBVSxDQUFBZ0YsVUFBUy9FLFVBQVUrRSxNQUFNQyxPQUFPdkIsS0FBSyxLQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlIO0FBQUEsV0FkN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLE9BdEZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RlA7QUFDSjtBQUFDdEUsR0F0SGVELGdCQUFjO0FBQUEsVUFDQTVCLFVBQ2JILFFBQWlDSyxjQUM5QkwsUUFDRkUsWUFDQ0EsWUFNVUUsUUFNVEgsV0FBVztBQUFBO0FBQUEsS0FqQmY4QjtBQXdIVCxnQkFBUzBHLGdCQUFnQjtBQUFBQyxNQUFBO0FBQzVCLFFBQU0sRUFBRXpHLEtBQUssSUFBSTlCLFNBQVM7QUFDMUIsUUFBTWdDLE9BQU9uQyxPQUFPLGlCQUFpQixFQUFFb0MsT0FBTy9CLGFBQWEsZUFBZSxFQUFFLENBQUM7QUFDN0UsUUFBTSxDQUFDc0ksWUFBWUMsYUFBYSxJQUFJdEosU0FBd0IsSUFBSTtBQUNoRSxRQUFNdUosU0FBUzdJLE9BQU8sZUFBZSxFQUFFa0gsTUFBTSxFQUFFQyxZQUFZd0IsY0FBYyxHQUFHLEVBQUUsR0FBR3RFLFFBQVFzRSxVQUFVLENBQUM7QUFDcEcsUUFBTUcsU0FBUzVJLFdBQVcsa0JBQWtCLENBQUMsZUFBZSxpQkFBaUIsc0JBQXNCLHNCQUFzQixDQUFDO0FBQzFILFFBQU0sQ0FBQzZJLFVBQVVDLFdBQVcsSUFBSTFKLFNBQStCLFNBQVM7QUFDeEUsUUFBTSxDQUFDc0QsUUFBUUMsU0FBUyxJQUFJdkQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0ySixXQUFXSixPQUFPdkUsTUFBTUE7QUFDOUIsUUFBTTRFLGVBQWVMLE9BQU92RSxNQUFNSyxLQUFLRDtBQUN2QyxRQUFNeUUsaUJBQWlCOUUsUUFBUTZFLFlBQVk7QUFDM0MsUUFBTUUsVUFBVUgsV0FBVyxDQUFDQyxnQkFBZ0JqRSxLQUFLQyxNQUFNK0QsU0FBU0ksU0FBUyxLQUFLcEUsS0FBS0MsTUFBTWdFLFlBQVksSUFBSTtBQUV6RyxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFTLG9HQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJJO0FBQUEsSUFDM0ksdUJBQUMsZ0JBQ0c7QUFBQSw2QkFBQyxTQUNEO0FBQUEsK0JBQUMsV0FBUSxXQUFVLG1CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsY0FBVyxPQUFPL0csTUFBTSxnQkFBZSxXQUNuQ0EsZUFBS21DLFFBQVEsbUNBQ1Y7QUFBQSxpQ0FBQyxhQUFVLE9BQU0scUJBQW9CLE1BQU1uQyxLQUFLbUMsS0FBS0EsTUFBTSxRQUFRLENBQUFnRixVQUFTQSxNQUFNL0MsSUFBSSxTQUFTO0FBQUEsWUFDM0YsRUFBRUMsS0FBSyxVQUFVMUgsT0FBTyxZQUFZMkgsUUFBUUEsQ0FBQTZDLFVBQVMsdUJBQUMsU0FBTTtBQUFBLHFDQUFDLGNBQVcsWUFBWS9KLFNBQVM0RyxXQUFXQyxXQUFXQyxRQUFTdEgsd0JBQWN1SyxNQUFNNUcsTUFBTSxLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RjtBQUFBLGNBQWEsdUJBQUMsY0FBVyxTQUFRLFdBQVczRDtBQUFBQSw4QkFBY3VLLE1BQU1DLFNBQVM1QyxJQUFJO0FBQUEsZ0JBQUU7QUFBQSxnQkFBSTJDLE1BQU01RztBQUFBQSxnQkFBTztBQUFBLGdCQUFrQjRHLE1BQU1DLFNBQVNoRDtBQUFBQSxtQkFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUg7QUFBQSxpQkFBdk87QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb1AsRUFBUztBQUFBLFlBQ2xULEVBQUVDLEtBQUssVUFBVTFILE9BQU8sV0FBVzJILFFBQVFBLENBQUE2QyxVQUFTLHVCQUFDLFVBQU8sT0FBT0EsTUFBTUUsVUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEIsRUFBSTtBQUFBLFlBQ3BGLEVBQUVoRCxLQUFLLFNBQVMxSCxPQUFPLGNBQWMySCxRQUFRQSxDQUFBNkMsVUFBUyx1QkFBQyxVQUFPLE9BQU9BLE1BQU16RixVQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QixFQUFJO0FBQUEsWUFDdEYsRUFBRTJDLEtBQUssT0FBTzFILE9BQU8sV0FBVzJILFFBQVFBLENBQUE2QyxVQUFTL0ksU0FBUytJLE1BQU1ELFdBQVdwSCxLQUFLNEUsUUFBUSxFQUFFO0FBQUEsWUFDMUY7QUFBQSxjQUNJTCxLQUFLO0FBQUEsY0FBVzFILE9BQU87QUFBQSxjQUFJMkgsUUFBUUEsQ0FBQTZDLFVBQVMsdUJBQUMsa0JBQWUsWUFBVyxvQkFBbUIsVUFBVUEsTUFBTXpGLFdBQVcsV0FBVyxTQUFTLE1BQU07QUFDM0krRSw4QkFBY1UsTUFBTS9DLEVBQUU7QUFDdEIxRCwwQkFBVSxFQUFFO0FBQ1ptRyw0QkFBWSxTQUFTO0FBQ3JCRix1QkFBT3RCLFdBQVc7QUFBQSxjQUN0QixHQUFHLGdDQUx5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUt6QjtBQUFBLFlBQ3ZCO0FBQUEsVUFBQyxLQVpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUU7QUFBQSxVQUNGLHVCQUFDLFNBQU0sTUFBTXJGLEtBQUttQyxLQUFLcUQsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQWZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JkLEtBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQXBCQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFDQSx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsU0F2QjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsTUFBTXRELFFBQVFzRSxVQUFVLEdBQUcsT0FBTSxxQkFBb0IsU0FBUyxNQUFNQyxjQUFjLElBQUksR0FBRyxNQUFNRSxPQUFPOUIsU0FBUyxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsb0JBQW1CLFNBQVEsYUFBWSxNQUFNOEIsT0FBTzlCLFNBQVMsVUFBVSxDQUFDaUMsWUFBWUosT0FBT2QsYUFBYWtCLFNBQVNwRixXQUFXLGFBQWF1RixXQUFXOUksZ0JBQWdCc0MsT0FBT2MsS0FBSyxDQUFDLElBQUksR0FBRyxTQUFTLFlBQVk7QUFDeFcsVUFBSSxDQUFDdUYsWUFBWUEsU0FBU3BGLFdBQVcsYUFBYXVGLFFBQVM7QUFDM0QsVUFBSTtBQUNBLGNBQU1OLE9BQU83QixRQUFRLEVBQUVDLE1BQU0sRUFBRUMsWUFBWThCLFNBQVMxQyxHQUFHLEdBQUdhLE1BQU0sRUFBRUMsaUJBQWlCNEIsU0FBUzNCLFNBQVNtQyxZQUFZUixTQUFTUSxZQUFZVixVQUFVbkcsT0FBTyxFQUFFLENBQUM7QUFDMUpnRyxzQkFBYyxJQUFJO0FBQUEsTUFDdEIsUUFDTTtBQUFBLE1BQUU7QUFBQSxJQUNaLEdBQUlHLHVCQUFhLFlBQVksNEJBQTRCLGFBUDJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPakUsR0FDL0Q7QUFBQSw2QkFBQyxlQUFZLE9BQU9ELE9BQU9oRCxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsY0FBVyxPQUFPK0MsUUFDZEksc0JBQVksdUJBQUMsY0FDVjtBQUFBLCtCQUFDLFNBQU0sVUFBUyxXQUFVLGlJQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFDMUksQ0FBQ0Usa0JBQWtCLHVCQUFDLFNBQU0sVUFBUyxTQUFRLGdHQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdHO0FBQUEsUUFDM0hDLFdBQVcsdUJBQUMsU0FBTSxVQUFTLFNBQVEsK0VBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxRQUNsR0gsU0FBU3BGLFdBQVcsYUFBYSx1QkFBQyxTQUFNLFVBQVMsUUFBTztBQUFBO0FBQUEsVUFBOEI5RSxjQUFja0ssU0FBU3BGLE1BQU07QUFBQSxVQUFFO0FBQUEsYUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFFBQ2xKLHVCQUFDLGNBQVcsT0FBTSxhQUFhOUUsd0JBQWNrSyxTQUFTdkcsTUFBTSxLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsUUFDOUQsdUJBQUMsY0FBVyxPQUFNLGFBQWF1RztBQUFBQSxtQkFBU00sU0FBUzVDO0FBQUFBLFVBQUs7QUFBQSxVQUFrQnNDLFNBQVNNLFNBQVNoRDtBQUFBQSxVQUFHO0FBQUEsVUFBYzBDLFNBQVNTO0FBQUFBLGFBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0k7QUFBQSxRQUNwSSx1QkFBQyxjQUFXLE9BQU0sY0FBY1QsbUJBQVNVLGlCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVEO0FBQUEsUUFDdkQsdUJBQUMsY0FBVyxPQUFNLGlCQUFnQjtBQUFBO0FBQUEsVUFBYVYsU0FBU1c7QUFBQUEsYUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFLHVCQUFDLGNBQVcsT0FBTSxXQUFVLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9YLFNBQVNPLFVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0MsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FLHVCQUFDLGNBQVcsT0FBTSxnQkFBZ0JqSixtQkFBUzBJLFNBQVNJLFdBQVdwSCxLQUFLNEUsUUFBUSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDN0VvQyxTQUFTWSxhQUFhLHVCQUFDLGNBQVcsT0FBTSxvQkFBbUI7QUFBQTtBQUFBLFVBQWFaLFNBQVNZO0FBQUFBLGFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUMzRlosU0FBU2Esa0JBQWtCLHVCQUFDLGNBQVcsT0FBTSxxQkFBcUJiLG1CQUFTYSxrQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQzNGLHVCQUFDLGNBQVcsU0FBUSxXQUFVLElBQUksRUFBRUMsY0FBYyxXQUFXLEdBQUc7QUFBQTtBQUFBLFVBQWdCZCxTQUFTUTtBQUFBQSxhQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsUUFDcEcsdUJBQUMsYUFBVSxPQUFNLGNBQWEsUUFBTSxNQUFDLE9BQU9WLFVBQVUsVUFBVSxDQUFBbkIsVUFBU29CLFlBQVlwQixNQUFNQyxPQUFPdkIsS0FBd0IsR0FBRyxVQUFVMkMsU0FBU3BGLFdBQVcsYUFBYXVGLFNBQ3BLO0FBQUEsaUNBQUMsWUFBUyxPQUFNLFdBQVUscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsWUFBUyxPQUFNLFVBQVMsdUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsYUFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLE9BQU0sb0JBQW1CLFdBQVMsTUFBQyxTQUFTLEdBQUcsT0FBT3hHLFFBQVEsVUFBVSxDQUFBZ0YsVUFBUy9FLFVBQVUrRSxNQUFNQyxPQUFPdkIsS0FBSyxHQUFHLFVBQVUyQyxTQUFTcEYsV0FBVyxhQUFhdUYsV0FBdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4SztBQUFBLFdBbEJySztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJiLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsT0ExREc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJEUDtBQUNKO0FBQUNWLElBekVlRCxlQUFhO0FBQUEsVUFDUnRJLFVBQ0pILFFBQWlDSyxjQUUvQkwsUUFDQUUsVUFBVTtBQUFBO0FBQUEsTUFMYnVJO0FBMkVoQixTQUFTdUIsMkJBQTJCO0FBQUFDLE1BQUE7QUFDaEMsUUFBTSxFQUFFaEksTUFBTUMsUUFBUSxJQUFJL0IsU0FBUztBQUNuQyxRQUFNK0osVUFBVTlKLE9BQU8sa0JBQWtCO0FBQ3pDLFFBQU0rSixZQUFZL0osT0FBTywrQkFBK0I7QUFDeEQsUUFBTWdLLFNBQVNwSyxPQUFPLDJCQUEyQixFQUFFb0MsT0FBTyxFQUFFaUksT0FBTyxHQUFHLEVBQUUsR0FBR0gsT0FBTztBQUNsRixRQUFNSSxlQUFldEssT0FBTyxzQ0FBc0MsRUFBRW9DLE9BQU8sRUFBRWlJLE9BQU8sR0FBRyxFQUFFLEdBQUdGLFNBQVM7QUFDckcsUUFBTUksU0FBU3RLLFlBQVksa0JBQWtCLENBQUMsR0FBR2tLLFNBQVM7QUFDMUQsUUFBTUssWUFBWXZLLFlBQVksaUJBQWlCLENBQUMsR0FBR2tLLFNBQVM7QUFDNUQsUUFBTU0sYUFBYXhLLFlBQVksa0JBQWtCLEVBQUVtQyxPQUFPLEVBQUV5QixRQUFRLFNBQVMsRUFBRSxHQUFHc0csU0FBUztBQUMzRixRQUFNTyxTQUFTekssWUFBWSxzQkFBc0IsQ0FBQyxHQUFHa0ssU0FBUztBQUM5RCxRQUFNUSxVQUFVMUssWUFBWSxzQkFBc0IsQ0FBQyxHQUFHa0ssU0FBUztBQUMvRCxRQUFNUyxrQkFBa0I1SyxPQUFPLGlCQUFpQixFQUFFb0MsT0FBTyxFQUFFaUksT0FBTyxJQUFJLEVBQUUsR0FBR0YsU0FBUztBQUNwRixRQUFNVSxTQUFTM0ssV0FBVyw0QkFBNEIsQ0FBQyx5QkFBeUIsQ0FBQztBQUNqRixRQUFNcUMsU0FBU3JDLFdBQVcsNEJBQTRCLENBQUMsMkJBQTJCLHNDQUFzQyxvQkFBb0IseUJBQXlCLENBQUM7QUFDdEssUUFBTSxDQUFDNEssWUFBWUMsYUFBYSxJQUFJekwsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzBMLFNBQVNDLFVBQVUsSUFBSTNMLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM0TCxZQUFZQyxhQUFhLElBQUk3TCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOEwsYUFBYUMsY0FBYyxJQUFJL0wsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2dNLFVBQVVDLFdBQVcsSUFBSWpNLFNBQW1CLEVBQUU7QUFDckQsUUFBTSxDQUFDa00sVUFBVUMsV0FBVyxJQUFJbk0sU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29NLGFBQWFDLGNBQWMsSUFBSXJNLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMrSixXQUFXdUMsWUFBWSxJQUFJdE0sU0FBUyxNQUFNdU0sbUJBQW1CNUcsS0FBSzZHLElBQUksSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUksQ0FBQztBQUN6RyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSTFNLFNBQW9DLElBQUk7QUFDOUUsUUFBTSxDQUFDMk0sY0FBY0MsZUFBZSxJQUFJNU0sU0FBMEMsUUFBUTtBQUMxRixRQUFNNk0sY0FBYzVCLE9BQU9qRyxNQUFNQSxLQUFLSixPQUFPLENBQUFrSSxVQUFTQSxNQUFNL0csU0FBUyxxQkFBcUIrRyxNQUFNQyxpQkFBaUJuSyxRQUFRMEUsS0FBS0wsRUFBRSxLQUFLO0FBQ3JJLFFBQU0rRixvQkFBb0I5QixVQUFVbEcsTUFBTUEsS0FBS0osT0FBTyxDQUFBcUksYUFBWUEsU0FBUzFJLFdBQVcsVUFBVSxLQUFLO0FBQ3JHLFFBQU0ySSxpQkFBaUI5QixPQUFPcEcsTUFBTUEsS0FBS0osT0FBTyxDQUFBdUksVUFBU0EsTUFBTXZCLGVBQWVBLFVBQVUsS0FBSztBQUM3RixRQUFNd0IscUJBQXFCL0IsUUFBUXJHLE1BQU1BLEtBQUtKLE9BQU8sQ0FBQ3lJLFdBQXlCQSxPQUFPdEgsU0FBUyxpQkFBaUJzSCxPQUFPQyxXQUFXLENBQUMsQ0FBQ0QsT0FBT0UsZUFBZSxDQUFDLENBQUNGLE9BQU9oRSxjQUFjLENBQUMsQ0FBQ2lDLGdCQUFnQnRHLE1BQU1LLEtBQUtELFFBQVFrRyxnQkFBZ0J0RyxLQUFLQSxLQUFLMEQsS0FBSyxDQUFBaUIsYUFBWUEsU0FBUzFDLE9BQU9vRyxPQUFPaEUsY0FBY00sU0FBU3BGLFdBQVcsY0FBY29GLFNBQVNNLFNBQVM1QyxTQUFTLG1CQUFtQnNDLFNBQVNNLFNBQVNoRCxPQUFPb0csT0FBT3BHLE1BQU0wQyxTQUFTUyxvQkFBb0JpRCxPQUFPckYsV0FBV3JDLEtBQUtDLE1BQU0rRCxTQUFTSSxTQUFTLElBQUlwRSxLQUFLQyxNQUFNMEYsZ0JBQWdCdEcsTUFBTUssS0FBS0QsUUFBUSxFQUFFLENBQUMsQ0FBRSxLQUFLO0FBQ3BpQixRQUFNb0ksaUJBQWlCSixtQkFBbUJLLEtBQUssQ0FBQUosV0FBVUEsT0FBT3BHLE9BQU9pRixRQUFRO0FBQy9FLFFBQU13QixjQUFjLFFBQVFDLEtBQUt2QixXQUFXLEtBQUt3QixPQUFPeEIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDb0IsZ0JBQWdCRCxlQUFlSyxPQUFPeEIsV0FBVyxLQUFLd0IsT0FBT0osZUFBZUQsWUFBWXJELE1BQU07QUFDNUssUUFBTTJELGNBQWNELE9BQU9FLFNBQVNuSSxLQUFLQyxNQUFNbUUsU0FBUyxDQUFDLEtBQUtwRSxLQUFLQyxNQUFNbUUsU0FBUyxJQUFJcEUsS0FBSzZHLElBQUk7QUFDL0YsUUFBTXVCLFlBQVksQ0FBQyxDQUFDckMsV0FBVyxDQUFDLENBQUNFLGNBQWMsQ0FBQyxDQUFDRSxlQUFlRSxTQUFTL0csU0FBUyxLQUFLLENBQUMsQ0FBQ3VJLGtCQUFrQkUsZUFBZUcsZUFBZSxDQUFDdEMsT0FBTzdEO0FBQ2pKLFFBQU1zRyxhQUFhQSxNQUFNO0FBQ3JCckMsZUFBV2tCLFlBQVksQ0FBQyxHQUFHNUYsTUFBTSxFQUFFO0FBQ25DNEUsa0JBQWMsRUFBRTtBQUNoQkUsbUJBQWVaLFdBQVduRyxNQUFNQSxLQUFLLENBQUMsR0FBR2lDLE1BQU0sRUFBRTtBQUNqRGdGLGdCQUFZLEVBQUU7QUFDZEUsZ0JBQVlpQixtQkFBbUIsQ0FBQyxHQUFHbkcsTUFBTSxFQUFFO0FBQzNDb0YsbUJBQWUsUUFBUTtBQUN2QkMsaUJBQWFDLG1CQUFtQjVHLEtBQUs2RyxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFJLENBQUM7QUFDckVqQixXQUFPckQsV0FBVztBQUNsQnVELGtCQUFjLElBQUk7QUFBQSxFQUN0QjtBQUNBLFFBQU13QyxZQUFZLFlBQVk7QUFDMUIsUUFBSSxDQUFDRixhQUFhLENBQUNQLGVBQWdCO0FBQ25DLFFBQUk7QUFDQSxZQUFNakMsT0FBTzVELFFBQVEsRUFBRUcsTUFBTTtBQUFBLFFBQ3pCNEQ7QUFBQUEsUUFBU0U7QUFBQUEsUUFBWUU7QUFBQUEsUUFBYUU7QUFBQUEsUUFDbENJLGFBQWEsRUFBRWxDLFFBQVFrQyxhQUFhOEIsVUFBVXZMLEtBQUt1TCxTQUFTO0FBQUEsUUFDNURDLGdCQUFnQmpDO0FBQUFBLFFBQVVuQyxXQUFXLElBQUlwRSxLQUFLb0UsU0FBUyxFQUFFcUUsWUFBWTtBQUFBLE1BQ3pFLEVBQUUsQ0FBQztBQUNIM0Msb0JBQWMsS0FBSztBQUFBLElBQ3ZCLFFBQ007QUFBQSxJQUFFO0FBQUEsRUFDWjtBQUNBLFFBQU00QyxhQUFhQSxDQUFDQyxVQUE4QjtBQUM5QyxVQUFNeEIsUUFBUTdCLE9BQU9qRyxNQUFNQSxLQUFLeUksS0FBSyxDQUFBYyxRQUFPQSxJQUFJdEgsT0FBT3FILE1BQU01QyxPQUFPO0FBQ3BFLFVBQU11QixXQUFXL0IsVUFBVWxHLE1BQU1BLEtBQUt5SSxLQUFLLENBQUFjLFFBQU9BLElBQUl0SCxPQUFPcUgsTUFBTTFDLFVBQVU7QUFDN0UsVUFBTTRDLFlBQVlyRCxXQUFXbkcsTUFBTUEsS0FBS3lJLEtBQUssQ0FBQWMsUUFBT0EsSUFBSXRILE9BQU9xSCxNQUFNeEMsV0FBVztBQUNoRixXQUFPLEdBQUdnQixPQUFPL0csT0FBTzNELFVBQVUwSyxNQUFNL0csSUFBSSxJQUFJLGVBQWV1SSxNQUFNNUMsT0FBTyxFQUFFLE1BQU11QixVQUFVd0IsUUFBUSxvQkFBb0JILE1BQU0xQyxVQUFVLEVBQUUsTUFBTTRDLFdBQVdDLFFBQVEsV0FBV0gsTUFBTXhDLFdBQVcsRUFBRTtBQUFBLEVBQ3ZNO0FBRUEsTUFBSSxDQUFDbEIsUUFBUyxRQUFPO0FBQ3JCLFNBQU8sdUJBQUMsU0FBTSxPQUFNLHdCQUF1QixVQUFTLGdJQUNoRDtBQUFBLDJCQUFDLFNBQU0sVUFBUyxRQUFPLElBQUluSyxTQUFTeUYsT0FBT0MsVUFBVSwwSUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErSztBQUFBLElBQzlLMEUsYUFBYSx1QkFBQyxlQUFZLFdBQVUsT0FBTSxXQUFVLFFBQU8saUNBQUMsa0JBQWUsWUFBVyxpQ0FBZ0MsU0FBU21ELFlBQVksd0NBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0csS0FBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SztBQUFBLElBQ3JMLHVCQUFDLGNBQVcsT0FBT2xELFFBQVEsZ0JBQWUsV0FBV0EsaUJBQU85RixRQUFRLHVCQUFDLGFBQVUsT0FBTSx3QkFBdUIsTUFBTThGLE9BQU85RixLQUFLQSxNQUFNLFFBQVEsQ0FBQXNKLFVBQVNBLE1BQU1ySCxJQUFJLFNBQVM7QUFBQSxNQUNwSyxFQUFFQyxLQUFLLFNBQVMxSCxPQUFPLFdBQVcySCxRQUFRQSxDQUFBbUgsVUFBUyx1QkFBQyxTQUFNO0FBQUEsK0JBQUMsY0FBVyxZQUFZck8sU0FBUzRHLFdBQVdDLFdBQVdDLFFBQVNzSCxxQkFBV0MsS0FBSyxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFBYSx1QkFBQyxjQUFXLFNBQVEsV0FBV0E7QUFBQUEsZ0JBQU1JLGVBQWV6SjtBQUFBQSxVQUFPO0FBQUEsVUFBbUJxSixNQUFNbEMsWUFBWWxDO0FBQUFBLFVBQU87QUFBQSxVQUFFb0UsTUFBTWxDLFlBQVk4QjtBQUFBQSxVQUFTO0FBQUEsYUFBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSTtBQUFBLFFBQWEsdUJBQUMsY0FBVyxTQUFRLFdBQVU7QUFBQTtBQUFBLFVBQTJCSSxNQUFNSDtBQUFBQSxVQUFlO0FBQUEsVUFBSUcsTUFBTUs7QUFBQUEsVUFBYTtBQUFBLFVBQVExTixTQUFTcU4sTUFBTXZFLFdBQVdwSCxLQUFLNEUsUUFBUTtBQUFBLGFBQXBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0o7QUFBQSxXQUFuWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdhLEVBQVM7QUFBQSxNQUM1ZCxFQUFFTCxLQUFLLFNBQVMxSCxPQUFPLGNBQWMySCxRQUFRQSxDQUFBbUgsVUFBUyx1QkFBQyxVQUFPLE9BQU8zSSxLQUFLQyxNQUFNMEksTUFBTXZFLFNBQVMsS0FBS3BFLEtBQUs2RyxJQUFJLEtBQUs4QixNQUFNL0osV0FBVyxXQUFXLFlBQVkrSixNQUFNL0osVUFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSCxFQUFHO0FBQUEsTUFDMUssRUFBRTJDLEtBQUssVUFBVTFILE9BQU8sa0JBQWtCMkgsUUFBUUEsQ0FBQW1ILFVBQVNBLE1BQU1NLGNBQWMsSUFBSTtBQUFBLE1BQ25GLEVBQUUxSCxLQUFLLFdBQVcxSCxPQUFPLElBQUkySCxRQUFRQSxDQUFBbUgsVUFBUyx1QkFBQyxlQUFZLFdBQVUsT0FDaEVBO0FBQUFBLGNBQU0vSixXQUFXLGFBQWFvQixLQUFLQyxNQUFNMEksTUFBTXZFLFNBQVMsSUFBSXBFLEtBQUs2RyxJQUFJLEtBQUssdUJBQUMsa0JBQWUsWUFBVyxpQ0FBZ0MsVUFBVXZKLE9BQU95RSxTQUFTLFNBQVMsTUFBTTtBQUFFZ0YseUJBQWU0QixLQUFLO0FBQUcxQiwwQkFBZ0IwQixNQUFNL0osV0FBVyxXQUFXLFdBQVcsUUFBUTtBQUFBLFFBQUcsR0FBSStKLGdCQUFNL0osV0FBVyxXQUFXLGFBQWEsZUFBNU87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3UDtBQUFBLFFBQ2xVK0osTUFBTS9KLFdBQVcsYUFBYSx1QkFBQyxrQkFBZSxZQUFXLGlDQUFnQyxPQUFNLFNBQVEsVUFBVXRCLE9BQU95RSxTQUFTLFNBQVMsTUFBTTtBQUFFZ0YseUJBQWU0QixLQUFLO0FBQUcxQiwwQkFBZ0IsU0FBUztBQUFBLFFBQUcsR0FBRyx1QkFBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTDtBQUFBLFdBRnRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHOUMsRUFBZTtBQUFBLElBQUMsS0FQZ0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFsRSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRSztBQUFBLElBQ0wsdUJBQUMsY0FBVyxPQUFPNUIsY0FBYyxnQkFBZSxXQUFXQSx1QkFBYWhHLFFBQVEsdUJBQUMsYUFBVSxPQUFNLCtCQUE4QixNQUFNZ0csYUFBYWhHLEtBQUtBLE1BQXlDLFFBQVEsQ0FBQXVKLFFBQU9BLElBQUl0SCxJQUFJLFNBQVM7QUFBQSxNQUM1TixFQUFFQyxLQUFLLFlBQVkxSCxPQUFPLFdBQVcySCxRQUFRQSxDQUFBb0gsUUFBT0EsSUFBSU0sZ0JBQWdCO0FBQUEsTUFDeEUsRUFBRTNILEtBQUssVUFBVTFILE9BQU8sV0FBVzJILFFBQVFBLENBQUFvSCxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSXJFLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEIsRUFBRztBQUFBLE1BQy9FLEVBQUVoRCxLQUFLLFVBQVUxSCxPQUFPLGdCQUFnQjJILFFBQVFBLENBQUFvSCxRQUFPQSxJQUFJTyxVQUFVO0FBQUEsTUFDckUsRUFBRTVILEtBQUssVUFBVTFILE9BQU8sYUFBYTJILFFBQVFBLENBQUFvSCxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSWhLLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEIsRUFBRztBQUFBLElBQUMsS0FKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzlFLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtLO0FBQUEsSUFDTCx1QkFBQyxlQUFZLE9BQU9nSCxPQUFPL0UsU0FBU3ZELE9BQU91RCxTQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQsdUJBQUMsY0FBVyxNQUFNZ0YsWUFBWSxPQUFNLHlCQUF3QixhQUFZLHVIQUFzSCxTQUFTLE1BQU1DLGNBQWMsS0FBSyxHQUFHLE1BQU1GLE9BQU83RCxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDcUcsV0FBVyxTQUFTLE1BQU0sS0FBS0UsVUFBVSxHQUFHLHlDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRHLEdBQzFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPMUMsT0FBTy9FLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxjQUNHO0FBQUEsK0JBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxxQ0FBb0MsT0FBT2tGLFNBQVMsVUFBVSxDQUFBcEQsVUFBU3FELFdBQVdyRCxNQUFNQyxPQUFPdkIsS0FBSyxHQUFJNkYsc0JBQVlyRSxJQUFJLENBQUFzRSxVQUFTLHVCQUFDLFlBQXdCLE9BQU9BLE1BQU03RixJQUFLN0U7QUFBQUEsb0JBQVUwSyxNQUFNL0csSUFBSTtBQUFBLFVBQUU7QUFBQSxVQUFJK0csTUFBTTdGO0FBQUFBLFVBQUc7QUFBQSxVQUFJNkYsTUFBTXZJLFdBQVcsV0FBVyxrQkFBa0J1SSxNQUFNdkk7QUFBQUEsYUFBdkh1SSxNQUFNN0YsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SSxDQUFXLEtBQWpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbVQ7QUFBQSxRQUNsVDRGLFlBQVk1SCxXQUFXLEtBQUssdUJBQUMsY0FBVyxNQUFLLFVBQVMsaUZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxRQUN4SCx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLHlCQUF3QixPQUFPMkcsWUFBWSxVQUFVLENBQUF0RCxVQUFTO0FBQUV1RCx3QkFBY3ZELE1BQU1DLE9BQU92QixLQUFLO0FBQUdpRixzQkFBWSxFQUFFO0FBQUEsUUFBRyxHQUFJZSw0QkFBa0J4RSxJQUFJLENBQUF5RSxhQUFZLHVCQUFDLFlBQTJCLE9BQU9BLFNBQVNoRyxJQUFLZ0csbUJBQVN3QixRQUEzQ3hCLFNBQVNoRyxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStELENBQVcsS0FBNVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4UDtBQUFBLFFBQzlQLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sc0JBQXFCLE9BQU82RSxhQUFhLFVBQVUsQ0FBQXhELFVBQVN5RCxlQUFlekQsTUFBTUMsT0FBT3ZCLEtBQUssR0FBSW1FLHFCQUFXbkcsTUFBTUEsS0FBS3dELElBQUksQ0FBQWdHLGNBQWEsdUJBQUMsWUFBNEIsT0FBT0EsVUFBVXZILElBQUt1SDtBQUFBQSxvQkFBVU87QUFBQUEsVUFBSztBQUFBLFVBQUlQLFVBQVVDO0FBQUFBLGFBQWpFRCxVQUFVdkgsSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRixDQUFXLEtBQWhRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa1E7QUFBQSxRQUNsUSx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLDZCQUE0QixPQUFPK0UsVUFBVSxXQUFXLEVBQUVnRCxRQUFRLEVBQUVDLFVBQVUsS0FBSyxFQUFFLEdBQUcsVUFBVSxDQUFBM0csVUFBUzJELFlBQVksT0FBTzNELE1BQU1DLE9BQU92QixVQUFVLFdBQVdzQixNQUFNQyxPQUFPdkIsTUFBTWtJLE1BQU0sR0FBRyxJQUFJNUcsTUFBTUMsT0FBT3ZCLEtBQUssR0FBSWtHLHlCQUFlMUUsSUFBSSxDQUFDMkUsVUFBeUIsdUJBQUMsWUFBd0IsT0FBT0EsTUFBTWxHLElBQUtrRztBQUFBQSxnQkFBTWxHO0FBQUFBLFVBQUc7QUFBQSxVQUFpQmtHLE1BQU1nQztBQUFBQSxVQUFVO0FBQUEsVUFBSWhDLE1BQU1pQyxTQUFTbEY7QUFBQUEsVUFBTztBQUFBLFVBQUVpRCxNQUFNaUMsU0FBU2xCO0FBQUFBLFVBQVM7QUFBQSxVQUFRZixNQUFNa0M7QUFBQUEsVUFBZ0I7QUFBQSxVQUFFbEMsTUFBTW1DO0FBQUFBLGFBQWhLbkMsTUFBTWxHLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0wsQ0FBVyxLQUE5ZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdlO0FBQUEsUUFDL2RxRSxnQkFBZ0I3QyxhQUFhLHVCQUFDLGNBQVcsTUFBSyxVQUFTLG1EQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFBZTZDLGdCQUFnQnRDLFdBQVcsdUJBQUMsZUFBWSxPQUFPc0MsZ0JBQWdCOUUsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQUcsdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSwyQ0FBMEMsT0FBTzBGLFVBQVUsVUFBVSxDQUFBNUQsVUFBUzZELFlBQVk3RCxNQUFNQyxPQUFPdkIsS0FBSyxHQUFJb0csNkJBQW1CNUUsSUFBSSxDQUFBNkUsV0FBVSx1QkFBQyxZQUF5QixPQUFPQSxPQUFPcEcsSUFBS29HO0FBQUFBLGlCQUFPcEc7QUFBQUEsVUFBRztBQUFBLFVBQUlvRyxPQUFPRSxhQUFhckQ7QUFBQUEsVUFBTztBQUFBLFVBQUVtRCxPQUFPRSxhQUFhVztBQUFBQSxVQUFTO0FBQUEsVUFBSWIsT0FBT2tDO0FBQUFBLGFBQWpIbEMsT0FBT3BHLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUksQ0FBVyxLQUEzVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZUO0FBQUEsUUFBYSxDQUFDcUUsZ0JBQWdCN0MsYUFBYSxDQUFDNkMsZ0JBQWdCdEMsV0FBV29FLG1CQUFtQm5JLFdBQVcsS0FBSyx1QkFBQyxjQUFXLE1BQUssVUFBUywrRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFFBQ2xzQix1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE1BQUssVUFBUyxPQUFPbUgsYUFBYSxVQUFVLENBQUE5RCxVQUFTK0QsZUFBZS9ELE1BQU1DLE9BQU92QixLQUFLLEdBQUcsWUFBWSxFQUFFd0ksS0FBSyxHQUFHQyxNQUFNLEVBQUUsR0FBRyxPQUFPckQsZ0JBQWdCLE1BQU0sQ0FBQ3NCLGFBQWEsWUFBWUYsaUJBQWlCLGNBQWNBLGVBQWVELGFBQWFyRCxNQUFNLElBQUl2SCxLQUFLdUwsUUFBUSxNQUFNLGtDQUE1UztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJVO0FBQUEsUUFDM1UsdUJBQUMsYUFBVSxPQUFNLGVBQWMsTUFBSyxrQkFBaUIsT0FBT25FLFdBQVcsVUFBVSxDQUFBekIsVUFBU2dFLGFBQWFoRSxNQUFNQyxPQUFPdkIsS0FBSyxHQUFHLE9BQU8rQyxjQUFjLE1BQU0sQ0FBQzhELGVBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0s7QUFBQSxRQUNwSyx1QkFBQyxjQUFXLFNBQVEsV0FBVSxpSUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSTtBQUFBLFdBVG5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFDQSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQ3BCLGFBQWEsT0FBT0UsaUJBQWlCLFlBQVksNkJBQTZCQSxpQkFBaUIsV0FBVywrQkFBK0IsNkJBQTZCLGFBQWEsR0FBR0YsY0FBYzRCLFdBQVc1QixXQUFXLElBQUksRUFBRSxhQUFhQSxhQUFhTCxZQUFZbEMsVUFBVSxFQUFFLElBQUl1QyxhQUFhTCxZQUFZOEIsWUFBWSxFQUFFLCtCQUErQnpCLGFBQWFpRCxVQUFVLGVBQWUsa0RBQWtELGNBQWMvQyxpQkFBaUIsWUFBWSxxQkFBcUJBLGlCQUFpQixXQUFXLHVCQUF1QixxQkFBcUIsZUFBYSxNQUFDLE1BQU0xSixPQUFPeUUsU0FBUyxPQUFPekUsT0FBT3VELE9BQU8sU0FBUyxNQUFNa0csZUFBZSxJQUFJLEdBQUcsV0FBVyxPQUFNcEosV0FBVTtBQUN4c0IsVUFBSSxDQUFDbUosWUFBYTtBQUNsQixVQUFJO0FBQUUsY0FBTXhKLE9BQU8wRSxRQUFRLEVBQUVDLE1BQU0sRUFBRUMsWUFBWTRFLFlBQVl4RixHQUFHLEdBQUdhLE1BQU0sRUFBRUMsaUJBQWlCMEUsWUFBWXpFLFNBQVN6RCxRQUFRb0ksY0FBY3JKLE9BQU8sRUFBRSxDQUFDO0FBQUdvSix1QkFBZSxJQUFJO0FBQUEsTUFBRyxRQUNwSztBQUFBLE1BQUU7QUFBQSxJQUNaLEtBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlFO0FBQUEsT0FyQ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDUDtBQUNKO0FBQUMvQixJQXRHUUQsMEJBQXdCO0FBQUEsVUFDSDdKLFVBQ1ZDLFFBQ0VBLFFBQ0hKLFFBQ01BLFFBQ05DLGFBQ0dBLGFBQ0NBLGFBQ0pBLGFBQ0NBLGFBQ1FELFFBQ1RFLFlBQ0FBLFVBQVU7QUFBQTtBQUFBLE1BYnBCOEo7QUF3R1QsU0FBUzZCLG1CQUFtQm9ELFdBQW1CO0FBQzNDLFFBQU1DLFFBQVEsSUFBSWpLLEtBQUtnSyxZQUFZLElBQUloSyxLQUFLZ0ssU0FBUyxFQUFFRSxrQkFBa0IsSUFBSSxHQUFNO0FBQ25GLFNBQU9ELE1BQU14QixZQUFZLEVBQUUwQixNQUFNLEdBQUcsRUFBRTtBQUMxQztBQUVPLGdCQUFTQyxjQUFjO0FBQUFDLE1BQUE7QUFDMUIsUUFBTSxFQUFFck4sS0FBSyxJQUFJOUIsU0FBUztBQUMxQixRQUFNZ0MsT0FBT25DLE9BQU8sZUFBZSxFQUFFb0MsT0FBTy9CLGFBQWEsYUFBYSxFQUFFLENBQUM7QUFDekUsUUFBTWtQLFNBQVN2UCxPQUFPLHNCQUFzQjtBQUM1QyxRQUFNd1AsVUFBVXRQLFdBQVcscUJBQXFCLENBQUMsa0JBQWtCLGdCQUFnQixzQkFBc0IsQ0FBQztBQUMxRyxRQUFNLENBQUN1UCxNQUFNQyxPQUFPLElBQUlwUSxTQUFpRSxJQUFJO0FBRTdGLFNBQU8sbUNBQ0g7QUFBQSwyQkFBQyxjQUFXLE9BQU0sK0JBQThCLFVBQVMsdUZBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEk7QUFBQSxJQUM1SSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxJQUFJUyxTQUFTeUYsT0FBT0MsVUFBVSwrSEFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvSztBQUFBLElBQ3BLLHVCQUFDLGVBQVksU0FBUyxFQUFFTSxJQUFJLE9BQU80SixJQUFJLFlBQVksR0FDL0M7QUFBQSw2QkFBQyxTQUFNLE9BQU0scUJBQW9CLFVBQVMsU0FDdEMsaUNBQUMsY0FBVyxPQUFPeE4sTUFDZixpQ0FBQyxrQkFDSUE7QUFBQUEsYUFBS21DLE1BQU1BLEtBQUt3RCxJQUFJLENBQUE4SCxXQUFVLHVCQUFDLE9BQW9CLElBQUksQ0FBQzdQLFNBQVM4SSxPQUFPZ0gsa0JBQWtCLEVBQUVDLFFBQVEsR0FBR0MsYUFBYSxXQUFXQyxjQUFjelEsU0FBUzBRLE9BQU9DLE9BQU8sQ0FBQyxHQUNsSztBQUFBLGlDQUFDLFNBQU0sV0FBVSxPQUFNLGdCQUFlLGlCQUFnQixJQUFJblEsU0FBU2tHLFFBQVFDLGVBQWU7QUFBQSxtQ0FBQyxTQUFNO0FBQUEscUNBQUMsY0FBVyxTQUFRLGFBQWEzRjtBQUFBQSx5QkFBU3FQLE9BQU9PLGFBQWFsTyxLQUFLNEUsUUFBUTtBQUFBLGdCQUFFO0FBQUEsZ0JBQUl0RyxTQUFTcVAsT0FBT1EsV0FBV25PLEtBQUs0RSxRQUFRO0FBQUEsbUJBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJIO0FBQUEsY0FBYSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFrQitJO0FBQUFBLHVCQUFPcko7QUFBQUEsZ0JBQUc7QUFBQSxnQkFBY3FKLE9BQU90STtBQUFBQSxtQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkY7QUFBQSxpQkFBNU87QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeVA7QUFBQSxZQUFRLHVCQUFDLFVBQU8sT0FBT3NJLE9BQU8vTCxVQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLGVBQXhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJYO0FBQUEsVUFDM1gsdUJBQUMsY0FBVyxJQUFJLENBQUM5RCxTQUFTa0csUUFBUW9LLGVBQWUsRUFBRUMsWUFBWSxXQUFXLENBQUMsR0FBSVYsaUJBQU9XLFFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDM0YsdUJBQUMsY0FBVyxPQUFNLDRCQUE0QmhRO0FBQUFBLHFCQUFTcVAsT0FBT1ksV0FBV3ZPLEtBQUs0RSxRQUFRO0FBQUEsWUFBRTtBQUFBLFlBQUl0RyxTQUFTcVAsT0FBT2EsV0FBV3hPLEtBQUs0RSxRQUFRO0FBQUEsZUFBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0k7QUFBQSxVQUN0SSx1QkFBQyxjQUFXLE9BQU0sbUJBQW1CK0ksaUJBQU9jLFlBQVluTSxTQUFTcUwsT0FBT2MsWUFBWWhKLEtBQUssS0FBSyxJQUFJLDRDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySTtBQUFBLGFBSnRHa0ksT0FBT3JKLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLL0IsQ0FBTTtBQUFBLFFBQ04sdUJBQUMsU0FBTSxNQUFNcEUsS0FBS21DLE1BQU1xRCxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsV0FQakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sd0JBQXVCLFVBQVMsU0FDekM7QUFBQSwrQkFBQyxjQUFXLE9BQU80SCxRQUNmLGlDQUFDLFNBQ0lBLGlCQUFPakwsTUFBTUEsS0FBS2lMLE9BQU96SCxJQUFJLENBQUE2SSxVQUFTLHVCQUFDLE9BQTBCLElBQUk1USxTQUFTNEgsS0FBS2lKLGNBQ2hGO0FBQUEsaUNBQUMsU0FBTSxXQUFVLE9BQU0sZ0JBQWUsaUJBQWdCO0FBQUEsbUNBQUMsY0FBWUQsZ0JBQU1FLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFBYSx1QkFBQyxVQUFPLE9BQU9GLE1BQU05TSxVQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBLGVBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStIO0FBQUEsVUFDL0gsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBaUIsSUFBSTlELFNBQVM4SSxPQUFPaUksbUJBQW9CSCxnQkFBTS9OLFVBQVUsc0JBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThIO0FBQUEsVUFDOUgsdUJBQUMsY0FBVyxTQUFRLFdBQVcrTixnQkFBTUksWUFBWXhRLFNBQVNvUSxNQUFNSSxXQUFXOU8sS0FBSzRFLFFBQVEsSUFBSSwyQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0g7QUFBQSxhQUh2RThKLE1BQU1FLFdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJdkMsQ0FBTSxLQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSTlRLFNBQVNrRyxRQUFRb0ssZUFBZSxvSUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSztBQUFBLFdBVm5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUNBLHVCQUFDLFNBQU0sT0FBTSxrQ0FBaUMsVUFBUyxnRkFBK0UsV0FBVyxXQUFXLFVBQVMsU0FDakssaUNBQUMsa0JBQWdCLGVBQVkscUJBQ3pCO0FBQUEsNkJBQUMsU0FBTSxVQUFTLFdBQVUsZ0tBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEs7QUFBQSxNQUN6SztBQUFBLFFBQ0csQ0FBQyxrQ0FBa0MsZUFBZTtBQUFBLFFBQ2xELENBQUMsK0NBQStDLGVBQWU7QUFBQSxRQUMvRCxDQUFDLGtDQUFrQyxlQUFlO0FBQUEsUUFDbEQsQ0FBQyx5Q0FBeUMsZUFBZTtBQUFBLE1BQUMsRUFDNUR2SSxJQUFJLENBQUMsQ0FBQ2tKLFdBQVduTixNQUFNLE1BQU0sdUJBQUMsT0FBb0IsSUFBSSxDQUFDOUQsU0FBUzhJLE9BQU9vSSxVQUFVbFIsU0FBUzhJLE9BQU9xSSxlQUFlLEVBQUVDLFNBQVMsUUFBUUMsZ0JBQWdCLGlCQUFpQkMsVUFBVSxRQUFRQyxjQUFjLEdBQUd2QixhQUFhLFVBQVUsQ0FBQyxHQUM3TjtBQUFBLCtCQUFDLGNBQVlpQix1QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFDdkIsdUJBQUMsY0FBVyxPQUFNLGdCQUFnQm5OLG9CQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsV0FGSm1OLFdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUcvQixDQUFNO0FBQUEsTUFDTix1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFpQix1SEFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SjtBQUFBLFNBWGhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxPQUFNLHlCQUF3QixVQUFTLHFHQUFvRyxXQUFXLFdBQVcsVUFBUyxTQUM3SztBQUFBLDZCQUFDLGNBQVcsT0FBT3pCLFFBQ2YsaUNBQUMsU0FBTSxJQUFJeFAsU0FBUzhJLE9BQU8wSSxnQkFDdEJoQyxpQkFBT2pMLE1BQU1BLEtBQUtrTixNQUFNMUosSUFBSSxDQUFBMkosU0FBUSx1QkFBQyxPQUFrQixJQUFJLENBQUMxUixTQUFTOEksT0FBT29JLFVBQVVsUixTQUFTOEksT0FBT3FJLGVBQWUsRUFBRUMsU0FBUyxRQUFRTyxZQUFZLFVBQVVOLGdCQUFnQixpQkFBaUJDLFVBQVUsUUFBUUMsY0FBYyxHQUFHdkIsYUFBYSxVQUFVLENBQUMsR0FDdlA7QUFBQSwrQkFBQyxTQUFNO0FBQUEsaUNBQUMsY0FBVyxZQUFZeFEsU0FBUzRHLFdBQVdDLFdBQVd1TCxVQUFXalEsb0JBQVUrUCxLQUFLcE0sSUFBSSxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBQWEsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLFlBQVFvTSxLQUFLRztBQUFBQSxZQUFXO0FBQUEsWUFBSUgsS0FBSzVOLFdBQVcsV0FBVyxrQkFBa0I0TixLQUFLNU4sV0FBVyxtQkFBbUIsa0JBQWtCNE4sS0FBSzVOO0FBQUFBLGVBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStMO0FBQUEsYUFBMVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1VDtBQUFBLFFBQ3ZULHVCQUFDLGtCQUFlLFlBQVcsYUFBWSxPQUFPNE4sS0FBSzVOLFdBQVcsV0FBVyxZQUFZLFNBQVMsU0FBUyxNQUFNNkwsUUFBUSxFQUFFK0IsTUFBTS9PLFFBQVErTyxLQUFLNU4sV0FBVyxXQUFXLFdBQVcsUUFBUSxDQUFDLEdBQUk0TixlQUFLNU4sV0FBVyxXQUFXLGdDQUFnQyxzQkFBblA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzUTtBQUFBLFdBRjNONE4sS0FBS2xMLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdyQyxDQUFNLEtBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxlQUFZLE9BQU9pSixRQUFRMUosU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLFNBVHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0EsdUJBQUMsaUJBQWMsTUFBTXpCLFFBQVFvTCxJQUFJLEdBQUcsT0FBT0EsTUFBTS9NLFdBQVcsVUFBVSx3QkFBd0IsK0JBQStCLGNBQWMrTSxNQUFNL00sV0FBVyxVQUFVLHFCQUFxQix3QkFBd0IsYUFBYSxHQUFHK00sT0FBTy9OLFVBQVUrTixLQUFLZ0MsS0FBS3BNLElBQUksSUFBSSxFQUFFLEtBQUtvSyxNQUFNZ0MsS0FBS2xMLE1BQU0sRUFBRSxXQUFXdEUsS0FBSzhMLElBQUksS0FBSzBCLE1BQU0vTSxXQUFXLFVBQVUsMkNBQTJDLCtEQUErRCx1REFBdUQsZUFBYSxNQUFDLFNBQVMsTUFBTWdOLFFBQVEsSUFBSSxHQUFHLE9BQU9GLFFBQVExSixPQUFPLE1BQU0wSixRQUFReEksU0FBUyxXQUFXLENBQUFwRSxXQUFVNE0sUUFBUXZJLFFBQVEsRUFBRUcsTUFBTSxFQUFFQyxpQkFBaUJvSSxNQUFNZ0MsS0FBS25LLFdBQVcsR0FBR3VLLE9BQU8sUUFBUTFLLFlBQVlzSSxNQUFNZ0MsS0FBS2xMLE1BQU0sTUFBTTdELFFBQVErTSxNQUFNL00sVUFBVSxTQUFTRSxPQUFPLEVBQUUsQ0FBQyxLQUFwd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzd0I7QUFBQSxPQXhEbndCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RFA7QUFDSjtBQUFDME0sSUFqRWVELGFBQVc7QUFBQSxVQUNObFAsVUFDSkgsUUFBK0JLLGNBQzdCTCxRQUNDRSxVQUFVO0FBQUE7QUFBQSxNQUpkbVA7QUFBVyxJQUFBeUMsSUFBQUMsS0FBQUMsS0FBQUM7QUFBQSxhQUFBSCxJQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwiUGFnZVNlY3Rpb25zIiwiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiU2VjdGlvbkdyaWQiLCJTdXJmYWNlQ29udGVudCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIk1lbnVJdGVtIiwiU3RhY2siLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwibGF5b3V0U3giLCJ1c2VBcGkiLCJ1c2VQYWdlZEFwaSIsInVzZUNvbW1hbmQiLCJ1c2VTY29wZSIsInVzZUNhbiIsInVzZUxpc3RRdWVyeSIsImNvZGVQb2ludExlbmd0aCIsImRhdGVUaW1lIiwiUGFnZUhlYWRlciIsIlBhbmVsIiwiU3RhdHMiLCJTdGF0IiwiRGF0YVRhYmxlIiwiUXVlcnlTdGF0ZSIsIlRvb2xiYXIiLCJQYWdlciIsIlN0YXR1cyIsIk11dGF0aW9uQnV0dG9uIiwiRWRpdERpYWxvZyIsIkVycm9yTm90aWNlIiwiUm91dGVMaW5rIiwiQW1vdW50IiwiRGV0YWlsTGluZSIsIkNvbmZpcm1EaWFsb2ciLCJMb29rdXBMb2FkTW9yZSIsIndvcmtJdGVtQWN0aW9ucyIsInJvbGVOYW1lcyIsInNhbGVzX2FkbWluIiwiYWNjb3VudGFudCIsIndhcmVob3VzZV9idXllciIsInN1cGVydmlzb3IiLCJPcGVyYXRpb25zUGFnZSIsIl9zIiwic2hvcCIsInNlc3Npb24iLCJsaXN0IiwicXVlcnkiLCJzdW1tYXJ5IiwiY2xhaW0iLCJ1cGRhdGUiLCJpdGVtIiwic2V0SXRlbSIsImFjdGlvbiIsInNldEFjdGlvbiIsInJlYXNvbiIsInNldFJlYXNvbiIsImFzc2lnbmVlIiwic2V0QXNzaWduZWUiLCJleGNlcHRpb25zT25seSIsInNldEV4Y2VwdGlvbnNPbmx5IiwiY2FuTWFuYWdlTWVtYmVycyIsIm1lbWJlclNlYXJjaElucHV0Iiwic2V0TWVtYmVyU2VhcmNoSW5wdXQiLCJtZW1iZXJTZWFyY2giLCJzZXRNZW1iZXJTZWFyY2giLCJ0aW1lciIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJ0cmltIiwiY2xlYXJUaW1lb3V0IiwibWVtYmVycyIsInN0YXR1cyIsInEiLCJ1bmRlZmluZWQiLCJhdmFpbGFibGVBY3Rpb25zIiwiYWxsb3dlZEFjdGlvbnMiLCJmaWx0ZXIiLCJjYW5kaWRhdGUiLCJpbmNsdWRlcyIsIkJvb2xlYW4iLCJkYXRhIiwibGVuZ3RoIiwiaGFzTW9yZSIsIndvcmtJdGVtcyIsImFzT2YiLCJtZXRhIiwiaXNFeGNlcHRpb24iLCJ0YXNrIiwic3RhdGUiLCJvdmVyZHVlIiwiZHVlQXQiLCJEYXRlIiwicGFyc2UiLCJ1bmNsYWltZWQiLCJhc3NpZ25lZVVzZXJJZCIsImtpbmQiLCJleGNlcHRpb25JdGVtcyIsInZpc2libGVJdGVtcyIsIm5vdGljZSIsImFmdGVyR2FwIiwicXVldWVkVGFza3MiLCJvdmVyZHVlVGFza3MiLCJwZW5kaW5nQXBwcm92YWxzIiwidW5rbm93bkNvbW1hbmRzIiwiZXJyb3IiLCJ4cyIsInNtIiwic3VyZmFjZSIsImhlYWRlckZsb3dHYXAiLCJ0eXBvZ3JhcGh5IiwiZm9udFdlaWdodCIsInN0cm9uZyIsInZhbHVlIiwiaWQiLCJrZXkiLCJyZW5kZXIiLCJzb3VyY2UiLCJ0eXBlIiwidXNlciIsInRpbWV6b25lIiwiYmxvY2tlZFJlYXNvbiIsInVwZGF0ZUFjdGlvbnMiLCJwZW5kaW5nIiwiZXhlY3V0ZSIsInBhdGgiLCJyZXNvdXJjZUlkIiwiYm9keSIsImV4cGVjdGVkVmVyc2lvbiIsInZlcnNpb24iLCJjYXRjaCIsImNsZWFyRXJyb3IiLCJhbGlnblNlbGYiLCJqb2luIiwicGFnZSIsImV2ZW50IiwidGFyZ2V0IiwibWFwIiwiaXNQZW5kaW5nIiwic29tZSIsIm1lbWJlciIsInVzZXJJZCIsImxvYWRlZENvdW50IiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaXNFcnJvciIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwicmVmZXRjaCIsIkFwcHJvdmFsc1BhZ2UiLCJfczIiLCJhcHByb3ZhbElkIiwic2V0QXBwcm92YWxJZCIsImRldGFpbCIsImRlY2lkZSIsImRlY2lzaW9uIiwic2V0RGVjaXNpb24iLCJhcHByb3ZhbCIsInNpbXVsYXRlZE5vdyIsImV4cGlyeVZlcmlmaWVkIiwiZXhwaXJlZCIsImV4cGlyZXNBdCIsImVudHJ5IiwicmVzb3VyY2UiLCJhbW91bnQiLCJpbnRlbnRIYXNoIiwicmVzb3VyY2VWZXJzaW9uIiwicG9saWN5VmVyc2lvbiIsInJlcXVlc3RlZEJ5IiwiZGVjaWRlZEJ5IiwiZGVjaXNpb25SZWFzb24iLCJvdmVyZmxvd1dyYXAiLCJQdXJjaGFzZURlbGVnYXRpb25zUGFuZWwiLCJfczMiLCJjYW5SZWFkIiwiY2FuTWFuYWdlIiwiZ3JhbnRzIiwibGltaXQiLCJyZXNlcnZhdGlvbnMiLCJhZ2VudHMiLCJzdXBwbGllcnMiLCJ3YXJlaG91c2VzIiwib2ZmZXJzIiwiYnVkZ2V0cyIsImJ1ZGdldEFwcHJvdmFscyIsImNyZWF0ZSIsImRpYWxvZ09wZW4iLCJzZXREaWFsb2dPcGVuIiwiYWdlbnRJZCIsInNldEFnZW50SWQiLCJzdXBwbGllcklkIiwic2V0U3VwcGxpZXJJZCIsIndhcmVob3VzZUlkIiwic2V0V2FyZWhvdXNlSWQiLCJvZmZlcklkcyIsInNldE9mZmVySWRzIiwiYnVkZ2V0SWQiLCJzZXRCdWRnZXRJZCIsIm1heFBlck9yZGVyIiwic2V0TWF4UGVyT3JkZXIiLCJzZXRFeHBpcmVzQXQiLCJsb2NhbERhdGVUaW1lSW5wdXQiLCJub3ciLCJhY3Rpb25HcmFudCIsInNldEFjdGlvbkdyYW50IiwiYWN0aW9uU3RhdHVzIiwic2V0QWN0aW9uU3RhdHVzIiwicmVhZHlBZ2VudHMiLCJhZ2VudCIsImh1bWFuT3duZXJJZCIsImFwcHJvdmVkU3VwcGxpZXJzIiwic3VwcGxpZXIiLCJlbGlnaWJsZU9mZmVycyIsIm9mZmVyIiwicHJvY3VyZW1lbnRCdWRnZXRzIiwiYnVkZ2V0IiwiZW5hYmxlZCIsImxpbWl0QW1vdW50Iiwic2VsZWN0ZWRCdWRnZXQiLCJmaW5kIiwidmFsaWRBbW91bnQiLCJ0ZXN0IiwiTnVtYmVyIiwiZXhwaXJ5VmFsaWQiLCJpc0Zpbml0ZSIsImNhbkNyZWF0ZSIsIm9wZW5DcmVhdGUiLCJzYXZlR3JhbnQiLCJjdXJyZW5jeSIsImJ1ZGdldFBvbGljeUlkIiwidG9JU09TdHJpbmciLCJncmFudExhYmVsIiwiZ3JhbnQiLCJyb3ciLCJ3YXJlaG91c2UiLCJuYW1lIiwib2ZmZXJTbmFwc2hvdHMiLCJidWRnZXRQZXJpb2QiLCJsYXN0UmVhc29uIiwicHVyY2hhc2VPcmRlcklkIiwicGVyaW9kS2V5IiwiY29kZSIsInNlbGVjdCIsIm11bHRpcGxlIiwic3BsaXQiLCJ2YXJpYW50SWQiLCJ1bml0Q29zdCIsIm1pbmltdW1RdWFudGl0eSIsInBhY2tTaXplIiwicGVyaW9kIiwibWluIiwic3RlcCIsInRvb2xJZCIsInRpbWVzdGFtcCIsImxvY2FsIiwiZ2V0VGltZXpvbmVPZmZzZXQiLCJzbGljZSIsIkRpZ2VzdHNQYWdlIiwiX3M0IiwiaGVhbHRoIiwiY29udHJvbCIsInN0b3AiLCJzZXRTdG9wIiwibGciLCJkaWdlc3QiLCJyZWxhdGVkSXRlbUluc2V0IiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJkaWFsb2ciLCJwZXJpb2RTdGFydCIsInBlcmlvZEVuZCIsInNlY3Rpb25CZWZvcmUiLCJ3aGl0ZVNwYWNlIiwidGV4dCIsImNyZWF0ZWRBdCIsInVwZGF0ZWRBdCIsIndvcmtJdGVtSWRzIiwiY2hlY2siLCJzZWN0aW9uQWZ0ZXIiLCJjb21wb25lbnQiLCJyZWxhdGVkQ29udGVudEdhcCIsImNoZWNrZWRBdCIsImNyaXRlcmlvbiIsInZhbHVlR2FwIiwicm93SW5zZXRCbG9jayIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhXcmFwIiwiYm9yZGVyQm90dG9tIiwicmVsYXRlZEl0ZW1HYXAiLCJyb2xlcyIsInJvbGUiLCJhbGlnbkl0ZW1zIiwic2VtaWJvbGQiLCJnZW5lcmF0aW9uIiwic2NvcGUiLCJfYyIsIl9jMiIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtsYWJlbCBhcyBidXNpbmVzc0xhYmVsfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9sYWJlbHMnO1xuaW1wb3J0IHsgUGFnZVNlY3Rpb25zIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvc2l0aW9uJztcclxuaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFNlY3Rpb25HcmlkLCBTdXJmYWNlQ29udGVudCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcclxuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9sYXlvdXQnO1xyXG5pbXBvcnQgdHlwZSB7IEFnZW50Um9sZSwgQnVkZ2V0UG9saWN5LCBQdXJjaGFzZURlbGVnYXRpb24sIFB1cmNoYXNlRGVsZWdhdGlvblJlc2VydmF0aW9uLCBTdXBwbGllck9mZmVyLCBXb3JrSXRlbSB9IGZyb20gJ0Bib3RzYWxlcy9jb250cmFjdHMnO1xuaW1wb3J0IHsgdXNlQXBpLCB1c2VQYWdlZEFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9ob29rcyc7XHJcbmltcG9ydCB7IHVzZVNjb3BlLCB1c2VDYW4gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xyXG5pbXBvcnQgeyBjb2RlUG9pbnRMZW5ndGgsIGRhdGVUaW1lIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgUGFnZUhlYWRlciwgUGFuZWwsIFN0YXRzLCBTdGF0LCBEYXRhVGFibGUsIFF1ZXJ5U3RhdGUsIFRvb2xiYXIsIFBhZ2VyLCBTdGF0dXMsIE11dGF0aW9uQnV0dG9uLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgUm91dGVMaW5rLCBBbW91bnQsIERldGFpbExpbmUsIENvbmZpcm1EaWFsb2csIExvb2t1cExvYWRNb3JlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcblxyXG5jb25zdCB3b3JrSXRlbUFjdGlvbnMgPSBbJ2JlZ2luJywgJ2NvbXBsZXRlJywgJ2Jsb2NrJywgJ3JlYXNzaWduJ10gYXMgY29uc3Q7XHJcbnR5cGUgV29ya0l0ZW1BY3Rpb24gPSB0eXBlb2Ygd29ya0l0ZW1BY3Rpb25zW251bWJlcl07XHJcbmNvbnN0IHJvbGVOYW1lczogUmVjb3JkPEFnZW50Um9sZVsna2luZCddLCBzdHJpbmc+ID0ge1xyXG4gICAgc2FsZXNfYWRtaW46ICdBZG1pbiBiw6FuIGjDoG5nJyxcclxuICAgIGFjY291bnRhbnQ6ICdL4bq/IHRvw6FuJyxcclxuICAgIHdhcmVob3VzZV9idXllcjogJ0tobyAmIG11YSBow6BuZycsXHJcbiAgICBzdXBlcnZpc29yOiAnVHLGsOG7n25nIG5ow7NtJyxcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPcGVyYXRpb25zUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCwgc2Vzc2lvbiB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RXb3JrSXRlbXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RXb3JrSXRlbXMnKSB9KTtcclxuICAgIGNvbnN0IHN1bW1hcnkgPSB1c2VBcGkoJ2dldE9wZXJhdGlvbnNTdW1tYXJ5Jyk7XHJcbiAgICBjb25zdCBjbGFpbSA9IHVzZUNvbW1hbmQoJ2NsYWltV29ya0l0ZW0nLCBbJ2xpc3RXb3JrSXRlbXMnLCAnbGlzdFByZXBKb2JzJywgJ2dldE9wZXJhdGlvbnNTdW1tYXJ5J10pO1xyXG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlV29ya0l0ZW0nLCBbJ2xpc3RXb3JrSXRlbXMnLCAnZ2V0T3BlcmF0aW9uc1N1bW1hcnknXSk7XHJcbiAgICBjb25zdCBbaXRlbSwgc2V0SXRlbV0gPSB1c2VTdGF0ZTxXb3JrSXRlbSB8IG51bGw+KG51bGwpO1xyXG4gICAgY29uc3QgW2FjdGlvbiwgc2V0QWN0aW9uXSA9IHVzZVN0YXRlPFdvcmtJdGVtQWN0aW9uPignYmVnaW4nKTtcclxuICAgIGNvbnN0IFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbYXNzaWduZWUsIHNldEFzc2lnbmVlXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtleGNlcHRpb25zT25seSwgc2V0RXhjZXB0aW9uc09ubHldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgY2FuTWFuYWdlTWVtYmVycyA9IHVzZUNhbignbWVtYmVycy5tYW5hZ2UnKTtcclxuICAgIGNvbnN0IFttZW1iZXJTZWFyY2hJbnB1dCwgc2V0TWVtYmVyU2VhcmNoSW5wdXRdID0gdXNlU3RhdGUoJycpLCBbbWVtYmVyU2VhcmNoLCBzZXRNZW1iZXJTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldE1lbWJlclNlYXJjaChtZW1iZXJTZWFyY2hJbnB1dC50cmltKCkpLCAyNTApO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH0sIFttZW1iZXJTZWFyY2hJbnB1dF0pO1xyXG4gICAgY29uc3QgbWVtYmVycyA9IHVzZVBhZ2VkQXBpKCdsaXN0TWVtYmVycycsIHsgcXVlcnk6IHsgc3RhdHVzOiAnYWN0aXZlJywgcTogbWVtYmVyU2VhcmNoIHx8IHVuZGVmaW5lZCB9IH0sIGNhbk1hbmFnZU1lbWJlcnMpO1xyXG4gICAgY29uc3QgYXZhaWxhYmxlQWN0aW9ucyA9IGl0ZW0/LmFsbG93ZWRBY3Rpb25zLmZpbHRlcigoY2FuZGlkYXRlKTogY2FuZGlkYXRlIGlzIFdvcmtJdGVtQWN0aW9uID0+IHdvcmtJdGVtQWN0aW9ucy5pbmNsdWRlcyhjYW5kaWRhdGUgYXMgV29ya0l0ZW1BY3Rpb24pICYmIChjYW5kaWRhdGUgIT09ICdyZWFzc2lnbicgfHwgQm9vbGVhbihtZW1iZXJzLmRhdGE/LmRhdGEubGVuZ3RoIHx8IG1lbWJlcnMuaGFzTW9yZSkpKSB8fCBbXTtcclxuICAgIGNvbnN0IHdvcmtJdGVtcyA9IGxpc3QuZGF0YT8uZGF0YSB8fCBbXTtcclxuICAgIGNvbnN0IGFzT2YgPSBsaXN0LmRhdGE/Lm1ldGEuYXNPZjtcclxuICAgIGNvbnN0IGlzRXhjZXB0aW9uID0gKHRhc2s6IFdvcmtJdGVtKSA9PiB7XHJcbiAgICAgICAgaWYgKHRhc2suc3RhdGUgPT09ICdjb21wbGV0ZWQnIHx8IHRhc2suc3RhdGUgPT09ICdjYW5jZWxsZWQnKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgY29uc3Qgb3ZlcmR1ZSA9IEJvb2xlYW4odGFzay5kdWVBdCAmJiBhc09mICYmIERhdGUucGFyc2UodGFzay5kdWVBdCkgPD0gRGF0ZS5wYXJzZShhc09mKSk7XHJcbiAgICAgICAgY29uc3QgdW5jbGFpbWVkID0gdGFzay5zdGF0ZSA9PT0gJ3F1ZXVlZCcgJiYgIXRhc2suYXNzaWduZWVVc2VySWQ7XHJcbiAgICAgICAgcmV0dXJuIHRhc2suc3RhdGUgPT09ICdibG9ja2VkJyB8fCBvdmVyZHVlIHx8IHVuY2xhaW1lZCB8fCB0YXNrLmtpbmQgPT09ICdwYXltZW50X21pc21hdGNoJztcclxuICAgIH07XHJcbiAgICBjb25zdCBleGNlcHRpb25JdGVtcyA9IHdvcmtJdGVtcy5maWx0ZXIoaXNFeGNlcHRpb24pO1xyXG4gICAgY29uc3QgdmlzaWJsZUl0ZW1zID0gZXhjZXB0aW9uc09ubHkgPyBleGNlcHRpb25JdGVtcyA6IHdvcmtJdGVtcztcclxuXHJcbiAgICByZXR1cm4gPD5cclxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkPDtG5nIHZp4buHYyBow7RtIG5heVwiIHN1YnRpdGxlPVwiR2lhbyB2aeG7h2Mg4oaSIG5o4bqtbiB2aeG7h2Mg4oaSIGhvw6BuIHRow6BuaCDihpIga2nhu4NtIHRyYSBr4bq/dCBxdeG6oy5cIiAvPlxyXG4gICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT5E4buvIGxp4buHdSB24bqtbiBow6BuaCB2w6AgdHLhuqFuZyB0aMOhaSBk4buLY2ggduG7pSDEkWFuZyDEkcaw4bujYyBtw7QgcGjhu49uZzsgY2jGsGEgeMOhYyBtaW5oIHdvcmtlciBob+G6t2MgYmFja2VuZCB0aOG6rXQuPC9BbGVydD5cclxuICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17c3VtbWFyeX0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIHtzdW1tYXJ5LmRhdGEgJiYgPFN0YXRzPlxyXG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCJDaMawYSBjw7MgbmfGsOG7nWkgbmjhuq1uXCIgdmFsdWU9e3N1bW1hcnkuZGF0YS5kYXRhLnF1ZXVlZFRhc2tzfSBhY2NlbnQgLz5cclxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiUXXDoSBo4bqhblwiIHZhbHVlPXtzdW1tYXJ5LmRhdGEuZGF0YS5vdmVyZHVlVGFza3N9IC8+XHJcbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkNo4budIHBow6ogZHV54buHdFwiIHZhbHVlPXtzdW1tYXJ5LmRhdGEuZGF0YS5wZW5kaW5nQXBwcm92YWxzfSAvPlxyXG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCJL4bq/dCBxdeG6oyBjaMawYSByw7VcIiB2YWx1ZT17c3VtbWFyeS5kYXRhLmRhdGEudW5rbm93bkNvbW1hbmRzfSAvPlxyXG4gICAgICAgICAgICA8L1N0YXRzPn1cclxuICAgICAgICA8L1F1ZXJ5U3RhdGU+XHJcbiAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjbGFpbS5lcnJvcn0gLz5cclxuICAgICAgICA8UGFuZWw+XHJcbiAgICAgICAgICAgIDxTdXJmYWNlQ29udGVudCBib2R5TW9kZT1cImluc2V0RGl2aWRlclwiIGRhdGEtdGVzdGlkPVwib3BlcmF0aW9uLWV4Y2VwdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0ganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ2NlbnRlcicgfX0gc3g9e2xheW91dFN4LnN1cmZhY2UuaGVhZGVyRmxvd0dhcH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+R2nDoW0gc8OhdCBuZ2/huqFpIGzhu4c8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5RdcOhIGjhuqFuIHRoZW8gdGjhu51pIMSRaeG7g20gQVBJOyBn4buTbSB2aeG7h2MgYuG7iyBjaOG6t24sIGNoxrBhIG5o4bqtbiwgxJHhur9uIGjhuqFuIGhv4bq3YyBzYWkgbOG7h2NoIHRoYW5oIHRvw6FuLiBDaOG7iSBs4buNYyB0cmFuZyBk4buvIGxp4buHdSBoaeG7h24gxJFhbmcgdOG6o2kuPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD17ZXhjZXB0aW9uc09ubHkgPyAnY29udGFpbmVkJyA6ICdvdXRsaW5lZCd9IGFyaWEtcHJlc3NlZD17ZXhjZXB0aW9uc09ubHl9IG9uQ2xpY2s9eygpID0+IHNldEV4Y2VwdGlvbnNPbmx5KHZhbHVlID0+ICF2YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXhjZXB0aW9uc09ubHkgPyBgSGnhu4duIG3hu41pIGPDtG5nIHZp4buHYyAoJHt3b3JrSXRlbXMubGVuZ3RofSlgIDogYENo4buJIHhlbSBuZ2/huqFpIGzhu4cgKCR7ZXhjZXB0aW9uSXRlbXMubGVuZ3RofSlgfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgIHtleGNlcHRpb25zT25seSAmJiBleGNlcHRpb25JdGVtcy5sZW5ndGggPT09IDAgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiPktow7RuZyBjw7Mgbmdv4bqhaSBs4buHIHRyb25nIHRyYW5nIGThu68gbGnhu4d1IGhp4buHbiB04bqhaS48L0FsZXJ0Pn1cclxuICAgICAgICAgICAgPC9TdXJmYWNlQ29udGVudD5cclxuICAgICAgICAgICAgPFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdFdvcmtJdGVtc1wiIC8+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIHtsaXN0LmRhdGEgJiYgPD5cclxuICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiQ8O0bmcgdmnhu4djIHbhuq1uIGjDoG5oXCIgcm93cz17dmlzaWJsZUl0ZW1zfSByb3dLZXk9e3Rhc2sgPT4gdGFzay5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICd0YXNrJywgbGFiZWw6ICdDw7RuZyB2aeG7h2MnLCByZW5kZXI6IHRhc2sgPT4gPFN0YWNrPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGZvbnRXZWlnaHQ9e3Zpc3VhbFN4LnR5cG9ncmFwaHkuZm9udFdlaWdodC5zdHJvbmd9Pnt0YXNrLmtpbmQgPT09ICdwcmVwYXJlX29yZGVyJyA/ICdDaHXhuqluIGLhu4sgxJHGoW4gaMOgbmcnIDogdGFzay5raW5kID09PSAnY3VzdG9tZXJfaGFuZG9mZicgPyAnVGnhur9wIHF14bqjbiBraMOhY2ggaMOgbmcnIDogdGFzay5raW5kID09PSAncGF5bWVudF9taXNtYXRjaCcgPyAnU2FpIGzhu4djaCB0aGFuaCB0b8OhbicgOiB0YXNrLmtpbmQgPT09ICdsYXRlX3NoaXBtZW50JyA/ICdW4bqtbiDEkcahbiBxdcOhIGjhuqFuJyA6IGJ1c2luZXNzTGFiZWwodGFzay5raW5kKX08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3Rhc2suc291cmNlLnR5cGV9IMK3IHt0YXNrLnNvdXJjZS5pZH08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N0YWNrPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0dXMnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IHRhc2sgPT4gPFN0YXR1cyB2YWx1ZT17dGFzay5zdGF0ZX0gLz4gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhc3NpZ25lZCcsIGxhYmVsOiAnTmfGsOG7nWkgbmjhuq1uJywgcmVuZGVyOiB0YXNrID0+IHRhc2suYXNzaWduZWVVc2VySWQgPT09IHNlc3Npb24udXNlci5pZCA/ICdC4bqhbicgOiB0YXNrLmFzc2lnbmVlVXNlcklkIHx8ICdDaMawYSBjw7MnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZHVlJywgbGFiZWw6ICdI4bqhbiB44butIGzDvScsIHJlbmRlcjogdGFzayA9PiB0YXNrLmR1ZUF0ID8gZGF0ZVRpbWUodGFzay5kdWVBdCwgc2hvcC50aW1lem9uZSkgOiAnQ2jGsGEgxJHhurd0IGzhu4tjaCcgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdyZWFzb24nLCBsYWJlbDogJ1bGsOG7m25nIG3huq9jJywgcmVuZGVyOiB0YXNrID0+IHRhc2suYmxvY2tlZFJlYXNvbiB8fCAn4oCUJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICdhY3Rpb25zJywgbGFiZWw6ICcnLCByZW5kZXI6IHRhc2sgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZUFjdGlvbnMgPSB0YXNrLmFsbG93ZWRBY3Rpb25zLmZpbHRlcihjYW5kaWRhdGUgPT4gd29ya0l0ZW1BY3Rpb25zLmluY2x1ZGVzKGNhbmRpZGF0ZSBhcyBXb3JrSXRlbUFjdGlvbikpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9wZXJhdGlvbnMuY2xhaW1cIiBhbGxvd2VkQWN0aW9ucz17dGFzay5hbGxvd2VkQWN0aW9uc30gYWN0aW9uPVwiY2xhaW1cIiBidXN5PXtjbGFpbS5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIGNsYWltLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IHRhc2suaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHRhc2sudmVyc2lvbiB9IH0pLmNhdGNoKCgpID0+IHVuZGVmaW5lZCl9PlTDtGkgbmjhuq1uIHZp4buHYzwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLmtpbmQgPT09ICdwcmVwYXJlX29yZGVyJyAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9mdWxmaWxsbWVudGB9PkNodeG6qW4gYuG7iyBow6BuZzwvUm91dGVMaW5rPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2sua2luZCAhPT0gJ3ByZXBhcmVfb3JkZXInICYmIHVwZGF0ZUFjdGlvbnMubGVuZ3RoID4gMCAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cIm9wZXJhdGlvbnMubWFuYWdlXCIgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXRlbSh0YXNrKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlYXNvbignJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBc3NpZ25lZSgnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3Rpb24odXBkYXRlQWN0aW9uc1swXSBhcyBXb3JrSXRlbUFjdGlvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGUuY2xlYXJFcnJvcigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5D4bqtcCBuaOG6rXQ8L011dGF0aW9uQnV0dG9uPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e3sgYWxpZ25TZWxmOiAnY2VudGVyJyB9fT7EkMaw4bujYyBwaMOpcDoge3Rhc2suYWxsb3dlZEFjdGlvbnMubGVuZ3RoID8gdGFzay5hbGxvd2VkQWN0aW9ucy5qb2luKCcgwrcgJykgOiAnS2jDtG5nIGPDsyBow6BuaCDEkeG7mW5nJ308L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9BY3Rpb25Hcm91cD47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfSAvPlxyXG4gICAgICAgICAgICAgICAgPC8+fVxyXG4gICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+XHJcbiAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICA8RWRpdERpYWxvZyBvcGVuPXshIWl0ZW19IHRpdGxlPVwiQ+G6rXAgbmjhuq10IGPDtG5nIHZp4buHY1wiIG9uQ2xvc2U9eygpID0+IHNldEl0ZW0obnVsbCl9IGJ1c3k9e3VwZGF0ZS5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IWl0ZW0gfHwgIWF2YWlsYWJsZUFjdGlvbnMuaW5jbHVkZXMoYWN0aW9uKSB8fCBjb2RlUG9pbnRMZW5ndGgocmVhc29uLnRyaW0oKSkgPCA1IHx8IChhY3Rpb24gPT09ICdyZWFzc2lnbicgJiYgIWFzc2lnbmVlKSB8fCB1cGRhdGUucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWl0ZW0gfHwgIWF2YWlsYWJsZUFjdGlvbnMuaW5jbHVkZXMoYWN0aW9uKSkgcmV0dXJuO1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IGl0ZW0uaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGl0ZW0udmVyc2lvbiwgYWN0aW9uLCByZWFzb24sIC4uLihhY3Rpb24gPT09ICdyZWFzc2lnbicgPyB7IGFzc2lnbmVlVXNlcklkOiBhc3NpZ25lZSB8fCBudWxsIH0gOiB7fSkgfSB9KTtcclxuICAgICAgICAgICAgICAgIHNldEl0ZW0obnVsbCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2F0Y2ggeyAvKiBlcnJvciBzdGF5cyB2aXNpYmxlICovIH1cclxuICAgICAgICB9fT5MxrB1IGvhur90IHF14bqjPC9CdXR0b24+fT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXt1cGRhdGUuZXJyb3J9IC8+XHJcbiAgICAgICAgICAgIDxGb3JtRmllbGRzID5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5PntpdGVtPy5zb3VyY2UuaWR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAge2F2YWlsYWJsZUFjdGlvbnMubGVuZ3RoID4gMCAmJiA8VGV4dEZpZWxkIGxhYmVsPVwiSMOgbmggxJHhu5luZyDEkcaw4bujYyBwaMOpcFwiIHNlbGVjdCB2YWx1ZT17YXZhaWxhYmxlQWN0aW9ucy5pbmNsdWRlcyhhY3Rpb24pID8gYWN0aW9uIDogYXZhaWxhYmxlQWN0aW9uc1swXX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEFjdGlvbihldmVudC50YXJnZXQudmFsdWUgYXMgV29ya0l0ZW1BY3Rpb24pfT5cclxuICAgICAgICAgICAgICAgICAgICB7YXZhaWxhYmxlQWN0aW9ucy5tYXAodmFsdWUgPT4gPE1lbnVJdGVtIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+e3ZhbHVlID09PSAnYmVnaW4nID8gJ0Lhuq90IMSR4bqndSB44butIGzDvScgOiB2YWx1ZSA9PT0gJ2NvbXBsZXRlJyA/ICdIb8OgbiB0aMOgbmgnIDogdmFsdWUgPT09ICdibG9jaycgPyAnQsOhbyDEkWFuZyBi4buLIGNo4bq3bicgOiAnQ2h1eeG7g24gbmfGsOG7nWkgcGjhu6UgdHLDoWNoJ308L01lbnVJdGVtPil9XHJcbiAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD59XHJcbiAgICAgICAgICAgICAgICB7YWN0aW9uID09PSAncmVhc3NpZ24nICYmIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlTDrG0gdGjDoG5oIHZpw6puIMSRYW5nIGhv4bqhdCDEkeG7mW5nXCIgdmFsdWU9e21lbWJlclNlYXJjaElucHV0fSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TWVtYmVyU2VhcmNoSW5wdXQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VNZW1iZXJzfSBoZWxwZXJUZXh0PVwiVMOsbSBraeG6v20gZMO5bmcgcSBj4bunYSBsaXN0TWVtYmVyczsgdHJhbmcgdGnhur9wIGTDuW5nIGN1cnNvci5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTmfGsOG7nWkgcGjhu6UgdHLDoWNoXCIgdmFsdWU9e2Fzc2lnbmVlfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0QXNzaWduZWUoZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5NYW5hZ2VNZW1iZXJzIHx8IChtZW1iZXJzLmlzUGVuZGluZyAmJiAhbWVtYmVycy5kYXRhKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthc3NpZ25lZSAmJiAhbWVtYmVycy5kYXRhPy5kYXRhLnNvbWUobWVtYmVyID0+IG1lbWJlci51c2VySWQgPT09IGFzc2lnbmVlKSAmJiA8TWVudUl0ZW0gdmFsdWU9e2Fzc2lnbmVlfT57YXNzaWduZWV9PC9NZW51SXRlbT59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHttZW1iZXJzLmRhdGE/LmRhdGEuZmlsdGVyKG1lbWJlciA9PiBtZW1iZXIuc3RhdHVzID09PSAnYWN0aXZlJykubWFwKG1lbWJlciA9PiA8TWVudUl0ZW0ga2V5PXttZW1iZXIuaWR9IHZhbHVlPXttZW1iZXIudXNlcklkfT57bWVtYmVyLnVzZXJJZH08L01lbnVJdGVtPil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPExvb2t1cExvYWRNb3JlIGxhYmVsPVwidGjDoG5oIHZpw6puXCIgbG9hZGVkQ291bnQ9e21lbWJlcnMubG9hZGVkQ291bnR9IGhhc01vcmU9e21lbWJlcnMuaGFzTW9yZX0gYnVzeT17bWVtYmVycy5pc0xvYWRpbmdNb3JlfSBvbkxvYWRNb3JlPXttZW1iZXJzLmxvYWRNb3JlfS8+XHJcbiAgICAgICAgICAgICAgICAgICAge21lbWJlcnMuaXNFcnJvciAmJiA8U3VyZmFjZUNvbnRlbnQgPjxFcnJvck5vdGljZSBlcnJvcj17bWVtYmVycy5lcnJvcn0vPjxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChtZW1iZXJzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gbWVtYmVycy5sb2FkTW9yZSgpIDogbWVtYmVycy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIHPDoWNoIHRow6BuaCB2acOqbjwvQnV0dG9uPjwvU3VyZmFjZUNvbnRlbnQ+fVxyXG4gICAgICAgICAgICAgICAgPC8+fVxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkvhur90IHF14bqjIC8gbMO9IGRvXCIgbXVsdGlsaW5lIG1pblJvd3M9ezN9IHZhbHVlPXtyZWFzb259IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRSZWFzb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgICAgIDwvRWRpdERpYWxvZz5cclxuICAgIDwvPjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFwcHJvdmFsc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0QXBwcm92YWxzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0QXBwcm92YWxzJykgfSk7XHJcbiAgICBjb25zdCBbYXBwcm92YWxJZCwgc2V0QXBwcm92YWxJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IGRldGFpbCA9IHVzZUFwaSgnZ2V0QXBwcm92YWwnLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogYXBwcm92YWxJZCB8fCAnJyB9IH0sIEJvb2xlYW4oYXBwcm92YWxJZCkpO1xyXG4gICAgY29uc3QgZGVjaWRlID0gdXNlQ29tbWFuZCgnZGVjaWRlQXBwcm92YWwnLCBbJ2dldEFwcHJvdmFsJywgJ2xpc3RBcHByb3ZhbHMnLCAnbGlzdFB1cmNoYXNlT3JkZXJzJywgJ2dldE9wZXJhdGlvbnNTdW1tYXJ5J10pO1xyXG4gICAgY29uc3QgW2RlY2lzaW9uLCBzZXREZWNpc2lvbl0gPSB1c2VTdGF0ZTwnYXBwcm92ZScgfCAncmVqZWN0Jz4oJ2FwcHJvdmUnKTtcclxuICAgIGNvbnN0IFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBhcHByb3ZhbCA9IGRldGFpbC5kYXRhPy5kYXRhO1xyXG4gICAgY29uc3Qgc2ltdWxhdGVkTm93ID0gZGV0YWlsLmRhdGE/Lm1ldGEuYXNPZjtcclxuICAgIGNvbnN0IGV4cGlyeVZlcmlmaWVkID0gQm9vbGVhbihzaW11bGF0ZWROb3cpO1xyXG4gICAgY29uc3QgZXhwaXJlZCA9IGFwcHJvdmFsID8gIXNpbXVsYXRlZE5vdyB8fCBEYXRlLnBhcnNlKGFwcHJvdmFsLmV4cGlyZXNBdCkgPD0gRGF0ZS5wYXJzZShzaW11bGF0ZWROb3cpIDogdHJ1ZTtcclxuXHJcbiAgICByZXR1cm4gPD5cclxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkPhuqduIHBow6ogZHV54buHdFwiIHN1YnRpdGxlPVwiUXV54bq/dCDEkeG7i25oIGfhuq9uIHbhu5tpIMSRw7puZyBu4buZaSBkdW5nLCBwaGnDqm4gYuG6o24gdsOgIGjhuqFuIGhp4buHdSBs4buxYyDigJQga2jDtG5nIHBo4bqjaSBt4buZdCBuw7p0IMSR4buTbmcgw70gY2h1bmcuXCIgLz5cclxuICAgICAgICA8UGFnZVNlY3Rpb25zPlxyXG4gICAgICAgICAgICA8UGFuZWw+XHJcbiAgICAgICAgICAgIDxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RBcHByb3ZhbHNcIiAvPlxyXG4gICAgICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICB7bGlzdC5kYXRhICYmIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSBsYWJlbD1cIlnDqnUgY+G6p3UgcGjDqiBkdXnhu4d0XCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17ZW50cnkgPT4gZW50cnkuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJ07hu5lpIGR1bmcnLCByZW5kZXI6IGVudHJ5ID0+IDxTdGFjaz48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc3Ryb25nfT57YnVzaW5lc3NMYWJlbChlbnRyeS5hY3Rpb24pfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPntidXNpbmVzc0xhYmVsKGVudHJ5LnJlc291cmNlLnR5cGUpfSDCtyB7ZW50cnkuYWN0aW9ufSDCtyBNw6MgxJHhu5FpIHTGsOG7o25nOiB7ZW50cnkucmVzb3VyY2UuaWR9PC9UeXBvZ3JhcGh5PjwvU3RhY2s+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnYW1vdW50JywgbGFiZWw6ICdT4buRIHRp4buBbicsIHJlbmRlcjogZW50cnkgPT4gPEFtb3VudCB2YWx1ZT17ZW50cnkuYW1vdW50fSAvPiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiBlbnRyeSA9PiA8U3RhdHVzIHZhbHVlPXtlbnRyeS5zdGF0dXN9IC8+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZHVlJywgbGFiZWw6ICdI4bq/dCBo4bqhbicsIHJlbmRlcjogZW50cnkgPT4gZGF0ZVRpbWUoZW50cnkuZXhwaXJlc0F0LCBzaG9wLnRpbWV6b25lKSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICdhY3Rpb25zJywgbGFiZWw6ICcnLCByZW5kZXI6IGVudHJ5ID0+IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiYXBwcm92YWxzLmRlY2lkZVwiIGRpc2FibGVkPXtlbnRyeS5zdGF0dXMgIT09ICdwZW5kaW5nJ30gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFwcHJvdmFsSWQoZW50cnkuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlYXNvbignJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGVjaXNpb24oJ2FwcHJvdmUnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWNpZGUuY2xlYXJFcnJvcigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+WGVtICYgcXV54bq/dCDEkeG7i25oPC9NdXRhdGlvbkJ1dHRvbj4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17bGlzdC5kYXRhLnBhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICA8Lz59XHJcbiAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICAgICAgPFB1cmNoYXNlRGVsZWdhdGlvbnNQYW5lbCAvPlxuICAgICAgICA8L1BhZ2VTZWN0aW9ucz5cclxuICAgICAgICA8RWRpdERpYWxvZyBvcGVuPXtCb29sZWFuKGFwcHJvdmFsSWQpfSB0aXRsZT1cIlhlbSB4w6l0IHBow6ogZHV54buHdFwiIG9uQ2xvc2U9eygpID0+IHNldEFwcHJvdmFsSWQobnVsbCl9IGJ1c3k9e2RlY2lkZS5wZW5kaW5nfSBhY3Rpb25zPXs8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImFwcHJvdmFscy5kZWNpZGVcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17ZGVjaWRlLnBlbmRpbmd9IGRpc2FibGVkPXshYXBwcm92YWwgfHwgZGV0YWlsLmlzUGVuZGluZyB8fCBhcHByb3ZhbC5zdGF0dXMgIT09ICdwZW5kaW5nJyB8fCBleHBpcmVkIHx8IGNvZGVQb2ludExlbmd0aChyZWFzb24udHJpbSgpKSA8IDV9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFhcHByb3ZhbCB8fCBhcHByb3ZhbC5zdGF0dXMgIT09ICdwZW5kaW5nJyB8fCBleHBpcmVkKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkZWNpZGUuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogYXBwcm92YWwuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGFwcHJvdmFsLnZlcnNpb24sIGludGVudEhhc2g6IGFwcHJvdmFsLmludGVudEhhc2gsIGRlY2lzaW9uLCByZWFzb24gfSB9KTtcclxuICAgICAgICAgICAgICAgIHNldEFwcHJvdmFsSWQobnVsbCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2F0Y2ggeyAvKiBrZWVwIHJlYXNvbiBhbmQgY3VycmVudCBhcHByb3ZhbCBkZXRhaWxzIHZpc2libGUgKi8gfVxyXG4gICAgICAgIH19PntkZWNpc2lvbiA9PT0gJ2FwcHJvdmUnID8gJ0R1eeG7h3QgxJHDum5nIG7hu5lpIGR1bmcgbsOgeScgOiAnVOG7qyBjaOG7kWknfTwvTXV0YXRpb25CdXR0b24+fT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtkZWNpZGUuZXJyb3J9IC8+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9PlxyXG4gICAgICAgICAgICAgICAge2FwcHJvdmFsICYmIDxGb3JtRmllbGRzID5cclxuICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VGhheSDEkeG7lWkgZ2nDoSwgc+G7kSBsxrDhu6NuZywgxJHhu5FpIHTGsOG7o25nIGhv4bq3YyBxdXnhu4FuIGPDsyB0aOG7gyBsw6BtIHBow6ogZHV54buHdCBo4bq/dCBoaeG7h3UgbOG7sWMuIEltIGzhurduZyBraMO0bmcgxJHGsOG7o2MgY29pIGzDoCDEkeG7k25nIMO9LjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgeyFleHBpcnlWZXJpZmllZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiPktow7RuZyB4w6FjIG1pbmggxJHGsOG7o2MgdGjhu51pIMSRaeG7g20gaGnhu4duIHThuqFpIHThu6sgQVBJOyBraMO0bmcgdGjhu4MgZ+G7rWkgcXV54bq/dCDEkeG7i25oIGFuIHRvw6BuLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIHtleHBpcmVkICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCI+UGjDqiBkdXnhu4d0IMSRw6MgaOG6v3QgaOG6oW47IGPhuqduIHhpbiBwaMOqIGR1eeG7h3QgbeG7m2kgdHLGsOG7m2Mga2hpIHRp4bq/cCB04bulYy48L0FsZXJ0Pn1cclxuICAgICAgICAgICAgICAgICAgICB7YXBwcm92YWwuc3RhdHVzICE9PSAncGVuZGluZycgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlBow6ogZHV54buHdCBoaeG7h24g4bufIHRy4bqhbmcgdGjDoWkg4oCce2J1c2luZXNzTGFiZWwoYXBwcm92YWwuc3RhdHVzKX3igJ07IGtow7RuZyB0aOG7gyBxdXnhur90IMSR4buLbmggbOG6oWkuPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJIw6BuaCDEkeG7mW5nXCI+e2J1c2luZXNzTGFiZWwoYXBwcm92YWwuYWN0aW9uKX08L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCLEkOG7kWkgdMaw4bujbmdcIj57YXBwcm92YWwucmVzb3VyY2UudHlwZX0gwrcgTcOjIMSR4buRaSB0xrDhu6NuZzoge2FwcHJvdmFsLnJlc291cmNlLmlkfSDCtyBwaGnDqm4gYuG6o24ge2FwcHJvdmFsLnJlc291cmNlVmVyc2lvbn08L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJDaMOtbmggc8OhY2hcIj57YXBwcm92YWwucG9saWN5VmVyc2lvbn08L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJOZ8aw4budaSB5w6p1IGPhuqd1XCI+TcOjIG5ow6JuIHPhu7E6IHthcHByb3ZhbC5yZXF1ZXN0ZWRCeX08L0RldGFpbExpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJHacOhIHRy4buLXCI+PEFtb3VudCB3cmFwIHZhbHVlPXthcHByb3ZhbC5hbW91bnR9IC8+PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxMaW5lIGxhYmVsPVwiSOG6oW4gaGnhu4d1IGzhu7FjXCI+e2RhdGVUaW1lKGFwcHJvdmFsLmV4cGlyZXNBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbC5kZWNpZGVkQnkgJiYgPERldGFpbExpbmUgbGFiZWw9XCJOZ8aw4budaSBxdXnhur90IMSR4buLbmhcIj5Nw6MgbmjDom4gc+G7sToge2FwcHJvdmFsLmRlY2lkZWRCeX08L0RldGFpbExpbmU+fVxyXG4gICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbC5kZWNpc2lvblJlYXNvbiAmJiA8RGV0YWlsTGluZSBsYWJlbD1cIkzDvSBkbyDEkcOjIGdoaSBuaOG6rW5cIj57YXBwcm92YWwuZGVjaXNpb25SZWFzb259PC9EZXRhaWxMaW5lPn1cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIHN4PXt7IG92ZXJmbG93V3JhcDogJ2FueXdoZXJlJyB9fT5IYXNoIG7hu5lpIGR1bmc6IHthcHByb3ZhbC5pbnRlbnRIYXNofTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiUXV54bq/dCDEkeG7i25oXCIgc2VsZWN0IHZhbHVlPXtkZWNpc2lvbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldERlY2lzaW9uKGV2ZW50LnRhcmdldC52YWx1ZSBhcyB0eXBlb2YgZGVjaXNpb24pfSBkaXNhYmxlZD17YXBwcm92YWwuc3RhdHVzICE9PSAncGVuZGluZycgfHwgZXhwaXJlZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cImFwcHJvdmVcIj5EdXnhu4d0PC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwicmVqZWN0XCI+VOG7qyBjaOG7kWk8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJMw70gZG8gcXV54bq/dCDEkeG7i25oXCIgbXVsdGlsaW5lIG1pblJvd3M9ezN9IHZhbHVlPXtyZWFzb259IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRSZWFzb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9e2FwcHJvdmFsLnN0YXR1cyAhPT0gJ3BlbmRpbmcnIHx8IGV4cGlyZWR9IC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+fVxyXG4gICAgICAgICAgICA8L1F1ZXJ5U3RhdGU+XHJcbiAgICAgICAgPC9FZGl0RGlhbG9nPlxyXG4gICAgPC8+O1xyXG59XHJcblxuZnVuY3Rpb24gUHVyY2hhc2VEZWxlZ2F0aW9uc1BhbmVsKCkge1xuICAgIGNvbnN0IHsgc2hvcCwgc2Vzc2lvbiB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBjYW5SZWFkID0gdXNlQ2FuKCdwcm9jdXJlbWVudC5yZWFkJyk7XG4gICAgY29uc3QgY2FuTWFuYWdlID0gdXNlQ2FuKCdwcm9jdXJlbWVudC5kZWxlZ2F0aW9uLm1hbmFnZScpO1xuICAgIGNvbnN0IGdyYW50cyA9IHVzZUFwaSgnbGlzdFB1cmNoYXNlRGVsZWdhdGlvbnMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAyMCB9IH0sIGNhblJlYWQpO1xuICAgIGNvbnN0IHJlc2VydmF0aW9ucyA9IHVzZUFwaSgnbGlzdFB1cmNoYXNlRGVsZWdhdGlvblJlc2VydmF0aW9ucycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwIH0gfSwgY2FuTWFuYWdlKTtcbiAgICBjb25zdCBhZ2VudHMgPSB1c2VQYWdlZEFwaSgnbGlzdEFnZW50Um9sZXMnLCB7fSwgY2FuTWFuYWdlKTtcbiAgICBjb25zdCBzdXBwbGllcnMgPSB1c2VQYWdlZEFwaSgnbGlzdFN1cHBsaWVycycsIHt9LCBjYW5NYW5hZ2UpO1xuICAgIGNvbnN0IHdhcmVob3VzZXMgPSB1c2VQYWdlZEFwaSgnbGlzdFdhcmVob3VzZXMnLCB7IHF1ZXJ5OiB7IHN0YXR1czogJ2FjdGl2ZScgfSB9LCBjYW5NYW5hZ2UpO1xuICAgIGNvbnN0IG9mZmVycyA9IHVzZVBhZ2VkQXBpKCdsaXN0U3VwcGxpZXJPZmZlcnMnLCB7fSwgY2FuTWFuYWdlKTtcbiAgICBjb25zdCBidWRnZXRzID0gdXNlUGFnZWRBcGkoJ2xpc3RCdWRnZXRQb2xpY2llcycsIHt9LCBjYW5NYW5hZ2UpO1xuICAgIGNvbnN0IGJ1ZGdldEFwcHJvdmFscyA9IHVzZUFwaSgnbGlzdEFwcHJvdmFscycsIHsgcXVlcnk6IHsgbGltaXQ6IDEwMCB9IH0sIGNhbk1hbmFnZSk7XG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUHVyY2hhc2VEZWxlZ2F0aW9uJywgWydsaXN0UHVyY2hhc2VEZWxlZ2F0aW9ucyddKTtcbiAgICBjb25zdCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVQdXJjaGFzZURlbGVnYXRpb24nLCBbJ2xpc3RQdXJjaGFzZURlbGVnYXRpb25zJywgJ2xpc3RQdXJjaGFzZURlbGVnYXRpb25SZXNlcnZhdGlvbnMnLCAnbGlzdFJlb3JkZXJSdWxlcycsICdsaXN0UHVyY2hhc2VTdWdnZXN0aW9ucyddKTtcbiAgICBjb25zdCBbZGlhbG9nT3Blbiwgc2V0RGlhbG9nT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2FnZW50SWQsIHNldEFnZW50SWRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzdXBwbGllcklkLCBzZXRTdXBwbGllcklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbd2FyZWhvdXNlSWQsIHNldFdhcmVob3VzZUlkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbb2ZmZXJJZHMsIHNldE9mZmVySWRzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gICAgY29uc3QgW2J1ZGdldElkLCBzZXRCdWRnZXRJZF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW21heFBlck9yZGVyLCBzZXRNYXhQZXJPcmRlcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2V4cGlyZXNBdCwgc2V0RXhwaXJlc0F0XSA9IHVzZVN0YXRlKCgpID0+IGxvY2FsRGF0ZVRpbWVJbnB1dChEYXRlLm5vdygpICsgNyAqIDI0ICogNjAgKiA2MCAqIDEwMDApKTtcbiAgICBjb25zdCBbYWN0aW9uR3JhbnQsIHNldEFjdGlvbkdyYW50XSA9IHVzZVN0YXRlPFB1cmNoYXNlRGVsZWdhdGlvbiB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFthY3Rpb25TdGF0dXMsIHNldEFjdGlvblN0YXR1c10gPSB1c2VTdGF0ZTwnYWN0aXZlJyB8ICdwYXVzZWQnIHwgJ3Jldm9rZWQnPigncGF1c2VkJyk7XG4gICAgY29uc3QgcmVhZHlBZ2VudHMgPSBhZ2VudHMuZGF0YT8uZGF0YS5maWx0ZXIoYWdlbnQgPT4gYWdlbnQua2luZCA9PT0gJ3dhcmVob3VzZV9idXllcicgJiYgYWdlbnQuaHVtYW5Pd25lcklkID09PSBzZXNzaW9uLnVzZXIuaWQpIHx8IFtdO1xuICAgIGNvbnN0IGFwcHJvdmVkU3VwcGxpZXJzID0gc3VwcGxpZXJzLmRhdGE/LmRhdGEuZmlsdGVyKHN1cHBsaWVyID0+IHN1cHBsaWVyLnN0YXR1cyA9PT0gJ2FwcHJvdmVkJykgfHwgW107XG4gICAgY29uc3QgZWxpZ2libGVPZmZlcnMgPSBvZmZlcnMuZGF0YT8uZGF0YS5maWx0ZXIob2ZmZXIgPT4gb2ZmZXIuc3VwcGxpZXJJZCA9PT0gc3VwcGxpZXJJZCkgfHwgW107XG4gICAgY29uc3QgcHJvY3VyZW1lbnRCdWRnZXRzID0gYnVkZ2V0cy5kYXRhPy5kYXRhLmZpbHRlcigoYnVkZ2V0OiBCdWRnZXRQb2xpY3kpID0+IGJ1ZGdldC5raW5kID09PSAncHJvY3VyZW1lbnQnICYmIGJ1ZGdldC5lbmFibGVkICYmICEhYnVkZ2V0LmxpbWl0QW1vdW50ICYmICEhYnVkZ2V0LmFwcHJvdmFsSWQgJiYgISFidWRnZXRBcHByb3ZhbHMuZGF0YT8ubWV0YS5hc09mICYmIGJ1ZGdldEFwcHJvdmFscy5kYXRhLmRhdGEuc29tZShhcHByb3ZhbCA9PiBhcHByb3ZhbC5pZCA9PT0gYnVkZ2V0LmFwcHJvdmFsSWQgJiYgYXBwcm92YWwuc3RhdHVzID09PSAnYXBwcm92ZWQnICYmIGFwcHJvdmFsLnJlc291cmNlLnR5cGUgPT09ICdidWRnZXRfcG9saWN5JyAmJiBhcHByb3ZhbC5yZXNvdXJjZS5pZCA9PT0gYnVkZ2V0LmlkICYmIGFwcHJvdmFsLnJlc291cmNlVmVyc2lvbiA9PT0gYnVkZ2V0LnZlcnNpb24gJiYgRGF0ZS5wYXJzZShhcHByb3ZhbC5leHBpcmVzQXQpID4gRGF0ZS5wYXJzZShidWRnZXRBcHByb3ZhbHMuZGF0YT8ubWV0YS5hc09mIHx8ICcnKSkgKSB8fCBbXTtcbiAgICBjb25zdCBzZWxlY3RlZEJ1ZGdldCA9IHByb2N1cmVtZW50QnVkZ2V0cy5maW5kKGJ1ZGdldCA9PiBidWRnZXQuaWQgPT09IGJ1ZGdldElkKTtcbiAgICBjb25zdCB2YWxpZEFtb3VudCA9IC9eXFxkKyQvLnRlc3QobWF4UGVyT3JkZXIpICYmIE51bWJlcihtYXhQZXJPcmRlcikgPiAwICYmICEhc2VsZWN0ZWRCdWRnZXQ/LmxpbWl0QW1vdW50ICYmIE51bWJlcihtYXhQZXJPcmRlcikgPD0gTnVtYmVyKHNlbGVjdGVkQnVkZ2V0LmxpbWl0QW1vdW50LmFtb3VudCk7XG4gICAgY29uc3QgZXhwaXJ5VmFsaWQgPSBOdW1iZXIuaXNGaW5pdGUoRGF0ZS5wYXJzZShleHBpcmVzQXQpKSAmJiBEYXRlLnBhcnNlKGV4cGlyZXNBdCkgPiBEYXRlLm5vdygpO1xuICAgIGNvbnN0IGNhbkNyZWF0ZSA9ICEhYWdlbnRJZCAmJiAhIXN1cHBsaWVySWQgJiYgISF3YXJlaG91c2VJZCAmJiBvZmZlcklkcy5sZW5ndGggPiAwICYmICEhc2VsZWN0ZWRCdWRnZXQgJiYgdmFsaWRBbW91bnQgJiYgZXhwaXJ5VmFsaWQgJiYgIWNyZWF0ZS5wZW5kaW5nO1xuICAgIGNvbnN0IG9wZW5DcmVhdGUgPSAoKSA9PiB7XG4gICAgICAgIHNldEFnZW50SWQocmVhZHlBZ2VudHNbMF0/LmlkIHx8ICcnKTtcbiAgICAgICAgc2V0U3VwcGxpZXJJZCgnJyk7XG4gICAgICAgIHNldFdhcmVob3VzZUlkKHdhcmVob3VzZXMuZGF0YT8uZGF0YVswXT8uaWQgfHwgJycpO1xuICAgICAgICBzZXRPZmZlcklkcyhbXSk7XG4gICAgICAgIHNldEJ1ZGdldElkKHByb2N1cmVtZW50QnVkZ2V0c1swXT8uaWQgfHwgJycpO1xuICAgICAgICBzZXRNYXhQZXJPcmRlcignMzAwMDAwJyk7XG4gICAgICAgIHNldEV4cGlyZXNBdChsb2NhbERhdGVUaW1lSW5wdXQoRGF0ZS5ub3coKSArIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKSk7XG4gICAgICAgIGNyZWF0ZS5jbGVhckVycm9yKCk7XG4gICAgICAgIHNldERpYWxvZ09wZW4odHJ1ZSk7XG4gICAgfTtcbiAgICBjb25zdCBzYXZlR3JhbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghY2FuQ3JlYXRlIHx8ICFzZWxlY3RlZEJ1ZGdldCkgcmV0dXJuO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5OiB7XG4gICAgICAgICAgICAgICAgYWdlbnRJZCwgc3VwcGxpZXJJZCwgd2FyZWhvdXNlSWQsIG9mZmVySWRzLFxuICAgICAgICAgICAgICAgIG1heFBlck9yZGVyOiB7IGFtb3VudDogbWF4UGVyT3JkZXIsIGN1cnJlbmN5OiBzaG9wLmN1cnJlbmN5IH0sXG4gICAgICAgICAgICAgICAgYnVkZ2V0UG9saWN5SWQ6IGJ1ZGdldElkLCBleHBpcmVzQXQ6IG5ldyBEYXRlKGV4cGlyZXNBdCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgIH0gfSk7XG4gICAgICAgICAgICBzZXREaWFsb2dPcGVuKGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7IC8qIGdp4buvIGJp4buDdSBt4bqrdSB2w6AgbOG7l2kgdOG6oWkgY2jhu5cgxJHhu4MgbmfGsOG7nWkgZMO5bmcgc+G7rWEgaG/hurdjIHRo4butIGzhuqFpICovIH1cbiAgICB9O1xuICAgIGNvbnN0IGdyYW50TGFiZWwgPSAoZ3JhbnQ6IFB1cmNoYXNlRGVsZWdhdGlvbikgPT4ge1xuICAgICAgICBjb25zdCBhZ2VudCA9IGFnZW50cy5kYXRhPy5kYXRhLmZpbmQocm93ID0+IHJvdy5pZCA9PT0gZ3JhbnQuYWdlbnRJZCk7XG4gICAgICAgIGNvbnN0IHN1cHBsaWVyID0gc3VwcGxpZXJzLmRhdGE/LmRhdGEuZmluZChyb3cgPT4gcm93LmlkID09PSBncmFudC5zdXBwbGllcklkKTtcbiAgICAgICAgY29uc3Qgd2FyZWhvdXNlID0gd2FyZWhvdXNlcy5kYXRhPy5kYXRhLmZpbmQocm93ID0+IHJvdy5pZCA9PT0gZ3JhbnQud2FyZWhvdXNlSWQpO1xuICAgICAgICByZXR1cm4gYCR7YWdlbnQ/LmtpbmQgPyByb2xlTmFtZXNbYWdlbnQua2luZF0gOiBgTcOjIHZhaSB0csOyOiAke2dyYW50LmFnZW50SWR9YH0gwrcgJHtzdXBwbGllcj8ubmFtZSB8fCBgTcOjIG5ow6AgY3VuZyBj4bqlcDogJHtncmFudC5zdXBwbGllcklkfWB9IMK3ICR7d2FyZWhvdXNlPy5uYW1lIHx8IGBNw6Mga2hvOiAke2dyYW50LndhcmVob3VzZUlkfWB9YDtcbiAgICB9O1xuXG4gICAgaWYgKCFjYW5SZWFkKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gPFBhbmVsIHRpdGxlPVwi4bumeSBxdXnhu4FuIGfhu61pIMSRxqFuIG11YVwiIHN1YnRpdGxlPVwiQ2jhu4kgb3duZXIgY+G6pXAgcXV54buBbjsgbeG7l2kg4buneSBxdXnhu4FuIGdp4bubaSBo4bqhbiB0aGVvIG5nxrDhu51pIHBo4bulIHRyw6FjaCwgbmjDoCBjdW5nIGPhuqVwLCBraG8sIGLDoW8gZ2nDoSwgbmfDom4gc8OhY2gsIGjhuqFuIG3hu6ljIHbDoCB0aOG7nWkgaOG6oW4uXCI+XG4gICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT7EkMOieSBsw6Agd29ya2VyIE1TVyBsb2NhbCB4w6FjIMSR4buLbmguIEtow7RuZyBn4buNaSBBSSwgbmjDoCBjdW5nIGPhuqVwIGhv4bq3YyB0aGFuaCB0b8OhbjsgdHLhuqFuZyB0aMOhaSDigJzEkcOjIGfhu61p4oCdIGNo4buJIGzDoCBr4bq/dCBxdeG6oyBtw7QgcGjhu49uZy48L0FsZXJ0PlxuICAgICAgICB7Y2FuTWFuYWdlICYmIDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249XCJyb3dcIiBiZWZvcmVHYXA9XCJmb3JtXCI+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJwcm9jdXJlbWVudC5kZWxlZ2F0aW9uLm1hbmFnZVwiIG9uQ2xpY2s9e29wZW5DcmVhdGV9PlThuqFvIOG7p3kgcXV54buBbiBjw7MgZ2nhu5tpIGjhuqFuPC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPn1cbiAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2dyYW50c30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2dyYW50cy5kYXRhICYmIDxEYXRhVGFibGUgbGFiZWw9XCLhu6Z5IHF1eeG7gW4gZ+G7rWkgxJHGoW4gbXVhXCIgcm93cz17Z3JhbnRzLmRhdGEuZGF0YX0gcm93S2V5PXtncmFudCA9PiBncmFudC5pZH0gY29sdW1ucz17W1xuICAgICAgICAgICAgeyBrZXk6ICdzY29wZScsIGxhYmVsOiAnUGjhuqFtIHZpJywgcmVuZGVyOiBncmFudCA9PiA8U3RhY2s+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e2dyYW50TGFiZWwoZ3JhbnQpfTwvVHlwb2dyYXBoeT48VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPntncmFudC5vZmZlclNuYXBzaG90cy5sZW5ndGh9IGLDoW8gZ2nDoSDCtyB04buRaSDEkWEge2dyYW50Lm1heFBlck9yZGVyLmFtb3VudH0ge2dyYW50Lm1heFBlck9yZGVyLmN1cnJlbmN5fSAvIMSRxqFuPC9UeXBvZ3JhcGh5PjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCI+TmfDom4gc8OhY2ggwrcgbcOjIGNow61uaCBzw6FjaCB7Z3JhbnQuYnVkZ2V0UG9saWN5SWR9IMK3IHtncmFudC5idWRnZXRQZXJpb2R9IMK3IMSR4bq/biB7ZGF0ZVRpbWUoZ3JhbnQuZXhwaXJlc0F0LCBzaG9wLnRpbWV6b25lKX08L1R5cG9ncmFwaHk+PC9TdGFjaz4gfSxcbiAgICAgICAgICAgIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGdyYW50ID0+IDxTdGF0dXMgdmFsdWU9e0RhdGUucGFyc2UoZ3JhbnQuZXhwaXJlc0F0KSA8PSBEYXRlLm5vdygpICYmIGdyYW50LnN0YXR1cyA9PT0gJ2FjdGl2ZScgPyAnZXhwaXJlZCcgOiBncmFudC5zdGF0dXN9Lz4gfSxcbiAgICAgICAgICAgIHsga2V5OiAncmVhc29uJywgbGFiZWw6ICdMw70gZG8gZ+G6p24gbmjhuqV0JywgcmVuZGVyOiBncmFudCA9PiBncmFudC5sYXN0UmVhc29uIHx8ICfigJQnIH0sXG4gICAgICAgICAgICB7IGtleTogJ2FjdGlvbnMnLCBsYWJlbDogJycsIHJlbmRlcjogZ3JhbnQgPT4gPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiPlxuICAgICAgICAgICAgICAgIHtncmFudC5zdGF0dXMgIT09ICdyZXZva2VkJyAmJiBEYXRlLnBhcnNlKGdyYW50LmV4cGlyZXNBdCkgPiBEYXRlLm5vdygpICYmIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJvY3VyZW1lbnQuZGVsZWdhdGlvbi5tYW5hZ2VcIiBkaXNhYmxlZD17dXBkYXRlLnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHsgc2V0QWN0aW9uR3JhbnQoZ3JhbnQpOyBzZXRBY3Rpb25TdGF0dXMoZ3JhbnQuc3RhdHVzID09PSAnYWN0aXZlJyA/ICdwYXVzZWQnIDogJ2FjdGl2ZScpOyB9fT57Z3JhbnQuc3RhdHVzID09PSAnYWN0aXZlJyA/ICdU4bqhbSBk4burbmcnIDogJ0vDrWNoIGhv4bqhdCd9PC9NdXRhdGlvbkJ1dHRvbj59XG4gICAgICAgICAgICAgICAge2dyYW50LnN0YXR1cyAhPT0gJ3Jldm9rZWQnICYmIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwicHJvY3VyZW1lbnQuZGVsZWdhdGlvbi5tYW5hZ2VcIiBjb2xvcj1cImVycm9yXCIgZGlzYWJsZWQ9e3VwZGF0ZS5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB7IHNldEFjdGlvbkdyYW50KGdyYW50KTsgc2V0QWN0aW9uU3RhdHVzKCdyZXZva2VkJyk7IH19PlRodSBo4buTaTwvTXV0YXRpb25CdXR0b24+fVxuICAgICAgICAgICAgPC9BY3Rpb25Hcm91cD4gfSxcbiAgICAgICAgXX0vPn08L1F1ZXJ5U3RhdGU+XG4gICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtyZXNlcnZhdGlvbnN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntyZXNlcnZhdGlvbnMuZGF0YSAmJiA8RGF0YVRhYmxlIGxhYmVsPVwiTOG7i2NoIHPhu60gaOG6oW4gbeG7qWMgbXVhIHThu7EgxJHhu5luZ1wiIHJvd3M9e3Jlc2VydmF0aW9ucy5kYXRhLmRhdGEgYXMgUHVyY2hhc2VEZWxlZ2F0aW9uUmVzZXJ2YXRpb25bXX0gcm93S2V5PXtyb3cgPT4gcm93LmlkfSBjb2x1bW5zPXtbXG4gICAgICAgICAgICB7IGtleTogJ3B1cmNoYXNlJywgbGFiZWw6ICfEkMahbiBtdWEnLCByZW5kZXI6IHJvdyA9PiByb3cucHVyY2hhc2VPcmRlcklkIH0sXG4gICAgICAgICAgICB7IGtleTogJ2Ftb3VudCcsIGxhYmVsOiAnU+G7kSB0aeG7gW4nLCByZW5kZXI6IHJvdyA9PiA8QW1vdW50IHZhbHVlPXtyb3cuYW1vdW50fS8+IH0sXG4gICAgICAgICAgICB7IGtleTogJ3BlcmlvZCcsIGxhYmVsOiAnS+G7syBuZ8OibiBzw6FjaCcsIHJlbmRlcjogcm93ID0+IHJvdy5wZXJpb2RLZXkgfSxcbiAgICAgICAgICAgIHsga2V5OiAnc3RhdHVzJywgbGFiZWw6ICfEkOG7kWkgY2hp4bq/dScsIHJlbmRlcjogcm93ID0+IDxTdGF0dXMgdmFsdWU9e3Jvdy5zdGF0dXN9Lz4gfSxcbiAgICAgICAgXX0vPn08L1F1ZXJ5U3RhdGU+XG4gICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yIHx8IHVwZGF0ZS5lcnJvcn0vPlxuICAgICAgICA8RWRpdERpYWxvZyBvcGVuPXtkaWFsb2dPcGVufSB0aXRsZT1cIlThuqFvIOG7p3kgcXV54buBbiBtdWEgaMOgbmdcIiBkZXNjcmlwdGlvbj1cIuG7pnkgcXV54buBbiB04bqhbyDhu58gdHLhuqFuZyB0aMOhaSB04bqhbSBk4burbmcuIEvDrWNoIGhv4bqhdCBjaOG7iSBraOG6oyBk4bulbmcgc2F1IGtoaSB2YWkgdHLDsiwgYsOhbyBnacOhIHbDoCBuZ8OibiBzw6FjaCDEkcaw4bujYyBraeG7g20gdHJhIGzhuqFpLlwiIG9uQ2xvc2U9eygpID0+IHNldERpYWxvZ09wZW4oZmFsc2UpfSBidXN5PXtjcmVhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFjYW5DcmVhdGV9IG9uQ2xpY2s9eygpID0+IHZvaWQgc2F2ZUdyYW50KCl9PlThuqFvIOG7nyB0cuG6oW5nIHRow6FpIHThuqFtIGThu6tuZzwvQnV0dG9uPn0+XG4gICAgICAgICAgICA8RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvcn0vPlxuICAgICAgICAgICAgPEZvcm1GaWVsZHM+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJWYWkgdHLDsiBtdWEgaMOgbmcgY2jhu4t1IHRyw6FjaCBuaGnhu4dtXCIgdmFsdWU9e2FnZW50SWR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRBZ2VudElkKGV2ZW50LnRhcmdldC52YWx1ZSl9PntyZWFkeUFnZW50cy5tYXAoYWdlbnQgPT4gPE1lbnVJdGVtIGtleT17YWdlbnQuaWR9IHZhbHVlPXthZ2VudC5pZH0+e3JvbGVOYW1lc1thZ2VudC5raW5kXX0gwrcge2FnZW50LmlkfSDCtyB7YWdlbnQuc3RhdHVzID09PSAncGF1c2VkJyA/ICfEkWFuZyB04bqhbSBk4burbmcnIDogYWdlbnQuc3RhdHVzfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD5cbiAgICAgICAgICAgICAgICB7cmVhZHlBZ2VudHMubGVuZ3RoID09PSAwICYmIDxUeXBvZ3JhcGh5IHJvbGU9XCJzdGF0dXNcIj5LaMO0bmcgY8OzIHZhaSB0csOyIHdhcmVob3VzZV9idXllciBkbyB0w6BpIGtob+G6o24gaGnhu4duIHThuqFpIHBo4bulIHRyw6FjaC48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiTmjDoCBjdW5nIGPhuqVwIMSRw6MgZHV54buHdFwiIHZhbHVlPXtzdXBwbGllcklkfSBvbkNoYW5nZT17ZXZlbnQgPT4geyBzZXRTdXBwbGllcklkKGV2ZW50LnRhcmdldC52YWx1ZSk7IHNldE9mZmVySWRzKFtdKTsgfX0+e2FwcHJvdmVkU3VwcGxpZXJzLm1hcChzdXBwbGllciA9PiA8TWVudUl0ZW0ga2V5PXtzdXBwbGllci5pZH0gdmFsdWU9e3N1cHBsaWVyLmlkfT57c3VwcGxpZXIubmFtZX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJLaG8gxJFhbmcgaG/huqF0IMSR4buZbmdcIiB2YWx1ZT17d2FyZWhvdXNlSWR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRXYXJlaG91c2VJZChldmVudC50YXJnZXQudmFsdWUpfT57d2FyZWhvdXNlcy5kYXRhPy5kYXRhLm1hcCh3YXJlaG91c2UgPT4gPE1lbnVJdGVtIGtleT17d2FyZWhvdXNlLmlkfSB2YWx1ZT17d2FyZWhvdXNlLmlkfT57d2FyZWhvdXNlLmNvZGV9IMK3IHt3YXJlaG91c2UubmFtZX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJCw6FvIGdpw6EgbuG6sW0gdHJvbmcgcGjhuqFtIHZpXCIgdmFsdWU9e29mZmVySWRzfSBzbG90UHJvcHM9e3sgc2VsZWN0OiB7IG11bHRpcGxlOiB0cnVlIH0gfX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldE9mZmVySWRzKHR5cGVvZiBldmVudC50YXJnZXQudmFsdWUgPT09ICdzdHJpbmcnID8gZXZlbnQudGFyZ2V0LnZhbHVlLnNwbGl0KCcsJykgOiBldmVudC50YXJnZXQudmFsdWUpfT57ZWxpZ2libGVPZmZlcnMubWFwKChvZmZlcjogU3VwcGxpZXJPZmZlcikgPT4gPE1lbnVJdGVtIGtleT17b2ZmZXIuaWR9IHZhbHVlPXtvZmZlci5pZH0+e29mZmVyLmlkfSDCtyBNw6MgYmnhur9uIHRo4buDOiB7b2ZmZXIudmFyaWFudElkfSDCtyB7b2ZmZXIudW5pdENvc3QuYW1vdW50fSB7b2ZmZXIudW5pdENvc3QuY3VycmVuY3l9IMK3IE1PUSB7b2ZmZXIubWluaW11bVF1YW50aXR5fS97b2ZmZXIucGFja1NpemV9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPlxuICAgICAgICAgICAgICAgIHtidWRnZXRBcHByb3ZhbHMuaXNQZW5kaW5nICYmIDxUeXBvZ3JhcGh5IHJvbGU9XCJzdGF0dXNcIj7EkGFuZyDEkeG7kWkgY2hp4bq/dSBwaMOqIGR1eeG7h3QgbmfDom4gc8OhY2jigKY8L1R5cG9ncmFwaHk+fXtidWRnZXRBcHByb3ZhbHMuaXNFcnJvciAmJiA8RXJyb3JOb3RpY2UgZXJyb3I9e2J1ZGdldEFwcHJvdmFscy5lcnJvcn0vPn08VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIk5nw6JuIHPDoWNoIG11YSBow6BuZyDEkcOjIGLhuq10IHbDoCDEkcaw4bujYyBkdXnhu4d0XCIgdmFsdWU9e2J1ZGdldElkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0QnVkZ2V0SWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0+e3Byb2N1cmVtZW50QnVkZ2V0cy5tYXAoYnVkZ2V0ID0+IDxNZW51SXRlbSBrZXk9e2J1ZGdldC5pZH0gdmFsdWU9e2J1ZGdldC5pZH0+e2J1ZGdldC5pZH0gwrcge2J1ZGdldC5saW1pdEFtb3VudD8uYW1vdW50fSB7YnVkZ2V0LmxpbWl0QW1vdW50Py5jdXJyZW5jeX0gwrcge2J1ZGdldC5wZXJpb2R9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPnshYnVkZ2V0QXBwcm92YWxzLmlzUGVuZGluZyAmJiAhYnVkZ2V0QXBwcm92YWxzLmlzRXJyb3IgJiYgcHJvY3VyZW1lbnRCdWRnZXRzLmxlbmd0aCA9PT0gMCAmJiA8VHlwb2dyYXBoeSByb2xlPVwic3RhdHVzXCI+S2jDtG5nIGPDsyBuZ8OibiBzw6FjaCBtdWEgaMOgbmcgxJFhbmcgYuG6rXQsIGPDsm4gaGnhu4d1IGzhu7FjIHBow6ogZHV54buHdCB2w6Aga2jhu5twIHBoacOqbiBi4bqjbi48L1R5cG9ncmFwaHk+fVxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJI4bqhbiBt4bupYyBt4buXaSDEkcahblwiIHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17bWF4UGVyT3JkZXJ9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRNYXhQZXJPcmRlcihldmVudC50YXJnZXQudmFsdWUpfSBpbnB1dFByb3BzPXt7IG1pbjogMSwgc3RlcDogMSB9fSBlcnJvcj17bWF4UGVyT3JkZXIgIT09ICcnICYmICF2YWxpZEFtb3VudH0gaGVscGVyVGV4dD17c2VsZWN0ZWRCdWRnZXQgPyBgS2jDtG5nIHbGsOG7o3QgJHtzZWxlY3RlZEJ1ZGdldC5saW1pdEFtb3VudD8uYW1vdW50fSAke3Nob3AuY3VycmVuY3l9LmAgOiAnQ2jhu41uIG5nw6JuIHPDoWNoIMSRw6MgYuG6rXQgdHLGsOG7m2MuJ30vPlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgbGFiZWw9XCJI4bq/dCBo4bqhbiB2w6BvXCIgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCIgdmFsdWU9e2V4cGlyZXNBdH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEV4cGlyZXNBdChldmVudC50YXJnZXQudmFsdWUpfSBlcnJvcj17ZXhwaXJlc0F0ICE9PSAnJyAmJiAhZXhwaXJ5VmFsaWR9Lz5cbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiPkLhuqNuIGdoaSBsxrB1IHNuYXBzaG90IGdpw6EvTU9RL3F1eSBjw6FjaCB2w6AgcGhpw6puIGLhuqNuIG5nw6JuIHPDoWNoLiBN4buNaSB0aGF5IMSR4buVaSB0cm9uZyBzY29wZSBz4bq9IGNo4bq3biBs4bqnbiBn4butaSB0aeG6v3AgdGhlby48L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XG4gICAgICAgIDwvRWRpdERpYWxvZz5cbiAgICAgICAgPENvbmZpcm1EaWFsb2cgb3Blbj17ISFhY3Rpb25HcmFudH0gdGl0bGU9e2FjdGlvblN0YXR1cyA9PT0gJ3Jldm9rZWQnID8gJ1RodSBo4buTaSDhu6d5IHF1eeG7gW4gZ+G7rWkgxJHGoW4nIDogYWN0aW9uU3RhdHVzID09PSAnYWN0aXZlJyA/ICdLw61jaCBob+G6oXQg4buneSBxdXnhu4FuIGfhu61pIMSRxqFuJyA6ICdU4bqhbSBk4burbmcg4buneSBxdXnhu4FuIGfhu61pIMSRxqFuJ30gZGVzY3JpcHRpb249e2Ake2FjdGlvbkdyYW50ID8gZ3JhbnRMYWJlbChhY3Rpb25HcmFudCkgOiAnJ30uIEjhuqFuIG3hu6ljICR7YWN0aW9uR3JhbnQ/Lm1heFBlck9yZGVyLmFtb3VudCB8fCAnJ30gJHthY3Rpb25HcmFudD8ubWF4UGVyT3JkZXIuY3VycmVuY3kgfHwgJyd9L8SRxqFuOyBow6BuaCDEkeG7mW5nIMOhcCBk4bulbmcgY2hvICR7YWN0aW9uR3JhbnQ/LnRvb2xJZCB8fCAncHVyY2hhc2Uuc2VuZCd9LiBM4buHbmggxJHDoyDEkcaw4bujYyB0aeG6v3Agbmjhuq1uIGtow7RuZyB0aOG7gyBi4buLIHRodSBo4buTaS5gfSBjb25maXJtTGFiZWw9e2FjdGlvblN0YXR1cyA9PT0gJ3Jldm9rZWQnID8gJ1RodSBo4buTaSDhu6d5IHF1eeG7gW4nIDogYWN0aW9uU3RhdHVzID09PSAnYWN0aXZlJyA/ICdLw61jaCBob+G6oXQg4buneSBxdXnhu4FuJyA6ICdU4bqhbSBk4burbmcg4buneSBxdXnhu4FuJ30gcmVxdWlyZVJlYXNvbiBidXN5PXt1cGRhdGUucGVuZGluZ30gZXJyb3I9e3VwZGF0ZS5lcnJvcn0gb25DbG9zZT17KCkgPT4gc2V0QWN0aW9uR3JhbnQobnVsbCl9IG9uQ29uZmlybT17YXN5bmMgcmVhc29uID0+IHtcbiAgICAgICAgICAgIGlmICghYWN0aW9uR3JhbnQpIHJldHVybjtcbiAgICAgICAgICAgIHRyeSB7IGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBhY3Rpb25HcmFudC5pZCB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogYWN0aW9uR3JhbnQudmVyc2lvbiwgc3RhdHVzOiBhY3Rpb25TdGF0dXMsIHJlYXNvbiB9IH0pOyBzZXRBY3Rpb25HcmFudChudWxsKTsgfVxuICAgICAgICAgICAgY2F0Y2ggeyAvKiBnaeG7ryBxdXnhur90IMSR4buLbmggdsOgIGzDvSBkbyDEkeG7gyDEkeG7kWkgY2hp4bq/dSBs4buXaS92ZXJzaW9uICovIH1cbiAgICAgICAgfX0vPlxuICAgIDwvUGFuZWw+O1xufVxuXG5mdW5jdGlvbiBsb2NhbERhdGVUaW1lSW5wdXQodGltZXN0YW1wOiBudW1iZXIpIHtcbiAgICBjb25zdCBsb2NhbCA9IG5ldyBEYXRlKHRpbWVzdGFtcCAtIG5ldyBEYXRlKHRpbWVzdGFtcCkuZ2V0VGltZXpvbmVPZmZzZXQoKSAqIDYwXzAwMCk7XG4gICAgcmV0dXJuIGxvY2FsLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTYpO1xufVxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEaWdlc3RzUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3REaWdlc3RzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0RGlnZXN0cycpIH0pO1xyXG4gICAgY29uc3QgaGVhbHRoID0gdXNlQXBpKCdnZXRPcGVyYXRpb25zU3VtbWFyeScpO1xyXG4gICAgY29uc3QgY29udHJvbCA9IHVzZUNvbW1hbmQoJ2NvbnRyb2xBdXRvbWF0aW9uJywgWydsaXN0QWdlbnRSb2xlcycsICdnZXRCb3RDb25maWcnLCAnZ2V0T3BlcmF0aW9uc1N1bW1hcnknXSk7XHJcbiAgICBjb25zdCBbc3RvcCwgc2V0U3RvcF0gPSB1c2VTdGF0ZTx7IHJvbGU6IEFnZW50Um9sZTsgYWN0aW9uOiAncGF1c2UnIHwgJ3Jlc3VtZScgfSB8IG51bGw+KG51bGwpO1xyXG5cclxuICAgIHJldHVybiA8PlxyXG4gICAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPVwiQuG6o24gdGluICYgc+G7qWMga2jhu49lIGjhu4cgdGjhu5FuZ1wiIHN1YnRpdGxlPVwiTmjhu69uZyB2aeG7h2MgcXVhbiB0cuG7jW5nIGPhuqduIGNo4bunIHNob3AgcXV54bq/dCDEkeG7i25oOyBraMO0bmcgdGhheSB0aOG6vyBuZ8aw4budaSB0cuG7sWMgdGjhu7FjIHThur8uXCIgLz5cclxuICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+xJDDonkgbMOgIGThu68gbGnhu4d1IG3DtCBwaOG7j25nLiBUcuG6oW5nIHRow6FpIOKAnGNoxrBhIHjDoWMgbWluaOKAnSBraMO0bmcgY2jhu6luZyBtaW5oIGJhY2tlbmQsIHByb3ZpZGVyIGhv4bq3YyB3b3JrZXIgxJHDoyBz4bq1biBzw6BuZy48L0FsZXJ0PlxyXG4gICAgICAgIDxTZWN0aW9uR3JpZCBjb2x1bW5zPXt7IHhzOiAnMWZyJywgbGc6ICcxLjVmciAxZnInIH19PlxyXG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJC4bqjbiB0aW4gxJFp4buBdSBow6BuaFwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cclxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fT5cclxuICAgICAgICAgICAgICAgICAgICA8U3VyZmFjZUNvbnRlbnQgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGlzdC5kYXRhPy5kYXRhLm1hcChkaWdlc3QgPT4gPEJveCBrZXk9e2RpZ2VzdC5pZH0gc3g9e1tsYXlvdXRTeC5kZXRhaWwucmVsYXRlZEl0ZW1JbnNldCwgeyBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmRpYWxvZyB9XX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCIgc3g9e2xheW91dFN4LnN1cmZhY2UuaGVhZGVyRmxvd0dhcH0+PFN0YWNrPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIj57ZGF0ZVRpbWUoZGlnZXN0LnBlcmlvZFN0YXJ0LCBzaG9wLnRpbWV6b25lKX0g4oaSIHtkYXRlVGltZShkaWdlc3QucGVyaW9kRW5kLCBzaG9wLnRpbWV6b25lKX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e2RpZ2VzdC5pZH0gwrcgcGhpw6puIGLhuqNuIHtkaWdlc3QudmVyc2lvbn08L1R5cG9ncmFwaHk+PC9TdGFjaz48U3RhdHVzIHZhbHVlPXtkaWdlc3Quc3RhdHVzfSAvPjwvU3RhY2s+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBzeD17W2xheW91dFN4LnN1cmZhY2Uuc2VjdGlvbkJlZm9yZSwgeyB3aGl0ZVNwYWNlOiAncHJlLXdyYXAnIH1dfT57ZGlnZXN0LnRleHR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJUaOG7nWkgxJFp4buDbSB04bqhbyAvIGPhuq1wIG5o4bqtdFwiPntkYXRlVGltZShkaWdlc3QuY3JlYXRlZEF0LCBzaG9wLnRpbWV6b25lKX0gLyB7ZGF0ZVRpbWUoZGlnZXN0LnVwZGF0ZWRBdCwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJOZ3Xhu5NuIGPDtG5nIHZp4buHY1wiPntkaWdlc3Qud29ya0l0ZW1JZHMubGVuZ3RoID8gZGlnZXN0LndvcmtJdGVtSWRzLmpvaW4oJyDCtyAnKSA6ICdLaMO0bmcgY8OzIG3hu6VjIGPDtG5nIHZp4buHYyDEkcaw4bujYyB0aGFtIGNoaeG6v3UnfTwvRGV0YWlsTGluZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YT8ucGFnZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1N1cmZhY2VDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxyXG4gICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJUcuG6oW5nIHRow6FpIHBo4bulIHRodeG7mWNcIiBib2R5TW9kZT1cImluc2V0XCI+XHJcbiAgICAgICAgICAgICAgICA8UXVlcnlTdGF0ZSBxdWVyeT17aGVhbHRofT5cclxuICAgICAgICAgICAgICAgICAgICA8U3RhY2s+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWFsdGguZGF0YT8uZGF0YS5oZWFsdGgubWFwKGNoZWNrID0+IDxCb3gga2V5PXtjaGVjay5jb21wb25lbnR9IHN4PXtsYXlvdXRTeC5wYWdlLnNlY3Rpb25BZnRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPVwicm93XCIganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCI+PFR5cG9ncmFwaHk+e2NoZWNrLmNvbXBvbmVudH08L1R5cG9ncmFwaHk+PFN0YXR1cyB2YWx1ZT17Y2hlY2suc3RhdHVzfSAvPjwvU3RhY2s+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LmRldGFpbC5yZWxhdGVkQ29udGVudEdhcH0+e2NoZWNrLnJlYXNvbiB8fCAnS2jDtG5nIGPDsyBnaGkgY2jDuid9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIj57Y2hlY2suY2hlY2tlZEF0ID8gZGF0ZVRpbWUoY2hlY2suY2hlY2tlZEF0LCBzaG9wLnRpbWV6b25lKSA6ICdDaMawYSBraeG7g20gdHJhIHRo4buxYyB04bq/J308L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94Pil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3guc3VyZmFjZS5zZWN0aW9uQmVmb3JlfT5DaOG7iSBoaeG7g24gdGjhu4sgbOG7i2NoIHPhu60gYuG6o24gdGluIHRoZW8gaOG7o3AgxJHhu5NuZyBoaeG7h24gaMOgbmguIENoxrBhIGPDsyBBUEkgdOG6oW8vc+G7rWEgbOG7i2NoIGLhuqNuIHRpbjsga2jDtG5nIGThu7FuZyBuw7p0IGzGsHUgbOG7i2NoIGdp4bqjLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDwvUGFuZWw+XHJcbiAgICAgICAgPC9TZWN0aW9uR3JpZD5cclxuICAgICAgICA8UGFuZWwgdGl0bGU9XCJQaOG7pWMgaOG7k2kgJiBz4bq1biBzw6BuZyB0cmnhu4NuIGtoYWlcIiBzdWJ0aXRsZT1cIkLhuqNuZyBraeG7g20gaGnhu4NuIHRo4buLIHLDtSBuaOG7r25nIMSRaeG7gXUgY2jGsGEgxJHGsOG7o2MgeMOhYyBtaW5oIHRyb25nIGLhuqNuIGZyb250ZW5kIGRlbW8uXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0gYm9keU1vZGU9XCJpbnNldFwiPlxyXG4gICAgICAgICAgICA8U3VyZmFjZUNvbnRlbnQgIGRhdGEtdGVzdGlkPVwicmVhZGluZXNzLXByZXZpZXdcIj5cclxuICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5DaMawYSBjw7Mgbmd14buTbiByZWFkaW5lc3MvcmVzdG9yZSB0cm9uZyBBUEkgaGnhu4duIGjDoG5oLiBDw6FjIG3hu6VjIGLDqm4gZMaw4bubaSBnaeG7ryB0cuG6oW5nIHRow6FpIGNoxrBhIHjDoWMgbWluaCB2w6Aga2jDtG5nIHRo4buDIGPhuqVwIHTDrW4gaGnhu4d1IGNobyBwaMOpcCBwaMOhdCBow6BuaC48L0FsZXJ0PlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICBbJ0Rp4buFbiB04bqtcCBraMO0aSBwaOG7pWMgYuG6o24gc2FvIGzGsHUnLCAnQ2jGsGEgeMOhYyBtaW5oJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgWydLaeG7g20gdHJhIGZyZXNobmVzcyBj4bunYSBhcnRpZmFjdCB2w6AgcmV2aXNpb24nLCAnQ2jGsGEgeMOhYyBtaW5oJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgWydHYXRlcyB0cmnhu4NuIGtoYWkgdsOgIGvhur90IHF14bqjIENJJywgJ0NoxrBhIHjDoWMgbWluaCddLFxyXG4gICAgICAgICAgICAgICAgICAgIFsnTcO0aSB0csaw4budbmcvcHJvdmlkZXIgc2F1IGtoaSBraMO0aSBwaOG7pWMnLCAnQ2jGsGEgeMOhYyBtaW5oJ10sXHJcbiAgICAgICAgICAgICAgICBdLm1hcCgoW2NyaXRlcmlvbiwgc3RhdHVzXSkgPT4gPEJveCBrZXk9e2NyaXRlcmlvbn0gc3g9e1tsYXlvdXRTeC5kZXRhaWwudmFsdWVHYXAsIGxheW91dFN4LmRldGFpbC5yb3dJbnNldEJsb2NrLCB7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZmxleFdyYXA6ICd3cmFwJywgYm9yZGVyQm90dG9tOiAxLCBib3JkZXJDb2xvcjogJ2RpdmlkZXInIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeT57Y3JpdGVyaW9ufTwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cIndhcm5pbmcubWFpblwiPntzdGF0dXN9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+KX1cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkPDsyBi4bqjbiBzYW8gbMawdSBraMO0bmcgY2jhu6luZyBtaW5oIMSRw6Mga2jDtGkgcGjhu6VjIHRow6BuaCBjw7RuZy4gS2jDtG5nIGPDsyBuw7p0IOKAnHPhurVuIHPDoG5n4oCdIHRyb25nIGNo4bq/IMSR4buZIG3DtCBwaOG7j25nLjwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPC9TdXJmYWNlQ29udGVudD5cclxuICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgIDxQYW5lbCB0aXRsZT1cIlF1eeG7gW4gZOG7q25nIHZhaSB0csOyIEFJXCIgc3VidGl0bGU9XCJM4buHbmggxJHGsOG7o2MgbcO0IHBo4buPbmcgdGhlbyB2ZXJzaW9uIGPhu6dhIHThu6tuZyB2YWkgdHLDsjsgdGnhur9wIHThu6VjIGtow7RuZyDEkeG7k25nIG5naMSpYSBo4buHIHRo4buRbmcgxJHDoyBz4bq1biBzw6BuZy5cIiBiZWZvcmVHYXA9e1wic2VjdGlvblwifSBib2R5TW9kZT1cImluc2V0XCI+XHJcbiAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtoZWFsdGh9PlxyXG4gICAgICAgICAgICAgICAgPFN0YWNrIHN4PXtsYXlvdXRTeC5kZXRhaWwucmVsYXRlZEl0ZW1HYXB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtoZWFsdGguZGF0YT8uZGF0YS5yb2xlcy5tYXAocm9sZSA9PiA8Qm94IGtleT17cm9sZS5pZH0gc3g9e1tsYXlvdXRTeC5kZXRhaWwudmFsdWVHYXAsIGxheW91dFN4LmRldGFpbC5yb3dJbnNldEJsb2NrLCB7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGZsZXhXcmFwOiAnd3JhcCcsIGJvcmRlckJvdHRvbTogMSwgYm9yZGVyQ29sb3I6ICdkaXZpZGVyJyB9XX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFjaz48VHlwb2dyYXBoeSBmb250V2VpZ2h0PXt2aXN1YWxTeC50eXBvZ3JhcGh5LmZvbnRXZWlnaHQuc2VtaWJvbGR9Pntyb2xlTmFtZXNbcm9sZS5raW5kXX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+VGjhur8gaOG7hyB7cm9sZS5nZW5lcmF0aW9ufSDCtyB7cm9sZS5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ8SQYW5nIHThuqFtIGThu6tuZycgOiByb2xlLnN0YXR1cyA9PT0gJ25vdF9jb25maWd1cmVkJyA/ICdDaMawYSBj4bqldSBow6xuaCcgOiByb2xlLnN0YXR1c308L1R5cG9ncmFwaHk+PC9TdGFjaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJib3QucGF1c2VcIiBjb2xvcj17cm9sZS5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ3ByaW1hcnknIDogJ2Vycm9yJ30gb25DbGljaz17KCkgPT4gc2V0U3RvcCh7IHJvbGUsIGFjdGlvbjogcm9sZS5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ3Jlc3VtZScgOiAncGF1c2UnIH0pfT57cm9sZS5zdGF0dXMgPT09ICdwYXVzZWQnID8gJ0tp4buDbSB0cmEgxJFp4buBdSBraeG7h24gdGnhur9wIHThu6VjJyA6ICdU4bqhbSBk4burbmcgdmFpIHRyw7InfTwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+KX1cclxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XHJcbiAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjb250cm9sLmVycm9yfSAvPlxyXG4gICAgICAgIDwvUGFuZWw+XHJcbiAgICAgICAgPENvbmZpcm1EaWFsb2cgb3Blbj17Qm9vbGVhbihzdG9wKX0gdGl0bGU9e3N0b3A/LmFjdGlvbiA9PT0gJ3BhdXNlJyA/ICdU4bqhbSBk4burbmcgdmFpIHRyw7IgQUknIDogJ0tp4buDbSB0cmEgxJFp4buBdSBraeG7h24gdGnhur9wIHThu6VjJ30gY29uZmlybUxhYmVsPXtzdG9wPy5hY3Rpb24gPT09IFwicGF1c2VcIiA/IFwiVOG6oW0gZOG7q25nIHZhaSB0csOyXCIgOiBcIktp4buDbSB0cmEgxJHhu4MgdGnhur9wIHThu6VjXCJ9IGRlc2NyaXB0aW9uPXtgJHtzdG9wID8gcm9sZU5hbWVzW3N0b3Aucm9sZS5raW5kXSA6IFwiXCJ9ICgke3N0b3A/LnJvbGUuaWQgfHwgXCJcIn0pIHRyb25nICR7c2hvcC5uYW1lfTogJHtzdG9wPy5hY3Rpb24gPT09IFwicGF1c2VcIiA/IFwiZOG7q25nIGPDoWMgdMOhYyDEkeG7mW5nIGNoxrBhIMSRxrDhu6NjIHRp4bq/cCBuaOG6rW4uXCIgOiBcImtp4buDbSDEkWnhu4F1IGtp4buHbiB2w6AgY2jDrW5oIHPDoWNoIHRyxrDhu5tjIGtoaSBjaG8gcGjDqXAgdMOhYyDEkeG7mW5nIG3hu5tpLlwifSBUw6FjIMSR4buZbmcgYsOqbiBuZ2/DoGkgxJHDoyDEkcaw4bujYyBuaOG6rW4ga2jDtG5nIHRo4buDIHRodSBo4buTaS5gfSByZXF1aXJlUmVhc29uIG9uQ2xvc2U9eygpID0+IHNldFN0b3AobnVsbCl9IGVycm9yPXtjb250cm9sLmVycm9yfSBidXN5PXtjb250cm9sLnBlbmRpbmd9IG9uQ29uZmlybT17cmVhc29uID0+IGNvbnRyb2wuZXhlY3V0ZSh7IGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzdG9wPy5yb2xlLnZlcnNpb24gfHwgMSwgc2NvcGU6ICdyb2xlJywgcmVzb3VyY2VJZDogc3RvcD8ucm9sZS5pZCB8fCBudWxsLCBhY3Rpb246IHN0b3A/LmFjdGlvbiB8fCAncGF1c2UnLCByZWFzb24gfSB9KX0gLz5cclxuICAgIDwvPjtcclxufVxyXG4iXSwiZmlsZSI6Ii9ob21lL3J1bm5lci93b3JrL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9vcGVyYXRpb25zL2luZGV4LnRzeCJ9