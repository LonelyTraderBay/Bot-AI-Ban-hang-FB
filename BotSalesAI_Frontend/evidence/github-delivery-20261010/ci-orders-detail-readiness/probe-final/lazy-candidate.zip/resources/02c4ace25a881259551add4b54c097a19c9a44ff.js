"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-TJQ5SMJY.js?v=4f74a750";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-YVU6SLE6.js?v=4f74a750";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-TQYMLHGU.js?v=4f74a750";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-FJYLEWCQ.js?v=4f74a750";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-QF5IVN5P.js?v=4f74a750";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-QU3FZV7L.js?v=4f74a750";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-41900-eb048b9b-5569-453d-a99d-cd83da49a0e7-orders-detail-readiness-probe-v3/deps/chunk-PX6F3LHL.js?v=4f74a750";

// ../../node_modules/@mui/icons-material/esm/AddRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var AddRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M18 13h-5v5c0 .55-.45 1-1 1s-1-.45-1-1v-5H6c-.55 0-1-.45-1-1s.45-1 1-1h5V6c0-.55.45-1 1-1s1 .45 1 1v5h5c.55 0 1 .45 1 1s-.45 1-1 1"
}), "AddRounded");
export {
  AddRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_AddRounded.js.map
