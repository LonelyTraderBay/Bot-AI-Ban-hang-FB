import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/reports/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5863-35f919f1-975a-44fa-adbe-c813f9d7b882/deps/react_jsx-dev-runtime.js?v=f9568e8d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5863-35f919f1-975a-44fa-adbe-c813f9d7b882/deps/react.js?v=f9568e8d"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { useSearchParams } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5863-35f919f1-975a-44fa-adbe-c813f9d7b882/deps/react-router-dom.js?v=f9568e8d";
import { Alert, Box, Button, Link, MenuItem, Stack, TextField, Typography } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5863-35f919f1-975a-44fa-adbe-c813f9d7b882/deps/@mui_material.js?v=f9568e8d";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Text, Tooltip, XAxis, YAxis } from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5863-35f919f1-975a-44fa-adbe-c813f9d7b882/deps/recharts.js?v=f9568e8d";
import { colors, tokens } from "/@fs/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/packages/design-tokens/src/index.ts";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { dateTime, formatDateOnly, isValidDateOnly } from "/src/shared/model/format.ts";
import { Amount, DataTable, DetailLine, ErrorNotice, PageHeader, Panel, Pager, QueryState, RouteLink, Stat, Stats, Status } from "/src/shared/ui/components.tsx";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { authorizedDownloadHref, dateInTimezone, reportDateBoundary, reportFilename } from "/src/modules/reports/report-utils.ts";
const reportLabels = {
  inventory: "Tồn kho",
  orders: "Đơn hàng",
  cashflow: "Dòng tiền",
  profit_loss: "Lợi nhuận"
};
const sourcePermissions = {
  inventory: "inventory.read",
  orders: "orders.read",
  cashflow: "finance.read",
  profit_loss: "finance.read"
};
function MarketingReasonTick({ x = 0, y = 0, width = 0, visibleTicksCount = 1, payload }) {
  const value = typeof payload?.value === "string" ? payload.value.trim() : "";
  const categoryLabelInset = 8;
  const labelWidth = Math.max(1, width / Math.max(1, visibleTicksCount) - categoryLabelInset);
  return /* @__PURE__ */ jsxDEV(
    Text,
    {
      x,
      y,
      dy: 12,
      width: labelWidth,
      breakAll: true,
      verticalAnchor: "start",
      textAnchor: "middle",
      fill: colors.textSecondary,
      style: { fontSize: tokens.fontSizes.body, fontFamily: tokens.fontFamily },
      children: value
    },
    void 0,
    false,
    {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 47,
      columnNumber: 10
    },
    this
  );
}
_c = MarketingReasonTick;
export function ReportsPage() {
  _s();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const latestParams = useRef(new URLSearchParams(params));
  const pendingSearch = useRef(null);
  useEffect(() => {
    const committedSearch = params.toString();
    if (pendingSearch.current !== null && pendingSearch.current !== committedSearch) return;
    latestParams.current = new URLSearchParams(params);
    pendingSearch.current = null;
  }, [params]);
  const summary = useApi("getReportSummary");
  const canReadJobs = useCan("jobs.read");
  const jobs = useApi("listJobs", { query: { limit: 10, cursor: params.get("cursor") || void 0 } }, canReadJobs);
  const run = useCommand("createExport", ["listJobs"]);
  const requestedType = params.get("reportType");
  const type = requestedType === "inventory" || requestedType === "cashflow" || requestedType === "profit_loss" ? requestedType : "orders";
  const snapshotAsOf = summary.data?.data.asOf;
  const defaultRange = useMemo(() => {
    if (!snapshotAsOf) return null;
    try {
      const currentDate = dateInTimezone(snapshotAsOf, shop.timezone);
      return { fromDate: `${currentDate.slice(0, 7)}-01`, toDate: currentDate };
    } catch {
      return null;
    }
  }, [shop.timezone, snapshotAsOf]);
  const fromValue = params.get("fromDate");
  const toValue = params.get("toDate");
  const readReportDate = (key, value) => {
    if (isValidDateOnly(value)) return value;
    if (params.has(key) && value === "") return "";
    return defaultRange?.[key] || "";
  };
  const from = readReportDate("fromDate", fromValue);
  const to = readReportDate("toDate", toValue);
  const setReportParam = (key, value) => {
    const next = new URLSearchParams(latestParams.current);
    if (key === "reportType") next.set(key, value);
    else
      next.set(key, isValidDateOnly(value) ? value : "");
    latestParams.current = next;
    pendingSearch.current = next.toString();
    setParams(next, { flushSync: true });
  };
  const [rangeError, setRangeError] = useState("");
  const [lastExport, setLastExport] = useState(null);
  const canExportReports = useCan("reports.export");
  const canExportSource = useCan(sourcePermissions[type]);
  const availableReports = summary.data?.data.availableReports || [];
  const reportAvailable = availableReports.includes(type);
  useEffect(() => {
    if (!snapshotAsOf) return;
    if (!defaultRange) {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
      return;
    }
    try {
      const next = new URLSearchParams(latestParams.current);
      let changed = false;
      if (requestedType !== "inventory" && requestedType !== "cashflow" && requestedType !== "profit_loss" && requestedType !== "orders") {
        next.set("reportType", "orders");
        changed = true;
      }
      if (!params.has("fromDate") || fromValue && !isValidDateOnly(fromValue)) {
        next.set("fromDate", defaultRange.fromDate);
        changed = true;
      }
      if (!params.has("toDate") || toValue && !isValidDateOnly(toValue)) {
        next.set("toDate", defaultRange.toDate);
        changed = true;
      }
      if (changed) {
        latestParams.current = next;
        pendingSearch.current = next.toString();
        setParams(next, { replace: true, flushSync: true });
      }
    } catch {
      setRangeError("Múi giờ cửa hàng hoặc mốc thời gian báo cáo không hợp lệ.");
    }
  }, [defaultRange, params, requestedType, fromValue, toValue, setParams, snapshotAsOf]);
  const submit = async () => {
    setRangeError("");
    try {
      if (!snapshotAsOf || !from || !to) throw new RangeError("Chưa có snapshot hoặc khoảng ngày đầy đủ.");
      const request = {
        reportType: type,
        format: "csv",
        from: reportDateBoundary(from, "start", shop.timezone),
        to: reportDateBoundary(to, "end", shop.timezone),
        timezone: shop.timezone,
        snapshotAsOf
      };
      setLastExport(null);
      const response = await run.execute({ body: request });
      setLastExport({ job: response.data, type, from, to });
    } catch (error) {
      if (error instanceof RangeError) setRangeError(error.message);
    }
  };
  const handleExport = () => {
    void submit();
  };
  const lastDownload = lastExport?.job.status === "succeeded" && lastExport.job.downloadUrl ? authorizedDownloadHref(lastExport.job.downloadUrl, location.origin, __MOCK__) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Báo cáo & xuất dữ liệu", subtitle: "Xuất snapshot do API tạo; số liệu tổng hợp không được tính từ một trang danh sách." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 158,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "reports-main-layout", columns: { xs: "minmax(0, 1fr)", xl: "minmax(0, 1.2fr) minmax(0, .8fr)" }, alignItems: "start", geometry: { minWidth: 0 }, children: [
      /* @__PURE__ */ jsxDEV(PageSections, { "data-testid": "reports-page-sections", children: [
        /* @__PURE__ */ jsxDEV(QueryState, { query: summary, pendingProfile: "section", children: summary.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Tạo tệp báo cáo", subtitle: "Ngày được hiểu theo múi giờ cửa hàng và gửi thành mốc thời gian rõ ràng.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-export-form-layout", geometry: { maxWidth: 760 }, children: [
          /* @__PURE__ */ jsxDEV(ErrorNotice, { error: run.error }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 164,
            columnNumber: 29
          }, this),
          rangeError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: rangeError }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 165,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { label: "Báo cáo", select: true, value: type, onChange: (event) => {
            const value = event.target.value;
            if (value === "orders" || value === "inventory" || value === "cashflow" || value === "profit_loss") setReportParam("reportType", value);
            setLastExport(null);
          }, children: availableReports.map((report) => /* @__PURE__ */ jsxDEV(MenuItem, { value: report, children: reportLabels[report] }, report, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 171,
            columnNumber: 67
          }, this)) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 166,
            columnNumber: 29
          }, this),
          availableReports.length === 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại chưa có loại báo cáo khả dụng." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 173,
            columnNumber: 63
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { "data-testid": "reports-date-filters", direction: { xs: "column", sm: "row" }, children: [
            /* @__PURE__ */ jsxDEV(TextField, { label: "Từ ngày", type: "date", value: from, onChange: (event) => setReportParam("fromDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 175,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(TextField, { label: "Đến ngày", type: "date", value: to, onChange: (event) => setReportParam("toDate", event.target.value), slotProps: { inputLabel: { shrink: true } }, fullWidth: true }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 176,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 174,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Múi giờ", children: shop.timezone }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 178,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Snapshot API", children: snapshotAsOf ? dateTime(snapshotAsOf, shop.timezone) : "Chưa có snapshot" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 179,
            columnNumber: 29
          }, this),
          !canExportReports && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Vai trò hiện tại không có quyền reports.export." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 180,
            columnNumber: 51
          }, this),
          canExportReports && !canExportSource && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: [
            "Quyền xuất không thay thế quyền đọc nguồn ",
            sourcePermissions[type],
            "; loại báo cáo này chưa thể xuất."
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 181,
            columnNumber: 70
          }, this),
          canExportReports && canExportSource && !reportAvailable && availableReports.length > 0 && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "API không liệt kê loại báo cáo này cho vai trò hiện tại." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 182,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: handleExport, disabled: !canExportReports || !canExportSource || !reportAvailable || !snapshotAsOf || !from || !to || from > to || run.pending, children: run.pending ? "Đang tạo snapshot…" : "Tạo tệp báo cáo CSV" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 183,
            columnNumber: 29
          }, this),
          lastExport && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "center" }, children: [
            /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${lastExport.job.id}`, children: [
              "Theo dõi công việc ",
              lastExport.job.id
            ] }, void 0, true, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 187,
              columnNumber: 33
            }, this),
            lastDownload && /* @__PURE__ */ jsxDEV(Link, { "data-testid": "reports-export-download", component: "a", href: lastDownload, download: reportFilename(lastExport.type, lastExport.from, lastExport.to), underline: "none", sx: [layoutSx.actions.linkTarget, { border: 1, borderColor: "divider", borderRadius: visualSx.radius.control, color: "text.primary", fontWeight: visualSx.typography.fontWeight.semibold, "&:hover": { bgcolor: "action.hover", textDecoration: "none" }, "&:focus-visible": { outline: `${tokens.focusRing.width}px solid`, outlineColor: "primary.light", outlineOffset: tokens.focusRing.controlOffset } }], children: "Tải CSV" }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 188,
              columnNumber: 50
            }, this),
            lastExport.job.status !== "succeeded" && /* @__PURE__ */ jsxDEV(Alert, { severity: lastExport.job.status === "partial" || lastExport.job.status === "failed" ? "warning" : "info", children: "Tệp chỉ được tải khi công việc xác nhận succeeded." }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 189,
              columnNumber: 75
            }, this),
            lastExport.job.status === "succeeded" && lastExport.job.downloadUrl && !lastDownload && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "URL tải không hợp lệ hoặc chưa thuộc HTTPS/nguồn hiện tại." }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 190,
              columnNumber: 122
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 186,
            columnNumber: 44
          }, this),
          summary.data.data.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: warning }, `${index}-${warning}`, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 192,
            columnNumber: 81
          }, this)),
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "API hiện chỉ trả danh sách loại báo cáo và thời điểm snapshot; bộ lọc ngày áp dụng cho lệnh xuất. Không có series hoặc tổng số liệu để giao diện tự suy ra." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 193,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 163,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 162,
          columnNumber: 38
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 161,
          columnNumber: 17
        }, this),
        canReadJobs ? /* @__PURE__ */ jsxDEV(QueryState, { query: jobs, pendingProfile: "section", children: jobs.data && /* @__PURE__ */ jsxDEV(Panel, { title: "Công việc gần đây", subtitle: "Trạng thái và tiến độ lấy từ API; trang hiện tại có thể chứa nhiều loại công việc.", children: [
          /* @__PURE__ */ jsxDEV(DataTable, { rows: jobs.data.data, rowKey: (job) => job.id, label: "Công việc gần đây", empty: "Chưa có công việc trong trang này.", columns: [
            { key: "id", label: "Mã công việc", render: (job) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${job.id}`, children: job.id }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 200,
              columnNumber: 66
            }, this) },
            { key: "kind", label: "Loại", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.kind }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 201,
              columnNumber: 60
            }, this) },
            { key: "status", label: "Trạng thái", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 202,
              columnNumber: 68
            }, this) },
            { key: "progress", label: "Tiến độ", align: "right", render: (job) => `${job.completed} / ${job.total ?? "Chưa biết"}` },
            { key: "updatedAt", label: "Cập nhật", render: (job) => dateTime(job.updatedAt, shop.timezone) }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 199,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Pager, { page: jobs.data.page }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 206,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 198,
          columnNumber: 35
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 197,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Vai trò hiện tại không có jobs.read; trạng thái công việc được ẩn theo quyền." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 208,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 160,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Phạm vi dữ liệu", subtitle: "Chỉ những gì API cung cấp mới được trình bày như số liệu.", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.report.contextGap, children: [
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Báo cáo dòng, biểu đồ và tổng hợp theo khoảng ngày chưa có trong getReportSummary. Frontend không cộng dữ liệu phân trang để tạo KPI thay thế." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 212,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "Trạng thái export được lấy riêng từ listJobs; URL tải chỉ được mở sau khi API trả về công việc hoàn tất." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 213,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/reports/marketing`, children: "Xem thông tin marketing" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 214,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 211,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 210,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 159,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 157,
    columnNumber: 10
  }, this);
}
_s(ReportsPage, "DFyE6kGn/WrimxAHqu/xbuEgHPg=", false, function() {
  return [useScope, useSearchParams, useApi, useCan, useApi, useCommand, useCan, useCan];
});
_c2 = ReportsPage;
export function MarketingPage() {
  _s2();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const search = params.toString();
  const fromParam = params.get("fromDate") || "";
  const toParam = params.get("toDate") || "";
  const bucketParam = params.get("bucket") || "day";
  const hasDateFilter = params.has("fromDate") || params.has("toDate");
  const appliedError = marketingRangeError(fromParam, toParam, bucketParam, !hasDateFilter);
  const query = appliedError ? void 0 : {
    ...params.has("fromDate") ? { fromDate: fromParam } : {},
    ...params.has("toDate") ? { toDate: toParam } : {},
    ...params.has("bucket") ? { bucket: bucketParam } : {}
  };
  const data = useApi("getMarketingSummary", query && Object.keys(query).length ? { query } : void 0, !appliedError);
  const m = data.data?.data;
  const marketingPeriod = m?.period;
  const [draft, setDraft] = useState({ fromDate: fromParam, toDate: toParam, bucket: bucketParam });
  const draftTouched = useRef(false);
  const pendingDefaultSearch = useRef(null);
  const [showFilterError, setShowFilterError] = useState(false);
  const fromRef = useRef(null);
  const toRef = useRef(null);
  const bucketRef = useRef(null);
  const draftError = marketingRangeError(draft.fromDate, draft.toDate, draft.bucket, false);
  const visibleFilterError = showFilterError ? draftError : appliedError;
  useEffect(() => {
    const isDefaultNormalization = pendingDefaultSearch.current === search;
    if (isDefaultNormalization) pendingDefaultSearch.current = null;
    if (isDefaultNormalization && draftTouched.current) return;
    draftTouched.current = false;
    const current = new URLSearchParams(search);
    if (!current.has("fromDate") && !current.has("toDate")) return;
    setDraft({ fromDate: current.get("fromDate") || "", toDate: current.get("toDate") || "", bucket: current.get("bucket") || "day" });
    setShowFilterError(false);
  }, [search]);
  useEffect(() => {
    if (marketingPeriod && !hasDateFilter && !draftTouched.current) {
      const next = new URLSearchParams({ fromDate: marketingPeriod.fromDate, toDate: marketingPeriod.toDate, bucket: marketingPeriod.bucket });
      if (next.toString() !== search) {
        pendingDefaultSearch.current = next.toString();
        setParams(next, { replace: true });
      }
    }
  }, [marketingPeriod, hasDateFilter, search, setParams]);
  const applyFilter = (event) => {
    event.preventDefault();
    setShowFilterError(true);
    if (draftError) {
      const target = draftError.field === "fromDate" ? fromRef.current : draftError.field === "toDate" ? toRef.current : bucketRef.current;
      target?.focus();
      return;
    }
    const next = new URLSearchParams({ fromDate: draft.fromDate, toDate: draft.toDate, bucket: draft.bucket });
    setShowFilterError(false);
    draftTouched.current = false;
    pendingDefaultSearch.current = null;
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Thông tin cho marketing", subtitle: "Đề xuất chỉ đọc; trang không tự đăng nội dung hoặc thay đổi ngân sách." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 287,
      columnNumber: 9
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: "Số liệu mẫu do API mô phỏng tổng hợp; chưa kết nối tài khoản quảng cáo hoặc nguồn phân bổ thật." }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 288,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Khoảng thời gian báo cáo", subtitle: `Ngày được tính theo lịch ${shop.timezone} của cửa hàng.`, bodyMode: "inset", afterGap: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { component: "form", onSubmit: applyFilter, "data-testid": "marketing-range-form", children: [
      /* @__PURE__ */ jsxDEV(Stack, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "flex-end" }, sx: layoutSx.toolbar.controlGap, children: [
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: fromRef, type: "date", label: "Từ ngày", value: draft.fromDate, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, fromDate: event.target.value }));
        }, slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "fromDate", helperText: visibleFilterError?.field === "fromDate" ? visibleFilterError.message : "Ngày bắt đầu, tính cả ngày đã chọn." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 292,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: toRef, type: "date", label: "Đến ngày", value: draft.toDate, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, toDate: event.target.value }));
        }, slotProps: { inputLabel: { shrink: true } }, error: visibleFilterError?.field === "toDate", helperText: visibleFilterError?.field === "toDate" ? visibleFilterError.message : "Tối đa 366 ngày, tính cả hai đầu." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 293,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { inputRef: bucketRef, select: true, label: "Gộp theo", value: draft.bucket, onChange: (event) => {
          draftTouched.current = true;
          setDraft((value) => ({ ...value, bucket: event.target.value }));
        }, error: visibleFilterError?.field === "bucket", helperText: visibleFilterError?.field === "bucket" ? visibleFilterError.message : "Chọn ngày, tuần hoặc tháng.", children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "day", children: "Ngày" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 295,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "week", children: "Tuần" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 295,
            columnNumber: 62
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "month", children: "Tháng" }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 295,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 294,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", children: "Áp dụng" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 297,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 291,
        columnNumber: 17
      }, this),
      showFilterError && draftError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: draftError.message }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 299,
        columnNumber: 51
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 290,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 289,
      columnNumber: 9
    }, this),
    appliedError ? /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Bộ lọc trên đường dẫn không hợp lệ." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 302,
        columnNumber: 62
      }, this),
      " Hãy sửa trường được đánh dấu trước khi áp dụng."
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 302,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: m && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn có nguồn xác định", value: m.knownAttributedOrders, note: "Được API tổng hợp trong kỳ" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 304,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Đơn chưa rõ nguồn", value: m.unknownAttributionOrders, note: "Giữ riêng, không tự gán nguồn" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 305,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo thực tế", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.actualSpend }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 306,
          columnNumber: 60
        }, this), note: m.actualSpend ? "API cung cấp số thực tế" : "Kỳ này chưa có số thực tế từ API" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 306,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Chi quảng cáo ước tính", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: m.estimatedSpend }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 307,
          columnNumber: 61
        }, this), note: "Ước tính không phải số ghi sổ" }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 307,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 303,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Stack, { "data-testid": "marketing-as-of", sx: [layoutSx.report.contextGap, layoutSx.page.sectionAfter], children: [
        m.period && /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
          "Kỳ ",
          formatDateOnly(m.period.fromDate),
          " – ",
          formatDateOnly(m.period.toDate),
          " · gộp theo ",
          m.period.bucket === "day" ? "ngày" : m.period.bucket === "week" ? "tuần" : "tháng"
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 310,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
          "Cập nhật ",
          dateTime(m.asOf, m.period?.timezone || shop.timezone),
          " · ",
          shop.name,
          " · múi giờ ",
          m.period?.timezone || shop.timezone
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 311,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 309,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(SectionGrid, { "data-testid": "marketing-sections-grid", columns: { xs: "1fr", lg: "1fr 1fr" }, children: [
        /* @__PURE__ */ jsxDEV(Panel, { title: "Đơn theo thời gian", subtitle: "Số đơn có nguồn xác định và chưa rõ nguồn do API tổng hợp.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Số đơn theo ${m.period?.bucket || "kỳ"} trong khoảng đã chọn`, "data-testid": "marketing-trend-chart", sx: [{ height: 280 }, layoutSx.report.chartViewportInset], children: m.trend?.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.trend, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 317,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "fromDate", stroke: colors.textSecondary, interval: Math.max(0, Math.ceil(m.trend.length / 7) - 1), tickFormatter: (value) => formatDateOnly(String(value)) }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 318,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 319,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { labelFormatter: (value) => formatDateOnly(String(value)), contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 320,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 321,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "knownAttributedOrders", name: "Có nguồn xác định", fill: colors.accent, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 322,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "unknownAttributionOrders", name: "Chưa rõ nguồn", fill: colors.textSecondary, radius: [3, 3, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 323,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 316,
            columnNumber: 92
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 316,
            columnNumber: 44
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "API chưa có bucket dữ liệu trong kỳ đã chọn." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 324,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 315,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { label: "Tổng hợp marketing theo kỳ", rows: m.trend || [], rowKey: (point) => point.fromDate, empty: "Chưa có dữ liệu theo kỳ trong khoảng này.", columns: [
            { key: "range", label: "Khoảng ngày", render: (point) => `${formatDateOnly(point.fromDate)} – ${formatDateOnly(point.toDate)}` },
            { key: "known", label: "Có nguồn", align: "right", render: (point) => point.knownAttributedOrders },
            { key: "unknown", label: "Chưa rõ nguồn", align: "right", render: (point) => point.unknownAttributionOrders },
            { key: "estimated", label: "Chi ước tính", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.estimatedSpend }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 330,
              columnNumber: 91
            }, this) },
            { key: "actual", label: "Chi thực tế", align: "right", render: (point) => /* @__PURE__ */ jsxDEV(Amount, { value: point.actualSpend }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 331,
              columnNumber: 87
            }, this) }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 326,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 314,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Câu hỏi khách thường hỏi", subtitle: "Các mục do API tổng hợp cung cấp.", children: /* @__PURE__ */ jsxDEV(Box, { "data-testid": "marketing-question-surface", sx: layoutSx.report.listSurfaceInset, children: /* @__PURE__ */ jsxDEV(Stack, { component: "ul", "data-testid": "marketing-top-questions", sx: [{ m: 0, p: 0 }, layoutSx.report.listMarkerInset, layoutSx.report.listItemGap], children: m.topQuestions.length ? m.topQuestions.map((question, index) => /* @__PURE__ */ jsxDEV(Typography, { component: "li", children: question }, `${index}-${question}`, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 337,
          columnNumber: 94
        }, this)) : /* @__PURE__ */ jsxDEV(Typography, { component: "li", color: "text.secondary", children: "Chưa có thống kê câu hỏi trong kỳ đã chọn." }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 337,
          columnNumber: 177
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 336,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 335,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 334,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Lý do không chốt đơn", subtitle: "Biểu đồ và bảng dùng cùng một payload API.", children: [
          /* @__PURE__ */ jsxDEV(Box, { role: "img", "aria-label": `Biểu đồ lý do không chốt đơn, ${m.lostSaleReasons.length} nhóm`, "data-testid": "marketing-loss-chart", sx: [{ height: 260 }, layoutSx.report.chartViewportInset], children: m.lostSaleReasons.length ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(BarChart, { data: m.lostSaleReasons, accessibilityLayer: true, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { stroke: colors.borderDecorative, vertical: false }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 344,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "reason", stroke: colors.textSecondary, interval: 0, height: 64, tick: /* @__PURE__ */ jsxDEV(MarketingReasonTick, {}, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 345,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 345,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { allowDecimals: false, stroke: colors.textSecondary }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 346,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { contentStyle: { background: colors.raised, color: colors.textPrimary, borderColor: colors.borderDecorative } }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 347,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "count", name: "Số trường hợp", fill: colors.accent, radius: [4, 4, 0, 0] }, void 0, false, {
              fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
              lineNumber: 348,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 343,
            columnNumber: 101
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 343,
            columnNumber: 53
          }, this) : /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: layoutSx.report.emptyStateInset, children: "Chưa có lý do mất đơn trong kỳ này." }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 349,
            columnNumber: 61
          }, this) }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 342,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(DataTable, { rows: m.lostSaleReasons, rowKey: (reason) => reason.reason, label: "Lý do không chốt đơn", empty: "Chưa có lý do mất đơn trong kỳ đã chọn.", columns: [
            { key: "reason", label: "Lý do", render: (reason) => reason.reason },
            { key: "count", label: "Số trường hợp", align: "right", render: (reason) => reason.count }
          ] }, void 0, false, {
            fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
            lineNumber: 351,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
          lineNumber: 341,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 313,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.page.sectionBefore, children: "Không tự gán nguồn cho đơn thiếu dữ liệu, không ghi chi ước tính thành chi thực tế và không tự đăng nội dung hoặc tăng ngân sách." }, void 0, false, {
        fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
        lineNumber: 357,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 302,
      columnNumber: 229
    }, this) }, void 0, false, {
      fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
      lineNumber: 302,
      columnNumber: 173
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx",
    lineNumber: 286,
    columnNumber: 10
  }, this);
}
_s2(MarketingPage, "ZWpsOgk1rkTa0nhARG38OjbzPAA=", false, function() {
  return [useScope, useSearchParams, useApi];
});
_c3 = MarketingPage;
function marketingRangeError(fromDate, toDate, bucket, allowDefault) {
  if (!["day", "week", "month"].includes(bucket)) return { field: "bucket", message: "Chọn nhóm ngày, tuần hoặc tháng." };
  if (allowDefault && !fromDate && !toDate) return null;
  if (!isValidDateOnly(fromDate)) return { field: "fromDate", message: "Nhập ngày bắt đầu hợp lệ." };
  if (!isValidDateOnly(toDate)) return { field: "toDate", message: "Nhập ngày kết thúc hợp lệ." };
  if (fromDate > toDate) return { field: "fromDate", message: "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc." };
  const days = Math.floor((Date.parse(`${toDate}T00:00:00.000Z`) - Date.parse(`${fromDate}T00:00:00.000Z`)) / (24 * 60 * 60 * 1e3)) + 1;
  if (days > 366) return { field: "toDate", message: "Khoảng báo cáo không được vượt quá 366 ngày." };
  return null;
}
var _c, _c2, _c3;
$RefreshReg$(_c, "MarketingReasonTick");
$RefreshReg$(_c2, "ReportsPage");
$RefreshReg$(_c3, "MarketingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/work/Bot-AI-Ban-hang-FB/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/reports/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJXLFNBOEdBLFVBOUdBOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCWCxTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxtQkFBbUI7QUFDbkUsU0FBU0MsV0FBV0MsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBRXJELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsTUFBTUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQ2pGLFNBQVNDLEtBQUtDLFVBQVVDLGVBQWVDLFFBQVFDLHFCQUFxQkMsTUFBTUMsU0FBU0MsT0FBT0MsYUFBYTtBQUV2RyxTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLGdCQUFnQkMsdUJBQXVCO0FBQzFELFNBQVNDLFFBQVFDLFdBQVdDLFlBQVlDLGFBQWFDLFlBQVlDLE9BQU9DLE9BQU9DLFlBQVlDLFdBQVdDLE1BQU1DLE9BQU9DLGNBQWM7QUFDakksU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHdCQUF3QkMsZ0JBQWdCQyxvQkFBb0JDLHNCQUFzQjtBQUUzRixNQUFNQyxlQUE0RDtBQUFBLEVBQzlEQyxXQUFXO0FBQUEsRUFBV0MsUUFBUTtBQUFBLEVBQVlDLFVBQVU7QUFBQSxFQUFhQyxhQUFhO0FBQ2xGO0FBQ0EsTUFBTUMsb0JBQWlFO0FBQUEsRUFDbkVKLFdBQVc7QUFBQSxFQUFrQkMsUUFBUTtBQUFBLEVBQWVDLFVBQVU7QUFBQSxFQUFnQkMsYUFBYTtBQUMvRjtBQUVBLFNBQVNFLG9CQUFvQixFQUFFQyxJQUFJLEdBQUdDLElBQUksR0FBR0MsUUFBUSxHQUFHQyxvQkFBb0IsR0FBR0MsUUFBK0csR0FBRztBQUM3TCxRQUFNQyxRQUFRLE9BQU9ELFNBQVNDLFVBQVUsV0FBV0QsUUFBUUMsTUFBTUMsS0FBSyxJQUFJO0FBQzFFLFFBQU1DLHFCQUFxQjtBQUMzQixRQUFNQyxhQUFhQyxLQUFLQyxJQUFJLEdBQUdSLFFBQVFPLEtBQUtDLElBQUksR0FBR1AsaUJBQWlCLElBQUlJLGtCQUFrQjtBQUMxRixTQUFPO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFBSztBQUFBLE1BQU07QUFBQSxNQUFNLElBQUk7QUFBQSxNQUFJLE9BQU9DO0FBQUFBLE1BQVksVUFBUTtBQUFBLE1BQUMsZ0JBQWU7QUFBQSxNQUFRLFlBQVc7QUFBQSxNQUFTLE1BQU16QyxPQUFPNEM7QUFBQUEsTUFDakgsT0FBTyxFQUFFQyxVQUFVNUMsT0FBTzZDLFVBQVVDLE1BQU1DLFlBQVkvQyxPQUFPK0MsV0FBVztBQUFBLE1BQUlWO0FBQUFBO0FBQUFBLElBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUMrRTtBQUMxRjtBQUFDVyxLQU5RakI7QUFRRixnQkFBU2tCLGNBQWM7QUFBQUMsS0FBQTtBQUMxQixRQUFNLEVBQUVDLEtBQUssSUFBSWhELFNBQVM7QUFDMUIsUUFBTSxDQUFDaUQsUUFBUUMsU0FBUyxJQUFJeEUsZ0JBQWdCO0FBQzVDLFFBQU15RSxlQUFlNUUsT0FBTyxJQUFJNkUsZ0JBQWdCSCxNQUFNLENBQUM7QUFDdkQsUUFBTUksZ0JBQWdCOUUsT0FBc0IsSUFBSTtBQUNoREYsWUFBVSxNQUFNO0FBQ1osVUFBTWlGLGtCQUFrQkwsT0FBT00sU0FBUztBQUN4QyxRQUFJRixjQUFjRyxZQUFZLFFBQVFILGNBQWNHLFlBQVlGLGdCQUFpQjtBQUNqRkgsaUJBQWFLLFVBQVUsSUFBSUosZ0JBQWdCSCxNQUFNO0FBQ2pESSxrQkFBY0csVUFBVTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ1AsTUFBTSxDQUFDO0FBQ1gsUUFBTVEsVUFBVTNELE9BQU8sa0JBQWtCO0FBQ3pDLFFBQU00RCxjQUFjekQsT0FBTyxXQUFXO0FBQ3RDLFFBQU0wRCxPQUFPN0QsT0FBTyxZQUFZLEVBQUU4RCxPQUFPLEVBQUVDLE9BQU8sSUFBSUMsUUFBUWIsT0FBT2MsSUFBSSxRQUFRLEtBQUtDLE9BQVUsRUFBRSxHQUFHTixXQUFXO0FBQ2hILFFBQU1PLE1BQU1sRSxXQUFXLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztBQUNuRCxRQUFNbUUsZ0JBQWdCakIsT0FBT2MsSUFBSSxZQUFZO0FBQzdDLFFBQU1JLE9BQW9DRCxrQkFBa0IsZUFBZUEsa0JBQWtCLGNBQWNBLGtCQUFrQixnQkFBZ0JBLGdCQUFnQjtBQUM3SixRQUFNRSxlQUFlWCxRQUFRWSxNQUFNQSxLQUFLQztBQUN4QyxRQUFNQyxlQUFlakcsUUFBUSxNQUFNO0FBQy9CLFFBQUksQ0FBQzhGLGFBQWMsUUFBTztBQUMxQixRQUFJO0FBQ0EsWUFBTUksY0FBY3JELGVBQWVpRCxjQUFjcEIsS0FBS3lCLFFBQVE7QUFDOUQsYUFBTyxFQUFFQyxVQUFVLEdBQUdGLFlBQVlHLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBT0MsUUFBUUosWUFBWTtBQUFBLElBQzVFLFFBQ007QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3hCLEtBQUt5QixVQUFVTCxZQUFZLENBQUM7QUFDaEMsUUFBTVMsWUFBWTVCLE9BQU9jLElBQUksVUFBVTtBQUN2QyxRQUFNZSxVQUFVN0IsT0FBT2MsSUFBSSxRQUFRO0FBQ25DLFFBQU1nQixpQkFBaUJBLENBQUNDLEtBQTRCOUMsVUFBeUI7QUFDekUsUUFBSTlCLGdCQUFnQjhCLEtBQUssRUFBRyxRQUFPQTtBQUNuQyxRQUFJZSxPQUFPZ0MsSUFBSUQsR0FBRyxLQUFLOUMsVUFBVSxHQUFJLFFBQU87QUFDNUMsV0FBT3FDLGVBQWVTLEdBQUcsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsUUFBTUUsT0FBT0gsZUFBZSxZQUFZRixTQUFTO0FBQ2pELFFBQU1NLEtBQUtKLGVBQWUsVUFBVUQsT0FBTztBQUMzQyxRQUFNTSxpQkFBaUJBLENBQUNKLEtBQTJDOUMsVUFBa0I7QUFDakYsVUFBTW1ELE9BQU8sSUFBSWpDLGdCQUFnQkQsYUFBYUssT0FBTztBQUNyRCxRQUFJd0IsUUFBUSxhQUFjSyxNQUFLQyxJQUFJTixLQUFLOUMsS0FBSztBQUFBO0FBQ3hDbUQsV0FBS0MsSUFBSU4sS0FBSzVFLGdCQUFnQjhCLEtBQUssSUFBSUEsUUFBUSxFQUFFO0FBQ3REaUIsaUJBQWFLLFVBQVU2QjtBQUN2QmhDLGtCQUFjRyxVQUFVNkIsS0FBSzlCLFNBQVM7QUFDdENMLGNBQVVtQyxNQUFNLEVBQUVFLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDdkM7QUFDQSxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWpILFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrSCxZQUFZQyxhQUFhLElBQUluSCxTQUEyRixJQUFJO0FBQ25JLFFBQU1vSCxtQkFBbUIzRixPQUFPLGdCQUFnQjtBQUNoRCxRQUFNNEYsa0JBQWtCNUYsT0FBTzBCLGtCQUFrQndDLElBQUksQ0FBQztBQUN0RCxRQUFNMkIsbUJBQW1CckMsUUFBUVksTUFBTUEsS0FBS3lCLG9CQUFvQjtBQUNoRSxRQUFNQyxrQkFBa0JELGlCQUFpQkUsU0FBUzdCLElBQUk7QUFFdEQ5RixZQUFVLE1BQU07QUFDWixRQUFJLENBQUMrRixhQUFjO0FBQ25CLFFBQUksQ0FBQ0csY0FBYztBQUNma0Isb0JBQWMsMkRBQTJEO0FBQ3pFO0FBQUEsSUFDSjtBQUNBLFFBQUk7QUFDQSxZQUFNSixPQUFPLElBQUlqQyxnQkFBZ0JELGFBQWFLLE9BQU87QUFDckQsVUFBSXlDLFVBQVU7QUFDZCxVQUFJL0Isa0JBQWtCLGVBQWVBLGtCQUFrQixjQUFjQSxrQkFBa0IsaUJBQWlCQSxrQkFBa0IsVUFBVTtBQUNoSW1CLGFBQUtDLElBQUksY0FBYyxRQUFRO0FBQy9CVyxrQkFBVTtBQUFBLE1BQ2Q7QUFDQSxVQUFJLENBQUNoRCxPQUFPZ0MsSUFBSSxVQUFVLEtBQU1KLGFBQWEsQ0FBQ3pFLGdCQUFnQnlFLFNBQVMsR0FBSTtBQUN2RVEsYUFBS0MsSUFBSSxZQUFZZixhQUFhRyxRQUFRO0FBQzFDdUIsa0JBQVU7QUFBQSxNQUNkO0FBQ0EsVUFBSSxDQUFDaEQsT0FBT2dDLElBQUksUUFBUSxLQUFNSCxXQUFXLENBQUMxRSxnQkFBZ0IwRSxPQUFPLEdBQUk7QUFDakVPLGFBQUtDLElBQUksVUFBVWYsYUFBYUssTUFBTTtBQUN0Q3FCLGtCQUFVO0FBQUEsTUFDZDtBQUNBLFVBQUlBLFNBQVM7QUFDVDlDLHFCQUFhSyxVQUFVNkI7QUFDdkJoQyxzQkFBY0csVUFBVTZCLEtBQUs5QixTQUFTO0FBQ3RDTCxrQkFBVW1DLE1BQU0sRUFBRWEsU0FBUyxNQUFNWCxXQUFXLEtBQUssQ0FBQztBQUFBLE1BQ3REO0FBQUEsSUFDSixRQUNNO0FBQUVFLG9CQUFjLDJEQUEyRDtBQUFBLElBQUc7QUFBQSxFQUN4RixHQUFHLENBQUNsQixjQUFjdEIsUUFBUWlCLGVBQWVXLFdBQVdDLFNBQVM1QixXQUFXa0IsWUFBWSxDQUFDO0FBRXJGLFFBQU0rQixTQUFTLFlBQVk7QUFDdkJWLGtCQUFjLEVBQUU7QUFDaEIsUUFBSTtBQUNBLFVBQUksQ0FBQ3JCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLEdBQUksT0FBTSxJQUFJaUIsV0FBVywyQ0FBMkM7QUFDbkcsWUFBTUMsVUFBVTtBQUFBLFFBQ1pDLFlBQVluQztBQUFBQSxRQUNab0MsUUFBUTtBQUFBLFFBQ1JyQixNQUFNOUQsbUJBQW1COEQsTUFBTSxTQUFTbEMsS0FBS3lCLFFBQVE7QUFBQSxRQUNyRFUsSUFBSS9ELG1CQUFtQitELElBQUksT0FBT25DLEtBQUt5QixRQUFRO0FBQUEsUUFDL0NBLFVBQVV6QixLQUFLeUI7QUFBQUEsUUFDZkw7QUFBQUEsTUFDSjtBQUNBdUIsb0JBQWMsSUFBSTtBQUNsQixZQUFNYSxXQUFXLE1BQU12QyxJQUFJd0MsUUFBUSxFQUFFOUQsTUFBTTBELFFBQVEsQ0FBQztBQUNwRFYsb0JBQWMsRUFBRWUsS0FBS0YsU0FBU25DLE1BQU1GLE1BQU1lLE1BQU1DLEdBQUcsQ0FBQztBQUFBLElBQ3hELFNBQ093QixPQUFPO0FBQ1YsVUFBSUEsaUJBQWlCUCxXQUFZWCxlQUFja0IsTUFBTUMsT0FBTztBQUFBLElBQ2hFO0FBQUEsRUFDSjtBQUNBLFFBQU1DLGVBQWVBLE1BQU07QUFBRSxTQUFLVixPQUFPO0FBQUEsRUFBRztBQUU1QyxRQUFNVyxlQUFlcEIsWUFBWWdCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxjQUN4RTlGLHVCQUF1QndFLFdBQVdnQixJQUFJTSxhQUFhQyxTQUFTQyxRQUFRQyxRQUFRLElBQzVFO0FBRU4sU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSwwQkFBeUIsVUFBUyx3RkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3STtBQUFBLElBQ3hJLHVCQUFDLGVBQVksZUFBWSx1QkFBc0IsU0FBUyxFQUFFQyxJQUFJLGtCQUFrQkMsSUFBSSxtQ0FBbUMsR0FBRyxZQUFZLFNBQVMsVUFBVSxFQUFDQyxVQUFVLEVBQUMsR0FDaks7QUFBQSw2QkFBQyxnQkFBYSxlQUFZLHlCQUN0QjtBQUFBLCtCQUFDLGNBQVcsT0FBTzdELFNBQVMsZ0JBQWUsV0FDdENBLGtCQUFRWSxRQUFRLHVCQUFDLFNBQU0sT0FBTSxtQkFBa0IsVUFBUyw0RUFBMkUsVUFBUyxTQUN6SSxpQ0FBQyxjQUFXLGVBQVksOEJBQTZCLFVBQVUsRUFBQ2tELFVBQVUsSUFBRyxHQUN6RTtBQUFBLGlDQUFDLGVBQVksT0FBT3RELElBQUkwQyxTQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzdCbkIsY0FBYyx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVNBLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2hFLHVCQUFDLGFBQVUsT0FBTSxXQUFVLFFBQU0sTUFBQyxPQUFPckIsTUFBTSxVQUFVLENBQUFxRCxVQUFTO0FBQzlELGtCQUFNdEYsUUFBUXNGLE1BQU1DLE9BQU92RjtBQUMzQixnQkFBSUEsVUFBVSxZQUFZQSxVQUFVLGVBQWVBLFVBQVUsY0FBY0EsVUFBVSxjQUFla0QsZ0JBQWUsY0FBY2xELEtBQUs7QUFDdEl5RCwwQkFBYyxJQUFJO0FBQUEsVUFDdEIsR0FDS0csMkJBQWlCNEIsSUFBSSxDQUFBQyxXQUFVLHVCQUFDLFlBQVMsT0FBT0EsUUFBc0JyRyx1QkFBYXFHLE1BQU0sS0FBNUJBLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELENBQVcsS0FMM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0M3QixpQkFBaUI4QixXQUFXLEtBQUssdUJBQUMsU0FBTSxVQUFTLFFBQU8sK0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDeEcsdUJBQUMsY0FBVyxlQUFZLHdCQUF1QixXQUFXLEVBQUVSLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQ2hGO0FBQUEsbUNBQUMsYUFBVSxPQUFNLFdBQVUsTUFBSyxRQUFPLE9BQU8zQyxNQUFNLFVBQVUsQ0FBQXNDLFVBQVNwQyxlQUFlLFlBQVlvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZLO0FBQUEsWUFDN0ssdUJBQUMsYUFBVSxPQUFNLFlBQVcsTUFBSyxRQUFPLE9BQU81QyxJQUFJLFVBQVUsQ0FBQXFDLFVBQVNwQyxlQUFlLFVBQVVvQyxNQUFNQyxPQUFPdkYsS0FBSyxHQUFHLFdBQVcsRUFBRTRGLFlBQVksRUFBRUMsUUFBUSxLQUFLLEVBQUUsR0FBRyxXQUFTLFFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBLO0FBQUEsZUFGOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsY0FBVyxPQUFNLFdBQVcvRSxlQUFLeUIsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxjQUFXLE9BQU0sZ0JBQWdCTCx5QkFBZWxFLFNBQVNrRSxjQUFjcEIsS0FBS3lCLFFBQVEsSUFBSSxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxVQUMzRyxDQUFDbUIsb0JBQW9CLHVCQUFDLFNBQU0sVUFBUyxXQUFVLCtEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQzlGQSxvQkFBb0IsQ0FBQ0MsbUJBQW1CLHVCQUFDLFNBQU0sVUFBUyxXQUFVO0FBQUE7QUFBQSxZQUEyQ2xFLGtCQUFrQndDLElBQUk7QUFBQSxZQUFFO0FBQUEsZUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEg7QUFBQSxVQUN0S3lCLG9CQUFvQkMsbUJBQW1CLENBQUNFLG1CQUFtQkQsaUJBQWlCOEIsU0FBUyxLQUFLLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHdFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQzdLLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVNmLGNBQWMsVUFBVSxDQUFDakIsb0JBQW9CLENBQUNDLG1CQUFtQixDQUFDRSxtQkFBbUIsQ0FBQzNCLGdCQUFnQixDQUFDYyxRQUFRLENBQUNDLE1BQU1ELE9BQU9DLE1BQU1sQixJQUFJK0QsU0FDdksvRCxjQUFJK0QsVUFBVSx1QkFBdUIseUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDdEMsY0FBYyx1QkFBQyxlQUFZLFdBQVcsRUFBRTBCLElBQUksVUFBVVMsSUFBSSxNQUFNLEdBQUksWUFBWSxFQUFFVCxJQUFJLFdBQVdTLElBQUksU0FBUyxHQUMzRztBQUFBLG1DQUFDLGFBQVUsSUFBSSxNQUFNN0UsS0FBS2lGLEVBQUUsU0FBU3ZDLFdBQVdnQixJQUFJdUIsRUFBRSxJQUFJO0FBQUE7QUFBQSxjQUFvQnZDLFdBQVdnQixJQUFJdUI7QUFBQUEsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsWUFDL0ZuQixnQkFBZ0IsdUJBQUMsUUFBSyxlQUFZLDJCQUEwQixXQUFVLEtBQUksTUFBTUEsY0FBYyxVQUFVekYsZUFBZXFFLFdBQVd2QixNQUFNdUIsV0FBV1IsTUFBTVEsV0FBV1AsRUFBRSxHQUFHLFdBQVUsUUFBTyxJQUFJLENBQUNsRSxTQUFTaUgsUUFBUUMsWUFBWSxFQUFFQyxRQUFRLEdBQUdDLGFBQWEsV0FBV0MsY0FBYzdKLFNBQVM4SixPQUFPQyxTQUFTQyxPQUFPLGdCQUFnQkMsWUFBWWpLLFNBQVNrSyxXQUFXRCxXQUFXRSxVQUFVLFdBQVcsRUFBRUMsU0FBUyxnQkFBZ0JDLGdCQUFnQixPQUFPLEdBQUcsbUJBQW1CLEVBQUVDLFNBQVMsR0FBR2xKLE9BQU9tSixVQUFVakgsS0FBSyxZQUFZa0gsY0FBYyxpQkFBaUJDLGVBQWVySixPQUFPbUosVUFBVUcsY0FBYyxFQUFFLENBQUMsR0FBRyx1QkFBMWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlrQjtBQUFBLFlBQ2psQnpELFdBQVdnQixJQUFJSyxXQUFXLGVBQWUsdUJBQUMsU0FBTSxVQUFVckIsV0FBV2dCLElBQUlLLFdBQVcsYUFBYXJCLFdBQVdnQixJQUFJSyxXQUFXLFdBQVcsWUFBWSxRQUFRLGtFQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSztBQUFBLFlBQzVNckIsV0FBV2dCLElBQUlLLFdBQVcsZUFBZXJCLFdBQVdnQixJQUFJTSxlQUFlLENBQUNGLGdCQUFnQix1QkFBQyxTQUFNLFVBQVMsV0FBVSwwRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUpsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtmO0FBQUEsVUFDQ3JELFFBQVFZLEtBQUtBLEtBQUsrRSxTQUFTMUIsSUFBSSxDQUFDMkIsU0FBU0MsVUFBVSx1QkFBQyxTQUFrQyxVQUFTLFFBQVFELHFCQUF4QyxHQUFHQyxLQUFLLElBQUlELE9BQU8sSUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQsQ0FBUTtBQUFBLFVBQ3hILHVCQUFDLFNBQU0sVUFBUyxRQUFPLDJLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrTDtBQUFBLGFBOUJ0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBLEtBaENhO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ2pCLEtBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxRQUNDM0YsY0FBYyx1QkFBQyxjQUFXLE9BQU9DLE1BQU0sZ0JBQWUsV0FDbERBLGVBQUtVLFFBQVEsdUJBQUMsU0FBTSxPQUFNLHFCQUFvQixVQUFTLHNGQUNwRDtBQUFBLGlDQUFDLGFBQVUsTUFBTVYsS0FBS1UsS0FBS0EsTUFBTSxRQUFRLENBQUFxQyxRQUFPQSxJQUFJdUIsSUFBSSxPQUFNLHFCQUFvQixPQUFNLHNDQUFxQyxTQUFTO0FBQUEsWUFDbEksRUFBRWpELEtBQUssTUFBTXVFLE9BQU8sZ0JBQWdCQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxhQUFVLElBQUksTUFBTTFELEtBQUtpRixFQUFFLFNBQVN2QixJQUFJdUIsRUFBRSxJQUFLdkIsY0FBSXVCLE1BQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVELEVBQWE7QUFBQSxZQUN2SCxFQUFFakQsS0FBSyxRQUFRdUUsT0FBTyxRQUFRQyxRQUFRQSxDQUFBOUMsUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUkrQyxRQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QixFQUFJO0FBQUEsWUFDekUsRUFBRXpFLEtBQUssVUFBVXVFLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQTlDLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJSyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQixFQUFJO0FBQUEsWUFDbkYsRUFBRS9CLEtBQUssWUFBWXVFLE9BQU8sV0FBV0csT0FBTyxTQUFTRixRQUFRQSxDQUFBOUMsUUFBTyxHQUFHQSxJQUFJaUQsU0FBUyxNQUFNakQsSUFBSWtELFNBQVMsV0FBVyxHQUFHO0FBQUEsWUFDckgsRUFBRTVFLEtBQUssYUFBYXVFLE9BQU8sWUFBWUMsUUFBUUEsQ0FBQTlDLFFBQU94RyxTQUFTd0csSUFBSW1ELFdBQVc3RyxLQUFLeUIsUUFBUSxFQUFFO0FBQUEsVUFBQyxLQUxsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1FO0FBQUEsVUFDRix1QkFBQyxTQUFNLE1BQU1kLEtBQUtVLEtBQUt5RixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLGFBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTZCxLQVZXO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXZixJQUFnQix1QkFBQyxTQUFNLFVBQVMsUUFBTyw2RkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFdBaER4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE9BQU0sbUJBQWtCLFVBQVMsNkRBQTRELFVBQVMsU0FDekcsaUNBQUMsU0FBTSxJQUFJN0ksU0FBUzBHLE9BQU9vQyxZQUN2QjtBQUFBLCtCQUFDLGNBQVcsT0FBTSxrQkFBaUIsOEpBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxRQUNqTCx1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLHdIQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFDM0ksdUJBQUMsYUFBVSxJQUFJLE1BQU0vRyxLQUFLaUYsRUFBRSxzQkFBc0IsdUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0E1REc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEUDtBQUNKO0FBQUNsRixHQXhLZUQsYUFBVztBQUFBLFVBQ045QyxVQUNXdEIsaUJBU1pvQixRQUNJRyxRQUNQSCxRQUNEQyxZQStCYUUsUUFDREEsTUFBTTtBQUFBO0FBQUEsTUE5Q2xCNkM7QUEwS1QsZ0JBQVNrSCxnQkFBZ0I7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUVqSCxLQUFLLElBQUloRCxTQUFTO0FBQzFCLFFBQU0sQ0FBQ2lELFFBQVFDLFNBQVMsSUFBSXhFLGdCQUFnQjtBQUM1QyxRQUFNd0wsU0FBU2pILE9BQU9NLFNBQVM7QUFDL0IsUUFBTTRHLFlBQVlsSCxPQUFPYyxJQUFJLFVBQVUsS0FBSztBQUM1QyxRQUFNcUcsVUFBVW5ILE9BQU9jLElBQUksUUFBUSxLQUFLO0FBQ3hDLFFBQU1zRyxjQUFjcEgsT0FBT2MsSUFBSSxRQUFRLEtBQUs7QUFDNUMsUUFBTXVHLGdCQUFnQnJILE9BQU9nQyxJQUFJLFVBQVUsS0FBS2hDLE9BQU9nQyxJQUFJLFFBQVE7QUFDbkUsUUFBTXNGLGVBQWVDLG9CQUFvQkwsV0FBV0MsU0FBU0MsYUFBYSxDQUFDQyxhQUFhO0FBQ3hGLFFBQU0xRyxRQUFRMkcsZUFBZXZHLFNBQVk7QUFBQSxJQUNyQyxHQUFJZixPQUFPZ0MsSUFBSSxVQUFVLElBQUksRUFBRVAsVUFBVXlGLFVBQVUsSUFBSSxDQUFDO0FBQUEsSUFDeEQsR0FBSWxILE9BQU9nQyxJQUFJLFFBQVEsSUFBSSxFQUFFTCxRQUFRd0YsUUFBUSxJQUFJLENBQUM7QUFBQSxJQUNsRCxHQUFJbkgsT0FBT2dDLElBQUksUUFBUSxJQUFJLEVBQUV3RixRQUFRSixZQUErQixJQUFJLENBQUM7QUFBQSxFQUM3RTtBQUNBLFFBQU1oRyxPQUFPdkUsT0FBTyx1QkFBdUI4RCxTQUFTOEcsT0FBT0MsS0FBSy9HLEtBQUssRUFBRWdFLFNBQVMsRUFBRWhFLE1BQU0sSUFBSUksUUFBVyxDQUFDdUcsWUFBWTtBQUNwSCxRQUFNSyxJQUFJdkcsS0FBS0EsTUFBTUE7QUFDckIsUUFBTXdHLGtCQUFrQkQsR0FBR0U7QUFDM0IsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl4TSxTQUFTLEVBQUVrRyxVQUFVeUYsV0FBV3ZGLFFBQVF3RixTQUFTSyxRQUFRSixZQUFZLENBQUM7QUFDaEcsUUFBTVksZUFBZTFNLE9BQU8sS0FBSztBQUNqQyxRQUFNMk0sdUJBQXVCM00sT0FBc0IsSUFBSTtBQUN2RCxRQUFNLENBQUM0TSxpQkFBaUJDLGtCQUFrQixJQUFJNU0sU0FBUyxLQUFLO0FBQzVELFFBQU02TSxVQUFVOU0sT0FBeUIsSUFBSTtBQUM3QyxRQUFNK00sUUFBUS9NLE9BQXlCLElBQUk7QUFDM0MsUUFBTWdOLFlBQVloTixPQUF5QixJQUFJO0FBQy9DLFFBQU1pTixhQUFhaEIsb0JBQW9CTyxNQUFNckcsVUFBVXFHLE1BQU1uRyxRQUFRbUcsTUFBTU4sUUFBUSxLQUFLO0FBQ3hGLFFBQU1nQixxQkFBcUJOLGtCQUFrQkssYUFBYWpCO0FBRTFEbE0sWUFBVSxNQUFNO0FBQ1osVUFBTXFOLHlCQUF5QlIscUJBQXFCMUgsWUFBWTBHO0FBQ2hFLFFBQUl3Qix1QkFBd0JSLHNCQUFxQjFILFVBQVU7QUFFM0QsUUFBSWtJLDBCQUEwQlQsYUFBYXpILFFBQVM7QUFDcER5SCxpQkFBYXpILFVBQVU7QUFDdkIsVUFBTUEsVUFBVSxJQUFJSixnQkFBZ0I4RyxNQUFNO0FBQzFDLFFBQUksQ0FBQzFHLFFBQVF5QixJQUFJLFVBQVUsS0FBSyxDQUFDekIsUUFBUXlCLElBQUksUUFBUSxFQUFHO0FBQ3hEK0YsYUFBUyxFQUFFdEcsVUFBVWxCLFFBQVFPLElBQUksVUFBVSxLQUFLLElBQUlhLFFBQVFwQixRQUFRTyxJQUFJLFFBQVEsS0FBSyxJQUFJMEcsUUFBUWpILFFBQVFPLElBQUksUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUNqSXFILHVCQUFtQixLQUFLO0FBQUEsRUFDNUIsR0FBRyxDQUFDbEIsTUFBTSxDQUFDO0FBRVg3TCxZQUFVLE1BQU07QUFFWixRQUFJd00sbUJBQW1CLENBQUNQLGlCQUFpQixDQUFDVyxhQUFhekgsU0FBUztBQUM1RCxZQUFNNkIsT0FBTyxJQUFJakMsZ0JBQWdCLEVBQUVzQixVQUFVbUcsZ0JBQWdCbkcsVUFBVUUsUUFBUWlHLGdCQUFnQmpHLFFBQVE2RixRQUFRSSxnQkFBZ0JKLE9BQU8sQ0FBQztBQUN2SSxVQUFJcEYsS0FBSzlCLFNBQVMsTUFBTTJHLFFBQVE7QUFDNUJnQiw2QkFBcUIxSCxVQUFVNkIsS0FBSzlCLFNBQVM7QUFDN0NMLGtCQUFVbUMsTUFBTSxFQUFFYSxTQUFTLEtBQUssQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDSjtBQUFBLEVBQ0osR0FBRyxDQUFDMkUsaUJBQWlCUCxlQUFlSixRQUFRaEgsU0FBUyxDQUFDO0FBRXRELFFBQU15SSxjQUFjQSxDQUFDbkUsVUFBc0M7QUFDdkRBLFVBQU1vRSxlQUFlO0FBQ3JCUix1QkFBbUIsSUFBSTtBQUN2QixRQUFJSSxZQUFZO0FBQ1osWUFBTS9ELFNBQVMrRCxXQUFXSyxVQUFVLGFBQWFSLFFBQVE3SCxVQUFVZ0ksV0FBV0ssVUFBVSxXQUFXUCxNQUFNOUgsVUFBVStILFVBQVUvSDtBQUM3SGlFLGNBQVFxRSxNQUFNO0FBQ2Q7QUFBQSxJQUNKO0FBQ0EsVUFBTXpHLE9BQU8sSUFBSWpDLGdCQUFnQixFQUFFc0IsVUFBVXFHLE1BQU1yRyxVQUFVRSxRQUFRbUcsTUFBTW5HLFFBQVE2RixRQUFRTSxNQUFNTixPQUFPLENBQUM7QUFDekdXLHVCQUFtQixLQUFLO0FBQ3hCSCxpQkFBYXpILFVBQVU7QUFDdkIwSCx5QkFBcUIxSCxVQUFVO0FBQy9CTixjQUFVbUMsSUFBSTtBQUFBLEVBQ2xCO0FBRUEsU0FBTyxtQ0FDSDtBQUFBLDJCQUFDLGNBQVcsT0FBTSwyQkFBMEIsVUFBUyw0RUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2SDtBQUFBLElBQzVIOEIsWUFBWSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxJQUFJbEcsU0FBUzhLLE9BQU9DLFVBQVUsK0dBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUo7QUFBQSxJQUNwSyx1QkFBQyxTQUFNLE9BQU0sNEJBQTJCLFVBQVUsNEJBQTRCaEosS0FBS3lCLFFBQVEsa0JBQWtCLFVBQVMsU0FBUSxVQUFTLFdBQ25JLGlDQUFDLGNBQVcsV0FBVSxRQUFPLFVBQVVrSCxhQUFhLGVBQVksd0JBQzVEO0FBQUEsNkJBQUMsU0FBTSxXQUFXLEVBQUV2RSxJQUFJLFVBQVU2RSxJQUFJLE1BQU0sR0FBRyxZQUFZLEVBQUU3RSxJQUFJLFdBQVc2RSxJQUFJLFdBQVcsR0FBRyxJQUFJaEwsU0FBU2lMLFFBQVFDLFlBQy9HO0FBQUEsK0JBQUMsYUFBVSxVQUFVZCxTQUFTLE1BQUssUUFBTyxPQUFNLFdBQVUsT0FBT04sTUFBTXJHLFVBQVUsVUFBVSxDQUFBOEMsVUFBUztBQUFFeUQsdUJBQWF6SCxVQUFVO0FBQU13SCxtQkFBUyxDQUFBOUksV0FBVSxFQUFFLEdBQUdBLE9BQU93QyxVQUFVOEMsTUFBTUMsT0FBT3ZGLE1BQU0sRUFBRTtBQUFBLFFBQUcsR0FBRyxXQUFXLEVBQUU0RixZQUFZLEVBQUVDLFFBQVEsS0FBSyxFQUFFLEdBQUcsT0FBTzBELG9CQUFvQkksVUFBVSxZQUFZLFlBQVlKLG9CQUFvQkksVUFBVSxhQUFhSixtQkFBbUI3RSxVQUFVLHlDQUF6WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStaO0FBQUEsUUFDL1osdUJBQUMsYUFBVSxVQUFVMEUsT0FBTyxNQUFLLFFBQU8sT0FBTSxZQUFXLE9BQU9QLE1BQU1uRyxRQUFRLFVBQVUsQ0FBQTRDLFVBQVM7QUFBRXlELHVCQUFhekgsVUFBVTtBQUFNd0gsbUJBQVMsQ0FBQTlJLFdBQVUsRUFBRSxHQUFHQSxPQUFPMEMsUUFBUTRDLE1BQU1DLE9BQU92RixNQUFNLEVBQUU7QUFBQSxRQUFHLEdBQUcsV0FBVyxFQUFFNEYsWUFBWSxFQUFFQyxRQUFRLEtBQUssRUFBRSxHQUFHLE9BQU8wRCxvQkFBb0JJLFVBQVUsVUFBVSxZQUFZSixvQkFBb0JJLFVBQVUsV0FBV0osbUJBQW1CN0UsVUFBVSx1Q0FBaFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvWjtBQUFBLFFBQ3BaLHVCQUFDLGFBQVUsVUFBVTJFLFdBQVcsUUFBTSxNQUFDLE9BQU0sWUFBVyxPQUFPUixNQUFNTixRQUFRLFVBQVUsQ0FBQWpELFVBQVM7QUFBRXlELHVCQUFhekgsVUFBVTtBQUFNd0gsbUJBQVMsQ0FBQTlJLFdBQVUsRUFBRSxHQUFHQSxPQUFPdUksUUFBUWpELE1BQU1DLE9BQU92RixNQUFNLEVBQUU7QUFBQSxRQUFHLEdBQUcsT0FBT3VKLG9CQUFvQkksVUFBVSxVQUFVLFlBQVlKLG9CQUFvQkksVUFBVSxXQUFXSixtQkFBbUI3RSxVQUFVLCtCQUM5VDtBQUFBLGlDQUFDLFlBQVMsT0FBTSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLFVBQVcsdUJBQUMsWUFBUyxPQUFNLFFBQU8sb0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFBVyx1QkFBQyxZQUFTLE9BQU0sU0FBUSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxhQUQ1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsYUFBWSx1QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFdBTnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0N1RSxtQkFBbUJLLGNBQWMsdUJBQUMsU0FBTSxVQUFTLFNBQVEsTUFBSyxTQUFTQSxxQkFBVzVFLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxTQVQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUNDMkQsZUFBZSx1QkFBQyxTQUFNLFVBQVMsU0FBUSxNQUFLLFNBQVE7QUFBQSw2QkFBQyxZQUFPLG1EQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUFTO0FBQUEsU0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5SSxJQUFXLHVCQUFDLGNBQVcsT0FBT2xHLE1BQU0sZ0JBQWUsV0FBV3VHLGVBQUssbUNBQ3hOO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUssT0FBTSx5QkFBd0IsT0FBT0EsRUFBRXdCLHVCQUF1QixNQUFLLGdDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFDckcsdUJBQUMsUUFBSyxPQUFNLHFCQUFvQixPQUFPeEIsRUFBRXlCLDBCQUEwQixNQUFLLG1DQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsUUFDdkcsdUJBQUMsUUFBSyxPQUFNLHlCQUF3QixPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU96QixFQUFFMEIsZUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQyxHQUFLLE1BQU0xQixFQUFFMEIsY0FBYyw0QkFBNEIsc0NBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUs7QUFBQSxRQUN2Syx1QkFBQyxRQUFLLE9BQU0sMEJBQXlCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBTzFCLEVBQUUyQixrQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQyxHQUFLLE1BQUssbUNBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEg7QUFBQSxXQUo5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQU0sZUFBWSxtQkFBa0IsSUFBSSxDQUFDdEwsU0FBUzBHLE9BQU9vQyxZQUFZOUksU0FBUzZJLEtBQUswQyxZQUFZLEdBQzNGNUI7QUFBQUEsVUFBRUUsVUFBVSx1QkFBQyxjQUFXLFNBQVEsU0FBUTtBQUFBO0FBQUEsVUFBSTNLLGVBQWV5SyxFQUFFRSxPQUFPcEcsUUFBUTtBQUFBLFVBQUU7QUFBQSxVQUFJdkUsZUFBZXlLLEVBQUVFLE9BQU9sRyxNQUFNO0FBQUEsVUFBRTtBQUFBLFVBQWFnRyxFQUFFRSxPQUFPTCxXQUFXLFFBQVEsU0FBU0csRUFBRUUsT0FBT0wsV0FBVyxTQUFTLFNBQVM7QUFBQSxhQUE5TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNNO0FBQUEsUUFDbk4sdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBaUI7QUFBQTtBQUFBLFVBQVV2SyxTQUFTMEssRUFBRXRHLE1BQU1zRyxFQUFFRSxRQUFRckcsWUFBWXpCLEtBQUt5QixRQUFRO0FBQUEsVUFBRTtBQUFBLFVBQUl6QixLQUFLeUo7QUFBQUEsVUFBSztBQUFBLFVBQVk3QixFQUFFRSxRQUFRckcsWUFBWXpCLEtBQUt5QjtBQUFBQSxhQUExSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1MO0FBQUEsV0FGdkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxlQUFZLGVBQVksMkJBQTBCLFNBQVMsRUFBRTJDLElBQUksT0FBT3NGLElBQUksVUFBVSxHQUNuRjtBQUFBLCtCQUFDLFNBQU0sT0FBTSxzQkFBcUIsVUFBUyw4REFDdkM7QUFBQSxpQ0FBQyxPQUFJLE1BQUssT0FBTSxjQUFZLGVBQWU5QixFQUFFRSxRQUFRTCxVQUFVLElBQUkseUJBQXlCLGVBQVkseUJBQXdCLElBQUksQ0FBQyxFQUFFa0MsUUFBUSxJQUFJLEdBQUcxTCxTQUFTMEcsT0FBT2lGLGtCQUFrQixHQUNuTGhDLFlBQUVpQyxPQUFPakYsU0FBUyx1QkFBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFBTyxpQ0FBQyxZQUFTLE1BQU1nRCxFQUFFaUMsT0FBTyxvQkFBa0IsTUFDMUc7QUFBQSxtQ0FBQyxpQkFBYyxRQUFRak4sT0FBT2tOLGtCQUFrQixVQUFVLFNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsU0FBTSxTQUFRLFlBQVcsUUFBUWxOLE9BQU80QyxlQUFlLFVBQVVGLEtBQUtDLElBQUksR0FBR0QsS0FBS3lLLEtBQUtuQyxFQUFFaUMsTUFBTWpGLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxlQUFlLENBQUExRixVQUFTL0IsZUFBZTZNLE9BQU85SyxLQUFLLENBQUMsS0FBdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0s7QUFBQSxZQUN4Syx1QkFBQyxTQUFNLGVBQWUsT0FBTyxRQUFRdEMsT0FBTzRDLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFdBQVEsZ0JBQWdCLENBQUFOLFVBQVMvQixlQUFlNk0sT0FBTzlLLEtBQUssQ0FBQyxHQUFHLGNBQWMsRUFBRStLLFlBQVlyTixPQUFPc04sUUFBUXpFLE9BQU83SSxPQUFPdU4sYUFBYTlFLGFBQWF6SSxPQUFPa04saUJBQWlCLEtBQTVLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThLO0FBQUEsWUFDOUssdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFPO0FBQUEsWUFDUCx1QkFBQyxPQUFJLFNBQVEseUJBQXdCLE1BQUsscUJBQW9CLE1BQU1sTixPQUFPd04sUUFBUSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLFlBQ3hHLHVCQUFDLE9BQUksU0FBUSw0QkFBMkIsTUFBSyxpQkFBZ0IsTUFBTXhOLE9BQU80QyxlQUFlLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThHO0FBQUEsZUFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRbkUsS0FSbUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRUixJQUF5Qix1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLElBQUl2QixTQUFTMEcsT0FBTzBGLGlCQUFpQiw0REFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0gsS0FUNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxPQUFNLDhCQUE2QixNQUFNekMsRUFBRWlDLFNBQVMsSUFBSSxRQUFRLENBQUFTLFVBQVNBLE1BQU01SSxVQUFVLE9BQU0sNkNBQTRDLFNBQVM7QUFBQSxZQUMzSixFQUFFTSxLQUFLLFNBQVN1RSxPQUFPLGVBQWVDLFFBQVFBLENBQUE4RCxVQUFTLEdBQUduTixlQUFlbU4sTUFBTTVJLFFBQVEsQ0FBQyxNQUFNdkUsZUFBZW1OLE1BQU0xSSxNQUFNLENBQUMsR0FBRztBQUFBLFlBQzdILEVBQUVJLEtBQUssU0FBU3VFLE9BQU8sWUFBWUcsT0FBTyxTQUFTRixRQUFRQSxDQUFBOEQsVUFBU0EsTUFBTWxCLHNCQUFzQjtBQUFBLFlBQ2hHLEVBQUVwSCxLQUFLLFdBQVd1RSxPQUFPLGlCQUFpQkcsT0FBTyxTQUFTRixRQUFRQSxDQUFBOEQsVUFBU0EsTUFBTWpCLHlCQUF5QjtBQUFBLFlBQzFHLEVBQUVySCxLQUFLLGFBQWF1RSxPQUFPLGdCQUFnQkcsT0FBTyxTQUFTRixRQUFRQSxDQUFBOEQsVUFBUyx1QkFBQyxVQUFPLE9BQU9BLE1BQU1mLGtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQyxFQUFJO0FBQUEsWUFDcEgsRUFBRXZILEtBQUssVUFBVXVFLE9BQU8sZUFBZUcsT0FBTyxTQUFTRixRQUFRQSxDQUFBOEQsVUFBUyx1QkFBQyxVQUFPLE9BQU9BLE1BQU1oQixlQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQyxFQUFJO0FBQUEsVUFBQyxLQUxsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1FO0FBQUEsYUFsQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxPQUFNLDRCQUEyQixVQUFTLHFDQUM3QyxpQ0FBQyxPQUFJLGVBQVksOEJBQTZCLElBQUlyTCxTQUFTMEcsT0FBTzRGLGtCQUM5RCxpQ0FBQyxTQUFNLFdBQVUsTUFBSyxlQUFZLDJCQUEwQixJQUFJLENBQUMsRUFBRTNDLEdBQUcsR0FBRzRDLEdBQUcsRUFBRSxHQUFHdk0sU0FBUzBHLE9BQU84RixpQkFBaUJ4TSxTQUFTMEcsT0FBTytGLFdBQVcsR0FDeEk5QyxZQUFFK0MsYUFBYS9GLFNBQVNnRCxFQUFFK0MsYUFBYWpHLElBQUksQ0FBQ2tHLFVBQVV0RSxVQUFVLHVCQUFDLGNBQVcsV0FBVSxNQUFtQ3NFLHNCQUF6QixHQUFHdEUsS0FBSyxJQUFJc0UsUUFBUSxJQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFLENBQWEsSUFBSSx1QkFBQyxjQUFXLFdBQVUsTUFBSyxPQUFNLGtCQUFpQiwwREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RixLQURwUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sT0FBTSx3QkFBdUIsVUFBUyw4Q0FDekM7QUFBQSxpQ0FBQyxPQUFJLE1BQUssT0FBTSxjQUFZLGlDQUFpQ2hELEVBQUVpRCxnQkFBZ0JqRyxNQUFNLFNBQVMsZUFBWSx3QkFBdUIsSUFBSSxDQUFDLEVBQUUrRSxRQUFRLElBQUksR0FBRzFMLFNBQVMwRyxPQUFPaUYsa0JBQWtCLEdBQ3BMaEMsWUFBRWlELGdCQUFnQmpHLFNBQVMsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFPLFFBQU8saUNBQUMsWUFBUyxNQUFNZ0QsRUFBRWlELGlCQUFpQixvQkFBa0IsTUFDN0g7QUFBQSxtQ0FBQyxpQkFBYyxRQUFRak8sT0FBT2tOLGtCQUFrQixVQUFVLFNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsU0FBTSxTQUFRLFVBQVMsUUFBUWxOLE9BQU80QyxlQUFlLFVBQVUsR0FBRyxRQUFRLElBQUksTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQixLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RztBQUFBLFlBQzdHLHVCQUFDLFNBQU0sZUFBZSxPQUFPLFFBQVE1QyxPQUFPNEMsaUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsV0FBUSxjQUFjLEVBQUV5SyxZQUFZck4sT0FBT3NOLFFBQVF6RSxPQUFPN0ksT0FBT3VOLGFBQWE5RSxhQUFhekksT0FBT2tOLGlCQUFpQixLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzSDtBQUFBLFlBQ3RILHVCQUFDLE9BQUksU0FBUSxTQUFRLE1BQUssaUJBQWdCLE1BQU1sTixPQUFPd04sUUFBUSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLGVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNNUUsS0FONEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNakIsSUFBeUIsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixJQUFJbk0sU0FBUzBHLE9BQU8wRixpQkFBaUIsbURBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJHLEtBUG5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsTUFBTXpDLEVBQUVpRCxpQkFBaUIsUUFBUSxDQUFBQyxXQUFVQSxPQUFPQSxRQUFRLE9BQU0sd0JBQXVCLE9BQU0sMkNBQTBDLFNBQVM7QUFBQSxZQUN2SixFQUFFOUksS0FBSyxVQUFVdUUsT0FBTyxTQUFTQyxRQUFRQSxDQUFBc0UsV0FBVUEsT0FBT0EsT0FBTztBQUFBLFlBQ2pFLEVBQUU5SSxLQUFLLFNBQVN1RSxPQUFPLGlCQUFpQkcsT0FBTyxTQUFTRixRQUFRQSxDQUFBc0UsV0FBVUEsT0FBT0MsTUFBTTtBQUFBLFVBQUMsS0FGNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHRTtBQUFBLGFBYk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSTlNLFNBQVM2SSxLQUFLa0UsZUFBZSxpSkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5TDtBQUFBLFNBdkQrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0Q1TixLQXhEb0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdEaEs7QUFBQSxPQXhFRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUVQO0FBQ0o7QUFBQy9ELElBM0llRCxlQUFhO0FBQUEsVUFDUmhLLFVBQ1d0QixpQkFZZm9CLE1BQU07QUFBQTtBQUFBLE1BZFBrSztBQTZJaEIsU0FBU1Esb0JBQW9COUYsVUFBa0JFLFFBQWdCNkYsUUFBZ0J3RCxjQUE0RjtBQUN2SyxNQUFJLENBQUMsQ0FBQyxPQUFPLFFBQVEsT0FBTyxFQUFFakksU0FBU3lFLE1BQU0sRUFBRyxRQUFPLEVBQUVvQixPQUFPLFVBQVVqRixTQUFTLG1DQUFtQztBQUN0SCxNQUFJcUgsZ0JBQWdCLENBQUN2SixZQUFZLENBQUNFLE9BQVEsUUFBTztBQUNqRCxNQUFJLENBQUN4RSxnQkFBZ0JzRSxRQUFRLEVBQUcsUUFBTyxFQUFFbUgsT0FBTyxZQUFZakYsU0FBUyw0QkFBNEI7QUFDakcsTUFBSSxDQUFDeEcsZ0JBQWdCd0UsTUFBTSxFQUFHLFFBQU8sRUFBRWlILE9BQU8sVUFBVWpGLFNBQVMsNkJBQTZCO0FBQzlGLE1BQUlsQyxXQUFXRSxPQUFRLFFBQU8sRUFBRWlILE9BQU8sWUFBWWpGLFNBQVMsbURBQW1EO0FBQy9HLFFBQU1zSCxPQUFPNUwsS0FBSzZMLE9BQU9DLEtBQUtDLE1BQU0sR0FBR3pKLE1BQU0sZ0JBQWdCLElBQUl3SixLQUFLQyxNQUFNLEdBQUczSixRQUFRLGdCQUFnQixNQUFNLEtBQUssS0FBSyxLQUFLLElBQUssSUFBSTtBQUNySSxNQUFJd0osT0FBTyxJQUFLLFFBQU8sRUFBRXJDLE9BQU8sVUFBVWpGLFNBQVMsK0NBQStDO0FBQ2xHLFNBQU87QUFDWDtBQUFDLElBQUEvRCxJQUFBeUwsS0FBQUM7QUFBQSxhQUFBMUwsSUFBQTtBQUFBLGFBQUF5TCxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIkFjdGlvbkdyb3VwIiwiRm9ybUZpZWxkcyIsIlBhZ2VTZWN0aW9ucyIsIlNlY3Rpb25HcmlkIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwidmlzdWFsU3giLCJ1c2VTZWFyY2hQYXJhbXMiLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIkxpbmsiLCJNZW51SXRlbSIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsIkJhciIsIkJhckNoYXJ0IiwiQ2FydGVzaWFuR3JpZCIsIkxlZ2VuZCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJUZXh0IiwiVG9vbHRpcCIsIlhBeGlzIiwiWUF4aXMiLCJjb2xvcnMiLCJ0b2tlbnMiLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJkYXRlVGltZSIsImZvcm1hdERhdGVPbmx5IiwiaXNWYWxpZERhdGVPbmx5IiwiQW1vdW50IiwiRGF0YVRhYmxlIiwiRGV0YWlsTGluZSIsIkVycm9yTm90aWNlIiwiUGFnZUhlYWRlciIsIlBhbmVsIiwiUGFnZXIiLCJRdWVyeVN0YXRlIiwiUm91dGVMaW5rIiwiU3RhdCIsIlN0YXRzIiwiU3RhdHVzIiwibGF5b3V0U3giLCJhdXRob3JpemVkRG93bmxvYWRIcmVmIiwiZGF0ZUluVGltZXpvbmUiLCJyZXBvcnREYXRlQm91bmRhcnkiLCJyZXBvcnRGaWxlbmFtZSIsInJlcG9ydExhYmVscyIsImludmVudG9yeSIsIm9yZGVycyIsImNhc2hmbG93IiwicHJvZml0X2xvc3MiLCJzb3VyY2VQZXJtaXNzaW9ucyIsIk1hcmtldGluZ1JlYXNvblRpY2siLCJ4IiwieSIsIndpZHRoIiwidmlzaWJsZVRpY2tzQ291bnQiLCJwYXlsb2FkIiwidmFsdWUiLCJ0cmltIiwiY2F0ZWdvcnlMYWJlbEluc2V0IiwibGFiZWxXaWR0aCIsIk1hdGgiLCJtYXgiLCJ0ZXh0U2Vjb25kYXJ5IiwiZm9udFNpemUiLCJmb250U2l6ZXMiLCJib2R5IiwiZm9udEZhbWlseSIsIl9jIiwiUmVwb3J0c1BhZ2UiLCJfcyIsInNob3AiLCJwYXJhbXMiLCJzZXRQYXJhbXMiLCJsYXRlc3RQYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJwZW5kaW5nU2VhcmNoIiwiY29tbWl0dGVkU2VhcmNoIiwidG9TdHJpbmciLCJjdXJyZW50Iiwic3VtbWFyeSIsImNhblJlYWRKb2JzIiwiam9icyIsInF1ZXJ5IiwibGltaXQiLCJjdXJzb3IiLCJnZXQiLCJ1bmRlZmluZWQiLCJydW4iLCJyZXF1ZXN0ZWRUeXBlIiwidHlwZSIsInNuYXBzaG90QXNPZiIsImRhdGEiLCJhc09mIiwiZGVmYXVsdFJhbmdlIiwiY3VycmVudERhdGUiLCJ0aW1lem9uZSIsImZyb21EYXRlIiwic2xpY2UiLCJ0b0RhdGUiLCJmcm9tVmFsdWUiLCJ0b1ZhbHVlIiwicmVhZFJlcG9ydERhdGUiLCJrZXkiLCJoYXMiLCJmcm9tIiwidG8iLCJzZXRSZXBvcnRQYXJhbSIsIm5leHQiLCJzZXQiLCJmbHVzaFN5bmMiLCJyYW5nZUVycm9yIiwic2V0UmFuZ2VFcnJvciIsImxhc3RFeHBvcnQiLCJzZXRMYXN0RXhwb3J0IiwiY2FuRXhwb3J0UmVwb3J0cyIsImNhbkV4cG9ydFNvdXJjZSIsImF2YWlsYWJsZVJlcG9ydHMiLCJyZXBvcnRBdmFpbGFibGUiLCJpbmNsdWRlcyIsImNoYW5nZWQiLCJyZXBsYWNlIiwic3VibWl0IiwiUmFuZ2VFcnJvciIsInJlcXVlc3QiLCJyZXBvcnRUeXBlIiwiZm9ybWF0IiwicmVzcG9uc2UiLCJleGVjdXRlIiwiam9iIiwiZXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlRXhwb3J0IiwibGFzdERvd25sb2FkIiwic3RhdHVzIiwiZG93bmxvYWRVcmwiLCJsb2NhdGlvbiIsIm9yaWdpbiIsIl9fTU9DS19fIiwieHMiLCJ4bCIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJldmVudCIsInRhcmdldCIsIm1hcCIsInJlcG9ydCIsImxlbmd0aCIsInNtIiwiaW5wdXRMYWJlbCIsInNocmluayIsInBlbmRpbmciLCJpZCIsImFjdGlvbnMiLCJsaW5rVGFyZ2V0IiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJib3JkZXJSYWRpdXMiLCJyYWRpdXMiLCJjb250cm9sIiwiY29sb3IiLCJmb250V2VpZ2h0IiwidHlwb2dyYXBoeSIsInNlbWlib2xkIiwiYmdjb2xvciIsInRleHREZWNvcmF0aW9uIiwib3V0bGluZSIsImZvY3VzUmluZyIsIm91dGxpbmVDb2xvciIsIm91dGxpbmVPZmZzZXQiLCJjb250cm9sT2Zmc2V0Iiwid2FybmluZ3MiLCJ3YXJuaW5nIiwiaW5kZXgiLCJsYWJlbCIsInJlbmRlciIsImtpbmQiLCJhbGlnbiIsImNvbXBsZXRlZCIsInRvdGFsIiwidXBkYXRlZEF0IiwicGFnZSIsImNvbnRleHRHYXAiLCJNYXJrZXRpbmdQYWdlIiwiX3MyIiwic2VhcmNoIiwiZnJvbVBhcmFtIiwidG9QYXJhbSIsImJ1Y2tldFBhcmFtIiwiaGFzRGF0ZUZpbHRlciIsImFwcGxpZWRFcnJvciIsIm1hcmtldGluZ1JhbmdlRXJyb3IiLCJidWNrZXQiLCJPYmplY3QiLCJrZXlzIiwibSIsIm1hcmtldGluZ1BlcmlvZCIsInBlcmlvZCIsImRyYWZ0Iiwic2V0RHJhZnQiLCJkcmFmdFRvdWNoZWQiLCJwZW5kaW5nRGVmYXVsdFNlYXJjaCIsInNob3dGaWx0ZXJFcnJvciIsInNldFNob3dGaWx0ZXJFcnJvciIsImZyb21SZWYiLCJ0b1JlZiIsImJ1Y2tldFJlZiIsImRyYWZ0RXJyb3IiLCJ2aXNpYmxlRmlsdGVyRXJyb3IiLCJpc0RlZmF1bHROb3JtYWxpemF0aW9uIiwiYXBwbHlGaWx0ZXIiLCJwcmV2ZW50RGVmYXVsdCIsImZpZWxkIiwiZm9jdXMiLCJub3RpY2UiLCJhZnRlckdhcCIsIm1kIiwidG9vbGJhciIsImNvbnRyb2xHYXAiLCJrbm93bkF0dHJpYnV0ZWRPcmRlcnMiLCJ1bmtub3duQXR0cmlidXRpb25PcmRlcnMiLCJhY3R1YWxTcGVuZCIsImVzdGltYXRlZFNwZW5kIiwic2VjdGlvbkFmdGVyIiwibmFtZSIsImxnIiwiaGVpZ2h0IiwiY2hhcnRWaWV3cG9ydEluc2V0IiwidHJlbmQiLCJib3JkZXJEZWNvcmF0aXZlIiwiY2VpbCIsIlN0cmluZyIsImJhY2tncm91bmQiLCJyYWlzZWQiLCJ0ZXh0UHJpbWFyeSIsImFjY2VudCIsImVtcHR5U3RhdGVJbnNldCIsInBvaW50IiwibGlzdFN1cmZhY2VJbnNldCIsInAiLCJsaXN0TWFya2VySW5zZXQiLCJsaXN0SXRlbUdhcCIsInRvcFF1ZXN0aW9ucyIsInF1ZXN0aW9uIiwibG9zdFNhbGVSZWFzb25zIiwicmVhc29uIiwiY291bnQiLCJzZWN0aW9uQmVmb3JlIiwiYWxsb3dEZWZhdWx0IiwiZGF5cyIsImZsb29yIiwiRGF0ZSIsInBhcnNlIiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpb25Hcm91cCwgRm9ybUZpZWxkcywgUGFnZVNlY3Rpb25zLCBTZWN0aW9uR3JpZCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdHlwZSB7IEZvcm1FdmVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHZpc3VhbFN4IH0gZnJvbSAnQC9zaGFyZWQvdWkvdmlzdWFsJztcbmltcG9ydCB7IHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgQWxlcnQsIEJveCwgQnV0dG9uLCBMaW5rLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IHsgQmFyLCBCYXJDaGFydCwgQ2FydGVzaWFuR3JpZCwgTGVnZW5kLCBSZXNwb25zaXZlQ29udGFpbmVyLCBUZXh0LCBUb29sdGlwLCBYQXhpcywgWUF4aXMgfSBmcm9tICdyZWNoYXJ0cyc7XG5pbXBvcnQgdHlwZSB7IEV4cG9ydFJlcXVlc3QsIEpvYiwgTWFya2V0aW5nQnVja2V0IH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XG5pbXBvcnQgeyBjb2xvcnMsIHRva2VucyB9IGZyb20gJ0Bib3RzYWxlcy90b2tlbnMnO1xuaW1wb3J0IHsgdXNlQXBpLCB1c2VDb21tYW5kIH0gZnJvbSAnLi4vLi4vc2hhcmVkL2FwaS9ob29rcyc7XG5pbXBvcnQgeyB1c2VTY29wZSwgdXNlQ2FuIH0gZnJvbSAnLi4vLi4vc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IGRhdGVUaW1lLCBmb3JtYXREYXRlT25seSwgaXNWYWxpZERhdGVPbmx5IH0gZnJvbSAnLi4vLi4vc2hhcmVkL21vZGVsL2Zvcm1hdCc7XG5pbXBvcnQgeyBBbW91bnQsIERhdGFUYWJsZSwgRGV0YWlsTGluZSwgRXJyb3JOb3RpY2UsIFBhZ2VIZWFkZXIsIFBhbmVsLCBQYWdlciwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0LCBTdGF0cywgU3RhdHVzIH0gZnJvbSAnLi4vLi4vc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgbGF5b3V0U3ggfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvbGF5b3V0JztcbmltcG9ydCB7IGF1dGhvcml6ZWREb3dubG9hZEhyZWYsIGRhdGVJblRpbWV6b25lLCByZXBvcnREYXRlQm91bmRhcnksIHJlcG9ydEZpbGVuYW1lIH0gZnJvbSAnLi9yZXBvcnQtdXRpbHMnO1xuXG5jb25zdCByZXBvcnRMYWJlbHM6IFJlY29yZDxFeHBvcnRSZXF1ZXN0WydyZXBvcnRUeXBlJ10sIHN0cmluZz4gPSB7XG4gICAgaW52ZW50b3J5OiAnVOG7k24ga2hvJywgb3JkZXJzOiAnxJDGoW4gaMOgbmcnLCBjYXNoZmxvdzogJ0TDsm5nIHRp4buBbicsIHByb2ZpdF9sb3NzOiAnTOG7o2kgbmh14bqtbicsXG59O1xuY29uc3Qgc291cmNlUGVybWlzc2lvbnM6IFJlY29yZDxFeHBvcnRSZXF1ZXN0WydyZXBvcnRUeXBlJ10sIHN0cmluZz4gPSB7XG4gICAgaW52ZW50b3J5OiAnaW52ZW50b3J5LnJlYWQnLCBvcmRlcnM6ICdvcmRlcnMucmVhZCcsIGNhc2hmbG93OiAnZmluYW5jZS5yZWFkJywgcHJvZml0X2xvc3M6ICdmaW5hbmNlLnJlYWQnLFxufTtcblxuZnVuY3Rpb24gTWFya2V0aW5nUmVhc29uVGljayh7IHggPSAwLCB5ID0gMCwgd2lkdGggPSAwLCB2aXNpYmxlVGlja3NDb3VudCA9IDEsIHBheWxvYWQgfTogeyB4PzogbnVtYmVyOyB5PzogbnVtYmVyOyB3aWR0aD86IG51bWJlcjsgdmlzaWJsZVRpY2tzQ291bnQ/OiBudW1iZXI7IHBheWxvYWQ/OiB7IHZhbHVlPzogdW5rbm93biB9IH0pIHtcbiAgICBjb25zdCB2YWx1ZSA9IHR5cGVvZiBwYXlsb2FkPy52YWx1ZSA9PT0gJ3N0cmluZycgPyBwYXlsb2FkLnZhbHVlLnRyaW0oKSA6ICcnO1xuICAgIGNvbnN0IGNhdGVnb3J5TGFiZWxJbnNldCA9IDg7XG4gICAgY29uc3QgbGFiZWxXaWR0aCA9IE1hdGgubWF4KDEsIHdpZHRoIC8gTWF0aC5tYXgoMSwgdmlzaWJsZVRpY2tzQ291bnQpIC0gY2F0ZWdvcnlMYWJlbEluc2V0KTtcbiAgICByZXR1cm4gPFRleHQgeD17eH0geT17eX0gZHk9ezEyfSB3aWR0aD17bGFiZWxXaWR0aH0gYnJlYWtBbGwgdmVydGljYWxBbmNob3I9XCJzdGFydFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIiBmaWxsPXtjb2xvcnMudGV4dFNlY29uZGFyeX1cbiAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IHRva2Vucy5mb250U2l6ZXMuYm9keSwgZm9udEZhbWlseTogdG9rZW5zLmZvbnRGYW1pbHkgfX0+e3ZhbHVlfTwvVGV4dD47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXBvcnRzUGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgW3BhcmFtcywgc2V0UGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IGxhdGVzdFBhcmFtcyA9IHVzZVJlZihuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcykpO1xuICAgIGNvbnN0IHBlbmRpbmdTZWFyY2ggPSB1c2VSZWY8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgY29tbWl0dGVkU2VhcmNoID0gcGFyYW1zLnRvU3RyaW5nKCk7XG4gICAgICAgIGlmIChwZW5kaW5nU2VhcmNoLmN1cnJlbnQgIT09IG51bGwgJiYgcGVuZGluZ1NlYXJjaC5jdXJyZW50ICE9PSBjb21taXR0ZWRTZWFyY2gpIHJldHVybjtcbiAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7XG4gICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG51bGw7XG4gICAgfSwgW3BhcmFtc10pO1xuICAgIGNvbnN0IHN1bW1hcnkgPSB1c2VBcGkoJ2dldFJlcG9ydFN1bW1hcnknKTtcbiAgICBjb25zdCBjYW5SZWFkSm9icyA9IHVzZUNhbignam9icy5yZWFkJyk7XG4gICAgY29uc3Qgam9icyA9IHVzZUFwaSgnbGlzdEpvYnMnLCB7IHF1ZXJ5OiB7IGxpbWl0OiAxMCwgY3Vyc29yOiBwYXJhbXMuZ2V0KCdjdXJzb3InKSB8fCB1bmRlZmluZWQgfSB9LCBjYW5SZWFkSm9icyk7XG4gICAgY29uc3QgcnVuID0gdXNlQ29tbWFuZCgnY3JlYXRlRXhwb3J0JywgWydsaXN0Sm9icyddKTtcbiAgICBjb25zdCByZXF1ZXN0ZWRUeXBlID0gcGFyYW1zLmdldCgncmVwb3J0VHlwZScpO1xuICAgIGNvbnN0IHR5cGU6IEV4cG9ydFJlcXVlc3RbJ3JlcG9ydFR5cGUnXSA9IHJlcXVlc3RlZFR5cGUgPT09ICdpbnZlbnRvcnknIHx8IHJlcXVlc3RlZFR5cGUgPT09ICdjYXNoZmxvdycgfHwgcmVxdWVzdGVkVHlwZSA9PT0gJ3Byb2ZpdF9sb3NzJyA/IHJlcXVlc3RlZFR5cGUgOiAnb3JkZXJzJztcbiAgICBjb25zdCBzbmFwc2hvdEFzT2YgPSBzdW1tYXJ5LmRhdGE/LmRhdGEuYXNPZjtcbiAgICBjb25zdCBkZWZhdWx0UmFuZ2UgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFzbmFwc2hvdEFzT2YpIHJldHVybiBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudERhdGUgPSBkYXRlSW5UaW1lem9uZShzbmFwc2hvdEFzT2YsIHNob3AudGltZXpvbmUpO1xuICAgICAgICAgICAgcmV0dXJuIHsgZnJvbURhdGU6IGAke2N1cnJlbnREYXRlLnNsaWNlKDAsIDcpfS0wMWAsIHRvRGF0ZTogY3VycmVudERhdGUgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7IHJldHVybiBudWxsOyB9XG4gICAgfSwgW3Nob3AudGltZXpvbmUsIHNuYXBzaG90QXNPZl0pO1xuICAgIGNvbnN0IGZyb21WYWx1ZSA9IHBhcmFtcy5nZXQoJ2Zyb21EYXRlJyk7XG4gICAgY29uc3QgdG9WYWx1ZSA9IHBhcmFtcy5nZXQoJ3RvRGF0ZScpO1xuICAgIGNvbnN0IHJlYWRSZXBvcnREYXRlID0gKGtleTogJ2Zyb21EYXRlJyB8ICd0b0RhdGUnLCB2YWx1ZTogc3RyaW5nIHwgbnVsbCkgPT4ge1xuICAgICAgICBpZiAoaXNWYWxpZERhdGVPbmx5KHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuICAgICAgICBpZiAocGFyYW1zLmhhcyhrZXkpICYmIHZhbHVlID09PSAnJykgcmV0dXJuICcnO1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJhbmdlPy5ba2V5XSB8fCAnJztcbiAgICB9O1xuICAgIGNvbnN0IGZyb20gPSByZWFkUmVwb3J0RGF0ZSgnZnJvbURhdGUnLCBmcm9tVmFsdWUpO1xuICAgIGNvbnN0IHRvID0gcmVhZFJlcG9ydERhdGUoJ3RvRGF0ZScsIHRvVmFsdWUpO1xuICAgIGNvbnN0IHNldFJlcG9ydFBhcmFtID0gKGtleTogJ3JlcG9ydFR5cGUnIHwgJ2Zyb21EYXRlJyB8ICd0b0RhdGUnLCB2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxhdGVzdFBhcmFtcy5jdXJyZW50KTtcbiAgICAgICAgaWYgKGtleSA9PT0gJ3JlcG9ydFR5cGUnKSBuZXh0LnNldChrZXksIHZhbHVlKTtcbiAgICAgICAgZWxzZSBuZXh0LnNldChrZXksIGlzVmFsaWREYXRlT25seSh2YWx1ZSkgPyB2YWx1ZSA6ICcnKTtcbiAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICBwZW5kaW5nU2VhcmNoLmN1cnJlbnQgPSBuZXh0LnRvU3RyaW5nKCk7XG4gICAgICAgIHNldFBhcmFtcyhuZXh0LCB7IGZsdXNoU3luYzogdHJ1ZSB9KTtcbiAgICB9O1xuICAgIGNvbnN0IFtyYW5nZUVycm9yLCBzZXRSYW5nZUVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbbGFzdEV4cG9ydCwgc2V0TGFzdEV4cG9ydF0gPSB1c2VTdGF0ZTx7IGpvYjogSm9iOyB0eXBlOiBFeHBvcnRSZXF1ZXN0WydyZXBvcnRUeXBlJ107IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgY2FuRXhwb3J0UmVwb3J0cyA9IHVzZUNhbigncmVwb3J0cy5leHBvcnQnKTtcbiAgICBjb25zdCBjYW5FeHBvcnRTb3VyY2UgPSB1c2VDYW4oc291cmNlUGVybWlzc2lvbnNbdHlwZV0pO1xuICAgIGNvbnN0IGF2YWlsYWJsZVJlcG9ydHMgPSBzdW1tYXJ5LmRhdGE/LmRhdGEuYXZhaWxhYmxlUmVwb3J0cyB8fCBbXTtcbiAgICBjb25zdCByZXBvcnRBdmFpbGFibGUgPSBhdmFpbGFibGVSZXBvcnRzLmluY2x1ZGVzKHR5cGUpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFzbmFwc2hvdEFzT2YpIHJldHVybjtcbiAgICAgICAgaWYgKCFkZWZhdWx0UmFuZ2UpIHtcbiAgICAgICAgICAgIHNldFJhbmdlRXJyb3IoJ03DumkgZ2nhu50gY+G7rWEgaMOgbmcgaG/hurdjIG3hu5FjIHRo4budaSBnaWFuIGLDoW8gY8OhbyBraMO0bmcgaOG7o3AgbOG7hy4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobGF0ZXN0UGFyYW1zLmN1cnJlbnQpO1xuICAgICAgICAgICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0ZWRUeXBlICE9PSAnaW52ZW50b3J5JyAmJiByZXF1ZXN0ZWRUeXBlICE9PSAnY2FzaGZsb3cnICYmIHJlcXVlc3RlZFR5cGUgIT09ICdwcm9maXRfbG9zcycgJiYgcmVxdWVzdGVkVHlwZSAhPT0gJ29yZGVycycpIHtcbiAgICAgICAgICAgICAgICBuZXh0LnNldCgncmVwb3J0VHlwZScsICdvcmRlcnMnKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFyYW1zLmhhcygnZnJvbURhdGUnKSB8fCAoZnJvbVZhbHVlICYmICFpc1ZhbGlkRGF0ZU9ubHkoZnJvbVZhbHVlKSkpIHtcbiAgICAgICAgICAgICAgICBuZXh0LnNldCgnZnJvbURhdGUnLCBkZWZhdWx0UmFuZ2UuZnJvbURhdGUpO1xuICAgICAgICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFwYXJhbXMuaGFzKCd0b0RhdGUnKSB8fCAodG9WYWx1ZSAmJiAhaXNWYWxpZERhdGVPbmx5KHRvVmFsdWUpKSkge1xuICAgICAgICAgICAgICAgIG5leHQuc2V0KCd0b0RhdGUnLCBkZWZhdWx0UmFuZ2UudG9EYXRlKTtcbiAgICAgICAgICAgICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICAgICAgICAgICAgbGF0ZXN0UGFyYW1zLmN1cnJlbnQgPSBuZXh0O1xuICAgICAgICAgICAgICAgIHBlbmRpbmdTZWFyY2guY3VycmVudCA9IG5leHQudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICBzZXRQYXJhbXMobmV4dCwgeyByZXBsYWNlOiB0cnVlLCBmbHVzaFN5bmM6IHRydWUgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggeyBzZXRSYW5nZUVycm9yKCdNw7ppIGdp4budIGPhu61hIGjDoG5nIGhv4bq3YyBt4buRYyB0aOG7nWkgZ2lhbiBiw6FvIGPDoW8ga2jDtG5nIGjhu6NwIGzhu4cuJyk7IH1cbiAgICB9LCBbZGVmYXVsdFJhbmdlLCBwYXJhbXMsIHJlcXVlc3RlZFR5cGUsIGZyb21WYWx1ZSwgdG9WYWx1ZSwgc2V0UGFyYW1zLCBzbmFwc2hvdEFzT2ZdKTtcblxuICAgIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0UmFuZ2VFcnJvcignJyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoIXNuYXBzaG90QXNPZiB8fCAhZnJvbSB8fCAhdG8pIHRocm93IG5ldyBSYW5nZUVycm9yKCdDaMawYSBjw7Mgc25hcHNob3QgaG/hurdjIGtob+G6o25nIG5nw6B5IMSR4bqneSDEkeG7py4nKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgcmVwb3J0VHlwZTogdHlwZSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6ICdjc3YnLFxuICAgICAgICAgICAgICAgIGZyb206IHJlcG9ydERhdGVCb3VuZGFyeShmcm9tLCAnc3RhcnQnLCBzaG9wLnRpbWV6b25lKSxcbiAgICAgICAgICAgICAgICB0bzogcmVwb3J0RGF0ZUJvdW5kYXJ5KHRvLCAnZW5kJywgc2hvcC50aW1lem9uZSksXG4gICAgICAgICAgICAgICAgdGltZXpvbmU6IHNob3AudGltZXpvbmUsXG4gICAgICAgICAgICAgICAgc25hcHNob3RBc09mLFxuICAgICAgICAgICAgfSBzYXRpc2ZpZXMgRXhwb3J0UmVxdWVzdDtcbiAgICAgICAgICAgIHNldExhc3RFeHBvcnQobnVsbCk7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHJ1bi5leGVjdXRlKHsgYm9keTogcmVxdWVzdCB9KTtcbiAgICAgICAgICAgIHNldExhc3RFeHBvcnQoeyBqb2I6IHJlc3BvbnNlLmRhdGEsIHR5cGUsIGZyb20sIHRvIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgUmFuZ2VFcnJvcikgc2V0UmFuZ2VFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaGFuZGxlRXhwb3J0ID0gKCkgPT4geyB2b2lkIHN1Ym1pdCgpOyB9O1xuXG4gICAgY29uc3QgbGFzdERvd25sb2FkID0gbGFzdEV4cG9ydD8uam9iLnN0YXR1cyA9PT0gJ3N1Y2NlZWRlZCcgJiYgbGFzdEV4cG9ydC5qb2IuZG93bmxvYWRVcmxcbiAgICAgICAgPyBhdXRob3JpemVkRG93bmxvYWRIcmVmKGxhc3RFeHBvcnQuam9iLmRvd25sb2FkVXJsLCBsb2NhdGlvbi5vcmlnaW4sIF9fTU9DS19fKVxuICAgICAgICA6IG51bGw7XG5cbiAgICByZXR1cm4gPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJCw6FvIGPDoW8gJiB4deG6pXQgZOG7ryBsaeG7h3VcIiBzdWJ0aXRsZT1cIlh14bqldCBzbmFwc2hvdCBkbyBBUEkgdOG6oW87IHPhu5EgbGnhu4d1IHThu5VuZyBo4bujcCBraMO0bmcgxJHGsOG7o2MgdMOtbmggdOG7qyBt4buZdCB0cmFuZyBkYW5oIHPDoWNoLlwiIC8+XG4gICAgICAgIDxTZWN0aW9uR3JpZCBkYXRhLXRlc3RpZD1cInJlcG9ydHMtbWFpbi1sYXlvdXRcIiBjb2x1bW5zPXt7IHhzOiAnbWlubWF4KDAsIDFmciknLCB4bDogJ21pbm1heCgwLCAxLjJmcikgbWlubWF4KDAsIC44ZnIpJyB9fSBhbGlnbkl0ZW1zPXsnc3RhcnQnfSBnZW9tZXRyeT17e21pbldpZHRoOiAwfX0+XG4gICAgICAgICAgICA8UGFnZVNlY3Rpb25zIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1wYWdlLXNlY3Rpb25zXCIgPlxuICAgICAgICAgICAgICAgIDxRdWVyeVN0YXRlIHF1ZXJ5PXtzdW1tYXJ5fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICAgICAge3N1bW1hcnkuZGF0YSAmJiA8UGFuZWwgdGl0bGU9XCJU4bqhbyB04buHcCBiw6FvIGPDoW9cIiBzdWJ0aXRsZT1cIk5nw6B5IMSRxrDhu6NjIGhp4buDdSB0aGVvIG3DumkgZ2nhu50gY+G7rWEgaMOgbmcgdsOgIGfhu61pIHRow6BuaCBt4buRYyB0aOG7nWkgZ2lhbiByw7UgcsOgbmcuXCIgYm9keU1vZGU9XCJpbnNldFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1GaWVsZHMgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLWV4cG9ydC1mb3JtLWxheW91dFwiIGdlb21ldHJ5PXt7bWF4V2lkdGg6IDc2MH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17cnVuLmVycm9yfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyYW5nZUVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e3JhbmdlRXJyb3J9PC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIkLDoW8gY8Ohb1wiIHNlbGVjdCB2YWx1ZT17dHlwZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJ29yZGVycycgfHwgdmFsdWUgPT09ICdpbnZlbnRvcnknIHx8IHZhbHVlID09PSAnY2FzaGZsb3cnIHx8IHZhbHVlID09PSAncHJvZml0X2xvc3MnKSBzZXRSZXBvcnRQYXJhbSgncmVwb3J0VHlwZScsIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TGFzdEV4cG9ydChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVJlcG9ydHMubWFwKHJlcG9ydCA9PiA8TWVudUl0ZW0gdmFsdWU9e3JlcG9ydH0ga2V5PXtyZXBvcnR9PntyZXBvcnRMYWJlbHNbcmVwb3J0XX08L01lbnVJdGVtPil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVJlcG9ydHMubGVuZ3RoID09PSAwICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIj5WYWkgdHLDsiBoaeG7h24gdOG6oWkgY2jGsGEgY8OzIGxv4bqhaSBiw6FvIGPDoW8ga2jhuqMgZOG7pW5nLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtRmllbGRzIGRhdGEtdGVzdGlkPVwicmVwb3J0cy1kYXRlLWZpbHRlcnNcIiBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVOG7qyBuZ8OgeVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e2Zyb219IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRSZXBvcnRQYXJhbSgnZnJvbURhdGUnLCBldmVudC50YXJnZXQudmFsdWUpfSBzbG90UHJvcHM9e3sgaW5wdXRMYWJlbDogeyBzaHJpbms6IHRydWUgfSB9fSBmdWxsV2lkdGggLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIsSQ4bq/biBuZ8OgeVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e3RvfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmVwb3J0UGFyYW0oJ3RvRGF0ZScsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIk3DumkgZ2nhu51cIj57c2hvcC50aW1lem9uZX08L0RldGFpbExpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERldGFpbExpbmUgbGFiZWw9XCJTbmFwc2hvdCBBUElcIj57c25hcHNob3RBc09mID8gZGF0ZVRpbWUoc25hcHNob3RBc09mLCBzaG9wLnRpbWV6b25lKSA6ICdDaMawYSBjw7Mgc25hcHNob3QnfTwvRGV0YWlsTGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWNhbkV4cG9ydFJlcG9ydHMgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiPlZhaSB0csOyIGhp4buHbiB04bqhaSBraMO0bmcgY8OzIHF1eeG7gW4gcmVwb3J0cy5leHBvcnQuPC9BbGVydD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbkV4cG9ydFJlcG9ydHMgJiYgIWNhbkV4cG9ydFNvdXJjZSAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+UXV54buBbiB4deG6pXQga2jDtG5nIHRoYXkgdGjhur8gcXV54buBbiDEkeG7jWMgbmd14buTbiB7c291cmNlUGVybWlzc2lvbnNbdHlwZV19OyBsb+G6oWkgYsOhbyBjw6FvIG7DoHkgY2jGsGEgdGjhu4MgeHXhuqV0LjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5FeHBvcnRSZXBvcnRzICYmIGNhbkV4cG9ydFNvdXJjZSAmJiAhcmVwb3J0QXZhaWxhYmxlICYmIGF2YWlsYWJsZVJlcG9ydHMubGVuZ3RoID4gMCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+QVBJIGtow7RuZyBsaeG7h3Qga8OqIGxv4bqhaSBiw6FvIGPDoW8gbsOgeSBjaG8gdmFpIHRyw7IgaGnhu4duIHThuqFpLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydH0gZGlzYWJsZWQ9eyFjYW5FeHBvcnRSZXBvcnRzIHx8ICFjYW5FeHBvcnRTb3VyY2UgfHwgIXJlcG9ydEF2YWlsYWJsZSB8fCAhc25hcHNob3RBc09mIHx8ICFmcm9tIHx8ICF0byB8fCBmcm9tID4gdG8gfHwgcnVuLnBlbmRpbmd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cnVuLnBlbmRpbmcgPyAnxJBhbmcgdOG6oW8gc25hcHNob3TigKYnIDogJ1ThuqFvIHThu4dwIGLDoW8gY8OhbyBDU1YnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RXhwb3J0ICYmIDxBY3Rpb25Hcm91cCBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gIGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7bGFzdEV4cG9ydC5qb2IuaWR9YH0+VGhlbyBkw7VpIGPDtG5nIHZp4buHYyB7bGFzdEV4cG9ydC5qb2IuaWR9PC9Sb3V0ZUxpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0RG93bmxvYWQgJiYgPExpbmsgZGF0YS10ZXN0aWQ9XCJyZXBvcnRzLWV4cG9ydC1kb3dubG9hZFwiIGNvbXBvbmVudD1cImFcIiBocmVmPXtsYXN0RG93bmxvYWR9IGRvd25sb2FkPXtyZXBvcnRGaWxlbmFtZShsYXN0RXhwb3J0LnR5cGUsIGxhc3RFeHBvcnQuZnJvbSwgbGFzdEV4cG9ydC50byl9IHVuZGVybGluZT1cIm5vbmVcIiBzeD17W2xheW91dFN4LmFjdGlvbnMubGlua1RhcmdldCwgeyBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wsIGNvbG9yOiAndGV4dC5wcmltYXJ5JywgZm9udFdlaWdodDogdmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnNlbWlib2xkLCAnJjpob3Zlcic6IHsgYmdjb2xvcjogJ2FjdGlvbi5ob3ZlcicsIHRleHREZWNvcmF0aW9uOiAnbm9uZScgfSwgJyY6Zm9jdXMtdmlzaWJsZSc6IHsgb3V0bGluZTogYCR7dG9rZW5zLmZvY3VzUmluZy53aWR0aH1weCBzb2xpZGAsIG91dGxpbmVDb2xvcjogJ3ByaW1hcnkubGlnaHQnLCBvdXRsaW5lT2Zmc2V0OiB0b2tlbnMuZm9jdXNSaW5nLmNvbnRyb2xPZmZzZXQgfSB9XX0+VOG6o2kgQ1NWPC9MaW5rPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RFeHBvcnQuam9iLnN0YXR1cyAhPT0gJ3N1Y2NlZWRlZCcgJiYgPEFsZXJ0IHNldmVyaXR5PXtsYXN0RXhwb3J0LmpvYi5zdGF0dXMgPT09ICdwYXJ0aWFsJyB8fCBsYXN0RXhwb3J0LmpvYi5zdGF0dXMgPT09ICdmYWlsZWQnID8gJ3dhcm5pbmcnIDogJ2luZm8nfT5U4buHcCBjaOG7iSDEkcaw4bujYyB04bqjaSBraGkgY8O0bmcgdmnhu4djIHjDoWMgbmjhuq1uIHN1Y2NlZWRlZC48L0FsZXJ0Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RFeHBvcnQuam9iLnN0YXR1cyA9PT0gJ3N1Y2NlZWRlZCcgJiYgbGFzdEV4cG9ydC5qb2IuZG93bmxvYWRVcmwgJiYgIWxhc3REb3dubG9hZCAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+VVJMIHThuqNpIGtow7RuZyBo4bujcCBs4buHIGhv4bq3YyBjaMawYSB0aHXhu5ljIEhUVFBTL25ndeG7k24gaGnhu4duIHThuqFpLjwvQWxlcnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQWN0aW9uR3JvdXA+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5LmRhdGEuZGF0YS53YXJuaW5ncy5tYXAoKHdhcm5pbmcsIGluZGV4KSA9PiA8QWxlcnQga2V5PXtgJHtpbmRleH0tJHt3YXJuaW5nfWB9IHNldmVyaXR5PVwiaW5mb1wiPnt3YXJuaW5nfTwvQWxlcnQ+KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+QVBJIGhp4buHbiBjaOG7iSB0cuG6oyBkYW5oIHPDoWNoIGxv4bqhaSBiw6FvIGPDoW8gdsOgIHRo4budaSDEkWnhu4NtIHNuYXBzaG90OyBi4buZIGzhu41jIG5nw6B5IMOhcCBk4bulbmcgY2hvIGzhu4duaCB4deG6pXQuIEtow7RuZyBjw7Mgc2VyaWVzIGhv4bq3YyB04buVbmcgc+G7kSBsaeG7h3UgxJHhu4MgZ2lhbyBkaeG7h24gdOG7sSBzdXkgcmEuPC9BbGVydD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD59XG4gICAgICAgICAgICAgICAgPC9RdWVyeVN0YXRlPlxuICAgICAgICAgICAgICAgIHtjYW5SZWFkSm9icyA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtqb2JzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICAgICAge2pvYnMuZGF0YSAmJiA8UGFuZWwgdGl0bGU9XCJDw7RuZyB2aeG7h2MgZ+G6p24gxJHDonlcIiBzdWJ0aXRsZT1cIlRy4bqhbmcgdGjDoWkgdsOgIHRp4bq/biDEkeG7mSBs4bqleSB04burIEFQSTsgdHJhbmcgaGnhu4duIHThuqFpIGPDsyB0aOG7gyBjaOG7qWEgbmhp4buBdSBsb+G6oWkgY8O0bmcgdmnhu4djLlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZSByb3dzPXtqb2JzLmRhdGEuZGF0YX0gcm93S2V5PXtqb2IgPT4gam9iLmlkfSBsYWJlbD1cIkPDtG5nIHZp4buHYyBn4bqnbiDEkcOieVwiIGVtcHR5PVwiQ2jGsGEgY8OzIGPDtG5nIHZp4buHYyB0cm9uZyB0cmFuZyBuw6B5LlwiIGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICdNw6MgY8O0bmcgdmnhu4djJywgcmVuZGVyOiBqb2IgPT4gPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2pvYi5pZH1gfT57am9iLmlkfTwvUm91dGVMaW5rPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAna2luZCcsIGxhYmVsOiAnTG/huqFpJywgcmVuZGVyOiBqb2IgPT4gPFN0YXR1cyB2YWx1ZT17am9iLmtpbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdzdGF0dXMnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGpvYiA9PiA8U3RhdHVzIHZhbHVlPXtqb2Iuc3RhdHVzfSAvPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncHJvZ3Jlc3MnLCBsYWJlbDogJ1Rp4bq/biDEkeG7mScsIGFsaWduOiAncmlnaHQnLCByZW5kZXI6IGpvYiA9PiBgJHtqb2IuY29tcGxldGVkfSAvICR7am9iLnRvdGFsID8/ICdDaMawYSBiaeG6v3QnfWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3VwZGF0ZWRBdCcsIGxhYmVsOiAnQ+G6rXAgbmjhuq10JywgcmVuZGVyOiBqb2IgPT4gZGF0ZVRpbWUoam9iLnVwZGF0ZWRBdCwgc2hvcC50aW1lem9uZSkgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17am9icy5kYXRhLnBhZ2V9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvUGFuZWw+fVxuICAgICAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT4gOiA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VmFpIHRyw7IgaGnhu4duIHThuqFpIGtow7RuZyBjw7Mgam9icy5yZWFkOyB0cuG6oW5nIHRow6FpIGPDtG5nIHZp4buHYyDEkcaw4bujYyDhuqluIHRoZW8gcXV54buBbi48L0FsZXJ0Pn1cbiAgICAgICAgICAgIDwvUGFnZVNlY3Rpb25zPlxuICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiUGjhuqFtIHZpIGThu68gbGnhu4d1XCIgc3VidGl0bGU9XCJDaOG7iSBuaOG7r25nIGfDrCBBUEkgY3VuZyBj4bqlcCBt4bubaSDEkcaw4bujYyB0csOsbmggYsOgeSBuaMawIHPhu5EgbGnhu4d1LlwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgc3g9e2xheW91dFN4LnJlcG9ydC5jb250ZXh0R2FwfT5cbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkLDoW8gY8OhbyBkw7JuZywgYmnhu4N1IMSR4buTIHbDoCB04buVbmcgaOG7o3AgdGhlbyBraG/huqNuZyBuZ8OgeSBjaMawYSBjw7MgdHJvbmcgZ2V0UmVwb3J0U3VtbWFyeS4gRnJvbnRlbmQga2jDtG5nIGPhu5luZyBk4buvIGxp4buHdSBwaMOibiB0cmFuZyDEkeG7gyB04bqhbyBLUEkgdGhheSB0aOG6vy48L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5UcuG6oW5nIHRow6FpIGV4cG9ydCDEkcaw4bujYyBs4bqleSByacOqbmcgdOG7qyBsaXN0Sm9iczsgVVJMIHThuqNpIGNo4buJIMSRxrDhu6NjIG3hu58gc2F1IGtoaSBBUEkgdHLhuqMgduG7gSBjw7RuZyB2aeG7h2MgaG/DoG4gdOG6pXQuPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9yZXBvcnRzL21hcmtldGluZ2B9PlhlbSB0aMO0bmcgdGluIG1hcmtldGluZzwvUm91dGVMaW5rPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICA8L1BhbmVsPlxuICAgICAgICA8L1NlY3Rpb25HcmlkPlxuICAgIDwvPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1hcmtldGluZ1BhZ2UoKSB7XG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBzZWFyY2ggPSBwYXJhbXMudG9TdHJpbmcoKTtcbiAgICBjb25zdCBmcm9tUGFyYW0gPSBwYXJhbXMuZ2V0KCdmcm9tRGF0ZScpIHx8ICcnO1xuICAgIGNvbnN0IHRvUGFyYW0gPSBwYXJhbXMuZ2V0KCd0b0RhdGUnKSB8fCAnJztcbiAgICBjb25zdCBidWNrZXRQYXJhbSA9IHBhcmFtcy5nZXQoJ2J1Y2tldCcpIHx8ICdkYXknO1xuICAgIGNvbnN0IGhhc0RhdGVGaWx0ZXIgPSBwYXJhbXMuaGFzKCdmcm9tRGF0ZScpIHx8IHBhcmFtcy5oYXMoJ3RvRGF0ZScpO1xuICAgIGNvbnN0IGFwcGxpZWRFcnJvciA9IG1hcmtldGluZ1JhbmdlRXJyb3IoZnJvbVBhcmFtLCB0b1BhcmFtLCBidWNrZXRQYXJhbSwgIWhhc0RhdGVGaWx0ZXIpO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYXBwbGllZEVycm9yID8gdW5kZWZpbmVkIDoge1xuICAgICAgICAuLi4ocGFyYW1zLmhhcygnZnJvbURhdGUnKSA/IHsgZnJvbURhdGU6IGZyb21QYXJhbSB9IDoge30pLFxuICAgICAgICAuLi4ocGFyYW1zLmhhcygndG9EYXRlJykgPyB7IHRvRGF0ZTogdG9QYXJhbSB9IDoge30pLFxuICAgICAgICAuLi4ocGFyYW1zLmhhcygnYnVja2V0JykgPyB7IGJ1Y2tldDogYnVja2V0UGFyYW0gYXMgTWFya2V0aW5nQnVja2V0IH0gOiB7fSksXG4gICAgfTtcbiAgICBjb25zdCBkYXRhID0gdXNlQXBpKCdnZXRNYXJrZXRpbmdTdW1tYXJ5JywgcXVlcnkgJiYgT2JqZWN0LmtleXMocXVlcnkpLmxlbmd0aCA/IHsgcXVlcnkgfSA6IHVuZGVmaW5lZCwgIWFwcGxpZWRFcnJvcik7XG4gICAgY29uc3QgbSA9IGRhdGEuZGF0YT8uZGF0YTtcbiAgICBjb25zdCBtYXJrZXRpbmdQZXJpb2QgPSBtPy5wZXJpb2Q7XG4gICAgY29uc3QgW2RyYWZ0LCBzZXREcmFmdF0gPSB1c2VTdGF0ZSh7IGZyb21EYXRlOiBmcm9tUGFyYW0sIHRvRGF0ZTogdG9QYXJhbSwgYnVja2V0OiBidWNrZXRQYXJhbSB9KTtcbiAgICBjb25zdCBkcmFmdFRvdWNoZWQgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IHBlbmRpbmdEZWZhdWx0U2VhcmNoID0gdXNlUmVmPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtzaG93RmlsdGVyRXJyb3IsIHNldFNob3dGaWx0ZXJFcnJvcl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgZnJvbVJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCB0b1JlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBidWNrZXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgZHJhZnRFcnJvciA9IG1hcmtldGluZ1JhbmdlRXJyb3IoZHJhZnQuZnJvbURhdGUsIGRyYWZ0LnRvRGF0ZSwgZHJhZnQuYnVja2V0LCBmYWxzZSk7XG4gICAgY29uc3QgdmlzaWJsZUZpbHRlckVycm9yID0gc2hvd0ZpbHRlckVycm9yID8gZHJhZnRFcnJvciA6IGFwcGxpZWRFcnJvcjtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGlzRGVmYXVsdE5vcm1hbGl6YXRpb24gPSBwZW5kaW5nRGVmYXVsdFNlYXJjaC5jdXJyZW50ID09PSBzZWFyY2g7XG4gICAgICAgIGlmIChpc0RlZmF1bHROb3JtYWxpemF0aW9uKSBwZW5kaW5nRGVmYXVsdFNlYXJjaC5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgLy8gSW5pdGlhbCBVUkwgbm9ybWFsaXphdGlvbiBtdXN0IHByZXNlcnZlIGVkaXRzIG1hZGUgYmVmb3JlIHRoZSBuYXZpZ2F0aW9uIGZpbmlzaGVzLlxuICAgICAgICBpZiAoaXNEZWZhdWx0Tm9ybWFsaXphdGlvbiAmJiBkcmFmdFRvdWNoZWQuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICBkcmFmdFRvdWNoZWQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBjdXJyZW50ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhzZWFyY2gpO1xuICAgICAgICBpZiAoIWN1cnJlbnQuaGFzKCdmcm9tRGF0ZScpICYmICFjdXJyZW50LmhhcygndG9EYXRlJykpIHJldHVybjtcbiAgICAgICAgc2V0RHJhZnQoeyBmcm9tRGF0ZTogY3VycmVudC5nZXQoJ2Zyb21EYXRlJykgfHwgJycsIHRvRGF0ZTogY3VycmVudC5nZXQoJ3RvRGF0ZScpIHx8ICcnLCBidWNrZXQ6IGN1cnJlbnQuZ2V0KCdidWNrZXQnKSB8fCAnZGF5JyB9KTtcbiAgICAgICAgc2V0U2hvd0ZpbHRlckVycm9yKGZhbHNlKTtcbiAgICB9LCBbc2VhcmNoXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICAvLyBVUkwgbmF2aWdhdGlvbiBvd25zIHRoZSBkcmFmdDsgQVBJIGRlZmF1bHRzIG9ubHkgaW5pdGlhbGl6ZSBhbiB1bnRvdWNoZWQgaW1wbGljaXQgZmlsdGVyLlxuICAgICAgICBpZiAobWFya2V0aW5nUGVyaW9kICYmICFoYXNEYXRlRmlsdGVyICYmICFkcmFmdFRvdWNoZWQuY3VycmVudCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyBmcm9tRGF0ZTogbWFya2V0aW5nUGVyaW9kLmZyb21EYXRlLCB0b0RhdGU6IG1hcmtldGluZ1BlcmlvZC50b0RhdGUsIGJ1Y2tldDogbWFya2V0aW5nUGVyaW9kLmJ1Y2tldCB9KTtcbiAgICAgICAgICAgIGlmIChuZXh0LnRvU3RyaW5nKCkgIT09IHNlYXJjaCkge1xuICAgICAgICAgICAgICAgIHBlbmRpbmdEZWZhdWx0U2VhcmNoLmN1cnJlbnQgPSBuZXh0LnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgc2V0UGFyYW1zKG5leHQsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFttYXJrZXRpbmdQZXJpb2QsIGhhc0RhdGVGaWx0ZXIsIHNlYXJjaCwgc2V0UGFyYW1zXSk7XG5cbiAgICBjb25zdCBhcHBseUZpbHRlciA9IChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0U2hvd0ZpbHRlckVycm9yKHRydWUpO1xuICAgICAgICBpZiAoZHJhZnRFcnJvcikge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZHJhZnRFcnJvci5maWVsZCA9PT0gJ2Zyb21EYXRlJyA/IGZyb21SZWYuY3VycmVudCA6IGRyYWZ0RXJyb3IuZmllbGQgPT09ICd0b0RhdGUnID8gdG9SZWYuY3VycmVudCA6IGJ1Y2tldFJlZi5jdXJyZW50O1xuICAgICAgICAgICAgdGFyZ2V0Py5mb2N1cygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHsgZnJvbURhdGU6IGRyYWZ0LmZyb21EYXRlLCB0b0RhdGU6IGRyYWZ0LnRvRGF0ZSwgYnVja2V0OiBkcmFmdC5idWNrZXQgfSk7XG4gICAgICAgIHNldFNob3dGaWx0ZXJFcnJvcihmYWxzZSk7XG4gICAgICAgIGRyYWZ0VG91Y2hlZC5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHBlbmRpbmdEZWZhdWx0U2VhcmNoLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRQYXJhbXMobmV4dCk7XG4gICAgfTtcblxuICAgIHJldHVybiA8PlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIlRow7RuZyB0aW4gY2hvIG1hcmtldGluZ1wiIHN1YnRpdGxlPVwixJDhu4EgeHXhuqV0IGNo4buJIMSR4buNYzsgdHJhbmcga2jDtG5nIHThu7EgxJHEg25nIG7hu5lpIGR1bmcgaG/hurdjIHRoYXkgxJHhu5VpIG5nw6JuIHPDoWNoLlwiIC8+XG4gICAgICAgIHtfX01PQ0tfXyAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCIgc3g9e2xheW91dFN4Lm5vdGljZS5hZnRlckdhcH0+U+G7kSBsaeG7h3UgbeG6q3UgZG8gQVBJIG3DtCBwaOG7j25nIHThu5VuZyBo4bujcDsgY2jGsGEga+G6v3QgbuG7kWkgdMOgaSBraG/huqNuIHF14bqjbmcgY8OhbyBob+G6t2Mgbmd14buTbiBwaMOibiBi4buVIHRo4bqtdC48L0FsZXJ0Pn1cbiAgICAgICAgPFBhbmVsIHRpdGxlPVwiS2hv4bqjbmcgdGjhu51pIGdpYW4gYsOhbyBjw6FvXCIgc3VidGl0bGU9e2BOZ8OgeSDEkcaw4bujYyB0w61uaCB0aGVvIGzhu4tjaCAke3Nob3AudGltZXpvbmV9IGPhu6dhIGPhu61hIGjDoG5nLmB9IGJvZHlNb2RlPVwiaW5zZXRcIiBhZnRlckdhcD1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgIDxGb3JtRmllbGRzIGNvbXBvbmVudD1cImZvcm1cIiBvblN1Ym1pdD17YXBwbHlGaWx0ZXJ9IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXJhbmdlLWZvcm1cIj5cbiAgICAgICAgICAgICAgICA8U3RhY2sgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgbWQ6ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgbWQ6ICdmbGV4LWVuZCcgfX0gc3g9e2xheW91dFN4LnRvb2xiYXIuY29udHJvbEdhcH0+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgaW5wdXRSZWY9e2Zyb21SZWZ9IHR5cGU9XCJkYXRlXCIgbGFiZWw9XCJU4burIG5nw6B5XCIgdmFsdWU9e2RyYWZ0LmZyb21EYXRlfSBvbkNoYW5nZT17ZXZlbnQgPT4geyBkcmFmdFRvdWNoZWQuY3VycmVudCA9IHRydWU7IHNldERyYWZ0KHZhbHVlID0+ICh7IC4uLnZhbHVlLCBmcm9tRGF0ZTogZXZlbnQudGFyZ2V0LnZhbHVlIH0pKTsgfX0gc2xvdFByb3BzPXt7IGlucHV0TGFiZWw6IHsgc2hyaW5rOiB0cnVlIH0gfX0gZXJyb3I9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICdmcm9tRGF0ZSd9IGhlbHBlclRleHQ9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICdmcm9tRGF0ZScgPyB2aXNpYmxlRmlsdGVyRXJyb3IubWVzc2FnZSA6ICdOZ8OgeSBi4bqvdCDEkeG6p3UsIHTDrW5oIGPhuqMgbmfDoHkgxJHDoyBjaOG7jW4uJ30gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBpbnB1dFJlZj17dG9SZWZ9IHR5cGU9XCJkYXRlXCIgbGFiZWw9XCLEkOG6v24gbmfDoHlcIiB2YWx1ZT17ZHJhZnQudG9EYXRlfSBvbkNoYW5nZT17ZXZlbnQgPT4geyBkcmFmdFRvdWNoZWQuY3VycmVudCA9IHRydWU7IHNldERyYWZ0KHZhbHVlID0+ICh7IC4uLnZhbHVlLCB0b0RhdGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSk7IH19IHNsb3RQcm9wcz17eyBpbnB1dExhYmVsOiB7IHNocmluazogdHJ1ZSB9IH19IGVycm9yPXt2aXNpYmxlRmlsdGVyRXJyb3I/LmZpZWxkID09PSAndG9EYXRlJ30gaGVscGVyVGV4dD17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ3RvRGF0ZScgPyB2aXNpYmxlRmlsdGVyRXJyb3IubWVzc2FnZSA6ICdU4buRaSDEkWEgMzY2IG5nw6B5LCB0w61uaCBj4bqjIGhhaSDEkeG6p3UuJ30gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBpbnB1dFJlZj17YnVja2V0UmVmfSBzZWxlY3QgbGFiZWw9XCJH4buZcCB0aGVvXCIgdmFsdWU9e2RyYWZ0LmJ1Y2tldH0gb25DaGFuZ2U9e2V2ZW50ID0+IHsgZHJhZnRUb3VjaGVkLmN1cnJlbnQgPSB0cnVlOyBzZXREcmFmdCh2YWx1ZSA9PiAoeyAuLi52YWx1ZSwgYnVja2V0OiBldmVudC50YXJnZXQudmFsdWUgfSkpOyB9fSBlcnJvcj17dmlzaWJsZUZpbHRlckVycm9yPy5maWVsZCA9PT0gJ2J1Y2tldCd9IGhlbHBlclRleHQ9e3Zpc2libGVGaWx0ZXJFcnJvcj8uZmllbGQgPT09ICdidWNrZXQnID8gdmlzaWJsZUZpbHRlckVycm9yLm1lc3NhZ2UgOiAnQ2jhu41uIG5nw6B5LCB0deG6p24gaG/hurdjIHRow6FuZy4nfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cImRheVwiPk5nw6B5PC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJ3ZWVrXCI+VHXhuqduPC9NZW51SXRlbT48TWVudUl0ZW0gdmFsdWU9XCJtb250aFwiPlRow6FuZzwvTWVudUl0ZW0+XG4gICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwiY29udGFpbmVkXCI+w4FwIGThu6VuZzwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAge3Nob3dGaWx0ZXJFcnJvciAmJiBkcmFmdEVycm9yICYmIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2RyYWZ0RXJyb3IubWVzc2FnZX08L0FsZXJ0Pn1cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9QYW5lbD5cbiAgICAgICAge2FwcGxpZWRFcnJvciA/IDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+PHN0cm9uZz5C4buZIGzhu41jIHRyw6puIMSRxrDhu51uZyBk4bqrbiBraMO0bmcgaOG7o3AgbOG7hy48L3N0cm9uZz4gSMOjeSBz4butYSB0csaw4budbmcgxJHGsOG7o2MgxJHDoW5oIGThuqV1IHRyxrDhu5tjIGtoaSDDoXAgZOG7pW5nLjwvQWxlcnQ+IDogPFF1ZXJ5U3RhdGUgcXVlcnk9e2RhdGF9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPnttICYmIDw+XG4gICAgICAgICAgICA8U3RhdHM+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCLEkMahbiBjw7Mgbmd14buTbiB4w6FjIMSR4buLbmhcIiB2YWx1ZT17bS5rbm93bkF0dHJpYnV0ZWRPcmRlcnN9IG5vdGU9XCLEkMaw4bujYyBBUEkgdOG7lW5nIGjhu6NwIHRyb25nIGvhu7NcIiAvPlxuICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwixJDGoW4gY2jGsGEgcsO1IG5ndeG7k25cIiB2YWx1ZT17bS51bmtub3duQXR0cmlidXRpb25PcmRlcnN9IG5vdGU9XCJHaeG7ryByacOqbmcsIGtow7RuZyB04buxIGfDoW4gbmd14buTblwiIC8+XG4gICAgICAgICAgICAgICAgPFN0YXQgdGl0bGU9XCJDaGkgcXXhuqNuZyBjw6FvIHRo4buxYyB04bq/XCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17bS5hY3R1YWxTcGVuZH0gLz59IG5vdGU9e20uYWN0dWFsU3BlbmQgPyAnQVBJIGN1bmcgY+G6pXAgc+G7kSB0aOG7sWMgdOG6vycgOiAnS+G7syBuw6B5IGNoxrBhIGPDsyBz4buRIHRo4buxYyB04bq/IHThu6sgQVBJJ30gLz5cbiAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkNoaSBxdeG6o25nIGPDoW8gxrDhu5tjIHTDrW5oXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17bS5lc3RpbWF0ZWRTcGVuZH0gLz59IG5vdGU9XCLGr+G7m2MgdMOtbmgga2jDtG5nIHBo4bqjaSBz4buRIGdoaSBz4buVXCIgLz5cbiAgICAgICAgICAgIDwvU3RhdHM+XG4gICAgICAgICAgICA8U3RhY2sgZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctYXMtb2ZcIiBzeD17W2xheW91dFN4LnJlcG9ydC5jb250ZXh0R2FwLCBsYXlvdXRTeC5wYWdlLnNlY3Rpb25BZnRlcl19PlxuICAgICAgICAgICAgICAgIHttLnBlcmlvZCAmJiA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5L4buzIHtmb3JtYXREYXRlT25seShtLnBlcmlvZC5mcm9tRGF0ZSl9IOKAkyB7Zm9ybWF0RGF0ZU9ubHkobS5wZXJpb2QudG9EYXRlKX0gwrcgZ+G7mXAgdGhlbyB7bS5wZXJpb2QuYnVja2V0ID09PSAnZGF5JyA/ICduZ8OgeScgOiBtLnBlcmlvZC5idWNrZXQgPT09ICd3ZWVrJyA/ICd0deG6p24nIDogJ3Row6FuZyd9PC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5D4bqtcCBuaOG6rXQge2RhdGVUaW1lKG0uYXNPZiwgbS5wZXJpb2Q/LnRpbWV6b25lIHx8IHNob3AudGltZXpvbmUpfSDCtyB7c2hvcC5uYW1lfSDCtyBtw7ppIGdp4budIHttLnBlcmlvZD8udGltZXpvbmUgfHwgc2hvcC50aW1lem9uZX08L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICA8L1N0YWNrPlxuICAgICAgICAgICAgPFNlY3Rpb25HcmlkIGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXNlY3Rpb25zLWdyaWRcIiBjb2x1bW5zPXt7IHhzOiAnMWZyJywgbGc6ICcxZnIgMWZyJyB9fT5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCLEkMahbiB0aGVvIHRo4budaSBnaWFuXCIgc3VidGl0bGU9XCJT4buRIMSRxqFuIGPDsyBuZ3Xhu5NuIHjDoWMgxJHhu4tuaCB2w6AgY2jGsGEgcsO1IG5ndeG7k24gZG8gQVBJIHThu5VuZyBo4bujcC5cIj5cbiAgICAgICAgICAgICAgICAgICAgPEJveCByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17YFPhu5EgxJHGoW4gdGhlbyAke20ucGVyaW9kPy5idWNrZXQgfHwgJ2vhu7MnfSB0cm9uZyBraG/huqNuZyDEkcOjIGNo4buNbmB9IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXRyZW5kLWNoYXJ0XCIgc3g9e1t7IGhlaWdodDogMjgwIH0sIGxheW91dFN4LnJlcG9ydC5jaGFydFZpZXdwb3J0SW5zZXRdfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttLnRyZW5kPy5sZW5ndGggPyA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+PEJhckNoYXJ0IGRhdGE9e20udHJlbmR9IGFjY2Vzc2liaWxpdHlMYXllcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2U9e2NvbG9ycy5ib3JkZXJEZWNvcmF0aXZlfSB2ZXJ0aWNhbD17ZmFsc2V9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJmcm9tRGF0ZVwiIHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IGludGVydmFsPXtNYXRoLm1heCgwLCBNYXRoLmNlaWwobS50cmVuZC5sZW5ndGggLyA3KSAtIDEpfSB0aWNrRm9ybWF0dGVyPXt2YWx1ZSA9PiBmb3JtYXREYXRlT25seShTdHJpbmcodmFsdWUpKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WUF4aXMgYWxsb3dEZWNpbWFscz17ZmFsc2V9IHN0cm9rZT17Y29sb3JzLnRleHRTZWNvbmRhcnl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgbGFiZWxGb3JtYXR0ZXI9e3ZhbHVlID0+IGZvcm1hdERhdGVPbmx5KFN0cmluZyh2YWx1ZSkpfSBjb250ZW50U3R5bGU9e3sgYmFja2dyb3VuZDogY29sb3JzLnJhaXNlZCwgY29sb3I6IGNvbG9ycy50ZXh0UHJpbWFyeSwgYm9yZGVyQ29sb3I6IGNvbG9ycy5ib3JkZXJEZWNvcmF0aXZlIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImtub3duQXR0cmlidXRlZE9yZGVyc1wiIG5hbWU9XCJDw7Mgbmd14buTbiB4w6FjIMSR4buLbmhcIiBmaWxsPXtjb2xvcnMuYWNjZW50fSByYWRpdXM9e1szLCAzLCAwLCAwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyIGRhdGFLZXk9XCJ1bmtub3duQXR0cmlidXRpb25PcmRlcnNcIiBuYW1lPVwiQ2jGsGEgcsO1IG5ndeG7k25cIiBmaWxsPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gcmFkaXVzPXtbMywgMywgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhckNoYXJ0PjwvUmVzcG9uc2l2ZUNvbnRhaW5lcj4gOiA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e2xheW91dFN4LnJlcG9ydC5lbXB0eVN0YXRlSW5zZXR9PkFQSSBjaMawYSBjw7MgYnVja2V0IGThu68gbGnhu4d1IHRyb25nIGvhu7MgxJHDoyBjaOG7jW4uPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJU4buVbmcgaOG7o3AgbWFya2V0aW5nIHRoZW8ga+G7s1wiIHJvd3M9e20udHJlbmQgfHwgW119IHJvd0tleT17cG9pbnQgPT4gcG9pbnQuZnJvbURhdGV9IGVtcHR5PVwiQ2jGsGEgY8OzIGThu68gbGnhu4d1IHRoZW8ga+G7syB0cm9uZyBraG/huqNuZyBuw6B5LlwiIGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncmFuZ2UnLCBsYWJlbDogJ0tob+G6o25nIG5nw6B5JywgcmVuZGVyOiBwb2ludCA9PiBgJHtmb3JtYXREYXRlT25seShwb2ludC5mcm9tRGF0ZSl9IOKAkyAke2Zvcm1hdERhdGVPbmx5KHBvaW50LnRvRGF0ZSl9YCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdrbm93bicsIGxhYmVsOiAnQ8OzIG5ndeG7k24nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiBwb2ludC5rbm93bkF0dHJpYnV0ZWRPcmRlcnMgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAndW5rbm93bicsIGxhYmVsOiAnQ2jGsGEgcsO1IG5ndeG7k24nLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiBwb2ludCA9PiBwb2ludC51bmtub3duQXR0cmlidXRpb25PcmRlcnMgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXN0aW1hdGVkJywgbGFiZWw6ICdDaGkgxrDhu5tjIHTDrW5oJywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gPEFtb3VudCB2YWx1ZT17cG9pbnQuZXN0aW1hdGVkU3BlbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdHVhbCcsIGxhYmVsOiAnQ2hpIHRo4buxYyB04bq/JywgYWxpZ246ICdyaWdodCcsIHJlbmRlcjogcG9pbnQgPT4gPEFtb3VudCB2YWx1ZT17cG9pbnQuYWN0dWFsU3BlbmR9IC8+IH0sXG4gICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJDw6J1IGjhu49pIGtow6FjaCB0aMaw4budbmcgaOG7j2lcIiBzdWJ0aXRsZT1cIkPDoWMgbeG7pWMgZG8gQVBJIHThu5VuZyBo4bujcCBjdW5nIGPhuqVwLlwiPlxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRhdGEtdGVzdGlkPVwibWFya2V0aW5nLXF1ZXN0aW9uLXN1cmZhY2VcIiBzeD17bGF5b3V0U3gucmVwb3J0Lmxpc3RTdXJmYWNlSW5zZXR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YWNrIGNvbXBvbmVudD1cInVsXCIgZGF0YS10ZXN0aWQ9XCJtYXJrZXRpbmctdG9wLXF1ZXN0aW9uc1wiIHN4PXtbeyBtOiAwLCBwOiAwIH0sIGxheW91dFN4LnJlcG9ydC5saXN0TWFya2VySW5zZXQsIGxheW91dFN4LnJlcG9ydC5saXN0SXRlbUdhcF19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttLnRvcFF1ZXN0aW9ucy5sZW5ndGggPyBtLnRvcFF1ZXN0aW9ucy5tYXAoKHF1ZXN0aW9uLCBpbmRleCkgPT4gPFR5cG9ncmFwaHkgY29tcG9uZW50PVwibGlcIiBrZXk9e2Ake2luZGV4fS0ke3F1ZXN0aW9ufWB9PntxdWVzdGlvbn08L1R5cG9ncmFwaHk+KSA6IDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImxpXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPkNoxrBhIGPDsyB0aOG7kW5nIGvDqiBjw6J1IGjhu49pIHRyb25nIGvhu7MgxJHDoyBjaOG7jW4uPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU3RhY2s+XG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDwvUGFuZWw+XG4gICAgICAgICAgICAgICAgPFBhbmVsIHRpdGxlPVwiTMO9IGRvIGtow7RuZyBjaOG7kXQgxJHGoW5cIiBzdWJ0aXRsZT1cIkJp4buDdSDEkeG7kyB2w6AgYuG6o25nIGTDuW5nIGPDuW5nIG3hu5l0IHBheWxvYWQgQVBJLlwiPlxuICAgICAgICAgICAgICAgICAgICA8Qm94IHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPXtgQmnhu4N1IMSR4buTIGzDvSBkbyBraMO0bmcgY2jhu5F0IMSRxqFuLCAke20ubG9zdFNhbGVSZWFzb25zLmxlbmd0aH0gbmjDs21gfSBkYXRhLXRlc3RpZD1cIm1hcmtldGluZy1sb3NzLWNoYXJ0XCIgc3g9e1t7IGhlaWdodDogMjYwIH0sIGxheW91dFN4LnJlcG9ydC5jaGFydFZpZXdwb3J0SW5zZXRdfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttLmxvc3RTYWxlUmVhc29ucy5sZW5ndGggPyA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+PEJhckNoYXJ0IGRhdGE9e20ubG9zdFNhbGVSZWFzb25zfSBhY2Nlc3NpYmlsaXR5TGF5ZXI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlPXtjb2xvcnMuYm9yZGVyRGVjb3JhdGl2ZX0gdmVydGljYWw9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwicmVhc29uXCIgc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gaW50ZXJ2YWw9ezB9IGhlaWdodD17NjR9IHRpY2s9ezxNYXJrZXRpbmdSZWFzb25UaWNrIC8+fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBhbGxvd0RlY2ltYWxzPXtmYWxzZX0gc3Ryb2tlPXtjb2xvcnMudGV4dFNlY29uZGFyeX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCBjb250ZW50U3R5bGU9e3sgYmFja2dyb3VuZDogY29sb3JzLnJhaXNlZCwgY29sb3I6IGNvbG9ycy50ZXh0UHJpbWFyeSwgYm9yZGVyQ29sb3I6IGNvbG9ycy5ib3JkZXJEZWNvcmF0aXZlIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiY291bnRcIiBuYW1lPVwiU+G7kSB0csaw4budbmcgaOG7o3BcIiBmaWxsPXtjb2xvcnMuYWNjZW50fSByYWRpdXM9e1s0LCA0LCAwLCAwXX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+PC9SZXNwb25zaXZlQ29udGFpbmVyPiA6IDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBzeD17bGF5b3V0U3gucmVwb3J0LmVtcHR5U3RhdGVJbnNldH0+Q2jGsGEgY8OzIGzDvSBkbyBt4bqldCDEkcahbiB0cm9uZyBr4buzIG7DoHkuPC9UeXBvZ3JhcGh5Pn1cbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgcm93cz17bS5sb3N0U2FsZVJlYXNvbnN9IHJvd0tleT17cmVhc29uID0+IHJlYXNvbi5yZWFzb259IGxhYmVsPVwiTMO9IGRvIGtow7RuZyBjaOG7kXQgxJHGoW5cIiBlbXB0eT1cIkNoxrBhIGPDsyBsw70gZG8gbeG6pXQgxJHGoW4gdHJvbmcga+G7syDEkcOjIGNo4buNbi5cIiBjb2x1bW5zPXtbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3JlYXNvbicsIGxhYmVsOiAnTMO9IGRvJywgcmVuZGVyOiByZWFzb24gPT4gcmVhc29uLnJlYXNvbiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjb3VudCcsIGxhYmVsOiAnU+G7kSB0csaw4budbmcgaOG7o3AnLCBhbGlnbjogJ3JpZ2h0JywgcmVuZGVyOiByZWFzb24gPT4gcmVhc29uLmNvdW50IH0sXG4gICAgICAgICAgICAgICAgICAgIF19IC8+XG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cbiAgICAgICAgICAgIDwvU2VjdGlvbkdyaWQ+XG4gICAgICAgICAgICA8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCIgc3g9e2xheW91dFN4LnBhZ2Uuc2VjdGlvbkJlZm9yZX0+S2jDtG5nIHThu7EgZ8OhbiBuZ3Xhu5NuIGNobyDEkcahbiB0aGnhur91IGThu68gbGnhu4d1LCBraMO0bmcgZ2hpIGNoaSDGsOG7m2MgdMOtbmggdGjDoG5oIGNoaSB0aOG7sWMgdOG6vyB2w6Aga2jDtG5nIHThu7EgxJHEg25nIG7hu5lpIGR1bmcgaG/hurdjIHTEg25nIG5nw6JuIHPDoWNoLjwvQWxlcnQ+XG4gICAgICAgIDwvPn08L1F1ZXJ5U3RhdGU+fVxuICAgIDwvPjtcbn1cblxuZnVuY3Rpb24gbWFya2V0aW5nUmFuZ2VFcnJvcihmcm9tRGF0ZTogc3RyaW5nLCB0b0RhdGU6IHN0cmluZywgYnVja2V0OiBzdHJpbmcsIGFsbG93RGVmYXVsdDogYm9vbGVhbik6IHsgZmllbGQ6ICdmcm9tRGF0ZScgfCAndG9EYXRlJyB8ICdidWNrZXQnOyBtZXNzYWdlOiBzdHJpbmcgfSB8IG51bGwge1xuICAgIGlmICghWydkYXknLCAnd2VlaycsICdtb250aCddLmluY2x1ZGVzKGJ1Y2tldCkpIHJldHVybiB7IGZpZWxkOiAnYnVja2V0JywgbWVzc2FnZTogJ0No4buNbiBuaMOzbSBuZ8OgeSwgdHXhuqduIGhv4bq3YyB0aMOhbmcuJyB9O1xuICAgIGlmIChhbGxvd0RlZmF1bHQgJiYgIWZyb21EYXRlICYmICF0b0RhdGUpIHJldHVybiBudWxsO1xuICAgIGlmICghaXNWYWxpZERhdGVPbmx5KGZyb21EYXRlKSkgcmV0dXJuIHsgZmllbGQ6ICdmcm9tRGF0ZScsIG1lc3NhZ2U6ICdOaOG6rXAgbmfDoHkgYuG6r3QgxJHhuqd1IGjhu6NwIGzhu4cuJyB9O1xuICAgIGlmICghaXNWYWxpZERhdGVPbmx5KHRvRGF0ZSkpIHJldHVybiB7IGZpZWxkOiAndG9EYXRlJywgbWVzc2FnZTogJ05o4bqtcCBuZ8OgeSBr4bq/dCB0aMO6YyBo4bujcCBs4buHLicgfTtcbiAgICBpZiAoZnJvbURhdGUgPiB0b0RhdGUpIHJldHVybiB7IGZpZWxkOiAnZnJvbURhdGUnLCBtZXNzYWdlOiAnTmfDoHkgYuG6r3QgxJHhuqd1IHBo4bqjaSB0csaw4bubYyBob+G6t2MgYuG6sW5nIG5nw6B5IGvhur90IHRow7pjLicgfTtcbiAgICBjb25zdCBkYXlzID0gTWF0aC5mbG9vcigoRGF0ZS5wYXJzZShgJHt0b0RhdGV9VDAwOjAwOjAwLjAwMFpgKSAtIERhdGUucGFyc2UoYCR7ZnJvbURhdGV9VDAwOjAwOjAwLjAwMFpgKSkgLyAoMjQgKiA2MCAqIDYwICogMTAwMCkpICsgMTtcbiAgICBpZiAoZGF5cyA+IDM2NikgcmV0dXJuIHsgZmllbGQ6ICd0b0RhdGUnLCBtZXNzYWdlOiAnS2hv4bqjbmcgYsOhbyBjw6FvIGtow7RuZyDEkcaw4bujYyB2xrDhu6N0IHF1w6EgMzY2IG5nw6B5LicgfTtcbiAgICByZXR1cm4gbnVsbDtcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVubmVyL3dvcmsvQm90LUFJLUJhbi1oYW5nLUZCL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL3JlcG9ydHMvaW5kZXgudHN4In0=