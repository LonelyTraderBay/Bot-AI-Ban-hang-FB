import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react_jsx-dev-runtime.js?v=585edd0d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$();
import { visualSx } from "/src/shared/ui/visual.ts";
import { JournalEditor } from "/src/modules/finance/journal-editor.tsx";
import { FinanceEntryEditor, financeEntryClasses as classes } from "/src/modules/finance/entry-editor.tsx";
import { StatementDialog } from "/src/modules/finance/statement-import.tsx";
import { BookProvenance, CreatePeriodDialog } from "/src/modules/finance/management.tsx";
export { OpeningBalancesPage, LedgerPage, TrialBalancePage, BalanceSheetPage } from "/src/modules/finance/management.tsx";
import { useReportRange, ReportRangeFields } from "/src/modules/finance/report-range.tsx";
import { label as businessLabel } from "/src/shared/model/labels.ts";
export { AccountsPage } from "/src/modules/finance/accounts.tsx";
import { ActionGroup, FormFields, PageSections, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport13_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react.js?v=585edd0d"; const useState = __vite__cjsImport13_react["useState"];
import { useSearchParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react-router-dom.js?v=585edd0d";
import { Alert, Box, Button, MenuItem, Stack, Tab, Tabs, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/@mui_material.js?v=585edd0d";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { codePointLength, dateTime, formatMoney, formatDateOnly } from "/src/shared/model/format.ts";
import { Amount, ConfirmDialog, DataTable, DetailLine, EditDialog, ErrorNotice, LookupLoadMore, MutationButton, PageHeader, Pager, Panel, QueryState, RouteLink, Stat, Stats, Status, Toolbar } from "/src/shared/ui/components.tsx";
import { explainProfitLoss, profitLossQuestions } from "/src/modules/finance/report-explanations.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
function decimalUnits(value) {
  if (!/^\d+(\.\d{1,4})?$/.test(value)) return null;
  const [whole = "", fraction = ""] = value.split(".");
  if (!whole) return null;
  return BigInt(whole) * 10000n + BigInt(fraction.padEnd(4, "0"));
}
function hasOutstandingBalance(value) {
  const amount = decimalUnits(value);
  return amount !== null && amount > 0n;
}
export function CashflowPage() {
  _s();
  const { shop } = useScope();
  const report = useReportRange(shop.timezone);
  const data = useApi("getCashflow", { query: report.query }, report.valid);
  const c = data.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Dòng tiền", subtitle: "Tiền thực thu và thực chi, tách biệt doanh thu và lợi nhuận.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/finance/entries`, children: "Sổ thu chi" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 123
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: report.range, timezone: shop.timezone, setFrom: report.setFrom, setTo: report.setTo }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 197
    }, this),
    report.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: c && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tiền đã thu", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: c.receipts }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 424
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 391
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Tiền đã chi", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: c.disbursements }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 495
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 462
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Biến động tiền thuần", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: c.netCashMovement }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 580
        }, this), accent: true, note: "Không phải số dư tài khoản" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 538
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Múi giờ báo cáo", value: c.timezone }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 666
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 57,
        columnNumber: 384
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Kỳ báo cáo", bodyMode: "inset", children: [
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Từ", children: dateTime(c.from, shop.timezone) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 768
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đến (không gồm)", children: dateTime(c.to, shop.timezone) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 837
        }, this),
        /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dữ liệu tại", children: dateTime(c.asOf, shop.timezone) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 917
        }, this),
        c.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.surface.sectionBefore, children: w }, w, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 57,
          columnNumber: 1018
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 57,
        columnNumber: 725
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 382
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 326
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 57,
      columnNumber: 1126
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 57,
    columnNumber: 10
  }, this);
}
_s(CashflowPage, "kMF4bss271epB6ChkSLKbVGqlGE=", false, function() {
  return [useScope, useReportRange, useApi];
});
_c = CashflowPage;
export function EntriesPage() {
  _s2();
  const { shop } = useScope();
  const list = useApi("listFinanceEntries", { query: useListQuery("listFinanceEntries") });
  const post = useCommand("postFinanceEntry", ["listFinanceEntries", "getCashflow", "getProfitLoss", "listJournals"]);
  const reverse = useCommand("reverseFinanceEntry", ["listFinanceEntries", "getCashflow", "getProfitLoss", "listJournals"]);
  const [entryId, setEntryId] = useState(null);
  const detail = useApi("getFinanceEntry", { path: { entryId: entryId || "" } }, Boolean(entryId));
  const selectedEntry = detail.data?.data;
  const [editing, setEditing] = useState(null), [open, setOpen] = useState(false), [selected, setSelected] = useState(null);
  const [entrySaved, setEntrySaved] = useState(false);
  const begin = (entry) => {
    setEditing(entry);
    setOpen(true);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    entrySaved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã lưu phiếu nháp." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 73,
      columnNumber: 27
    }, this),
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Sổ thu chi", subtitle: "Phiếu nháp → kiểm tra → ghi sổ. Phiếu đã ghi chỉ điều chỉnh có lịch sử.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", variant: "contained", onClick: () => begin(null), children: "Tạo phiếu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 73,
      columnNumber: 217
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 73,
      columnNumber: 94
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listFinanceEntries" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 73,
        columnNumber: 344
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Chứng từ thu chi", rows: list.data.data, rowKey: (r) => r.id, columns: [
          { key: "id", label: "Chứng từ", render: (r) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(r.id), children: r.id }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 74,
            columnNumber: 58
          }, this) },
          { key: "date", label: "Ngày", render: (r) => dateTime(r.occurredAt, shop.timezone) },
          { key: "type", label: "Phân loại", render: (r) => classes[r.classification] },
          { key: "amount", label: "Số tiền", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.amount }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 74,
            columnNumber: 333
          }, this) },
          { key: "note", label: "Diễn giải", render: (r) => r.description },
          { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { value: r.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 74,
            columnNumber: 483
          }, this) },
          {
            key: "action",
            label: "Thao tác",
            render: (r) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(r.id), children: "Chi tiết" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 76,
              columnNumber: 62
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 73,
          columnNumber: 452
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 78,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 73,
        columnNumber: 450
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 73,
        columnNumber: 386
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 73,
      columnNumber: 337
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: Boolean(entryId), title: selectedEntry ? `Chứng từ ${selectedEntry.id}` : "Đang tải chứng từ", onClose: () => setEntryId(null), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEntryId(null), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 79,
      columnNumber: 157
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: selectedEntry && /* @__PURE__ */ jsxDEV(Stack, { sx: layoutSx.query.stateGap, children: [
      /* @__PURE__ */ jsxDEV(Status, { value: selectedEntry.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 294
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Loại", children: selectedEntry.kind === "receipt" ? "Thu tiền" : "Chi tiền" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 333
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Phân loại", children: classes[selectedEntry.classification] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 431
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Số tiền", children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: selectedEntry.amount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 541
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 513
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Ngày ghi nhận", children: dateTime(selectedEntry.occurredAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 598
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Nguồn", children: selectedEntry.sourceRef ? `${selectedEntry.sourceRef.type} / ${selectedEntry.sourceRef.id}` : "Không có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 696
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Diễn giải", children: selectedEntry.description }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 841
      }, this),
      selectedEntry.status === "draft" && /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => begin(selectedEntry), children: "Sửa nháp" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 79,
          columnNumber: 977
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ entry: selectedEntry, action: "post" }), children: "Ghi sổ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 79,
          columnNumber: 1081
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 948
      }, this),
      selectedEntry.status === "posted" && !["bank_allocation", "cod_settlement", "order", "order_refund"].includes(selectedEntry.sourceRef?.type || "") && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ entry: selectedEntry, action: "reverse" }), children: "Đảo phiếu" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 79,
        columnNumber: 1382
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 79,
      columnNumber: 258
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 79,
      columnNumber: 213
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 79,
      columnNumber: 2
    }, this),
    open && /* @__PURE__ */ jsxDEV(FinanceEntryEditor, { initial: editing, onClose: () => setOpen(false), onSaved: () => setEntrySaved(true) }, editing?.id || "new", false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 80,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: selected?.action === "post" ? "Ghi sổ phiếu đã kiểm" : "Đảo phiếu đã ghi", confirmLabel: selected?.action === "post" ? "Ghi sổ phiếu" : "Đảo phiếu", description: `${selected?.entry.id || ""} · ${formatMoney(selected?.entry.amount)}. Không chuyển tiền thực tế qua chức năng này.`, requireReason: true, onClose: () => setSelected(null), busy: post.pending || reverse.pending, error: post.error || reverse.error, onConfirm: (reason) => selected?.action === "post" ? post.execute({ path: { entryId: selected.entry.id }, body: { expectedVersion: selected.entry.version, reason } }) : reverse.execute({ path: { entryId: selected?.entry.id || "" }, body: { expectedVersion: selected?.entry.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 81,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 73,
    columnNumber: 10
  }, this);
}
_s2(EntriesPage, "1f/ls0u4Zaa2If0NV3wRmQZNGBA=", false, function() {
  return [useScope, useApi, useListQuery, useCommand, useCommand, useApi];
});
_c2 = EntriesPage;
export function ProfitLossPage() {
  _s3();
  const { shop } = useScope();
  const report = useReportRange(shop.timezone);
  const data = useApi("getProfitLoss", { query: report.query }, report.valid);
  const p = data.data?.data;
  const [question, setQuestion] = useState("summary");
  const [generatedKey, setGeneratedKey] = useState("");
  const currentKey = p ? `${report.range.from}|${report.range.to}|${p.asOf}|${question}` : "";
  const explanation = p && generatedKey === currentKey ? explainProfitLoss(p, question) : null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Lợi nhuận quản trị", subtitle: "Số liệu do API tổng hợp từ nguồn giao dịch, không tính từ trang danh sách đang mở." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 93,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ReportRangeFields, { range: report.range, timezone: shop.timezone, setFrom: (value) => {
      setGeneratedKey("");
      report.setFrom(value);
    }, setTo: (value) => {
      setGeneratedKey("");
      report.setTo(value);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 94,
      columnNumber: 9
    }, this),
    report.valid ? /* @__PURE__ */ jsxDEV(QueryState, { query: data, pendingProfile: "section", children: p && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stats, { children: [
        /* @__PURE__ */ jsxDEV(Stat, { title: "Doanh thu thuần", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: p.netSales }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 98,
          columnNumber: 58
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 98,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Giá vốn", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: p.cogs }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 99,
          columnNumber: 50
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 99,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Lãi gộp", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: p.grossProfit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 100,
          columnNumber: 50
        }, this), accent: true }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 100,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { title: "Lợi nhuận vận hành", value: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: p.operatingProfit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 101,
          columnNumber: 61
        }, this), note: "Chưa có chứng nhận kế toán pháp định" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 101,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 97,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(PageSections, { children: [
        /* @__PURE__ */ jsxDEV(Panel, { title: "Chi tiết kết quả kinh doanh", action: /* @__PURE__ */ jsxDEV(Status, { value: p.completeness }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 104,
          columnNumber: 72
        }, this), bodyMode: "inset", children: [
          [
            ["Doanh thu gộp", p.grossSales],
            ["Giảm giá", p.discounts],
            ["Hàng bán trả lại", p.salesReturns],
            ["Doanh thu thuần", p.netSales],
            ["Giá vốn", p.cogs],
            ["Thu phí giao", p.shippingIncome],
            ["Chi phí giao", p.shippingExpense],
            ["Phí nền tảng", p.platformFees],
            ["Phí thanh toán", p.paymentFees],
            ["Chi phí AI", p.aiExpense],
            ["Chi phí khác", p.otherOperatingExpenses]
          ].map(([title, value]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: String(title), children: /* @__PURE__ */ jsxDEV(Amount, { wrap: true, value: typeof value === "object" ? value : null }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 107,
            columnNumber: 91
          }, this) }, String(title), false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 107,
            columnNumber: 37
          }, this)),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: p.policyVersion }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 108,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(DetailLine, { label: "Dữ liệu tại", children: dateTime(p.asOf, shop.timezone) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 109,
            columnNumber: 25
          }, this),
          p.warnings.map((warning) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.surface.sectionBefore, children: warning }, warning, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 110,
            columnNumber: 54
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 104,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Panel, { title: "Hỏi đáp có nguồn", subtitle: "Giải thích giới hạn theo đúng snapshot đang hiển thị.", bodyMode: "inset", children: __MOCK__ ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Chế độ mô phỏng: câu trả lời theo mẫu cố định, chỉ đọc dữ liệu P&L API tổng hợp này; không gọi AI và không ghi sổ." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 114,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(FormFields, { children: /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Câu hỏi về báo cáo", value: question, onChange: (event) => {
            setQuestion(event.target.value);
            setGeneratedKey("");
          }, children: profitLossQuestions.map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: item.label }, item.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 117,
            columnNumber: 72
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 116,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 115,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "column", beforeGap: "form", children: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", onClick: () => setGeneratedKey(currentKey), disabled: !currentKey, children: "Tạo giải thích mô phỏng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 121,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 120,
            columnNumber: 29
          }, this),
          explanation && /* @__PURE__ */ jsxDEV(SurfaceContent, { beforeGap: "surface", children: /* @__PURE__ */ jsxDEV(Box, { role: "region", "aria-label": "Giải thích báo cáo mô phỏng", "data-testid": "profit-loss-explanation", sx: { ...layoutSx.surface.inset, border: 1, borderColor: "divider", borderRadius: visualSx.radius.control }, children: [
            /* @__PURE__ */ jsxDEV(Typography, { sx: layoutSx.notice.afterGap, children: explanation.answer }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 125,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: layoutSx.report.subheadingAfterGap, children: "Dữ liệu nguồn trong snapshot" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 126,
              columnNumber: 37
            }, this),
            explanation.sources.map((source) => /* @__PURE__ */ jsxDEV(DetailLine, { label: source.label, children: source.value }, source.label, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 127,
              columnNumber: 74
            }, this)),
            explanation.warnings.map((warning, index) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.contentGap, children: warning }, `${index}-${warning}`, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 128,
              columnNumber: 83
            }, this)),
            /* @__PURE__ */ jsxDEV(BookProvenance, { report: p }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
              lineNumber: 129,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 124,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 123,
            columnNumber: 45
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 113,
          columnNumber: 37
        }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Chức năng giải thích chỉ có bản xem trước mô phỏng. API hiện chưa có operation hỏi đáp báo cáo." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 132,
          columnNumber: 31
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 112,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 103,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 96,
      columnNumber: 19
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 95,
      columnNumber: 25
    }, this) : /* @__PURE__ */ jsxDEV(Alert, { severity: "error", children: "Ngày bắt đầu phải trước ngày kết thúc." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 136,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 92,
    columnNumber: 10
  }, this);
}
_s3(ProfitLossPage, "LtOWyWl6PdqtCVPevzPfpZnn42o=", false, function() {
  return [useScope, useReportRange, useApi];
});
_c3 = ProfitLossPage;
export function JournalsPage() {
  _s4();
  const list = useApi("listJournals", { query: useListQuery("listJournals") });
  const [journalParams, setJournalParams] = useSearchParams();
  const viewId = journalParams.get("journalId");
  const setViewId = (id) => {
    const next = new URLSearchParams(journalParams);
    if (id) next.set("journalId", id);
    else next.delete("journalId");
    setJournalParams(next);
  };
  const detail = useApi("getJournal", { path: { resourceId: viewId || "" } }, Boolean(viewId));
  const viewedJournal = detail.data?.data;
  const post = useCommand("postJournal", ["listJournals", "getJournal", "getLedger", "getTrialBalance", "getBalanceSheet", "getProfitLoss", "getCashflow"]), reverse = useCommand("reverseJournal", ["listJournals", "getJournal", "getLedger", "getTrialBalance", "getBalanceSheet", "getProfitLoss", "getCashflow"]);
  const [open, setOpen] = useState(false), [replacement, setReplacement] = useState(null), [saved, setSaved] = useState(false), [selected, setSelected] = useState(null);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    saved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã lưu bút toán nháp; kiểm lại trước khi ghi." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 148,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Bút toán", subtitle: "Sổ kép có chứng từ nguồn, kiểm cân bằng tại API và không sửa bút toán đã ghi.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", variant: "contained", onClick: () => {
      setReplacement(null);
      setOpen(true);
    }, children: "Tạo bút toán nháp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 148,
      columnNumber: 243
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 148,
      columnNumber: 116
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listJournals" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 148,
        columnNumber: 404
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh sách bút toán", rows: list.data.data, rowKey: (journal) => journal.id, columns: [
          { key: "id", label: "Bút toán", render: (journal) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(journal.id), children: journal.id }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 149,
            columnNumber: 64
          }, this) },
          { key: "date", label: "Ngày hiệu lực", render: (journal) => formatDateOnly(journal.effectiveDate) },
          { key: "source", label: "Nguồn", render: (journal) => `${businessLabel(journal.sourceType)} / Mã chứng từ: ${journal.sourceId}` },
          { key: "state", label: "Trạng thái", render: (journal) => /* @__PURE__ */ jsxDEV(Status, { value: journal.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 152,
            columnNumber: 69
          }, this) },
          { key: "actions", label: "", render: (journal) => /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(journal.id), children: "Chi tiết" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 153,
            columnNumber: 61
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 148,
          columnNumber: 506
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 154,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 148,
        columnNumber: 504
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 148,
        columnNumber: 440
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 148,
      columnNumber: 397
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: Boolean(viewId), title: viewedJournal ? `Bút toán ${viewedJournal.id}` : "Đang tải bút toán", onClose: () => setViewId(null), actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setViewId(null), children: "Đóng" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 155,
      columnNumber: 158
    }, this), children: /* @__PURE__ */ jsxDEV(QueryState, { query: detail, children: viewedJournal && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Status, { value: viewedJournal.status }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 155,
        columnNumber: 260
      }, this),
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Các dòng của bút toán", rows: viewedJournal.lines.map((line, index) => ({ ...line, key: String(index) })), rowKey: (line) => line.key, columns: [
        { key: "account", label: "Tài khoản", render: (line) => line.accountId },
        { key: "debit", label: "Nợ", render: (line) => /* @__PURE__ */ jsxDEV(Amount, { value: line.debit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 157,
          columnNumber: 58
        }, this) },
        { key: "credit", label: "Có", render: (line) => /* @__PURE__ */ jsxDEV(Amount, { value: line.credit }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 158,
          columnNumber: 59
        }, this) },
        { key: "note", label: "Diễn giải", render: (line) => line.description }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 155,
        columnNumber: 299
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: viewedJournal.policyVersion }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Bút toán gốc", children: viewedJournal.reversalOf || "—" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 88
      }, this),
      viewedJournal.status === "reversed" && !["opening_balance", "finance_entry", "goods_receipt", "shipment_dispatch", "order_delivery", "return_inspection", "stock_adjustment"].includes(viewedJournal.sourceType) && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => {
        setReplacement(viewedJournal);
        setViewId(null);
        setOpen(true);
      }, children: "Thay thế bút toán" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 380
      }, this),
      viewedJournal.status === "draft" && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ journal: viewedJournal, action: "post" }), children: "Ghi sổ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 573
      }, this),
      viewedJournal.status === "posted" && !["opening_balance", "finance_entry", "goods_receipt", "shipment_dispatch", "order_delivery", "return_inspection", "stock_adjustment"].includes(viewedJournal.sourceType) && /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.post", onClick: () => setSelected({ journal: viewedJournal, action: "reverse" }), children: "Đảo bút toán" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 160,
        columnNumber: 922
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 155,
      columnNumber: 258
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 155,
      columnNumber: 213
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 155,
      columnNumber: 5
    }, this),
    open && /* @__PURE__ */ jsxDEV(JournalEditor, { replacement, onClose: () => setOpen(false), onSaved: () => setSaved(true) }, replacement?.id || "new", false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 161,
      columnNumber: 14
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: selected?.action === "post" ? "Ghi sổ bút toán" : "Đảo bút toán", confirmLabel: selected?.action === "post" ? "Ghi sổ bút toán" : "Đảo bút toán", description: `Bút toán ${selected?.journal.id || ""}: ${selected?.action === "post" ? "ghi vào sổ sau khi kiểm kỳ, cân bằng và nguồn chứng từ; bản đã ghi không được sửa trực tiếp." : "tạo bút toán đảo, giữ nguyên chứng từ gốc và lịch sử."}`, requireReason: selected?.action === "reverse", onClose: () => setSelected(null), error: post.error || reverse.error, busy: post.pending || reverse.pending, onConfirm: (confirmReason) => selected?.action === "post" ? post.execute({ path: { resourceId: selected.journal.id }, body: { expectedVersion: selected.journal.version } }) : reverse.execute({ path: { resourceId: selected?.journal.id || "" }, body: { expectedVersion: selected?.journal.version || 1, reason: confirmReason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 162,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 148,
    columnNumber: 10
  }, this);
}
_s4(JournalsPage, "kP2Qgt5hSIULFWStK5eByOZU1i8=", false, function() {
  return [useApi, useListQuery, useSearchParams, useApi, useCommand, useCommand];
});
_c4 = JournalsPage;
export function ReconciliationPage() {
  _s5();
  const { shop } = useScope();
  const [params, setParams] = useSearchParams();
  const requestedTab = params.get("tab");
  const tab = requestedTab === "cod" || requestedTab === "cases" ? requestedTab : "bank";
  const banks = useApi("listBankTransactions", { query: useListQuery("listBankTransactions", "bankCursor") });
  const cod = useApi("listCODSettlements", { query: useListQuery("listCODSettlements", "codCursor") });
  const cases = useApi("listReconciliationCases", { query: useListQuery("listReconciliationCases", "caseCursor") });
  const match = useCommand("matchCODSettlement", ["listCODSettlements", "listBankTransactions", "listDebtItems", "getCashflow"]);
  const matchBank = useCommand("matchSettlement", ["listReconciliationCases", "listBankTransactions", "listDebtItems"]);
  const [selected, setSelected] = useState(null), [caseItem, setCase] = useState(null), [transaction, setTransaction] = useState(""), [fees, setFees] = useState("0"), [evidence, setEvidence] = useState(""), [resourceId, setResource] = useState(""), [allocation, setAllocation] = useState(""), [reason, setReason] = useState(""), [importOpen, setImport] = useState(false);
  const bankChoices = usePagedApi("listBankTransactions", {}, Boolean(selected));
  const caseBank = useApi("getBankTransaction", { path: { resourceId: caseItem?.transactionId || "" } }, Boolean(caseItem));
  const debtChoices = usePagedApi("listDebtItems", {}, Boolean(caseItem));
  const selectedBank = caseItem ? caseBank.data?.data : bankChoices.data?.data.find((item) => item.id === transaction);
  const selectedDebt = debtChoices.data?.data.find((item) => item.id === resourceId);
  const feeUnits = decimalUnits(fees), allocationUnits = decimalUnits(allocation);
  const codMatchValid = Boolean(selected && selectedBank && feeUnits !== null && feeUnits >= 0n && feeUnits <= (decimalUnits(selected.grossDue.amount) ?? -1n) && (decimalUnits(selected.grossDue.amount) ?? -1n) - feeUnits === decimalUnits(selectedBank.amount.amount) && evidence.trim());
  const bankMatchValid = Boolean(caseItem && selectedBank && selectedDebt && !selectedDebt.disputed && allocationUnits !== null && allocationUnits > 0n && allocationUnits <= (decimalUnits(caseItem.difference.amount) ?? -1n) && allocationUnits <= (decimalUnits(selectedDebt.outstandingAmount.amount) ?? -1n) && selectedDebt.outstandingAmount.currency === selectedBank.amount.currency && selectedBank.direction === "credit" === (selectedDebt.direction === "receivable") && codePointLength(reason.trim()) >= 5);
  const selectTab = (_event, value) => {
    const next = new URLSearchParams(params);
    if (value === "bank") next.delete("tab");
    else
      next.set("tab", value);
    setParams(next, { replace: true, flushSync: true });
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Đối soát ngân hàng & COD", subtitle: "Khách trả tiền cho đơn vị giao hàng chưa đồng nghĩa tiền đã về shop.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", variant: "contained", onClick: () => setImport(true), children: "Nhập bảng đối soát" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 146
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Tabs, { value: tab, onChange: selectTab, sx: layoutSx.page.sectionAfter, variant: "scrollable", children: [
      /* @__PURE__ */ jsxDEV(Tab, { value: "bank", label: "Ngân hàng" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 190,
        columnNumber: 376
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { value: "cod", label: "COD" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 190,
        columnNumber: 414
      }, this),
      /* @__PURE__ */ jsxDEV(Tab, { value: "cases", label: "Chênh lệch cần xử lý" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 190,
        columnNumber: 445
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 284
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: tab === "bank" ? /* @__PURE__ */ jsxDEV(QueryState, { query: banks, pendingProfile: "section", children: banks.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Giao dịch sao kê ngân hàng", rows: banks.data.data, rowKey: (row) => row.id, empty: "Chưa có giao dịch sao kê trong phạm vi đang xem.", emptyAction: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setImport(true), children: "Nhập bảng sao kê" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 190,
        columnNumber: 759
      }, this), columns: [
        { key: "id", label: "Mã ngoài hệ thống", render: (row) => row.externalTransactionId },
        { key: "account", label: "Tài khoản", render: (row) => row.accountId },
        { key: "money", label: "Số tiền", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.amount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 193,
          columnNumber: 62
        }, this) },
        { key: "direction", label: "Chiều", render: (row) => row.direction === "credit" ? "Tiền vào" : "Tiền ra" },
        { key: "note", label: "Nội dung", render: (row) => row.referenceText },
        { key: "state", label: "Khớp", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.matchState }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 196,
          columnNumber: 59
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 190,
        columnNumber: 595
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: banks.data.page, cursorParam: "bankCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 197,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 593
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 527
    }, this) : tab === "cod" ? /* @__PURE__ */ jsxDEV(QueryState, { query: cod, pendingProfile: "section", children: cod.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Đợt đối soát COD", rows: cod.data.data, rowKey: (row) => row.id, empty: "Chưa có đợt đối soát COD trong phạm vi đang xem.", columns: [
        { key: "id", label: "Đợt COD", render: (row) => row.externalBatchId },
        { key: "carrier", label: "Đơn vị giao", render: (row) => row.carrierId },
        { key: "gross", label: "Phải thu", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.grossDue }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 200,
          columnNumber: 63
        }, this) },
        { key: "fee", label: "Phí thực tế", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.actualFees }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 201,
          columnNumber: 64
        }, this) },
        { key: "cash", label: "Đã về ngân hàng", render: (row) => /* @__PURE__ */ jsxDEV(Amount, { value: row.bankReceived }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 202,
          columnNumber: 69
        }, this) },
        { key: "state", label: "Trạng thái", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 203,
          columnNumber: 65
        }, this) },
        { key: "action", label: "", render: (row) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", disabled: row.status === "matched", onClick: () => {
          setSelected(row);
          setTransaction("");
          setFees(row.actualFees.amount);
          setEvidence("");
        }, children: "Đối chiếu" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 204,
          columnNumber: 56
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 197,
        columnNumber: 172
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: cod.data.page, cursorParam: "codCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 205,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 197,
      columnNumber: 170
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 197,
      columnNumber: 108
    }, this) : /* @__PURE__ */ jsxDEV(QueryState, { query: cases, pendingProfile: "section", children: cases.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Hồ sơ ghép và đối chiếu", rows: cases.data.data, rowKey: (row) => row.id, empty: "Chưa có hồ sơ chênh lệch cần xử lý trong phạm vi đang xem.", columns: [
        { key: "id", label: "Mã", render: (row) => row.id },
        { key: "transaction", label: "Giao dịch", render: (row) => banks.data?.data.find((transaction2) => transaction2.id === row.transactionId)?.externalTransactionId || row.transactionId },
        { key: "state", label: "Trạng thái", render: (row) => /* @__PURE__ */ jsxDEV(Status, { value: row.state }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 208,
          columnNumber: 65
        }, this) },
        { key: "reason", label: "Cần xử lý", render: (row) => row.reason },
        { key: "action", label: "", render: (row) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.reconcile", disabled: row.state === "matched", onClick: () => {
          setCase(row);
          setTransaction(row.transactionId);
          setResource("");
          setAllocation("");
          setReason("");
        }, children: "Ghép giao dịch" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 210,
          columnNumber: 56
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 205,
        columnNumber: 157
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: cases.data.page, cursorParam: "caseCursor" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 211,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 205,
      columnNumber: 155
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 205,
      columnNumber: 89
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 190,
      columnNumber: 502
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!selected, title: "Ghép tiền COD", onClose: () => setSelected(null), busy: match.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !codMatchValid || match.pending, onClick: async () => {
      try {
        await match.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, bankTransactionId: transaction, actualFees: { amount: fees, currency: shop.currency }, feeEvidenceRef: evidence, reason: "Đối chiếu bảng COD và giao dịch ngân hàng" } });
        setSelected(null);
      } catch {
      }
    }, children: "Xác nhận khớp" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 212,
      columnNumber: 121
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: match.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 212,
        columnNumber: 570
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: bankChoices, children: bankChoices.data && /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Mã giao dịch ngân hàng", value: transaction, onChange: (event) => setTransaction(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn giao dịch chưa ghép" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 212,
            columnNumber: 796
          }, this),
          bankChoices.data.data.filter((item) => item.direction === "credit" && item.matchState === "unmatched" && item.amount.currency === selected?.grossDue.currency).map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: [
            item.externalTransactionId,
            " · ",
            formatMoney(item.amount)
          ] }, item.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 212,
            columnNumber: 1024
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 212,
          columnNumber: 670
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "giao dịch ngân hàng", loadedCount: bankChoices.loadedCount, hasMore: bankChoices.hasMore, busy: bankChoices.isLoadingMore, onLoadMore: bankChoices.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 212,
          columnNumber: 1146
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Phí thực tế (${shop.currency})`, value: fees, error: feeUnits === null, helperText: selectedBank && feeUnits !== null && !codMatchValid ? "Tiền về + phí phải bằng khoản COD và cần chứng từ phí." : "Nhập phí theo chứng từ; khoản fee đã khấu trừ không phải chi tiền thêm.", onChange: (event) => setFees(event.target.value), inputProps: { inputMode: "decimal" } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 212,
          columnNumber: 1327
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã chứng từ phí", value: evidence, onChange: (event) => setEvidence(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 212,
          columnNumber: 1708
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không xác nhận thanh toán bằng ảnh chuyển khoản. Tổng tiền về và phí phải khớp khoản COD." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 212,
          columnNumber: 1816
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 212,
        columnNumber: 658
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 212,
        columnNumber: 605
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 212,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: !!caseItem, title: "Ghép giao dịch với công nợ", onClose: () => setCase(null), busy: matchBank.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !bankMatchValid || matchBank.pending, onClick: async () => {
      try {
        await matchBank.execute({ path: { resourceId: caseItem?.id || "" }, body: { expectedVersion: caseItem?.version || 1, transactionId: transaction, allocations: [{ resource: { type: "debt", id: resourceId }, amount: { amount: allocation, currency: shop.currency } }], reason } });
        setCase(null);
      } catch {
      }
    }, children: "Ghi kết quả đối soát" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 213,
      columnNumber: 134
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: matchBank.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 213,
        columnNumber: 597
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: caseBank, children: caseBank.data && /* @__PURE__ */ jsxDEV(QueryState, { query: debtChoices, children: debtChoices.data && /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Giao dịch ngoài hệ thống", value: caseBank.data.data.externalTransactionId, InputProps: { readOnly: true } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 748
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khoản công nợ", value: resourceId, onChange: (event) => setResource(event.target.value), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chọn khoản nợ chưa tranh chấp" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 213,
            columnNumber: 988
          }, this),
          debtChoices.data.data.filter((item) => !item.disputed && hasOutstandingBalance(item.outstandingAmount.amount) && item.outstandingAmount.currency === selectedBank?.amount.currency && selectedBank?.direction === "credit" === (item.direction === "receivable")).map((item) => /* @__PURE__ */ jsxDEV(MenuItem, { value: item.id, children: [
            item.id,
            " · ",
            item.direction === "receivable" ? "Phải thu" : "Phải trả",
            " · ",
            formatMoney(item.outstandingAmount)
          ] }, item.id, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
            lineNumber: 213,
            columnNumber: 1320
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 875
        }, this),
        /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "công nợ", loadedCount: debtChoices.loadedCount, hasMore: debtChoices.hasMore, busy: debtChoices.isLoadingMore, onLoadMore: debtChoices.loadMore }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 1496
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Số tiền phân bổ (${shop.currency})`, value: allocation, error: allocation !== "" && allocationUnits === null, helperText: allocationUnits !== null && allocationUnits > 0n && !bankMatchValid ? "Số tiền vượt chênh lệch/khoản nợ, khác tiền tệ hoặc thiếu lý do." : "", onChange: (event) => setAllocation(event.target.value), inputProps: { inputMode: "decimal" } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 1665
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (event) => setReason(event.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 213,
          columnNumber: 2045
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 213,
        columnNumber: 736
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 213,
        columnNumber: 683
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 213,
        columnNumber: 636
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 213,
      columnNumber: 5
    }, this),
    importOpen && /* @__PURE__ */ jsxDEV(StatementDialog, { onClose: () => setImport(false) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 214,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 190,
    columnNumber: 10
  }, this);
}
_s5(ReconciliationPage, "9qdkxQdeXVPTaKGcCJmeunbC/wU=", false, function() {
  return [useScope, useSearchParams, useApi, useListQuery, useApi, useListQuery, useApi, useListQuery, useCommand, useCommand, usePagedApi, useApi, usePagedApi];
});
_c5 = ReconciliationPage;
export function DebtsPage() {
  _s6();
  const { shop } = useScope();
  const [periodOpen, setPeriodOpen] = useState(false), [periodSaved, setPeriodSaved] = useState(false);
  const debts = useApi("listDebtItems", { query: useListQuery("listDebtItems") }), periods = useApi("listAccountingPeriods");
  const close = useCommand("closeAccountingPeriod", ["listAccountingPeriods"]);
  const reopen = useCommand("reopenAccountingPeriod", ["listAccountingPeriods"]);
  const [selected, setSelected] = useState(null), [approval, setApproval] = useState(""), [reason, setReason] = useState("");
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Công nợ & khóa kỳ", subtitle: "Theo dõi khoản còn phải thu/trả; khóa kỳ chỉ khi các điều kiện được kiểm chứng.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.close", variant: "contained", onClick: () => setPeriodOpen(true), children: "Tạo kỳ kế toán" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 150
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 12
    }, this),
    periodSaved && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: "Đã tạo kỳ kế toán mới." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 300
    }, this),
    periodOpen && /* @__PURE__ */ jsxDEV(CreatePeriodDialog, { onClose: () => setPeriodOpen(false), onSaved: () => setPeriodSaved(true) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 386
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Công nợ", children: /* @__PURE__ */ jsxDEV(QueryState, { query: debts, pendingProfile: "section", children: debts.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Công nợ", rows: debts.data.data, rowKey: (r) => r.id, columns: [
        { key: "id", label: "Khoản nợ", render: (r) => r.id },
        { key: "who", label: "Đối tượng", render: (r) => `${r.counterpartyType} / Mã đối tượng: ${r.counterpartyId}` },
        { key: "direction", label: "Loại", render: (r) => r.direction === "receivable" ? "Phải thu" : "Phải trả" },
        { key: "original", label: "Ban đầu", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.originalAmount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 224,
          columnNumber: 338
        }, this) },
        { key: "current", label: "Còn lại", render: (r) => /* @__PURE__ */ jsxDEV(Amount, { value: r.outstandingAmount }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 224,
          columnNumber: 428
        }, this) },
        { key: "due", label: "Đến hạn", render: (r) => dateTime(r.dueAt, shop.timezone) },
        { key: "dispute", label: "Tranh chấp", render: (r) => r.disputed ? "Đang giữ xử lý" : "Không" }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 223,
        columnNumber: 574
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: debts.data.page }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 225,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 572
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 506
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 223,
      columnNumber: 483
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Kỳ kế toán", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: periods, pendingProfile: "section", children: /* @__PURE__ */ jsxDEV(DataTable, { label: "Kỳ kế toán", rows: periods.data?.data || [], rowKey: (r) => r.id, columns: [
      { key: "period", label: "Kỳ", render: (r) => `${formatDateOnly(r.startDate)} → ${formatDateOnly(r.endDate)}` },
      { key: "state", label: "Trạng thái", render: (r) => /* @__PURE__ */ jsxDEV(Status, { domain: "accountingPeriod", value: r.state }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 226,
        columnNumber: 173
      }, this) },
      { key: "issues", label: "Điều kiện còn thiếu", render: (r) => r.blockingIssues.join("; ") || "Xác minh lại tại lúc ghi" },
      {
        key: "action",
        label: "",
        render: (r) => /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.close", onClick: () => {
          setSelected(r);
          setApproval("");
          setReason("");
        }, children: r.state === "closed" ? "Mở lại có phê duyệt" : "Kiểm & khóa kỳ" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 228,
          columnNumber: 52
        }, this)
      }
    ] }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 225,
      columnNumber: 173
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 225,
      columnNumber: 120
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 225,
      columnNumber: 72
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected && selected.state !== "closed", title: "Khóa kỳ kế toán", confirmLabel: "Khóa kỳ kế toán", description: `Kỳ ${selected?.id || ""}, từ ${selected?.startDate || ""} đến ${selected?.endDate || ""}: khóa ghi sổ mới sau khi kiểm chứng từ nháp, sai lệch và COD. Mở lại cần quyền và phê duyệt riêng.`, onClose: () => setSelected(null), busy: close.pending, error: close.error, onConfirm: () => close.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1 } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 230,
      columnNumber: 34
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open: selected?.state === "closed", title: "Mở lại kỳ đã khóa", onClose: () => setSelected(null), busy: reopen.pending, actions: /* @__PURE__ */ jsxDEV(Button, { disabled: !approval || codePointLength(reason) < 5 || reopen.pending, onClick: async () => {
      try {
        await reopen.execute({ path: { resourceId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, approvalId: approval, reason } });
        setSelected(null);
      } catch {
      }
    }, children: "Mở lại kỳ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 230,
      columnNumber: 702
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: reopen.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 234,
        columnNumber: 51
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã phê duyệt đúng kỳ", value: approval, onChange: (e) => setApproval(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 234,
          columnNumber: 99
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Lý do", value: reason, onChange: (e) => setReason(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
          lineNumber: 234,
          columnNumber: 204
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
        lineNumber: 234,
        columnNumber: 87
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
      lineNumber: 230,
      columnNumber: 563
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx",
    lineNumber: 223,
    columnNumber: 10
  }, this);
}
_s6(DebtsPage, "isuuV5d42vlGwoS+G9VWLqDguKc=", false, function() {
  return [useScope, useApi, useListQuery, useApi, useCommand, useCommand];
});
_c6 = DebtsPage;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "CashflowPage");
$RefreshReg$(_c2, "EntriesPage");
$RefreshReg$(_c3, "ProfitLossPage");
$RefreshReg$(_c4, "JournalsPage");
$RefreshReg$(_c5, "ReconciliationPage");
$RefreshReg$(_c6, "DebtsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUM0SCxTQUFpUSxVQUFqUTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQzVILFNBQVFBLGdCQUFlO0FBQ3ZCLFNBQVFDLHFCQUFvQjtBQUM1QixTQUFRQyxvQkFBbUJDLHVCQUF1QkMsZUFBYztBQUNoRSxTQUFRQyx1QkFBc0I7QUFDOUIsU0FBUUMsZ0JBQWVDLDBCQUF5QjtBQUNoRCxTQUFRQyxxQkFBb0JDLFlBQVdDLGtCQUFpQkMsd0JBQXVCO0FBQy9FLFNBQVFDLGdCQUFlQyx5QkFBd0I7QUFDL0MsU0FBUUMsU0FBU0MscUJBQW9CO0FBQ3JDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxhQUFhQyxZQUFZQyxjQUFjQyxzQkFBc0I7QUFDdEUsU0FBU0MsZ0JBQXFDO0FBQzlDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxPQUFPQyxLQUFLQyxRQUFRQyxVQUFVQyxPQUFPQyxLQUFLQyxNQUFNQyxXQUFXQyxrQkFBa0I7QUFFdEYsU0FBU0MsUUFBUUMsWUFBWUMsbUJBQW1CO0FBQ2hELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCQyxVQUFVQyxhQUFhQyxzQkFBc0I7QUFDdkUsU0FBU0MsUUFBUUMsZUFBZUMsV0FBV0MsWUFBWUMsWUFBWUMsYUFBYUMsZ0JBQWdCQyxnQkFBZ0JDLFlBQVlDLE9BQU9DLE9BQU9DLFlBQVlDLFdBQVdDLE1BQU1DLE9BQU9DLFFBQVFDLGVBQWU7QUFDck0sU0FBU0MsbUJBQW1CQywyQkFBc0Q7QUFDbEYsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLGFBQWFDLE9BQThCO0FBQ2hELE1BQUksQ0FBQyxvQkFBb0JDLEtBQUtELEtBQUssRUFBRyxRQUFPO0FBQzdDLFFBQU0sQ0FBQ0UsUUFBUSxJQUFJQyxXQUFXLEVBQUUsSUFBSUgsTUFBTUksTUFBTSxHQUFHO0FBQ25ELE1BQUksQ0FBQ0YsTUFBTyxRQUFPO0FBQ25CLFNBQU9HLE9BQU9ILEtBQUssSUFBSSxTQUFTRyxPQUFPRixTQUFTRyxPQUFPLEdBQUcsR0FBRyxDQUFDO0FBQ2xFO0FBQ0EsU0FBU0Msc0JBQXNCUCxPQUFlO0FBQzFDLFFBQU1RLFNBQVNULGFBQWFDLEtBQUs7QUFDakMsU0FBT1EsV0FBVyxRQUFRQSxTQUFTO0FBQ3ZDO0FBQ08sZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNLEVBQUVDLEtBQUssSUFBSXRDLFNBQVM7QUFDMUIsUUFBTXVDLFNBQVM5RCxlQUFlNkQsS0FBS0UsUUFBUTtBQUMzQyxRQUFNQyxPQUFPNUMsT0FBTyxlQUFlLEVBQUU2QyxPQUFPSCxPQUFPRyxNQUFNLEdBQUdILE9BQU9JLEtBQUs7QUFDeEUsUUFBTUMsSUFBSUgsS0FBS0EsTUFBTUE7QUFDckIsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxhQUFZLFVBQVMsZ0VBQStELFNBQVMsdUJBQUMsYUFBVSxJQUFJLE1BQU1ILEtBQUtPLEVBQUUsb0JBQW9CLDBCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBELEtBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0w7QUFBQSxJQUFFLHVCQUFDLHFCQUFrQixPQUFPTixPQUFPTyxPQUFPLFVBQVVSLEtBQUtFLFVBQVUsU0FBU0QsT0FBT1EsU0FBUyxPQUFPUixPQUFPUyxTQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThHO0FBQUEsSUFBR1QsT0FBT0ksUUFBUSx1QkFBQyxjQUFXLE9BQU9GLE1BQU0sZ0JBQWUsV0FBV0csZUFBSyxtQ0FBRTtBQUFBLDZCQUFDLFNBQU07QUFBQSwrQkFBQyxRQUFLLE9BQU0sZUFBYyxPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9BLEVBQUVLLFlBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0IsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLGVBQWMsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPTCxFQUFFTSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQyxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFBRSx1QkFBQyxRQUFLLE9BQU0sd0JBQXVCLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT04sRUFBRU8sbUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsR0FBSSxRQUFNLE1BQUMsTUFBSyxnQ0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0SDtBQUFBLFFBQUUsdUJBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPUCxFQUFFSixZQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsV0FBcFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzVTtBQUFBLE1BQVEsdUJBQUMsU0FBTSxPQUFNLGNBQWEsVUFBUyxTQUFRO0FBQUEsK0JBQUMsY0FBVyxPQUFNLE1BQU1yQyxtQkFBU3lDLEVBQUVRLE1BQU1kLEtBQUtFLFFBQVEsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQWEsdUJBQUMsY0FBVyxPQUFNLG1CQUFtQnJDLG1CQUFTeUMsRUFBRVMsSUFBSWYsS0FBS0UsUUFBUSxLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFBYSx1QkFBQyxjQUFXLE9BQU0sZUFBZXJDLG1CQUFTeUMsRUFBRVUsTUFBTWhCLEtBQUtFLFFBQVEsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQWNJLEVBQUVXLFNBQVNDLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFjLFVBQVMsUUFBTyxJQUFJaEMsU0FBU2lDLFFBQVFDLGVBQWdCRixlQUF4REEsR0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFLENBQVE7QUFBQSxXQUFqWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1YO0FBQUEsU0FBbnNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMnNCLEtBQW53QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXV3QixJQUFnQix1QkFBQyxTQUFNLFVBQVMsU0FBUSxzREFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLE9BQS9vQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdwQztBQUNucUM7QUFBQ3BCLEdBTmVELGNBQVk7QUFBQSxVQUNQcEMsVUFDRnZCLGdCQUNGb0IsTUFBTTtBQUFBO0FBQUEsS0FIUHVDO0FBT1QsZ0JBQVN3QixjQUFjO0FBQUFDLE1BQUE7QUFDMUIsUUFBTSxFQUFFdkIsS0FBSyxJQUFJdEMsU0FBUztBQUMxQixRQUFNOEQsT0FBT2pFLE9BQU8sc0JBQXNCLEVBQUU2QyxPQUFPekMsYUFBYSxvQkFBb0IsRUFBRSxDQUFDO0FBQ3ZGLFFBQU04RCxPQUFPakUsV0FBVyxvQkFBb0IsQ0FBQyxzQkFBc0IsZUFBZSxpQkFBaUIsY0FBYyxDQUFDO0FBQ2xILFFBQU1rRSxVQUFVbEUsV0FBVyx1QkFBdUIsQ0FBQyxzQkFBc0IsZUFBZSxpQkFBaUIsY0FBYyxDQUFDO0FBQ3hILFFBQU0sQ0FBQ21FLFNBQVNDLFVBQVUsSUFBSWhGLFNBQXdCLElBQUk7QUFDMUQsUUFBTWlGLFNBQVN0RSxPQUFPLG1CQUFtQixFQUFFdUUsTUFBTSxFQUFFSCxTQUFTQSxXQUFXLEdBQUcsRUFBRSxHQUFHSSxRQUFRSixPQUFPLENBQUM7QUFDL0YsUUFBTUssZ0JBQWdCSCxPQUFPMUIsTUFBTUE7QUFDbkMsUUFBTSxDQUFDOEIsU0FBU0MsVUFBVSxJQUFJdEYsU0FBOEIsSUFBSSxHQUFHLENBQUN1RixNQUFNQyxPQUFPLElBQUl4RixTQUFTLEtBQUssR0FBRyxDQUFDeUYsVUFBVUMsV0FBVyxJQUFJMUYsU0FHdEgsSUFBSTtBQUNkLFFBQU0sQ0FBQzJGLFlBQVdDLGFBQWEsSUFBRTVGLFNBQVMsS0FBSztBQUMvQyxRQUFNNkYsUUFBTUEsQ0FBQ0MsVUFBMEI7QUFBQ1IsZUFBV1EsS0FBSztBQUFFTixZQUFRLElBQUk7QUFBQSxFQUFFO0FBQ3hFLFNBQU8sbUNBQUdHO0FBQUFBLGtCQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBUyxrQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLElBQVMsdUJBQUMsY0FBVyxPQUFNLGNBQWEsVUFBUywyRUFBMEUsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVEsYUFBWSxTQUFTLE1BQU1FLE1BQU0sSUFBSSxHQUFHLHlCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HLEtBQTlOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ1A7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUFHLHVCQUFDLGNBQVcsT0FBT2pCLE1BQU0sZ0JBQWUsV0FBV0EsZUFBS3JCLFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sb0JBQW1CLE1BQU1xQixLQUFLckIsS0FBS0EsTUFBTSxRQUFRLENBQUF3QyxNQUFLQSxFQUFFcEMsSUFBSSxTQUFTO0FBQUEsVUFDaGhCLEVBQUVxQyxLQUFLLE1BQU12RyxPQUFPLFlBQVl3RyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFVBQU8sU0FBUyxNQUFNZixXQUFXZSxFQUFFcEMsRUFBRSxHQUFJb0MsWUFBRXBDLE1BQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDLEVBQVU7QUFBQSxVQUFHLEVBQUVxQyxLQUFLLFFBQVF2RyxPQUFPLFFBQVF3RyxRQUFRQSxDQUFBRixNQUFLOUUsU0FBUzhFLEVBQUVHLFlBQVk5QyxLQUFLRSxRQUFRLEVBQUU7QUFBQSxVQUFHLEVBQUUwQyxLQUFLLFFBQVF2RyxPQUFPLGFBQWF3RyxRQUFRQSxDQUFBRixNQUFLaEgsUUFBUWdILEVBQUVJLGNBQWMsRUFBRTtBQUFBLFVBQUcsRUFBRUgsS0FBSyxVQUFVdkcsT0FBTyxXQUFXd0csUUFBUUEsQ0FBQUYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUU5QyxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QixFQUFHO0FBQUEsVUFBRyxFQUFFK0MsS0FBSyxRQUFRdkcsT0FBTyxhQUFhd0csUUFBUUEsQ0FBQUYsTUFBS0EsRUFBRUssWUFBWTtBQUFBLFVBQUcsRUFBRUosS0FBSyxTQUFTdkcsT0FBTyxjQUFjd0csUUFBUUEsQ0FBQUYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVNLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUN0ZTtBQUFBLFlBQ0lMLEtBQUs7QUFBQSxZQUFVdkcsT0FBTztBQUFBLFlBQVl3RyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFVBQU8sU0FBUyxNQUFNZixXQUFXZSxFQUFFcEMsRUFBRSxHQUFHLHdCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFVBQ3BHO0FBQUEsUUFBQyxLQUp5YjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSzViO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1pQixLQUFLckIsS0FBSytDLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQUw0WjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzFaLEtBTDBWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLdFY7QUFBQSxTQUxxUztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3hSO0FBQUEsSUFDdEQsdUJBQUMsY0FBVyxNQUFNbkIsUUFBUUosT0FBTyxHQUFHLE9BQU9LLGdCQUFnQixZQUFZQSxjQUFjekIsRUFBRSxLQUFLLHFCQUFxQixTQUFTLE1BQU1xQixXQUFXLElBQUksR0FBRyxTQUFTLHVCQUFDLFVBQU8sU0FBUyxNQUFNQSxXQUFXLElBQUksR0FBRyxvQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QyxHQUFXLGlDQUFDLGNBQVcsT0FBT0MsUUFBU0csMkJBQWlCLHVCQUFDLFNBQU0sSUFBSTdDLFNBQVNpQixNQUFNK0MsVUFBVTtBQUFBLDZCQUFDLFVBQU8sT0FBT25CLGNBQWNpQixVQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU0sUUFBUWpCLHdCQUFjb0IsU0FBUyxZQUFZLGFBQWEsY0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGFBQWF6SCxrQkFBUXFHLGNBQWNlLGNBQWMsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFdBQVUsaUNBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT2YsY0FBY25DLFVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUMsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGlCQUFpQmhDLG1CQUFTbUUsY0FBY2MsWUFBWTlDLEtBQUtFLFFBQVEsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFNBQVM4Qix3QkFBY3FCLFlBQVksR0FBR3JCLGNBQWNxQixVQUFVQyxJQUFJLE1BQU10QixjQUFjcUIsVUFBVTlDLEVBQUUsS0FBSyxjQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9JO0FBQUEsTUFBYSx1QkFBQyxjQUFXLE9BQU0sYUFBYXlCLHdCQUFjZ0IsZUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLE1BQWNoQixjQUFjaUIsV0FBVyxXQUFXLHVCQUFDLGVBQVksV0FBVSxPQUFPO0FBQUEsK0JBQUMsa0JBQWUsWUFBVyxnQkFBZSxTQUFTLE1BQU1SLE1BQU1ULGFBQWEsR0FBRyx3QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQWlCLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUyxNQUFNTSxZQUFZLEVBQUVJLE9BQU9WLGVBQWV1QixRQUFRLE9BQU8sQ0FBQyxHQUFHLHNCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsV0FBNVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2UTtBQUFBLE1BQWdCdkIsY0FBY2lCLFdBQVcsWUFBWSxDQUFDLENBQUMsbUJBQWtCLGtCQUFpQixTQUFRLGNBQWMsRUFBRU8sU0FBU3hCLGNBQWNxQixXQUFXQyxRQUFNLEVBQUUsS0FBSyx1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVMsTUFBTWhCLFlBQVksRUFBRUksT0FBT1YsZUFBZXVCLFFBQVEsVUFBVSxDQUFDLEdBQUcseUJBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxTQUExdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0dUMsS0FBenhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa3lDLEtBQXIvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtnRDtBQUFBLElBQ2pnRHBCLFFBQU0sdUJBQUMsc0JBQTRDLFNBQVNGLFNBQVMsU0FBUyxNQUFJRyxRQUFRLEtBQUssR0FBRyxTQUFTLE1BQUlJLGNBQWMsSUFBSSxLQUFsR1AsU0FBUzFCLE1BQUksT0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2SDtBQUFBLElBQ3BJLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDOEIsVUFBVSxPQUFPQSxVQUFVa0IsV0FBVyxTQUFTLHlCQUF5QixvQkFBb0IsY0FBY2xCLFVBQVVrQixXQUFXLFNBQVMsaUJBQWlCLGFBQWEsYUFBYSxHQUFHbEIsVUFBVUssTUFBTW5DLE1BQU0sRUFBRSxNQUFNekMsWUFBWXVFLFVBQVVLLE1BQU03QyxNQUFNLENBQUMsa0RBQWtELGVBQWEsTUFBQyxTQUFTLE1BQU15QyxZQUFZLElBQUksR0FBRyxNQUFNYixLQUFLZ0MsV0FBVy9CLFFBQVErQixTQUFTLE9BQU9oQyxLQUFLaUMsU0FBU2hDLFFBQVFnQyxPQUFPLFdBQVcsQ0FBQUMsV0FBVXRCLFVBQVVrQixXQUFXLFNBQVM5QixLQUFLbUMsUUFBUSxFQUFFOUIsTUFBTSxFQUFFSCxTQUFTVSxTQUFTSyxNQUFNbkMsR0FBRyxHQUFHc0QsTUFBTSxFQUFFQyxpQkFBaUJ6QixTQUFTSyxNQUFNcUIsU0FBU0osT0FBTyxFQUFFLENBQUMsSUFBSWpDLFFBQVFrQyxRQUFRLEVBQUU5QixNQUFNLEVBQUVILFNBQVNVLFVBQVVLLE1BQU1uQyxNQUFNLEdBQUcsR0FBR3NELE1BQU0sRUFBRUMsaUJBQWlCekIsVUFBVUssTUFBTXFCLFdBQVcsR0FBR0osT0FBTyxFQUFFLENBQUMsS0FBbHVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb3VCO0FBQUEsT0FSMXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRNHRCO0FBQ3Z1QjtBQUFDcEMsSUF2QmVELGFBQVc7QUFBQSxVQUNONUQsVUFDSkgsUUFBc0NJLGNBQ3RDSCxZQUNHQSxZQUVERCxNQUFNO0FBQUE7QUFBQSxNQU5UK0Q7QUF3QlQsZ0JBQVMwQyxpQkFBaUI7QUFBQUMsTUFBQTtBQUM3QixRQUFNLEVBQUVqRSxLQUFLLElBQUl0QyxTQUFTO0FBQzFCLFFBQU11QyxTQUFTOUQsZUFBZTZELEtBQUtFLFFBQVE7QUFDM0MsUUFBTUMsT0FBTzVDLE9BQU8saUJBQWlCLEVBQUU2QyxPQUFPSCxPQUFPRyxNQUFNLEdBQUdILE9BQU9JLEtBQUs7QUFDMUUsUUFBTTZELElBQUkvRCxLQUFLQSxNQUFNQTtBQUNyQixRQUFNLENBQUNnRSxVQUFVQyxXQUFXLElBQUl4SCxTQUErQixTQUFTO0FBQ3hFLFFBQU0sQ0FBQ3lILGNBQWNDLGVBQWUsSUFBSTFILFNBQVMsRUFBRTtBQUNuRCxRQUFNMkgsYUFBYUwsSUFBSSxHQUFHakUsT0FBT08sTUFBTU0sSUFBSSxJQUFJYixPQUFPTyxNQUFNTyxFQUFFLElBQUltRCxFQUFFbEQsSUFBSSxJQUFJbUQsUUFBUSxLQUFLO0FBQ3pGLFFBQU1LLGNBQWNOLEtBQUtHLGlCQUFpQkUsYUFBYXRGLGtCQUFrQmlGLEdBQUdDLFFBQVEsSUFBSTtBQUN4RixTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHNCQUFxQixVQUFTLHdGQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9JO0FBQUEsSUFDcEksdUJBQUMscUJBQWtCLE9BQU9sRSxPQUFPTyxPQUFPLFVBQVVSLEtBQUtFLFVBQVUsU0FBUyxDQUFBYixVQUFTO0FBQUVpRixzQkFBZ0IsRUFBRTtBQUFHckUsYUFBT1EsUUFBUXBCLEtBQUs7QUFBQSxJQUFHLEdBQUcsT0FBTyxDQUFBQSxVQUFTO0FBQUVpRixzQkFBZ0IsRUFBRTtBQUFHckUsYUFBT1MsTUFBTXJCLEtBQUs7QUFBQSxJQUFHLEtBQWhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa007QUFBQSxJQUNqTVksT0FBT0ksUUFBUSx1QkFBQyxjQUFXLE9BQU9GLE1BQU0sZ0JBQWUsV0FDbkQrRCxlQUFLLG1DQUNGO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUssT0FBTSxtQkFBa0IsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPQSxFQUFFTyxZQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxRQUFLLE9BQU0sV0FBVSxPQUFPLHVCQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU9QLEVBQUVRLFFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzVELHVCQUFDLFFBQUssT0FBTSxXQUFVLE9BQU8sdUJBQUMsVUFBTyxNQUFJLE1BQUMsT0FBT1IsRUFBRVMsZUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQyxHQUFLLFFBQU0sUUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFFBQzFFLHVCQUFDLFFBQUssT0FBTSxzQkFBcUIsT0FBTyx1QkFBQyxVQUFPLE1BQUksTUFBQyxPQUFPVCxFQUFFVSxtQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxHQUFLLE1BQUssMENBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEg7QUFBQSxXQUpsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLGdCQUNHO0FBQUEsK0JBQUMsU0FBTSxPQUFNLCtCQUE4QixRQUFRLHVCQUFDLFVBQU8sT0FBT1YsRUFBRVcsZ0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsR0FBSyxVQUFTLFNBQzFGO0FBQUE7QUFBQSxZQUNHLENBQUMsaUJBQWlCWCxFQUFFWSxVQUFVO0FBQUEsWUFBRyxDQUFDLFlBQVlaLEVBQUVhLFNBQVM7QUFBQSxZQUFHLENBQUMsb0JBQW9CYixFQUFFYyxZQUFZO0FBQUEsWUFBRyxDQUFDLG1CQUFtQmQsRUFBRU8sUUFBUTtBQUFBLFlBQUcsQ0FBQyxXQUFXUCxFQUFFUSxJQUFJO0FBQUEsWUFBRyxDQUFDLGdCQUFnQlIsRUFBRWUsY0FBYztBQUFBLFlBQUcsQ0FBQyxnQkFBZ0JmLEVBQUVnQixlQUFlO0FBQUEsWUFBRyxDQUFDLGdCQUFnQmhCLEVBQUVpQixZQUFZO0FBQUEsWUFBRyxDQUFDLGtCQUFrQmpCLEVBQUVrQixXQUFXO0FBQUEsWUFBRyxDQUFDLGNBQWNsQixFQUFFbUIsU0FBUztBQUFBLFlBQUcsQ0FBQyxnQkFBZ0JuQixFQUFFb0Isc0JBQXNCO0FBQUEsVUFBQyxFQUMvV3BFLElBQUksQ0FBQyxDQUFDcUUsT0FBT2xHLEtBQUssTUFBTSx1QkFBQyxjQUErQixPQUFPbUcsT0FBT0QsS0FBSyxHQUFHLGlDQUFDLFVBQU8sTUFBSSxNQUFDLE9BQU8sT0FBT2xHLFVBQVUsV0FBV0EsUUFBUSxRQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RCxLQUFsR21HLE9BQU9ELEtBQUssR0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0gsQ0FBYTtBQUFBLFVBQzdKLHVCQUFDLGNBQVcsT0FBTSxjQUFjckIsWUFBRXVCLGlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hELHVCQUFDLGNBQVcsT0FBTSxlQUFlNUgsbUJBQVNxRyxFQUFFbEQsTUFBTWhCLEtBQUtFLFFBQVEsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNoRWdFLEVBQUVqRCxTQUFTQyxJQUFJLENBQUF3RSxZQUFXLHVCQUFDLFNBQW9CLFVBQVMsV0FBVSxJQUFJdkcsU0FBU2lDLFFBQVFDLGVBQWdCcUUscUJBQWpFQSxTQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGLENBQVE7QUFBQSxhQU41SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQU0sT0FBTSxvQkFBbUIsVUFBUyx5REFBd0QsVUFBUyxTQUNyR0MscUJBQVcsbUNBQ1I7QUFBQSxpQ0FBQyxTQUFNLFVBQVMsUUFBTyxJQUFJeEcsU0FBU3lHLE9BQU9DLFVBQVUsa0lBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVLO0FBQUEsVUFDdkssdUJBQUMsY0FDRyxpQ0FBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLHNCQUFxQixPQUFPMUIsVUFBVSxVQUFVLENBQUEyQixVQUFTO0FBQUUxQix3QkFBWTBCLE1BQU1DLE9BQU8xRyxLQUE2QjtBQUFHaUYsNEJBQWdCLEVBQUU7QUFBQSxVQUFHLEdBQzVKcEYsOEJBQW9CZ0MsSUFBSSxDQUFBOEUsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLekYsSUFBS3lGLGVBQUszSixTQUEvQjJKLEtBQUt6RixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRCxDQUFXLEtBRHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxlQUFZLFdBQVUsVUFBUyxXQUFVLFFBQ3RDLGlDQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVMsTUFBTStELGdCQUFnQkMsVUFBVSxHQUFHLFVBQVUsQ0FBQ0EsWUFBWSx1Q0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0gsS0FEMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NDLGVBQWUsdUJBQUMsa0JBQWUsV0FBVSxXQUN0QyxpQ0FBQyxPQUFJLE1BQUssVUFBUyxjQUFXLCtCQUE4QixlQUFZLDJCQUEwQixJQUFJLEVBQUUsR0FBR3JGLFNBQVNpQyxRQUFRNkUsT0FBT0MsUUFBUSxHQUFHQyxhQUFhLFdBQVdDLGNBQWM3SyxTQUFTOEssT0FBT0MsUUFBUSxHQUN4TTtBQUFBLG1DQUFDLGNBQVcsSUFBSW5ILFNBQVN5RyxPQUFPQyxVQUFXckIsc0JBQVkrQixVQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLGNBQVcsU0FBUSxhQUFZLElBQUlwSCxTQUFTYyxPQUFPdUcsb0JBQW9CLDRDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLFlBQ25HaEMsWUFBWWlDLFFBQVF2RixJQUFJLENBQUF3RixXQUFVLHVCQUFDLGNBQThCLE9BQU9BLE9BQU9ySyxPQUFRcUssaUJBQU9ySCxTQUEzQ3FILE9BQU9ySyxPQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRSxDQUFhO0FBQUEsWUFDakhtSSxZQUFZdkQsU0FBU0MsSUFBSSxDQUFDd0UsU0FBU2lCLFVBQVUsdUJBQUMsU0FBa0MsVUFBUyxXQUFVLElBQUl4SCxTQUFTeUcsT0FBT2dCLFlBQWFsQixxQkFBM0UsR0FBR2lCLEtBQUssSUFBSWpCLE9BQU8sSUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0YsQ0FBUTtBQUFBLFlBQ3JKLHVCQUFDLGtCQUFlLFFBQVF4QixLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQjtBQUFBLGVBTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUEsS0FQWTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFoQjtBQUFBLGFBbEJRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQlosSUFBTSx1QkFBQyxTQUFNLFVBQVMsUUFBTywrR0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSCxLQXBCaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFdBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQkE7QUFBQSxTQXRDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNOLEtBeENZO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5Q2hCLElBQWdCLHVCQUFDLFNBQU0sVUFBUyxTQUFRLHNEQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThEO0FBQUEsT0E1QzNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2Q1A7QUFDSjtBQUFDRCxJQXZEZUQsZ0JBQWM7QUFBQSxVQUNUdEcsVUFDRnZCLGdCQUNGb0IsTUFBTTtBQUFBO0FBQUEsTUFIUHlHO0FBd0RULGdCQUFTNkMsZUFBZTtBQUFBQyxNQUFBO0FBQzNCLFFBQU10RixPQUFPakUsT0FBTyxnQkFBZ0IsRUFBRTZDLE9BQU96QyxhQUFhLGNBQWMsRUFBRSxDQUFDO0FBQzNFLFFBQU0sQ0FBQ29KLGVBQWNDLGdCQUFnQixJQUFFbkssZ0JBQWdCO0FBQ3ZELFFBQU1vSyxTQUFPRixjQUFjRyxJQUFJLFdBQVc7QUFDMUMsUUFBTUMsWUFBVUEsQ0FBQzVHLE9BQWlCO0FBQUMsVUFBTTZHLE9BQUssSUFBSUMsZ0JBQWdCTixhQUFhO0FBQUUsUUFBR3hHLEdBQUc2RyxNQUFLRSxJQUFJLGFBQVkvRyxFQUFFO0FBQUEsUUFBTzZHLE1BQUtHLE9BQU8sV0FBVztBQUFFUCxxQkFBaUJJLElBQUk7QUFBQSxFQUFFO0FBQ3JLLFFBQU12RixTQUFTdEUsT0FBTyxjQUFjLEVBQUV1RSxNQUFNLEVBQUUwRixZQUFZUCxVQUFVLEdBQUcsRUFBRSxHQUFHbEYsUUFBUWtGLE1BQU0sQ0FBQztBQUMzRixRQUFNUSxnQkFBZ0I1RixPQUFPMUIsTUFBTUE7QUFDbkMsUUFBTXNCLE9BQUtqRSxXQUFXLGVBQWMsQ0FBQyxnQkFBZSxjQUFhLGFBQVksbUJBQWtCLG1CQUFrQixpQkFBZ0IsYUFBYSxDQUFDLEdBQUVrRSxVQUFRbEUsV0FBVyxrQkFBaUIsQ0FBQyxnQkFBZSxjQUFhLGFBQVksbUJBQWtCLG1CQUFrQixpQkFBZ0IsYUFBYSxDQUFDO0FBQ2hTLFFBQU0sQ0FBQzJFLE1BQUtDLE9BQU8sSUFBRXhGLFNBQVMsS0FBSyxHQUFFLENBQUM4SyxhQUFZQyxjQUFjLElBQUUvSyxTQUF1QixJQUFJLEdBQUUsQ0FBQ2dMLE9BQU1DLFFBQVEsSUFBRWpMLFNBQVMsS0FBSyxHQUFFLENBQUN5RixVQUFTQyxXQUFXLElBQUUxRixTQUF5RCxJQUFJO0FBQ3BOLFNBQU8sbUNBQUdnTDtBQUFBQSxhQUFPLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBUyw2REFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRjtBQUFBLElBQVMsdUJBQUMsY0FBVyxPQUFNLFlBQVcsVUFBUyxpRkFBZ0YsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVEsYUFBWSxTQUFTLE1BQU07QUFBQ0QscUJBQWUsSUFBSTtBQUFFdkYsY0FBUSxJQUFJO0FBQUEsSUFBRSxHQUFHLGlDQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFJLEtBQXBRO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc1I7QUFBQSxJQUFFLHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsa0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBT1osTUFBTSxnQkFBZSxXQUFXQSxlQUFLckIsUUFBUSxtQ0FBRTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxzQkFBcUIsTUFBTXFCLEtBQUtyQixLQUFLQSxNQUFNLFFBQVEsQ0FBQTJILFlBQVdBLFFBQVF2SCxJQUFJLFNBQVM7QUFBQSxVQUNubEIsRUFBRXFDLEtBQUssTUFBTXZHLE9BQU8sWUFBWXdHLFFBQVFBLENBQUFpRixZQUFXLHVCQUFDLFVBQU8sU0FBUyxNQUFNWCxVQUFVVyxRQUFRdkgsRUFBRSxHQUFJdUgsa0JBQVF2SCxNQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRCxFQUFVO0FBQUEsVUFDdkgsRUFBRXFDLEtBQUssUUFBUXZHLE9BQU8saUJBQWlCd0csUUFBUUEsQ0FBQWlGLFlBQVcvSixlQUFlK0osUUFBUUMsYUFBYSxFQUFFO0FBQUEsVUFDaEcsRUFBRW5GLEtBQUssVUFBVXZHLE9BQU8sU0FBU3dHLFFBQVFBLENBQUFpRixZQUFXLEdBQUd4TCxjQUFjd0wsUUFBUUUsVUFBVSxDQUFDLG1CQUFtQkYsUUFBUUcsUUFBUSxHQUFHO0FBQUEsVUFDOUgsRUFBRXJGLEtBQUssU0FBU3ZHLE9BQU8sY0FBY3dHLFFBQVFBLENBQUFpRixZQUFXLHVCQUFDLFVBQU8sT0FBT0EsUUFBUTdFLFVBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCLEVBQUc7QUFBQSxVQUN6RixFQUFFTCxLQUFLLFdBQVd2RyxPQUFPLElBQUl3RyxRQUFRQSxDQUFBaUYsWUFBVyx1QkFBQyxVQUFPLFNBQVMsTUFBTVgsVUFBVVcsUUFBUXZILEVBQUUsR0FBRyx3QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0QsRUFBVTtBQUFBLFFBQUMsS0FMOFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1qZjtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNaUIsS0FBS3JCLEtBQUsrQyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FOaWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU0vYyxLQU4rWTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTTNZO0FBQUEsU0FOaVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1wVjtBQUFBLElBQ25ELHVCQUFDLGNBQVcsTUFBTW5CLFFBQVFrRixNQUFNLEdBQUcsT0FBT1EsZ0JBQWdCLFlBQVlBLGNBQWNsSCxFQUFFLEtBQUsscUJBQXFCLFNBQVMsTUFBTTRHLFVBQVUsSUFBSSxHQUFHLFNBQVMsdUJBQUMsVUFBTyxTQUFTLE1BQU1BLFVBQVUsSUFBSSxHQUFHLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDLEdBQVcsaUNBQUMsY0FBVyxPQUFPdEYsUUFBUzRGLDJCQUFpQixtQ0FBRTtBQUFBLDZCQUFDLFVBQU8sT0FBT0EsY0FBY3hFLFVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUFFLHVCQUFDLGFBQVUsT0FBTSx5QkFBd0IsTUFBTXdFLGNBQWNTLE1BQU1oSCxJQUFJLENBQUNpSCxNQUFNeEIsV0FBVyxFQUFFLEdBQUd3QixNQUFNdkYsS0FBSzRDLE9BQU9tQixLQUFLLEVBQUUsRUFBRSxHQUFHLFFBQVEsQ0FBQXdCLFNBQVFBLEtBQUt2RixLQUFLLFNBQVM7QUFBQSxRQUNoYyxFQUFFQSxLQUFLLFdBQVd2RyxPQUFPLGFBQWF3RyxRQUFRQSxDQUFBc0YsU0FBUUEsS0FBS0MsVUFBVTtBQUFBLFFBQ3JFLEVBQUV4RixLQUFLLFNBQVN2RyxPQUFPLE1BQU13RyxRQUFRQSxDQUFBc0YsU0FBUSx1QkFBQyxVQUFPLE9BQU9BLEtBQUtFLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEIsRUFBRztBQUFBLFFBQzFFLEVBQUV6RixLQUFLLFVBQVV2RyxPQUFPLE1BQU13RyxRQUFRQSxDQUFBc0YsU0FBUSx1QkFBQyxVQUFPLE9BQU9BLEtBQUtHLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsRUFBRztBQUFBLFFBQzVFLEVBQUUxRixLQUFLLFFBQVF2RyxPQUFPLGFBQWF3RyxRQUFRQSxDQUFBc0YsU0FBUUEsS0FBS25GLFlBQVk7QUFBQSxNQUFDLEtBSjROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLblM7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBTSxjQUFjeUUsd0JBQWNoQyxpQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLGdCQUFnQmdDLHdCQUFjYyxjQUFjLE9BQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxNQUFjZCxjQUFjeEUsV0FBUyxjQUFZLENBQUMsQ0FBQyxtQkFBa0IsaUJBQWdCLGlCQUFnQixxQkFBb0Isa0JBQWlCLHFCQUFvQixrQkFBa0IsRUFBRU8sU0FBU2lFLGNBQWNPLFVBQVUsS0FBRyx1QkFBQyxrQkFBZSxZQUFXLGdCQUFlLFNBQVMsTUFBSTtBQUFDTCx1QkFBZUYsYUFBYTtBQUFFTixrQkFBVSxJQUFJO0FBQUUvRSxnQkFBUSxJQUFJO0FBQUEsTUFBRSxHQUFHLGlDQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdJO0FBQUEsTUFBbUJxRixjQUFjeEUsV0FBVyxXQUFXLHVCQUFDLGtCQUFlLFlBQVcsZ0JBQWUsU0FBUyxNQUFNWCxZQUFZLEVBQUV3RixTQUFTTCxlQUFlbEUsUUFBUSxPQUFPLENBQUMsR0FBRyxzQkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SDtBQUFBLE1BQW1Ca0UsY0FBY3hFLFdBQVcsWUFBWSxDQUFDLENBQUMsbUJBQWtCLGlCQUFnQixpQkFBZ0IscUJBQW9CLGtCQUFpQixxQkFBb0Isa0JBQWtCLEVBQUVPLFNBQVNpRSxjQUFjTyxVQUFVLEtBQUssdUJBQUMsa0JBQWUsWUFBVyxnQkFBZSxTQUFTLE1BQU0xRixZQUFZLEVBQUV3RixTQUFTTCxlQUFlbEUsUUFBUSxVQUFVLENBQUMsR0FBRyw0QkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSTtBQUFBLFNBTC92QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS2l4QixLQUw5ekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtrMEIsS0FMbGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLK2hDO0FBQUEsSUFDOWhDcEIsUUFBTSx1QkFBQyxpQkFBMkMsYUFBMEIsU0FBUyxNQUFJQyxRQUFRLEtBQUssR0FBRyxTQUFTLE1BQUl5RixTQUFTLElBQUksS0FBekdILGFBQWFuSCxNQUFJLE9BQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0g7QUFBQSxJQUN0SSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQzhCLFVBQVUsT0FBT0EsVUFBVWtCLFdBQVcsU0FBUyxvQkFBb0IsZ0JBQWdCLGNBQWNsQixVQUFVa0IsV0FBVyxTQUFTLG9CQUFvQixnQkFBZ0IsYUFBYSxZQUFZbEIsVUFBVXlGLFFBQVF2SCxNQUFNLEVBQUUsS0FBSzhCLFVBQVVrQixXQUFXLFNBQVMsaUdBQWlHLHVEQUF1RCxJQUFJLGVBQWVsQixVQUFVa0IsV0FBVyxXQUFXLFNBQVMsTUFBTWpCLFlBQVksSUFBSSxHQUFHLE9BQU9iLEtBQUtpQyxTQUFTaEMsUUFBUWdDLE9BQU8sTUFBTWpDLEtBQUtnQyxXQUFXL0IsUUFBUStCLFNBQVMsV0FBVyxDQUFBK0Usa0JBQWlCbkcsVUFBVWtCLFdBQVcsU0FBUzlCLEtBQUttQyxRQUFRLEVBQUU5QixNQUFNLEVBQUUwRixZQUFZbkYsU0FBU3lGLFFBQVF2SCxHQUFHLEdBQUdzRCxNQUFNLEVBQUVDLGlCQUFpQnpCLFNBQVN5RixRQUFRL0QsUUFBUSxFQUFFLENBQUMsSUFBSXJDLFFBQVFrQyxRQUFRLEVBQUU5QixNQUFNLEVBQUUwRixZQUFZbkYsVUFBVXlGLFFBQVF2SCxNQUFNLEdBQUcsR0FBR3NELE1BQU0sRUFBRUMsaUJBQWlCekIsVUFBVXlGLFFBQVEvRCxXQUFXLEdBQUdKLFFBQVE2RSxjQUFjLEVBQUUsQ0FBQyxLQUEzNEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2NEI7QUFBQSxPQWR0NEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWN3NEI7QUFDbjVCO0FBQUMxQixJQXhCZUQsY0FBWTtBQUFBLFVBQ1h0SixRQUFnQ0ksY0FDTmQsaUJBR3hCVSxRQUVKQyxZQUE4SUEsVUFBVTtBQUFBO0FBQUEsTUFQdkpxSjtBQTBCVCxnQkFBUzRCLHFCQUFxQjtBQUFBQyxNQUFBO0FBQ2pDLFFBQU0sRUFBRTFJLEtBQUssSUFBSXRDLFNBQVM7QUFDMUIsUUFBTSxDQUFDaUwsUUFBUUMsU0FBUyxJQUFJL0wsZ0JBQWdCO0FBQzVDLFFBQU1nTSxlQUFlRixPQUFPekIsSUFBSSxLQUFLO0FBQ3JDLFFBQU00QixNQUFNRCxpQkFBaUIsU0FBU0EsaUJBQWlCLFVBQVVBLGVBQWU7QUFDaEYsUUFBTUUsUUFBUXhMLE9BQU8sd0JBQXdCLEVBQUU2QyxPQUFPekMsYUFBYSx3QkFBd0IsWUFBWSxFQUFFLENBQUM7QUFDMUcsUUFBTXFMLE1BQU16TCxPQUFPLHNCQUFzQixFQUFFNkMsT0FBT3pDLGFBQWEsc0JBQXNCLFdBQVcsRUFBRSxDQUFDO0FBQ25HLFFBQU1zTCxRQUFRMUwsT0FBTywyQkFBMkIsRUFBRTZDLE9BQU96QyxhQUFhLDJCQUEyQixZQUFZLEVBQUUsQ0FBQztBQUNoSCxRQUFNdUwsUUFBUTFMLFdBQVcsc0JBQXNCLENBQUMsc0JBQXNCLHdCQUF3QixpQkFBaUIsYUFBYSxDQUFDO0FBQzdILFFBQU0yTCxZQUFZM0wsV0FBVyxtQkFBbUIsQ0FBQywyQkFBMkIsd0JBQXdCLGVBQWUsQ0FBQztBQUNwSCxRQUFNLENBQUM2RSxVQUFVQyxXQUFXLElBQUkxRixTQUErQixJQUFJLEdBQUcsQ0FBQ3dNLFVBQVVDLE9BQU8sSUFBSXpNLFNBQW9DLElBQUksR0FBRyxDQUFDME0sYUFBYUMsY0FBYyxJQUFJM00sU0FBUyxFQUFFLEdBQUcsQ0FBQzRNLE1BQU1DLE9BQU8sSUFBSTdNLFNBQVMsR0FBRyxHQUFHLENBQUM4TSxVQUFVQyxXQUFXLElBQUkvTSxTQUFTLEVBQUUsR0FBRyxDQUFDNEssWUFBWW9DLFdBQVcsSUFBSWhOLFNBQVMsRUFBRSxHQUFHLENBQUNpTixZQUFZQyxhQUFhLElBQUlsTixTQUFTLEVBQUUsR0FBRyxDQUFDK0csUUFBUW9HLFNBQVMsSUFBSW5OLFNBQVMsRUFBRSxHQUFHLENBQUNvTixZQUFZQyxTQUFTLElBQUlyTixTQUFTLEtBQUs7QUFDaGEsUUFBTXNOLGNBQWN6TSxZQUFZLHdCQUF3QixDQUFDLEdBQUdzRSxRQUFRTSxRQUFRLENBQUM7QUFDN0UsUUFBTThILFdBQVc1TSxPQUFPLHNCQUFzQixFQUFFdUUsTUFBTSxFQUFFMEYsWUFBWTRCLFVBQVVnQixpQkFBaUIsR0FBRyxFQUFFLEdBQUdySSxRQUFRcUgsUUFBUSxDQUFDO0FBQ3hILFFBQU1pQixjQUFjNU0sWUFBWSxpQkFBaUIsQ0FBQyxHQUFHc0UsUUFBUXFILFFBQVEsQ0FBQztBQUN0RSxRQUFNa0IsZUFBZWxCLFdBQVdlLFNBQVNoSyxNQUFNQSxPQUFPK0osWUFBWS9KLE1BQU1BLEtBQUtvSyxLQUFLLENBQUF2RSxTQUFRQSxLQUFLekYsT0FBTytJLFdBQVc7QUFDakgsUUFBTWtCLGVBQWVILFlBQVlsSyxNQUFNQSxLQUFLb0ssS0FBSyxDQUFBdkUsU0FBUUEsS0FBS3pGLE9BQU9pSCxVQUFVO0FBQy9FLFFBQU1pRCxXQUFXckwsYUFBYW9LLElBQUksR0FBR2tCLGtCQUFrQnRMLGFBQWF5SyxVQUFVO0FBQzlFLFFBQU1jLGdCQUFnQjVJLFFBQVFNLFlBQVlpSSxnQkFBZ0JHLGFBQWEsUUFBUUEsWUFBWSxNQUFNQSxhQUFhckwsYUFBYWlELFNBQVN1SSxTQUFTL0ssTUFBTSxLQUFLLENBQUMsUUFBUVQsYUFBYWlELFNBQVN1SSxTQUFTL0ssTUFBTSxLQUFLLENBQUMsTUFBTTRLLGFBQWFyTCxhQUFha0wsYUFBYXpLLE9BQU9BLE1BQU0sS0FBSzZKLFNBQVNtQixLQUFLLENBQUM7QUFDMVIsUUFBTUMsaUJBQWlCL0ksUUFBUXFILFlBQVlrQixnQkFBZ0JFLGdCQUFnQixDQUFDQSxhQUFhTyxZQUFZTCxvQkFBb0IsUUFBUUEsa0JBQWtCLE1BQU1BLG9CQUFvQnRMLGFBQWFnSyxTQUFTNEIsV0FBV25MLE1BQU0sS0FBSyxDQUFDLE9BQU82SyxvQkFBb0J0TCxhQUFhb0wsYUFBYVMsa0JBQWtCcEwsTUFBTSxLQUFLLENBQUMsT0FBTzJLLGFBQWFTLGtCQUFrQkMsYUFBYVosYUFBYXpLLE9BQU9xTCxZQUFjWixhQUFhYSxjQUFjLGNBQWVYLGFBQWFXLGNBQWMsaUJBQWtCdk4sZ0JBQWdCK0YsT0FBT2tILEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDNWYsUUFBTU8sWUFBWUEsQ0FBQ0MsUUFBd0JoTSxVQUFvQztBQUMzRSxVQUFNK0gsT0FBTyxJQUFJQyxnQkFBZ0JzQixNQUFNO0FBQ3ZDLFFBQUl0SixVQUFVLE9BQVErSCxNQUFLRyxPQUFPLEtBQUs7QUFBQTtBQUNsQ0gsV0FBS0UsSUFBSSxPQUFPakksS0FBSztBQUMxQnVKLGNBQVV4QixNQUFNLEVBQUVrRSxTQUFTLE1BQU1DLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDdEQ7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLDRCQUEyQixVQUFTLHdFQUF1RSxTQUFTLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFNBQVEsYUFBWSxTQUFTLE1BQU10QixVQUFVLElBQUksR0FBRyxrQ0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSCxLQUEzUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZRO0FBQUEsSUFBRSx1QkFBQyxRQUFLLE9BQU9uQixLQUFLLFVBQVVzQyxXQUFXLElBQUlqTSxTQUFTK0QsS0FBS3NJLGNBQWMsU0FBUSxjQUFhO0FBQUEsNkJBQUMsT0FBSSxPQUFNLFFBQU8sT0FBTSxlQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsTUFBRSx1QkFBQyxPQUFJLE9BQU0sT0FBTSxPQUFNLFNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUFFLHVCQUFDLE9BQUksT0FBTSxTQUFRLE9BQU0sMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxTQUE5TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdOO0FBQUEsSUFBTyx1QkFBQyxTQUFPMUMsa0JBQVEsU0FBUyx1QkFBQyxjQUFXLE9BQU9DLE9BQU8sZ0JBQWUsV0FBV0EsZ0JBQU01SSxRQUFRLG1DQUFFO0FBQUEsNkJBQUMsYUFBVSxPQUFNLDhCQUE2QixNQUFNNEksTUFBTTVJLEtBQUtBLE1BQU0sUUFBUSxDQUFBc0wsUUFBT0EsSUFBSWxMLElBQUksT0FBTSxvREFBbUQsYUFBYSx1QkFBQyxVQUFPLFNBQVMsTUFBTTBKLFVBQVUsSUFBSSxHQUFHLGdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdELEdBQVcsU0FBUztBQUFBLFFBQ3R6QixFQUFFckgsS0FBSyxNQUFNdkcsT0FBTyxxQkFBcUJ3RyxRQUFRQSxDQUFBNEksUUFBT0EsSUFBSUMsc0JBQXNCO0FBQUEsUUFDbEYsRUFBRTlJLEtBQUssV0FBV3ZHLE9BQU8sYUFBYXdHLFFBQVFBLENBQUE0SSxRQUFPQSxJQUFJckQsVUFBVTtBQUFBLFFBQ25FLEVBQUV4RixLQUFLLFNBQVN2RyxPQUFPLFdBQVd3RyxRQUFRQSxDQUFBNEksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUk1TCxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLEVBQUc7QUFBQSxRQUM5RSxFQUFFK0MsS0FBSyxhQUFhdkcsT0FBTyxTQUFTd0csUUFBUUEsQ0FBQTRJLFFBQU9BLElBQUlOLGNBQWMsV0FBVyxhQUFhLFVBQVU7QUFBQSxRQUN2RyxFQUFFdkksS0FBSyxRQUFRdkcsT0FBTyxZQUFZd0csUUFBUUEsQ0FBQTRJLFFBQU9BLElBQUlFLGNBQWM7QUFBQSxRQUNuRSxFQUFFL0ksS0FBSyxTQUFTdkcsT0FBTyxRQUFRd0csUUFBUUEsQ0FBQTRJLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJRyxjQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCLEVBQUc7QUFBQSxNQUFDLEtBTndmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPMWtCO0FBQUEsTUFBRSx1QkFBQyxTQUFNLE1BQU03QyxNQUFNNUksS0FBSytDLE1BQU0sYUFBWSxnQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLFNBUGdoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTzlnQixLQVA0YztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT3hjLElBQWdCNEYsUUFBUSxRQUFRLHVCQUFDLGNBQVcsT0FBT0UsS0FBSyxnQkFBZSxXQUFXQSxjQUFJN0ksUUFBUSxtQ0FBRTtBQUFBLDZCQUFDLGFBQVUsT0FBTSxvQkFBbUIsTUFBTTZJLElBQUk3SSxLQUFLQSxNQUFNLFFBQVEsQ0FBQXNMLFFBQU9BLElBQUlsTCxJQUFJLE9BQU0sb0RBQW1ELFNBQVM7QUFBQSxRQUM5UyxFQUFFcUMsS0FBSyxNQUFNdkcsT0FBTyxXQUFXd0csUUFBUUEsQ0FBQTRJLFFBQU9BLElBQUlJLGdCQUFnQjtBQUFBLFFBQ2xFLEVBQUVqSixLQUFLLFdBQVd2RyxPQUFPLGVBQWV3RyxRQUFRQSxDQUFBNEksUUFBT0EsSUFBSUssVUFBVTtBQUFBLFFBQ3JFLEVBQUVsSixLQUFLLFNBQVN2RyxPQUFPLFlBQVl3RyxRQUFRQSxDQUFBNEksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUliLFlBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsRUFBRztBQUFBLFFBQ2pGLEVBQUVoSSxLQUFLLE9BQU92RyxPQUFPLGVBQWV3RyxRQUFRQSxDQUFBNEksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUlNLGNBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEIsRUFBRztBQUFBLFFBQ3BGLEVBQUVuSixLQUFLLFFBQVF2RyxPQUFPLG1CQUFtQndHLFFBQVFBLENBQUE0SSxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSU8sZ0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsRUFBRztBQUFBLFFBQzNGLEVBQUVwSixLQUFLLFNBQVN2RyxPQUFPLGNBQWN3RyxRQUFRQSxDQUFBNEksUUFBTyx1QkFBQyxVQUFPLE9BQU9BLElBQUl4SSxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLEVBQUc7QUFBQSxRQUNqRixFQUFFTCxLQUFLLFVBQVV2RyxPQUFPLElBQUl3RyxRQUFRQSxDQUFBNEksUUFBTyx1QkFBQyxrQkFBZSxZQUFXLHFCQUFvQixVQUFVQSxJQUFJeEksV0FBVyxXQUFXLFNBQVMsTUFBTTtBQUFFWCxzQkFBWW1KLEdBQUc7QUFBR2xDLHlCQUFlLEVBQUU7QUFBR0Usa0JBQVFnQyxJQUFJTSxXQUFXbE0sTUFBTTtBQUFHOEosc0JBQVksRUFBRTtBQUFBLFFBQUcsR0FBRyx5QkFBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TSxFQUFrQjtBQUFBLE1BQUMsS0FQekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVE5SjtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNWCxJQUFJN0ksS0FBSytDLE1BQU0sYUFBWSxlQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FSdUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFyRyxLQVJ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUW5DLElBQWdCLHVCQUFDLGNBQVcsT0FBTytGLE9BQU8sZ0JBQWUsV0FBV0EsZ0JBQU05SSxRQUFRLG1DQUFFO0FBQUEsNkJBQUMsYUFBVSxPQUFNLDJCQUEwQixNQUFNOEksTUFBTTlJLEtBQUtBLE1BQU0sUUFBUSxDQUFBc0wsUUFBT0EsSUFBSWxMLElBQUksT0FBTSw4REFBNkQsU0FBUztBQUFBLFFBQ2xULEVBQUVxQyxLQUFLLE1BQU12RyxPQUFPLE1BQU13RyxRQUFRQSxDQUFBNEksUUFBT0EsSUFBSWxMLEdBQUc7QUFBQSxRQUNoRCxFQUFFcUMsS0FBSyxlQUFldkcsT0FBTyxhQUFhd0csUUFBUUEsQ0FBQTRJLFFBQU8xQyxNQUFNNUksTUFBTUEsS0FBS29LLEtBQUssQ0FBQWpCLGlCQUFlQSxhQUFZL0ksT0FBT2tMLElBQUlyQixhQUFhLEdBQUdzQix5QkFBeUJELElBQUlyQixjQUFjO0FBQUEsUUFDaEwsRUFBRXhILEtBQUssU0FBU3ZHLE9BQU8sY0FBY3dHLFFBQVFBLENBQUE0SSxRQUFPLHVCQUFDLFVBQU8sT0FBT0EsSUFBSVEsU0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QixFQUFHO0FBQUEsUUFDaEYsRUFBRXJKLEtBQUssVUFBVXZHLE9BQU8sYUFBYXdHLFFBQVFBLENBQUE0SSxRQUFPQSxJQUFJOUgsT0FBTztBQUFBLFFBQy9ELEVBQUVmLEtBQUssVUFBVXZHLE9BQU8sSUFBSXdHLFFBQVFBLENBQUE0SSxRQUFPLHVCQUFDLGtCQUFlLFlBQVcscUJBQW9CLFVBQVVBLElBQUlRLFVBQVUsV0FBVyxTQUFTLE1BQU07QUFBRTVDLGtCQUFRb0MsR0FBRztBQUFHbEMseUJBQWVrQyxJQUFJckIsYUFBYTtBQUFHUixzQkFBWSxFQUFFO0FBQUdFLHdCQUFjLEVBQUU7QUFBR0Msb0JBQVUsRUFBRTtBQUFBLFFBQUcsR0FBRyw4QkFBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TixFQUFrQjtBQUFBLE1BQUMsS0FMekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU0vSTtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNZCxNQUFNOUksS0FBSytDLE1BQU0sYUFBWSxnQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLFNBTnFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNbkYsS0FOaUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1iLEtBckIrYTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJqYTtBQUFBLElBQzlFLHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUNiLFVBQVUsT0FBTSxpQkFBZ0IsU0FBUyxNQUFNQyxZQUFZLElBQUksR0FBRyxNQUFNNEcsTUFBTXpGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNrSCxpQkFBaUJ6QixNQUFNekYsU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJO0FBQUUsY0FBTXlGLE1BQU10RixRQUFRLEVBQUU5QixNQUFNLEVBQUUwRixZQUFZbkYsVUFBVTlCLE1BQU0sR0FBRyxHQUFHc0QsTUFBTSxFQUFFQyxpQkFBaUJ6QixVQUFVMEIsV0FBVyxHQUFHbUksbUJBQW1CNUMsYUFBYXlDLFlBQVksRUFBRWxNLFFBQVEySixNQUFNMEIsVUFBVWxMLEtBQUtrTCxTQUFTLEdBQUdpQixnQkFBZ0J6QyxVQUFVL0YsUUFBUSw0Q0FBNEMsRUFBRSxDQUFDO0FBQUdyQixvQkFBWSxJQUFJO0FBQUEsTUFBRyxRQUFRO0FBQUEsTUFBRTtBQUFBLElBQWdCLEdBQUcsNkJBQWhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNmIsR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBTzRHLE1BQU14RixTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU93RyxhQUFjQSxzQkFBWS9KLFFBQVEsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sMEJBQXlCLE9BQU9tSixhQUFhLFVBQVUsQ0FBQXhELFVBQVN5RCxlQUFlekQsTUFBTUMsT0FBTzFHLEtBQUssR0FBRztBQUFBLGlDQUFDLFlBQVMsT0FBTSxJQUFHLHdDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQVk2SyxZQUFZL0osS0FBS0EsS0FBS2lNLE9BQU8sQ0FBQXBHLFNBQVFBLEtBQUttRixjQUFjLFlBQVluRixLQUFLNEYsZUFBZSxlQUFlNUYsS0FBS25HLE9BQU9xTCxhQUFhN0ksVUFBVXVJLFNBQVNNLFFBQVEsRUFBRWhLLElBQUksQ0FBQThFLFNBQVEsdUJBQUMsWUFBdUIsT0FBT0EsS0FBS3pGLElBQUt5RjtBQUFBQSxpQkFBSzBGO0FBQUFBLFlBQXNCO0FBQUEsWUFBSTVOLFlBQVlrSSxLQUFLbkcsTUFBTTtBQUFBLGVBQWhGbUcsS0FBS3pGLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlHLENBQVc7QUFBQSxhQUF4YztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBjO0FBQUEsUUFBWSx1QkFBQyxrQkFBZSxPQUFNLHVCQUFzQixhQUFhMkosWUFBWW1DLGFBQWEsU0FBU25DLFlBQVlvQyxTQUFTLE1BQU1wQyxZQUFZcUMsZUFBZSxZQUFZckMsWUFBWXNDLFlBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0w7QUFBQSxRQUFFLHVCQUFDLGFBQVUsT0FBTyxnQkFBZ0J4TSxLQUFLa0wsUUFBUSxLQUFLLE9BQU8xQixNQUFNLE9BQU9pQixhQUFhLE1BQU0sWUFBWUgsZ0JBQWdCRyxhQUFhLFFBQVEsQ0FBQ0UsZ0JBQWdCLDJEQUEyRCwyRUFBMkUsVUFBVSxDQUFBN0UsVUFBUzJELFFBQVEzRCxNQUFNQyxPQUFPMUcsS0FBSyxHQUFHLFlBQVksRUFBRW9OLFdBQVcsVUFBVSxLQUF0WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdYO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sbUJBQWtCLE9BQU8vQyxVQUFVLFVBQVUsQ0FBQTVELFVBQVM2RCxZQUFZN0QsTUFBTUMsT0FBTzFHLEtBQUssS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFFBQUUsdUJBQUMsU0FBTSxVQUFTLFdBQVUseUdBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQUE3dUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxdkMsS0FBMXlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd3pDO0FBQUEsU0FBdDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbTZEO0FBQUEsSUFDbjZELHVCQUFDLGNBQVcsTUFBTSxDQUFDLENBQUMrSixVQUFVLE9BQU0sOEJBQTZCLFNBQVMsTUFBTUMsUUFBUSxJQUFJLEdBQUcsTUFBTUYsVUFBVTFGLFNBQVMsU0FBUyx1QkFBQyxVQUFPLFNBQVEsYUFBWSxVQUFVLENBQUNxSCxrQkFBa0IzQixVQUFVMUYsU0FBUyxTQUFTLFlBQVk7QUFBRSxVQUFJO0FBQUUsY0FBTTBGLFVBQVV2RixRQUFRLEVBQUU5QixNQUFNLEVBQUUwRixZQUFZNEIsVUFBVTdJLE1BQU0sR0FBRyxHQUFHc0QsTUFBTSxFQUFFQyxpQkFBaUJzRixVQUFVckYsV0FBVyxHQUFHcUcsZUFBZWQsYUFBYW9ELGFBQWEsQ0FBQyxFQUFFQyxVQUFVLEVBQUVySixNQUFNLFFBQVEvQyxJQUFJaUgsV0FBVyxHQUFHM0gsUUFBUSxFQUFFQSxRQUFRZ0ssWUFBWXFCLFVBQVVsTCxLQUFLa0wsU0FBUyxFQUFFLENBQUMsR0FBR3ZILE9BQU8sRUFBRSxDQUFDO0FBQUcwRixnQkFBUSxJQUFJO0FBQUEsTUFBRyxRQUFRO0FBQUEsTUFBRTtBQUFBLElBQTRCLEdBQUcsb0NBQXZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMmMsR0FBVztBQUFBLDZCQUFDLGVBQVksT0FBT0YsVUFBVXpGLFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUFFLHVCQUFDLGNBQVcsT0FBT3lHLFVBQVdBLG1CQUFTaEssUUFBUSx1QkFBQyxjQUFXLE9BQU9rSyxhQUFjQSxzQkFBWWxLLFFBQVEsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSw0QkFBMkIsT0FBT2dLLFNBQVNoSyxLQUFLQSxLQUFLdUwsdUJBQXVCLFlBQVksRUFBRWtCLFVBQVUsS0FBSyxLQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRIO0FBQUEsUUFBRSx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGlCQUFnQixPQUFPcEYsWUFBWSxVQUFVLENBQUExQixVQUFTOEQsWUFBWTlELE1BQU1DLE9BQU8xRyxLQUFLLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE9BQU0sSUFBRyw2Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUFZZ0wsWUFBWWxLLEtBQUtBLEtBQUtpTSxPQUFPLENBQUFwRyxTQUFRLENBQUNBLEtBQUsrRSxZQUFZbkwsc0JBQXNCb0csS0FBS2lGLGtCQUFrQnBMLE1BQU0sS0FBS21HLEtBQUtpRixrQkFBa0JDLGFBQWFaLGNBQWN6SyxPQUFPcUwsWUFBY1osY0FBY2EsY0FBYyxjQUFlbkYsS0FBS21GLGNBQWMsYUFBYyxFQUFFakssSUFBSSxDQUFBOEUsU0FBUSx1QkFBQyxZQUF1QixPQUFPQSxLQUFLekYsSUFBS3lGO0FBQUFBLGlCQUFLekY7QUFBQUEsWUFBRztBQUFBLFlBQUl5RixLQUFLbUYsY0FBYyxlQUFlLGFBQWE7QUFBQSxZQUFXO0FBQUEsWUFBSXJOLFlBQVlrSSxLQUFLaUYsaUJBQWlCO0FBQUEsZUFBdElqRixLQUFLekYsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUosQ0FBVztBQUFBLGFBQTdsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStsQjtBQUFBLFFBQVksdUJBQUMsa0JBQWUsT0FBTSxXQUFVLGFBQWE4SixZQUFZZ0MsYUFBYSxTQUFTaEMsWUFBWWlDLFNBQVMsTUFBTWpDLFlBQVlrQyxlQUFlLFlBQVlsQyxZQUFZbUMsWUFBN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFPLG9CQUFvQnhNLEtBQUtrTCxRQUFRLEtBQUssT0FBT3JCLFlBQVksT0FBT0EsZUFBZSxNQUFNYSxvQkFBb0IsTUFBTSxZQUFZQSxvQkFBb0IsUUFBUUEsa0JBQWtCLE1BQU0sQ0FBQ0ksaUJBQWlCLHFFQUFxRSxJQUFJLFVBQVUsQ0FBQWhGLFVBQVNnRSxjQUFjaEUsTUFBTUMsT0FBTzFHLEtBQUssR0FBRyxZQUFZLEVBQUVvTixXQUFXLFVBQVUsS0FBclg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1WDtBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBTzlJLFFBQVEsVUFBVSxDQUFBbUMsVUFBU2lFLFVBQVVqRSxNQUFNQyxPQUFPMUcsS0FBSyxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FBaDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBazNDLEtBQXY2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXE3QyxLQUFwK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrL0M7QUFBQSxTQUEvbUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0bkU7QUFBQSxJQUMzbkUySyxjQUFjLHVCQUFDLG1CQUFnQixTQUFTLE1BQU1DLFVBQVUsS0FBSyxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsT0F4QnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QjREO0FBQ3ZFO0FBQUN2QixJQWxEZUQsb0JBQWtCO0FBQUEsVUFDYi9LLFVBQ1diLGlCQUdkVSxRQUF3Q0ksY0FDMUNKLFFBQXNDSSxjQUNwQ0osUUFBMkNJLGNBQzNDSCxZQUNJQSxZQUVFQyxhQUNIRixRQUNHRSxXQUFXO0FBQUE7QUFBQSxNQWJuQmdMO0FBbURULGdCQUFTb0UsWUFBWTtBQUFBQyxNQUFBO0FBQ3hCLFFBQU0sRUFBRTlNLEtBQUssSUFBSXRDLFNBQVM7QUFDMUIsUUFBTSxDQUFDcVAsWUFBV0MsYUFBYSxJQUFFcFEsU0FBUyxLQUFLLEdBQUUsQ0FBQ3FRLGFBQVlDLGNBQWMsSUFBRXRRLFNBQVMsS0FBSztBQUM1RixRQUFNdVEsUUFBUTVQLE9BQU8saUJBQWlCLEVBQUU2QyxPQUFPekMsYUFBYSxlQUFlLEVBQUUsQ0FBQyxHQUFHeVAsVUFBVTdQLE9BQU8sdUJBQXVCO0FBQ3pILFFBQU04UCxRQUFRN1AsV0FBVyx5QkFBeUIsQ0FBQyx1QkFBdUIsQ0FBQztBQUMzRSxRQUFNOFAsU0FBUzlQLFdBQVcsMEJBQTBCLENBQUMsdUJBQXVCLENBQUM7QUFDN0UsUUFBTSxDQUFDNkUsVUFBVUMsV0FBVyxJQUFJMUYsU0FBa0MsSUFBSSxHQUFHLENBQUMyUSxVQUFVQyxXQUFXLElBQUk1USxTQUFTLEVBQUUsR0FBRyxDQUFDK0csUUFBUW9HLFNBQVMsSUFBSW5OLFNBQVMsRUFBRTtBQUNsSixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHFCQUFvQixVQUFTLG1GQUFrRixTQUFTLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVEsYUFBWSxTQUFTLE1BQUlvUSxjQUFjLElBQUksR0FBRyw4QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRyxLQUF6UDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJRO0FBQUEsSUFBR0MsZUFBYSx1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFVBQVMsc0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxJQUFVRixjQUFZLHVCQUFDLHNCQUFtQixTQUFTLE1BQUlDLGNBQWMsS0FBSyxHQUFHLFNBQVMsTUFBSUUsZUFBZSxJQUFJLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUY7QUFBQSxJQUFHLHVCQUFDLFNBQU0sT0FBTSxXQUFVLGlDQUFDLGNBQVcsT0FBT0MsT0FBTyxnQkFBZSxXQUFXQSxnQkFBTWhOLFFBQVEsbUNBQUU7QUFBQSw2QkFBQyxhQUFVLE9BQU0sV0FBVSxNQUFNZ04sTUFBTWhOLEtBQUtBLE1BQU0sUUFBUSxDQUFBd0MsTUFBS0EsRUFBRXBDLElBQUksU0FBUztBQUFBLFFBQ3puQixFQUFFcUMsS0FBSyxNQUFNdkcsT0FBTyxZQUFZd0csUUFBUUEsQ0FBQUYsTUFBS0EsRUFBRXBDLEdBQUc7QUFBQSxRQUFHLEVBQUVxQyxLQUFLLE9BQU92RyxPQUFPLGFBQWF3RyxRQUFRQSxDQUFBRixNQUFLLEdBQUdBLEVBQUU4SyxnQkFBZ0Isb0JBQW9COUssRUFBRStLLGNBQWMsR0FBRztBQUFBLFFBQUcsRUFBRTlLLEtBQUssYUFBYXZHLE9BQU8sUUFBUXdHLFFBQVFBLENBQUFGLE1BQUtBLEVBQUV3SSxjQUFjLGVBQWUsYUFBYSxXQUFXO0FBQUEsUUFBRyxFQUFFdkksS0FBSyxZQUFZdkcsT0FBTyxXQUFXd0csUUFBUUEsQ0FBQUYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVnTCxrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxFQUFHO0FBQUEsUUFBRyxFQUFFL0ssS0FBSyxXQUFXdkcsT0FBTyxXQUFXd0csUUFBUUEsQ0FBQUYsTUFBSyx1QkFBQyxVQUFPLE9BQU9BLEVBQUVzSSxxQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQyxFQUFHO0FBQUEsUUFBRyxFQUFFckksS0FBSyxPQUFPdkcsT0FBTyxXQUFXd0csUUFBUUEsQ0FBQUYsTUFBSzlFLFNBQVM4RSxFQUFFaUwsT0FBTzVOLEtBQUtFLFFBQVEsRUFBRTtBQUFBLFFBQUcsRUFBRTBDLEtBQUssV0FBV3ZHLE9BQU8sY0FBY3dHLFFBQVFBLENBQUFGLE1BQUtBLEVBQUVvSSxXQUFXLG1CQUFtQixRQUFRO0FBQUEsTUFBQyxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRTdpQjtBQUFBLE1BQUUsdUJBQUMsU0FBTSxNQUFNb0MsTUFBTWhOLEtBQUsrQyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsU0FGNGdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFMWdCLEtBRndjO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFcGMsS0FGNmE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVoYTtBQUFBLElBQVEsdUJBQUMsU0FBTSxPQUFNLGNBQWEsV0FBVyxXQUFXLGlDQUFDLGNBQVcsT0FBT2tLLFNBQVMsZ0JBQWUsV0FBVSxpQ0FBQyxhQUFVLE9BQU0sY0FBYSxNQUFNQSxRQUFRak4sTUFBTUEsUUFBUSxJQUFJLFFBQVEsQ0FBQXdDLE1BQUtBLEVBQUVwQyxJQUFJLFNBQVM7QUFBQSxNQUN2UCxFQUFFcUMsS0FBSyxVQUFVdkcsT0FBTyxNQUFNd0csUUFBUUEsQ0FBQUYsTUFBSyxHQUFHNUUsZUFBZTRFLEVBQUVrTCxTQUFTLENBQUMsTUFBTTlQLGVBQWU0RSxFQUFFbUwsT0FBTyxDQUFDLEdBQUc7QUFBQSxNQUFHLEVBQUVsTCxLQUFLLFNBQVN2RyxPQUFPLGNBQWN3RyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFVBQU8sUUFBTyxvQkFBbUIsT0FBT0EsRUFBRXNKLFNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQsRUFBRztBQUFBLE1BQUcsRUFBRXJKLEtBQUssVUFBVXZHLE9BQU8sdUJBQXVCd0csUUFBUUEsQ0FBQUYsTUFBS0EsRUFBRW9MLGVBQWVDLEtBQUssSUFBSSxLQUFLLDJCQUEyQjtBQUFBLE1BQzdVO0FBQUEsUUFDSXBMLEtBQUs7QUFBQSxRQUFVdkcsT0FBTztBQUFBLFFBQUl3RyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVMsTUFBTTtBQUFFTCxzQkFBWUssQ0FBQztBQUFHNkssc0JBQVksRUFBRTtBQUFHekQsb0JBQVUsRUFBRTtBQUFBLFFBQUcsR0FBSXBILFlBQUVzSixVQUFVLFdBQVcsd0JBQXdCLG9CQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdMO0FBQUEsTUFDM047QUFBQSxJQUFDLEtBSjRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLL0osS0FMMEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUt4RyxLQUx3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzNDO0FBQUEsSUFBUSx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQzVKLFlBQVlBLFNBQVM0SixVQUFVLFVBQVUsT0FBTSxtQkFBa0IsY0FBYSxtQkFBa0IsYUFBYSxNQUFNNUosVUFBVTlCLE1BQU0sRUFBRSxRQUFROEIsVUFBVXdMLGFBQWEsRUFBRSxRQUFReEwsVUFBVXlMLFdBQVcsRUFBRSx1R0FBdUcsU0FBUyxNQUFNeEwsWUFBWSxJQUFJLEdBQUcsTUFBTStLLE1BQU01SixTQUFTLE9BQU80SixNQUFNM0osT0FBTyxXQUFXLE1BQU0ySixNQUFNekosUUFBUSxFQUFFOUIsTUFBTSxFQUFFMEYsWUFBWW5GLFVBQVU5QixNQUFNLEdBQUcsR0FBR3NELE1BQU0sRUFBRUMsaUJBQWlCekIsVUFBVTBCLFdBQVcsRUFBRSxFQUFFLENBQUMsS0FBNWdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOGdCO0FBQUEsSUFBRSx1QkFBQyxjQUFXLE1BQU0xQixVQUFVNEosVUFBVSxVQUFVLE9BQU0scUJBQW9CLFNBQVMsTUFBTTNKLFlBQVksSUFBSSxHQUFHLE1BQU1nTCxPQUFPN0osU0FBUyxTQUFTLHVCQUFDLFVBQU8sVUFBVSxDQUFDOEosWUFBWTNQLGdCQUFnQitGLE1BQU0sSUFBSSxLQUFLMkosT0FBTzdKLFNBQVMsU0FBUyxZQUFZO0FBQUUsVUFBSTtBQUN6eEIsY0FBTTZKLE9BQU8xSixRQUFRLEVBQUU5QixNQUFNLEVBQUUwRixZQUFZbkYsVUFBVTlCLE1BQU0sR0FBRyxHQUFHc0QsTUFBTSxFQUFFQyxpQkFBaUJ6QixVQUFVMEIsV0FBVyxHQUFHa0ssWUFBWVYsVUFBVTVKLE9BQU8sRUFBRSxDQUFDO0FBQ2xKckIsb0JBQVksSUFBSTtBQUFBLE1BQ3BCLFFBQ007QUFBQSxNQUFFO0FBQUEsSUFBZ0IsR0FBRyx5QkFKeXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJaHBCLEdBQVc7QUFBQSw2QkFBQyxlQUFZLE9BQU9nTCxPQUFPNUosU0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQUUsdUJBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSx3QkFBdUIsT0FBTzZKLFVBQVUsVUFBVSxDQUFBVyxNQUFLVixZQUFZVSxFQUFFbkksT0FBTzFHLEtBQUssS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBT3NFLFFBQVEsVUFBVSxDQUFBdUssTUFBS25FLFVBQVVtRSxFQUFFbkksT0FBTzFHLEtBQUssS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc007QUFBQSxTQUppUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSXBRO0FBQUEsT0FYOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVcyUztBQUN0VDtBQUFDeU4sSUFuQmVELFdBQVM7QUFBQSxVQUNKblAsVUFFSEgsUUFBaUNJLGNBQTRDSixRQUM3RUMsWUFDQ0EsVUFBVTtBQUFBO0FBQUEsTUFMYnFQO0FBQVMsSUFBQXNCLElBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDO0FBQUEsYUFBQUwsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidmlzdWFsU3giLCJKb3VybmFsRWRpdG9yIiwiRmluYW5jZUVudHJ5RWRpdG9yIiwiZmluYW5jZUVudHJ5Q2xhc3NlcyIsImNsYXNzZXMiLCJTdGF0ZW1lbnREaWFsb2ciLCJCb29rUHJvdmVuYW5jZSIsIkNyZWF0ZVBlcmlvZERpYWxvZyIsIk9wZW5pbmdCYWxhbmNlc1BhZ2UiLCJMZWRnZXJQYWdlIiwiVHJpYWxCYWxhbmNlUGFnZSIsIkJhbGFuY2VTaGVldFBhZ2UiLCJ1c2VSZXBvcnRSYW5nZSIsIlJlcG9ydFJhbmdlRmllbGRzIiwibGFiZWwiLCJidXNpbmVzc0xhYmVsIiwiQWNjb3VudHNQYWdlIiwiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU3VyZmFjZUNvbnRlbnQiLCJ1c2VTdGF0ZSIsInVzZVNlYXJjaFBhcmFtcyIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiTWVudUl0ZW0iLCJTdGFjayIsIlRhYiIsIlRhYnMiLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVBhZ2VkQXBpIiwidXNlU2NvcGUiLCJ1c2VMaXN0UXVlcnkiLCJjb2RlUG9pbnRMZW5ndGgiLCJkYXRlVGltZSIsImZvcm1hdE1vbmV5IiwiZm9ybWF0RGF0ZU9ubHkiLCJBbW91bnQiLCJDb25maXJtRGlhbG9nIiwiRGF0YVRhYmxlIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkxvb2t1cExvYWRNb3JlIiwiTXV0YXRpb25CdXR0b24iLCJQYWdlSGVhZGVyIiwiUGFnZXIiLCJQYW5lbCIsIlF1ZXJ5U3RhdGUiLCJSb3V0ZUxpbmsiLCJTdGF0IiwiU3RhdHMiLCJTdGF0dXMiLCJUb29sYmFyIiwiZXhwbGFpblByb2ZpdExvc3MiLCJwcm9maXRMb3NzUXVlc3Rpb25zIiwibGF5b3V0U3giLCJkZWNpbWFsVW5pdHMiLCJ2YWx1ZSIsInRlc3QiLCJ3aG9sZSIsImZyYWN0aW9uIiwic3BsaXQiLCJCaWdJbnQiLCJwYWRFbmQiLCJoYXNPdXRzdGFuZGluZ0JhbGFuY2UiLCJhbW91bnQiLCJDYXNoZmxvd1BhZ2UiLCJfcyIsInNob3AiLCJyZXBvcnQiLCJ0aW1lem9uZSIsImRhdGEiLCJxdWVyeSIsInZhbGlkIiwiYyIsImlkIiwicmFuZ2UiLCJzZXRGcm9tIiwic2V0VG8iLCJyZWNlaXB0cyIsImRpc2J1cnNlbWVudHMiLCJuZXRDYXNoTW92ZW1lbnQiLCJmcm9tIiwidG8iLCJhc09mIiwid2FybmluZ3MiLCJtYXAiLCJ3Iiwic3VyZmFjZSIsInNlY3Rpb25CZWZvcmUiLCJFbnRyaWVzUGFnZSIsIl9zMiIsImxpc3QiLCJwb3N0IiwicmV2ZXJzZSIsImVudHJ5SWQiLCJzZXRFbnRyeUlkIiwiZGV0YWlsIiwicGF0aCIsIkJvb2xlYW4iLCJzZWxlY3RlZEVudHJ5IiwiZWRpdGluZyIsInNldEVkaXRpbmciLCJvcGVuIiwic2V0T3BlbiIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJlbnRyeVNhdmVkIiwic2V0RW50cnlTYXZlZCIsImJlZ2luIiwiZW50cnkiLCJyIiwia2V5IiwicmVuZGVyIiwib2NjdXJyZWRBdCIsImNsYXNzaWZpY2F0aW9uIiwiZGVzY3JpcHRpb24iLCJzdGF0dXMiLCJwYWdlIiwic3RhdGVHYXAiLCJraW5kIiwic291cmNlUmVmIiwidHlwZSIsImFjdGlvbiIsImluY2x1ZGVzIiwicGVuZGluZyIsImVycm9yIiwicmVhc29uIiwiZXhlY3V0ZSIsImJvZHkiLCJleHBlY3RlZFZlcnNpb24iLCJ2ZXJzaW9uIiwiUHJvZml0TG9zc1BhZ2UiLCJfczMiLCJwIiwicXVlc3Rpb24iLCJzZXRRdWVzdGlvbiIsImdlbmVyYXRlZEtleSIsInNldEdlbmVyYXRlZEtleSIsImN1cnJlbnRLZXkiLCJleHBsYW5hdGlvbiIsIm5ldFNhbGVzIiwiY29ncyIsImdyb3NzUHJvZml0Iiwib3BlcmF0aW5nUHJvZml0IiwiY29tcGxldGVuZXNzIiwiZ3Jvc3NTYWxlcyIsImRpc2NvdW50cyIsInNhbGVzUmV0dXJucyIsInNoaXBwaW5nSW5jb21lIiwic2hpcHBpbmdFeHBlbnNlIiwicGxhdGZvcm1GZWVzIiwicGF5bWVudEZlZXMiLCJhaUV4cGVuc2UiLCJvdGhlck9wZXJhdGluZ0V4cGVuc2VzIiwidGl0bGUiLCJTdHJpbmciLCJwb2xpY3lWZXJzaW9uIiwid2FybmluZyIsIl9fTU9DS19fIiwibm90aWNlIiwiYWZ0ZXJHYXAiLCJldmVudCIsInRhcmdldCIsIml0ZW0iLCJpbnNldCIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYm9yZGVyUmFkaXVzIiwicmFkaXVzIiwiY29udHJvbCIsImFuc3dlciIsInN1YmhlYWRpbmdBZnRlckdhcCIsInNvdXJjZXMiLCJzb3VyY2UiLCJpbmRleCIsImNvbnRlbnRHYXAiLCJKb3VybmFsc1BhZ2UiLCJfczQiLCJqb3VybmFsUGFyYW1zIiwic2V0Sm91cm5hbFBhcmFtcyIsInZpZXdJZCIsImdldCIsInNldFZpZXdJZCIsIm5leHQiLCJVUkxTZWFyY2hQYXJhbXMiLCJzZXQiLCJkZWxldGUiLCJyZXNvdXJjZUlkIiwidmlld2VkSm91cm5hbCIsInJlcGxhY2VtZW50Iiwic2V0UmVwbGFjZW1lbnQiLCJzYXZlZCIsInNldFNhdmVkIiwiam91cm5hbCIsImVmZmVjdGl2ZURhdGUiLCJzb3VyY2VUeXBlIiwic291cmNlSWQiLCJsaW5lcyIsImxpbmUiLCJhY2NvdW50SWQiLCJkZWJpdCIsImNyZWRpdCIsInJldmVyc2FsT2YiLCJjb25maXJtUmVhc29uIiwiUmVjb25jaWxpYXRpb25QYWdlIiwiX3M1IiwicGFyYW1zIiwic2V0UGFyYW1zIiwicmVxdWVzdGVkVGFiIiwidGFiIiwiYmFua3MiLCJjb2QiLCJjYXNlcyIsIm1hdGNoIiwibWF0Y2hCYW5rIiwiY2FzZUl0ZW0iLCJzZXRDYXNlIiwidHJhbnNhY3Rpb24iLCJzZXRUcmFuc2FjdGlvbiIsImZlZXMiLCJzZXRGZWVzIiwiZXZpZGVuY2UiLCJzZXRFdmlkZW5jZSIsInNldFJlc291cmNlIiwiYWxsb2NhdGlvbiIsInNldEFsbG9jYXRpb24iLCJzZXRSZWFzb24iLCJpbXBvcnRPcGVuIiwic2V0SW1wb3J0IiwiYmFua0Nob2ljZXMiLCJjYXNlQmFuayIsInRyYW5zYWN0aW9uSWQiLCJkZWJ0Q2hvaWNlcyIsInNlbGVjdGVkQmFuayIsImZpbmQiLCJzZWxlY3RlZERlYnQiLCJmZWVVbml0cyIsImFsbG9jYXRpb25Vbml0cyIsImNvZE1hdGNoVmFsaWQiLCJncm9zc0R1ZSIsInRyaW0iLCJiYW5rTWF0Y2hWYWxpZCIsImRpc3B1dGVkIiwiZGlmZmVyZW5jZSIsIm91dHN0YW5kaW5nQW1vdW50IiwiY3VycmVuY3kiLCJkaXJlY3Rpb24iLCJzZWxlY3RUYWIiLCJfZXZlbnQiLCJyZXBsYWNlIiwiZmx1c2hTeW5jIiwic2VjdGlvbkFmdGVyIiwicm93IiwiZXh0ZXJuYWxUcmFuc2FjdGlvbklkIiwicmVmZXJlbmNlVGV4dCIsIm1hdGNoU3RhdGUiLCJleHRlcm5hbEJhdGNoSWQiLCJjYXJyaWVySWQiLCJhY3R1YWxGZWVzIiwiYmFua1JlY2VpdmVkIiwic3RhdGUiLCJiYW5rVHJhbnNhY3Rpb25JZCIsImZlZUV2aWRlbmNlUmVmIiwiZmlsdGVyIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaW5wdXRNb2RlIiwiYWxsb2NhdGlvbnMiLCJyZXNvdXJjZSIsInJlYWRPbmx5IiwiRGVidHNQYWdlIiwiX3M2IiwicGVyaW9kT3BlbiIsInNldFBlcmlvZE9wZW4iLCJwZXJpb2RTYXZlZCIsInNldFBlcmlvZFNhdmVkIiwiZGVidHMiLCJwZXJpb2RzIiwiY2xvc2UiLCJyZW9wZW4iLCJhcHByb3ZhbCIsInNldEFwcHJvdmFsIiwiY291bnRlcnBhcnR5VHlwZSIsImNvdW50ZXJwYXJ0eUlkIiwib3JpZ2luYWxBbW91bnQiLCJkdWVBdCIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJibG9ja2luZ0lzc3VlcyIsImpvaW4iLCJhcHByb3ZhbElkIiwiZSIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1IiwiX2M2Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3Zpc3VhbFN4fSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQge0pvdXJuYWxFZGl0b3J9IGZyb20gJy4vam91cm5hbC1lZGl0b3InO1xyXG5pbXBvcnQge0ZpbmFuY2VFbnRyeUVkaXRvcixmaW5hbmNlRW50cnlDbGFzc2VzIGFzIGNsYXNzZXN9IGZyb20gJy4vZW50cnktZWRpdG9yJztcclxuaW1wb3J0IHtTdGF0ZW1lbnREaWFsb2d9IGZyb20gJy4vc3RhdGVtZW50LWltcG9ydCc7XHJcbmltcG9ydCB7Qm9va1Byb3ZlbmFuY2UsQ3JlYXRlUGVyaW9kRGlhbG9nfSBmcm9tICcuL21hbmFnZW1lbnQnO1xyXG5leHBvcnQge09wZW5pbmdCYWxhbmNlc1BhZ2UsTGVkZ2VyUGFnZSxUcmlhbEJhbGFuY2VQYWdlLEJhbGFuY2VTaGVldFBhZ2V9IGZyb20gJy4vbWFuYWdlbWVudCc7XHJcbmltcG9ydCB7dXNlUmVwb3J0UmFuZ2UsUmVwb3J0UmFuZ2VGaWVsZHN9IGZyb20gJy4vcmVwb3J0LXJhbmdlJztcclxuaW1wb3J0IHtsYWJlbCBhcyBidXNpbmVzc0xhYmVsfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9sYWJlbHMnO1xyXG5leHBvcnQgeyBBY2NvdW50c1BhZ2UgfSBmcm9tICcuL2FjY291bnRzJztcclxuaW1wb3J0IHsgQWN0aW9uR3JvdXAsIEZvcm1GaWVsZHMsIFBhZ2VTZWN0aW9ucywgU3VyZmFjZUNvbnRlbnQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBTeW50aGV0aWNFdmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEFsZXJ0LCBCb3gsIEJ1dHRvbiwgTWVudUl0ZW0sIFN0YWNrLCBUYWIsIFRhYnMsIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgdHlwZSB7IEFjY291bnRpbmdQZXJpb2QsIENPRFNldHRsZW1lbnQsIEZpbmFuY2VFbnRyeSwgSm91cm5hbCwgUmVjb25jaWxpYXRpb25DYXNlIH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCwgdXNlUGFnZWRBcGkgfSBmcm9tICcuLi8uLi9zaGFyZWQvYXBpL2hvb2tzJztcclxuaW1wb3J0IHsgdXNlU2NvcGUgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvc2NvcGUnO1xyXG5pbXBvcnQgeyB1c2VMaXN0UXVlcnkgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvZmlsdGVycyc7XHJcbmltcG9ydCB7IGNvZGVQb2ludExlbmd0aCwgZGF0ZVRpbWUsIGZvcm1hdE1vbmV5LCBmb3JtYXREYXRlT25seSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XHJcbmltcG9ydCB7IEFtb3VudCwgQ29uZmlybURpYWxvZywgRGF0YVRhYmxlLCBEZXRhaWxMaW5lLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgTG9va3VwTG9hZE1vcmUsIE11dGF0aW9uQnV0dG9uLCBQYWdlSGVhZGVyLCBQYWdlciwgUGFuZWwsIFF1ZXJ5U3RhdGUsIFJvdXRlTGluaywgU3RhdCwgU3RhdHMsIFN0YXR1cywgVG9vbGJhciB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb25lbnRzJztcclxuaW1wb3J0IHsgZXhwbGFpblByb2ZpdExvc3MsIHByb2ZpdExvc3NRdWVzdGlvbnMsIHR5cGUgUHJvZml0TG9zc1F1ZXN0aW9uSWQgfSBmcm9tICcuL3JlcG9ydC1leHBsYW5hdGlvbnMnO1xyXG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9sYXlvdXQnO1xyXG5cclxuZnVuY3Rpb24gZGVjaW1hbFVuaXRzKHZhbHVlOiBzdHJpbmcpOiBiaWdpbnQgfCBudWxsIHtcclxuICAgIGlmICghL15cXGQrKFxcLlxcZHsxLDR9KT8kLy50ZXN0KHZhbHVlKSkgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBbd2hvbGUgPSAnJywgZnJhY3Rpb24gPSAnJ10gPSB2YWx1ZS5zcGxpdCgnLicpO1xyXG4gICAgaWYgKCF3aG9sZSkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gQmlnSW50KHdob2xlKSAqIDEwMDAwbiArIEJpZ0ludChmcmFjdGlvbi5wYWRFbmQoNCwgJzAnKSk7XHJcbn1cclxuZnVuY3Rpb24gaGFzT3V0c3RhbmRpbmdCYWxhbmNlKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGFtb3VudCA9IGRlY2ltYWxVbml0cyh2YWx1ZSk7XHJcbiAgICByZXR1cm4gYW1vdW50ICE9PSBudWxsICYmIGFtb3VudCA+IDBuO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBDYXNoZmxvd1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCByZXBvcnQgPSB1c2VSZXBvcnRSYW5nZShzaG9wLnRpbWV6b25lKTtcclxuICAgIGNvbnN0IGRhdGEgPSB1c2VBcGkoJ2dldENhc2hmbG93JywgeyBxdWVyeTogcmVwb3J0LnF1ZXJ5IH0sIHJlcG9ydC52YWxpZCk7XHJcbiAgICBjb25zdCBjID0gZGF0YS5kYXRhPy5kYXRhO1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJEw7JuZyB0aeG7gW5cIiBzdWJ0aXRsZT1cIlRp4buBbiB0aOG7sWMgdGh1IHbDoCB0aOG7sWMgY2hpLCB0w6FjaCBiaeG7h3QgZG9hbmggdGh1IHbDoCBs4bujaSBuaHXhuq1uLlwiIGFjdGlvbnM9ezxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ZpbmFuY2UvZW50cmllc2B9PlPhu5UgdGh1IGNoaTwvUm91dGVMaW5rPn0vPjxSZXBvcnRSYW5nZUZpZWxkcyByYW5nZT17cmVwb3J0LnJhbmdlfSB0aW1lem9uZT17c2hvcC50aW1lem9uZX0gc2V0RnJvbT17cmVwb3J0LnNldEZyb219IHNldFRvPXtyZXBvcnQuc2V0VG99Lz57cmVwb3J0LnZhbGlkID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e2RhdGF9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntjICYmIDw+PFN0YXRzPjxTdGF0IHRpdGxlPVwiVGnhu4FuIMSRw6MgdGh1XCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17Yy5yZWNlaXB0c30vPn0vPjxTdGF0IHRpdGxlPVwiVGnhu4FuIMSRw6MgY2hpXCIgdmFsdWU9ezxBbW91bnQgd3JhcCB2YWx1ZT17Yy5kaXNidXJzZW1lbnRzfS8+fS8+PFN0YXQgdGl0bGU9XCJCaeG6v24gxJHhu5luZyB0aeG7gW4gdGh14bqnblwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e2MubmV0Q2FzaE1vdmVtZW50fS8+fSBhY2NlbnQgbm90ZT1cIktow7RuZyBwaOG6o2kgc+G7kSBkxrAgdMOgaSBraG/huqNuXCIvPjxTdGF0IHRpdGxlPVwiTcO6aSBnaeG7nSBiw6FvIGPDoW9cIiB2YWx1ZT17Yy50aW1lem9uZX0vPjwvU3RhdHM+PFBhbmVsIHRpdGxlPVwiS+G7syBiw6FvIGPDoW9cIiBib2R5TW9kZT1cImluc2V0XCI+PERldGFpbExpbmUgbGFiZWw9XCJU4burXCI+e2RhdGVUaW1lKGMuZnJvbSwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwixJDhur9uIChraMO0bmcgZ+G7k20pXCI+e2RhdGVUaW1lKGMudG8sIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIkThu68gbGnhu4d1IHThuqFpXCI+e2RhdGVUaW1lKGMuYXNPZiwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPntjLndhcm5pbmdzLm1hcCh3ID0+IDxBbGVydCBrZXk9e3d9IHNldmVyaXR5PVwiaW5mb1wiIHN4PXtsYXlvdXRTeC5zdXJmYWNlLnNlY3Rpb25CZWZvcmV9Pnt3fTwvQWxlcnQ+KX08L1BhbmVsPjwvPn08L1F1ZXJ5U3RhdGU+IDogPEFsZXJ0IHNldmVyaXR5PVwiZXJyb3JcIj5OZ8OgeSBi4bqvdCDEkeG6p3UgcGjhuqNpIHRyxrDhu5tjIG5nw6B5IGvhur90IHRow7pjLjwvQWxlcnQ+fTwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gRW50cmllc1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0RmluYW5jZUVudHJpZXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RGaW5hbmNlRW50cmllcycpIH0pO1xyXG4gICAgY29uc3QgcG9zdCA9IHVzZUNvbW1hbmQoJ3Bvc3RGaW5hbmNlRW50cnknLCBbJ2xpc3RGaW5hbmNlRW50cmllcycsICdnZXRDYXNoZmxvdycsICdnZXRQcm9maXRMb3NzJywgJ2xpc3RKb3VybmFscyddKTtcclxuICAgIGNvbnN0IHJldmVyc2UgPSB1c2VDb21tYW5kKCdyZXZlcnNlRmluYW5jZUVudHJ5JywgWydsaXN0RmluYW5jZUVudHJpZXMnLCAnZ2V0Q2FzaGZsb3cnLCAnZ2V0UHJvZml0TG9zcycsICdsaXN0Sm91cm5hbHMnXSk7XHJcbiAgICBjb25zdCBbZW50cnlJZCwgc2V0RW50cnlJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IGRldGFpbCA9IHVzZUFwaSgnZ2V0RmluYW5jZUVudHJ5JywgeyBwYXRoOiB7IGVudHJ5SWQ6IGVudHJ5SWQgfHwgJycgfSB9LCBCb29sZWFuKGVudHJ5SWQpKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkRW50cnkgPSBkZXRhaWwuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlPEZpbmFuY2VFbnRyeSB8IG51bGw+KG51bGwpLCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSksIFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8e1xyXG4gICAgICAgIGVudHJ5OiBGaW5hbmNlRW50cnk7XHJcbiAgICAgICAgYWN0aW9uOiAncG9zdCcgfCAncmV2ZXJzZSc7XHJcbiAgICB9IHwgbnVsbD4obnVsbCk7XHJcbiAgICBjb25zdCBbZW50cnlTYXZlZCxzZXRFbnRyeVNhdmVkXT11c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBiZWdpbj0oZW50cnk6RmluYW5jZUVudHJ5fG51bGwpPT57c2V0RWRpdGluZyhlbnRyeSk7c2V0T3Blbih0cnVlKTt9O1xyXG4gICAgcmV0dXJuIDw+e2VudHJ5U2F2ZWQmJjxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+xJDDoyBsxrB1IHBoaeG6v3UgbmjDoXAuPC9BbGVydD59PFBhZ2VIZWFkZXIgdGl0bGU9XCJT4buVIHRodSBjaGlcIiBzdWJ0aXRsZT1cIlBoaeG6v3UgbmjDoXAg4oaSIGtp4buDbSB0cmEg4oaSIGdoaSBz4buVLiBQaGnhur91IMSRw6MgZ2hpIGNo4buJIMSRaeG7gXUgY2jhu4luaCBjw7MgbOG7i2NoIHPhu60uXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4gYmVnaW4obnVsbCl9PlThuqFvIHBoaeG6v3U8L011dGF0aW9uQnV0dG9uPn0vPjxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0RmluYW5jZUVudHJpZXNcIiAvPjxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIkNo4bupbmcgdOG7qyB0aHUgY2hpXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17ciA9PiByLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnQ2jhu6luZyB04burJywgcmVuZGVyOiByID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RW50cnlJZChyLmlkKX0+e3IuaWR9PC9CdXR0b24+IH0sIHsga2V5OiAnZGF0ZScsIGxhYmVsOiAnTmfDoHknLCByZW5kZXI6IHIgPT4gZGF0ZVRpbWUoci5vY2N1cnJlZEF0LCBzaG9wLnRpbWV6b25lKSB9LCB7IGtleTogJ3R5cGUnLCBsYWJlbDogJ1Bow6JuIGxv4bqhaScsIHJlbmRlcjogciA9PiBjbGFzc2VzW3IuY2xhc3NpZmljYXRpb25dIH0sIHsga2V5OiAnYW1vdW50JywgbGFiZWw6ICdT4buRIHRp4buBbicsIHJlbmRlcjogciA9PiA8QW1vdW50IHZhbHVlPXtyLmFtb3VudH0vPiB9LCB7IGtleTogJ25vdGUnLCBsYWJlbDogJ0Rp4buFbiBnaeG6o2knLCByZW5kZXI6IHIgPT4gci5kZXNjcmlwdGlvbiB9LCB7IGtleTogJ3N0YXRlJywgbGFiZWw6ICdUcuG6oW5nIHRow6FpJywgcmVuZGVyOiByID0+IDxTdGF0dXMgdmFsdWU9e3Iuc3RhdHVzfS8+IH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJ1RoYW8gdMOhYycsIHJlbmRlcjogciA9PiA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEVudHJ5SWQoci5pZCl9PkNoaSB0aeG6v3Q8L0J1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gPEVkaXREaWFsb2cgb3Blbj17Qm9vbGVhbihlbnRyeUlkKX0gdGl0bGU9e3NlbGVjdGVkRW50cnkgPyBgQ2jhu6luZyB04burICR7c2VsZWN0ZWRFbnRyeS5pZH1gIDogJ8SQYW5nIHThuqNpIGNo4bupbmcgdOG7qyd9IG9uQ2xvc2U9eygpID0+IHNldEVudHJ5SWQobnVsbCl9IGFjdGlvbnM9ezxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0RW50cnlJZChudWxsKX0+xJDDs25nPC9CdXR0b24+fT48UXVlcnlTdGF0ZSBxdWVyeT17ZGV0YWlsfT57c2VsZWN0ZWRFbnRyeSAmJiA8U3RhY2sgc3g9e2xheW91dFN4LnF1ZXJ5LnN0YXRlR2FwfT48U3RhdHVzIHZhbHVlPXtzZWxlY3RlZEVudHJ5LnN0YXR1c30vPjxEZXRhaWxMaW5lIGxhYmVsPVwiTG/huqFpXCI+e3NlbGVjdGVkRW50cnkua2luZCA9PT0gJ3JlY2VpcHQnID8gJ1RodSB0aeG7gW4nIDogJ0NoaSB0aeG7gW4nfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlBow6JuIGxv4bqhaVwiPntjbGFzc2VzW3NlbGVjdGVkRW50cnkuY2xhc3NpZmljYXRpb25dfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIlPhu5EgdGnhu4FuXCI+PEFtb3VudCB3cmFwIHZhbHVlPXtzZWxlY3RlZEVudHJ5LmFtb3VudH0vPjwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIk5nw6B5IGdoaSBuaOG6rW5cIj57ZGF0ZVRpbWUoc2VsZWN0ZWRFbnRyeS5vY2N1cnJlZEF0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJOZ3Xhu5NuXCI+e3NlbGVjdGVkRW50cnkuc291cmNlUmVmID8gYCR7c2VsZWN0ZWRFbnRyeS5zb3VyY2VSZWYudHlwZX0gLyAke3NlbGVjdGVkRW50cnkuc291cmNlUmVmLmlkfWAgOiAnS2jDtG5nIGPDsyd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiRGnhu4VuIGdp4bqjaVwiPntzZWxlY3RlZEVudHJ5LmRlc2NyaXB0aW9ufTwvRGV0YWlsTGluZT57c2VsZWN0ZWRFbnRyeS5zdGF0dXMgPT09ICdkcmFmdCcgJiYgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiID48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZpbmFuY2UucG9zdFwiIG9uQ2xpY2s9eygpID0+IGJlZ2luKHNlbGVjdGVkRW50cnkpfT5T4butYSBuaMOhcDwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZCh7IGVudHJ5OiBzZWxlY3RlZEVudHJ5LCBhY3Rpb246ICdwb3N0JyB9KX0+R2hpIHPhu5U8L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+fXtzZWxlY3RlZEVudHJ5LnN0YXR1cyA9PT0gJ3Bvc3RlZCcgJiYgIVsnYmFua19hbGxvY2F0aW9uJywnY29kX3NldHRsZW1lbnQnLCdvcmRlcicsJ29yZGVyX3JlZnVuZCddLmluY2x1ZGVzKHNlbGVjdGVkRW50cnkuc291cmNlUmVmPy50eXBlfHwnJykgJiYgPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZCh7IGVudHJ5OiBzZWxlY3RlZEVudHJ5LCBhY3Rpb246ICdyZXZlcnNlJyB9KX0+xJDhuqNvIHBoaeG6v3U8L011dGF0aW9uQnV0dG9uPn08L1N0YWNrPn08L1F1ZXJ5U3RhdGU+PC9FZGl0RGlhbG9nPlxyXG4ge29wZW4mJjxGaW5hbmNlRW50cnlFZGl0b3Iga2V5PXtlZGl0aW5nPy5pZHx8J25ldyd9IGluaXRpYWw9e2VkaXRpbmd9IG9uQ2xvc2U9eygpPT5zZXRPcGVuKGZhbHNlKX0gb25TYXZlZD17KCk9PnNldEVudHJ5U2F2ZWQodHJ1ZSl9Lz59XHJcbiA8Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT17c2VsZWN0ZWQ/LmFjdGlvbiA9PT0gJ3Bvc3QnID8gJ0doaSBz4buVIHBoaeG6v3UgxJHDoyBraeG7g20nIDogJ8SQ4bqjbyBwaGnhur91IMSRw6MgZ2hpJ30gY29uZmlybUxhYmVsPXtzZWxlY3RlZD8uYWN0aW9uID09PSBcInBvc3RcIiA/IFwiR2hpIHPhu5UgcGhp4bq/dVwiIDogXCLEkOG6o28gcGhp4bq/dVwifSBkZXNjcmlwdGlvbj17YCR7c2VsZWN0ZWQ/LmVudHJ5LmlkIHx8ICcnfSDCtyAke2Zvcm1hdE1vbmV5KHNlbGVjdGVkPy5lbnRyeS5hbW91bnQpfS4gS2jDtG5nIGNodXnhu4NuIHRp4buBbiB0aOG7sWMgdOG6vyBxdWEgY2jhu6ljIG7Eg25nIG7DoHkuYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17cG9zdC5wZW5kaW5nIHx8IHJldmVyc2UucGVuZGluZ30gZXJyb3I9e3Bvc3QuZXJyb3IgfHwgcmV2ZXJzZS5lcnJvcn0gb25Db25maXJtPXtyZWFzb24gPT4gc2VsZWN0ZWQ/LmFjdGlvbiA9PT0gJ3Bvc3QnID8gcG9zdC5leGVjdXRlKHsgcGF0aDogeyBlbnRyeUlkOiBzZWxlY3RlZC5lbnRyeS5pZCB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQuZW50cnkudmVyc2lvbiwgcmVhc29uIH0gfSkgOiByZXZlcnNlLmV4ZWN1dGUoeyBwYXRoOiB7IGVudHJ5SWQ6IHNlbGVjdGVkPy5lbnRyeS5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LmVudHJ5LnZlcnNpb24gfHwgMSwgcmVhc29uIH0gfSl9Lz48Lz47XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFByb2ZpdExvc3NQYWdlKCkge1xyXG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgcmVwb3J0ID0gdXNlUmVwb3J0UmFuZ2Uoc2hvcC50aW1lem9uZSk7XHJcbiAgICBjb25zdCBkYXRhID0gdXNlQXBpKCdnZXRQcm9maXRMb3NzJywgeyBxdWVyeTogcmVwb3J0LnF1ZXJ5IH0sIHJlcG9ydC52YWxpZCk7XHJcbiAgICBjb25zdCBwID0gZGF0YS5kYXRhPy5kYXRhO1xyXG4gICAgY29uc3QgW3F1ZXN0aW9uLCBzZXRRdWVzdGlvbl0gPSB1c2VTdGF0ZTxQcm9maXRMb3NzUXVlc3Rpb25JZD4oJ3N1bW1hcnknKTtcclxuICAgIGNvbnN0IFtnZW5lcmF0ZWRLZXksIHNldEdlbmVyYXRlZEtleV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBjdXJyZW50S2V5ID0gcCA/IGAke3JlcG9ydC5yYW5nZS5mcm9tfXwke3JlcG9ydC5yYW5nZS50b318JHtwLmFzT2Z9fCR7cXVlc3Rpb259YCA6ICcnO1xyXG4gICAgY29uc3QgZXhwbGFuYXRpb24gPSBwICYmIGdlbmVyYXRlZEtleSA9PT0gY3VycmVudEtleSA/IGV4cGxhaW5Qcm9maXRMb3NzKHAsIHF1ZXN0aW9uKSA6IG51bGw7XHJcbiAgICByZXR1cm4gPD5cclxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkzhu6NpIG5odeG6rW4gcXXhuqNuIHRy4buLXCIgc3VidGl0bGU9XCJT4buRIGxp4buHdSBkbyBBUEkgdOG7lW5nIGjhu6NwIHThu6sgbmd14buTbiBnaWFvIGThu4tjaCwga2jDtG5nIHTDrW5oIHThu6sgdHJhbmcgZGFuaCBzw6FjaCDEkWFuZyBt4bufLlwiIC8+XHJcbiAgICAgICAgPFJlcG9ydFJhbmdlRmllbGRzIHJhbmdlPXtyZXBvcnQucmFuZ2V9IHRpbWV6b25lPXtzaG9wLnRpbWV6b25lfSBzZXRGcm9tPXt2YWx1ZSA9PiB7IHNldEdlbmVyYXRlZEtleSgnJyk7IHJlcG9ydC5zZXRGcm9tKHZhbHVlKTsgfX0gc2V0VG89e3ZhbHVlID0+IHsgc2V0R2VuZXJhdGVkS2V5KCcnKTsgcmVwb3J0LnNldFRvKHZhbHVlKTsgfX0gLz5cclxuICAgICAgICB7cmVwb3J0LnZhbGlkID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e2RhdGF9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPlxyXG4gICAgICAgICAgICB7cCAmJiA8PlxyXG4gICAgICAgICAgICAgICAgPFN0YXRzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiRG9hbmggdGh1IHRodeG6p25cIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXtwLm5ldFNhbGVzfSAvPn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkdpw6EgduG7kW5cIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXtwLmNvZ3N9IC8+fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0IHRpdGxlPVwiTMOjaSBn4buZcFwiIHZhbHVlPXs8QW1vdW50IHdyYXAgdmFsdWU9e3AuZ3Jvc3NQcm9maXR9IC8+fSBhY2NlbnQgLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3RhdCB0aXRsZT1cIkzhu6NpIG5odeG6rW4gduG6rW4gaMOgbmhcIiB2YWx1ZT17PEFtb3VudCB3cmFwIHZhbHVlPXtwLm9wZXJhdGluZ1Byb2ZpdH0gLz59IG5vdGU9XCJDaMawYSBjw7MgY2jhu6luZyBuaOG6rW4ga+G6vyB0b8OhbiBwaMOhcCDEkeG7i25oXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvU3RhdHM+XHJcbiAgICAgICAgICAgICAgICA8UGFnZVNlY3Rpb25zPlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYW5lbCB0aXRsZT1cIkNoaSB0aeG6v3Qga+G6v3QgcXXhuqMga2luaCBkb2FuaFwiIGFjdGlvbj17PFN0YXR1cyB2YWx1ZT17cC5jb21wbGV0ZW5lc3N9IC8+fSBib2R5TW9kZT1cImluc2V0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbJ0RvYW5oIHRodSBn4buZcCcsIHAuZ3Jvc3NTYWxlc10sIFsnR2nhuqNtIGdpw6EnLCBwLmRpc2NvdW50c10sIFsnSMOgbmcgYsOhbiB0cuG6oyBs4bqhaScsIHAuc2FsZXNSZXR1cm5zXSwgWydEb2FuaCB0aHUgdGh14bqnbicsIHAubmV0U2FsZXNdLCBbJ0dpw6EgduG7kW4nLCBwLmNvZ3NdLCBbJ1RodSBwaMOtIGdpYW8nLCBwLnNoaXBwaW5nSW5jb21lXSwgWydDaGkgcGjDrSBnaWFvJywgcC5zaGlwcGluZ0V4cGVuc2VdLCBbJ1Bow60gbuG7gW4gdOG6o25nJywgcC5wbGF0Zm9ybUZlZXNdLCBbJ1Bow60gdGhhbmggdG/DoW4nLCBwLnBheW1lbnRGZWVzXSwgWydDaGkgcGjDrSBBSScsIHAuYWlFeHBlbnNlXSwgWydDaGkgcGjDrSBraMOhYycsIHAub3RoZXJPcGVyYXRpbmdFeHBlbnNlc10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChbdGl0bGUsIHZhbHVlXSkgPT4gPERldGFpbExpbmUga2V5PXtTdHJpbmcodGl0bGUpfSBsYWJlbD17U3RyaW5nKHRpdGxlKX0+PEFtb3VudCB3cmFwIHZhbHVlPXt0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnID8gdmFsdWUgOiBudWxsfSAvPjwvRGV0YWlsTGluZT4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkNow61uaCBzw6FjaFwiPntwLnBvbGljeVZlcnNpb259PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGV0YWlsTGluZSBsYWJlbD1cIkThu68gbGnhu4d1IHThuqFpXCI+e2RhdGVUaW1lKHAuYXNPZiwgc2hvcC50aW1lem9uZSl9PC9EZXRhaWxMaW5lPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cC53YXJuaW5ncy5tYXAod2FybmluZyA9PiA8QWxlcnQga2V5PXt3YXJuaW5nfSBzZXZlcml0eT1cIndhcm5pbmdcIiBzeD17bGF5b3V0U3guc3VyZmFjZS5zZWN0aW9uQmVmb3JlfT57d2FybmluZ308L0FsZXJ0Pil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICAgICAgICAgICAgICA8UGFuZWwgdGl0bGU9XCJI4buPaSDEkcOhcCBjw7Mgbmd14buTblwiIHN1YnRpdGxlPVwiR2nhuqNpIHRow61jaCBnaeG7m2kgaOG6oW4gdGhlbyDEkcO6bmcgc25hcHNob3QgxJFhbmcgaGnhu4NuIHRo4buLLlwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge19fTU9DS19fID8gPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT5DaOG6vyDEkeG7mSBtw7QgcGjhu49uZzogY8OidSB0cuG6oyBs4budaSB0aGVvIG3huqt1IGPhu5EgxJHhu4tuaCwgY2jhu4kgxJHhu41jIGThu68gbGnhu4d1IFAmTCBBUEkgdOG7lW5nIGjhu6NwIG7DoHk7IGtow7RuZyBn4buNaSBBSSB2w6Aga2jDtG5nIGdoaSBz4buVLjwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUZpZWxkcz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIkPDonUgaOG7j2kgduG7gSBiw6FvIGPDoW9cIiB2YWx1ZT17cXVlc3Rpb259IG9uQ2hhbmdlPXtldmVudCA9PiB7IHNldFF1ZXN0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSBhcyBQcm9maXRMb3NzUXVlc3Rpb25JZCk7IHNldEdlbmVyYXRlZEtleSgnJyk7IH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZml0TG9zc1F1ZXN0aW9ucy5tYXAoaXRlbSA9PiA8TWVudUl0ZW0ga2V5PXtpdGVtLmlkfSB2YWx1ZT17aXRlbS5pZH0+e2l0ZW0ubGFiZWx9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtRmllbGRzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cImNvbHVtblwiIGJlZm9yZUdhcD1cImZvcm1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRHZW5lcmF0ZWRLZXkoY3VycmVudEtleSl9IGRpc2FibGVkPXshY3VycmVudEtleX0+VOG6oW8gZ2nhuqNpIHRow61jaCBtw7QgcGjhu49uZzwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9BY3Rpb25Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBsYW5hdGlvbiAmJiA8U3VyZmFjZUNvbnRlbnQgYmVmb3JlR2FwPVwic3VyZmFjZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcm9sZT1cInJlZ2lvblwiIGFyaWEtbGFiZWw9XCJHaeG6o2kgdGjDrWNoIGLDoW8gY8OhbyBtw7QgcGjhu49uZ1wiIGRhdGEtdGVzdGlkPVwicHJvZml0LWxvc3MtZXhwbGFuYXRpb25cIiBzeD17eyAuLi5sYXlvdXRTeC5zdXJmYWNlLmluc2V0LCBib3JkZXI6IDEsIGJvcmRlckNvbG9yOiAnZGl2aWRlcicsIGJvcmRlclJhZGl1czogdmlzdWFsU3gucmFkaXVzLmNvbnRyb2wgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHN4PXtsYXlvdXRTeC5ub3RpY2UuYWZ0ZXJHYXB9PntleHBsYW5hdGlvbi5hbnN3ZXJ9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUyXCIgc3g9e2xheW91dFN4LnJlcG9ydC5zdWJoZWFkaW5nQWZ0ZXJHYXB9PkThu68gbGnhu4d1IG5ndeG7k24gdHJvbmcgc25hcHNob3Q8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBsYW5hdGlvbi5zb3VyY2VzLm1hcChzb3VyY2UgPT4gPERldGFpbExpbmUga2V5PXtzb3VyY2UubGFiZWx9IGxhYmVsPXtzb3VyY2UubGFiZWx9Pntzb3VyY2UudmFsdWV9PC9EZXRhaWxMaW5lPil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBsYW5hdGlvbi53YXJuaW5ncy5tYXAoKHdhcm5pbmcsIGluZGV4KSA9PiA8QWxlcnQga2V5PXtgJHtpbmRleH0tJHt3YXJuaW5nfWB9IHNldmVyaXR5PVwid2FybmluZ1wiIHN4PXtsYXlvdXRTeC5ub3RpY2UuY29udGVudEdhcH0+e3dhcm5pbmd9PC9BbGVydD4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm9va1Byb3ZlbmFuY2UgcmVwb3J0PXtwfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1N1cmZhY2VDb250ZW50Pn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+IDogPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPkNo4bupYyBuxINuZyBnaeG6o2kgdGjDrWNoIGNo4buJIGPDsyBi4bqjbiB4ZW0gdHLGsOG7m2MgbcO0IHBo4buPbmcuIEFQSSBoaeG7h24gY2jGsGEgY8OzIG9wZXJhdGlvbiBo4buPaSDEkcOhcCBiw6FvIGPDoW8uPC9BbGVydD59XHJcbiAgICAgICAgICAgICAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICAgICAgICAgIDwvUGFnZVNlY3Rpb25zPlxyXG4gICAgICAgICAgICA8Lz59XHJcbiAgICAgICAgPC9RdWVyeVN0YXRlPiA6IDxBbGVydCBzZXZlcml0eT1cImVycm9yXCI+TmfDoHkgYuG6r3QgxJHhuqd1IHBo4bqjaSB0csaw4bubYyBuZ8OgeSBr4bq/dCB0aMO6Yy48L0FsZXJ0Pn1cclxuICAgIDwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gSm91cm5hbHNQYWdlKCkge1xyXG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdEpvdXJuYWxzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0Sm91cm5hbHMnKSB9KTtcclxuICAgIGNvbnN0IFtqb3VybmFsUGFyYW1zLHNldEpvdXJuYWxQYXJhbXNdPXVzZVNlYXJjaFBhcmFtcygpO1xyXG4gICAgY29uc3Qgdmlld0lkPWpvdXJuYWxQYXJhbXMuZ2V0KCdqb3VybmFsSWQnKTtcclxuICAgIGNvbnN0IHNldFZpZXdJZD0oaWQ6c3RyaW5nfG51bGwpPT57Y29uc3QgbmV4dD1uZXcgVVJMU2VhcmNoUGFyYW1zKGpvdXJuYWxQYXJhbXMpO2lmKGlkKW5leHQuc2V0KCdqb3VybmFsSWQnLGlkKTtlbHNlIG5leHQuZGVsZXRlKCdqb3VybmFsSWQnKTtzZXRKb3VybmFsUGFyYW1zKG5leHQpO307XHJcbiAgICBjb25zdCBkZXRhaWwgPSB1c2VBcGkoJ2dldEpvdXJuYWwnLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogdmlld0lkIHx8ICcnIH0gfSwgQm9vbGVhbih2aWV3SWQpKTtcclxuICAgIGNvbnN0IHZpZXdlZEpvdXJuYWwgPSBkZXRhaWwuZGF0YT8uZGF0YTtcclxuICAgIGNvbnN0IHBvc3Q9dXNlQ29tbWFuZCgncG9zdEpvdXJuYWwnLFsnbGlzdEpvdXJuYWxzJywnZ2V0Sm91cm5hbCcsJ2dldExlZGdlcicsJ2dldFRyaWFsQmFsYW5jZScsJ2dldEJhbGFuY2VTaGVldCcsJ2dldFByb2ZpdExvc3MnLCdnZXRDYXNoZmxvdyddKSxyZXZlcnNlPXVzZUNvbW1hbmQoJ3JldmVyc2VKb3VybmFsJyxbJ2xpc3RKb3VybmFscycsJ2dldEpvdXJuYWwnLCdnZXRMZWRnZXInLCdnZXRUcmlhbEJhbGFuY2UnLCdnZXRCYWxhbmNlU2hlZXQnLCdnZXRQcm9maXRMb3NzJywnZ2V0Q2FzaGZsb3cnXSk7XHJcbiAgICBjb25zdCBbb3BlbixzZXRPcGVuXT11c2VTdGF0ZShmYWxzZSksW3JlcGxhY2VtZW50LHNldFJlcGxhY2VtZW50XT11c2VTdGF0ZTxKb3VybmFsfG51bGw+KG51bGwpLFtzYXZlZCxzZXRTYXZlZF09dXNlU3RhdGUoZmFsc2UpLFtzZWxlY3RlZCxzZXRTZWxlY3RlZF09dXNlU3RhdGU8e2pvdXJuYWw6Sm91cm5hbDthY3Rpb246J3Bvc3QnfCdyZXZlcnNlJ318bnVsbD4obnVsbCk7XHJcbiAgICByZXR1cm4gPD57c2F2ZWQmJjxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+xJDDoyBsxrB1IGLDunQgdG/DoW4gbmjDoXA7IGtp4buDbSBs4bqhaSB0csaw4bubYyBraGkgZ2hpLjwvQWxlcnQ+fTxQYWdlSGVhZGVyIHRpdGxlPVwiQsO6dCB0b8OhblwiIHN1YnRpdGxlPVwiU+G7lSBrw6lwIGPDsyBjaOG7qW5nIHThu6sgbmd14buTbiwga2nhu4NtIGPDom4gYuG6sW5nIHThuqFpIEFQSSB2w6Aga2jDtG5nIHPhu61hIGLDunQgdG/DoW4gxJHDoyBnaGkuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCkgPT4ge3NldFJlcGxhY2VtZW50KG51bGwpO3NldE9wZW4odHJ1ZSk7fX0+VOG6oW8gYsO6dCB0b8OhbiBuaMOhcDwvTXV0YXRpb25CdXR0b24+fS8+PFBhbmVsPjxUb29sYmFyIG9wZXJhdGlvbj1cImxpc3RKb3VybmFsc1wiLz48UXVlcnlTdGF0ZSBxdWVyeT17bGlzdH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2xpc3QuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJEYW5oIHPDoWNoIGLDunQgdG/DoW5cIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtqb3VybmFsID0+IGpvdXJuYWwuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICdCw7p0IHRvw6FuJywgcmVuZGVyOiBqb3VybmFsID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Vmlld0lkKGpvdXJuYWwuaWQpfT57am91cm5hbC5pZH08L0J1dHRvbj4gfSxcclxuICAgICAgICB7IGtleTogJ2RhdGUnLCBsYWJlbDogJ05nw6B5IGhp4buHdSBs4buxYycsIHJlbmRlcjogam91cm5hbCA9PiBmb3JtYXREYXRlT25seShqb3VybmFsLmVmZmVjdGl2ZURhdGUpIH0sXHJcbiAgICAgICAgeyBrZXk6ICdzb3VyY2UnLCBsYWJlbDogJ05ndeG7k24nLCByZW5kZXI6IGpvdXJuYWwgPT4gYCR7YnVzaW5lc3NMYWJlbChqb3VybmFsLnNvdXJjZVR5cGUpfSAvIE3DoyBjaOG7qW5nIHThu6s6ICR7am91cm5hbC5zb3VyY2VJZH1gIH0sXHJcbiAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogam91cm5hbCA9PiA8U3RhdHVzIHZhbHVlPXtqb3VybmFsLnN0YXR1c30vPiB9LFxyXG4gICAgICAgIHsga2V5OiAnYWN0aW9ucycsIGxhYmVsOiAnJywgcmVuZGVyOiBqb3VybmFsID0+IDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Vmlld0lkKGpvdXJuYWwuaWQpfT5DaGkgdGnhur90PC9CdXR0b24+IH0sXHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gICAgPEVkaXREaWFsb2cgb3Blbj17Qm9vbGVhbih2aWV3SWQpfSB0aXRsZT17dmlld2VkSm91cm5hbCA/IGBCw7p0IHRvw6FuICR7dmlld2VkSm91cm5hbC5pZH1gIDogJ8SQYW5nIHThuqNpIGLDunQgdG/DoW4nfSBvbkNsb3NlPXsoKSA9PiBzZXRWaWV3SWQobnVsbCl9IGFjdGlvbnM9ezxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Vmlld0lkKG51bGwpfT7EkMOzbmc8L0J1dHRvbj59PjxRdWVyeVN0YXRlIHF1ZXJ5PXtkZXRhaWx9Pnt2aWV3ZWRKb3VybmFsICYmIDw+PFN0YXR1cyB2YWx1ZT17dmlld2VkSm91cm5hbC5zdGF0dXN9Lz48RGF0YVRhYmxlIGxhYmVsPVwiQ8OhYyBkw7JuZyBj4bunYSBiw7p0IHRvw6FuXCIgcm93cz17dmlld2VkSm91cm5hbC5saW5lcy5tYXAoKGxpbmUsIGluZGV4KSA9PiAoeyAuLi5saW5lLCBrZXk6IFN0cmluZyhpbmRleCkgfSkpfSByb3dLZXk9e2xpbmUgPT4gbGluZS5rZXl9IGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ2FjY291bnQnLCBsYWJlbDogJ1TDoGkga2hv4bqjbicsIHJlbmRlcjogbGluZSA9PiBsaW5lLmFjY291bnRJZCB9LFxyXG4gICAgICAgIHsga2V5OiAnZGViaXQnLCBsYWJlbDogJ07hu6MnLCByZW5kZXI6IGxpbmUgPT4gPEFtb3VudCB2YWx1ZT17bGluZS5kZWJpdH0vPiB9LFxyXG4gICAgICAgIHsga2V5OiAnY3JlZGl0JywgbGFiZWw6ICdDw7MnLCByZW5kZXI6IGxpbmUgPT4gPEFtb3VudCB2YWx1ZT17bGluZS5jcmVkaXR9Lz4gfSxcclxuICAgICAgICB7IGtleTogJ25vdGUnLCBsYWJlbDogJ0Rp4buFbiBnaeG6o2knLCByZW5kZXI6IGxpbmUgPT4gbGluZS5kZXNjcmlwdGlvbiB9LFxyXG4gICAgXX0vPjxEZXRhaWxMaW5lIGxhYmVsPVwiQ2jDrW5oIHPDoWNoXCI+e3ZpZXdlZEpvdXJuYWwucG9saWN5VmVyc2lvbn08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJCw7p0IHRvw6FuIGfhu5FjXCI+e3ZpZXdlZEpvdXJuYWwucmV2ZXJzYWxPZiB8fCAn4oCUJ308L0RldGFpbExpbmU+e3ZpZXdlZEpvdXJuYWwuc3RhdHVzPT09J3JldmVyc2VkJyYmIVsnb3BlbmluZ19iYWxhbmNlJywnZmluYW5jZV9lbnRyeScsJ2dvb2RzX3JlY2VpcHQnLCdzaGlwbWVudF9kaXNwYXRjaCcsJ29yZGVyX2RlbGl2ZXJ5JywncmV0dXJuX2luc3BlY3Rpb24nLCdzdG9ja19hZGp1c3RtZW50J10uaW5jbHVkZXModmlld2VkSm91cm5hbC5zb3VyY2VUeXBlKSYmPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnBvc3RcIiBvbkNsaWNrPXsoKT0+e3NldFJlcGxhY2VtZW50KHZpZXdlZEpvdXJuYWwpO3NldFZpZXdJZChudWxsKTtzZXRPcGVuKHRydWUpO319PlRoYXkgdGjhur8gYsO6dCB0b8OhbjwvTXV0YXRpb25CdXR0b24+fXt2aWV3ZWRKb3VybmFsLnN0YXR1cyA9PT0gJ2RyYWZ0JyAmJiA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZpbmFuY2UucG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHsgam91cm5hbDogdmlld2VkSm91cm5hbCwgYWN0aW9uOiAncG9zdCcgfSl9PkdoaSBz4buVPC9NdXRhdGlvbkJ1dHRvbj59e3ZpZXdlZEpvdXJuYWwuc3RhdHVzID09PSAncG9zdGVkJyAmJiAhWydvcGVuaW5nX2JhbGFuY2UnLCdmaW5hbmNlX2VudHJ5JywnZ29vZHNfcmVjZWlwdCcsJ3NoaXBtZW50X2Rpc3BhdGNoJywnb3JkZXJfZGVsaXZlcnknLCdyZXR1cm5faW5zcGVjdGlvbicsJ3N0b2NrX2FkanVzdG1lbnQnXS5pbmNsdWRlcyh2aWV3ZWRKb3VybmFsLnNvdXJjZVR5cGUpICYmIDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5wb3N0XCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoeyBqb3VybmFsOiB2aWV3ZWRKb3VybmFsLCBhY3Rpb246ICdyZXZlcnNlJyB9KX0+xJDhuqNvIGLDunQgdG/DoW48L011dGF0aW9uQnV0dG9uPn08Lz59PC9RdWVyeVN0YXRlPjwvRWRpdERpYWxvZz5cclxuICAgIHtvcGVuJiY8Sm91cm5hbEVkaXRvciBrZXk9e3JlcGxhY2VtZW50Py5pZHx8J25ldyd9IHJlcGxhY2VtZW50PXtyZXBsYWNlbWVudH0gb25DbG9zZT17KCk9PnNldE9wZW4oZmFsc2UpfSBvblNhdmVkPXsoKT0+c2V0U2F2ZWQodHJ1ZSl9Lz59XHJcbiAgICA8Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkfSB0aXRsZT17c2VsZWN0ZWQ/LmFjdGlvbiA9PT0gJ3Bvc3QnID8gJ0doaSBz4buVIGLDunQgdG/DoW4nIDogJ8SQ4bqjbyBiw7p0IHRvw6FuJ30gY29uZmlybUxhYmVsPXtzZWxlY3RlZD8uYWN0aW9uID09PSBcInBvc3RcIiA/IFwiR2hpIHPhu5UgYsO6dCB0b8OhblwiIDogXCLEkOG6o28gYsO6dCB0b8OhblwifSBkZXNjcmlwdGlvbj17YELDunQgdG/DoW4gJHtzZWxlY3RlZD8uam91cm5hbC5pZCB8fCBcIlwifTogJHtzZWxlY3RlZD8uYWN0aW9uID09PSBcInBvc3RcIiA/IFwiZ2hpIHbDoG8gc+G7lSBzYXUga2hpIGtp4buDbSBr4buzLCBjw6JuIGLhurFuZyB2w6Agbmd14buTbiBjaOG7qW5nIHThu6s7IGLhuqNuIMSRw6MgZ2hpIGtow7RuZyDEkcaw4bujYyBz4butYSB0cuG7sWMgdGnhur9wLlwiIDogXCJ04bqhbyBiw7p0IHRvw6FuIMSR4bqjbywgZ2nhu68gbmd1ecOqbiBjaOG7qW5nIHThu6sgZ+G7kWMgdsOgIGzhu4tjaCBz4butLlwifWB9IHJlcXVpcmVSZWFzb249e3NlbGVjdGVkPy5hY3Rpb24gPT09ICdyZXZlcnNlJ30gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGVycm9yPXtwb3N0LmVycm9yIHx8IHJldmVyc2UuZXJyb3J9IGJ1c3k9e3Bvc3QucGVuZGluZyB8fCByZXZlcnNlLnBlbmRpbmd9IG9uQ29uZmlybT17Y29uZmlybVJlYXNvbiA9PiBzZWxlY3RlZD8uYWN0aW9uID09PSAncG9zdCcgPyBwb3N0LmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IHNlbGVjdGVkLmpvdXJuYWwuaWQgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IHNlbGVjdGVkLmpvdXJuYWwudmVyc2lvbiB9IH0pIDogcmV2ZXJzZS5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBzZWxlY3RlZD8uam91cm5hbC5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LmpvdXJuYWwudmVyc2lvbiB8fCAxLCByZWFzb246IGNvbmZpcm1SZWFzb24gfSB9KX0vPjwvPjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFJlY29uY2lsaWF0aW9uUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICAgIGNvbnN0IHJlcXVlc3RlZFRhYiA9IHBhcmFtcy5nZXQoJ3RhYicpO1xyXG4gICAgY29uc3QgdGFiID0gcmVxdWVzdGVkVGFiID09PSAnY29kJyB8fCByZXF1ZXN0ZWRUYWIgPT09ICdjYXNlcycgPyByZXF1ZXN0ZWRUYWIgOiAnYmFuayc7XHJcbiAgICBjb25zdCBiYW5rcyA9IHVzZUFwaSgnbGlzdEJhbmtUcmFuc2FjdGlvbnMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RCYW5rVHJhbnNhY3Rpb25zJywgJ2JhbmtDdXJzb3InKSB9KTtcclxuICAgIGNvbnN0IGNvZCA9IHVzZUFwaSgnbGlzdENPRFNldHRsZW1lbnRzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0Q09EU2V0dGxlbWVudHMnLCAnY29kQ3Vyc29yJykgfSk7XHJcbiAgICBjb25zdCBjYXNlcyA9IHVzZUFwaSgnbGlzdFJlY29uY2lsaWF0aW9uQ2FzZXMnLCB7IHF1ZXJ5OiB1c2VMaXN0UXVlcnkoJ2xpc3RSZWNvbmNpbGlhdGlvbkNhc2VzJywgJ2Nhc2VDdXJzb3InKSB9KTtcclxuICAgIGNvbnN0IG1hdGNoID0gdXNlQ29tbWFuZCgnbWF0Y2hDT0RTZXR0bGVtZW50JywgWydsaXN0Q09EU2V0dGxlbWVudHMnLCAnbGlzdEJhbmtUcmFuc2FjdGlvbnMnLCAnbGlzdERlYnRJdGVtcycsICdnZXRDYXNoZmxvdyddKTtcclxuICAgIGNvbnN0IG1hdGNoQmFuayA9IHVzZUNvbW1hbmQoJ21hdGNoU2V0dGxlbWVudCcsIFsnbGlzdFJlY29uY2lsaWF0aW9uQ2FzZXMnLCAnbGlzdEJhbmtUcmFuc2FjdGlvbnMnLCAnbGlzdERlYnRJdGVtcyddKTtcclxuICAgIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8Q09EU2V0dGxlbWVudCB8IG51bGw+KG51bGwpLCBbY2FzZUl0ZW0sIHNldENhc2VdID0gdXNlU3RhdGU8UmVjb25jaWxpYXRpb25DYXNlIHwgbnVsbD4obnVsbCksIFt0cmFuc2FjdGlvbiwgc2V0VHJhbnNhY3Rpb25dID0gdXNlU3RhdGUoJycpLCBbZmVlcywgc2V0RmVlc10gPSB1c2VTdGF0ZSgnMCcpLCBbZXZpZGVuY2UsIHNldEV2aWRlbmNlXSA9IHVzZVN0YXRlKCcnKSwgW3Jlc291cmNlSWQsIHNldFJlc291cmNlXSA9IHVzZVN0YXRlKCcnKSwgW2FsbG9jYXRpb24sIHNldEFsbG9jYXRpb25dID0gdXNlU3RhdGUoJycpLCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpLCBbaW1wb3J0T3Blbiwgc2V0SW1wb3J0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IGJhbmtDaG9pY2VzID0gdXNlUGFnZWRBcGkoJ2xpc3RCYW5rVHJhbnNhY3Rpb25zJywge30sIEJvb2xlYW4oc2VsZWN0ZWQpKTtcclxuICAgIGNvbnN0IGNhc2VCYW5rID0gdXNlQXBpKCdnZXRCYW5rVHJhbnNhY3Rpb24nLCB7IHBhdGg6IHsgcmVzb3VyY2VJZDogY2FzZUl0ZW0/LnRyYW5zYWN0aW9uSWQgfHwgJycgfSB9LCBCb29sZWFuKGNhc2VJdGVtKSk7XHJcbiAgICBjb25zdCBkZWJ0Q2hvaWNlcyA9IHVzZVBhZ2VkQXBpKCdsaXN0RGVidEl0ZW1zJywge30sIEJvb2xlYW4oY2FzZUl0ZW0pKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkQmFuayA9IGNhc2VJdGVtID8gY2FzZUJhbmsuZGF0YT8uZGF0YSA6IGJhbmtDaG9pY2VzLmRhdGE/LmRhdGEuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHRyYW5zYWN0aW9uKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkRGVidCA9IGRlYnRDaG9pY2VzLmRhdGE/LmRhdGEuZmluZChpdGVtID0+IGl0ZW0uaWQgPT09IHJlc291cmNlSWQpO1xyXG4gICAgY29uc3QgZmVlVW5pdHMgPSBkZWNpbWFsVW5pdHMoZmVlcyksIGFsbG9jYXRpb25Vbml0cyA9IGRlY2ltYWxVbml0cyhhbGxvY2F0aW9uKTtcclxuICAgIGNvbnN0IGNvZE1hdGNoVmFsaWQgPSBCb29sZWFuKHNlbGVjdGVkICYmIHNlbGVjdGVkQmFuayAmJiBmZWVVbml0cyAhPT0gbnVsbCAmJiBmZWVVbml0cyA+PSAwbiAmJiBmZWVVbml0cyA8PSAoZGVjaW1hbFVuaXRzKHNlbGVjdGVkLmdyb3NzRHVlLmFtb3VudCkgPz8gLTFuKSAmJiAoZGVjaW1hbFVuaXRzKHNlbGVjdGVkLmdyb3NzRHVlLmFtb3VudCkgPz8gLTFuKSAtIGZlZVVuaXRzID09PSBkZWNpbWFsVW5pdHMoc2VsZWN0ZWRCYW5rLmFtb3VudC5hbW91bnQpICYmIGV2aWRlbmNlLnRyaW0oKSk7XHJcbiAgICBjb25zdCBiYW5rTWF0Y2hWYWxpZCA9IEJvb2xlYW4oY2FzZUl0ZW0gJiYgc2VsZWN0ZWRCYW5rICYmIHNlbGVjdGVkRGVidCAmJiAhc2VsZWN0ZWREZWJ0LmRpc3B1dGVkICYmIGFsbG9jYXRpb25Vbml0cyAhPT0gbnVsbCAmJiBhbGxvY2F0aW9uVW5pdHMgPiAwbiAmJiBhbGxvY2F0aW9uVW5pdHMgPD0gKGRlY2ltYWxVbml0cyhjYXNlSXRlbS5kaWZmZXJlbmNlLmFtb3VudCkgPz8gLTFuKSAmJiBhbGxvY2F0aW9uVW5pdHMgPD0gKGRlY2ltYWxVbml0cyhzZWxlY3RlZERlYnQub3V0c3RhbmRpbmdBbW91bnQuYW1vdW50KSA/PyAtMW4pICYmIHNlbGVjdGVkRGVidC5vdXRzdGFuZGluZ0Ftb3VudC5jdXJyZW5jeSA9PT0gc2VsZWN0ZWRCYW5rLmFtb3VudC5jdXJyZW5jeSAmJiAoKHNlbGVjdGVkQmFuay5kaXJlY3Rpb24gPT09ICdjcmVkaXQnKSA9PT0gKHNlbGVjdGVkRGVidC5kaXJlY3Rpb24gPT09ICdyZWNlaXZhYmxlJykpICYmIGNvZGVQb2ludExlbmd0aChyZWFzb24udHJpbSgpKSA+PSA1KTtcclxuICAgIGNvbnN0IHNlbGVjdFRhYiA9IChfZXZlbnQ6IFN5bnRoZXRpY0V2ZW50LCB2YWx1ZTogJ2JhbmsnIHwgJ2NvZCcgfCAnY2FzZXMnKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMocGFyYW1zKTtcclxuICAgICAgICBpZiAodmFsdWUgPT09ICdiYW5rJykgbmV4dC5kZWxldGUoJ3RhYicpO1xyXG4gICAgICAgIGVsc2UgbmV4dC5zZXQoJ3RhYicsIHZhbHVlKTtcclxuICAgICAgICBzZXRQYXJhbXMobmV4dCwgeyByZXBsYWNlOiB0cnVlLCBmbHVzaFN5bmM6IHRydWUgfSk7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCLEkOG7kWkgc2/DoXQgbmfDom4gaMOgbmcgJiBDT0RcIiBzdWJ0aXRsZT1cIktow6FjaCB0cuG6oyB0aeG7gW4gY2hvIMSRxqFuIHbhu4sgZ2lhbyBow6BuZyBjaMawYSDEkeG7k25nIG5naMSpYSB0aeG7gW4gxJHDoyB24buBIHNob3AuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzZXRJbXBvcnQodHJ1ZSl9Pk5o4bqtcCBi4bqjbmcgxJHhu5FpIHNvw6F0PC9NdXRhdGlvbkJ1dHRvbj59Lz48VGFicyB2YWx1ZT17dGFifSBvbkNoYW5nZT17c2VsZWN0VGFifSBzeD17bGF5b3V0U3gucGFnZS5zZWN0aW9uQWZ0ZXJ9IHZhcmlhbnQ9XCJzY3JvbGxhYmxlXCI+PFRhYiB2YWx1ZT1cImJhbmtcIiBsYWJlbD1cIk5nw6JuIGjDoG5nXCIvPjxUYWIgdmFsdWU9XCJjb2RcIiBsYWJlbD1cIkNPRFwiLz48VGFiIHZhbHVlPVwiY2FzZXNcIiBsYWJlbD1cIkNow6puaCBs4buHY2ggY+G6p24geOG7rSBsw71cIi8+PC9UYWJzPjxQYW5lbD57dGFiID09PSAnYmFuaycgPyA8UXVlcnlTdGF0ZSBxdWVyeT17YmFua3N9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntiYW5rcy5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIkdpYW8gZOG7i2NoIHNhbyBrw6ogbmfDom4gaMOgbmdcIiByb3dzPXtiYW5rcy5kYXRhLmRhdGF9IHJvd0tleT17cm93ID0+IHJvdy5pZH0gZW1wdHk9XCJDaMawYSBjw7MgZ2lhbyBk4buLY2ggc2FvIGvDqiB0cm9uZyBwaOG6oW0gdmkgxJFhbmcgeGVtLlwiIGVtcHR5QWN0aW9uPXs8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEltcG9ydCh0cnVlKX0+Tmjhuq1wIGLhuqNuZyBzYW8ga8OqPC9CdXR0b24+fSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnTcOjIG5nb8OgaSBo4buHIHRo4buRbmcnLCByZW5kZXI6IHJvdyA9PiByb3cuZXh0ZXJuYWxUcmFuc2FjdGlvbklkIH0sXHJcbiAgICAgICAgeyBrZXk6ICdhY2NvdW50JywgbGFiZWw6ICdUw6BpIGtob+G6o24nLCByZW5kZXI6IHJvdyA9PiByb3cuYWNjb3VudElkIH0sXHJcbiAgICAgICAgeyBrZXk6ICdtb25leScsIGxhYmVsOiAnU+G7kSB0aeG7gW4nLCByZW5kZXI6IHJvdyA9PiA8QW1vdW50IHZhbHVlPXtyb3cuYW1vdW50fS8+IH0sXHJcbiAgICAgICAgeyBrZXk6ICdkaXJlY3Rpb24nLCBsYWJlbDogJ0NoaeG7gXUnLCByZW5kZXI6IHJvdyA9PiByb3cuZGlyZWN0aW9uID09PSAnY3JlZGl0JyA/ICdUaeG7gW4gdsOgbycgOiAnVGnhu4FuIHJhJyB9LFxyXG4gICAgICAgIHsga2V5OiAnbm90ZScsIGxhYmVsOiAnTuG7mWkgZHVuZycsIHJlbmRlcjogcm93ID0+IHJvdy5yZWZlcmVuY2VUZXh0IH0sXHJcbiAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnS2jhu5twJywgcmVuZGVyOiByb3cgPT4gPFN0YXR1cyB2YWx1ZT17cm93Lm1hdGNoU3RhdGV9Lz4gfSxcclxuICAgIF19Lz48UGFnZXIgcGFnZT17YmFua3MuZGF0YS5wYWdlfSBjdXJzb3JQYXJhbT1cImJhbmtDdXJzb3JcIi8+PC8+fTwvUXVlcnlTdGF0ZT4gOiB0YWIgPT09ICdjb2QnID8gPFF1ZXJ5U3RhdGUgcXVlcnk9e2NvZH0gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2NvZC5kYXRhICYmIDw+PERhdGFUYWJsZSBsYWJlbD1cIsSQ4bujdCDEkeG7kWkgc2/DoXQgQ09EXCIgcm93cz17Y29kLmRhdGEuZGF0YX0gcm93S2V5PXtyb3cgPT4gcm93LmlkfSBlbXB0eT1cIkNoxrBhIGPDsyDEkeG7o3QgxJHhu5FpIHNvw6F0IENPRCB0cm9uZyBwaOG6oW0gdmkgxJFhbmcgeGVtLlwiIGNvbHVtbnM9e1tcclxuICAgICAgICB7IGtleTogJ2lkJywgbGFiZWw6ICfEkOG7o3QgQ09EJywgcmVuZGVyOiByb3cgPT4gcm93LmV4dGVybmFsQmF0Y2hJZCB9LFxyXG4gICAgICAgIHsga2V5OiAnY2FycmllcicsIGxhYmVsOiAnxJDGoW4gduG7iyBnaWFvJywgcmVuZGVyOiByb3cgPT4gcm93LmNhcnJpZXJJZCB9LFxyXG4gICAgICAgIHsga2V5OiAnZ3Jvc3MnLCBsYWJlbDogJ1Bo4bqjaSB0aHUnLCByZW5kZXI6IHJvdyA9PiA8QW1vdW50IHZhbHVlPXtyb3cuZ3Jvc3NEdWV9Lz4gfSxcclxuICAgICAgICB7IGtleTogJ2ZlZScsIGxhYmVsOiAnUGjDrSB0aOG7sWMgdOG6vycsIHJlbmRlcjogcm93ID0+IDxBbW91bnQgdmFsdWU9e3Jvdy5hY3R1YWxGZWVzfS8+IH0sXHJcbiAgICAgICAgeyBrZXk6ICdjYXNoJywgbGFiZWw6ICfEkMOjIHbhu4EgbmfDom4gaMOgbmcnLCByZW5kZXI6IHJvdyA9PiA8QW1vdW50IHZhbHVlPXtyb3cuYmFua1JlY2VpdmVkfS8+IH0sXHJcbiAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogcm93ID0+IDxTdGF0dXMgdmFsdWU9e3Jvdy5zdGF0dXN9Lz4gfSxcclxuICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiByb3cgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIGRpc2FibGVkPXtyb3cuc3RhdHVzID09PSAnbWF0Y2hlZCd9IG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWQocm93KTsgc2V0VHJhbnNhY3Rpb24oJycpOyBzZXRGZWVzKHJvdy5hY3R1YWxGZWVzLmFtb3VudCk7IHNldEV2aWRlbmNlKCcnKTsgfX0+xJDhu5FpIGNoaeG6v3U8L011dGF0aW9uQnV0dG9uPiB9LFxyXG4gICAgXX0vPjxQYWdlciBwYWdlPXtjb2QuZGF0YS5wYWdlfSBjdXJzb3JQYXJhbT1cImNvZEN1cnNvclwiLz48Lz59PC9RdWVyeVN0YXRlPiA6IDxRdWVyeVN0YXRlIHF1ZXJ5PXtjYXNlc30gcGVuZGluZ1Byb2ZpbGU9XCJzZWN0aW9uXCI+e2Nhc2VzLmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiSOG7kyBzxqEgZ2jDqXAgdsOgIMSR4buRaSBjaGnhur91XCIgcm93cz17Y2FzZXMuZGF0YS5kYXRhfSByb3dLZXk9e3JvdyA9PiByb3cuaWR9IGVtcHR5PVwiQ2jGsGEgY8OzIGjhu5Mgc8ahIGNow6puaCBs4buHY2ggY+G6p24geOG7rSBsw70gdHJvbmcgcGjhuqFtIHZpIMSRYW5nIHhlbS5cIiBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnTcOjJywgcmVuZGVyOiByb3cgPT4gcm93LmlkIH0sXHJcbiAgICAgICAgeyBrZXk6ICd0cmFuc2FjdGlvbicsIGxhYmVsOiAnR2lhbyBk4buLY2gnLCByZW5kZXI6IHJvdyA9PiBiYW5rcy5kYXRhPy5kYXRhLmZpbmQodHJhbnNhY3Rpb24gPT4gdHJhbnNhY3Rpb24uaWQgPT09IHJvdy50cmFuc2FjdGlvbklkKT8uZXh0ZXJuYWxUcmFuc2FjdGlvbklkIHx8IHJvdy50cmFuc2FjdGlvbklkIH0sXHJcbiAgICAgICAgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogcm93ID0+IDxTdGF0dXMgdmFsdWU9e3Jvdy5zdGF0ZX0vPiB9LFxyXG4gICAgICAgIHsga2V5OiAncmVhc29uJywgbGFiZWw6ICdD4bqnbiB44butIGzDvScsIHJlbmRlcjogcm93ID0+IHJvdy5yZWFzb24gfSxcclxuICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiByb3cgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLnJlY29uY2lsZVwiIGRpc2FibGVkPXtyb3cuc3RhdGUgPT09ICdtYXRjaGVkJ30gb25DbGljaz17KCkgPT4geyBzZXRDYXNlKHJvdyk7IHNldFRyYW5zYWN0aW9uKHJvdy50cmFuc2FjdGlvbklkKTsgc2V0UmVzb3VyY2UoJycpOyBzZXRBbGxvY2F0aW9uKCcnKTsgc2V0UmVhc29uKCcnKTsgfX0+R2jDqXAgZ2lhbyBk4buLY2g8L011dGF0aW9uQnV0dG9uPiB9LFxyXG4gICAgXX0vPjxQYWdlciBwYWdlPXtjYXNlcy5kYXRhLnBhZ2V9IGN1cnNvclBhcmFtPVwiY2FzZUN1cnNvclwiLz48Lz59PC9RdWVyeVN0YXRlPn08L1BhbmVsPlxyXG4gICAgPEVkaXREaWFsb2cgb3Blbj17ISFzZWxlY3RlZH0gdGl0bGU9XCJHaMOpcCB0aeG7gW4gQ09EXCIgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGJ1c3k9e21hdGNoLnBlbmRpbmd9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshY29kTWF0Y2hWYWxpZCB8fCBtYXRjaC5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IG1hdGNoLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IHNlbGVjdGVkPy5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LnZlcnNpb24gfHwgMSwgYmFua1RyYW5zYWN0aW9uSWQ6IHRyYW5zYWN0aW9uLCBhY3R1YWxGZWVzOiB7IGFtb3VudDogZmVlcywgY3VycmVuY3k6IHNob3AuY3VycmVuY3kgfSwgZmVlRXZpZGVuY2VSZWY6IGV2aWRlbmNlLCByZWFzb246ICfEkOG7kWkgY2hp4bq/dSBi4bqjbmcgQ09EIHbDoCBnaWFvIGThu4tjaCBuZ8OibiBow6BuZycgfSB9KTsgc2V0U2VsZWN0ZWQobnVsbCk7IH0gY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+WMOhYyBuaOG6rW4ga2jhu5twPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e21hdGNoLmVycm9yfS8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2JhbmtDaG9pY2VzfT57YmFua0Nob2ljZXMuZGF0YSAmJiA8Rm9ybUZpZWxkcyA+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJNw6MgZ2lhbyBk4buLY2ggbmfDom4gaMOgbmdcIiB2YWx1ZT17dHJhbnNhY3Rpb259IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRUcmFuc2FjdGlvbihldmVudC50YXJnZXQudmFsdWUpfT48TWVudUl0ZW0gdmFsdWU9XCJcIj5DaOG7jW4gZ2lhbyBk4buLY2ggY2jGsGEgZ2jDqXA8L01lbnVJdGVtPntiYW5rQ2hvaWNlcy5kYXRhLmRhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbS5kaXJlY3Rpb24gPT09ICdjcmVkaXQnICYmIGl0ZW0ubWF0Y2hTdGF0ZSA9PT0gJ3VubWF0Y2hlZCcgJiYgaXRlbS5hbW91bnQuY3VycmVuY3kgPT09IHNlbGVjdGVkPy5ncm9zc0R1ZS5jdXJyZW5jeSkubWFwKGl0ZW0gPT4gPE1lbnVJdGVtIGtleT17aXRlbS5pZH0gdmFsdWU9e2l0ZW0uaWR9PntpdGVtLmV4dGVybmFsVHJhbnNhY3Rpb25JZH0gwrcge2Zvcm1hdE1vbmV5KGl0ZW0uYW1vdW50KX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwiZ2lhbyBk4buLY2ggbmfDom4gaMOgbmdcIiBsb2FkZWRDb3VudD17YmFua0Nob2ljZXMubG9hZGVkQ291bnR9IGhhc01vcmU9e2JhbmtDaG9pY2VzLmhhc01vcmV9IGJ1c3k9e2JhbmtDaG9pY2VzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2JhbmtDaG9pY2VzLmxvYWRNb3JlfS8+PFRleHRGaWVsZCBsYWJlbD17YFBow60gdGjhu7FjIHThur8gKCR7c2hvcC5jdXJyZW5jeX0pYH0gdmFsdWU9e2ZlZXN9IGVycm9yPXtmZWVVbml0cyA9PT0gbnVsbH0gaGVscGVyVGV4dD17c2VsZWN0ZWRCYW5rICYmIGZlZVVuaXRzICE9PSBudWxsICYmICFjb2RNYXRjaFZhbGlkID8gJ1Rp4buBbiB24buBICsgcGjDrSBwaOG6o2kgYuG6sW5nIGtob+G6o24gQ09EIHbDoCBj4bqnbiBjaOG7qW5nIHThu6sgcGjDrS4nIDogJ05o4bqtcCBwaMOtIHRoZW8gY2jhu6luZyB04burOyBraG/huqNuIGZlZSDEkcOjIGto4bqldSB0cuG7qyBraMO0bmcgcGjhuqNpIGNoaSB0aeG7gW4gdGjDqm0uJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEZlZXMoZXZlbnQudGFyZ2V0LnZhbHVlKX0gaW5wdXRQcm9wcz17eyBpbnB1dE1vZGU6ICdkZWNpbWFsJyB9fS8+PFRleHRGaWVsZCBsYWJlbD1cIk3DoyBjaOG7qW5nIHThu6sgcGjDrVwiIHZhbHVlPXtldmlkZW5jZX0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEV2aWRlbmNlKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz48QWxlcnQgc2V2ZXJpdHk9XCJ3YXJuaW5nXCI+S2jDtG5nIHjDoWMgbmjhuq1uIHRoYW5oIHRvw6FuIGLhurFuZyDhuqNuaCBjaHV54buDbiBraG/huqNuLiBU4buVbmcgdGnhu4FuIHbhu4EgdsOgIHBow60gcGjhuqNpIGto4bubcCBraG/huqNuIENPRC48L0FsZXJ0PjwvRm9ybUZpZWxkcz59PC9RdWVyeVN0YXRlPjwvRWRpdERpYWxvZz5cclxuICAgIDxFZGl0RGlhbG9nIG9wZW49eyEhY2FzZUl0ZW19IHRpdGxlPVwiR2jDqXAgZ2lhbyBk4buLY2ggduG7m2kgY8O0bmcgbuG7o1wiIG9uQ2xvc2U9eygpID0+IHNldENhc2UobnVsbCl9IGJ1c3k9e21hdGNoQmFuay5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIHZhcmlhbnQ9XCJjb250YWluZWRcIiBkaXNhYmxlZD17IWJhbmtNYXRjaFZhbGlkIHx8IG1hdGNoQmFuay5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IG1hdGNoQmFuay5leGVjdXRlKHsgcGF0aDogeyByZXNvdXJjZUlkOiBjYXNlSXRlbT8uaWQgfHwgJycgfSwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGNhc2VJdGVtPy52ZXJzaW9uIHx8IDEsIHRyYW5zYWN0aW9uSWQ6IHRyYW5zYWN0aW9uLCBhbGxvY2F0aW9uczogW3sgcmVzb3VyY2U6IHsgdHlwZTogJ2RlYnQnLCBpZDogcmVzb3VyY2VJZCB9LCBhbW91bnQ6IHsgYW1vdW50OiBhbGxvY2F0aW9uLCBjdXJyZW5jeTogc2hvcC5jdXJyZW5jeSB9IH1dLCByZWFzb24gfSB9KTsgc2V0Q2FzZShudWxsKTsgfSBjYXRjaCB7IC8qIGtlZXAgZm9ybSBhbmQgZXJyb3IgKi8gfSB9fT5HaGkga+G6v3QgcXXhuqMgxJHhu5FpIHNvw6F0PC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e21hdGNoQmFuay5lcnJvcn0vPjxRdWVyeVN0YXRlIHF1ZXJ5PXtjYXNlQmFua30+e2Nhc2VCYW5rLmRhdGEgJiYgPFF1ZXJ5U3RhdGUgcXVlcnk9e2RlYnRDaG9pY2VzfT57ZGVidENob2ljZXMuZGF0YSAmJiA8Rm9ybUZpZWxkcyA+PFRleHRGaWVsZCBsYWJlbD1cIkdpYW8gZOG7i2NoIG5nb8OgaSBo4buHIHRo4buRbmdcIiB2YWx1ZT17Y2FzZUJhbmsuZGF0YS5kYXRhLmV4dGVybmFsVHJhbnNhY3Rpb25JZH0gSW5wdXRQcm9wcz17eyByZWFkT25seTogdHJ1ZSB9fS8+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJLaG/huqNuIGPDtG5nIG7hu6NcIiB2YWx1ZT17cmVzb3VyY2VJZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJlc291cmNlKGV2ZW50LnRhcmdldC52YWx1ZSl9PjxNZW51SXRlbSB2YWx1ZT1cIlwiPkNo4buNbiBraG/huqNuIG7hu6MgY2jGsGEgdHJhbmggY2jhuqVwPC9NZW51SXRlbT57ZGVidENob2ljZXMuZGF0YS5kYXRhLmZpbHRlcihpdGVtID0+ICFpdGVtLmRpc3B1dGVkICYmIGhhc091dHN0YW5kaW5nQmFsYW5jZShpdGVtLm91dHN0YW5kaW5nQW1vdW50LmFtb3VudCkgJiYgaXRlbS5vdXRzdGFuZGluZ0Ftb3VudC5jdXJyZW5jeSA9PT0gc2VsZWN0ZWRCYW5rPy5hbW91bnQuY3VycmVuY3kgJiYgKChzZWxlY3RlZEJhbms/LmRpcmVjdGlvbiA9PT0gJ2NyZWRpdCcpID09PSAoaXRlbS5kaXJlY3Rpb24gPT09ICdyZWNlaXZhYmxlJykpKS5tYXAoaXRlbSA9PiA8TWVudUl0ZW0ga2V5PXtpdGVtLmlkfSB2YWx1ZT17aXRlbS5pZH0+e2l0ZW0uaWR9IMK3IHtpdGVtLmRpcmVjdGlvbiA9PT0gJ3JlY2VpdmFibGUnID8gJ1Bo4bqjaSB0aHUnIDogJ1Bo4bqjaSB0cuG6oyd9IMK3IHtmb3JtYXRNb25leShpdGVtLm91dHN0YW5kaW5nQW1vdW50KX08L01lbnVJdGVtPil9PC9UZXh0RmllbGQ+PExvb2t1cExvYWRNb3JlIGxhYmVsPVwiY8O0bmcgbuG7o1wiIGxvYWRlZENvdW50PXtkZWJ0Q2hvaWNlcy5sb2FkZWRDb3VudH0gaGFzTW9yZT17ZGVidENob2ljZXMuaGFzTW9yZX0gYnVzeT17ZGVidENob2ljZXMuaXNMb2FkaW5nTW9yZX0gb25Mb2FkTW9yZT17ZGVidENob2ljZXMubG9hZE1vcmV9Lz48VGV4dEZpZWxkIGxhYmVsPXtgU+G7kSB0aeG7gW4gcGjDom4gYuG7lSAoJHtzaG9wLmN1cnJlbmN5fSlgfSB2YWx1ZT17YWxsb2NhdGlvbn0gZXJyb3I9e2FsbG9jYXRpb24gIT09ICcnICYmIGFsbG9jYXRpb25Vbml0cyA9PT0gbnVsbH0gaGVscGVyVGV4dD17YWxsb2NhdGlvblVuaXRzICE9PSBudWxsICYmIGFsbG9jYXRpb25Vbml0cyA+IDBuICYmICFiYW5rTWF0Y2hWYWxpZCA/ICdT4buRIHRp4buBbiB2xrDhu6N0IGNow6puaCBs4buHY2gva2hv4bqjbiBu4bujLCBraMOhYyB0aeG7gW4gdOG7hyBob+G6t2MgdGhp4bq/dSBsw70gZG8uJyA6ICcnfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0QWxsb2NhdGlvbihldmVudC50YXJnZXQudmFsdWUpfSBpbnB1dFByb3BzPXt7IGlucHV0TW9kZTogJ2RlY2ltYWwnIH19Lz48VGV4dEZpZWxkIGxhYmVsPVwiTMO9IGRvXCIgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJlYXNvbihldmVudC50YXJnZXQudmFsdWUpfS8+PC9Gb3JtRmllbGRzPn08L1F1ZXJ5U3RhdGU+fTwvUXVlcnlTdGF0ZT48L0VkaXREaWFsb2c+XHJcbiAgICB7aW1wb3J0T3BlbiAmJiA8U3RhdGVtZW50RGlhbG9nIG9uQ2xvc2U9eygpID0+IHNldEltcG9ydChmYWxzZSl9Lz59PC8+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBEZWJ0c1BhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XHJcbiAgICBjb25zdCBbcGVyaW9kT3BlbixzZXRQZXJpb2RPcGVuXT11c2VTdGF0ZShmYWxzZSksW3BlcmlvZFNhdmVkLHNldFBlcmlvZFNhdmVkXT11c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBkZWJ0cyA9IHVzZUFwaSgnbGlzdERlYnRJdGVtcycsIHsgcXVlcnk6IHVzZUxpc3RRdWVyeSgnbGlzdERlYnRJdGVtcycpIH0pLCBwZXJpb2RzID0gdXNlQXBpKCdsaXN0QWNjb3VudGluZ1BlcmlvZHMnKTtcclxuICAgIGNvbnN0IGNsb3NlID0gdXNlQ29tbWFuZCgnY2xvc2VBY2NvdW50aW5nUGVyaW9kJywgWydsaXN0QWNjb3VudGluZ1BlcmlvZHMnXSk7XHJcbiAgICBjb25zdCByZW9wZW4gPSB1c2VDb21tYW5kKCdyZW9wZW5BY2NvdW50aW5nUGVyaW9kJywgWydsaXN0QWNjb3VudGluZ1BlcmlvZHMnXSk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPEFjY291bnRpbmdQZXJpb2QgfCBudWxsPihudWxsKSwgW2FwcHJvdmFsLCBzZXRBcHByb3ZhbF0gPSB1c2VTdGF0ZSgnJyksIFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIkPDtG5nIG7hu6MgJiBraMOzYSBr4buzXCIgc3VidGl0bGU9XCJUaGVvIGTDtWkga2hv4bqjbiBjw7JuIHBo4bqjaSB0aHUvdHLhuqM7IGtow7NhIGvhu7MgY2jhu4kga2hpIGPDoWMgxJFp4buBdSBraeG7h24gxJHGsOG7o2Mga2nhu4NtIGNo4bupbmcuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLmNsb3NlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpPT5zZXRQZXJpb2RPcGVuKHRydWUpfT5U4bqhbyBr4buzIGvhur8gdG/DoW48L011dGF0aW9uQnV0dG9uPn0vPntwZXJpb2RTYXZlZCYmPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIj7EkMOjIHThuqFvIGvhu7Mga+G6vyB0b8OhbiBt4bubaS48L0FsZXJ0Pn17cGVyaW9kT3BlbiYmPENyZWF0ZVBlcmlvZERpYWxvZyBvbkNsb3NlPXsoKT0+c2V0UGVyaW9kT3BlbihmYWxzZSl9IG9uU2F2ZWQ9eygpPT5zZXRQZXJpb2RTYXZlZCh0cnVlKX0vPn08UGFuZWwgdGl0bGU9XCJDw7RuZyBu4bujXCI+PFF1ZXJ5U3RhdGUgcXVlcnk9e2RlYnRzfSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57ZGVidHMuZGF0YSAmJiA8PjxEYXRhVGFibGUgbGFiZWw9XCJDw7RuZyBu4bujXCIgcm93cz17ZGVidHMuZGF0YS5kYXRhfSByb3dLZXk9e3IgPT4gci5pZH0gY29sdW1ucz17W1xyXG4gICAgICAgIHsga2V5OiAnaWQnLCBsYWJlbDogJ0tob+G6o24gbuG7oycsIHJlbmRlcjogciA9PiByLmlkIH0sIHsga2V5OiAnd2hvJywgbGFiZWw6ICfEkOG7kWkgdMaw4bujbmcnLCByZW5kZXI6IHIgPT4gYCR7ci5jb3VudGVycGFydHlUeXBlfSAvIE3DoyDEkeG7kWkgdMaw4bujbmc6ICR7ci5jb3VudGVycGFydHlJZH1gIH0sIHsga2V5OiAnZGlyZWN0aW9uJywgbGFiZWw6ICdMb+G6oWknLCByZW5kZXI6IHIgPT4gci5kaXJlY3Rpb24gPT09ICdyZWNlaXZhYmxlJyA/ICdQaOG6o2kgdGh1JyA6ICdQaOG6o2kgdHLhuqMnIH0sIHsga2V5OiAnb3JpZ2luYWwnLCBsYWJlbDogJ0JhbiDEkeG6p3UnLCByZW5kZXI6IHIgPT4gPEFtb3VudCB2YWx1ZT17ci5vcmlnaW5hbEFtb3VudH0vPiB9LCB7IGtleTogJ2N1cnJlbnQnLCBsYWJlbDogJ0PDsm4gbOG6oWknLCByZW5kZXI6IHIgPT4gPEFtb3VudCB2YWx1ZT17ci5vdXRzdGFuZGluZ0Ftb3VudH0vPiB9LCB7IGtleTogJ2R1ZScsIGxhYmVsOiAnxJDhur9uIGjhuqFuJywgcmVuZGVyOiByID0+IGRhdGVUaW1lKHIuZHVlQXQsIHNob3AudGltZXpvbmUpIH0sIHsga2V5OiAnZGlzcHV0ZScsIGxhYmVsOiAnVHJhbmggY2jhuqVwJywgcmVuZGVyOiByID0+IHIuZGlzcHV0ZWQgPyAnxJBhbmcgZ2nhu68geOG7rSBsw70nIDogJ0tow7RuZycgfVxyXG4gICAgXX0vPjxQYWdlciBwYWdlPXtkZWJ0cy5kYXRhLnBhZ2V9Lz48Lz59PC9RdWVyeVN0YXRlPjwvUGFuZWw+PFBhbmVsIHRpdGxlPVwiS+G7syBr4bq/IHRvw6FuXCIgYmVmb3JlR2FwPXtcInNlY3Rpb25cIn0+PFF1ZXJ5U3RhdGUgcXVlcnk9e3BlcmlvZHN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPjxEYXRhVGFibGUgbGFiZWw9XCJL4buzIGvhur8gdG/DoW5cIiByb3dzPXtwZXJpb2RzLmRhdGE/LmRhdGEgfHwgW119IHJvd0tleT17ciA9PiByLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICdwZXJpb2QnLCBsYWJlbDogJ0vhu7MnLCByZW5kZXI6IHIgPT4gYCR7Zm9ybWF0RGF0ZU9ubHkoci5zdGFydERhdGUpfSDihpIgJHtmb3JtYXREYXRlT25seShyLmVuZERhdGUpfWAgfSwgeyBrZXk6ICdzdGF0ZScsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogciA9PiA8U3RhdHVzIGRvbWFpbj1cImFjY291bnRpbmdQZXJpb2RcIiB2YWx1ZT17ci5zdGF0ZX0vPiB9LCB7IGtleTogJ2lzc3VlcycsIGxhYmVsOiAnxJBp4buBdSBraeG7h24gY8OybiB0aGnhur91JywgcmVuZGVyOiByID0+IHIuYmxvY2tpbmdJc3N1ZXMuam9pbignOyAnKSB8fCAnWMOhYyBtaW5oIGzhuqFpIHThuqFpIGzDumMgZ2hpJyB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiAnYWN0aW9uJywgbGFiZWw6ICcnLCByZW5kZXI6IHIgPT4gPE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLmNsb3NlXCIgb25DbGljaz17KCkgPT4geyBzZXRTZWxlY3RlZChyKTsgc2V0QXBwcm92YWwoJycpOyBzZXRSZWFzb24oJycpOyB9fT57ci5zdGF0ZSA9PT0gJ2Nsb3NlZCcgPyAnTeG7nyBs4bqhaSBjw7MgcGjDqiBkdXnhu4d0JyA6ICdLaeG7g20gJiBraMOzYSBr4buzJ308L011dGF0aW9uQnV0dG9uPlxyXG4gICAgICAgIH1cclxuICAgIF19Lz48L1F1ZXJ5U3RhdGU+PC9QYW5lbD48Q29uZmlybURpYWxvZyBvcGVuPXshIXNlbGVjdGVkICYmIHNlbGVjdGVkLnN0YXRlICE9PSAnY2xvc2VkJ30gdGl0bGU9XCJLaMOzYSBr4buzIGvhur8gdG/DoW5cIiBjb25maXJtTGFiZWw9XCJLaMOzYSBr4buzIGvhur8gdG/DoW5cIiBkZXNjcmlwdGlvbj17YEvhu7MgJHtzZWxlY3RlZD8uaWQgfHwgXCJcIn0sIHThu6sgJHtzZWxlY3RlZD8uc3RhcnREYXRlIHx8IFwiXCJ9IMSR4bq/biAke3NlbGVjdGVkPy5lbmREYXRlIHx8IFwiXCJ9OiBraMOzYSBnaGkgc+G7lSBt4bubaSBzYXUga2hpIGtp4buDbSBjaOG7qW5nIHThu6sgbmjDoXAsIHNhaSBs4buHY2ggdsOgIENPRC4gTeG7nyBs4bqhaSBj4bqnbiBxdXnhu4FuIHbDoCBwaMOqIGR1eeG7h3QgcmnDqm5nLmB9IG9uQ2xvc2U9eygpID0+IHNldFNlbGVjdGVkKG51bGwpfSBidXN5PXtjbG9zZS5wZW5kaW5nfSBlcnJvcj17Y2xvc2UuZXJyb3J9IG9uQ29uZmlybT17KCkgPT4gY2xvc2UuZXhlY3V0ZSh7IHBhdGg6IHsgcmVzb3VyY2VJZDogc2VsZWN0ZWQ/LmlkIHx8ICcnIH0sIGJvZHk6IHsgZXhwZWN0ZWRWZXJzaW9uOiBzZWxlY3RlZD8udmVyc2lvbiB8fCAxIH0gfSl9Lz48RWRpdERpYWxvZyBvcGVuPXtzZWxlY3RlZD8uc3RhdGUgPT09ICdjbG9zZWQnfSB0aXRsZT1cIk3hu58gbOG6oWkga+G7syDEkcOjIGtow7NhXCIgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9IGJ1c3k9e3Jlb3Blbi5wZW5kaW5nfSBhY3Rpb25zPXs8QnV0dG9uIGRpc2FibGVkPXshYXBwcm92YWwgfHwgY29kZVBvaW50TGVuZ3RoKHJlYXNvbikgPCA1IHx8IHJlb3Blbi5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7IHRyeSB7XHJcbiAgICAgICAgYXdhaXQgcmVvcGVuLmV4ZWN1dGUoeyBwYXRoOiB7IHJlc291cmNlSWQ6IHNlbGVjdGVkPy5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LnZlcnNpb24gfHwgMSwgYXBwcm92YWxJZDogYXBwcm92YWwsIHJlYXNvbiB9IH0pO1xyXG4gICAgICAgIHNldFNlbGVjdGVkKG51bGwpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggeyAvKiB2aXNpYmxlICovIH0gfX0+TeG7nyBs4bqhaSBr4buzPC9CdXR0b24+fT48RXJyb3JOb3RpY2UgZXJyb3I9e3Jlb3Blbi5lcnJvcn0vPjxGb3JtRmllbGRzID48VGV4dEZpZWxkIGxhYmVsPVwiTcOjIHBow6ogZHV54buHdCDEkcO6bmcga+G7s1wiIHZhbHVlPXthcHByb3ZhbH0gb25DaGFuZ2U9e2UgPT4gc2V0QXBwcm92YWwoZS50YXJnZXQudmFsdWUpfS8+PFRleHRGaWVsZCBsYWJlbD1cIkzDvSBkb1wiIHZhbHVlPXtyZWFzb259IG9uQ2hhbmdlPXtlID0+IHNldFJlYXNvbihlLnRhcmdldC52YWx1ZSl9Lz48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPjwvPjtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9maW5hbmNlL2luZGV4LnRzeCJ9