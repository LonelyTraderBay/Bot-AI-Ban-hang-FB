import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/finance/accounts.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react_jsx-dev-runtime.js?v=585edd0d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react.js?v=585edd0d"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Alert, Button, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/@mui_material.js?v=585edd0d";
import { useForm, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/react-hook-form.js?v=585edd0d";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/@hookform_resolvers_zod.js?v=585edd0d";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/playwright-87852-9f9f3946-5e8b-474a-a79a-5a977121e5b9/deps/zod.js?v=585edd0d";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { useVersionedDraft, draftEqual } from "/src/shared/model/versioned-draft.ts";
import { useDraftForm, markDraftClean } from "/src/shared/model/dirty-drafts.ts";
import { codePointLength } from "/src/shared/model/format.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { FormFields, ActionGroup } from "/src/shared/ui/composition.tsx";
import { PageHeader, Panel, Toolbar, QueryState, DataTable, Pager, Status, MutationButton, EditDialog, ConfirmDialog, ErrorNotice } from "/src/shared/ui/components.tsx";
const schema = z.object({ code: z.string().regex(/^[A-Za-z0-9_.-]{1,40}$/, "Mã gồm 1–40 chữ/số, dấu chấm, gạch ngang hoặc gạch dưới."), name: z.string().refine((v) => codePointLength(v) <= 160, "Tên tối đa 160 ký tự.").trim().min(1, "Nhập tên tài khoản."), group: z.enum(["asset", "liability", "equity", "income", "expense"]) });
const empty = { code: "", name: "", group: "asset" };
const snapshot = (account) => ({ version: account.version, values: { code: account.code, name: account.name, group: account.group } });
export const accountGroupName = { asset: "Tài sản", liability: "Nợ phải trả", equity: "Vốn chủ sở hữu", income: "Thu nhập", expense: "Chi phí" };
export function AccountsPage() {
  _s();
  const { shop } = useScope(), canEdit = useCan("finance.accounts.manage");
  const list = useApi("listAccounts", { query: useListQuery("listAccounts") });
  const [open, setOpen] = useState(false), [selected, setSelected] = useState(null), [archive, setArchive] = useState(null), [success, setSuccess] = useState("");
  const detail = useApi("getAccount", { path: { accountId: selected?.id || "" } }, open && Boolean(selected));
  const create = useCommand("createAccount", ["listAccounts"]), update = useCommand("updateAccount", ["listAccounts", "getAccount"]), remove = useCommand("archiveAccount", ["listAccounts", "getAccount"]);
  const form = useForm({ defaultValues: empty, resolver: zodResolver(schema) });
  useWatch({ control: form.control });
  const editor = useVersionedDraft({ identity: `${shop.id}:account:${selected?.id || "new"}`, source: detail.data ? snapshot(detail.data.data) : selected ? snapshot(selected) : void 0, draft: form.getValues(), apply: (values) => form.reset(values), refresh: () => detail.refetch({ throwOnError: true }) });
  const dirty = open && (selected ? editor.dirty : !draftEqual(empty, form.getValues())), bindDraft = useDraftForm(dirty), formRef = useRef(null), busy = create.pending || update.pending;
  const used = detail.data?.data.used ?? selected?.used ?? false;
  const blocked = Boolean(selected ? update.unresolved : create.unresolved);
  const submit = form.handleSubmit(async (values) => {
    if (!canEdit || blocked) return;
    try {
      if (selected) {
        const prepared = editor.prepare();
        if (!prepared) return;
        const submitted = form.getValues(), patch = { ...prepared.patch };
        for (const key of Object.keys(patch)) Object.assign(patch, { [key]: values[key] });
        const response = await update.execute({ path: { accountId: selected.id }, version: prepared.version, body: patch });
        if (!editor.committed(snapshot(response.data), submitted)) return;
      } else
        await create.execute({ body: values });
      if (formRef.current) markDraftClean(formRef.current);
      setSuccess(`Đã lưu tài khoản ${values.code} · ${values.name}.`);
      setOpen(false);
      form.reset(empty);
    } catch (error) {
      editor.failed(error);
    }
  });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Tài khoản kế toán", subtitle: "Danh mục kế toán quản trị; mã và nhóm đã dùng trong chứng từ được bảo vệ, không phải hệ thống tài khoản pháp định.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.accounts.manage", variant: "contained", onClick: () => {
      setSelected(null);
      form.reset(empty);
      setOpen(true);
    }, children: "Thêm tài khoản" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 61,
      columnNumber: 182
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    success && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", children: success }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 62,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listAccounts", placeholder: "Tìm mã hoặc tên tài khoản…" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 63,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh mục tài khoản kế toán", rows: list.data.data, rowKey: (account) => account.id, columns: [
          { key: "code", label: "Mã tài khoản", render: (a) => a.code },
          { key: "name", label: "Tên tài khoản", render: (a) => a.name },
          { key: "group", label: "Nhóm", render: (a) => accountGroupName[a.group] },
          { key: "used", label: "Chứng từ", render: (a) => a.used ? "Đã sử dụng" : "Chưa sử dụng" },
          { key: "status", label: "Trạng thái", render: (a) => /* @__PURE__ */ jsxDEV(Status, { value: a.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
            lineNumber: 65,
            columnNumber: 357
          }, this) },
          { key: "edit", label: "Thao tác", render: (a) => a.status === "active" ? /* @__PURE__ */ jsxDEV(ActionGroup, { children: [
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.accounts.manage", onClick: () => {
              setSelected(a);
              form.reset(snapshot(a).values);
              setOpen(true);
            }, children: [
              "Sửa tài khoản ",
              a.code
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
              lineNumber: 66,
              columnNumber: 97
            }, this),
            /* @__PURE__ */ jsxDEV(MutationButton, { permission: "finance.accounts.manage", onClick: () => setArchive(a), children: [
              "Ngừng dùng ",
              a.code
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
              lineNumber: 66,
              columnNumber: 268
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
            lineNumber: 66,
            columnNumber: 84
          }, this) : "Lịch sử được giữ" }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 64,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 67,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 63,
        columnNumber: 157
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 63,
        columnNumber: 93
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 63,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: selected ? `Sửa tài khoản ${selected.code}` : "Thêm tài khoản", busy, onClose: () => setOpen(false), actions: /* @__PURE__ */ jsxDEV(Button, { type: "submit", form: "account-editor", variant: "contained", disabled: busy || blocked || !canEdit || Boolean(selected) && !editor.dirty, children: "Lưu tài khoản" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 68,
      columnNumber: 156
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || detail.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 69,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { code: "Mã tài khoản", name: "Tên tài khoản", group: "Nhóm tài khoản" }, busy }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 69,
        columnNumber: 81
      }, this),
      used && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Tài khoản đã có chứng từ; chỉ sửa tên, mã và nhóm được giữ nguyên." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 70,
        columnNumber: 22
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { component: "form", id: "account-editor", noValidate: true, ref: (node) => {
        formRef.current = node;
        bindDraft(node);
      }, onSubmit: submit, "data-draft-clean": !dirty ? "true" : void 0, children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mã tài khoản", ...form.register("code"), disabled: busy || !canEdit || used, error: Boolean(form.formState.errors.code), helperText: form.formState.errors.code?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 72,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên tài khoản", ...form.register("name"), disabled: busy || !canEdit, error: Boolean(form.formState.errors.name), helperText: form.formState.errors.name?.message }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 73,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Nhóm tài khoản", ...form.register("group"), value: form.watch("group"), disabled: busy || !canEdit || used, children: Object.entries(accountGroupName).map(([value, label]) => /* @__PURE__ */ jsxDEV(MenuItem, { value, children: label }, value, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 74,
          columnNumber: 208
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
          lineNumber: 74,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
        lineNumber: 71,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 68,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: Boolean(archive), title: "Ngừng dùng tài khoản", confirmLabel: "Ngừng dùng tài khoản", description: `Tài khoản ${archive?.code || ""} · ${archive?.name || ""} sẽ không dùng cho chứng từ mới. API chặn khi còn bút toán nháp; chứng từ và số dư lịch sử được giữ.`, requireReason: true, busy: remove.pending, error: remove.error, onClose: () => setArchive(null), onConfirm: async (reason) => {
      if (!archive) return;
      await remove.execute({ path: { accountId: archive.id }, body: { expectedVersion: archive.version, reason } });
      setSuccess(`Đã ngừng dùng tài khoản ${archive.code}.`);
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx",
    lineNumber: 60,
    columnNumber: 10
  }, this);
}
_s(AccountsPage, "QDxPe0m4vmQHG2pWKHQpgvdtP6Q=", false, function() {
  return [useScope, useCan, useApi, useListQuery, useApi, useCommand, useCommand, useCommand, useForm, useWatch, useVersionedDraft, useDraftForm];
});
_c = AccountsPage;
var _c;
$RefreshReg$(_c, "AccountsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/finance/accounts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNxTCxTQUU1QixVQUY0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6Q3JMLFNBQVNBLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxPQUFPQyxRQUFRQyxVQUFVQyxpQkFBaUI7QUFDbkQsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxTQUFTO0FBRWxCLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUJDLGtCQUFrQjtBQUM5QyxTQUFTQyxjQUFjQyxzQkFBc0I7QUFDN0MsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxZQUFZQyxtQkFBbUI7QUFDeEMsU0FBU0MsWUFBWUMsT0FBT0MsU0FBU0MsWUFBWUMsV0FBV0MsT0FBT0MsUUFBUUMsZ0JBQWdCQyxZQUFZQyxlQUFlQyxtQkFBbUI7QUFFekksTUFBTUMsU0FBT3pCLEVBQUUwQixPQUFPLEVBQUNDLE1BQUszQixFQUFFNEIsT0FBTyxFQUFFQyxNQUFNLDBCQUF5QiwwREFBMEQsR0FBRUMsTUFBSzlCLEVBQUU0QixPQUFPLEVBQUVHLE9BQU8sQ0FBQUMsTUFBR3RCLGdCQUFnQnNCLENBQUMsS0FBRyxLQUFJLHVCQUF1QixFQUFFQyxLQUFLLEVBQUVDLElBQUksR0FBRSxxQkFBcUIsR0FBRUMsT0FBTW5DLEVBQUVvQyxLQUFLLENBQUMsU0FBUSxhQUFZLFVBQVMsVUFBUyxTQUFTLENBQUMsRUFBQyxDQUFDO0FBRWpULE1BQU1DLFFBQWEsRUFBQ1YsTUFBSyxJQUFHRyxNQUFLLElBQUdLLE9BQU0sUUFBTztBQUNqRCxNQUFNRyxXQUFTQSxDQUFDQyxhQUFtQixFQUFDQyxTQUFRRCxRQUFRQyxTQUFRQyxRQUFPLEVBQUNkLE1BQUtZLFFBQVFaLE1BQUtHLE1BQUtTLFFBQVFULE1BQUtLLE9BQU1JLFFBQVFKLE1BQUssRUFBQztBQUNySCxhQUFNTyxtQkFBaUQsRUFBQ0MsT0FBTSxXQUFVQyxXQUFVLGVBQWNDLFFBQU8sa0JBQWlCQyxRQUFPLFlBQVdDLFNBQVEsVUFBUztBQUUzSixnQkFBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQzNCLFFBQU0sRUFBQ0MsS0FBSSxJQUFFL0MsU0FBUyxHQUFFZ0QsVUFBUS9DLE9BQU8seUJBQXlCO0FBQUUsUUFBTWdELE9BQUtuRCxPQUFPLGdCQUFlLEVBQUNvRCxPQUFNaEQsYUFBYSxjQUFjLEVBQUMsQ0FBQztBQUN2SSxRQUFNLENBQUNpRCxNQUFLQyxPQUFPLElBQUUvRCxTQUFTLEtBQUssR0FBRSxDQUFDZ0UsVUFBU0MsV0FBVyxJQUFFakUsU0FBdUIsSUFBSSxHQUFFLENBQUNrRSxTQUFRQyxVQUFVLElBQUVuRSxTQUF1QixJQUFJLEdBQUUsQ0FBQ29FLFNBQVFDLFVBQVUsSUFBRXJFLFNBQVMsRUFBRTtBQUMzSyxRQUFNc0UsU0FBTzdELE9BQU8sY0FBYSxFQUFDOEQsTUFBSyxFQUFDQyxXQUFVUixVQUFVUyxNQUFJLEdBQUUsRUFBQyxHQUFFWCxRQUFNWSxRQUFRVixRQUFRLENBQUM7QUFDNUYsUUFBTVcsU0FBT2pFLFdBQVcsaUJBQWdCLENBQUMsY0FBYyxDQUFDLEdBQUVrRSxTQUFPbEUsV0FBVyxpQkFBZ0IsQ0FBQyxnQkFBZSxZQUFZLENBQUMsR0FBRW1FLFNBQU9uRSxXQUFXLGtCQUFpQixDQUFDLGdCQUFlLFlBQVksQ0FBQztBQUMzTCxRQUFNb0UsT0FBS3pFLFFBQWdCLEVBQUMwRSxlQUFjbEMsT0FBTW1DLFVBQVN6RSxZQUFZMEIsTUFBTSxFQUFDLENBQUM7QUFBRTNCLFdBQVMsRUFBQzJFLFNBQVFILEtBQUtHLFFBQU8sQ0FBQztBQUM5RyxRQUFNQyxTQUFPcEUsa0JBQWtCLEVBQUNxRSxVQUFTLEdBQUd6QixLQUFLZSxFQUFFLFlBQVlULFVBQVVTLE1BQUksS0FBSyxJQUFHVyxRQUFPZCxPQUFPZSxPQUFLdkMsU0FBU3dCLE9BQU9lLEtBQUtBLElBQUksSUFBRXJCLFdBQVNsQixTQUFTa0IsUUFBUSxJQUFFc0IsUUFBVUMsT0FBTVQsS0FBS1UsVUFBVSxHQUFFQyxPQUFNQSxDQUFBeEMsV0FBUTZCLEtBQUtZLE1BQU16QyxNQUFNLEdBQUUwQyxTQUFRQSxNQUFJckIsT0FBT3NCLFFBQVEsRUFBQ0MsY0FBYSxLQUFJLENBQUMsRUFBQyxDQUFDO0FBQ2pSLFFBQU1DLFFBQU1oQyxTQUFPRSxXQUFTa0IsT0FBT1ksUUFBTSxDQUFDL0UsV0FBVzhCLE9BQU1pQyxLQUFLVSxVQUFVLENBQUMsSUFBR08sWUFBVS9FLGFBQWE4RSxLQUFLLEdBQUVFLFVBQVFqRyxPQUE2QixJQUFJLEdBQUVrRyxPQUFLdEIsT0FBT3VCLFdBQVN0QixPQUFPc0I7QUFDbkwsUUFBTUMsT0FBSzdCLE9BQU9lLE1BQU1BLEtBQUtjLFFBQU1uQyxVQUFVbUMsUUFBTTtBQUNuRCxRQUFNQyxVQUFRMUIsUUFBUVYsV0FBU1ksT0FBT3lCLGFBQVcxQixPQUFPMEIsVUFBVTtBQUNsRSxRQUFNQyxTQUFPeEIsS0FBS3lCLGFBQWEsT0FBTXRELFdBQVE7QUFDekMsUUFBRyxDQUFDVSxXQUFTeUMsUUFBUTtBQUNyQixRQUFJO0FBQ0EsVUFBR3BDLFVBQVM7QUFBQyxjQUFNd0MsV0FBU3RCLE9BQU91QixRQUFRO0FBQUUsWUFBRyxDQUFDRCxTQUFTO0FBQU8sY0FBTUUsWUFBVTVCLEtBQUtVLFVBQVUsR0FBRW1CLFFBQU0sRUFBQyxHQUFHSCxTQUFTRyxNQUFLO0FBQUUsbUJBQVVDLE9BQU9DLE9BQU9DLEtBQUtILEtBQUssRUFBdUJFLFFBQU9FLE9BQU9KLE9BQU0sRUFBQyxDQUFDQyxHQUFHLEdBQUUzRCxPQUFPMkQsR0FBRyxFQUFDLENBQUM7QUFBRSxjQUFNSSxXQUFTLE1BQU1wQyxPQUFPcUMsUUFBUSxFQUFDMUMsTUFBSyxFQUFDQyxXQUFVUixTQUFTUyxHQUFFLEdBQUV6QixTQUFRd0QsU0FBU3hELFNBQVFrRSxNQUFLUCxNQUFLLENBQUM7QUFBRSxZQUFHLENBQUN6QixPQUFPaUMsVUFBVXJFLFNBQVNrRSxTQUFTM0IsSUFBSSxHQUFFcUIsU0FBUyxFQUFFO0FBQUEsTUFBTztBQUNoWSxjQUFNL0IsT0FBT3NDLFFBQVEsRUFBQ0MsTUFBS2pFLE9BQU0sQ0FBQztBQUN2QyxVQUFHK0MsUUFBUW9CLFFBQVFuRyxnQkFBZStFLFFBQVFvQixPQUFPO0FBQUUvQyxpQkFBVyxvQkFBb0JwQixPQUFPZCxJQUFJLE1BQU1jLE9BQU9YLElBQUksR0FBRztBQUFFeUIsY0FBUSxLQUFLO0FBQUVlLFdBQUtZLE1BQU03QyxLQUFLO0FBQUEsSUFDdEosU0FBT3dFLE9BQU07QUFBQ25DLGFBQU9vQyxPQUFPRCxLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQ3ZDLENBQUM7QUFDRCxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHFCQUFvQixVQUFTLHNIQUFxSCxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsMkJBQTBCLFNBQVEsYUFBWSxTQUFTLE1BQUk7QUFBQ3BELGtCQUFZLElBQUk7QUFBRWEsV0FBS1ksTUFBTTdDLEtBQUs7QUFBRWtCLGNBQVEsSUFBSTtBQUFBLElBQUUsR0FBRyw4QkFBNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSixLQUF2VTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlWO0FBQUEsSUFDeFZLLFdBQVMsdUJBQUMsU0FBTSxVQUFTLFdBQVUsTUFBSyxVQUFVQSxxQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLElBQzNELHVCQUFDLFNBQU07QUFBQSw2QkFBQyxXQUFRLFdBQVUsZ0JBQWUsYUFBWSxnQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLE1BQUUsdUJBQUMsY0FBVyxPQUFPUixNQUFNLGdCQUFlLFdBQVdBLGVBQUt5QixRQUFNLG1DQUM3STtBQUFBLCtCQUFDLGFBQVUsT0FBTSw4QkFBNkIsTUFBTXpCLEtBQUt5QixLQUFLQSxNQUFNLFFBQVEsQ0FBQXRDLFlBQVNBLFFBQVEwQixJQUFJLFNBQVM7QUFBQSxVQUN0RyxFQUFDbUMsS0FBSSxRQUFPVyxPQUFNLGdCQUFlQyxRQUFPQSxDQUFBQyxNQUFHQSxFQUFFdEYsS0FBSTtBQUFBLFVBQUUsRUFBQ3lFLEtBQUksUUFBT1csT0FBTSxpQkFBZ0JDLFFBQU9BLENBQUFDLE1BQUdBLEVBQUVuRixLQUFJO0FBQUEsVUFBRSxFQUFDc0UsS0FBSSxTQUFRVyxPQUFNLFFBQU9DLFFBQU9BLENBQUFDLE1BQUd2RSxpQkFBaUJ1RSxFQUFFOUUsS0FBSyxFQUFDO0FBQUEsVUFBRSxFQUFDaUUsS0FBSSxRQUFPVyxPQUFNLFlBQVdDLFFBQU9BLENBQUFDLE1BQUdBLEVBQUV0QixPQUFLLGVBQWEsZUFBYztBQUFBLFVBQUUsRUFBQ1MsS0FBSSxVQUFTVyxPQUFNLGNBQWFDLFFBQU9BLENBQUFDLE1BQUcsdUJBQUMsVUFBTyxPQUFPQSxFQUFFQyxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QixFQUFFO0FBQUEsVUFDdFQsRUFBQ2QsS0FBSSxRQUFPVyxPQUFNLFlBQVdDLFFBQU9BLENBQUFDLE1BQUdBLEVBQUVDLFdBQVMsV0FBUyx1QkFBQyxlQUFZO0FBQUEsbUNBQUMsa0JBQWUsWUFBVywyQkFBMEIsU0FBUyxNQUFJO0FBQUN6RCwwQkFBWXdELENBQUM7QUFBRTNDLG1CQUFLWSxNQUFNNUMsU0FBUzJFLENBQUMsRUFBRXhFLE1BQU07QUFBRWMsc0JBQVEsSUFBSTtBQUFBLFlBQUUsR0FBRztBQUFBO0FBQUEsY0FBZTBELEVBQUV0RjtBQUFBQSxpQkFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0o7QUFBQSxZQUFpQix1QkFBQyxrQkFBZSxZQUFXLDJCQUEwQixTQUFTLE1BQUlnQyxXQUFXc0QsQ0FBQyxHQUFHO0FBQUE7QUFBQSxjQUFZQSxFQUFFdEY7QUFBQUEsaUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9HO0FBQUEsZUFBMVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMlMsSUFBZSxtQkFBa0I7QUFBQSxRQUFDLEtBRjVZO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHRTtBQUFBLFFBQUUsdUJBQUMsU0FBTSxNQUFNeUIsS0FBS3lCLEtBQUtzQyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FKNkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUkzRyxLQUo2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSXpDO0FBQUEsU0FKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUl1RDtBQUFBLElBQ3ZELHVCQUFDLGNBQVcsTUFBWSxPQUFPM0QsV0FBUyxpQkFBaUJBLFNBQVM3QixJQUFJLEtBQUcsa0JBQWtCLE1BQVksU0FBUyxNQUFJNEIsUUFBUSxLQUFLLEdBQUcsU0FBUyx1QkFBQyxVQUFPLE1BQUssVUFBUyxNQUFLLGtCQUFpQixTQUFRLGFBQVksVUFBVWtDLFFBQU1HLFdBQVMsQ0FBQ3pDLFdBQVVlLFFBQVFWLFFBQVEsS0FBRyxDQUFDa0IsT0FBT1ksT0FBUSw2QkFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvSixHQUM3UjtBQUFBLDZCQUFDLGVBQVksT0FBT25CLE9BQU8wQyxTQUFPekMsT0FBT3lDLFNBQU8vQyxPQUFPK0MsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQUUsdUJBQUMsaUJBQWMsUUFBZ0IsUUFBUSxFQUFDbEYsTUFBSyxnQkFBZUcsTUFBSyxpQkFBZ0JLLE9BQU0saUJBQWdCLEdBQUcsUUFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxSDtBQUFBLE1BQ25Md0QsUUFBTSx1QkFBQyxTQUFNLFVBQVMsUUFBTyxrRkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RjtBQUFBLE1BQ2hHLHVCQUFDLGNBQVcsV0FBVSxRQUFPLElBQUcsa0JBQWlCLFlBQVUsTUFBQyxLQUFLLENBQUF5QixTQUFNO0FBQUM1QixnQkFBUW9CLFVBQVFRO0FBQUs3QixrQkFBVTZCLElBQUk7QUFBQSxNQUFFLEdBQUcsVUFBVXRCLFFBQVEsb0JBQWtCLENBQUNSLFFBQU0sU0FBT1IsUUFDOUo7QUFBQSwrQkFBQyxhQUFVLE9BQU0sZ0JBQWUsR0FBSVIsS0FBSytDLFNBQVMsTUFBTSxHQUFHLFVBQVU1QixRQUFNLENBQUN0QyxXQUFTd0MsTUFBTSxPQUFPekIsUUFBUUksS0FBS2dELFVBQVVDLE9BQU81RixJQUFJLEdBQUcsWUFBWTJDLEtBQUtnRCxVQUFVQyxPQUFPNUYsTUFBTTZGLFdBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUw7QUFBQSxRQUN2TCx1QkFBQyxhQUFVLE9BQU0saUJBQWdCLEdBQUlsRCxLQUFLK0MsU0FBUyxNQUFNLEdBQUcsVUFBVTVCLFFBQU0sQ0FBQ3RDLFNBQVMsT0FBT2UsUUFBUUksS0FBS2dELFVBQVVDLE9BQU96RixJQUFJLEdBQUcsWUFBWXdDLEtBQUtnRCxVQUFVQyxPQUFPekYsTUFBTTBGLFdBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0w7QUFBQSxRQUNsTCx1QkFBQyxhQUFVLFFBQU0sTUFBQyxPQUFNLGtCQUFpQixHQUFJbEQsS0FBSytDLFNBQVMsT0FBTyxHQUFHLE9BQU8vQyxLQUFLbUQsTUFBTSxPQUFPLEdBQUcsVUFBVWhDLFFBQU0sQ0FBQ3RDLFdBQVN3QyxNQUFPVSxpQkFBT3FCLFFBQVFoRixnQkFBZ0IsRUFBRWlGLElBQUksQ0FBQyxDQUFDQyxPQUFNYixLQUFLLE1BQUksdUJBQUMsWUFBcUIsT0FBZUEsbUJBQXRCYSxPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkMsQ0FBVyxLQUE5TztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdQO0FBQUEsV0FIcFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLE1BQU0xRCxRQUFRUixPQUFPLEdBQUcsT0FBTSx3QkFBdUIsY0FBYSx3QkFBdUIsYUFBYSxhQUFhQSxTQUFTL0IsUUFBTSxFQUFFLE1BQU0rQixTQUFTNUIsUUFBTSxFQUFFLHdHQUF3RyxlQUFhLE1BQUMsTUFBTXVDLE9BQU9xQixTQUFTLE9BQU9yQixPQUFPd0MsT0FBTyxTQUFTLE1BQUlsRCxXQUFXLElBQUksR0FBRyxXQUFXLE9BQU1rRSxXQUFRO0FBQUMsVUFBRyxDQUFDbkUsUUFBUTtBQUFPLFlBQU1XLE9BQU9vQyxRQUFRLEVBQUMxQyxNQUFLLEVBQUNDLFdBQVVOLFFBQVFPLEdBQUUsR0FBRXlDLE1BQUssRUFBQ29CLGlCQUFnQnBFLFFBQVFsQixTQUFRcUYsT0FBTSxFQUFDLENBQUM7QUFBRWhFLGlCQUFXLDJCQUEyQkgsUUFBUS9CLElBQUksR0FBRztBQUFBLElBQUUsS0FBaGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa2pCO0FBQUEsT0FqQi9pQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JQO0FBQ0o7QUFBQ3NCLEdBckNlRCxjQUFZO0FBQUEsVUFDWDdDLFVBQW1CQyxRQUE2Q0gsUUFBNkJJLGNBRTdGSixRQUNBQyxZQUFvREEsWUFBaUVBLFlBQ3ZITCxTQUFvRUMsVUFDbEVRLG1CQUMyRUUsWUFBWTtBQUFBO0FBQUEsS0FQeEZ3QztBQUFZLElBQUErRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIkFsZXJ0IiwiQnV0dG9uIiwiTWVudUl0ZW0iLCJUZXh0RmllbGQiLCJ1c2VGb3JtIiwidXNlV2F0Y2giLCJ6b2RSZXNvbHZlciIsInoiLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwidXNlU2NvcGUiLCJ1c2VDYW4iLCJ1c2VMaXN0UXVlcnkiLCJ1c2VWZXJzaW9uZWREcmFmdCIsImRyYWZ0RXF1YWwiLCJ1c2VEcmFmdEZvcm0iLCJtYXJrRHJhZnRDbGVhbiIsImNvZGVQb2ludExlbmd0aCIsIkRyYWZ0Q29uZmxpY3QiLCJGb3JtRmllbGRzIiwiQWN0aW9uR3JvdXAiLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJUb29sYmFyIiwiUXVlcnlTdGF0ZSIsIkRhdGFUYWJsZSIsIlBhZ2VyIiwiU3RhdHVzIiwiTXV0YXRpb25CdXR0b24iLCJFZGl0RGlhbG9nIiwiQ29uZmlybURpYWxvZyIsIkVycm9yTm90aWNlIiwic2NoZW1hIiwib2JqZWN0IiwiY29kZSIsInN0cmluZyIsInJlZ2V4IiwibmFtZSIsInJlZmluZSIsInYiLCJ0cmltIiwibWluIiwiZ3JvdXAiLCJlbnVtIiwiZW1wdHkiLCJzbmFwc2hvdCIsImFjY291bnQiLCJ2ZXJzaW9uIiwidmFsdWVzIiwiYWNjb3VudEdyb3VwTmFtZSIsImFzc2V0IiwibGlhYmlsaXR5IiwiZXF1aXR5IiwiaW5jb21lIiwiZXhwZW5zZSIsIkFjY291bnRzUGFnZSIsIl9zIiwic2hvcCIsImNhbkVkaXQiLCJsaXN0IiwicXVlcnkiLCJvcGVuIiwic2V0T3BlbiIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJhcmNoaXZlIiwic2V0QXJjaGl2ZSIsInN1Y2Nlc3MiLCJzZXRTdWNjZXNzIiwiZGV0YWlsIiwicGF0aCIsImFjY291bnRJZCIsImlkIiwiQm9vbGVhbiIsImNyZWF0ZSIsInVwZGF0ZSIsInJlbW92ZSIsImZvcm0iLCJkZWZhdWx0VmFsdWVzIiwicmVzb2x2ZXIiLCJjb250cm9sIiwiZWRpdG9yIiwiaWRlbnRpdHkiLCJzb3VyY2UiLCJkYXRhIiwidW5kZWZpbmVkIiwiZHJhZnQiLCJnZXRWYWx1ZXMiLCJhcHBseSIsInJlc2V0IiwicmVmcmVzaCIsInJlZmV0Y2giLCJ0aHJvd09uRXJyb3IiLCJkaXJ0eSIsImJpbmREcmFmdCIsImZvcm1SZWYiLCJidXN5IiwicGVuZGluZyIsInVzZWQiLCJibG9ja2VkIiwidW5yZXNvbHZlZCIsInN1Ym1pdCIsImhhbmRsZVN1Ym1pdCIsInByZXBhcmVkIiwicHJlcGFyZSIsInN1Ym1pdHRlZCIsInBhdGNoIiwia2V5IiwiT2JqZWN0Iiwia2V5cyIsImFzc2lnbiIsInJlc3BvbnNlIiwiZXhlY3V0ZSIsImJvZHkiLCJjb21taXR0ZWQiLCJjdXJyZW50IiwiZXJyb3IiLCJmYWlsZWQiLCJsYWJlbCIsInJlbmRlciIsImEiLCJzdGF0dXMiLCJwYWdlIiwibm9kZSIsInJlZ2lzdGVyIiwiZm9ybVN0YXRlIiwiZXJyb3JzIiwibWVzc2FnZSIsIndhdGNoIiwiZW50cmllcyIsIm1hcCIsInZhbHVlIiwicmVhc29uIiwiZXhwZWN0ZWRWZXJzaW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYWNjb3VudHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBbGVydCwgQnV0dG9uLCBNZW51SXRlbSwgVGV4dEZpZWxkIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XG5pbXBvcnQgeyB1c2VGb3JtLCB1c2VXYXRjaCB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSc7XG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJztcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xuaW1wb3J0IHR5cGUgeyBBY2NvdW50IH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XG5pbXBvcnQgeyB1c2VBcGksIHVzZUNvbW1hbmQgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlU2NvcGUsIHVzZUNhbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3Njb3BlJztcbmltcG9ydCB7IHVzZUxpc3RRdWVyeSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2ZpbHRlcnMnO1xuaW1wb3J0IHsgdXNlVmVyc2lvbmVkRHJhZnQsIGRyYWZ0RXF1YWwgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC92ZXJzaW9uZWQtZHJhZnQnO1xuaW1wb3J0IHsgdXNlRHJhZnRGb3JtLCBtYXJrRHJhZnRDbGVhbiB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2RpcnR5LWRyYWZ0cyc7XG5pbXBvcnQgeyBjb2RlUG9pbnRMZW5ndGggfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xuaW1wb3J0IHsgRHJhZnRDb25mbGljdCB9IGZyb20gJ0Avc2hhcmVkL3VpL2RyYWZ0LWNvbmZsaWN0JztcbmltcG9ydCB7IEZvcm1GaWVsZHMsIEFjdGlvbkdyb3VwIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgUGFnZUhlYWRlciwgUGFuZWwsIFRvb2xiYXIsIFF1ZXJ5U3RhdGUsIERhdGFUYWJsZSwgUGFnZXIsIFN0YXR1cywgTXV0YXRpb25CdXR0b24sIEVkaXREaWFsb2csIENvbmZpcm1EaWFsb2csIEVycm9yTm90aWNlIH0gZnJvbSAnQC9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG5cbmNvbnN0IHNjaGVtYT16Lm9iamVjdCh7Y29kZTp6LnN0cmluZygpLnJlZ2V4KC9eW0EtWmEtejAtOV8uLV17MSw0MH0kLywnTcOjIGfhu5NtIDHigJM0MCBjaOG7ry9z4buRLCBk4bqldSBjaOG6pW0sIGfhuqFjaCBuZ2FuZyBob+G6t2MgZ+G6oWNoIGTGsOG7m2kuJyksbmFtZTp6LnN0cmluZygpLnJlZmluZSh2PT5jb2RlUG9pbnRMZW5ndGgodik8PTE2MCwnVMOqbiB04buRaSDEkWEgMTYwIGvDvSB04buxLicpLnRyaW0oKS5taW4oMSwnTmjhuq1wIHTDqm4gdMOgaSBraG/huqNuLicpLGdyb3VwOnouZW51bShbJ2Fzc2V0JywnbGlhYmlsaXR5JywnZXF1aXR5JywnaW5jb21lJywnZXhwZW5zZSddKX0pO1xudHlwZSBGaWVsZHM9ei5pbmZlcjx0eXBlb2Ygc2NoZW1hPjtcbmNvbnN0IGVtcHR5OkZpZWxkcz17Y29kZTonJyxuYW1lOicnLGdyb3VwOidhc3NldCd9O1xuY29uc3Qgc25hcHNob3Q9KGFjY291bnQ6QWNjb3VudCk9Pih7dmVyc2lvbjphY2NvdW50LnZlcnNpb24sdmFsdWVzOntjb2RlOmFjY291bnQuY29kZSxuYW1lOmFjY291bnQubmFtZSxncm91cDphY2NvdW50Lmdyb3VwfX0pO1xuZXhwb3J0IGNvbnN0IGFjY291bnRHcm91cE5hbWU6UmVjb3JkPEFjY291bnRbJ2dyb3VwJ10sc3RyaW5nPj17YXNzZXQ6J1TDoGkgc+G6o24nLGxpYWJpbGl0eTonTuG7oyBwaOG6o2kgdHLhuqMnLGVxdWl0eTonVuG7kW4gY2jhu6cgc+G7nyBo4buvdScsaW5jb21lOidUaHUgbmjhuq1wJyxleHBlbnNlOidDaGkgcGjDrSd9O1xuXG5leHBvcnQgZnVuY3Rpb24gQWNjb3VudHNQYWdlKCkge1xuICAgIGNvbnN0IHtzaG9wfT11c2VTY29wZSgpLGNhbkVkaXQ9dXNlQ2FuKFwiZmluYW5jZS5hY2NvdW50cy5tYW5hZ2VcIik7Y29uc3QgbGlzdD11c2VBcGkoJ2xpc3RBY2NvdW50cycse3F1ZXJ5OnVzZUxpc3RRdWVyeSgnbGlzdEFjY291bnRzJyl9KTtcbiAgICBjb25zdCBbb3BlbixzZXRPcGVuXT11c2VTdGF0ZShmYWxzZSksW3NlbGVjdGVkLHNldFNlbGVjdGVkXT11c2VTdGF0ZTxBY2NvdW50fG51bGw+KG51bGwpLFthcmNoaXZlLHNldEFyY2hpdmVdPXVzZVN0YXRlPEFjY291bnR8bnVsbD4obnVsbCksW3N1Y2Nlc3Msc2V0U3VjY2Vzc109dXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGRldGFpbD11c2VBcGkoJ2dldEFjY291bnQnLHtwYXRoOnthY2NvdW50SWQ6c2VsZWN0ZWQ/LmlkfHwnJ319LG9wZW4mJkJvb2xlYW4oc2VsZWN0ZWQpKTtcbiAgICBjb25zdCBjcmVhdGU9dXNlQ29tbWFuZCgnY3JlYXRlQWNjb3VudCcsWydsaXN0QWNjb3VudHMnXSksdXBkYXRlPXVzZUNvbW1hbmQoJ3VwZGF0ZUFjY291bnQnLFsnbGlzdEFjY291bnRzJywnZ2V0QWNjb3VudCddKSxyZW1vdmU9dXNlQ29tbWFuZCgnYXJjaGl2ZUFjY291bnQnLFsnbGlzdEFjY291bnRzJywnZ2V0QWNjb3VudCddKTtcbiAgICBjb25zdCBmb3JtPXVzZUZvcm08RmllbGRzPih7ZGVmYXVsdFZhbHVlczplbXB0eSxyZXNvbHZlcjp6b2RSZXNvbHZlcihzY2hlbWEpfSk7dXNlV2F0Y2goe2NvbnRyb2w6Zm9ybS5jb250cm9sfSk7XG4gICAgY29uc3QgZWRpdG9yPXVzZVZlcnNpb25lZERyYWZ0KHtpZGVudGl0eTpgJHtzaG9wLmlkfTphY2NvdW50OiR7c2VsZWN0ZWQ/LmlkfHwnbmV3J31gLHNvdXJjZTpkZXRhaWwuZGF0YT9zbmFwc2hvdChkZXRhaWwuZGF0YS5kYXRhKTpzZWxlY3RlZD9zbmFwc2hvdChzZWxlY3RlZCk6dW5kZWZpbmVkLGRyYWZ0OmZvcm0uZ2V0VmFsdWVzKCksYXBwbHk6dmFsdWVzPT5mb3JtLnJlc2V0KHZhbHVlcykscmVmcmVzaDooKT0+ZGV0YWlsLnJlZmV0Y2goe3Rocm93T25FcnJvcjp0cnVlfSl9KTtcbiAgICBjb25zdCBkaXJ0eT1vcGVuJiYoc2VsZWN0ZWQ/ZWRpdG9yLmRpcnR5OiFkcmFmdEVxdWFsKGVtcHR5LGZvcm0uZ2V0VmFsdWVzKCkpKSxiaW5kRHJhZnQ9dXNlRHJhZnRGb3JtKGRpcnR5KSxmb3JtUmVmPXVzZVJlZjxIVE1MRm9ybUVsZW1lbnR8bnVsbD4obnVsbCksYnVzeT1jcmVhdGUucGVuZGluZ3x8dXBkYXRlLnBlbmRpbmc7XG4gICAgY29uc3QgdXNlZD1kZXRhaWwuZGF0YT8uZGF0YS51c2VkPz9zZWxlY3RlZD8udXNlZD8/ZmFsc2U7XG4gICAgY29uc3QgYmxvY2tlZD1Cb29sZWFuKHNlbGVjdGVkP3VwZGF0ZS51bnJlc29sdmVkOmNyZWF0ZS51bnJlc29sdmVkKTtcbiAgICBjb25zdCBzdWJtaXQ9Zm9ybS5oYW5kbGVTdWJtaXQoYXN5bmMgdmFsdWVzPT57XG4gICAgICAgIGlmKCFjYW5FZGl0fHxibG9ja2VkKXJldHVybjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmKHNlbGVjdGVkKXtjb25zdCBwcmVwYXJlZD1lZGl0b3IucHJlcGFyZSgpO2lmKCFwcmVwYXJlZClyZXR1cm47Y29uc3Qgc3VibWl0dGVkPWZvcm0uZ2V0VmFsdWVzKCkscGF0Y2g9ey4uLnByZXBhcmVkLnBhdGNofTtmb3IoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHBhdGNoKSBhcyAoa2V5b2YgRmllbGRzKVtdKSBPYmplY3QuYXNzaWduKHBhdGNoLHtba2V5XTp2YWx1ZXNba2V5XX0pO2NvbnN0IHJlc3BvbnNlPWF3YWl0IHVwZGF0ZS5leGVjdXRlKHtwYXRoOnthY2NvdW50SWQ6c2VsZWN0ZWQuaWR9LHZlcnNpb246cHJlcGFyZWQudmVyc2lvbixib2R5OnBhdGNofSk7aWYoIWVkaXRvci5jb21taXR0ZWQoc25hcHNob3QocmVzcG9uc2UuZGF0YSksc3VibWl0dGVkKSlyZXR1cm47fVxuICAgICAgICAgICAgZWxzZSBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7Ym9keTp2YWx1ZXN9KTtcbiAgICAgICAgICAgIGlmKGZvcm1SZWYuY3VycmVudCltYXJrRHJhZnRDbGVhbihmb3JtUmVmLmN1cnJlbnQpO3NldFN1Y2Nlc3MoYMSQw6MgbMawdSB0w6BpIGtob+G6o24gJHt2YWx1ZXMuY29kZX0gwrcgJHt2YWx1ZXMubmFtZX0uYCk7c2V0T3BlbihmYWxzZSk7Zm9ybS5yZXNldChlbXB0eSk7XG4gICAgICAgIH1jYXRjaChlcnJvcil7ZWRpdG9yLmZhaWxlZChlcnJvcik7fVxuICAgIH0pO1xuICAgIHJldHVybiA8PlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIlTDoGkga2hv4bqjbiBr4bq/IHRvw6FuXCIgc3VidGl0bGU9XCJEYW5oIG3hu6VjIGvhur8gdG/DoW4gcXXhuqNuIHRy4buLOyBtw6MgdsOgIG5ow7NtIMSRw6MgZMO5bmcgdHJvbmcgY2jhu6luZyB04burIMSRxrDhu6NjIGLhuqNvIHbhu4csIGtow7RuZyBwaOG6o2kgaOG7hyB0aOG7kW5nIHTDoGkga2hv4bqjbiBwaMOhcCDEkeG7i25oLlwiIGFjdGlvbnM9ezxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiZmluYW5jZS5hY2NvdW50cy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17KCk9PntzZXRTZWxlY3RlZChudWxsKTtmb3JtLnJlc2V0KGVtcHR5KTtzZXRPcGVuKHRydWUpO319PlRow6ptIHTDoGkga2hv4bqjbjwvTXV0YXRpb25CdXR0b24+fS8+XG4gICAgICAgIHtzdWNjZXNzJiY8QWxlcnQgc2V2ZXJpdHk9XCJzdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPntzdWNjZXNzfTwvQWxlcnQ+fVxuICAgICAgICA8UGFuZWw+PFRvb2xiYXIgb3BlcmF0aW9uPVwibGlzdEFjY291bnRzXCIgcGxhY2Vob2xkZXI9XCJUw6xtIG3DoyBob+G6t2MgdMOqbiB0w6BpIGtob+G6o27igKZcIi8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEmJjw+XG4gICAgICAgICAgICA8RGF0YVRhYmxlIGxhYmVsPVwiRGFuaCBt4bulYyB0w6BpIGtob+G6o24ga+G6vyB0b8OhblwiIHJvd3M9e2xpc3QuZGF0YS5kYXRhfSByb3dLZXk9e2FjY291bnQ9PmFjY291bnQuaWR9IGNvbHVtbnM9e1tcbiAgICAgICAgICAgICAgICB7a2V5Oidjb2RlJyxsYWJlbDonTcOjIHTDoGkga2hv4bqjbicscmVuZGVyOmE9PmEuY29kZX0se2tleTonbmFtZScsbGFiZWw6J1TDqm4gdMOgaSBraG/huqNuJyxyZW5kZXI6YT0+YS5uYW1lfSx7a2V5Oidncm91cCcsbGFiZWw6J05ow7NtJyxyZW5kZXI6YT0+YWNjb3VudEdyb3VwTmFtZVthLmdyb3VwXX0se2tleTondXNlZCcsbGFiZWw6J0No4bupbmcgdOG7qycscmVuZGVyOmE9PmEudXNlZD8nxJDDoyBz4butIGThu6VuZyc6J0NoxrBhIHPhu60gZOG7pW5nJ30se2tleTonc3RhdHVzJyxsYWJlbDonVHLhuqFuZyB0aMOhaScscmVuZGVyOmE9PjxTdGF0dXMgdmFsdWU9e2Euc3RhdHVzfS8+fSxcbiAgICAgICAgICAgICAgICB7a2V5OidlZGl0JyxsYWJlbDonVGhhbyB0w6FjJyxyZW5kZXI6YT0+YS5zdGF0dXM9PT0nYWN0aXZlJz88QWN0aW9uR3JvdXA+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJmaW5hbmNlLmFjY291bnRzLm1hbmFnZVwiIG9uQ2xpY2s9eygpPT57c2V0U2VsZWN0ZWQoYSk7Zm9ybS5yZXNldChzbmFwc2hvdChhKS52YWx1ZXMpO3NldE9wZW4odHJ1ZSk7fX0+U+G7rWEgdMOgaSBraG/huqNuIHthLmNvZGV9PC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImZpbmFuY2UuYWNjb3VudHMubWFuYWdlXCIgb25DbGljaz17KCk9PnNldEFyY2hpdmUoYSl9Pk5n4burbmcgZMO5bmcge2EuY29kZX08L011dGF0aW9uQnV0dG9uPjwvQWN0aW9uR3JvdXA+OidM4buLY2ggc+G7rSDEkcaw4bujYyBnaeG7ryd9LFxuICAgICAgICAgICAgXX0vPjxQYWdlciBwYWdlPXtsaXN0LmRhdGEucGFnZX0vPjwvPn08L1F1ZXJ5U3RhdGU+PC9QYW5lbD5cbiAgICAgICAgPEVkaXREaWFsb2cgb3Blbj17b3Blbn0gdGl0bGU9e3NlbGVjdGVkP2BT4butYSB0w6BpIGtob+G6o24gJHtzZWxlY3RlZC5jb2RlfWA6J1Row6ptIHTDoGkga2hv4bqjbid9IGJ1c3k9e2J1c3l9IG9uQ2xvc2U9eygpPT5zZXRPcGVuKGZhbHNlKX0gYWN0aW9ucz17PEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZm9ybT1cImFjY291bnQtZWRpdG9yXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXtidXN5fHxibG9ja2VkfHwhY2FuRWRpdHx8KEJvb2xlYW4oc2VsZWN0ZWQpJiYhZWRpdG9yLmRpcnR5KX0+TMawdSB0w6BpIGtob+G6o248L0J1dHRvbj59PlxuICAgICAgICAgICAgPEVycm9yTm90aWNlIGVycm9yPXtjcmVhdGUuZXJyb3J8fHVwZGF0ZS5lcnJvcnx8ZGV0YWlsLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17e2NvZGU6J03DoyB0w6BpIGtob+G6o24nLG5hbWU6J1TDqm4gdMOgaSBraG/huqNuJyxncm91cDonTmjDs20gdMOgaSBraG/huqNuJ319IGJ1c3k9e2J1c3l9Lz5cbiAgICAgICAgICAgIHt1c2VkJiY8QWxlcnQgc2V2ZXJpdHk9XCJpbmZvXCI+VMOgaSBraG/huqNuIMSRw6MgY8OzIGNo4bupbmcgdOG7qzsgY2jhu4kgc+G7rWEgdMOqbiwgbcOjIHbDoCBuaMOzbSDEkcaw4bujYyBnaeG7ryBuZ3V5w6puLjwvQWxlcnQ+fVxuICAgICAgICAgICAgPEZvcm1GaWVsZHMgY29tcG9uZW50PVwiZm9ybVwiIGlkPVwiYWNjb3VudC1lZGl0b3JcIiBub1ZhbGlkYXRlIHJlZj17bm9kZT0+e2Zvcm1SZWYuY3VycmVudD1ub2RlO2JpbmREcmFmdChub2RlKTt9fSBvblN1Ym1pdD17c3VibWl0fSBkYXRhLWRyYWZ0LWNsZWFuPXshZGlydHk/J3RydWUnOnVuZGVmaW5lZH0+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIk3DoyB0w6BpIGtob+G6o25cIiB7Li4uZm9ybS5yZWdpc3RlcignY29kZScpfSBkaXNhYmxlZD17YnVzeXx8IWNhbkVkaXR8fHVzZWR9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5jb2RlKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLmNvZGU/Lm1lc3NhZ2V9Lz5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIGxhYmVsPVwiVMOqbiB0w6BpIGtob+G6o25cIiB7Li4uZm9ybS5yZWdpc3RlcignbmFtZScpfSBkaXNhYmxlZD17YnVzeXx8IWNhbkVkaXR9IGVycm9yPXtCb29sZWFuKGZvcm0uZm9ybVN0YXRlLmVycm9ycy5uYW1lKX0gaGVscGVyVGV4dD17Zm9ybS5mb3JtU3RhdGUuZXJyb3JzLm5hbWU/Lm1lc3NhZ2V9Lz5cbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIk5ow7NtIHTDoGkga2hv4bqjblwiIHsuLi5mb3JtLnJlZ2lzdGVyKCdncm91cCcpfSB2YWx1ZT17Zm9ybS53YXRjaCgnZ3JvdXAnKX0gZGlzYWJsZWQ9e2J1c3l8fCFjYW5FZGl0fHx1c2VkfT57T2JqZWN0LmVudHJpZXMoYWNjb3VudEdyb3VwTmFtZSkubWFwKChbdmFsdWUsbGFiZWxdKT0+PE1lbnVJdGVtIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+e2xhYmVsfTwvTWVudUl0ZW0+KX08L1RleHRGaWVsZD5cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkcz5cbiAgICAgICAgPC9FZGl0RGlhbG9nPlxuICAgICAgICA8Q29uZmlybURpYWxvZyBvcGVuPXtCb29sZWFuKGFyY2hpdmUpfSB0aXRsZT1cIk5n4burbmcgZMO5bmcgdMOgaSBraG/huqNuXCIgY29uZmlybUxhYmVsPVwiTmfhu6tuZyBkw7luZyB0w6BpIGtob+G6o25cIiBkZXNjcmlwdGlvbj17YFTDoGkga2hv4bqjbiAke2FyY2hpdmU/LmNvZGV8fCcnfSDCtyAke2FyY2hpdmU/Lm5hbWV8fCcnfSBz4bq9IGtow7RuZyBkw7luZyBjaG8gY2jhu6luZyB04burIG3hu5tpLiBBUEkgY2jhurduIGtoaSBjw7JuIGLDunQgdG/DoW4gbmjDoXA7IGNo4bupbmcgdOG7qyB2w6Agc+G7kSBkxrAgbOG7i2NoIHPhu60gxJHGsOG7o2MgZ2nhu68uYH0gcmVxdWlyZVJlYXNvbiBidXN5PXtyZW1vdmUucGVuZGluZ30gZXJyb3I9e3JlbW92ZS5lcnJvcn0gb25DbG9zZT17KCk9PnNldEFyY2hpdmUobnVsbCl9IG9uQ29uZmlybT17YXN5bmMgcmVhc29uPT57aWYoIWFyY2hpdmUpcmV0dXJuO2F3YWl0IHJlbW92ZS5leGVjdXRlKHtwYXRoOnthY2NvdW50SWQ6YXJjaGl2ZS5pZH0sYm9keTp7ZXhwZWN0ZWRWZXJzaW9uOmFyY2hpdmUudmVyc2lvbixyZWFzb259fSk7c2V0U3VjY2VzcyhgxJDDoyBuZ+G7q25nIGTDuW5nIHTDoGkga2hv4bqjbiAke2FyY2hpdmUuY29kZX0uYCk7fX0vPlxuICAgIDwvPjtcbn1cbiJdLCJmaWxlIjoiQzovVXNlcnMvSm9rZXItUEMvRG9jdW1lbnRzL1Byb2plY3RzL0JvdC1BSS1CYW4taGFuZy1GQi9Cb3RTYWxlc0FJX0Zyb250ZW5kL2FwcHMvd2ViL3NyYy9tb2R1bGVzL2ZpbmFuY2UvYWNjb3VudHMudHN4In0=