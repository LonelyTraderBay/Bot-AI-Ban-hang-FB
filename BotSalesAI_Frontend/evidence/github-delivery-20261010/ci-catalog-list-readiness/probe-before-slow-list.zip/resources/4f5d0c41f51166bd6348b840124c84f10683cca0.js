import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/catalog/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react_jsx-dev-runtime.js?v=11faa885"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { useListReturn } from "/src/shared/model/list-return.ts";
import { codePointLength } from "/src/shared/model/format.ts";
import { ActionGroup, FieldGroup, FormFields } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport6_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react.js?v=11faa885"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useRef = __vite__cjsImport6_react["useRef"]; const useState = __vite__cjsImport6_react["useState"];
import { visualSx } from "/src/shared/ui/visual.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { useNavigate, useParams, useSearchParams, Link as RouterLink } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react-router-dom.js?v=85ce2841";
import { useForm, useFieldArray, Controller, useWatch } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react-hook-form.js?v=0b7a1dec";
import { zodResolver } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/@hookform_resolvers_zod.js?v=80a34b47";
import { z } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/zod.js?v=4d82ca26";
import { Alert, Box, Button, Checkbox, FormControlLabel, IconButton, MenuItem, Stack, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/@mui_material.js?v=8caac895";
import AddRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/@mui_icons-material_AddRounded.js?v=de13be4f";
import DeleteOutlineRounded from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/@mui_icons-material_DeleteOutlineRounded.js?v=31dc972f";
import { useApi, useCommand, usePagedApi } from "/src/shared/api/hooks.ts";
import { useScope, useCan } from "/src/shared/model/scope.tsx";
import { useListQuery } from "/src/shared/model/filters.ts";
import { PRODUCT_IMAGE_MAX_BYTES, productImageFileError } from "/src/modules/catalog/import-file.ts";
import { ApiError } from "/src/shared/api/errors.ts";
import { draftEqual, useVersionedDraft } from "/src/shared/model/versioned-draft.ts";
import { markDraftClean, useDraftForm } from "/src/shared/model/dirty-drafts.ts";
import { DraftConflict } from "/src/shared/ui/draft-conflict.tsx";
import { PageHeader, Panel, DataTable, Status, Amount, QueryState, Toolbar, Pager, MutationButton, EditDialog, ErrorNotice, ConfirmDialog, RouteLink, LookupLoadMore } from "/src/shared/ui/components.tsx";
const productSchema = z.object({
  name: z.string().trim().min(1, "Nhập tên sản phẩm").refine((value) => codePointLength(value) <= 160, "Tên sản phẩm tối đa 160 ký tự."),
  description: z.string().refine((value) => codePointLength(value) <= 2e4, "Mô tả tối đa 20.000 ký tự."),
  categoryId: z.string(),
  status: z.enum(["draft", "active"]),
  variants: z.array(z.object({
    id: z.string().optional(),
    options: z.record(z.string(), z.string()).optional(),
    sku: z.string().trim().min(1, "Nhập SKU").refine((value) => codePointLength(value) <= 80, "SKU tối đa 80 ký tự."),
    name: z.string().min(1, "Nhập tên biến thể"),
    price: z.string().trim().min(1, "Nhập giá bán").regex(/^\d+(\.\d{1,4})?$/, "Giá không hợp lệ").refine((value) => Number(value) > 0, "Giá phải lớn hơn 0"),
    active: z.boolean()
  })).min(1, "Cần ít nhất một biến thể")
});
const defaults = { name: "", description: "", categoryId: "", status: "draft", variants: [{ sku: "", name: "Mặc định", price: "", active: true }] };
export function ProductsPage() {
  _s();
  const { shop } = useScope();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [categorySearchInput, setCategorySearchInput] = useState(""), [categorySearch, setCategorySearch] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setCategorySearch(categorySearchInput.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [categorySearchInput]);
  const categories = usePagedApi("listCategories", { query: { q: categorySearch || void 0 } });
  const selectedCategoryDetail = useApi("getCategory", { path: { categoryId: params.get("categoryId") || "" } }, !!params.get("categoryId"));
  const selectedCategory = categories.data?.data.find((category) => category.id === params.get("categoryId")) || selectedCategoryDetail.data?.data;
  const list = useApi("listProducts", { query: { ...useListQuery("listProducts"), categoryId: params.get("categoryId") || void 0 } });
  const setFilter = (key, value) => {
    const next = new URLSearchParams(params);
    if (value)
      next.set(key, value);
    else
      next.delete(key);
    next.delete("cursor");
    setParams(next);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Sản phẩm", subtitle: "Một nguồn thông tin cho tư vấn, giá bán và các biến thể.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", onClick: () => navigate(`/s/${shop.id}/products/new`), variant: "contained", children: "Thêm sản phẩm" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 72,
      columnNumber: 118
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 72,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(
        Toolbar,
        {
          operation: "listProducts",
          placeholder: "Tìm tên hoặc SKU…",
          extra: /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Trạng thái", value: params.get("status") || "", onChange: (event) => setFilter("status", event.target.value), sx: { minWidth: 150 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả trạng thái" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 75,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "draft", children: "Bản nháp" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 75,
              columnNumber: 64
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "active", children: "Đang bán" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 75,
              columnNumber: 107
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "archived", children: "Đã ngừng bán" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 75,
              columnNumber: 151
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 74,
            columnNumber: 14
          }, this),
          filters: /* @__PURE__ */ jsxDEV(FormFields, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "flex-start" }, role: "group", "aria-label": "Bộ lọc danh mục", children: [
            /* @__PURE__ */ jsxDEV(FieldGroup, { geometry: { flex: 1, minWidth: 0 }, children: /* @__PURE__ */ jsxDEV(TextField, { size: "small", label: "Tìm danh mục", value: categorySearchInput, onChange: (event) => setCategorySearchInput(event.target.value), helperText: "Tìm danh mục trên toàn cửa hàng." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 79,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 78,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(FieldGroup, { geometry: { flex: 1, minWidth: 0 }, children: [
              /* @__PURE__ */ jsxDEV(TextField, { select: true, size: "small", label: "Danh mục", value: params.get("categoryId") || "", onChange: (event) => setFilter("categoryId", event.target.value), children: [
                /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Tất cả danh mục" }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                  lineNumber: 83,
                  columnNumber: 25
                }, this),
                params.get("categoryId") && !categories.data?.data.some((category) => category.id === params.get("categoryId")) && /* @__PURE__ */ jsxDEV(MenuItem, { value: params.get("categoryId"), children: selectedCategory?.name || params.get("categoryId") }, void 0, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                  lineNumber: 84,
                  columnNumber: 141
                }, this),
                categories.data?.data.map((category) => /* @__PURE__ */ jsxDEV(MenuItem, { value: category.id, children: category.name }, category.id, false, {
                  fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                  lineNumber: 85,
                  columnNumber: 66
                }, this))
              ] }, void 0, true, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 82,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "danh mục", loadedCount: categories.loadedCount, hasMore: categories.hasMore, busy: categories.isLoadingMore, onLoadMore: categories.loadMore }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 87,
                columnNumber: 21
              }, this),
              categories.isError && /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => {
                void (categories.isFetchNextPageError ? categories.loadMore() : categories.refetch());
              }, children: "Thử lại danh mục" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 88,
                columnNumber: 44
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 81,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 77,
            columnNumber: 16
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh sách sản phẩm", rows: list.data.data, rowKey: (p) => p.id, columns: [
          {
            key: "name",
            label: "Sản phẩm",
            render: (p) => /* @__PURE__ */ jsxDEV(Stack, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { fontWeight: visualSx.typography.fontWeight.strong, children: p.name }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 93,
                columnNumber: 67
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: p.variants.map((v) => v.sku).join(" · ") }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 93,
                columnNumber: 151
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 93,
              columnNumber: 60
            }, this)
          },
          { key: "variants", label: "Biến thể", render: (p) => p.variants.length },
          { key: "price", label: "Giá biến thể đầu", render: (p) => /* @__PURE__ */ jsxDEV(Amount, { value: p.variants[0]?.price }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 95,
            columnNumber: 143
          }, this) },
          { key: "status", label: "Trạng thái", render: (p) => /* @__PURE__ */ jsxDEV(Status, { value: p.status }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 95,
            columnNumber: 239
          }, this) },
          { key: "action", label: "Thao tác", render: (p) => /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/products/${p.id}`, children: "Chi tiết" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 95,
            columnNumber: 321
          }, this) }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 91,
          columnNumber: 75
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 96,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 91,
        columnNumber: 73
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 72,
      columnNumber: 270
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
}
_s(ProductsPage, "F6lStQtPd+5uNe7aR3PfGBl034U=", false, function() {
  return [useScope, useNavigate, useSearchParams, usePagedApi, useApi, useApi, useListQuery];
});
_c = ProductsPage;
export function ProductEditorPage() {
  _s2();
  const { productId: routeProductId } = useParams();
  const [createdProductId, setCreatedProductId] = useState();
  const productId = routeProductId || createdProductId;
  const { shop } = useScope();
  const listHref = useListReturn(`/s/${shop.id}/products`);
  const navigate = useNavigate();
  const canWrite = useCan("catalog.write");
  const product = useApi("getProduct", { path: { productId: productId || "new" } }, !!productId);
  const [categorySearch, setCategorySearch] = useState("");
  const [categoryQuery, setCategoryQuery] = useState("");
  useEffect(() => {
    const timer = window.setTimeout(() => setCategoryQuery(categorySearch.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [categorySearch]);
  const categories = usePagedApi("listCategories", { query: { limit: 20, q: categoryQuery || void 0 } });
  const create = useCommand("createProduct", ["listProducts"]);
  const update = useCommand("updateProduct", ["getProduct", "listProducts"]);
  const archive = useCommand("archiveProduct", ["getProduct", "listProducts"]);
  const [confirm, setConfirm] = useState(false);
  const [imageIds, setImageIds] = useState([]);
  const [savedImageIds, setSavedImageIds] = useState([]);
  const [imageError, setImageError] = useState("");
  const upload = useCommand("uploadFile", []);
  const productForm = useForm({ defaultValues: defaults, resolver: zodResolver(productSchema) });
  const { register, control, handleSubmit, reset, formState: { errors, isDirty } } = productForm;
  useWatch({ control });
  const selectedCategoryId = useWatch({ control, name: "categoryId" });
  const categoryOnPage = categories.data?.data.find((category) => category.id === selectedCategoryId);
  const selectedCategory = useApi("getCategory", { path: { categoryId: selectedCategoryId || "" } }, Boolean(selectedCategoryId && !categoryOnPage));
  const retainedCategory = categoryOnPage || (selectedCategory.data?.data.id === selectedCategoryId ? selectedCategory.data.data : void 0);
  const fieldArray = useFieldArray({ control, name: "variants" });
  const imagesDirty = imageIds.length !== savedImageIds.length || imageIds.some((id, index) => id !== savedImageIds[index]);
  const editor = useVersionedDraft({
    identity: `${shop.id}:product:${routeProductId || "new"}`,
    source: product.data ? productSnapshot(product.data.data) : void 0,
    draft: { ...productForm.getValues(), imageFileIds: imageIds },
    apply: (values, baseline) => {
      reset(baseline);
      for (const key of ["name", "description", "categoryId", "status", "variants"])
        if (!draftEqual(values[key], baseline[key])) productForm.setValue(key, values[key], { shouldDirty: true });
      setImageIds(values.imageFileIds);
      setSavedImageIds(baseline.imageFileIds);
    },
    refresh: () => product.refetch({ throwOnError: true })
  });
  const draftForm = useDraftForm(isDirty || imagesDirty || editor.dirty);
  const productElement = useRef(null);
  useEffect(() => {
    if (!isDirty && !imagesDirty)
      return;
    const prevent = (e) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", prevent);
    return () => window.removeEventListener("beforeunload", prevent);
  }, [isDirty, imagesDirty]);
  const save = handleSubmit(async (fields) => {
    const submitted = { ...productForm.getValues(), imageFileIds: [...imageIds] };
    const body = {
      name: fields.name,
      description: fields.description,
      categoryId: fields.categoryId || null,
      status: fields.status,
      imageFileIds: imageIds,
      variants: fields.variants.map((v) => ({ id: v.id, sku: v.sku, name: v.name, options: v.options || {}, price: { amount: v.price, currency: shop.currency }, active: v.active }))
    };
    try {
      let response;
      if (productId) {
        const prepared = editor.prepare();
        if (!prepared || !Object.keys(prepared.patch).length) return;
        const patch = Object.fromEntries(Object.keys(prepared.patch).map((key) => [key, body[key]]));
        response = await update.execute({ path: { productId }, version: prepared.version, body: patch });
      } else response = await create.execute({ body });
      const clean = editor.committed(productSnapshot(response.data), submitted);
      setCreatedProductId(response.data.id);
      if (clean) {
        if (productElement.current) markDraftClean(productElement.current);
        navigate(`/s/${shop.id}/products/${response.data.id}`, { replace: true });
      }
    } catch (error) {
      editor.failed(error);
    }
  });
  const pending = create.pending || update.pending || upload.pending;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: productId ? "Thông tin sản phẩm" : "Thêm sản phẩm", subtitle: "Giá theo biến thể. Tồn kho được quản lý ở màn hình riêng.", actions: /* @__PURE__ */ jsxDEV(Button, { component: RouterLink, to: listHref, children: "Danh sách" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 164,
      columnNumber: 161
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 164,
      columnNumber: 12
    }, this),
    productId && product.isPending ? /* @__PURE__ */ jsxDEV(QueryState, { query: product, children: null }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 164,
      columnNumber: 262
    }, this) : productId && product.isError ? /* @__PURE__ */ jsxDEV(QueryState, { query: product, children: null }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 164,
      columnNumber: 343
    }, this) : /* @__PURE__ */ jsxDEV(Box, { component: "form", ref: (form) => {
      const element = form;
      productElement.current = element;
      draftForm(element);
    }, "data-draft-clean": !isDirty && !imagesDirty ? "true" : void 0, onSubmit: save, children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error || upload.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 165,
        columnNumber: 2
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor, labels: { name: "Tên sản phẩm", description: "Mô tả", categoryId: "Danh mục", status: "Trạng thái", variants: "Biến thể và giá", imageFileIds: "Ảnh sản phẩm" }, busy: pending }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 165,
        columnNumber: 70
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Thông tin bán hàng", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên sản phẩm", ...register("name"), error: !!errors.name, helperText: errors.name?.message, disabled: !canWrite }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 165,
          columnNumber: 342
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Mô tả dùng cho AI tư vấn", multiline: true, minRows: 4, ...register("description"), disabled: !canWrite }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 165,
          columnNumber: 475
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tìm danh mục", size: "small", value: categorySearch, onChange: (event) => setCategorySearch(event.target.value), disabled: !canWrite, helperText: "Tìm trên danh sách cửa hàng; có thể tải thêm khi cần." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 165,
          columnNumber: 593
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(Controller, { name: "categoryId", control, render: ({ field }) => /* @__PURE__ */ jsxDEV(FieldGroup, { geometry: { flex: 1, minWidth: 0, width: "100%" }, children: [
            /* @__PURE__ */ jsxDEV(TextField, { select: true, fullWidth: true, label: "Danh mục", ...field, disabled: !canWrite, children: [
              /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Chưa phân loại" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 165,
                columnNumber: 1118
              }, this),
              selectedCategoryId && !categoryOnPage && /* @__PURE__ */ jsxDEV(MenuItem, { value: selectedCategoryId, children: retainedCategory?.name || (selectedCategory.isError ? `Danh mục hiện tại (${selectedCategoryId})` : "Đang tải danh mục hiện tại…") }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 165,
                columnNumber: 1204
              }, this),
              categories.data?.data.map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: c.name }, c.id, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 165,
                columnNumber: 1419
              }, this))
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 1041
            }, this),
            /* @__PURE__ */ jsxDEV(LookupLoadMore, { label: "danh mục", loadedCount: categories.loadedCount, hasMore: categories.hasMore, busy: categories.isLoadingMore, onLoadMore: categories.loadMore }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 1486
            }, this),
            categories.isPending && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: "Đang tải danh mục…" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 1677
            }, this),
            categories.isError && /* @__PURE__ */ jsxDEV(Alert, { severity: categories.isFetchNextPageError ? "warning" : "error", role: "alert", action: /* @__PURE__ */ jsxDEV(Button, { color: "inherit", size: "small", onClick: () => {
              void (categories.isFetchNextPageError ? categories.loadMore() : categories.refetch());
            }, children: "Thử lại danh mục" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 1857
            }, this), children: categories.isFetchNextPageError ? `Không tải thêm được danh mục (HTTP ${categories.error instanceof ApiError ? categories.error.status : "lỗi"}). Các lựa chọn đã tải vẫn dùng được.` : `Không tải được danh mục (HTTP ${categories.error instanceof ApiError ? categories.error.status : "lỗi"}). Bản nháp được giữ; hãy thử lại hoặc chọn “Chưa phân loại”.` }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 1764
            }, this),
            categories.data?.data.length === 0 && !categories.isFetching && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: categoryQuery ? "Không tìm thấy danh mục phù hợp." : "Cửa hàng chưa có danh mục." }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 2452
            }, this),
            selectedCategory.isPending && selectedCategoryId && !categoryOnPage && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", role: "status", children: "Đang tải tên danh mục đã gắn với sản phẩm…" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 2653
            }, this),
            selectedCategory.isError && selectedCategoryId && !categoryOnPage && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", role: "alert", action: /* @__PURE__ */ jsxDEV(Button, { color: "inherit", size: "small", onClick: () => {
              void selectedCategory.refetch();
            }, children: "Thử lại danh mục đang chọn" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 2858
            }, this), children: selectedCategory.error instanceof ApiError && selectedCategory.error.status === 403 ? "Không có quyền đọc danh mục hiện tại (403). ID đã chọn vẫn được giữ trong biểu mẫu." : `Không tải được danh mục hiện tại (${selectedCategory.error instanceof ApiError ? selectedCategory.error.status : "lỗi"}). ID đã chọn vẫn được giữ trong biểu mẫu.` }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 2811
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 165,
            columnNumber: 978
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 165,
            columnNumber: 907
          }, this),
          /* @__PURE__ */ jsxDEV(Controller, { name: "status", control, render: ({ field }) => /* @__PURE__ */ jsxDEV(TextField, { select: true, fullWidth: true, label: "Trạng thái", ...field, disabled: !canWrite, sx: { flex: 1, minWidth: 0 }, children: [
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "draft", children: "Bản nháp" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 3524
            }, this),
            /* @__PURE__ */ jsxDEV(MenuItem, { value: "active", children: "Đang bán" }, void 0, false, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 165,
              columnNumber: 3567
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 165,
            columnNumber: 3415
          }, this) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 165,
            columnNumber: 3348
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 165,
          columnNumber: 811
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 165,
        columnNumber: 330
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 165,
        columnNumber: 279
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Biến thể và giá", bodyMode: "inset", beforeGap: "section", action: /* @__PURE__ */ jsxDEV(Button, { startIcon: /* @__PURE__ */ jsxDEV(AddRounded, {}, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 166,
        columnNumber: 99
      }, this), disabled: !canWrite, onClick: () => fieldArray.append({ sku: "", name: "", price: "", active: true }), children: "Thêm biến thể" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 166,
        columnNumber: 80
      }, this), children: /* @__PURE__ */ jsxDEV(FormFields, { children: fieldArray.fields.map((field, index) => /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", md: "row" }, alignItems: { xs: "stretch", md: "start" }, flexWrap: "wrap", children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "SKU", ...register(`variants.${index}.sku`), error: !!errors.variants?.[index]?.sku, helperText: errors.variants?.[index]?.sku?.message, disabled: !canWrite, sx: { width: { xs: "100%", md: "auto" }, minWidth: "min(100%, 12em)", maxWidth: "100%", flex: { xs: "0 1 auto", md: "1 1 12em" } } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 422
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên / màu / kích cỡ", ...register(`variants.${index}.name`), disabled: !canWrite, sx: { width: { xs: "100%", md: "auto" }, minWidth: "min(100%, 12em)", maxWidth: "100%", flex: { xs: "0 1 auto", md: "1 1 12em" } } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 731
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: `Giá bán (${shop.currency})`, inputProps: { inputMode: "decimal" }, ...register(`variants.${index}.price`), error: !!errors.variants?.[index]?.price, helperText: errors.variants?.[index]?.price?.message, disabled: !canWrite, sx: { width: { xs: "100%", md: "auto" }, minWidth: "min(100%, 12em)", maxWidth: "100%", flex: { xs: "0 1 auto", md: "1 1 12em" } } }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 965
        }, this),
        /* @__PURE__ */ jsxDEV(FormControlLabel, { label: "Đang bán", control: /* @__PURE__ */ jsxDEV(Checkbox, { defaultChecked: field.active, ...register(`variants.${index}.active`), disabled: !canWrite }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 1387
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 1343
        }, this),
        /* @__PURE__ */ jsxDEV(IconButton, { "aria-label": `Xóa biến thể ${index + 1}`, disabled: !canWrite || fieldArray.fields.length === 1, onClick: () => fieldArray.remove(index), children: /* @__PURE__ */ jsxDEV(DeleteOutlineRounded, {}, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 1645
        }, this) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 166,
          columnNumber: 1496
        }, this)
      ] }, field.id, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 166,
        columnNumber: 295
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 166,
        columnNumber: 242
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 166,
        columnNumber: 2
      }, this),
      /* @__PURE__ */ jsxDEV(Panel, { title: "Ảnh sản phẩm", subtitle: "File được kiểm soát qua API upload; không nhúng secret hoặc URL tùy ý.", bodyMode: "inset", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: [
          imageIds.length,
          " tệp được gắn với sản phẩm"
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 167,
          columnNumber: 163
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { component: "label", variant: "outlined", disabled: !canWrite || pending, children: [
          "Chọn ảnh",
          /* @__PURE__ */ jsxDEV("input", { hidden: true, type: "file", accept: "image/png,image/jpeg,image/webp", onChange: async (e) => {
            const input = e.currentTarget;
            const file = input.files?.[0] || null;
            const error = productImageFileError(file, __MOCK__ ? PRODUCT_IMAGE_MAX_BYTES : void 0);
            setImageError(error);
            if (error) {
              input.value = "";
              return;
            }
            if (!file) return;
            const form = new FormData();
            form.append("file", file);
            form.append("purpose", "product_image");
            try {
              const r = await upload.execute({ form });
              if (r.data.status === "ready")
                setImageIds((ids) => [...ids, r.data.id]);
              else
                alert("Tệp đang được cách ly/kiểm tra; chưa gắn vào sản phẩm.");
            } catch {
            }
            input.value = "";
          } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 167,
            columnNumber: 332
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 167,
          columnNumber: 247
        }, this),
        imageError && /* @__PURE__ */ jsxDEV(Alert, { severity: "error", role: "alert", children: imageError }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 174,
          columnNumber: 88
        }, this),
        imageIds.map((fileId) => /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
          /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", children: fileId }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 174,
            columnNumber: 214
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "small", disabled: !canWrite, onClick: () => setImageIds((ids) => ids.filter((x) => x !== fileId)), children: "Bỏ liên kết ảnh" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 174,
            columnNumber: 265
          }, this)
        ] }, fileId, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 174,
          columnNumber: 172
        }, this))
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 167,
        columnNumber: 151
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 167,
        columnNumber: 2
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "form", justifyContent: "space-between", children: [
        productId && product.data?.data.status !== "archived" ? /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", color: "error", onClick: () => setConfirm(true), children: "Ngừng bán" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 175,
          columnNumber: 138
        }, this) : /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 175,
          columnNumber: 257
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", type: "submit", variant: "contained", busy: pending, children: "Lưu sản phẩm" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 175,
          columnNumber: 266
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 175,
        columnNumber: 2
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 164,
      columnNumber: 393
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: confirm, title: "Ngừng bán sản phẩm", confirmLabel: "Ngừng bán sản phẩm", description: `Sản phẩm ${product.data?.data.name || ""} (${productId || ""}): ngừng bán mới; lịch sử đơn hàng và dữ liệu đã phát sinh được giữ.`, requireReason: true, onClose: () => setConfirm(false), busy: archive.pending, error: archive.error, onConfirm: async (reason) => {
      const current = product.data?.data;
      if (!productId || !current) return;
      await archive.execute({ path: { productId }, version: current.version, body: { expectedVersion: current.version, reason } });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 176,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
    lineNumber: 164,
    columnNumber: 10
  }, this);
}
_s2(ProductEditorPage, "q0KyQ2ggWpWCpmurq2w6IW+3PJc=", false, function() {
  return [useParams, useScope, useListReturn, useNavigate, useCan, useApi, usePagedApi, useCommand, useCommand, useCommand, useCommand, useForm, useWatch, useWatch, useApi, useFieldArray, useVersionedDraft, useDraftForm];
});
_c2 = ProductEditorPage;
export function CategoriesPage() {
  _s3();
  const list = useApi("listCategories", { query: useListQuery("listCategories") });
  const create = useCommand("createCategory", ["listCategories"]);
  const update = useCommand("updateCategory", ["listCategories"]);
  const archive = useCommand("archiveCategory", ["listCategories"]);
  const [edit, setEdit] = useState();
  const [name, setName] = useState("");
  const [parentId, setParentId] = useState("");
  const [remove, setRemove] = useState(null), [savedMessage, setSavedMessage] = useState("");
  const categoryDetail = useApi("getCategory", { path: { categoryId: edit?.id || "" } }, !!edit?.id);
  const waitingForDetail = Boolean(edit?.id && categoryDetail.data?.data.id !== edit.id);
  const detail = edit?.id && categoryDetail.data?.data.id === edit.id ? categoryDetail.data.data : edit;
  const categoryEditor = useVersionedDraft({
    identity: `${useScope().shop.id}:category:${edit?.id || "new"}`,
    source: detail ? { version: detail.version, values: { name: detail.name, parentId: detail.parentId || "" } } : void 0,
    draft: { name, parentId },
    apply: (values) => {
      setName(values.name);
      setParentId(values.parentId);
    },
    refresh: () => categoryDetail.refetch({ throwOnError: true })
  });
  const open = (c) => {
    setSavedMessage("");
    setName(c?.name || "");
    setParentId(c?.parentId || "");
    setEdit(c);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Danh mục", subtitle: "Sắp xếp sản phẩm, không thay đổi tồn kho.", actions: /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", variant: "contained", onClick: () => open(null), children: "Thêm danh mục" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 201,
      columnNumber: 103
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 201,
      columnNumber: 12
    }, this),
    savedMessage && /* @__PURE__ */ jsxDEV(Alert, { severity: "success", role: "status", sx: layoutSx.notice.afterGap, children: savedMessage }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 201,
      columnNumber: 244
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { children: [
      /* @__PURE__ */ jsxDEV(Toolbar, { operation: "listCategories" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 201,
        columnNumber: 344
      }, this),
      /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(DataTable, { label: "Danh sách danh mục", rows: list.data.data, rowKey: (c) => c.id, columns: [
          { key: "name", label: "Tên danh mục", render: (c) => c.name },
          { key: "parent", label: "Danh mục cha", render: (c) => list.data?.data.find((p) => p.id === c.parentId)?.name || "—" },
          { key: "state", label: "Trạng thái", render: (c) => /* @__PURE__ */ jsxDEV(Status, { value: c.active ? "active" : "disabled" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 202,
            columnNumber: 246
          }, this) },
          {
            key: "action",
            label: "",
            render: (c) => /* @__PURE__ */ jsxDEV(Stack, { direction: "row", children: [
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", onClick: () => open(c), children: "Sửa" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 204,
                columnNumber: 77
              }, this),
              /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.write", color: "error", onClick: () => setRemove(c), children: "Ngừng dùng" }, void 0, false, {
                fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
                lineNumber: 204,
                columnNumber: 164
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
              lineNumber: 204,
              columnNumber: 54
            }, this)
          }
        ] }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 201,
          columnNumber: 448
        }, this),
        /* @__PURE__ */ jsxDEV(Pager, { page: list.data.page }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 206,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 201,
        columnNumber: 446
      }, this) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 201,
        columnNumber: 382
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 201,
      columnNumber: 337
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { allowEditsWhileBusy: true, open: edit !== void 0, title: edit ? "Sửa danh mục" : "Thêm danh mục", onClose: () => setEdit(void 0), busy: create.pending || update.pending || waitingForDetail, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !name.trim() || create.pending || update.pending || waitingForDetail, onClick: async () => {
      try {
        const submitted = { name, parentId };
        const body = { name: name.trim(), parentId: parentId || null };
        let result;
        if (edit) {
          const prepared = categoryEditor.prepare();
          if (!prepared || !Object.keys(prepared.patch).length) return;
          result = await update.execute({ path: { categoryId: edit.id }, version: prepared.version, body: {
            ...prepared.patch.name !== void 0 ? { name: body.name } : {},
            ...prepared.patch.parentId !== void 0 ? { parentId: body.parentId } : {}
          } });
        } else result = await create.execute({ body });
        const clean = categoryEditor.committed({ version: result.data.version, values: { name: result.data.name, parentId: result.data.parentId || "" } }, submitted, `${result.data.shopId}:category:${result.data.id}`);
        setSavedMessage(clean ? `Đã lưu danh mục “${result.data.name}”.` : `Đã lưu danh mục “${result.data.name}”; thay đổi mới vẫn chưa được lưu.`);
        setEdit(clean ? void 0 : result.data);
      } catch (error) {
        categoryEditor.failed(error);
      }
    }, children: "Lưu" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 207,
      columnNumber: 212
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 222,
        columnNumber: 69
      }, this),
      /* @__PURE__ */ jsxDEV(DraftConflict, { editor: categoryEditor, labels: { name: "Tên danh mục", parentId: "Danh mục cha" }, busy: create.pending || update.pending }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 222,
        columnNumber: 121
      }, this),
      edit?.id && waitingForDetail && /* @__PURE__ */ jsxDEV(Alert, { severity: categoryDetail.error ? "error" : "info", action: categoryDetail.error ? /* @__PURE__ */ jsxDEV(Button, { size: "small", onClick: () => void categoryDetail.refetch(), children: "Thử lại" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 222,
        columnNumber: 384
      }, this) : void 0, children: categoryDetail.error ? "Không tải được chi tiết danh mục; dữ liệu nhập vẫn được giữ. Hãy thử lại." : "Đang tải chi tiết danh mục trước khi cho phép chỉnh sửa." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 222,
        columnNumber: 295
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { density: "compact", children: [
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên", value: name, onChange: (e) => setName(e.target.value), disabled: waitingForDetail }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 222,
          columnNumber: 681
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Danh mục cha", select: true, value: parentId, onChange: (e) => setParentId(e.target.value), disabled: waitingForDetail, children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "", children: "Không có" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 222,
            columnNumber: 919
          }, this),
          list.data?.data.filter((c) => c.id !== edit?.id).map((c) => /* @__PURE__ */ jsxDEV(MenuItem, { value: c.id, children: c.name }, c.id, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
            lineNumber: 222,
            columnNumber: 1018
          }, this))
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
          lineNumber: 222,
          columnNumber: 789
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
        lineNumber: 222,
        columnNumber: 651
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 207,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!remove, title: "Ngừng dùng danh mục", confirmLabel: "Ngừng dùng danh mục", description: `Danh mục ${remove?.name || ""} (${remove?.id || ""}): ngừng dùng trong lựa chọn mới; không xóa sản phẩm hoặc lịch sử.`, requireReason: true, onClose: () => setRemove(null), error: archive.error, busy: archive.pending, onConfirm: (reason) => archive.execute({ path: { categoryId: remove?.id || "" }, version: remove?.version, body: { expectedVersion: remove?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
      lineNumber: 223,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx",
    lineNumber: 201,
    columnNumber: 10
  }, this);
}
_s3(CategoriesPage, "jU7I/pFM5OZ/XZra77Kslx9C/DQ=", false, function() {
  return [useApi, useListQuery, useCommand, useCommand, useCommand, useApi, useVersionedDraft, useScope];
});
_c3 = CategoriesPage;
export { ImportsPage, ImportResultPage } from "/src/modules/catalog/imports.tsx";
function productSnapshot(product) {
  const values = {
    name: product.name,
    description: product.description,
    categoryId: product.categoryId || "",
    status: product.status === "active" ? "active" : "draft",
    variants: product.variants.map((v) => ({ id: v.id, sku: v.sku, name: v.name, options: v.options, price: v.price?.amount || "", active: v.active })),
    imageFileIds: product.imageFileIds
  };
  return { version: product.version, values };
}
var _c, _c2, _c3;
$RefreshReg$(_c, "ProductsPage");
$RefreshReg$(_c2, "ProductEditorPage");
$RefreshReg$(_c3, "CategoriesPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0R1SCxTQW1CL0MsVUFuQitDOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEdkgsU0FBUUEscUJBQW9CO0FBQzVCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxhQUFhQyxZQUFZQyxrQkFBa0I7QUFDcEQsU0FBU0MsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQzVDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsV0FBV0MsaUJBQWlCQyxRQUFRQyxrQkFBa0I7QUFDNUUsU0FBU0MsU0FBU0MsZUFBZUMsWUFBWUMsZ0JBQWdCO0FBQzdELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxTQUFTO0FBQ2xCLFNBQVNDLE9BQU9DLEtBQUtDLFFBQVFDLFVBQVVDLGtCQUFrQkMsWUFBWUMsVUFBVUMsT0FBT0MsV0FBV0Msa0JBQWtCO0FBQ25ILE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQywwQkFBMEI7QUFFakMsU0FBU0MsUUFBUUMsWUFBWUMsbUJBQW1CO0FBQ2hELFNBQVNDLFVBQVVDLGNBQWM7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHlCQUF5QkMsNkJBQTZCO0FBQy9ELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZQyx5QkFBeUI7QUFDOUMsU0FBU0MsZ0JBQWdCQyxvQkFBb0I7QUFDN0MsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFlBQVlDLE9BQU9DLFdBQVdDLFFBQVFDLFFBQVFDLFlBQVlDLFNBQVNDLE9BQU9DLGdCQUFnQkMsWUFBWUMsYUFBYUMsZUFBZUMsV0FBV0Msc0JBQXNCO0FBQzVLLE1BQU1DLGdCQUFnQnpDLEVBQUUwQyxPQUFPO0FBQUEsRUFDM0JDLE1BQU0zQyxFQUFFNEMsT0FBTyxFQUFFQyxLQUFLLEVBQUVDLElBQUksR0FBRyxtQkFBbUIsRUFBRUMsT0FBTyxDQUFBQyxVQUFTbkUsZ0JBQWdCbUUsS0FBSyxLQUFLLEtBQUssZ0NBQWdDO0FBQUEsRUFBR0MsYUFBYWpELEVBQUU0QyxPQUFPLEVBQUVHLE9BQU8sQ0FBQUMsVUFBU25FLGdCQUFnQm1FLEtBQUssS0FBSyxLQUFPLDRCQUE0QjtBQUFBLEVBQUdFLFlBQVlsRCxFQUFFNEMsT0FBTztBQUFBLEVBQUdPLFFBQVFuRCxFQUFFb0QsS0FBSyxDQUFDLFNBQVMsUUFBUSxDQUFDO0FBQUEsRUFBR0MsVUFBVXJELEVBQUVzRCxNQUFNdEQsRUFBRTBDLE9BQU87QUFBQSxJQUNsVWEsSUFBSXZELEVBQUU0QyxPQUFPLEVBQUVZLFNBQVM7QUFBQSxJQUFHQyxTQUFTekQsRUFBRTBELE9BQU8xRCxFQUFFNEMsT0FBTyxHQUFHNUMsRUFBRTRDLE9BQU8sQ0FBQyxFQUFFWSxTQUFTO0FBQUEsSUFBR0csS0FBSzNELEVBQUU0QyxPQUFPLEVBQUVDLEtBQUssRUFBRUMsSUFBSSxHQUFHLFVBQVUsRUFBRUMsT0FBTyxDQUFBQyxVQUFTbkUsZ0JBQWdCbUUsS0FBSyxLQUFLLElBQUksc0JBQXNCO0FBQUEsSUFBR0wsTUFBTTNDLEVBQUU0QyxPQUFPLEVBQUVFLElBQUksR0FBRyxtQkFBbUI7QUFBQSxJQUFHYyxPQUFPNUQsRUFBRTRDLE9BQU8sRUFBRUMsS0FBSyxFQUFFQyxJQUFJLEdBQUcsY0FBYyxFQUFFZSxNQUFNLHFCQUFxQixrQkFBa0IsRUFBRWQsT0FBTyxDQUFBQyxVQUFTYyxPQUFPZCxLQUFLLElBQUksR0FBRyxvQkFBb0I7QUFBQSxJQUFHZSxRQUFRL0QsRUFBRWdFLFFBQVE7QUFBQSxFQUMvWixDQUFDLENBQUMsRUFBRWxCLElBQUksR0FBRywwQkFBMEI7QUFDekMsQ0FBQztBQUVELE1BQU1tQixXQUEwQixFQUFFdEIsTUFBTSxJQUFJTSxhQUFhLElBQUlDLFlBQVksSUFBSUMsUUFBUSxTQUFTRSxVQUFVLENBQUMsRUFBRU0sS0FBSyxJQUFJaEIsTUFBTSxZQUFZaUIsT0FBTyxJQUFJRyxRQUFRLEtBQUssQ0FBQyxFQUFFO0FBQzFKLGdCQUFTRyxlQUFlO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxFQUFFQyxLQUFLLElBQUlwRCxTQUFTO0FBQzFCLFFBQU1xRCxXQUFXL0UsWUFBWTtBQUM3QixRQUFNLENBQUNnRixRQUFRQyxTQUFTLElBQUkvRSxnQkFBZ0I7QUFDNUMsUUFBTSxDQUFDZ0YscUJBQXFCQyxzQkFBc0IsSUFBSXRGLFNBQVMsRUFBRSxHQUFHLENBQUN1RixnQkFBZ0JDLGlCQUFpQixJQUFJeEYsU0FBUyxFQUFFO0FBQ3JIRixZQUFVLE1BQU07QUFDWixVQUFNMkYsUUFBUUMsT0FBT0MsV0FBVyxNQUFNSCxrQkFBa0JILG9CQUFvQjNCLEtBQUssQ0FBQyxHQUFHLEdBQUc7QUFDeEYsV0FBTyxNQUFNZ0MsT0FBT0UsYUFBYUgsS0FBSztBQUFBLEVBQzFDLEdBQUcsQ0FBQ0osbUJBQW1CLENBQUM7QUFDeEIsUUFBTVEsYUFBYWpFLFlBQVksa0JBQWtCLEVBQUVrRSxPQUFPLEVBQUVDLEdBQUdSLGtCQUFrQlMsT0FBVSxFQUFFLENBQUM7QUFDOUYsUUFBTUMseUJBQXlCdkUsT0FBTyxlQUFlLEVBQUV3RSxNQUFNLEVBQUVuQyxZQUFZb0IsT0FBT2dCLElBQUksWUFBWSxLQUFLLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQ2hCLE9BQU9nQixJQUFJLFlBQVksQ0FBQztBQUN6SSxRQUFNQyxtQkFBbUJQLFdBQVdRLE1BQU1BLEtBQUtDLEtBQUssQ0FBQUMsYUFBWUEsU0FBU25DLE9BQU9lLE9BQU9nQixJQUFJLFlBQVksQ0FBQyxLQUFLRix1QkFBdUJJLE1BQU1BO0FBQzFJLFFBQU1HLE9BQU85RSxPQUFPLGdCQUFnQixFQUFFb0UsT0FBTyxFQUFFLEdBQUcvRCxhQUFhLGNBQWMsR0FBR2dDLFlBQVlvQixPQUFPZ0IsSUFBSSxZQUFZLEtBQUtILE9BQVUsRUFBRSxDQUFDO0FBQ3JJLFFBQU1TLFlBQVlBLENBQUNDLEtBQWE3QyxVQUFrQjtBQUM5QyxVQUFNOEMsT0FBTyxJQUFJQyxnQkFBZ0J6QixNQUFNO0FBQ3ZDLFFBQUl0QjtBQUNBOEMsV0FBS0UsSUFBSUgsS0FBSzdDLEtBQUs7QUFBQTtBQUVuQjhDLFdBQUtHLE9BQU9KLEdBQUc7QUFDbkJDLFNBQUtHLE9BQU8sUUFBUTtBQUNwQjFCLGNBQVV1QixJQUFJO0FBQUEsRUFDbEI7QUFDQSxTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLFlBQVcsVUFBUyw0REFBMkQsU0FBUyx1QkFBQyxrQkFBZSxZQUFXLGlCQUFnQixTQUFTLE1BQU16QixTQUFTLE1BQU1ELEtBQUtiLEVBQUUsZUFBZSxHQUFHLFNBQVEsYUFBWSw2QkFBdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtSSxLQUE3TztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStQO0FBQUEsSUFBRSx1QkFBQyxTQUN2UTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBUSxXQUFVO0FBQUEsVUFBZSxhQUFZO0FBQUEsVUFDMUMsT0FBTyx1QkFBQyxhQUFVLFFBQU0sTUFBQyxNQUFLLFNBQVEsT0FBTSxjQUFhLE9BQU9lLE9BQU9nQixJQUFJLFFBQVEsS0FBSyxJQUFJLFVBQVUsQ0FBQVksVUFBU04sVUFBVSxVQUFVTSxNQUFNQyxPQUFPbkQsS0FBSyxHQUFHLElBQUksRUFBRW9ELFVBQVUsSUFBSSxHQUN4SztBQUFBLG1DQUFDLFlBQVMsT0FBTSxJQUFHLGlDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQVcsdUJBQUMsWUFBUyxPQUFNLFNBQVEsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFBVyx1QkFBQyxZQUFTLE9BQU0sVUFBUyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUFXLHVCQUFDLFlBQVMsT0FBTSxZQUFXLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLGVBRDFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRVA7QUFBQSxVQUNBLFNBQVMsdUJBQUMsY0FBVyxXQUFXLEVBQUVDLElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFRCxJQUFJLFdBQVdDLElBQUksYUFBYSxHQUFHLE1BQUssU0FBUSxjQUFXLG1CQUNsSTtBQUFBLG1DQUFDLGNBQVcsVUFBVSxFQUFFQyxNQUFNLEdBQUdILFVBQVUsRUFBRSxHQUN6QyxpQ0FBQyxhQUFVLE1BQUssU0FBUSxPQUFNLGdCQUFlLE9BQU81QixxQkFBcUIsVUFBVSxDQUFBMEIsVUFBU3pCLHVCQUF1QnlCLE1BQU1DLE9BQU9uRCxLQUFLLEdBQUcsWUFBVyxzQ0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUwsS0FEekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsY0FBVyxVQUFVLEVBQUV1RCxNQUFNLEdBQUdILFVBQVUsRUFBRSxHQUN6QztBQUFBLHFDQUFDLGFBQVUsUUFBTSxNQUFDLE1BQUssU0FBUSxPQUFNLFlBQVcsT0FBTzlCLE9BQU9nQixJQUFJLFlBQVksS0FBSyxJQUFJLFVBQVUsQ0FBQVksVUFBU04sVUFBVSxjQUFjTSxNQUFNQyxPQUFPbkQsS0FBSyxHQUNoSjtBQUFBLHVDQUFDLFlBQVMsT0FBTSxJQUFHLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGdCQUNqQ3NCLE9BQU9nQixJQUFJLFlBQVksS0FBSyxDQUFDTixXQUFXUSxNQUFNQSxLQUFLZ0IsS0FBSyxDQUFBZCxhQUFZQSxTQUFTbkMsT0FBT2UsT0FBT2dCLElBQUksWUFBWSxDQUFDLEtBQUssdUJBQUMsWUFBUyxPQUFPaEIsT0FBT2dCLElBQUksWUFBWSxHQUFLQyw0QkFBa0I1QyxRQUFRMkIsT0FBT2dCLElBQUksWUFBWSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRztBQUFBLGdCQUNqTk4sV0FBV1EsTUFBTUEsS0FBS2lCLElBQUksQ0FBQWYsYUFBWSx1QkFBQyxZQUEyQixPQUFPQSxTQUFTbkMsSUFBS21DLG1CQUFTL0MsUUFBM0MrQyxTQUFTbkMsSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0QsQ0FBVztBQUFBLG1CQUhySDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxrQkFBZSxPQUFNLFlBQVcsYUFBYXlCLFdBQVcwQixhQUFhLFNBQVMxQixXQUFXMkIsU0FBUyxNQUFNM0IsV0FBVzRCLGVBQWUsWUFBWTVCLFdBQVc2QixZQUExSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtSztBQUFBLGNBQ2xLN0IsV0FBVzhCLFdBQVcsdUJBQUMsVUFBTyxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsc0JBQU05QixXQUFXK0IsdUJBQXVCL0IsV0FBVzZCLFNBQVMsSUFBSTdCLFdBQVdnQyxRQUFRO0FBQUEsY0FBSSxHQUFHLGdDQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnSjtBQUFBLGlCQVAzSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFaSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFUO0FBQUE7QUFBQSxRQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFpQmtCO0FBQUEsTUFDbEIsdUJBQUMsY0FBVyxPQUFPckIsTUFBTSxnQkFBZSxXQUFXQSxlQUFLSCxRQUFRLG1DQUFFO0FBQUEsK0JBQUMsYUFBVSxPQUFNLHNCQUFxQixNQUFNRyxLQUFLSCxLQUFLQSxNQUFNLFFBQVEsQ0FBQXlCLE1BQUtBLEVBQUUxRCxJQUFJLFNBQVM7QUFBQSxVQUMxSjtBQUFBLFlBQ0lzQyxLQUFLO0FBQUEsWUFBUXFCLE9BQU87QUFBQSxZQUFZQyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFNBQU07QUFBQSxxQ0FBQyxjQUFXLFlBQVk3SCxTQUFTZ0ksV0FBV0MsV0FBV0MsUUFBU0wsWUFBRXRFLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FBYSx1QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUFrQnNFLFlBQUU1RCxTQUFTb0QsSUFBSSxDQUFBYyxNQUFLQSxFQUFFNUQsR0FBRyxFQUFFNkQsS0FBSyxLQUFLLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZGO0FBQUEsaUJBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFNO0FBQUEsVUFDdFA7QUFBQSxVQUNBLEVBQUUzQixLQUFLLFlBQVlxQixPQUFPLFlBQVlDLFFBQVFBLENBQUFGLE1BQUtBLEVBQUU1RCxTQUFTb0UsT0FBTztBQUFBLFVBQUcsRUFBRTVCLEtBQUssU0FBU3FCLE9BQU8sb0JBQW9CQyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRTVELFNBQVMsQ0FBQyxHQUFHTyxTQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQyxFQUFHO0FBQUEsVUFBRyxFQUFFaUMsS0FBSyxVQUFVcUIsT0FBTyxjQUFjQyxRQUFRQSxDQUFBRixNQUFLLHVCQUFDLFVBQU8sT0FBT0EsRUFBRTlELFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEVBQUc7QUFBQSxVQUFHLEVBQUUwQyxLQUFLLFVBQVVxQixPQUFPLFlBQVlDLFFBQVFBLENBQUFGLE1BQUssdUJBQUMsYUFBVSxJQUFJLE1BQU03QyxLQUFLYixFQUFFLGFBQWEwRCxFQUFFMUQsRUFBRSxJQUFJLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RCxFQUFhO0FBQUEsUUFBQyxLQUpqVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3BFO0FBQUEsUUFBRSx1QkFBQyxTQUFNLE1BQU1vQyxLQUFLSCxLQUFLa0MsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBTG9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLbEMsS0FMOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtrQztBQUFBLFNBeEJvTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0J2TjtBQUFBLE9BeEI1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JvRDtBQUMvRDtBQUFDdkQsR0EvQ2VELGNBQVk7QUFBQSxVQUNQbEQsVUFDQTFCLGFBQ1dFLGlCQU1UdUIsYUFDWUYsUUFFbEJBLFFBQXFDSyxZQUFZO0FBQUE7QUFBQSxLQVpsRGdEO0FBZ0RULGdCQUFTeUQsb0JBQW9CO0FBQUFDLE1BQUE7QUFDaEMsUUFBTSxFQUFFQyxXQUFXQyxlQUFlLElBQUl2SSxVQUFVO0FBQ2hELFFBQU0sQ0FBQ3dJLGtCQUFrQkMsbUJBQW1CLElBQUk3SSxTQUFpQjtBQUNqRSxRQUFNMEksWUFBWUMsa0JBQWtCQztBQUNwQyxRQUFNLEVBQUUzRCxLQUFLLElBQUlwRCxTQUFTO0FBQzFCLFFBQU1pSCxXQUFTckosY0FBYyxNQUFNd0YsS0FBS2IsRUFBRSxXQUFXO0FBQ3JELFFBQU1jLFdBQVcvRSxZQUFZO0FBQzdCLFFBQU00SSxXQUFXakgsT0FBTyxlQUFlO0FBQ3ZDLFFBQU1rSCxVQUFVdEgsT0FBTyxjQUFjLEVBQUV3RSxNQUFNLEVBQUV3QyxXQUFXQSxhQUFhLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQ0EsU0FBUztBQUM3RixRQUFNLENBQUNuRCxnQkFBZ0JDLGlCQUFpQixJQUFJeEYsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2lKLGVBQWVDLGdCQUFnQixJQUFJbEosU0FBUyxFQUFFO0FBQ3JERixZQUFVLE1BQU07QUFDWixVQUFNMkYsUUFBUUMsT0FBT0MsV0FBVyxNQUFNdUQsaUJBQWlCM0QsZUFBZTdCLEtBQUssQ0FBQyxHQUFHLEdBQUc7QUFDbEYsV0FBTyxNQUFNZ0MsT0FBT0UsYUFBYUgsS0FBSztBQUFBLEVBQzFDLEdBQUcsQ0FBQ0YsY0FBYyxDQUFDO0FBQ25CLFFBQU1NLGFBQWFqRSxZQUFZLGtCQUFrQixFQUFFa0UsT0FBTyxFQUFFcUQsT0FBTyxJQUFJcEQsR0FBR2tELGlCQUFpQmpELE9BQVUsRUFBRSxDQUFDO0FBQ3hHLFFBQU1vRCxTQUFTekgsV0FBVyxpQkFBaUIsQ0FBQyxjQUFjLENBQUM7QUFDM0QsUUFBTTBILFNBQVMxSCxXQUFXLGlCQUFpQixDQUFDLGNBQWMsY0FBYyxDQUFDO0FBQ3pFLFFBQU0ySCxVQUFVM0gsV0FBVyxrQkFBa0IsQ0FBQyxjQUFjLGNBQWMsQ0FBQztBQUMzRSxRQUFNLENBQUM0SCxTQUFTQyxVQUFVLElBQUl4SixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDeUosVUFBVUMsV0FBVyxJQUFJMUosU0FBbUIsRUFBRTtBQUNyRCxRQUFNLENBQUMySixlQUFlQyxnQkFBZ0IsSUFBSTVKLFNBQW1CLEVBQUU7QUFDL0QsUUFBTSxDQUFDNkosWUFBWUMsYUFBYSxJQUFJOUosU0FBUyxFQUFFO0FBQy9DLFFBQU0rSixTQUFTcEksV0FBVyxjQUFjLEVBQUU7QUFDMUMsUUFBTXFJLGNBQWN4SixRQUF1QixFQUFFeUosZUFBZW5GLFVBQVVvRixVQUFVdEosWUFBWTBDLGFBQWEsRUFBRSxDQUFDO0FBQzVHLFFBQU0sRUFBRTZHLFVBQVVDLFNBQVNDLGNBQWNDLE9BQU9DLFdBQVcsRUFBRUMsUUFBUUMsUUFBUSxFQUFFLElBQUlUO0FBQ25GckosV0FBUyxFQUFFeUosUUFBUSxDQUFDO0FBQ3BCLFFBQU1NLHFCQUFxQi9KLFNBQVMsRUFBRXlKLFNBQVM1RyxNQUFNLGFBQWEsQ0FBQztBQUNuRSxRQUFNbUgsaUJBQWlCOUUsV0FBV1EsTUFBTUEsS0FBS0MsS0FBSyxDQUFBQyxhQUFZQSxTQUFTbkMsT0FBT3NHLGtCQUFrQjtBQUNoRyxRQUFNdEUsbUJBQW1CMUUsT0FBTyxlQUFlLEVBQUV3RSxNQUFNLEVBQUVuQyxZQUFZMkcsc0JBQXNCLEdBQUcsRUFBRSxHQUFHRSxRQUFRRixzQkFBc0IsQ0FBQ0MsY0FBYyxDQUFDO0FBQ2pKLFFBQU1FLG1CQUFtQkYsbUJBQW1CdkUsaUJBQWlCQyxNQUFNQSxLQUFLakMsT0FBT3NHLHFCQUFxQnRFLGlCQUFpQkMsS0FBS0EsT0FBT0w7QUFDakksUUFBTThFLGFBQWFySyxjQUFjLEVBQUUySixTQUFTNUcsTUFBTSxXQUFXLENBQUM7QUFDOUQsUUFBTXVILGNBQWN0QixTQUFTbkIsV0FBV3FCLGNBQWNyQixVQUFVbUIsU0FBU3BDLEtBQUssQ0FBQ2pELElBQUk0RyxVQUFVNUcsT0FBT3VGLGNBQWNxQixLQUFLLENBQUM7QUFDeEgsUUFBTUMsU0FBUzdJLGtCQUFrQjtBQUFBLElBQzdCOEksVUFBVSxHQUFHakcsS0FBS2IsRUFBRSxZQUFZdUUsa0JBQWtCLEtBQUs7QUFBQSxJQUN2RHdDLFFBQVFuQyxRQUFRM0MsT0FBTytFLGdCQUFnQnBDLFFBQVEzQyxLQUFLQSxJQUFJLElBQUlMO0FBQUFBLElBQzVEcUYsT0FBTyxFQUFFLEdBQUdyQixZQUFZc0IsVUFBVSxHQUFHQyxjQUFjOUIsU0FBUztBQUFBLElBQzVEK0IsT0FBT0EsQ0FBQ0MsUUFBUUMsYUFBYTtBQUN6QnBCLFlBQU1vQixRQUFRO0FBQ2QsaUJBQVdoRixPQUFPLENBQUMsUUFBUSxlQUFlLGNBQWMsVUFBVSxVQUFVO0FBQ3hFLFlBQUksQ0FBQ3ZFLFdBQVdzSixPQUFPL0UsR0FBRyxHQUFHZ0YsU0FBU2hGLEdBQUcsQ0FBQyxFQUFHc0QsYUFBWTJCLFNBQVNqRixLQUFLK0UsT0FBTy9FLEdBQUcsR0FBRyxFQUFFa0YsYUFBYSxLQUFLLENBQUM7QUFDN0dsQyxrQkFBWStCLE9BQU9GLFlBQVk7QUFBRzNCLHVCQUFpQjhCLFNBQVNILFlBQVk7QUFBQSxJQUM1RTtBQUFBLElBQ0FNLFNBQVNBLE1BQU03QyxRQUFRbkIsUUFBUSxFQUFFaUUsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUN6RCxDQUFDO0FBQ0QsUUFBTUMsWUFBWXpKLGFBQWFtSSxXQUFXTSxlQUFlRSxPQUFPZSxLQUFLO0FBQ3JFLFFBQU1DLGlCQUFpQmxNLE9BQXdCLElBQUk7QUFDbkRELFlBQVUsTUFBTTtBQUFFLFFBQUksQ0FBQzJLLFdBQVcsQ0FBQ007QUFDL0I7QUFBUSxVQUFNbUIsVUFBVUEsQ0FBQ0MsTUFBeUI7QUFBRUEsUUFBRUMsZUFBZTtBQUFHRCxRQUFFRSxjQUFjO0FBQUEsSUFBSTtBQUFHM0csV0FBTzRHLGlCQUFpQixnQkFBZ0JKLE9BQU87QUFBRyxXQUFPLE1BQU14RyxPQUFPNkcsb0JBQW9CLGdCQUFnQkwsT0FBTztBQUFBLEVBQUcsR0FBRyxDQUFDekIsU0FBU00sV0FBVyxDQUFDO0FBQ2hQLFFBQU15QixPQUFPbkMsYUFBYSxPQUFPb0MsV0FBVztBQUN4QyxVQUFNQyxZQUFZLEVBQUUsR0FBRzFDLFlBQVlzQixVQUFVLEdBQUdDLGNBQWMsQ0FBQyxHQUFHOUIsUUFBUSxFQUFFO0FBQzVFLFVBQU1rRCxPQUFPO0FBQUEsTUFBRW5KLE1BQU1pSixPQUFPako7QUFBQUEsTUFBTU0sYUFBYTJJLE9BQU8zSTtBQUFBQSxNQUFhQyxZQUFZMEksT0FBTzFJLGNBQWM7QUFBQSxNQUFNQyxRQUFReUksT0FBT3pJO0FBQUFBLE1BQ3JIdUgsY0FBYzlCO0FBQUFBLE1BQVV2RixVQUFVdUksT0FBT3ZJLFNBQVNvRCxJQUFJLENBQUFjLE9BQU0sRUFBRWhFLElBQUlnRSxFQUFFaEUsSUFBSUksS0FBSzRELEVBQUU1RCxLQUFLaEIsTUFBTTRFLEVBQUU1RSxNQUFNYyxTQUFTOEQsRUFBRTlELFdBQVcsQ0FBQyxHQUFHRyxPQUFPLEVBQUVtSSxRQUFReEUsRUFBRTNELE9BQU9vSSxVQUFVNUgsS0FBSzRILFNBQVMsR0FBR2pJLFFBQVF3RCxFQUFFeEQsT0FBTyxFQUFFO0FBQUEsSUFBRTtBQUMxTSxRQUFJO0FBQ0EsVUFBSWtJO0FBQ0osVUFBSXBFLFdBQVc7QUFDWCxjQUFNcUUsV0FBVzlCLE9BQU8rQixRQUFRO0FBQUcsWUFBSSxDQUFDRCxZQUFZLENBQUNFLE9BQU9DLEtBQUtILFNBQVNJLEtBQUssRUFBRTdFLE9BQVE7QUFDekYsY0FBTTZFLFFBQVFGLE9BQU9HLFlBQVlILE9BQU9DLEtBQUtILFNBQVNJLEtBQUssRUFBRTdGLElBQUksQ0FBQVosUUFBTyxDQUFDQSxLQUFLaUcsS0FBS2pHLEdBQXdCLENBQUMsQ0FBQyxDQUFDO0FBQzlHb0csbUJBQVcsTUFBTXpELE9BQU9nRSxRQUFRLEVBQUVuSCxNQUFNLEVBQUV3QyxVQUFVLEdBQUc0RSxTQUFTUCxTQUFTTyxTQUFTWCxNQUFNUSxNQUFNLENBQUM7QUFBQSxNQUNuRyxNQUFPTCxZQUFXLE1BQU0xRCxPQUFPaUUsUUFBUSxFQUFFVixLQUFLLENBQUM7QUFDL0MsWUFBTVksUUFBUXRDLE9BQU91QyxVQUFVcEMsZ0JBQWdCMEIsU0FBU3pHLElBQUksR0FBR3FHLFNBQVM7QUFDeEU3RCwwQkFBb0JpRSxTQUFTekcsS0FBS2pDLEVBQUU7QUFDcEMsVUFBSW1KLE9BQU87QUFBRSxZQUFJdEIsZUFBZXdCLFFBQVNwTCxnQkFBZTRKLGVBQWV3QixPQUFPO0FBQUd2SSxpQkFBUyxNQUFNRCxLQUFLYixFQUFFLGFBQWEwSSxTQUFTekcsS0FBS2pDLEVBQUUsSUFBSSxFQUFFc0osU0FBUyxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDaEssU0FBU0MsT0FBTztBQUFFMUMsYUFBTzJDLE9BQU9ELEtBQUs7QUFBQSxJQUFHO0FBQUEsRUFDNUMsQ0FBQztBQUNELFFBQU1FLFVBQVV6RSxPQUFPeUUsV0FBV3hFLE9BQU93RSxXQUFXOUQsT0FBTzhEO0FBQzNELFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU9uRixZQUFZLHVCQUF1QixpQkFBaUIsVUFBUyw2REFBNEQsU0FBUyx1QkFBQyxVQUFPLFdBQVduSSxZQUFZLElBQUl1SSxVQUFVLHlCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBQTNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcU47QUFBQSxJQUFHSixhQUFhTSxRQUFROEUsWUFBWSx1QkFBQyxjQUFXLE9BQU85RSxTQUFVLGtCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDLElBQWdCTixhQUFhTSxRQUFRckIsVUFBVSx1QkFBQyxjQUFXLE9BQU9xQixTQUFVLGtCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDLElBQWdCLHVCQUFDLE9BQUksV0FBVSxRQUFPLEtBQUssQ0FBQStFLFNBQVE7QUFBRSxZQUFNQyxVQUFVRDtBQUFnQzlCLHFCQUFld0IsVUFBVU87QUFBU2pDLGdCQUFVaUMsT0FBTztBQUFBLElBQUcsR0FBRyxvQkFBa0IsQ0FBQ3ZELFdBQVcsQ0FBQ00sY0FBYyxTQUFTL0UsUUFBVyxVQUFVd0csTUFDam1CO0FBQUEsNkJBQUMsZUFBWSxPQUFPcEQsT0FBT3VFLFNBQVN0RSxPQUFPc0UsU0FBUzVELE9BQU80RCxTQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFBRSx1QkFBQyxpQkFBYyxRQUFnQixRQUFRLEVBQUVuSyxNQUFNLGdCQUFnQk0sYUFBYSxTQUFTQyxZQUFZLFlBQVlDLFFBQVEsY0FBY0UsVUFBVSxtQkFBbUJxSCxjQUFjLGVBQWUsR0FBRyxNQUFNc0MsV0FBdE07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4TTtBQUFBLE1BQUUsdUJBQUMsU0FBTSxPQUFNLHNCQUFxQixVQUFTLFNBQVEsaUNBQUMsY0FBWTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxnQkFBZSxHQUFJMUQsU0FBUyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUNLLE9BQU9oSCxNQUFNLFlBQVlnSCxPQUFPaEgsTUFBTXlLLFNBQVMsVUFBVSxDQUFDbEYsWUFBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSTtBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFNLDRCQUEyQixXQUFTLE1BQUMsU0FBUyxHQUFHLEdBQUlvQixTQUFTLGFBQWEsR0FBRyxVQUFVLENBQUNwQixZQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1IO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsTUFBSyxTQUFRLE9BQU94RCxnQkFBZ0IsVUFBVSxDQUFBd0IsVUFBU3ZCLGtCQUFrQnVCLE1BQU1DLE9BQU9uRCxLQUFLLEdBQUcsVUFBVSxDQUFDa0YsVUFBVSxZQUFXLDJEQUE5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFOO0FBQUEsUUFBRSx1QkFBQyxjQUFXLFdBQVcsRUFBRTdCLElBQUksVUFBVUMsSUFBSSxNQUFNLEdBQUcsWUFBWSxFQUFFRCxJQUFJLFdBQVdDLElBQUksUUFBUSxHQUFHO0FBQUEsaUNBQUMsY0FBVyxNQUFLLGNBQWEsU0FBa0IsUUFBUSxDQUFDLEVBQUUrRyxNQUFNLE1BQU0sdUJBQUMsY0FBVyxVQUFVLEVBQUM5RyxNQUFNLEdBQUdILFVBQVUsR0FBR2tILE9BQU8sT0FBTSxHQUFHO0FBQUEsbUNBQUMsYUFBVSxRQUFNLE1BQUMsV0FBUyxNQUFDLE9BQU0sWUFBVyxHQUFJRCxPQUFPLFVBQVUsQ0FBQ25GLFVBQVU7QUFBQSxxQ0FBQyxZQUFTLE9BQU0sSUFBRyw4QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUFZMkIsc0JBQXNCLENBQUNDLGtCQUFrQix1QkFBQyxZQUFTLE9BQU9ELG9CQUFxQkcsNEJBQWtCckgsU0FBUzRDLGlCQUFpQnVCLFVBQVUsc0JBQXNCK0Msa0JBQWtCLE1BQU0sa0NBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlLO0FBQUEsY0FBYTdFLFdBQVdRLE1BQU1BLEtBQUtpQixJQUFJLENBQUE4RyxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVoSyxJQUFLZ0ssWUFBRTVLLFFBQXRCNEssRUFBRWhLLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDLENBQVc7QUFBQSxpQkFBN2E7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK2E7QUFBQSxZQUFZLHVCQUFDLGtCQUFlLE9BQU0sWUFBVyxhQUFheUIsV0FBVzBCLGFBQWEsU0FBUzFCLFdBQVcyQixTQUFTLE1BQU0zQixXQUFXNEIsZUFBZSxZQUFZNUIsV0FBVzZCLFlBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1LO0FBQUEsWUFBRzdCLFdBQVdpSSxhQUFhLHVCQUFDLFNBQU0sVUFBUyxRQUFPLE1BQUssVUFBUyxrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUFVakksV0FBVzhCLFdBQVcsdUJBQUMsU0FBTSxVQUFVOUIsV0FBVytCLHVCQUF1QixZQUFZLFNBQVMsTUFBSyxTQUFRLFFBQVEsdUJBQUMsVUFBTyxPQUFNLFdBQVUsTUFBSyxTQUFRLFNBQVMsTUFBTTtBQUFFLG9CQUFNL0IsV0FBVytCLHVCQUF1Qi9CLFdBQVc2QixTQUFTLElBQUk3QixXQUFXZ0MsUUFBUTtBQUFBLFlBQUksR0FBRyxnQ0FBaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0ssR0FBWWhDLHFCQUFXK0IsdUJBQXVCLHNDQUFzQy9CLFdBQVc4SCxpQkFBaUJ6TCxXQUFXMkQsV0FBVzhILE1BQU0zSixTQUFTLEtBQUssMENBQTBDLGlDQUFpQzZCLFdBQVc4SCxpQkFBaUJ6TCxXQUFXMkQsV0FBVzhILE1BQU0zSixTQUFTLEtBQUssbUVBQXhpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3bUI7QUFBQSxZQUFVNkIsV0FBV1EsTUFBTUEsS0FBS2lDLFdBQVcsS0FBSyxDQUFDekMsV0FBV3dJLGNBQWMsdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFVcEYsMEJBQWdCLHFDQUFxQyxnQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxZQUFVN0MsaUJBQWlCMEgsYUFBYXBELHNCQUFzQixDQUFDQyxrQkFBa0IsdUJBQUMsU0FBTSxVQUFTLFFBQU8sTUFBSyxVQUFTLDBEQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQVV2RSxpQkFBaUJ1QixXQUFXK0Msc0JBQXNCLENBQUNDLGtCQUFrQix1QkFBQyxTQUFNLFVBQVMsV0FBVSxNQUFLLFNBQVEsUUFBUSx1QkFBQyxVQUFPLE9BQU0sV0FBVSxNQUFLLFNBQVEsU0FBUyxNQUFNO0FBQUUsbUJBQUt2RSxpQkFBaUJ5QixRQUFRO0FBQUEsWUFBRyxHQUFHLDBDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSCxHQUFZekIsMkJBQWlCdUgsaUJBQWlCekwsWUFBWWtFLGlCQUFpQnVILE1BQU0zSixXQUFXLE1BQU0sd0ZBQXdGLHFDQUFxQ29DLGlCQUFpQnVILGlCQUFpQnpMLFdBQVdrRSxpQkFBaUJ1SCxNQUFNM0osU0FBUyxLQUFLLGdEQUFwZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpZ0I7QUFBQSxlQUF2eUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ3pFLEtBQXYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxNEU7QUFBQSxVQUFFLHVCQUFDLGNBQVcsTUFBSyxVQUFTLFNBQWtCLFFBQVEsQ0FBQyxFQUFFa0ssTUFBTSxNQUFNLHVCQUFDLGFBQVUsUUFBTSxNQUFDLFdBQVMsTUFBQyxPQUFNLGNBQWEsR0FBSUEsT0FBTyxVQUFVLENBQUNuRixVQUFVLElBQUksRUFBRTNCLE1BQU0sR0FBR0gsVUFBVSxFQUFFLEdBQUc7QUFBQSxtQ0FBQyxZQUFTLE9BQU0sU0FBUSx3QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUFXLHVCQUFDLFlBQVMsT0FBTSxVQUFTLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLGVBQXpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9NLEtBQXZRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9SO0FBQUEsYUFBM3ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNnZGO0FBQUEsV0FBMXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdXVHLEtBQTF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXV5RztBQUFBLE1BQzFqSCx1QkFBQyxTQUFNLE9BQU0sbUJBQWtCLFVBQVMsU0FBUSxXQUFXLFdBQVcsUUFBUSx1QkFBQyxVQUFPLFdBQVcsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEdBQUssVUFBVSxDQUFDOEIsVUFBVSxTQUFTLE1BQU0rQixXQUFXd0QsT0FBTyxFQUFFOUosS0FBSyxJQUFJaEIsTUFBTSxJQUFJaUIsT0FBTyxJQUFJRyxRQUFRLEtBQUssQ0FBQyxHQUFHLDZCQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVKLEdBQVcsaUNBQUMsY0FBYWtHLHFCQUFXMkIsT0FBT25GLElBQUksQ0FBQzRHLE9BQU9sRCxVQUFVLHVCQUFDLGNBQTBCLFdBQVcsRUFBRTlELElBQUksVUFBVXFILElBQUksTUFBTSxHQUFJLFlBQVksRUFBRXJILElBQUksV0FBV3FILElBQUksUUFBUSxHQUFHLFVBQVMsUUFBTztBQUFBLCtCQUFDLGFBQVUsT0FBTSxPQUFNLEdBQUlwRSxTQUFTLFlBQVlhLEtBQUssTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDUixPQUFPdEcsV0FBVzhHLEtBQUssR0FBR3hHLEtBQUssWUFBWWdHLE9BQU90RyxXQUFXOEcsS0FBSyxHQUFHeEcsS0FBS3lKLFNBQVMsVUFBVSxDQUFDbEYsVUFBVSxJQUFJLEVBQUVvRixPQUFPLEVBQUVqSCxJQUFJLFFBQVFxSCxJQUFJLE9BQU8sR0FBR3RILFVBQVUsbUJBQW1CdUgsVUFBVSxRQUFRcEgsTUFBTSxFQUFFRixJQUFJLFlBQVlxSCxJQUFJLFdBQVcsRUFBRSxLQUFoVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtUO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sdUJBQXNCLEdBQUlwRSxTQUFTLFlBQVlhLEtBQUssT0FBTyxHQUFHLFVBQVUsQ0FBQ2pDLFVBQVUsSUFBSSxFQUFFb0YsT0FBTyxFQUFFakgsSUFBSSxRQUFRcUgsSUFBSSxPQUFPLEdBQUd0SCxVQUFVLG1CQUFtQnVILFVBQVUsUUFBUXBILE1BQU0sRUFBRUYsSUFBSSxZQUFZcUgsSUFBSSxXQUFXLEVBQUUsS0FBck87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TztBQUFBLFFBQUUsdUJBQUMsYUFBVSxPQUFPLFlBQVl0SixLQUFLNEgsUUFBUSxLQUFLLFlBQVksRUFBRTRCLFdBQVcsVUFBVSxHQUFHLEdBQUl0RSxTQUFTLFlBQVlhLEtBQUssUUFBUSxHQUFHLE9BQU8sQ0FBQyxDQUFDUixPQUFPdEcsV0FBVzhHLEtBQUssR0FBR3ZHLE9BQU8sWUFBWStGLE9BQU90RyxXQUFXOEcsS0FBSyxHQUFHdkcsT0FBT3dKLFNBQVMsVUFBVSxDQUFDbEYsVUFBVSxJQUFJLEVBQUVvRixPQUFPLEVBQUVqSCxJQUFJLFFBQVFxSCxJQUFJLE9BQU8sR0FBR3RILFVBQVUsbUJBQW1CdUgsVUFBVSxRQUFRcEgsTUFBTSxFQUFFRixJQUFJLFlBQVlxSCxJQUFJLFdBQVcsRUFBRSxLQUFyWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVYO0FBQUEsUUFBRSx1QkFBQyxvQkFBaUIsT0FBTSxZQUFXLFNBQVMsdUJBQUMsWUFBUyxnQkFBZ0JMLE1BQU10SixRQUFRLEdBQUl1RixTQUFTLFlBQVlhLEtBQUssU0FBUyxHQUFHLFVBQVUsQ0FBQ2pDLFlBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0csS0FBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxSjtBQUFBLFFBQUUsdUJBQUMsY0FBVyxjQUFZLGdCQUFnQmlDLFFBQVEsQ0FBQyxJQUFJLFVBQVUsQ0FBQ2pDLFlBQVkrQixXQUFXMkIsT0FBT25FLFdBQVcsR0FBRyxTQUFTLE1BQU13QyxXQUFXNEQsT0FBTzFELEtBQUssR0FBRyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCLEtBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNks7QUFBQSxXQUF6MENrRCxNQUFNOUosSUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1MkMsQ0FBYSxLQUExNkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0NkMsS0FBNXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeXFEO0FBQUEsTUFDenFELHVCQUFDLFNBQU0sT0FBTSxnQkFBZSxVQUFTLDBFQUF5RSxVQUFTLFNBQVEsV0FBVyxXQUFXLGlDQUFDLGNBQVk7QUFBQSwrQkFBQyxjQUFXLFNBQVEsU0FBU3FGO0FBQUFBLG1CQUFTbkI7QUFBQUEsVUFBTztBQUFBLGFBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUFhLHVCQUFDLFVBQU8sV0FBVSxTQUFRLFNBQVEsWUFBVyxVQUFVLENBQUNTLFlBQVk4RSxTQUFTO0FBQUE7QUFBQSxVQUFRLHVCQUFDLFdBQU0sUUFBTSxNQUFDLE1BQUssUUFBTyxRQUFPLG1DQUFrQyxVQUFVLE9BQU8xQixNQUFNO0FBQUUsa0JBQU13QyxRQUFReEMsRUFBRXlDO0FBQWUsa0JBQU1DLE9BQU9GLE1BQU1HLFFBQVEsQ0FBQyxLQUFLO0FBQU0sa0JBQU1uQixRQUFRMUwsc0JBQXNCNE0sTUFBTUUsV0FBVy9NLDBCQUEwQmdFLE1BQVM7QUFBRzhELDBCQUFjNkQsS0FBSztBQUFHLGdCQUFJQSxPQUFPO0FBQUVnQixvQkFBTTlLLFFBQVE7QUFBSTtBQUFBLFlBQVE7QUFBRSxnQkFBSSxDQUFDZ0wsS0FBTTtBQUFRLGtCQUFNZCxPQUFPLElBQUlpQixTQUFTO0FBQUdqQixpQkFBS08sT0FBTyxRQUFRTyxJQUFJO0FBQUdkLGlCQUFLTyxPQUFPLFdBQVcsZUFBZTtBQUFHLGdCQUFJO0FBQ3B2QixvQkFBTVcsSUFBSSxNQUFNbEYsT0FBT3NELFFBQVEsRUFBRVUsS0FBSyxDQUFDO0FBQ3ZDLGtCQUFJa0IsRUFBRTVJLEtBQUtyQyxXQUFXO0FBQ2xCMEYsNEJBQVksQ0FBQXdGLFFBQU8sQ0FBQyxHQUFHQSxLQUFLRCxFQUFFNUksS0FBS2pDLEVBQUUsQ0FBQztBQUFBO0FBRXRDK0ssc0JBQU0sd0RBQXdEO0FBQUEsWUFDdEUsUUFDTTtBQUFBLFlBQUU7QUFBc0JSLGtCQUFNOUssUUFBUTtBQUFBLFVBQUksS0FQb1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPbFI7QUFBQSxhQVA2TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTzNMO0FBQUEsUUFBVWdHLGNBQWMsdUJBQUMsU0FBTSxVQUFTLFNBQVEsTUFBSyxTQUFTQSx3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQVVKLFNBQVNuQyxJQUFJLENBQUE4SCxXQUFVLHVCQUFDLGVBQXlCLFdBQVUsT0FBTztBQUFBLGlDQUFDLGNBQVcsU0FBUSxXQUFXQSxvQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUFhLHVCQUFDLFVBQU8sTUFBSyxTQUFRLFVBQVUsQ0FBQ3JHLFVBQVUsU0FBUyxNQUFNVyxZQUFZLENBQUF3RixRQUFPQSxJQUFJRyxPQUFPLENBQUFDLE1BQUtBLE1BQU1GLE1BQU0sQ0FBQyxHQUFHLCtCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySDtBQUFBLGFBQXZNQSxRQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtPLENBQWM7QUFBQSxXQVBoUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT2tRLEtBUHZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPb2E7QUFBQSxNQUNwYSx1QkFBQyxlQUFZLFdBQVUsT0FBTSxXQUFVLFFBQU8sZ0JBQWdCLGlCQUFtQjFHO0FBQUFBLHFCQUFhTSxRQUFRM0MsTUFBTUEsS0FBS3JDLFdBQVcsYUFBYSx1QkFBQyxrQkFBZSxZQUFXLGlCQUFnQixPQUFNLFNBQVEsU0FBUyxNQUFNd0YsV0FBVyxJQUFJLEdBQUcseUJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUcsSUFBb0IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUFJLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLE1BQUssVUFBUyxTQUFRLGFBQVksTUFBTXFFLFNBQVMsNEJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxXQUFqWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtZO0FBQUEsU0FYTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV1E7QUFBQSxJQUNoWix1QkFBQyxpQkFBYyxNQUFNdEUsU0FBUyxPQUFNLHNCQUFxQixjQUFhLHNCQUFxQixhQUFhLFlBQVlQLFFBQVEzQyxNQUFNQSxLQUFLN0MsUUFBUSxFQUFFLEtBQUtrRixhQUFhLEVBQUUsd0VBQXdFLGVBQWEsTUFBQyxTQUFTLE1BQU1jLFdBQVcsS0FBSyxHQUFHLE1BQU1GLFFBQVF1RSxTQUFTLE9BQU92RSxRQUFRcUUsT0FBTyxXQUFXLE9BQU00QixXQUFVO0FBQzlWLFlBQU05QixVQUFVekUsUUFBUTNDLE1BQU1BO0FBQzlCLFVBQUksQ0FBQ3FDLGFBQWEsQ0FBQytFLFFBQVM7QUFDNUIsWUFBTW5FLFFBQVErRCxRQUFRLEVBQUVuSCxNQUFNLEVBQUV3QyxVQUFVLEdBQUc0RSxTQUFTRyxRQUFRSCxTQUFTWCxNQUFNLEVBQUU2QyxpQkFBaUIvQixRQUFRSCxTQUFTaUMsT0FBTyxFQUFFLENBQUM7QUFBQSxJQUMvSCxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJSztBQUFBLE9BaEJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkg7QUFDUjtBQUFDOUcsSUFuRmVELG1CQUFpQjtBQUFBLFVBQ1NwSSxXQUdyQnlCLFVBQ0ZwQyxlQUNFVSxhQUNBMkIsUUFDREosUUFPR0UsYUFDSkQsWUFDQUEsWUFDQ0EsWUFLREEsWUFDS25CLFNBRXBCRyxVQUMyQkEsVUFFRmUsUUFFTmpCLGVBRUoyQixtQkFZR0UsWUFBWTtBQUFBO0FBQUEsTUE3Q2xCa0c7QUFvRlQsZ0JBQVNpSCxpQkFBaUI7QUFBQUMsTUFBQTtBQUM3QixRQUFNbEosT0FBTzlFLE9BQU8sa0JBQWtCLEVBQUVvRSxPQUFPL0QsYUFBYSxnQkFBZ0IsRUFBRSxDQUFDO0FBQy9FLFFBQU1xSCxTQUFTekgsV0FBVyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM5RCxRQUFNMEgsU0FBUzFILFdBQVcsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUM7QUFDOUQsUUFBTTJILFVBQVUzSCxXQUFXLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDO0FBQ2hFLFFBQU0sQ0FBQ2dPLE1BQU1DLE9BQU8sSUFBSTVQLFNBQXNDO0FBQzlELFFBQU0sQ0FBQ3dELE1BQU1xTSxPQUFPLElBQUk3UCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDOFAsVUFBVUMsV0FBVyxJQUFJL1AsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzBPLFFBQVFzQixTQUFTLElBQUloUSxTQUEwQixJQUFJLEdBQUcsQ0FBQ2lRLGNBQWNDLGVBQWUsSUFBSWxRLFNBQVMsRUFBRTtBQUMxRyxRQUFNbVEsaUJBQWlCek8sT0FBTyxlQUFlLEVBQUV3RSxNQUFNLEVBQUVuQyxZQUFZNEwsTUFBTXZMLE1BQU0sR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDdUwsTUFBTXZMLEVBQUU7QUFDakcsUUFBTWdNLG1CQUFtQnhGLFFBQVErRSxNQUFNdkwsTUFBTStMLGVBQWU5SixNQUFNQSxLQUFLakMsT0FBT3VMLEtBQUt2TCxFQUFFO0FBQ3JGLFFBQU1pTSxTQUFTVixNQUFNdkwsTUFBTStMLGVBQWU5SixNQUFNQSxLQUFLakMsT0FBT3VMLEtBQUt2TCxLQUFLK0wsZUFBZTlKLEtBQUtBLE9BQU9zSjtBQUNqRyxRQUFNVyxpQkFBaUJsTyxrQkFBa0I7QUFBQSxJQUNyQzhJLFVBQVUsR0FBR3JKLFNBQVMsRUFBRW9ELEtBQUtiLEVBQUUsYUFBYXVMLE1BQU12TCxNQUFNLEtBQUs7QUFBQSxJQUM3RCtHLFFBQVFrRixTQUFTLEVBQUUvQyxTQUFTK0MsT0FBTy9DLFNBQVM3QixRQUFRLEVBQUVqSSxNQUFNNk0sT0FBTzdNLE1BQU1zTSxVQUFVTyxPQUFPUCxZQUFZLEdBQUcsRUFBRSxJQUFJOUo7QUFBQUEsSUFDL0dxRixPQUFPLEVBQUU3SCxNQUFNc00sU0FBUztBQUFBLElBQUd0RSxPQUFPQSxDQUFBQyxXQUFVO0FBQUVvRSxjQUFRcEUsT0FBT2pJLElBQUk7QUFBR3VNLGtCQUFZdEUsT0FBT3FFLFFBQVE7QUFBQSxJQUFHO0FBQUEsSUFDbEdqRSxTQUFTQSxNQUFNc0UsZUFBZXRJLFFBQVEsRUFBRWlFLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDaEUsQ0FBQztBQUNELFFBQU15RSxPQUFPQSxDQUFDbkMsTUFBdUI7QUFBRThCLG9CQUFnQixFQUFFO0FBQUdMLFlBQVF6QixHQUFHNUssUUFBUSxFQUFFO0FBQUd1TSxnQkFBWTNCLEdBQUcwQixZQUFZLEVBQUU7QUFBR0YsWUFBUXhCLENBQUM7QUFBQSxFQUFHO0FBQ2hJLFNBQU8sbUNBQUU7QUFBQSwyQkFBQyxjQUFXLE9BQU0sWUFBVyxVQUFTLDZDQUE0QyxTQUFTLHVCQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVEsYUFBWSxTQUFTLE1BQU1tQyxLQUFLLElBQUksR0FBRyw2QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RyxLQUFsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9OO0FBQUEsSUFBR04sZ0JBQWdCLHVCQUFDLFNBQU0sVUFBUyxXQUFVLE1BQUssVUFBUyxJQUFJL1AsU0FBU3NRLE9BQU9DLFVBQVdSLDBCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9GO0FBQUEsSUFBUyx1QkFBQyxTQUFNO0FBQUEsNkJBQUMsV0FBUSxXQUFVLG9CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsTUFBRyx1QkFBQyxjQUFXLE9BQU96SixNQUFNLGdCQUFlLFdBQVdBLGVBQUtILFFBQVEsbUNBQUU7QUFBQSwrQkFBQyxhQUFVLE9BQU0sc0JBQXFCLE1BQU1HLEtBQUtILEtBQUtBLE1BQU0sUUFBUSxDQUFBK0gsTUFBS0EsRUFBRWhLLElBQUksU0FBUztBQUFBLFVBQ2hoQixFQUFFc0MsS0FBSyxRQUFRcUIsT0FBTyxnQkFBZ0JDLFFBQVFBLENBQUFvRyxNQUFLQSxFQUFFNUssS0FBSztBQUFBLFVBQUcsRUFBRWtELEtBQUssVUFBVXFCLE9BQU8sZ0JBQWdCQyxRQUFRQSxDQUFBb0csTUFBSzVILEtBQUtILE1BQU1BLEtBQUtDLEtBQUssQ0FBQXdCLE1BQUtBLEVBQUUxRCxPQUFPZ0ssRUFBRTBCLFFBQVEsR0FBR3RNLFFBQVEsSUFBSTtBQUFBLFVBQUcsRUFBRWtELEtBQUssU0FBU3FCLE9BQU8sY0FBY0MsUUFBUUEsQ0FBQW9HLE1BQUssdUJBQUMsVUFBTyxPQUFPQSxFQUFFeEosU0FBUyxXQUFXLGNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdELEVBQUc7QUFBQSxVQUN0UjtBQUFBLFlBQ0k4QixLQUFLO0FBQUEsWUFBVXFCLE9BQU87QUFBQSxZQUFJQyxRQUFRQSxDQUFBb0csTUFBSyx1QkFBQyxTQUFNLFdBQVUsT0FBTTtBQUFBLHFDQUFDLGtCQUFlLFlBQVcsaUJBQWdCLFNBQVMsTUFBTW1DLEtBQUtuQyxDQUFDLEdBQUcsbUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FBaUIsdUJBQUMsa0JBQWUsWUFBVyxpQkFBZ0IsT0FBTSxTQUFRLFNBQVMsTUFBTTRCLFVBQVU1QixDQUFDLEdBQUcsMEJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdHO0FBQUEsaUJBQTlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStOO0FBQUEsVUFDMVE7QUFBQSxRQUFDLEtBSnViO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLMWI7QUFBQSxRQUFFLHVCQUFDLFNBQU0sTUFBTTVILEtBQUtILEtBQUtrQyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FMMFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUt4WixLQUx3VjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS3BWO0FBQUEsU0FMdVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUsxUjtBQUFBLElBQ3RELHVCQUFDLGNBQVcscUJBQW1CLE1BQUMsTUFBTW9ILFNBQVMzSixRQUFXLE9BQU8ySixPQUFPLGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNQyxRQUFRNUosTUFBUyxHQUFHLE1BQU1vRCxPQUFPeUUsV0FBV3hFLE9BQU93RSxXQUFXdUMsa0JBQWtCLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDNU0sS0FBS0UsS0FBSyxLQUFLMEYsT0FBT3lFLFdBQVd4RSxPQUFPd0UsV0FBV3VDLGtCQUFrQixTQUFTLFlBQVk7QUFBRSxVQUFJO0FBQ2xWLGNBQU0xRCxZQUFZLEVBQUVsSixNQUFNc00sU0FBUztBQUNuQyxjQUFNbkQsT0FBTyxFQUFFbkosTUFBTUEsS0FBS0UsS0FBSyxHQUFHb00sVUFBVUEsWUFBWSxLQUFLO0FBQzdELFlBQUlZO0FBQ0osWUFBSWYsTUFBTTtBQUNOLGdCQUFNNUMsV0FBV3VELGVBQWV0RCxRQUFRO0FBQUcsY0FBSSxDQUFDRCxZQUFZLENBQUNFLE9BQU9DLEtBQUtILFNBQVNJLEtBQUssRUFBRTdFLE9BQVE7QUFDakdvSSxtQkFBUyxNQUFNckgsT0FBT2dFLFFBQVEsRUFBRW5ILE1BQU0sRUFBRW5DLFlBQVk0TCxLQUFLdkwsR0FBRyxHQUFHa0osU0FBU1AsU0FBU08sU0FBU1gsTUFBTTtBQUFBLFlBQzVGLEdBQUlJLFNBQVNJLE1BQU0zSixTQUFTd0MsU0FBWSxFQUFFeEMsTUFBTW1KLEtBQUtuSixLQUFLLElBQUksQ0FBQztBQUFBLFlBQy9ELEdBQUl1SixTQUFTSSxNQUFNMkMsYUFBYTlKLFNBQVksRUFBRThKLFVBQVVuRCxLQUFLbUQsU0FBUyxJQUFJLENBQUM7QUFBQSxVQUMvRSxFQUFFLENBQUM7QUFBQSxRQUNQLE1BQU9ZLFVBQVMsTUFBTXRILE9BQU9pRSxRQUFRLEVBQUVWLEtBQUssQ0FBQztBQUM3QyxjQUFNWSxRQUFRK0MsZUFBZTlDLFVBQVUsRUFBRUYsU0FBU29ELE9BQU9ySyxLQUFLaUgsU0FBUzdCLFFBQVEsRUFBRWpJLE1BQU1rTixPQUFPckssS0FBSzdDLE1BQU1zTSxVQUFVWSxPQUFPckssS0FBS3lKLFlBQVksR0FBRyxFQUFFLEdBQUdwRCxXQUFXLEdBQUdnRSxPQUFPckssS0FBS3NLLE1BQU0sYUFBYUQsT0FBT3JLLEtBQUtqQyxFQUFFLEVBQUU7QUFDaE44TCx3QkFBZ0IzQyxRQUFRLG9CQUFvQm1ELE9BQU9ySyxLQUFLN0MsSUFBSSxPQUFPLG9CQUFvQmtOLE9BQU9ySyxLQUFLN0MsSUFBSSxvQ0FBb0M7QUFDM0lvTSxnQkFBUXJDLFFBQVF2SCxTQUFZMEssT0FBT3JLLElBQUk7QUFBQSxNQUMzQyxTQUNPc0gsT0FBTztBQUFFMkMsdUJBQWUxQyxPQUFPRCxLQUFLO0FBQUEsTUFBRztBQUFBLElBQUUsR0FBRyxtQkFmNEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWV6SixHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPdkUsT0FBT3VFLFNBQVN0RSxPQUFPc0UsU0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQUUsdUJBQUMsaUJBQWMsUUFBUTJDLGdCQUFnQixRQUFRLEVBQUU5TSxNQUFNLGdCQUFnQnNNLFVBQVUsZUFBZSxHQUFHLE1BQU0xRyxPQUFPeUUsV0FBV3hFLE9BQU93RSxXQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBJO0FBQUEsTUFBRzhCLE1BQU12TCxNQUFNZ00sb0JBQW9CLHVCQUFDLFNBQU0sVUFBVUQsZUFBZXhDLFFBQVEsVUFBVSxRQUFRLFFBQVF3QyxlQUFleEMsUUFBUSx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU0sS0FBS3dDLGVBQWV0SSxRQUFRLEdBQUcsdUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEUsSUFBWTdCLFFBQVltSyx5QkFBZXhDLFFBQVEsOEVBQThFLDhEQUFoUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJWO0FBQUEsTUFBUyx1QkFBQyxjQUFXLFNBQVEsV0FBVTtBQUFBLCtCQUFDLGFBQVUsT0FBTSxPQUFNLE9BQU9uSyxNQUFNLFVBQVUsQ0FBQTJJLE1BQUswRCxRQUFRMUQsRUFBRW5GLE9BQU9uRCxLQUFLLEdBQUcsVUFBVXVNLG9CQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsUUFBRSx1QkFBQyxhQUFVLE9BQU0sZ0JBQWUsUUFBTSxNQUFDLE9BQU9OLFVBQVUsVUFBVSxDQUFBM0QsTUFBSzRELFlBQVk1RCxFQUFFbkYsT0FBT25ELEtBQUssR0FBRyxVQUFVdU0sa0JBQWtCO0FBQUEsaUNBQUMsWUFBUyxPQUFNLElBQUcsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFBWTVKLEtBQUtILE1BQU1BLEtBQUtnSixPQUFPLENBQUFqQixNQUFLQSxFQUFFaEssT0FBT3VMLE1BQU12TCxFQUFFLEVBQUVrRCxJQUFJLENBQUE4RyxNQUFLLHVCQUFDLFlBQW9CLE9BQU9BLEVBQUVoSyxJQUFLZ0ssWUFBRTVLLFFBQXRCNEssRUFBRWhLLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDLENBQVc7QUFBQSxhQUFwUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNSO0FBQUEsV0FBN1o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5YTtBQUFBLFNBZmpqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZThqQztBQUFBLElBQzlqQyx1QkFBQyxpQkFBYyxNQUFNLENBQUMsQ0FBQ3NLLFFBQVEsT0FBTSx1QkFBc0IsY0FBYSx1QkFBc0IsYUFBYSxZQUFZQSxRQUFRbEwsUUFBUSxFQUFFLEtBQUtrTCxRQUFRdEssTUFBTSxFQUFFLHNFQUFzRSxlQUFhLE1BQUMsU0FBUyxNQUFNNEwsVUFBVSxJQUFJLEdBQUcsT0FBTzFHLFFBQVFxRSxPQUFPLE1BQU1yRSxRQUFRdUUsU0FBUyxXQUFXLENBQUEwQixXQUFVakcsUUFBUStELFFBQVEsRUFBRW5ILE1BQU0sRUFBRW5DLFlBQVkySyxRQUFRdEssTUFBTSxHQUFHLEdBQUdrSixTQUFTb0IsUUFBUXBCLFNBQVNYLE1BQU0sRUFBRTZDLGlCQUFpQmQsUUFBUXBCLFdBQVcsR0FBR2lDLE9BQU8sRUFBRSxDQUFDLEtBQWplO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbWU7QUFBQSxPQXRCemQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCMmQ7QUFDdGU7QUFBQ0csSUExQ2VELGdCQUFjO0FBQUEsVUFDYi9OLFFBQWtDSyxjQUNoQ0osWUFDQUEsWUFDQ0EsWUFLT0QsUUFHQVUsbUJBQ05QLFFBQVE7QUFBQTtBQUFBLE1BYmI0TjtBQTRDaEIsU0FBU21CLGFBQWFDLHdCQUF3QjtBQUU5QyxTQUFTekYsZ0JBQWdCcEMsU0FBa0I7QUFDdkMsUUFBTXlDLFNBQXFEO0FBQUEsSUFDdkRqSSxNQUFNd0YsUUFBUXhGO0FBQUFBLElBQU1NLGFBQWFrRixRQUFRbEY7QUFBQUEsSUFBYUMsWUFBWWlGLFFBQVFqRixjQUFjO0FBQUEsSUFBSUMsUUFBUWdGLFFBQVFoRixXQUFXLFdBQVcsV0FBVztBQUFBLElBQzdJRSxVQUFVOEUsUUFBUTlFLFNBQVNvRCxJQUFJLENBQUFjLE9BQU0sRUFBRWhFLElBQUlnRSxFQUFFaEUsSUFBSUksS0FBSzRELEVBQUU1RCxLQUFLaEIsTUFBTTRFLEVBQUU1RSxNQUFNYyxTQUFTOEQsRUFBRTlELFNBQVNHLE9BQU8yRCxFQUFFM0QsT0FBT21JLFVBQVUsSUFBSWhJLFFBQVF3RCxFQUFFeEQsT0FBTyxFQUFFO0FBQUEsSUFBRzJHLGNBQWN2QyxRQUFRdUM7QUFBQUEsRUFDN0s7QUFDQSxTQUFPLEVBQUUrQixTQUFTdEUsUUFBUXNFLFNBQVM3QixPQUFPO0FBQzlDO0FBQUMsSUFBQXFGLElBQUFDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlTGlzdFJldHVybiIsImNvZGVQb2ludExlbmd0aCIsIkFjdGlvbkdyb3VwIiwiRmllbGRHcm91cCIsIkZvcm1GaWVsZHMiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInZpc3VhbFN4IiwibGF5b3V0U3giLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsIkxpbmsiLCJSb3V0ZXJMaW5rIiwidXNlRm9ybSIsInVzZUZpZWxkQXJyYXkiLCJDb250cm9sbGVyIiwidXNlV2F0Y2giLCJ6b2RSZXNvbHZlciIsInoiLCJBbGVydCIsIkJveCIsIkJ1dHRvbiIsIkNoZWNrYm94IiwiRm9ybUNvbnRyb2xMYWJlbCIsIkljb25CdXR0b24iLCJNZW51SXRlbSIsIlN0YWNrIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsIkFkZFJvdW5kZWQiLCJEZWxldGVPdXRsaW5lUm91bmRlZCIsInVzZUFwaSIsInVzZUNvbW1hbmQiLCJ1c2VQYWdlZEFwaSIsInVzZVNjb3BlIiwidXNlQ2FuIiwidXNlTGlzdFF1ZXJ5IiwiUFJPRFVDVF9JTUFHRV9NQVhfQllURVMiLCJwcm9kdWN0SW1hZ2VGaWxlRXJyb3IiLCJBcGlFcnJvciIsImRyYWZ0RXF1YWwiLCJ1c2VWZXJzaW9uZWREcmFmdCIsIm1hcmtEcmFmdENsZWFuIiwidXNlRHJhZnRGb3JtIiwiRHJhZnRDb25mbGljdCIsIlBhZ2VIZWFkZXIiLCJQYW5lbCIsIkRhdGFUYWJsZSIsIlN0YXR1cyIsIkFtb3VudCIsIlF1ZXJ5U3RhdGUiLCJUb29sYmFyIiwiUGFnZXIiLCJNdXRhdGlvbkJ1dHRvbiIsIkVkaXREaWFsb2ciLCJFcnJvck5vdGljZSIsIkNvbmZpcm1EaWFsb2ciLCJSb3V0ZUxpbmsiLCJMb29rdXBMb2FkTW9yZSIsInByb2R1Y3RTY2hlbWEiLCJvYmplY3QiLCJuYW1lIiwic3RyaW5nIiwidHJpbSIsIm1pbiIsInJlZmluZSIsInZhbHVlIiwiZGVzY3JpcHRpb24iLCJjYXRlZ29yeUlkIiwic3RhdHVzIiwiZW51bSIsInZhcmlhbnRzIiwiYXJyYXkiLCJpZCIsIm9wdGlvbmFsIiwib3B0aW9ucyIsInJlY29yZCIsInNrdSIsInByaWNlIiwicmVnZXgiLCJOdW1iZXIiLCJhY3RpdmUiLCJib29sZWFuIiwiZGVmYXVsdHMiLCJQcm9kdWN0c1BhZ2UiLCJfcyIsInNob3AiLCJuYXZpZ2F0ZSIsInBhcmFtcyIsInNldFBhcmFtcyIsImNhdGVnb3J5U2VhcmNoSW5wdXQiLCJzZXRDYXRlZ29yeVNlYXJjaElucHV0IiwiY2F0ZWdvcnlTZWFyY2giLCJzZXRDYXRlZ29yeVNlYXJjaCIsInRpbWVyIiwid2luZG93Iiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsImNhdGVnb3JpZXMiLCJxdWVyeSIsInEiLCJ1bmRlZmluZWQiLCJzZWxlY3RlZENhdGVnb3J5RGV0YWlsIiwicGF0aCIsImdldCIsInNlbGVjdGVkQ2F0ZWdvcnkiLCJkYXRhIiwiZmluZCIsImNhdGVnb3J5IiwibGlzdCIsInNldEZpbHRlciIsImtleSIsIm5leHQiLCJVUkxTZWFyY2hQYXJhbXMiLCJzZXQiLCJkZWxldGUiLCJldmVudCIsInRhcmdldCIsIm1pbldpZHRoIiwieHMiLCJzbSIsImZsZXgiLCJzb21lIiwibWFwIiwibG9hZGVkQ291bnQiLCJoYXNNb3JlIiwiaXNMb2FkaW5nTW9yZSIsImxvYWRNb3JlIiwiaXNFcnJvciIsImlzRmV0Y2hOZXh0UGFnZUVycm9yIiwicmVmZXRjaCIsInAiLCJsYWJlbCIsInJlbmRlciIsInR5cG9ncmFwaHkiLCJmb250V2VpZ2h0Iiwic3Ryb25nIiwidiIsImpvaW4iLCJsZW5ndGgiLCJwYWdlIiwiUHJvZHVjdEVkaXRvclBhZ2UiLCJfczIiLCJwcm9kdWN0SWQiLCJyb3V0ZVByb2R1Y3RJZCIsImNyZWF0ZWRQcm9kdWN0SWQiLCJzZXRDcmVhdGVkUHJvZHVjdElkIiwibGlzdEhyZWYiLCJjYW5Xcml0ZSIsInByb2R1Y3QiLCJjYXRlZ29yeVF1ZXJ5Iiwic2V0Q2F0ZWdvcnlRdWVyeSIsImxpbWl0IiwiY3JlYXRlIiwidXBkYXRlIiwiYXJjaGl2ZSIsImNvbmZpcm0iLCJzZXRDb25maXJtIiwiaW1hZ2VJZHMiLCJzZXRJbWFnZUlkcyIsInNhdmVkSW1hZ2VJZHMiLCJzZXRTYXZlZEltYWdlSWRzIiwiaW1hZ2VFcnJvciIsInNldEltYWdlRXJyb3IiLCJ1cGxvYWQiLCJwcm9kdWN0Rm9ybSIsImRlZmF1bHRWYWx1ZXMiLCJyZXNvbHZlciIsInJlZ2lzdGVyIiwiY29udHJvbCIsImhhbmRsZVN1Ym1pdCIsInJlc2V0IiwiZm9ybVN0YXRlIiwiZXJyb3JzIiwiaXNEaXJ0eSIsInNlbGVjdGVkQ2F0ZWdvcnlJZCIsImNhdGVnb3J5T25QYWdlIiwiQm9vbGVhbiIsInJldGFpbmVkQ2F0ZWdvcnkiLCJmaWVsZEFycmF5IiwiaW1hZ2VzRGlydHkiLCJpbmRleCIsImVkaXRvciIsImlkZW50aXR5Iiwic291cmNlIiwicHJvZHVjdFNuYXBzaG90IiwiZHJhZnQiLCJnZXRWYWx1ZXMiLCJpbWFnZUZpbGVJZHMiLCJhcHBseSIsInZhbHVlcyIsImJhc2VsaW5lIiwic2V0VmFsdWUiLCJzaG91bGREaXJ0eSIsInJlZnJlc2giLCJ0aHJvd09uRXJyb3IiLCJkcmFmdEZvcm0iLCJkaXJ0eSIsInByb2R1Y3RFbGVtZW50IiwicHJldmVudCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInJldHVyblZhbHVlIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJzYXZlIiwiZmllbGRzIiwic3VibWl0dGVkIiwiYm9keSIsImFtb3VudCIsImN1cnJlbmN5IiwicmVzcG9uc2UiLCJwcmVwYXJlZCIsInByZXBhcmUiLCJPYmplY3QiLCJrZXlzIiwicGF0Y2giLCJmcm9tRW50cmllcyIsImV4ZWN1dGUiLCJ2ZXJzaW9uIiwiY2xlYW4iLCJjb21taXR0ZWQiLCJjdXJyZW50IiwicmVwbGFjZSIsImVycm9yIiwiZmFpbGVkIiwicGVuZGluZyIsImlzUGVuZGluZyIsImZvcm0iLCJlbGVtZW50IiwibWVzc2FnZSIsImZpZWxkIiwid2lkdGgiLCJjIiwiaXNGZXRjaGluZyIsImFwcGVuZCIsIm1kIiwibWF4V2lkdGgiLCJpbnB1dE1vZGUiLCJyZW1vdmUiLCJpbnB1dCIsImN1cnJlbnRUYXJnZXQiLCJmaWxlIiwiZmlsZXMiLCJfX01PQ0tfXyIsIkZvcm1EYXRhIiwiciIsImlkcyIsImFsZXJ0IiwiZmlsZUlkIiwiZmlsdGVyIiwieCIsInJlYXNvbiIsImV4cGVjdGVkVmVyc2lvbiIsIkNhdGVnb3JpZXNQYWdlIiwiX3MzIiwiZWRpdCIsInNldEVkaXQiLCJzZXROYW1lIiwicGFyZW50SWQiLCJzZXRQYXJlbnRJZCIsInNldFJlbW92ZSIsInNhdmVkTWVzc2FnZSIsInNldFNhdmVkTWVzc2FnZSIsImNhdGVnb3J5RGV0YWlsIiwid2FpdGluZ0ZvckRldGFpbCIsImRldGFpbCIsImNhdGVnb3J5RWRpdG9yIiwib3BlbiIsIm5vdGljZSIsImFmdGVyR2FwIiwicmVzdWx0Iiwic2hvcElkIiwiSW1wb3J0c1BhZ2UiLCJJbXBvcnRSZXN1bHRQYWdlIiwiX2MiLCJfYzIiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlTGlzdFJldHVybn0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvbGlzdC1yZXR1cm4nO1xyXG5pbXBvcnQgeyBjb2RlUG9pbnRMZW5ndGggfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9mb3JtYXQnO1xyXG5pbXBvcnQgeyBBY3Rpb25Hcm91cCwgRmllbGRHcm91cCwgRm9ybUZpZWxkcyB9IGZyb20gJy4uLy4uL3NoYXJlZC91aS9jb21wb3NpdGlvbic7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdmlzdWFsU3ggfSBmcm9tICdAL3NoYXJlZC91aS92aXN1YWwnO1xyXG5pbXBvcnQgeyBsYXlvdXRTeCB9IGZyb20gJ0Avc2hhcmVkL3VpL2xheW91dCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcywgTGluayBhcyBSb3V0ZXJMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUZvcm0sIHVzZUZpZWxkQXJyYXksIENvbnRyb2xsZXIsIHVzZVdhdGNoIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJztcclxuaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCc7XHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnO1xyXG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIENoZWNrYm94LCBGb3JtQ29udHJvbExhYmVsLCBJY29uQnV0dG9uLCBNZW51SXRlbSwgU3RhY2ssIFRleHRGaWVsZCwgVHlwb2dyYXBoeSB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgQWRkUm91bmRlZCBmcm9tICdAbXVpL2ljb25zLW1hdGVyaWFsL0FkZFJvdW5kZWQnO1xyXG5pbXBvcnQgRGVsZXRlT3V0bGluZVJvdW5kZWQgZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9EZWxldGVPdXRsaW5lUm91bmRlZCc7XHJcbmltcG9ydCB0eXBlIHsgQ2F0ZWdvcnksIFByb2R1Y3QsIFByb2R1Y3RXcml0ZVBhdGNoIH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCwgdXNlUGFnZWRBcGkgfSBmcm9tICdAL3NoYXJlZC9hcGkvaG9va3MnO1xyXG5pbXBvcnQgeyB1c2VTY29wZSwgdXNlQ2FuIH0gZnJvbSAnQC9zaGFyZWQvbW9kZWwvc2NvcGUnO1xyXG5pbXBvcnQgeyB1c2VMaXN0UXVlcnkgfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9maWx0ZXJzJztcclxuaW1wb3J0IHsgUFJPRFVDVF9JTUFHRV9NQVhfQllURVMsIHByb2R1Y3RJbWFnZUZpbGVFcnJvciB9IGZyb20gJy4vaW1wb3J0LWZpbGUnO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJ0Avc2hhcmVkL2FwaS9lcnJvcnMnO1xyXG5pbXBvcnQgeyBkcmFmdEVxdWFsLCB1c2VWZXJzaW9uZWREcmFmdCB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL3ZlcnNpb25lZC1kcmFmdCc7XHJcbmltcG9ydCB7IG1hcmtEcmFmdENsZWFuLCB1c2VEcmFmdEZvcm0gfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9kaXJ0eS1kcmFmdHMnO1xyXG5pbXBvcnQgeyBEcmFmdENvbmZsaWN0IH0gZnJvbSAnQC9zaGFyZWQvdWkvZHJhZnQtY29uZmxpY3QnO1xyXG5pbXBvcnQgeyBQYWdlSGVhZGVyLCBQYW5lbCwgRGF0YVRhYmxlLCBTdGF0dXMsIEFtb3VudCwgUXVlcnlTdGF0ZSwgVG9vbGJhciwgUGFnZXIsIE11dGF0aW9uQnV0dG9uLCBFZGl0RGlhbG9nLCBFcnJvck5vdGljZSwgQ29uZmlybURpYWxvZywgUm91dGVMaW5rLCBMb29rdXBMb2FkTW9yZSB9IGZyb20gJ0Avc2hhcmVkL3VpL2NvbXBvbmVudHMnO1xyXG5jb25zdCBwcm9kdWN0U2NoZW1hID0gei5vYmplY3Qoe1xyXG4gICAgbmFtZTogei5zdHJpbmcoKS50cmltKCkubWluKDEsICdOaOG6rXAgdMOqbiBz4bqjbiBwaOG6qW0nKS5yZWZpbmUodmFsdWUgPT4gY29kZVBvaW50TGVuZ3RoKHZhbHVlKSA8PSAxNjAsICdUw6puIHPhuqNuIHBo4bqpbSB04buRaSDEkWEgMTYwIGvDvSB04buxLicpLCBkZXNjcmlwdGlvbjogei5zdHJpbmcoKS5yZWZpbmUodmFsdWUgPT4gY29kZVBvaW50TGVuZ3RoKHZhbHVlKSA8PSAyMDAwMCwgJ03DtCB04bqjIHThu5FpIMSRYSAyMC4wMDAga8O9IHThu7EuJyksIGNhdGVnb3J5SWQ6IHouc3RyaW5nKCksIHN0YXR1czogei5lbnVtKFsnZHJhZnQnLCAnYWN0aXZlJ10pLCB2YXJpYW50czogei5hcnJheSh6Lm9iamVjdCh7XHJcbiAgICAgICAgaWQ6IHouc3RyaW5nKCkub3B0aW9uYWwoKSwgb3B0aW9uczogei5yZWNvcmQoei5zdHJpbmcoKSwgei5zdHJpbmcoKSkub3B0aW9uYWwoKSwgc2t1OiB6LnN0cmluZygpLnRyaW0oKS5taW4oMSwgJ05o4bqtcCBTS1UnKS5yZWZpbmUodmFsdWUgPT4gY29kZVBvaW50TGVuZ3RoKHZhbHVlKSA8PSA4MCwgJ1NLVSB04buRaSDEkWEgODAga8O9IHThu7EuJyksIG5hbWU6IHouc3RyaW5nKCkubWluKDEsICdOaOG6rXAgdMOqbiBiaeG6v24gdGjhu4MnKSwgcHJpY2U6IHouc3RyaW5nKCkudHJpbSgpLm1pbigxLCAnTmjhuq1wIGdpw6EgYsOhbicpLnJlZ2V4KC9eXFxkKyhcXC5cXGR7MSw0fSk/JC8sICdHacOhIGtow7RuZyBo4bujcCBs4buHJykucmVmaW5lKHZhbHVlID0+IE51bWJlcih2YWx1ZSkgPiAwLCAnR2nDoSBwaOG6o2kgbOG7m24gaMahbiAwJyksIGFjdGl2ZTogei5ib29sZWFuKClcclxuICAgIH0pKS5taW4oMSwgJ0PhuqduIMOtdCBuaOG6pXQgbeG7mXQgYmnhur9uIHRo4buDJylcclxufSk7XHJcbnR5cGUgUHJvZHVjdEZpZWxkcyA9IHouaW5mZXI8dHlwZW9mIHByb2R1Y3RTY2hlbWE+O1xyXG5jb25zdCBkZWZhdWx0czogUHJvZHVjdEZpZWxkcyA9IHsgbmFtZTogJycsIGRlc2NyaXB0aW9uOiAnJywgY2F0ZWdvcnlJZDogJycsIHN0YXR1czogJ2RyYWZ0JywgdmFyaWFudHM6IFt7IHNrdTogJycsIG5hbWU6ICdN4bq3YyDEkeG7i25oJywgcHJpY2U6ICcnLCBhY3RpdmU6IHRydWUgfV0gfTtcclxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3RzUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICAgIGNvbnN0IFtwYXJhbXMsIHNldFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICAgIGNvbnN0IFtjYXRlZ29yeVNlYXJjaElucHV0LCBzZXRDYXRlZ29yeVNlYXJjaElucHV0XSA9IHVzZVN0YXRlKCcnKSwgW2NhdGVnb3J5U2VhcmNoLCBzZXRDYXRlZ29yeVNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0Q2F0ZWdvcnlTZWFyY2goY2F0ZWdvcnlTZWFyY2hJbnB1dC50cmltKCkpLCAyNTApO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH0sIFtjYXRlZ29yeVNlYXJjaElucHV0XSk7XHJcbiAgICBjb25zdCBjYXRlZ29yaWVzID0gdXNlUGFnZWRBcGkoJ2xpc3RDYXRlZ29yaWVzJywgeyBxdWVyeTogeyBxOiBjYXRlZ29yeVNlYXJjaCB8fCB1bmRlZmluZWQgfSB9KTtcclxuICAgIGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnlEZXRhaWwgPSB1c2VBcGkoJ2dldENhdGVnb3J5JywgeyBwYXRoOiB7IGNhdGVnb3J5SWQ6IHBhcmFtcy5nZXQoJ2NhdGVnb3J5SWQnKSB8fCAnJyB9IH0sICEhcGFyYW1zLmdldCgnY2F0ZWdvcnlJZCcpKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnkgPSBjYXRlZ29yaWVzLmRhdGE/LmRhdGEuZmluZChjYXRlZ29yeSA9PiBjYXRlZ29yeS5pZCA9PT0gcGFyYW1zLmdldCgnY2F0ZWdvcnlJZCcpKSB8fCBzZWxlY3RlZENhdGVnb3J5RGV0YWlsLmRhdGE/LmRhdGE7XHJcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0UHJvZHVjdHMnLCB7IHF1ZXJ5OiB7IC4uLnVzZUxpc3RRdWVyeSgnbGlzdFByb2R1Y3RzJyksIGNhdGVnb3J5SWQ6IHBhcmFtcy5nZXQoJ2NhdGVnb3J5SWQnKSB8fCB1bmRlZmluZWQgfSB9KTtcclxuICAgIGNvbnN0IHNldEZpbHRlciA9IChrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHBhcmFtcyk7XHJcbiAgICAgICAgaWYgKHZhbHVlKVxyXG4gICAgICAgICAgICBuZXh0LnNldChrZXksIHZhbHVlKTtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIG5leHQuZGVsZXRlKGtleSk7XHJcbiAgICAgICAgbmV4dC5kZWxldGUoJ2N1cnNvcicpO1xyXG4gICAgICAgIHNldFBhcmFtcyhuZXh0KTtcclxuICAgIH07XHJcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT1cIlPhuqNuIHBo4bqpbVwiIHN1YnRpdGxlPVwiTeG7mXQgbmd14buTbiB0aMO0bmcgdGluIGNobyB0xrAgduG6pW4sIGdpw6EgYsOhbiB2w6AgY8OhYyBiaeG6v24gdGjhu4MuXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJjYXRhbG9nLndyaXRlXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9zLyR7c2hvcC5pZH0vcHJvZHVjdHMvbmV3YCl9IHZhcmlhbnQ9XCJjb250YWluZWRcIj5UaMOqbSBz4bqjbiBwaOG6qW08L011dGF0aW9uQnV0dG9uPn0vPjxQYW5lbD5cclxuICAgICAgICA8VG9vbGJhciBvcGVyYXRpb249XCJsaXN0UHJvZHVjdHNcIiBwbGFjZWhvbGRlcj1cIlTDrG0gdMOqbiBob+G6t2MgU0tV4oCmXCJcclxuICAgICAgICAgICAgZXh0cmE9ezxUZXh0RmllbGQgc2VsZWN0IHNpemU9XCJzbWFsbFwiIGxhYmVsPVwiVHLhuqFuZyB0aMOhaVwiIHZhbHVlPXtwYXJhbXMuZ2V0KCdzdGF0dXMnKSB8fCAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEZpbHRlcignc3RhdHVzJywgZXZlbnQudGFyZ2V0LnZhbHVlKX0gc3g9e3sgbWluV2lkdGg6IDE1MCB9fT5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIlwiPlThuqV0IGPhuqMgdHLhuqFuZyB0aMOhaTwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiZHJhZnRcIj5C4bqjbiBuaMOhcDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiYWN0aXZlXCI+xJBhbmcgYsOhbjwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiYXJjaGl2ZWRcIj7EkMOjIG5n4burbmcgYsOhbjwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgIDwvVGV4dEZpZWxkPn1cclxuICAgICAgICAgICAgZmlsdGVycz17PEZvcm1GaWVsZHMgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdmbGV4LXN0YXJ0JyB9fSByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQuG7mSBs4buNYyBkYW5oIG3hu6VjXCI+XHJcbiAgICAgICAgICAgICAgICA8RmllbGRHcm91cCBnZW9tZXRyeT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNpemU9XCJzbWFsbFwiIGxhYmVsPVwiVMOsbSBkYW5oIG3hu6VjXCIgdmFsdWU9e2NhdGVnb3J5U2VhcmNoSW5wdXR9IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRDYXRlZ29yeVNlYXJjaElucHV0KGV2ZW50LnRhcmdldC52YWx1ZSl9IGhlbHBlclRleHQ9XCJUw6xtIGRhbmggbeG7pWMgdHLDqm4gdG/DoG4gY+G7rWEgaMOgbmcuXCIvPlxyXG4gICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPlxyXG4gICAgICAgICAgICAgICAgPEZpZWxkR3JvdXAgZ2VvbWV0cnk9e3sgZmxleDogMSwgbWluV2lkdGg6IDAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBzZWxlY3Qgc2l6ZT1cInNtYWxsXCIgbGFiZWw9XCJEYW5oIG3hu6VjXCIgdmFsdWU9e3BhcmFtcy5nZXQoJ2NhdGVnb3J5SWQnKSB8fCAnJ30gb25DaGFuZ2U9e2V2ZW50ID0+IHNldEZpbHRlcignY2F0ZWdvcnlJZCcsIGV2ZW50LnRhcmdldC52YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9XCJcIj5U4bqldCBj4bqjIGRhbmggbeG7pWM8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGFyYW1zLmdldCgnY2F0ZWdvcnlJZCcpICYmICFjYXRlZ29yaWVzLmRhdGE/LmRhdGEuc29tZShjYXRlZ29yeSA9PiBjYXRlZ29yeS5pZCA9PT0gcGFyYW1zLmdldCgnY2F0ZWdvcnlJZCcpKSAmJiA8TWVudUl0ZW0gdmFsdWU9e3BhcmFtcy5nZXQoJ2NhdGVnb3J5SWQnKSF9PntzZWxlY3RlZENhdGVnb3J5Py5uYW1lIHx8IHBhcmFtcy5nZXQoJ2NhdGVnb3J5SWQnKX08L01lbnVJdGVtPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXMuZGF0YT8uZGF0YS5tYXAoY2F0ZWdvcnkgPT4gPE1lbnVJdGVtIGtleT17Y2F0ZWdvcnkuaWR9IHZhbHVlPXtjYXRlZ29yeS5pZH0+e2NhdGVnb3J5Lm5hbWV9PC9NZW51SXRlbT4pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGV4dEZpZWxkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImRhbmggbeG7pWNcIiBsb2FkZWRDb3VudD17Y2F0ZWdvcmllcy5sb2FkZWRDb3VudH0gaGFzTW9yZT17Y2F0ZWdvcmllcy5oYXNNb3JlfSBidXN5PXtjYXRlZ29yaWVzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2NhdGVnb3JpZXMubG9hZE1vcmV9Lz5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcmllcy5pc0Vycm9yICYmIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChjYXRlZ29yaWVzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gY2F0ZWdvcmllcy5sb2FkTW9yZSgpIDogY2F0ZWdvcmllcy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIG3hu6VjPC9CdXR0b24+fVxyXG4gICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPlxyXG4gICAgICAgICAgICA8L0Zvcm1GaWVsZHM+fS8+XHJcbiAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiRGFuaCBzw6FjaCBz4bqjbiBwaOG6qW1cIiByb3dzPXtsaXN0LmRhdGEuZGF0YX0gcm93S2V5PXtwID0+IHAuaWR9IGNvbHVtbnM9e1tcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ25hbWUnLCBsYWJlbDogJ1PhuqNuIHBo4bqpbScsIHJlbmRlcjogcCA9PiA8U3RhY2s+PFR5cG9ncmFwaHkgZm9udFdlaWdodD17dmlzdWFsU3gudHlwb2dyYXBoeS5mb250V2VpZ2h0LnN0cm9uZ30+e3AubmFtZX08L1R5cG9ncmFwaHk+PFR5cG9ncmFwaHkgdmFyaWFudD1cImNhcHRpb25cIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+e3AudmFyaWFudHMubWFwKHYgPT4gdi5za3UpLmpvaW4oJyDCtyAnKX08L1R5cG9ncmFwaHk+PC9TdGFjaz5cclxuICAgICAgICB9LFxyXG4gICAgICAgIHsga2V5OiAndmFyaWFudHMnLCBsYWJlbDogJ0Jp4bq/biB0aOG7gycsIHJlbmRlcjogcCA9PiBwLnZhcmlhbnRzLmxlbmd0aCB9LCB7IGtleTogJ3ByaWNlJywgbGFiZWw6ICdHacOhIGJp4bq/biB0aOG7gyDEkeG6p3UnLCByZW5kZXI6IHAgPT4gPEFtb3VudCB2YWx1ZT17cC52YXJpYW50c1swXT8ucHJpY2V9Lz4gfSwgeyBrZXk6ICdzdGF0dXMnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IHAgPT4gPFN0YXR1cyB2YWx1ZT17cC5zdGF0dXN9Lz4gfSwgeyBrZXk6ICdhY3Rpb24nLCBsYWJlbDogJ1RoYW8gdMOhYycsIHJlbmRlcjogcCA9PiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9wcm9kdWN0cy8ke3AuaWR9YH0+Q2hpIHRp4bq/dDwvUm91dGVMaW5rPiB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPjwvPjtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdEVkaXRvclBhZ2UoKSB7XHJcbiAgICBjb25zdCB7IHByb2R1Y3RJZDogcm91dGVQcm9kdWN0SWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gICAgY29uc3QgW2NyZWF0ZWRQcm9kdWN0SWQsIHNldENyZWF0ZWRQcm9kdWN0SWRdID0gdXNlU3RhdGU8c3RyaW5nPigpO1xyXG4gICAgY29uc3QgcHJvZHVjdElkID0gcm91dGVQcm9kdWN0SWQgfHwgY3JlYXRlZFByb2R1Y3RJZDtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IGxpc3RIcmVmPXVzZUxpc3RSZXR1cm4oYC9zLyR7c2hvcC5pZH0vcHJvZHVjdHNgKTtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICAgIGNvbnN0IGNhbldyaXRlID0gdXNlQ2FuKCdjYXRhbG9nLndyaXRlJyk7XHJcbiAgICBjb25zdCBwcm9kdWN0ID0gdXNlQXBpKCdnZXRQcm9kdWN0JywgeyBwYXRoOiB7IHByb2R1Y3RJZDogcHJvZHVjdElkIHx8ICduZXcnIH0gfSwgISFwcm9kdWN0SWQpO1xyXG4gICAgY29uc3QgW2NhdGVnb3J5U2VhcmNoLCBzZXRDYXRlZ29yeVNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbY2F0ZWdvcnlRdWVyeSwgc2V0Q2F0ZWdvcnlRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0Q2F0ZWdvcnlRdWVyeShjYXRlZ29yeVNlYXJjaC50cmltKCkpLCAyNTApO1xyXG4gICAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH0sIFtjYXRlZ29yeVNlYXJjaF0pO1xyXG4gICAgY29uc3QgY2F0ZWdvcmllcyA9IHVzZVBhZ2VkQXBpKCdsaXN0Q2F0ZWdvcmllcycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwLCBxOiBjYXRlZ29yeVF1ZXJ5IHx8IHVuZGVmaW5lZCB9IH0pO1xyXG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlUHJvZHVjdCcsIFsnbGlzdFByb2R1Y3RzJ10pO1xyXG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlUHJvZHVjdCcsIFsnZ2V0UHJvZHVjdCcsICdsaXN0UHJvZHVjdHMnXSk7XHJcbiAgICBjb25zdCBhcmNoaXZlID0gdXNlQ29tbWFuZCgnYXJjaGl2ZVByb2R1Y3QnLCBbJ2dldFByb2R1Y3QnLCAnbGlzdFByb2R1Y3RzJ10pO1xyXG4gICAgY29uc3QgW2NvbmZpcm0sIHNldENvbmZpcm1dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2ltYWdlSWRzLCBzZXRJbWFnZUlkc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xyXG4gICAgY29uc3QgW3NhdmVkSW1hZ2VJZHMsIHNldFNhdmVkSW1hZ2VJZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICAgIGNvbnN0IFtpbWFnZUVycm9yLCBzZXRJbWFnZUVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IHVwbG9hZCA9IHVzZUNvbW1hbmQoJ3VwbG9hZEZpbGUnLCBbXSk7XHJcbiAgICBjb25zdCBwcm9kdWN0Rm9ybSA9IHVzZUZvcm08UHJvZHVjdEZpZWxkcz4oeyBkZWZhdWx0VmFsdWVzOiBkZWZhdWx0cywgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHByb2R1Y3RTY2hlbWEpIH0pO1xyXG4gICAgY29uc3QgeyByZWdpc3RlciwgY29udHJvbCwgaGFuZGxlU3VibWl0LCByZXNldCwgZm9ybVN0YXRlOiB7IGVycm9ycywgaXNEaXJ0eSB9IH0gPSBwcm9kdWN0Rm9ybTtcclxuICAgIHVzZVdhdGNoKHsgY29udHJvbCB9KTtcclxuICAgIGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnlJZCA9IHVzZVdhdGNoKHsgY29udHJvbCwgbmFtZTogJ2NhdGVnb3J5SWQnIH0pO1xyXG4gICAgY29uc3QgY2F0ZWdvcnlPblBhZ2UgPSBjYXRlZ29yaWVzLmRhdGE/LmRhdGEuZmluZChjYXRlZ29yeSA9PiBjYXRlZ29yeS5pZCA9PT0gc2VsZWN0ZWRDYXRlZ29yeUlkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnkgPSB1c2VBcGkoJ2dldENhdGVnb3J5JywgeyBwYXRoOiB7IGNhdGVnb3J5SWQ6IHNlbGVjdGVkQ2F0ZWdvcnlJZCB8fCAnJyB9IH0sIEJvb2xlYW4oc2VsZWN0ZWRDYXRlZ29yeUlkICYmICFjYXRlZ29yeU9uUGFnZSkpO1xyXG4gICAgY29uc3QgcmV0YWluZWRDYXRlZ29yeSA9IGNhdGVnb3J5T25QYWdlIHx8IChzZWxlY3RlZENhdGVnb3J5LmRhdGE/LmRhdGEuaWQgPT09IHNlbGVjdGVkQ2F0ZWdvcnlJZCA/IHNlbGVjdGVkQ2F0ZWdvcnkuZGF0YS5kYXRhIDogdW5kZWZpbmVkKTtcclxuICAgIGNvbnN0IGZpZWxkQXJyYXkgPSB1c2VGaWVsZEFycmF5KHsgY29udHJvbCwgbmFtZTogJ3ZhcmlhbnRzJyB9KTtcclxuICAgIGNvbnN0IGltYWdlc0RpcnR5ID0gaW1hZ2VJZHMubGVuZ3RoICE9PSBzYXZlZEltYWdlSWRzLmxlbmd0aCB8fCBpbWFnZUlkcy5zb21lKChpZCwgaW5kZXgpID0+IGlkICE9PSBzYXZlZEltYWdlSWRzW2luZGV4XSk7XHJcbiAgICBjb25zdCBlZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XHJcbiAgICAgICAgaWRlbnRpdHk6IGAke3Nob3AuaWR9OnByb2R1Y3Q6JHtyb3V0ZVByb2R1Y3RJZCB8fCAnbmV3J31gLFxyXG4gICAgICAgIHNvdXJjZTogcHJvZHVjdC5kYXRhID8gcHJvZHVjdFNuYXBzaG90KHByb2R1Y3QuZGF0YS5kYXRhKSA6IHVuZGVmaW5lZCxcclxuICAgICAgICBkcmFmdDogeyAuLi5wcm9kdWN0Rm9ybS5nZXRWYWx1ZXMoKSwgaW1hZ2VGaWxlSWRzOiBpbWFnZUlkcyB9LFxyXG4gICAgICAgIGFwcGx5OiAodmFsdWVzLCBiYXNlbGluZSkgPT4ge1xyXG4gICAgICAgICAgICByZXNldChiYXNlbGluZSk7XHJcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIFsnbmFtZScsICdkZXNjcmlwdGlvbicsICdjYXRlZ29yeUlkJywgJ3N0YXR1cycsICd2YXJpYW50cyddIGFzIGNvbnN0KVxyXG4gICAgICAgICAgICAgICAgaWYgKCFkcmFmdEVxdWFsKHZhbHVlc1trZXldLCBiYXNlbGluZVtrZXldKSkgcHJvZHVjdEZvcm0uc2V0VmFsdWUoa2V5LCB2YWx1ZXNba2V5XSwgeyBzaG91bGREaXJ0eTogdHJ1ZSB9KTtcclxuICAgICAgICAgICAgc2V0SW1hZ2VJZHModmFsdWVzLmltYWdlRmlsZUlkcyk7IHNldFNhdmVkSW1hZ2VJZHMoYmFzZWxpbmUuaW1hZ2VGaWxlSWRzKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIHJlZnJlc2g6ICgpID0+IHByb2R1Y3QucmVmZXRjaCh7IHRocm93T25FcnJvcjogdHJ1ZSB9KSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgZHJhZnRGb3JtID0gdXNlRHJhZnRGb3JtKGlzRGlydHkgfHwgaW1hZ2VzRGlydHkgfHwgZWRpdG9yLmRpcnR5KTtcclxuICAgIGNvbnN0IHByb2R1Y3RFbGVtZW50ID0gdXNlUmVmPEhUTUxGb3JtRWxlbWVudD4obnVsbCk7XHJcbiAgICB1c2VFZmZlY3QoKCkgPT4geyBpZiAoIWlzRGlydHkgJiYgIWltYWdlc0RpcnR5KVxyXG4gICAgICAgIHJldHVybjsgY29uc3QgcHJldmVudCA9IChlOiBCZWZvcmVVbmxvYWRFdmVudCkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IGUucmV0dXJuVmFsdWUgPSAnJzsgfTsgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JlZm9yZXVubG9hZCcsIHByZXZlbnQpOyByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2JlZm9yZXVubG9hZCcsIHByZXZlbnQpOyB9LCBbaXNEaXJ0eSwgaW1hZ2VzRGlydHldKTtcclxuICAgIGNvbnN0IHNhdmUgPSBoYW5kbGVTdWJtaXQoYXN5bmMgKGZpZWxkcykgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgLi4ucHJvZHVjdEZvcm0uZ2V0VmFsdWVzKCksIGltYWdlRmlsZUlkczogWy4uLmltYWdlSWRzXSB9O1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7IG5hbWU6IGZpZWxkcy5uYW1lLCBkZXNjcmlwdGlvbjogZmllbGRzLmRlc2NyaXB0aW9uLCBjYXRlZ29yeUlkOiBmaWVsZHMuY2F0ZWdvcnlJZCB8fCBudWxsLCBzdGF0dXM6IGZpZWxkcy5zdGF0dXMsXHJcbiAgICAgICAgICAgIGltYWdlRmlsZUlkczogaW1hZ2VJZHMsIHZhcmlhbnRzOiBmaWVsZHMudmFyaWFudHMubWFwKHYgPT4gKHsgaWQ6IHYuaWQsIHNrdTogdi5za3UsIG5hbWU6IHYubmFtZSwgb3B0aW9uczogdi5vcHRpb25zIHx8IHt9LCBwcmljZTogeyBhbW91bnQ6IHYucHJpY2UsIGN1cnJlbmN5OiBzaG9wLmN1cnJlbmN5IH0sIGFjdGl2ZTogdi5hY3RpdmUgfSkpIH07XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlc3BvbnNlOiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZS5leGVjdXRlPj47XHJcbiAgICAgICAgICAgIGlmIChwcm9kdWN0SWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXBhcmVkID0gZWRpdG9yLnByZXBhcmUoKTsgaWYgKCFwcmVwYXJlZCB8fCAhT2JqZWN0LmtleXMocHJlcGFyZWQucGF0Y2gpLmxlbmd0aCkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF0Y2ggPSBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmtleXMocHJlcGFyZWQucGF0Y2gpLm1hcChrZXkgPT4gW2tleSwgYm9keVtrZXkgYXMga2V5b2YgdHlwZW9mIGJvZHldXSkpIGFzIFByb2R1Y3RXcml0ZVBhdGNoO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCB1cGRhdGUuZXhlY3V0ZSh7IHBhdGg6IHsgcHJvZHVjdElkIH0sIHZlcnNpb246IHByZXBhcmVkLnZlcnNpb24sIGJvZHk6IHBhdGNoIH0pO1xyXG4gICAgICAgICAgICB9IGVsc2UgcmVzcG9uc2UgPSBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHkgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuID0gZWRpdG9yLmNvbW1pdHRlZChwcm9kdWN0U25hcHNob3QocmVzcG9uc2UuZGF0YSksIHN1Ym1pdHRlZCk7XHJcbiAgICAgICAgICAgIHNldENyZWF0ZWRQcm9kdWN0SWQocmVzcG9uc2UuZGF0YS5pZCk7XHJcbiAgICAgICAgICAgIGlmIChjbGVhbikgeyBpZiAocHJvZHVjdEVsZW1lbnQuY3VycmVudCkgbWFya0RyYWZ0Q2xlYW4ocHJvZHVjdEVsZW1lbnQuY3VycmVudCk7IG5hdmlnYXRlKGAvcy8ke3Nob3AuaWR9L3Byb2R1Y3RzLyR7cmVzcG9uc2UuZGF0YS5pZH1gLCB7IHJlcGxhY2U6IHRydWUgfSk7IH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikgeyBlZGl0b3IuZmFpbGVkKGVycm9yKTsgfVxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBwZW5kaW5nID0gY3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmcgfHwgdXBsb2FkLnBlbmRpbmc7XHJcbiAgICByZXR1cm4gPD48UGFnZUhlYWRlciB0aXRsZT17cHJvZHVjdElkID8gJ1Row7RuZyB0aW4gc+G6o24gcGjhuqltJyA6ICdUaMOqbSBz4bqjbiBwaOG6qW0nfSBzdWJ0aXRsZT1cIkdpw6EgdGhlbyBiaeG6v24gdGjhu4MuIFThu5NuIGtobyDEkcaw4bujYyBxdeG6o24gbMO9IOG7nyBtw6BuIGjDrG5oIHJpw6puZy5cIiBhY3Rpb25zPXs8QnV0dG9uIGNvbXBvbmVudD17Um91dGVyTGlua30gdG89e2xpc3RIcmVmfT5EYW5oIHPDoWNoPC9CdXR0b24+fS8+e3Byb2R1Y3RJZCAmJiBwcm9kdWN0LmlzUGVuZGluZyA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtwcm9kdWN0fT57bnVsbH08L1F1ZXJ5U3RhdGU+IDogcHJvZHVjdElkICYmIHByb2R1Y3QuaXNFcnJvciA/IDxRdWVyeVN0YXRlIHF1ZXJ5PXtwcm9kdWN0fT57bnVsbH08L1F1ZXJ5U3RhdGU+IDogPEJveCBjb21wb25lbnQ9XCJmb3JtXCIgcmVmPXtmb3JtID0+IHsgY29uc3QgZWxlbWVudCA9IGZvcm0gYXMgSFRNTEZvcm1FbGVtZW50IHwgbnVsbDsgcHJvZHVjdEVsZW1lbnQuY3VycmVudCA9IGVsZW1lbnQ7IGRyYWZ0Rm9ybShlbGVtZW50KTsgfX0gZGF0YS1kcmFmdC1jbGVhbj17IWlzRGlydHkgJiYgIWltYWdlc0RpcnR5ID8gJ3RydWUnIDogdW5kZWZpbmVkfSBvblN1Ym1pdD17c2F2ZX0+XHJcbiA8RXJyb3JOb3RpY2UgZXJyb3I9e2NyZWF0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3IgfHwgdXBsb2FkLmVycm9yfS8+PERyYWZ0Q29uZmxpY3QgZWRpdG9yPXtlZGl0b3J9IGxhYmVscz17eyBuYW1lOiAnVMOqbiBz4bqjbiBwaOG6qW0nLCBkZXNjcmlwdGlvbjogJ03DtCB04bqjJywgY2F0ZWdvcnlJZDogJ0RhbmggbeG7pWMnLCBzdGF0dXM6ICdUcuG6oW5nIHRow6FpJywgdmFyaWFudHM6ICdCaeG6v24gdGjhu4MgdsOgIGdpw6EnLCBpbWFnZUZpbGVJZHM6ICfhuqJuaCBz4bqjbiBwaOG6qW0nIH19IGJ1c3k9e3BlbmRpbmd9Lz48UGFuZWwgdGl0bGU9XCJUaMO0bmcgdGluIGLDoW4gaMOgbmdcIiBib2R5TW9kZT1cImluc2V0XCI+PEZvcm1GaWVsZHMgPjxUZXh0RmllbGQgbGFiZWw9XCJUw6puIHPhuqNuIHBo4bqpbVwiIHsuLi5yZWdpc3RlcignbmFtZScpfSBlcnJvcj17ISFlcnJvcnMubmFtZX0gaGVscGVyVGV4dD17ZXJyb3JzLm5hbWU/Lm1lc3NhZ2V9IGRpc2FibGVkPXshY2FuV3JpdGV9Lz48VGV4dEZpZWxkIGxhYmVsPVwiTcO0IHThuqMgZMO5bmcgY2hvIEFJIHTGsCB24bqlblwiIG11bHRpbGluZSBtaW5Sb3dzPXs0fSB7Li4ucmVnaXN0ZXIoJ2Rlc2NyaXB0aW9uJyl9IGRpc2FibGVkPXshY2FuV3JpdGV9Lz48VGV4dEZpZWxkIGxhYmVsPVwiVMOsbSBkYW5oIG3hu6VjXCIgc2l6ZT1cInNtYWxsXCIgdmFsdWU9e2NhdGVnb3J5U2VhcmNofSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0Q2F0ZWdvcnlTZWFyY2goZXZlbnQudGFyZ2V0LnZhbHVlKX0gZGlzYWJsZWQ9eyFjYW5Xcml0ZX0gaGVscGVyVGV4dD1cIlTDrG0gdHLDqm4gZGFuaCBzw6FjaCBj4butYSBow6BuZzsgY8OzIHRo4buDIHThuqNpIHRow6ptIGtoaSBj4bqnbi5cIi8+PEZpZWxkR3JvdXAgZGlyZWN0aW9uPXt7IHhzOiAnY29sdW1uJywgc206ICdyb3cnIH19IGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgc206ICdzdGFydCcgfX0+PENvbnRyb2xsZXIgbmFtZT1cImNhdGVnb3J5SWRcIiBjb250cm9sPXtjb250cm9sfSByZW5kZXI9eyh7IGZpZWxkIH0pID0+IDxGaWVsZEdyb3VwIGdlb21ldHJ5PXt7ZmxleDogMSwgbWluV2lkdGg6IDAsIHdpZHRoOiAnMTAwJSd9fT48VGV4dEZpZWxkIHNlbGVjdCBmdWxsV2lkdGggbGFiZWw9XCJEYW5oIG3hu6VjXCIgey4uLmZpZWxkfSBkaXNhYmxlZD17IWNhbldyaXRlfT48TWVudUl0ZW0gdmFsdWU9XCJcIj5DaMawYSBwaMOibiBsb+G6oWk8L01lbnVJdGVtPntzZWxlY3RlZENhdGVnb3J5SWQgJiYgIWNhdGVnb3J5T25QYWdlICYmIDxNZW51SXRlbSB2YWx1ZT17c2VsZWN0ZWRDYXRlZ29yeUlkfT57cmV0YWluZWRDYXRlZ29yeT8ubmFtZSB8fCAoc2VsZWN0ZWRDYXRlZ29yeS5pc0Vycm9yID8gYERhbmggbeG7pWMgaGnhu4duIHThuqFpICgke3NlbGVjdGVkQ2F0ZWdvcnlJZH0pYCA6ICfEkGFuZyB04bqjaSBkYW5oIG3hu6VjIGhp4buHbiB04bqhaeKApicpfTwvTWVudUl0ZW0+fXtjYXRlZ29yaWVzLmRhdGE/LmRhdGEubWFwKGMgPT4gPE1lbnVJdGVtIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PntjLm5hbWV9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxMb29rdXBMb2FkTW9yZSBsYWJlbD1cImRhbmggbeG7pWNcIiBsb2FkZWRDb3VudD17Y2F0ZWdvcmllcy5sb2FkZWRDb3VudH0gaGFzTW9yZT17Y2F0ZWdvcmllcy5oYXNNb3JlfSBidXN5PXtjYXRlZ29yaWVzLmlzTG9hZGluZ01vcmV9IG9uTG9hZE1vcmU9e2NhdGVnb3JpZXMubG9hZE1vcmV9Lz57Y2F0ZWdvcmllcy5pc1BlbmRpbmcgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHJvbGU9XCJzdGF0dXNcIj7EkGFuZyB04bqjaSBkYW5oIG3hu6Vj4oCmPC9BbGVydD59e2NhdGVnb3JpZXMuaXNFcnJvciAmJiA8QWxlcnQgc2V2ZXJpdHk9e2NhdGVnb3JpZXMuaXNGZXRjaE5leHRQYWdlRXJyb3IgPyAnd2FybmluZycgOiAnZXJyb3InfSByb2xlPVwiYWxlcnRcIiBhY3Rpb249ezxCdXR0b24gY29sb3I9XCJpbmhlcml0XCIgc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4geyB2b2lkIChjYXRlZ29yaWVzLmlzRmV0Y2hOZXh0UGFnZUVycm9yID8gY2F0ZWdvcmllcy5sb2FkTW9yZSgpIDogY2F0ZWdvcmllcy5yZWZldGNoKCkpOyB9fT5UaOG7rSBs4bqhaSBkYW5oIG3hu6VjPC9CdXR0b24+fT57Y2F0ZWdvcmllcy5pc0ZldGNoTmV4dFBhZ2VFcnJvciA/IGBLaMO0bmcgdOG6o2kgdGjDqm0gxJHGsOG7o2MgZGFuaCBt4bulYyAoSFRUUCAke2NhdGVnb3JpZXMuZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGNhdGVnb3JpZXMuZXJyb3Iuc3RhdHVzIDogJ2zhu5dpJ30pLiBDw6FjIGzhu7FhIGNo4buNbiDEkcOjIHThuqNpIHbhuqtuIGTDuW5nIMSRxrDhu6NjLmAgOiBgS2jDtG5nIHThuqNpIMSRxrDhu6NjIGRhbmggbeG7pWMgKEhUVFAgJHtjYXRlZ29yaWVzLmVycm9yIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBjYXRlZ29yaWVzLmVycm9yLnN0YXR1cyA6ICds4buXaSd9KS4gQuG6o24gbmjDoXAgxJHGsOG7o2MgZ2nhu687IGjDo3kgdGjhu60gbOG6oWkgaG/hurdjIGNo4buNbiDigJxDaMawYSBwaMOibiBsb+G6oWnigJ0uYH08L0FsZXJ0Pn17Y2F0ZWdvcmllcy5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCAmJiAhY2F0ZWdvcmllcy5pc0ZldGNoaW5nICYmIDxBbGVydCBzZXZlcml0eT1cImluZm9cIiByb2xlPVwic3RhdHVzXCI+e2NhdGVnb3J5UXVlcnkgPyAnS2jDtG5nIHTDrG0gdGjhuqV5IGRhbmggbeG7pWMgcGjDuSBo4bujcC4nIDogJ0Phu61hIGjDoG5nIGNoxrBhIGPDsyBkYW5oIG3hu6VjLid9PC9BbGVydD59e3NlbGVjdGVkQ2F0ZWdvcnkuaXNQZW5kaW5nICYmIHNlbGVjdGVkQ2F0ZWdvcnlJZCAmJiAhY2F0ZWdvcnlPblBhZ2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHJvbGU9XCJzdGF0dXNcIj7EkGFuZyB04bqjaSB0w6puIGRhbmggbeG7pWMgxJHDoyBn4bqvbiB24bubaSBz4bqjbiBwaOG6qW3igKY8L0FsZXJ0Pn17c2VsZWN0ZWRDYXRlZ29yeS5pc0Vycm9yICYmIHNlbGVjdGVkQ2F0ZWdvcnlJZCAmJiAhY2F0ZWdvcnlPblBhZ2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwid2FybmluZ1wiIHJvbGU9XCJhbGVydFwiIGFjdGlvbj17PEJ1dHRvbiBjb2xvcj1cImluaGVyaXRcIiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB7IHZvaWQgc2VsZWN0ZWRDYXRlZ29yeS5yZWZldGNoKCk7IH19PlRo4butIGzhuqFpIGRhbmggbeG7pWMgxJFhbmcgY2jhu41uPC9CdXR0b24+fT57c2VsZWN0ZWRDYXRlZ29yeS5lcnJvciBpbnN0YW5jZW9mIEFwaUVycm9yICYmIHNlbGVjdGVkQ2F0ZWdvcnkuZXJyb3Iuc3RhdHVzID09PSA0MDMgPyAnS2jDtG5nIGPDsyBxdXnhu4FuIMSR4buNYyBkYW5oIG3hu6VjIGhp4buHbiB04bqhaSAoNDAzKS4gSUQgxJHDoyBjaOG7jW4gduG6q24gxJHGsOG7o2MgZ2nhu68gdHJvbmcgYmnhu4N1IG3huqt1LicgOiBgS2jDtG5nIHThuqNpIMSRxrDhu6NjIGRhbmggbeG7pWMgaGnhu4duIHThuqFpICgke3NlbGVjdGVkQ2F0ZWdvcnkuZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciA/IHNlbGVjdGVkQ2F0ZWdvcnkuZXJyb3Iuc3RhdHVzIDogJ2zhu5dpJ30pLiBJRCDEkcOjIGNo4buNbiB24bqrbiDEkcaw4bujYyBnaeG7ryB0cm9uZyBiaeG7g3UgbeG6q3UuYH08L0FsZXJ0Pn08L0ZpZWxkR3JvdXA+fS8+PENvbnRyb2xsZXIgbmFtZT1cInN0YXR1c1wiIGNvbnRyb2w9e2NvbnRyb2x9IHJlbmRlcj17KHsgZmllbGQgfSkgPT4gPFRleHRGaWVsZCBzZWxlY3QgZnVsbFdpZHRoIGxhYmVsPVwiVHLhuqFuZyB0aMOhaVwiIHsuLi5maWVsZH0gZGlzYWJsZWQ9eyFjYW5Xcml0ZX0gc3g9e3sgZmxleDogMSwgbWluV2lkdGg6IDAgfX0+PE1lbnVJdGVtIHZhbHVlPVwiZHJhZnRcIj5C4bqjbiBuaMOhcDwvTWVudUl0ZW0+PE1lbnVJdGVtIHZhbHVlPVwiYWN0aXZlXCI+xJBhbmcgYsOhbjwvTWVudUl0ZW0+PC9UZXh0RmllbGQ+fS8+PC9GaWVsZEdyb3VwPjwvRm9ybUZpZWxkcz48L1BhbmVsPlxyXG4gPFBhbmVsIHRpdGxlPVwiQmnhur9uIHRo4buDIHbDoCBnacOhXCIgYm9keU1vZGU9XCJpbnNldFwiIGJlZm9yZUdhcD17XCJzZWN0aW9uXCJ9IGFjdGlvbj17PEJ1dHRvbiBzdGFydEljb249ezxBZGRSb3VuZGVkIC8+fSBkaXNhYmxlZD17IWNhbldyaXRlfSBvbkNsaWNrPXsoKSA9PiBmaWVsZEFycmF5LmFwcGVuZCh7IHNrdTogJycsIG5hbWU6ICcnLCBwcmljZTogJycsIGFjdGl2ZTogdHJ1ZSB9KX0+VGjDqm0gYmnhur9uIHRo4buDPC9CdXR0b24+fT48Rm9ybUZpZWxkcyA+e2ZpZWxkQXJyYXkuZmllbGRzLm1hcCgoZmllbGQsIGluZGV4KSA9PiA8RmllbGRHcm91cCBrZXk9e2ZpZWxkLmlkfSBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBtZDogJ3JvdycgfX0gIGFsaWduSXRlbXM9e3sgeHM6ICdzdHJldGNoJywgbWQ6ICdzdGFydCcgfX0gZmxleFdyYXA9XCJ3cmFwXCI+PFRleHRGaWVsZCBsYWJlbD1cIlNLVVwiIHsuLi5yZWdpc3RlcihgdmFyaWFudHMuJHtpbmRleH0uc2t1YCl9IGVycm9yPXshIWVycm9ycy52YXJpYW50cz8uW2luZGV4XT8uc2t1fSBoZWxwZXJUZXh0PXtlcnJvcnMudmFyaWFudHM/LltpbmRleF0/LnNrdT8ubWVzc2FnZX0gZGlzYWJsZWQ9eyFjYW5Xcml0ZX0gc3g9e3sgd2lkdGg6IHsgeHM6ICcxMDAlJywgbWQ6ICdhdXRvJyB9LCBtaW5XaWR0aDogJ21pbigxMDAlLCAxMmVtKScsIG1heFdpZHRoOiAnMTAwJScsIGZsZXg6IHsgeHM6ICcwIDEgYXV0bycsIG1kOiAnMSAxIDEyZW0nIH0gfX0vPjxUZXh0RmllbGQgbGFiZWw9XCJUw6puIC8gbcOgdSAvIGvDrWNoIGPhu6FcIiB7Li4ucmVnaXN0ZXIoYHZhcmlhbnRzLiR7aW5kZXh9Lm5hbWVgKX0gZGlzYWJsZWQ9eyFjYW5Xcml0ZX0gc3g9e3sgd2lkdGg6IHsgeHM6ICcxMDAlJywgbWQ6ICdhdXRvJyB9LCBtaW5XaWR0aDogJ21pbigxMDAlLCAxMmVtKScsIG1heFdpZHRoOiAnMTAwJScsIGZsZXg6IHsgeHM6ICcwIDEgYXV0bycsIG1kOiAnMSAxIDEyZW0nIH0gfX0vPjxUZXh0RmllbGQgbGFiZWw9e2BHacOhIGLDoW4gKCR7c2hvcC5jdXJyZW5jeX0pYH0gaW5wdXRQcm9wcz17eyBpbnB1dE1vZGU6ICdkZWNpbWFsJyB9fSB7Li4ucmVnaXN0ZXIoYHZhcmlhbnRzLiR7aW5kZXh9LnByaWNlYCl9IGVycm9yPXshIWVycm9ycy52YXJpYW50cz8uW2luZGV4XT8ucHJpY2V9IGhlbHBlclRleHQ9e2Vycm9ycy52YXJpYW50cz8uW2luZGV4XT8ucHJpY2U/Lm1lc3NhZ2V9IGRpc2FibGVkPXshY2FuV3JpdGV9IHN4PXt7IHdpZHRoOiB7IHhzOiAnMTAwJScsIG1kOiAnYXV0bycgfSwgbWluV2lkdGg6ICdtaW4oMTAwJSwgMTJlbSknLCBtYXhXaWR0aDogJzEwMCUnLCBmbGV4OiB7IHhzOiAnMCAxIGF1dG8nLCBtZDogJzEgMSAxMmVtJyB9IH19Lz48Rm9ybUNvbnRyb2xMYWJlbCBsYWJlbD1cIsSQYW5nIGLDoW5cIiBjb250cm9sPXs8Q2hlY2tib3ggZGVmYXVsdENoZWNrZWQ9e2ZpZWxkLmFjdGl2ZX0gey4uLnJlZ2lzdGVyKGB2YXJpYW50cy4ke2luZGV4fS5hY3RpdmVgKX0gZGlzYWJsZWQ9eyFjYW5Xcml0ZX0vPn0vPjxJY29uQnV0dG9uIGFyaWEtbGFiZWw9e2BYw7NhIGJp4bq/biB0aOG7gyAke2luZGV4ICsgMX1gfSBkaXNhYmxlZD17IWNhbldyaXRlIHx8IGZpZWxkQXJyYXkuZmllbGRzLmxlbmd0aCA9PT0gMX0gb25DbGljaz17KCkgPT4gZmllbGRBcnJheS5yZW1vdmUoaW5kZXgpfT48RGVsZXRlT3V0bGluZVJvdW5kZWQgLz48L0ljb25CdXR0b24+PC9GaWVsZEdyb3VwPil9PC9Gb3JtRmllbGRzPjwvUGFuZWw+XHJcbiA8UGFuZWwgdGl0bGU9XCLhuqJuaCBz4bqjbiBwaOG6qW1cIiBzdWJ0aXRsZT1cIkZpbGUgxJHGsOG7o2Mga2nhu4NtIHNvw6F0IHF1YSBBUEkgdXBsb2FkOyBraMO0bmcgbmjDum5nIHNlY3JldCBob+G6t2MgVVJMIHTDuXkgw70uXCIgYm9keU1vZGU9XCJpbnNldFwiIGJlZm9yZUdhcD17XCJzZWN0aW9uXCJ9PjxGb3JtRmllbGRzID48VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj57aW1hZ2VJZHMubGVuZ3RofSB04buHcCDEkcaw4bujYyBn4bqvbiB24bubaSBz4bqjbiBwaOG6qW08L1R5cG9ncmFwaHk+PEJ1dHRvbiBjb21wb25lbnQ9XCJsYWJlbFwiIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGRpc2FibGVkPXshY2FuV3JpdGUgfHwgcGVuZGluZ30+Q2jhu41uIOG6o25oPGlucHV0IGhpZGRlbiB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlL3BuZyxpbWFnZS9qcGVnLGltYWdlL3dlYnBcIiBvbkNoYW5nZT17YXN5bmMgKGUpID0+IHsgY29uc3QgaW5wdXQgPSBlLmN1cnJlbnRUYXJnZXQ7IGNvbnN0IGZpbGUgPSBpbnB1dC5maWxlcz8uWzBdIHx8IG51bGw7IGNvbnN0IGVycm9yID0gcHJvZHVjdEltYWdlRmlsZUVycm9yKGZpbGUsIF9fTU9DS19fID8gUFJPRFVDVF9JTUFHRV9NQVhfQllURVMgOiB1bmRlZmluZWQpOyBzZXRJbWFnZUVycm9yKGVycm9yKTsgaWYgKGVycm9yKSB7IGlucHV0LnZhbHVlID0gJyc7IHJldHVybjsgfSBpZiAoIWZpbGUpIHJldHVybjsgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpOyBmb3JtLmFwcGVuZCgnZmlsZScsIGZpbGUpOyBmb3JtLmFwcGVuZCgncHVycG9zZScsICdwcm9kdWN0X2ltYWdlJyk7IHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHIgPSBhd2FpdCB1cGxvYWQuZXhlY3V0ZSh7IGZvcm0gfSk7XHJcbiAgICAgICAgICAgIGlmIChyLmRhdGEuc3RhdHVzID09PSAncmVhZHknKVxyXG4gICAgICAgICAgICAgICAgc2V0SW1hZ2VJZHMoaWRzID0+IFsuLi5pZHMsIHIuZGF0YS5pZF0pO1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBhbGVydCgnVOG7h3AgxJFhbmcgxJHGsOG7o2MgY8OhY2ggbHkva2nhu4NtIHRyYTsgY2jGsGEgZ+G6r24gdsOgbyBz4bqjbiBwaOG6qW0uJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIHsgLyogdmlzaWJsZSBlcnJvciAqLyB9IGlucHV0LnZhbHVlID0gJyc7IH19Lz48L0J1dHRvbj57aW1hZ2VFcnJvciAmJiA8QWxlcnQgc2V2ZXJpdHk9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPntpbWFnZUVycm9yfTwvQWxlcnQ+fXtpbWFnZUlkcy5tYXAoZmlsZUlkID0+IDxBY3Rpb25Hcm91cCBrZXk9e2ZpbGVJZH0gZGlyZWN0aW9uPVwicm93XCIgPjxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCI+e2ZpbGVJZH08L1R5cG9ncmFwaHk+PEJ1dHRvbiBzaXplPVwic21hbGxcIiBkaXNhYmxlZD17IWNhbldyaXRlfSBvbkNsaWNrPXsoKSA9PiBzZXRJbWFnZUlkcyhpZHMgPT4gaWRzLmZpbHRlcih4ID0+IHggIT09IGZpbGVJZCkpfT5C4buPIGxpw6puIGvhur90IOG6o25oPC9CdXR0b24+PC9BY3Rpb25Hcm91cD4pfTwvRm9ybUZpZWxkcz48L1BhbmVsPlxyXG4gPEFjdGlvbkdyb3VwIGRpcmVjdGlvbj1cInJvd1wiIGJlZm9yZUdhcD1cImZvcm1cIiBqdXN0aWZ5Q29udGVudD17XCJzcGFjZS1iZXR3ZWVuXCJ9ID57cHJvZHVjdElkICYmIHByb2R1Y3QuZGF0YT8uZGF0YS5zdGF0dXMgIT09ICdhcmNoaXZlZCcgPyA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImNhdGFsb2cud3JpdGVcIiBjb2xvcj1cImVycm9yXCIgb25DbGljaz17KCkgPT4gc2V0Q29uZmlybSh0cnVlKX0+Tmfhu6tuZyBiw6FuPC9NdXRhdGlvbkJ1dHRvbj4gOiA8c3BhbiAvPn08TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImNhdGFsb2cud3JpdGVcIiB0eXBlPVwic3VibWl0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e3BlbmRpbmd9PkzGsHUgc+G6o24gcGjhuqltPC9NdXRhdGlvbkJ1dHRvbj48L0FjdGlvbkdyb3VwPjwvQm94Pn1cclxuIDxDb25maXJtRGlhbG9nIG9wZW49e2NvbmZpcm19IHRpdGxlPVwiTmfhu6tuZyBiw6FuIHPhuqNuIHBo4bqpbVwiIGNvbmZpcm1MYWJlbD1cIk5n4burbmcgYsOhbiBz4bqjbiBwaOG6qW1cIiBkZXNjcmlwdGlvbj17YFPhuqNuIHBo4bqpbSAke3Byb2R1Y3QuZGF0YT8uZGF0YS5uYW1lIHx8IFwiXCJ9ICgke3Byb2R1Y3RJZCB8fCBcIlwifSk6IG5n4burbmcgYsOhbiBt4bubaTsgbOG7i2NoIHPhu60gxJHGoW4gaMOgbmcgdsOgIGThu68gbGnhu4d1IMSRw6MgcGjDoXQgc2luaCDEkcaw4bujYyBnaeG7ry5gfSByZXF1aXJlUmVhc29uIG9uQ2xvc2U9eygpID0+IHNldENvbmZpcm0oZmFsc2UpfSBidXN5PXthcmNoaXZlLnBlbmRpbmd9IGVycm9yPXthcmNoaXZlLmVycm9yfSBvbkNvbmZpcm09e2FzeW5jIHJlYXNvbiA9PiB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudCA9IHByb2R1Y3QuZGF0YT8uZGF0YTtcclxuICAgICAgICBpZiAoIXByb2R1Y3RJZCB8fCAhY3VycmVudCkgcmV0dXJuO1xyXG4gICAgICAgIGF3YWl0IGFyY2hpdmUuZXhlY3V0ZSh7IHBhdGg6IHsgcHJvZHVjdElkIH0sIHZlcnNpb246IGN1cnJlbnQudmVyc2lvbiwgYm9keTogeyBleHBlY3RlZFZlcnNpb246IGN1cnJlbnQudmVyc2lvbiwgcmVhc29uIH0gfSk7XHJcbiAgICB9fS8+PC8+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBDYXRlZ29yaWVzUGFnZSgpIHtcclxuICAgIGNvbnN0IGxpc3QgPSB1c2VBcGkoJ2xpc3RDYXRlZ29yaWVzJywgeyBxdWVyeTogdXNlTGlzdFF1ZXJ5KCdsaXN0Q2F0ZWdvcmllcycpIH0pO1xyXG4gICAgY29uc3QgY3JlYXRlID0gdXNlQ29tbWFuZCgnY3JlYXRlQ2F0ZWdvcnknLCBbJ2xpc3RDYXRlZ29yaWVzJ10pO1xyXG4gICAgY29uc3QgdXBkYXRlID0gdXNlQ29tbWFuZCgndXBkYXRlQ2F0ZWdvcnknLCBbJ2xpc3RDYXRlZ29yaWVzJ10pO1xyXG4gICAgY29uc3QgYXJjaGl2ZSA9IHVzZUNvbW1hbmQoJ2FyY2hpdmVDYXRlZ29yeScsIFsnbGlzdENhdGVnb3JpZXMnXSk7XHJcbiAgICBjb25zdCBbZWRpdCwgc2V0RWRpdF0gPSB1c2VTdGF0ZTxDYXRlZ29yeSB8IG51bGwgfCB1bmRlZmluZWQ+KCk7XHJcbiAgICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbcGFyZW50SWQsIHNldFBhcmVudElkXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtyZW1vdmUsIHNldFJlbW92ZV0gPSB1c2VTdGF0ZTxDYXRlZ29yeSB8IG51bGw+KG51bGwpLCBbc2F2ZWRNZXNzYWdlLCBzZXRTYXZlZE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgY2F0ZWdvcnlEZXRhaWwgPSB1c2VBcGkoJ2dldENhdGVnb3J5JywgeyBwYXRoOiB7IGNhdGVnb3J5SWQ6IGVkaXQ/LmlkIHx8ICcnIH0gfSwgISFlZGl0Py5pZCk7XHJcbiAgICBjb25zdCB3YWl0aW5nRm9yRGV0YWlsID0gQm9vbGVhbihlZGl0Py5pZCAmJiBjYXRlZ29yeURldGFpbC5kYXRhPy5kYXRhLmlkICE9PSBlZGl0LmlkKTtcclxuICAgIGNvbnN0IGRldGFpbCA9IGVkaXQ/LmlkICYmIGNhdGVnb3J5RGV0YWlsLmRhdGE/LmRhdGEuaWQgPT09IGVkaXQuaWQgPyBjYXRlZ29yeURldGFpbC5kYXRhLmRhdGEgOiBlZGl0O1xyXG4gICAgY29uc3QgY2F0ZWdvcnlFZGl0b3IgPSB1c2VWZXJzaW9uZWREcmFmdCh7XHJcbiAgICAgICAgaWRlbnRpdHk6IGAke3VzZVNjb3BlKCkuc2hvcC5pZH06Y2F0ZWdvcnk6JHtlZGl0Py5pZCB8fCAnbmV3J31gLFxyXG4gICAgICAgIHNvdXJjZTogZGV0YWlsID8geyB2ZXJzaW9uOiBkZXRhaWwudmVyc2lvbiwgdmFsdWVzOiB7IG5hbWU6IGRldGFpbC5uYW1lLCBwYXJlbnRJZDogZGV0YWlsLnBhcmVudElkIHx8ICcnIH0gfSA6IHVuZGVmaW5lZCxcclxuICAgICAgICBkcmFmdDogeyBuYW1lLCBwYXJlbnRJZCB9LCBhcHBseTogdmFsdWVzID0+IHsgc2V0TmFtZSh2YWx1ZXMubmFtZSk7IHNldFBhcmVudElkKHZhbHVlcy5wYXJlbnRJZCk7IH0sXHJcbiAgICAgICAgcmVmcmVzaDogKCkgPT4gY2F0ZWdvcnlEZXRhaWwucmVmZXRjaCh7IHRocm93T25FcnJvcjogdHJ1ZSB9KSxcclxuICAgIH0pO1xyXG4gICAgY29uc3Qgb3BlbiA9IChjOiBDYXRlZ29yeSB8IG51bGwpID0+IHsgc2V0U2F2ZWRNZXNzYWdlKCcnKTsgc2V0TmFtZShjPy5uYW1lIHx8ICcnKTsgc2V0UGFyZW50SWQoYz8ucGFyZW50SWQgfHwgJycpOyBzZXRFZGl0KGMpOyB9O1xyXG4gICAgcmV0dXJuIDw+PFBhZ2VIZWFkZXIgdGl0bGU9XCJEYW5oIG3hu6VjXCIgc3VidGl0bGU9XCJT4bqvcCB44bq/cCBz4bqjbiBwaOG6qW0sIGtow7RuZyB0aGF5IMSR4buVaSB04buTbiBraG8uXCIgYWN0aW9ucz17PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJjYXRhbG9nLndyaXRlXCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9eygpID0+IG9wZW4obnVsbCl9PlRow6ptIGRhbmggbeG7pWM8L011dGF0aW9uQnV0dG9uPn0vPntzYXZlZE1lc3NhZ2UgJiYgPEFsZXJ0IHNldmVyaXR5PVwic3VjY2Vzc1wiIHJvbGU9XCJzdGF0dXNcIiBzeD17bGF5b3V0U3gubm90aWNlLmFmdGVyR2FwfT57c2F2ZWRNZXNzYWdlfTwvQWxlcnQ+fTxQYW5lbD48VG9vbGJhciBvcGVyYXRpb249XCJsaXN0Q2F0ZWdvcmllc1wiIC8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGEgJiYgPD48RGF0YVRhYmxlIGxhYmVsPVwiRGFuaCBzw6FjaCBkYW5oIG3hu6VjXCIgcm93cz17bGlzdC5kYXRhLmRhdGF9IHJvd0tleT17YyA9PiBjLmlkfSBjb2x1bW5zPXtbXHJcbiAgICAgICAgeyBrZXk6ICduYW1lJywgbGFiZWw6ICdUw6puIGRhbmggbeG7pWMnLCByZW5kZXI6IGMgPT4gYy5uYW1lIH0sIHsga2V5OiAncGFyZW50JywgbGFiZWw6ICdEYW5oIG3hu6VjIGNoYScsIHJlbmRlcjogYyA9PiBsaXN0LmRhdGE/LmRhdGEuZmluZChwID0+IHAuaWQgPT09IGMucGFyZW50SWQpPy5uYW1lIHx8ICfigJQnIH0sIHsga2V5OiAnc3RhdGUnLCBsYWJlbDogJ1Ry4bqhbmcgdGjDoWknLCByZW5kZXI6IGMgPT4gPFN0YXR1cyB2YWx1ZT17Yy5hY3RpdmUgPyAnYWN0aXZlJyA6ICdkaXNhYmxlZCd9Lz4gfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiBjID0+IDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImNhdGFsb2cud3JpdGVcIiBvbkNsaWNrPXsoKSA9PiBvcGVuKGMpfT5T4butYTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJjYXRhbG9nLndyaXRlXCIgY29sb3I9XCJlcnJvclwiIG9uQ2xpY2s9eygpID0+IHNldFJlbW92ZShjKX0+Tmfhu6tuZyBkw7luZzwvTXV0YXRpb25CdXR0b24+PC9TdGFjaz5cclxuICAgICAgICB9XHJcbiAgICBdfS8+PFBhZ2VyIHBhZ2U9e2xpc3QuZGF0YS5wYWdlfS8+PC8+fTwvUXVlcnlTdGF0ZT48L1BhbmVsPlxyXG4gPEVkaXREaWFsb2cgYWxsb3dFZGl0c1doaWxlQnVzeSBvcGVuPXtlZGl0ICE9PSB1bmRlZmluZWR9IHRpdGxlPXtlZGl0ID8gJ1Phu61hIGRhbmggbeG7pWMnIDogJ1Row6ptIGRhbmggbeG7pWMnfSBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0KHVuZGVmaW5lZCl9IGJ1c3k9e2NyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nIHx8IHdhaXRpbmdGb3JEZXRhaWx9IGFjdGlvbnM9ezxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGRpc2FibGVkPXshbmFtZS50cmltKCkgfHwgY3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmcgfHwgd2FpdGluZ0ZvckRldGFpbH0gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xyXG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZCA9IHsgbmFtZSwgcGFyZW50SWQgfTtcclxuICAgICAgICBjb25zdCBib2R5ID0geyBuYW1lOiBuYW1lLnRyaW0oKSwgcGFyZW50SWQ6IHBhcmVudElkIHx8IG51bGwgfTtcclxuICAgICAgICBsZXQgcmVzdWx0OiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZS5leGVjdXRlPj47XHJcbiAgICAgICAgaWYgKGVkaXQpIHtcclxuICAgICAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBjYXRlZ29yeUVkaXRvci5wcmVwYXJlKCk7IGlmICghcHJlcGFyZWQgfHwgIU9iamVjdC5rZXlzKHByZXBhcmVkLnBhdGNoKS5sZW5ndGgpIHJldHVybjtcclxuICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgdXBkYXRlLmV4ZWN1dGUoeyBwYXRoOiB7IGNhdGVnb3J5SWQ6IGVkaXQuaWQgfSwgdmVyc2lvbjogcHJlcGFyZWQudmVyc2lvbiwgYm9keToge1xyXG4gICAgICAgICAgICAgICAgLi4uKHByZXBhcmVkLnBhdGNoLm5hbWUgIT09IHVuZGVmaW5lZCA/IHsgbmFtZTogYm9keS5uYW1lIH0gOiB7fSksXHJcbiAgICAgICAgICAgICAgICAuLi4ocHJlcGFyZWQucGF0Y2gucGFyZW50SWQgIT09IHVuZGVmaW5lZCA/IHsgcGFyZW50SWQ6IGJvZHkucGFyZW50SWQgfSA6IHt9KSxcclxuICAgICAgICAgICAgfSB9KTtcclxuICAgICAgICB9IGVsc2UgcmVzdWx0ID0gYXdhaXQgY3JlYXRlLmV4ZWN1dGUoeyBib2R5IH0pO1xyXG4gICAgICAgIGNvbnN0IGNsZWFuID0gY2F0ZWdvcnlFZGl0b3IuY29tbWl0dGVkKHsgdmVyc2lvbjogcmVzdWx0LmRhdGEudmVyc2lvbiwgdmFsdWVzOiB7IG5hbWU6IHJlc3VsdC5kYXRhLm5hbWUsIHBhcmVudElkOiByZXN1bHQuZGF0YS5wYXJlbnRJZCB8fCAnJyB9IH0sIHN1Ym1pdHRlZCwgYCR7cmVzdWx0LmRhdGEuc2hvcElkfTpjYXRlZ29yeToke3Jlc3VsdC5kYXRhLmlkfWApO1xyXG4gICAgICAgIHNldFNhdmVkTWVzc2FnZShjbGVhbiA/IGDEkMOjIGzGsHUgZGFuaCBt4bulYyDigJwke3Jlc3VsdC5kYXRhLm5hbWV94oCdLmAgOiBgxJDDoyBsxrB1IGRhbmggbeG7pWMg4oCcJHtyZXN1bHQuZGF0YS5uYW1lfeKAnTsgdGhheSDEkeG7lWkgbeG7m2kgduG6q24gY2jGsGEgxJHGsOG7o2MgbMawdS5gKTtcbiAgICAgICAgc2V0RWRpdChjbGVhbiA/IHVuZGVmaW5lZCA6IHJlc3VsdC5kYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoIChlcnJvcikgeyBjYXRlZ29yeUVkaXRvci5mYWlsZWQoZXJyb3IpOyB9IH19PkzGsHU8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17Y3JlYXRlLmVycm9yIHx8IHVwZGF0ZS5lcnJvcn0vPjxEcmFmdENvbmZsaWN0IGVkaXRvcj17Y2F0ZWdvcnlFZGl0b3J9IGxhYmVscz17eyBuYW1lOiAnVMOqbiBkYW5oIG3hu6VjJywgcGFyZW50SWQ6ICdEYW5oIG3hu6VjIGNoYScgfX0gYnVzeT17Y3JlYXRlLnBlbmRpbmcgfHwgdXBkYXRlLnBlbmRpbmd9Lz57ZWRpdD8uaWQgJiYgd2FpdGluZ0ZvckRldGFpbCAmJiA8QWxlcnQgc2V2ZXJpdHk9e2NhdGVnb3J5RGV0YWlsLmVycm9yID8gJ2Vycm9yJyA6ICdpbmZvJ30gYWN0aW9uPXtjYXRlZ29yeURldGFpbC5lcnJvciA/IDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4gdm9pZCBjYXRlZ29yeURldGFpbC5yZWZldGNoKCl9PlRo4butIGzhuqFpPC9CdXR0b24+IDogdW5kZWZpbmVkfT57Y2F0ZWdvcnlEZXRhaWwuZXJyb3IgPyAnS2jDtG5nIHThuqNpIMSRxrDhu6NjIGNoaSB0aeG6v3QgZGFuaCBt4bulYzsgZOG7ryBsaeG7h3Ugbmjhuq1wIHbhuqtuIMSRxrDhu6NjIGdp4buvLiBIw6N5IHRo4butIGzhuqFpLicgOiAnxJBhbmcgdOG6o2kgY2hpIHRp4bq/dCBkYW5oIG3hu6VjIHRyxrDhu5tjIGtoaSBjaG8gcGjDqXAgY2jhu4luaCBz4butYS4nfTwvQWxlcnQ+fTxGb3JtRmllbGRzIGRlbnNpdHk9XCJjb21wYWN0XCI+PFRleHRGaWVsZCBsYWJlbD1cIlTDqm5cIiB2YWx1ZT17bmFtZX0gb25DaGFuZ2U9e2UgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9IGRpc2FibGVkPXt3YWl0aW5nRm9yRGV0YWlsfS8+PFRleHRGaWVsZCBsYWJlbD1cIkRhbmggbeG7pWMgY2hhXCIgc2VsZWN0IHZhbHVlPXtwYXJlbnRJZH0gb25DaGFuZ2U9e2UgPT4gc2V0UGFyZW50SWQoZS50YXJnZXQudmFsdWUpfSBkaXNhYmxlZD17d2FpdGluZ0ZvckRldGFpbH0+PE1lbnVJdGVtIHZhbHVlPVwiXCI+S2jDtG5nIGPDszwvTWVudUl0ZW0+e2xpc3QuZGF0YT8uZGF0YS5maWx0ZXIoYyA9PiBjLmlkICE9PSBlZGl0Py5pZCkubWFwKGMgPT4gPE1lbnVJdGVtIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PntjLm5hbWV9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjwvRm9ybUZpZWxkcz48L0VkaXREaWFsb2c+XHJcbiA8Q29uZmlybURpYWxvZyBvcGVuPXshIXJlbW92ZX0gdGl0bGU9XCJOZ+G7q25nIGTDuW5nIGRhbmggbeG7pWNcIiBjb25maXJtTGFiZWw9XCJOZ+G7q25nIGTDuW5nIGRhbmggbeG7pWNcIiBkZXNjcmlwdGlvbj17YERhbmggbeG7pWMgJHtyZW1vdmU/Lm5hbWUgfHwgXCJcIn0gKCR7cmVtb3ZlPy5pZCB8fCBcIlwifSk6IG5n4burbmcgZMO5bmcgdHJvbmcgbOG7sWEgY2jhu41uIG3hu5tpOyBraMO0bmcgeMOzYSBz4bqjbiBwaOG6qW0gaG/hurdjIGzhu4tjaCBz4butLmB9IHJlcXVpcmVSZWFzb24gb25DbG9zZT17KCkgPT4gc2V0UmVtb3ZlKG51bGwpfSBlcnJvcj17YXJjaGl2ZS5lcnJvcn0gYnVzeT17YXJjaGl2ZS5wZW5kaW5nfSBvbkNvbmZpcm09e3JlYXNvbiA9PiBhcmNoaXZlLmV4ZWN1dGUoeyBwYXRoOiB7IGNhdGVnb3J5SWQ6IHJlbW92ZT8uaWQgfHwgJycgfSwgdmVyc2lvbjogcmVtb3ZlPy52ZXJzaW9uLCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogcmVtb3ZlPy52ZXJzaW9uIHx8IDEsIHJlYXNvbiB9IH0pfS8+PC8+O1xyXG59XHJcblxyXG5leHBvcnQgeyBJbXBvcnRzUGFnZSwgSW1wb3J0UmVzdWx0UGFnZSB9IGZyb20gJy4vaW1wb3J0cyc7XHJcblxyXG5mdW5jdGlvbiBwcm9kdWN0U25hcHNob3QocHJvZHVjdDogUHJvZHVjdCkge1xyXG4gICAgY29uc3QgdmFsdWVzOiBQcm9kdWN0RmllbGRzICYgeyBpbWFnZUZpbGVJZHM6IHN0cmluZ1tdIH0gPSB7XHJcbiAgICAgICAgbmFtZTogcHJvZHVjdC5uYW1lLCBkZXNjcmlwdGlvbjogcHJvZHVjdC5kZXNjcmlwdGlvbiwgY2F0ZWdvcnlJZDogcHJvZHVjdC5jYXRlZ29yeUlkIHx8ICcnLCBzdGF0dXM6IHByb2R1Y3Quc3RhdHVzID09PSAnYWN0aXZlJyA/ICdhY3RpdmUnIDogJ2RyYWZ0JyxcclxuICAgICAgICB2YXJpYW50czogcHJvZHVjdC52YXJpYW50cy5tYXAodiA9PiAoeyBpZDogdi5pZCwgc2t1OiB2LnNrdSwgbmFtZTogdi5uYW1lLCBvcHRpb25zOiB2Lm9wdGlvbnMsIHByaWNlOiB2LnByaWNlPy5hbW91bnQgfHwgJycsIGFjdGl2ZTogdi5hY3RpdmUgfSkpLCBpbWFnZUZpbGVJZHM6IHByb2R1Y3QuaW1hZ2VGaWxlSWRzLFxyXG4gICAgfTtcclxuICAgIHJldHVybiB7IHZlcnNpb246IHByb2R1Y3QudmVyc2lvbiwgdmFsdWVzIH07XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvY2F0YWxvZy9pbmRleC50c3gifQ==