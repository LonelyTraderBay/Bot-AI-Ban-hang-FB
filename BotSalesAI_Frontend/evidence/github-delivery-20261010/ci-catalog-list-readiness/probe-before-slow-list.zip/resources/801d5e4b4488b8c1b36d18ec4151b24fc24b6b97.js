"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-TJQ5SMJY.js?v=a69f6c0e";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-YVU6SLE6.js?v=a69f6c0e";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-TQYMLHGU.js?v=a69f6c0e";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-FJYLEWCQ.js?v=a69f6c0e";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-QF5IVN5P.js?v=a69f6c0e";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-QU3FZV7L.js?v=a69f6c0e";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/chunk-PX6F3LHL.js?v=a69f6c0e";

// ../../node_modules/@mui/icons-material/esm/DeleteOutlineRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var DeleteOutlineRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2zM9 9h6c.55 0 1 .45 1 1v8c0 .55-.45 1-1 1H9c-.55 0-1-.45-1-1v-8c0-.55.45-1 1-1m6.5-5-.71-.71c-.18-.18-.44-.29-.7-.29H9.91c-.26 0-.52.11-.7.29L8.5 4H6c-.55 0-1 .45-1 1s.45 1 1 1h12c.55 0 1-.45 1-1s-.45-1-1-1z"
}), "DeleteOutlineRounded");
export {
  DeleteOutlineRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_DeleteOutlineRounded.js.map
