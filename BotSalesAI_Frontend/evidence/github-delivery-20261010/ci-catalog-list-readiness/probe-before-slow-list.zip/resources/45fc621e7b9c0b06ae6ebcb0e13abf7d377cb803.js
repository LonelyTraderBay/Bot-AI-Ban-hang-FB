import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/catalog/imports.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "demo", "PROD": false, "SSR": false, "VITE_APP_NAME": "BotSales AI", "VITE_WEB_PUSH_PUBLIC_KEY": ""};import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react_jsx-dev-runtime.js?v=11faa885"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { FieldGroup, FormFields } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react.js?v=11faa885"; const useState = __vite__cjsImport4_react["useState"];
import { useNavigate, useParams } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/react-router-dom.js?v=85ce2841";
import { Alert, Box, Button, MenuItem, TextField, Typography } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-22956-a19ae72e-d6fb-4740-82ee-f8b52994ad5b/deps/@mui_material.js?v=8caac895";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { PRODUCT_IMPORT_MAX_BYTES, productImportFileError } from "/src/modules/catalog/import-file.ts";
import { dateTime } from "/src/shared/model/format.ts";
import { label } from "/src/shared/model/labels.ts";
import { ConfirmDialog, DataTable, DetailLine, ErrorNotice, MutationButton, PageHeader, Pager, Panel, QueryState, RouteLink, Status } from "/src/shared/ui/components.tsx";
export function ImportsPage() {
  _s();
  const { shop } = useScope();
  const nav = useNavigate();
  const jobs = useApi("listJobs", { query: { limit: 20, sort: "-createdAt" } });
  const upload = useCommand("uploadFile", []);
  const dry = useCommand("createProductImport", ["listJobs"]);
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState("");
  const [strategy, setStrategy] = useState("reject");
  const [mapping, setMapping] = useState(
    [
      { sourceColumn: "sku", targetField: "sku" },
      { sourceColumn: "name", targetField: "name" },
      { sourceColumn: "price", targetField: "price" },
      { sourceColumn: "description", targetField: "description" },
      { sourceColumn: "currency", targetField: "currency" }
    ]
  );
  const targets = ["sku", "name", "description", "category", "price", "currency", "variantName"];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhập dữ liệu sản phẩm", subtitle: "Tải tệp → ánh xạ cột → kiểm tra trước → xác nhận các dòng hợp lệ." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Tệp & ánh xạ", bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%", minWidth: 0 }, children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: upload.error || dry.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 54,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Trong demo mô phỏng: CSV UTF-8 tối đa 5 MB và 1.000 dòng dữ liệu. Khi nối backend thật, giới hạn được lấy từ API." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 56,
          columnNumber: 34
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", component: "label", children: [
          file ? file.name : "Chọn CSV UTF-8",
          /* @__PURE__ */ jsxDEV("input", { hidden: true, type: "file", accept: ".csv,text/csv", "aria-describedby": fileError ? "product-import-file-error" : void 0, onChange: (event) => {
            const input = event.currentTarget;
            const next = input.files?.[0] || null;
            const error = productImportFileError(next, __MOCK__ ? PRODUCT_IMPORT_MAX_BYTES : void 0);
            setFileError(error);
            setFile(error ? null : next);
            if (error)
              input.value = "";
          } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 59,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 57,
          columnNumber: 21
        }, this),
        fileError && /* @__PURE__ */ jsxDEV(Alert, { id: "product-import-file-error", severity: "error", role: "alert", children: fileError }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 69,
          columnNumber: 35
        }, this),
        /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "center" }, children: [
          /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Mẫu CSV tổng hợp để kiểm tra import. XLSX chưa có parser được chốt; chuyển sang CSV, không đổi đuôi tệp." }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 71,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { component: "a", href: import.meta.env.BASE_URL + "samples/products.csv", download: "botsales-products.csv", size: "small", children: "Tải CSV mẫu" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 72,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 70,
          columnNumber: 21
        }, this),
        mapping.map((item, index) => /* @__PURE__ */ jsxDEV(FieldGroup, { direction: { xs: "column", sm: "row" }, alignItems: { xs: "stretch", sm: "start" }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Tên cột trong tệp", value: item.sourceColumn, onChange: (event) => setMapping(mapping.map((value, itemIndex) => itemIndex === index ? { ...value, sourceColumn: event.target.value } : value)), sx: { flex: 1, minWidth: 0 } }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 75,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Trường sản phẩm", value: item.targetField, onChange: (event) => {
            const value = targets.find((target) => target === event.target.value);
            if (value)
              setMapping(mapping.map((entry, itemIndex) => itemIndex === index ? { ...entry, targetField: value } : entry));
          }, sx: { flex: 1, minWidth: 0 }, children: targets.map((target) => /* @__PURE__ */ jsxDEV(MenuItem, { value: target, children: target }, target, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 81,
            columnNumber: 54
          }, this)) }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 76,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { color: "error", onClick: () => setMapping(mapping.filter((_, itemIndex) => itemIndex !== index)), children: "Bỏ" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 83,
            columnNumber: 25
          }, this)
        ] }, index, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 74,
          columnNumber: 51
        }, this)),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => setMapping([...mapping, { sourceColumn: "", targetField: "variantName" }]), children: "Thêm cột" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 85,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Khi trùng SKU", value: strategy, onChange: (event) => setStrategy(event.target.value === "update_existing" ? "update_existing" : "reject"), children: [
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "reject", children: "Từ chối dòng trùng" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 87,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(MenuItem, { value: "update_existing", children: "Cập nhật SKU có sẵn sau xác nhận" }, void 0, false, {
            fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
            lineNumber: 88,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 86,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.import", variant: "contained", busy: upload.pending || dry.pending, disabled: !file || mapping.some((item) => !item.sourceColumn), onClick: async () => {
          if (!file)
            return;
          try {
            const form = new FormData();
            form.append("file", file);
            form.append("purpose", "product_import");
            const uploaded = await upload.execute({ form });
            const result = await dry.execute({ body: { fileId: uploaded.data.id, mapping, duplicateStrategy: strategy, dryRun: true } });
            nav("/s/" + shop.id + "/imports/" + result.data.id);
          } catch {
          }
        }, children: "Kiểm tra trước khi nhập" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 90,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 55,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 53,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 52,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Panel, { title: "Tác vụ gần đây", subtitle: "Tình trạng xử lý do API trả về; dữ liệu mẫu chỉ chạy trong bộ nhớ.", beforeGap: "section", children: /* @__PURE__ */ jsxDEV(QueryState, { query: jobs, pendingProfile: "section", children: jobs.data && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Tác vụ nền gần đây", rows: jobs.data.data, rowKey: (job) => job.id, empty: "Chưa có tác vụ nhập. Chọn tệp ở biểu mẫu phía trên để bắt đầu.", columns: [
        { key: "kind", label: "Loại tác vụ", render: (job) => label(job.kind) },
        { key: "id", label: "Mã tác vụ", render: (job) => job.id },
        { key: "status", label: "Trạng thái", render: (job) => /* @__PURE__ */ jsxDEV(Status, { value: job.status }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 114,
          columnNumber: 66
        }, this) },
        { key: "progress", label: "Đã xử lý", render: (job) => String(job.completed) + " / " + (job.total ?? "Chưa rõ") },
        { key: "errors", label: "Dòng lỗi", render: (job) => job.errorCount },
        { key: "updatedAt", label: "Cập nhật", render: (job) => dateTime(job.updatedAt, shop.timezone) },
        { key: "action", label: "", render: (job) => /* @__PURE__ */ jsxDEV(RouteLink, { to: job.kind === "import" ? "/s/" + shop.id + "/imports/" + job.id : "/s/" + shop.id + "/jobs/" + job.id, children: "Xem kết quả" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
          lineNumber: 118,
          columnNumber: 56
        }, this) }
      ] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 111,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Pager, { page: jobs.data.page }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 120,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 110,
      columnNumber: 31
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 109,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 108,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
}
_s(ImportsPage, "54yK/nIlGFYL3IRryheg6IsL/l0=", false, function() {
  return [useScope, useNavigate, useApi, useCommand, useCommand];
});
_c = ImportsPage;
export function ImportResultPage() {
  _s2();
  const { shop } = useScope();
  const { jobId = "" } = useParams();
  const job = useApi("getJob", { path: { jobId } });
  const commit = useCommand("commitProductImport", ["getJob", "listJobs", "listProducts", "listStockSnapshots"]);
  const [confirm, setConfirm] = useState(false);
  const j = job.data?.data;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Kết quả kiểm tra tệp", subtitle: "Không nhập dữ liệu âm thầm khi còn lỗi; token kiểm tra gắn với phiên bản dữ liệu.", actions: /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/imports`, children: "Danh sách tác vụ" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 155
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: job, pendingProfile: "section", children: j && /* @__PURE__ */ jsxDEV(Panel, { title: j.id, action: /* @__PURE__ */ jsxDEV(Status, { value: j.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 310
    }, this), bodyMode: "inset", children: /* @__PURE__ */ jsxDEV(FormFields, { children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: commit.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 368
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Đã xử lý", children: [
        j.completed,
        " / ",
        j.total ?? "Chưa rõ"
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 404
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lỗi", children: j.errorCount }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 484
      }, this),
      /* @__PURE__ */ jsxDEV(DataTable, { label: "Lỗi từng dòng trong tệp nhập", rows: j.rowErrors.map((e, i) => ({ ...e, key: String(i) })), rowKey: (e) => e.key, empty: "Không có dòng lỗi trong báo cáo kiểm tra.", columns: [{ key: "row", label: "Dòng", render: (e) => e.row }, { key: "field", label: "Cột", render: (e) => e.field }, { key: "message", label: "Lỗi", render: (e) => e.message }] }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 535
      }, this),
      j.validationToken && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Xác nhận chỉ nhập những dòng đã hợp lệ. Dòng lỗi được giữ trong báo cáo, không coi là nhập thành công." }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 920
      }, this),
      /* @__PURE__ */ jsxDEV(MutationButton, { permission: "catalog.import", variant: "contained", disabled: !j.validationToken || j.status !== "awaiting_confirmation", onClick: () => setConfirm(true), children: "Xác nhận nhập các dòng hợp lệ" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 1054
      }, this),
      /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/imports`, children: "Chọn tệp khác" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
        lineNumber: 133,
        columnNumber: 1267
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 356
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 282
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 227
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: confirm, title: "Ghi dữ liệu đã kiểm tra", confirmLabel: "Nhập các dòng hợp lệ", description: `Tệp đã kiểm trong công việc ${jobId}: chỉ ghi các dòng hợp lệ; dòng lỗi không được nhập. Nếu danh mục đã thay đổi, phải kiểm tra tệp lại.`, onClose: () => setConfirm(false), error: commit.error, busy: commit.pending, onConfirm: () => commit.execute({ path: { jobId }, body: { validationToken: j?.validationToken || "", confirmValidRowsOnly: true } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
      lineNumber: 133,
      columnNumber: 1367
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx",
    lineNumber: 133,
    columnNumber: 10
  }, this);
}
_s2(ImportResultPage, "cc2FcHG1EtPRz7erdwGK1cpRUgA=", false, function() {
  return [useScope, useParams, useApi, useCommand];
});
_c2 = ImportResultPage;
var _c, _c2;
$RefreshReg$(_c, "ImportsPage");
$RefreshReg$(_c2, "ImportResultPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/catalog/imports.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JRLFNBMkRzQixVQTNEdEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBL0JSLFNBQVNBLFlBQVlDLGtCQUFrQjtBQUN2QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLE9BQU9DLEtBQUtDLFFBQVFDLFVBQVVDLFdBQVdDLGtCQUFrQjtBQUVwRSxTQUFTQyxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLDBCQUEwQkMsOEJBQThCO0FBQ2pFLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGVBQWVDLFdBQVdDLFlBQVlDLGFBQWFDLGdCQUFnQkMsWUFBWUMsT0FBT0MsT0FBT0MsWUFBWUMsV0FBV0MsY0FBYztBQUNwSSxnQkFBU0MsY0FBYztBQUFBQyxLQUFBO0FBQzFCLFFBQU0sRUFBRUMsS0FBSyxJQUFJbEIsU0FBUztBQUMxQixRQUFNbUIsTUFBTTdCLFlBQVk7QUFDeEIsUUFBTThCLE9BQU90QixPQUFPLFlBQVksRUFBRXVCLE9BQU8sRUFBRUMsT0FBTyxJQUFJQyxNQUFNLGFBQWEsRUFBRSxDQUFDO0FBQzVFLFFBQU1DLFNBQVN6QixXQUFXLGNBQWMsRUFBRTtBQUMxQyxRQUFNMEIsTUFBTTFCLFdBQVcsdUJBQXVCLENBQUMsVUFBVSxDQUFDO0FBQzFELFFBQU0sQ0FBQzJCLE1BQU1DLE9BQU8sSUFBSXRDLFNBQXNCLElBQUk7QUFDbEQsUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lDLFVBQVVDLFdBQVcsSUFBSTFDLFNBQXVDLFFBQVE7QUFDL0UsUUFBTSxDQUFDMkMsU0FBU0MsVUFBVSxJQUFJNUM7QUFBQUEsSUFBMEI7QUFBQSxNQUNwRCxFQUFFNkMsY0FBYyxPQUFPQyxhQUFhLE1BQU07QUFBQSxNQUMxQyxFQUFFRCxjQUFjLFFBQVFDLGFBQWEsT0FBTztBQUFBLE1BQzVDLEVBQUVELGNBQWMsU0FBU0MsYUFBYSxRQUFRO0FBQUEsTUFDOUMsRUFBRUQsY0FBYyxlQUFlQyxhQUFhLGNBQWM7QUFBQSxNQUMxRCxFQUFFRCxjQUFjLFlBQVlDLGFBQWEsV0FBVztBQUFBLElBQUM7QUFBQSxFQUN4RDtBQUNELFFBQU1DLFVBQTBDLENBQUMsT0FBTyxRQUFRLGVBQWUsWUFBWSxTQUFTLFlBQVksYUFBYTtBQUU3SCxTQUFPLG1DQUNIO0FBQUEsMkJBQUMsY0FBVyxPQUFNLHlCQUF3QixVQUFTLHVFQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNIO0FBQUEsSUFDdEgsdUJBQUMsU0FBTSxPQUFNLGdCQUFlLFVBQVMsU0FDakMsaUNBQUMsT0FBSSxJQUFJLEVBQUVDLE9BQU8sUUFBUUMsVUFBVSxFQUFFLEdBQ2xDO0FBQUEsNkJBQUMsZUFBWSxPQUFPZCxPQUFPZSxTQUFTZCxJQUFJYyxTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsTUFDOUMsdUJBQUMsY0FDSUM7QUFBQUEsb0JBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8saUlBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0k7QUFBQSxRQUNySix1QkFBQyxVQUFPLFNBQVEsWUFBVyxXQUFVLFNBQ2hDZDtBQUFBQSxpQkFBT0EsS0FBS2UsT0FBTztBQUFBLFVBQ3BCLHVCQUFDLFdBQU0sUUFBTSxNQUFDLE1BQUssUUFBTyxRQUFPLGlCQUFnQixvQkFBa0JiLFlBQVksOEJBQThCYyxRQUFXLFVBQVUsQ0FBQUMsVUFBUztBQUN2SSxrQkFBTUMsUUFBUUQsTUFBTUU7QUFDcEIsa0JBQU1DLE9BQU9GLE1BQU1HLFFBQVEsQ0FBQyxLQUFLO0FBQ2pDLGtCQUFNUixRQUFRckMsdUJBQXVCNEMsTUFBTU4sV0FBV3ZDLDJCQUEyQnlDLE1BQVM7QUFDMUZiLHlCQUFhVSxLQUFLO0FBQ2xCWixvQkFBUVksUUFBUSxPQUFPTyxJQUFJO0FBQzNCLGdCQUFJUDtBQUNBSyxvQkFBTUksUUFBUTtBQUFBLFVBQ3RCLEtBUkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRRTtBQUFBLGFBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQ3BCLGFBQWEsdUJBQUMsU0FBTSxJQUFHLDZCQUE0QixVQUFTLFNBQVEsTUFBSyxTQUFTQSx1QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBQzdGLHVCQUFDLGNBQVcsV0FBVyxFQUFFcUIsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBSSxZQUFZLEVBQUVELElBQUksV0FBV0MsSUFBSSxTQUFTLEdBQzNGO0FBQUEsaUNBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBaUIsd0hBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJKO0FBQUEsVUFDM0osdUJBQUMsVUFBTyxXQUFVLEtBQUksTUFBTUMsWUFBWUMsSUFBSUMsV0FBVyx3QkFBd0IsVUFBUyx5QkFBd0IsTUFBSyxTQUFRLDJCQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3STtBQUFBLGFBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0NyQixRQUFRc0IsSUFBSSxDQUFDQyxNQUFNQyxVQUFVLHVCQUFDLGNBQXVCLFdBQVcsRUFBRVAsSUFBSSxVQUFVQyxJQUFJLE1BQU0sR0FBRyxZQUFZLEVBQUVELElBQUksV0FBV0MsSUFBSSxRQUFRLEdBQ25JO0FBQUEsaUNBQUMsYUFBVSxPQUFNLHFCQUFvQixPQUFPSyxLQUFLckIsY0FBYyxVQUFVLENBQUFTLFVBQVNWLFdBQVdELFFBQVFzQixJQUFJLENBQUNOLE9BQU9TLGNBQWNBLGNBQWNELFFBQVEsRUFBRSxHQUFHUixPQUFPZCxjQUFjUyxNQUFNZSxPQUFPVixNQUFNLElBQUlBLEtBQUssQ0FBQyxHQUFHLElBQUksRUFBRVcsTUFBTSxHQUFHckIsVUFBVSxFQUFFLEtBQTFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRPO0FBQUEsVUFDNU8sdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxtQkFBa0IsT0FBT2lCLEtBQUtwQixhQUFhLFVBQVUsQ0FBQVEsVUFBUztBQUNsRixrQkFBTUssUUFBUVosUUFBUXdCLEtBQUssQ0FBQUYsV0FBVUEsV0FBV2YsTUFBTWUsT0FBT1YsS0FBSztBQUNsRSxnQkFBSUE7QUFDQWYseUJBQVdELFFBQVFzQixJQUFJLENBQUNPLE9BQU9KLGNBQWNBLGNBQWNELFFBQVEsRUFBRSxHQUFHSyxPQUFPMUIsYUFBYWEsTUFBTSxJQUFJYSxLQUFLLENBQUM7QUFBQSxVQUNwSCxHQUFHLElBQUksRUFBRUYsTUFBTSxHQUFHckIsVUFBVSxFQUFFLEdBQ3pCRixrQkFBUWtCLElBQUksQ0FBQUksV0FBVSx1QkFBQyxZQUFTLE9BQU9BLFFBQXNCQSxvQkFBVEEsUUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEMsQ0FBVyxLQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE9BQU0sU0FBUSxTQUFTLE1BQU16QixXQUFXRCxRQUFROEIsT0FBTyxDQUFDQyxHQUFHTixjQUFjQSxjQUFjRCxLQUFLLENBQUMsR0FBRyxrQkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxhQVQvREEsT0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVU5QixDQUFhO0FBQUEsUUFDYix1QkFBQyxVQUFPLFNBQVMsTUFBTXZCLFdBQVcsQ0FBQyxHQUFHRCxTQUFTLEVBQUVFLGNBQWMsSUFBSUMsYUFBYSxjQUFjLENBQUMsQ0FBQyxHQUFHLHdCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJHO0FBQUEsUUFDM0csdUJBQUMsYUFBVSxRQUFNLE1BQUMsT0FBTSxpQkFBZ0IsT0FBT0wsVUFBVSxVQUFVLENBQUFhLFVBQVNaLFlBQVlZLE1BQU1lLE9BQU9WLFVBQVUsb0JBQW9CLG9CQUFvQixRQUFRLEdBQzNKO0FBQUEsaUNBQUMsWUFBUyxPQUFNLFVBQVMsa0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFDM0MsdUJBQUMsWUFBUyxPQUFNLG1CQUFrQixnREFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxhQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGtCQUFlLFlBQVcsa0JBQWlCLFNBQVEsYUFBWSxNQUFNeEIsT0FBT3dDLFdBQVd2QyxJQUFJdUMsU0FBUyxVQUFVLENBQUN0QyxRQUFRTSxRQUFRaUMsS0FBSyxDQUFBVixTQUFRLENBQUNBLEtBQUtyQixZQUFZLEdBQUcsU0FBUyxZQUFZO0FBQ25MLGNBQUksQ0FBQ1I7QUFDRDtBQUNKLGNBQUk7QUFDQSxrQkFBTXdDLE9BQU8sSUFBSUMsU0FBUztBQUMxQkQsaUJBQUtFLE9BQU8sUUFBUTFDLElBQUk7QUFDeEJ3QyxpQkFBS0UsT0FBTyxXQUFXLGdCQUFnQjtBQUN2QyxrQkFBTUMsV0FBVyxNQUFNN0MsT0FBTzhDLFFBQVEsRUFBRUosS0FBSyxDQUFDO0FBQzlDLGtCQUFNSyxTQUFTLE1BQU05QyxJQUFJNkMsUUFBUSxFQUFFRSxNQUFNLEVBQUVDLFFBQVFKLFNBQVNLLEtBQUtDLElBQUkzQyxTQUFTNEMsbUJBQW1COUMsVUFBVStDLFFBQVEsS0FBSyxFQUFFLENBQUM7QUFDM0gxRCxnQkFBSSxRQUFRRCxLQUFLeUQsS0FBSyxjQUFjSixPQUFPRyxLQUFLQyxFQUFFO0FBQUEsVUFDdEQsUUFDTTtBQUFBLFVBQ0Y7QUFBQSxRQUVSLEdBQUcsdUNBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWMwQjtBQUFBLFdBakQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsU0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQSxLQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdURBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLE9BQU0sa0JBQWlCLFVBQVMsc0VBQXFFLFdBQVcsV0FDbkgsaUNBQUMsY0FBVyxPQUFPdkQsTUFBTSxnQkFBZSxXQUNuQ0EsZUFBS3NELFFBQVEsbUNBQ1Y7QUFBQSw2QkFBQyxhQUFVLE9BQU0sc0JBQXFCLE1BQU10RCxLQUFLc0QsS0FBS0EsTUFBTSxRQUFRLENBQUFJLFFBQU9BLElBQUlILElBQUksT0FBTSxrRUFBaUUsU0FBUztBQUFBLFFBQy9KLEVBQUVJLEtBQUssUUFBUTNFLE9BQU8sZUFBZTRFLFFBQVFBLENBQUFGLFFBQU8xRSxNQUFNMEUsSUFBSUcsSUFBSSxFQUFFO0FBQUEsUUFDcEUsRUFBRUYsS0FBSyxNQUFNM0UsT0FBTyxhQUFhNEUsUUFBUUEsQ0FBQUYsUUFBT0EsSUFBSUgsR0FBRztBQUFBLFFBQ3ZELEVBQUVJLEtBQUssVUFBVTNFLE9BQU8sY0FBYzRFLFFBQVFBLENBQUFGLFFBQU8sdUJBQUMsVUFBTyxPQUFPQSxJQUFJSSxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLEVBQUk7QUFBQSxRQUNuRixFQUFFSCxLQUFLLFlBQVkzRSxPQUFPLFlBQVk0RSxRQUFRQSxDQUFBRixRQUFPSyxPQUFPTCxJQUFJTSxTQUFTLElBQUksU0FBU04sSUFBSU8sU0FBUyxXQUFXO0FBQUEsUUFDOUcsRUFBRU4sS0FBSyxVQUFVM0UsT0FBTyxZQUFZNEUsUUFBUUEsQ0FBQUYsUUFBT0EsSUFBSVEsV0FBVztBQUFBLFFBQ2xFLEVBQUVQLEtBQUssYUFBYTNFLE9BQU8sWUFBWTRFLFFBQVFBLENBQUFGLFFBQU8zRSxTQUFTMkUsSUFBSVMsV0FBV3JFLEtBQUtzRSxRQUFRLEVBQUU7QUFBQSxRQUM3RixFQUFFVCxLQUFLLFVBQVUzRSxPQUFPLElBQUk0RSxRQUFRQSxDQUFBRixRQUFPLHVCQUFDLGFBQVUsSUFBSUEsSUFBSUcsU0FBUyxXQUFXLFFBQVEvRCxLQUFLeUQsS0FBSyxjQUFjRyxJQUFJSCxLQUFLLFFBQVF6RCxLQUFLeUQsS0FBSyxXQUFXRyxJQUFJSCxJQUFJLDJCQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdJLEVBQWE7QUFBQSxNQUFDLEtBUDdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRRTtBQUFBLE1BQ0YsdUJBQUMsU0FBTSxNQUFNdkQsS0FBS3NELEtBQUtlLFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQVZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV2QsS0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxPQXpFRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEVQO0FBQ0o7QUFBQ3hFLEdBN0ZlRCxhQUFXO0FBQUEsVUFDTmhCLFVBQ0xWLGFBQ0NRLFFBQ0VDLFlBQ0hBLFVBQVU7QUFBQTtBQUFBLEtBTFZpQjtBQThGVCxnQkFBUzBFLG1CQUFtQjtBQUFBQyxNQUFBO0FBQy9CLFFBQU0sRUFBRXpFLEtBQUssSUFBSWxCLFNBQVM7QUFDMUIsUUFBTSxFQUFFNEYsUUFBUSxHQUFHLElBQUlyRyxVQUFVO0FBQ2pDLFFBQU11RixNQUFNaEYsT0FBTyxVQUFVLEVBQUUrRixNQUFNLEVBQUVELE1BQU0sRUFBRSxDQUFDO0FBQ2hELFFBQU1FLFNBQVMvRixXQUFXLHVCQUF1QixDQUFDLFVBQVUsWUFBWSxnQkFBZ0Isb0JBQW9CLENBQUM7QUFDN0csUUFBTSxDQUFDZ0csU0FBU0MsVUFBVSxJQUFJM0csU0FBUyxLQUFLO0FBQzVDLFFBQU00RyxJQUFJbkIsSUFBSUosTUFBTUE7QUFDcEIsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSx3QkFBdUIsVUFBUyxxRkFBb0YsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTXhELEtBQUt5RCxFQUFFLFlBQVksZ0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0QsS0FBdk07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvTjtBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPRyxLQUFLLGdCQUFlLFdBQVdtQixlQUFLLHVCQUFDLFNBQU0sT0FBT0EsRUFBRXRCLElBQUksUUFBUSx1QkFBQyxVQUFPLE9BQU9zQixFQUFFZixVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCLEdBQUksVUFBUyxTQUFRLGlDQUFDLGNBQVk7QUFBQSw2QkFBQyxlQUFZLE9BQU9ZLE9BQU92RCxTQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFBRSx1QkFBQyxjQUFXLE9BQU0sWUFBWTBEO0FBQUFBLFVBQUViO0FBQUFBLFFBQVU7QUFBQSxRQUFJYSxFQUFFWixTQUFTO0FBQUEsV0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLE9BQU9ZLFlBQUVYLGNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUFhLHVCQUFDLGFBQVUsT0FBTSxnQ0FBK0IsTUFBTVcsRUFBRUMsVUFBVTVDLElBQUksQ0FBQzZDLEdBQUdDLE9BQU8sRUFBRSxHQUFHRCxHQUFHcEIsS0FBS0ksT0FBT2lCLENBQUMsRUFBRSxFQUFFLEdBQUcsUUFBUSxDQUFBRCxNQUFLQSxFQUFFcEIsS0FBSyxPQUFNLDZDQUE0QyxTQUFTLENBQUMsRUFBRUEsS0FBSyxPQUFPM0UsT0FBTyxRQUFRNEUsUUFBUUEsQ0FBQW1CLE1BQUtBLEVBQUVFLElBQUksR0FBRyxFQUFFdEIsS0FBSyxTQUFTM0UsT0FBTyxPQUFPNEUsUUFBUUEsQ0FBQW1CLE1BQUtBLEVBQUVHLE1BQU0sR0FBRyxFQUFFdkIsS0FBSyxXQUFXM0UsT0FBTyxPQUFPNEUsUUFBUUEsQ0FBQW1CLE1BQUtBLEVBQUVJLFFBQVEsQ0FBQyxLQUE5VjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdXO0FBQUEsTUFBR04sRUFBRU8sbUJBQW1CLHVCQUFDLFNBQU0sVUFBUyxRQUFPLHNIQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZIO0FBQUEsTUFBUyx1QkFBQyxrQkFBZSxZQUFXLGtCQUFpQixTQUFRLGFBQVksVUFBVSxDQUFDUCxFQUFFTyxtQkFBbUJQLEVBQUVmLFdBQVcseUJBQXlCLFNBQVMsTUFBTWMsV0FBVyxJQUFJLEdBQUcsNkNBQXZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb007QUFBQSxNQUFpQix1QkFBQyxhQUFVLElBQUksTUFBTTlFLEtBQUt5RCxFQUFFLFlBQVksNkJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUEzN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1OEIsS0FBaGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNmhDLEtBQXBsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZsQztBQUFBLElBQWEsdUJBQUMsaUJBQWMsTUFBTW9CLFNBQVMsT0FBTSwyQkFBMEIsY0FBYSx3QkFBdUIsYUFBYSwrQkFBK0JILEtBQUsseUdBQXlHLFNBQVMsTUFBTUksV0FBVyxLQUFLLEdBQUcsT0FBT0YsT0FBT3ZELE9BQU8sTUFBTXVELE9BQU85QixTQUFTLFdBQVcsTUFBTThCLE9BQU94QixRQUFRLEVBQUV1QixNQUFNLEVBQUVELE1BQU0sR0FBR3BCLE1BQU0sRUFBRWdDLGlCQUFpQlAsR0FBR08sbUJBQW1CLElBQUlDLHNCQUFzQixLQUFLLEVBQUUsQ0FBQyxLQUE3YztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStjO0FBQUEsT0FBanhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbXhEO0FBQzl4RDtBQUFDZCxJQVJlRCxrQkFBZ0I7QUFBQSxVQUNYMUYsVUFDTVQsV0FDWE8sUUFDR0MsVUFBVTtBQUFBO0FBQUEsTUFKYjJGO0FBQWdCLElBQUFnQixJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiRmllbGRHcm91cCIsIkZvcm1GaWVsZHMiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwiQWxlcnQiLCJCb3giLCJCdXR0b24iLCJNZW51SXRlbSIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJ1c2VBcGkiLCJ1c2VDb21tYW5kIiwidXNlU2NvcGUiLCJQUk9EVUNUX0lNUE9SVF9NQVhfQllURVMiLCJwcm9kdWN0SW1wb3J0RmlsZUVycm9yIiwiZGF0ZVRpbWUiLCJsYWJlbCIsIkNvbmZpcm1EaWFsb2ciLCJEYXRhVGFibGUiLCJEZXRhaWxMaW5lIiwiRXJyb3JOb3RpY2UiLCJNdXRhdGlvbkJ1dHRvbiIsIlBhZ2VIZWFkZXIiLCJQYWdlciIsIlBhbmVsIiwiUXVlcnlTdGF0ZSIsIlJvdXRlTGluayIsIlN0YXR1cyIsIkltcG9ydHNQYWdlIiwiX3MiLCJzaG9wIiwibmF2Iiwiam9icyIsInF1ZXJ5IiwibGltaXQiLCJzb3J0IiwidXBsb2FkIiwiZHJ5IiwiZmlsZSIsInNldEZpbGUiLCJmaWxlRXJyb3IiLCJzZXRGaWxlRXJyb3IiLCJzdHJhdGVneSIsInNldFN0cmF0ZWd5IiwibWFwcGluZyIsInNldE1hcHBpbmciLCJzb3VyY2VDb2x1bW4iLCJ0YXJnZXRGaWVsZCIsInRhcmdldHMiLCJ3aWR0aCIsIm1pbldpZHRoIiwiZXJyb3IiLCJfX01PQ0tfXyIsIm5hbWUiLCJ1bmRlZmluZWQiLCJldmVudCIsImlucHV0IiwiY3VycmVudFRhcmdldCIsIm5leHQiLCJmaWxlcyIsInZhbHVlIiwieHMiLCJzbSIsImltcG9ydCIsImVudiIsIkJBU0VfVVJMIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaXRlbUluZGV4IiwidGFyZ2V0IiwiZmxleCIsImZpbmQiLCJlbnRyeSIsImZpbHRlciIsIl8iLCJwZW5kaW5nIiwic29tZSIsImZvcm0iLCJGb3JtRGF0YSIsImFwcGVuZCIsInVwbG9hZGVkIiwiZXhlY3V0ZSIsInJlc3VsdCIsImJvZHkiLCJmaWxlSWQiLCJkYXRhIiwiaWQiLCJkdXBsaWNhdGVTdHJhdGVneSIsImRyeVJ1biIsImpvYiIsImtleSIsInJlbmRlciIsImtpbmQiLCJzdGF0dXMiLCJTdHJpbmciLCJjb21wbGV0ZWQiLCJ0b3RhbCIsImVycm9yQ291bnQiLCJ1cGRhdGVkQXQiLCJ0aW1lem9uZSIsInBhZ2UiLCJJbXBvcnRSZXN1bHRQYWdlIiwiX3MyIiwiam9iSWQiLCJwYXRoIiwiY29tbWl0IiwiY29uZmlybSIsInNldENvbmZpcm0iLCJqIiwicm93RXJyb3JzIiwiZSIsImkiLCJyb3ciLCJmaWVsZCIsIm1lc3NhZ2UiLCJ2YWxpZGF0aW9uVG9rZW4iLCJjb25maXJtVmFsaWRSb3dzT25seSIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImltcG9ydHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpZWxkR3JvdXAsIEZvcm1GaWVsZHMgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyBBbGVydCwgQm94LCBCdXR0b24sIE1lbnVJdGVtLCBUZXh0RmllbGQsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcclxuaW1wb3J0IHR5cGUgeyBDb2x1bW5NYXBwaW5nIH0gZnJvbSAnQGJvdHNhbGVzL2NvbnRyYWN0cyc7XHJcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJy4uLy4uL3NoYXJlZC9hcGkvaG9va3MnO1xyXG5pbXBvcnQgeyB1c2VTY29wZSB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb2RlbC9zY29wZSc7XHJcblxyXG5pbXBvcnQgeyBQUk9EVUNUX0lNUE9SVF9NQVhfQllURVMsIHByb2R1Y3RJbXBvcnRGaWxlRXJyb3IgfSBmcm9tICcuL2ltcG9ydC1maWxlJztcclxuaW1wb3J0IHsgZGF0ZVRpbWUgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvZm9ybWF0JztcclxuaW1wb3J0IHsgbGFiZWwgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvbGFiZWxzJztcclxuaW1wb3J0IHsgQ29uZmlybURpYWxvZywgRGF0YVRhYmxlLCBEZXRhaWxMaW5lLCBFcnJvck5vdGljZSwgTXV0YXRpb25CdXR0b24sIFBhZ2VIZWFkZXIsIFBhZ2VyLCBQYW5lbCwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0dXMgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9uZW50cyc7XHJcbmV4cG9ydCBmdW5jdGlvbiBJbXBvcnRzUGFnZSgpIHtcclxuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcclxuICAgIGNvbnN0IG5hdiA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgICBjb25zdCBqb2JzID0gdXNlQXBpKCdsaXN0Sm9icycsIHsgcXVlcnk6IHsgbGltaXQ6IDIwLCBzb3J0OiAnLWNyZWF0ZWRBdCcgfSB9KTtcclxuICAgIGNvbnN0IHVwbG9hZCA9IHVzZUNvbW1hbmQoJ3VwbG9hZEZpbGUnLCBbXSk7XHJcbiAgICBjb25zdCBkcnkgPSB1c2VDb21tYW5kKCdjcmVhdGVQcm9kdWN0SW1wb3J0JywgWydsaXN0Sm9icyddKTtcclxuICAgIGNvbnN0IFtmaWxlLCBzZXRGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKTtcclxuICAgIGNvbnN0IFtmaWxlRXJyb3IsIHNldEZpbGVFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbc3RyYXRlZ3ksIHNldFN0cmF0ZWd5XSA9IHVzZVN0YXRlPCdyZWplY3QnIHwgJ3VwZGF0ZV9leGlzdGluZyc+KCdyZWplY3QnKTtcclxuICAgIGNvbnN0IFttYXBwaW5nLCBzZXRNYXBwaW5nXSA9IHVzZVN0YXRlPENvbHVtbk1hcHBpbmdbXT4oW1xyXG4gICAgICAgIHsgc291cmNlQ29sdW1uOiAnc2t1JywgdGFyZ2V0RmllbGQ6ICdza3UnIH0sXHJcbiAgICAgICAgeyBzb3VyY2VDb2x1bW46ICduYW1lJywgdGFyZ2V0RmllbGQ6ICduYW1lJyB9LFxyXG4gICAgICAgIHsgc291cmNlQ29sdW1uOiAncHJpY2UnLCB0YXJnZXRGaWVsZDogJ3ByaWNlJyB9LFxyXG4gICAgICAgIHsgc291cmNlQ29sdW1uOiAnZGVzY3JpcHRpb24nLCB0YXJnZXRGaWVsZDogJ2Rlc2NyaXB0aW9uJyB9LFxyXG4gICAgICAgIHsgc291cmNlQ29sdW1uOiAnY3VycmVuY3knLCB0YXJnZXRGaWVsZDogJ2N1cnJlbmN5JyB9LFxyXG4gICAgXSk7XHJcbiAgICBjb25zdCB0YXJnZXRzOiBDb2x1bW5NYXBwaW5nWyd0YXJnZXRGaWVsZCddW10gPSBbJ3NrdScsICduYW1lJywgJ2Rlc2NyaXB0aW9uJywgJ2NhdGVnb3J5JywgJ3ByaWNlJywgJ2N1cnJlbmN5JywgJ3ZhcmlhbnROYW1lJ107XHJcblxyXG4gICAgcmV0dXJuIDw+XHJcbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJOaOG6rXAgZOG7ryBsaeG7h3Ugc+G6o24gcGjhuqltXCIgc3VidGl0bGU9XCJU4bqjaSB04buHcCDihpIgw6FuaCB44bqhIGPhu5l0IOKGkiBraeG7g20gdHJhIHRyxrDhu5tjIOKGkiB4w6FjIG5o4bqtbiBjw6FjIGTDsm5nIGjhu6NwIGzhu4cuXCIgLz5cclxuICAgICAgICA8UGFuZWwgdGl0bGU9XCJU4buHcCAmIMOhbmggeOG6oVwiIGJvZHlNb2RlPVwiaW5zZXRcIj5cclxuICAgICAgICAgICAgPEJveCBzeD17eyB3aWR0aDogJzEwMCUnLCBtaW5XaWR0aDogMCB9fT5cclxuICAgICAgICAgICAgICAgIDxFcnJvck5vdGljZSBlcnJvcj17dXBsb2FkLmVycm9yIHx8IGRyeS5lcnJvcn0gLz5cclxuICAgICAgICAgICAgICAgIDxGb3JtRmllbGRzID5cclxuICAgICAgICAgICAgICAgICAgICB7X19NT0NLX18gJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlRyb25nIGRlbW8gbcO0IHBo4buPbmc6IENTViBVVEYtOCB04buRaSDEkWEgNSBNQiB2w6AgMS4wMDAgZMOybmcgZOG7ryBsaeG7h3UuIEtoaSBu4buRaSBiYWNrZW5kIHRo4bqtdCwgZ2nhu5tpIGjhuqFuIMSRxrDhu6NjIGzhuqV5IHThu6sgQVBJLjwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVkXCIgY29tcG9uZW50PVwibGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbGUgPyBmaWxlLm5hbWUgOiAnQ2jhu41uIENTViBVVEYtOCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBoaWRkZW4gdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCIuY3N2LHRleHQvY3N2XCIgYXJpYS1kZXNjcmliZWRieT17ZmlsZUVycm9yID8gJ3Byb2R1Y3QtaW1wb3J0LWZpbGUtZXJyb3InIDogdW5kZWZpbmVkfSBvbkNoYW5nZT17ZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5wdXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV4dCA9IGlucHV0LmZpbGVzPy5bMF0gfHwgbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gcHJvZHVjdEltcG9ydEZpbGVFcnJvcihuZXh0LCBfX01PQ0tfXyA/IFBST0RVQ1RfSU1QT1JUX01BWF9CWVRFUyA6IHVuZGVmaW5lZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWxlRXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RmlsZShlcnJvciA/IG51bGwgOiBuZXh0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dC52YWx1ZSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWxlRXJyb3IgJiYgPEFsZXJ0IGlkPVwicHJvZHVjdC1pbXBvcnQtZmlsZS1lcnJvclwiIHNldmVyaXR5PVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57ZmlsZUVycm9yfTwvQWxlcnQ+fVxyXG4gICAgICAgICAgICAgICAgICAgIDxGaWVsZEdyb3VwIGRpcmVjdGlvbj17eyB4czogJ2NvbHVtbicsIHNtOiAncm93JyB9fSAgYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5N4bqrdSBDU1YgdOG7lW5nIGjhu6NwIMSR4buDIGtp4buDbSB0cmEgaW1wb3J0LiBYTFNYIGNoxrBhIGPDsyBwYXJzZXIgxJHGsOG7o2MgY2jhu5F0OyBjaHV54buDbiBzYW5nIENTViwga2jDtG5nIMSR4buVaSDEkXXDtGkgdOG7h3AuPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGNvbXBvbmVudD1cImFcIiBocmVmPXtpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkwgKyAnc2FtcGxlcy9wcm9kdWN0cy5jc3YnfSBkb3dubG9hZD1cImJvdHNhbGVzLXByb2R1Y3RzLmNzdlwiIHNpemU9XCJzbWFsbFwiPlThuqNpIENTViBt4bqrdTwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRmllbGRHcm91cD5cclxuICAgICAgICAgICAgICAgICAgICB7bWFwcGluZy5tYXAoKGl0ZW0sIGluZGV4KSA9PiA8RmllbGRHcm91cCBrZXk9e2luZGV4fSBkaXJlY3Rpb249e3sgeHM6ICdjb2x1bW4nLCBzbTogJ3JvdycgfX0gYWxpZ25JdGVtcz17eyB4czogJ3N0cmV0Y2gnLCBzbTogJ3N0YXJ0JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZCBsYWJlbD1cIlTDqm4gY+G7mXQgdHJvbmcgdOG7h3BcIiB2YWx1ZT17aXRlbS5zb3VyY2VDb2x1bW59IG9uQ2hhbmdlPXtldmVudCA9PiBzZXRNYXBwaW5nKG1hcHBpbmcubWFwKCh2YWx1ZSwgaXRlbUluZGV4KSA9PiBpdGVtSW5kZXggPT09IGluZGV4ID8geyAuLi52YWx1ZSwgc291cmNlQ29sdW1uOiBldmVudC50YXJnZXQudmFsdWUgfSA6IHZhbHVlKSl9IHN4PXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGQgc2VsZWN0IGxhYmVsPVwiVHLGsOG7nW5nIHPhuqNuIHBo4bqpbVwiIHZhbHVlPXtpdGVtLnRhcmdldEZpZWxkfSBvbkNoYW5nZT17ZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSB0YXJnZXRzLmZpbmQodGFyZ2V0ID0+IHRhcmdldCA9PT0gZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNYXBwaW5nKG1hcHBpbmcubWFwKChlbnRyeSwgaXRlbUluZGV4KSA9PiBpdGVtSW5kZXggPT09IGluZGV4ID8geyAuLi5lbnRyeSwgdGFyZ2V0RmllbGQ6IHZhbHVlIH0gOiBlbnRyeSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSBzeD17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXRzLm1hcCh0YXJnZXQgPT4gPE1lbnVJdGVtIHZhbHVlPXt0YXJnZXR9IGtleT17dGFyZ2V0fT57dGFyZ2V0fTwvTWVudUl0ZW0+KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gY29sb3I9XCJlcnJvclwiIG9uQ2xpY2s9eygpID0+IHNldE1hcHBpbmcobWFwcGluZy5maWx0ZXIoKF8sIGl0ZW1JbmRleCkgPT4gaXRlbUluZGV4ICE9PSBpbmRleCkpfT5C4buPPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9GaWVsZEdyb3VwPil9XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRNYXBwaW5nKFsuLi5tYXBwaW5nLCB7IHNvdXJjZUNvbHVtbjogJycsIHRhcmdldEZpZWxkOiAndmFyaWFudE5hbWUnIH1dKX0+VGjDqm0gY+G7mXQ8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkIHNlbGVjdCBsYWJlbD1cIktoaSB0csO5bmcgU0tVXCIgdmFsdWU9e3N0cmF0ZWd5fSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0U3RyYXRlZ3koZXZlbnQudGFyZ2V0LnZhbHVlID09PSAndXBkYXRlX2V4aXN0aW5nJyA/ICd1cGRhdGVfZXhpc3RpbmcnIDogJ3JlamVjdCcpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwicmVqZWN0XCI+VOG7qyBjaOG7kWkgZMOybmcgdHLDuW5nPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwidXBkYXRlX2V4aXN0aW5nXCI+Q+G6rXAgbmjhuq10IFNLVSBjw7Mgc+G6tW4gc2F1IHjDoWMgbmjhuq1uPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L1RleHRGaWVsZD5cclxuICAgICAgICAgICAgICAgICAgICA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImNhdGFsb2cuaW1wb3J0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiIGJ1c3k9e3VwbG9hZC5wZW5kaW5nIHx8IGRyeS5wZW5kaW5nfSBkaXNhYmxlZD17IWZpbGUgfHwgbWFwcGluZy5zb21lKGl0ZW0gPT4gIWl0ZW0uc291cmNlQ29sdW1uKX0gb25DbGljaz17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWZpbGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybS5hcHBlbmQoJ3B1cnBvc2UnLCAncHJvZHVjdF9pbXBvcnQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwbG9hZGVkID0gYXdhaXQgdXBsb2FkLmV4ZWN1dGUoeyBmb3JtIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZHJ5LmV4ZWN1dGUoeyBib2R5OiB7IGZpbGVJZDogdXBsb2FkZWQuZGF0YS5pZCwgbWFwcGluZywgZHVwbGljYXRlU3RyYXRlZ3k6IHN0cmF0ZWd5LCBkcnlSdW46IHRydWUgfSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hdignL3MvJyArIHNob3AuaWQgKyAnL2ltcG9ydHMvJyArIHJlc3VsdC5kYXRhLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRjaCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFcnJvck5vdGljZSBrZWVwcyB0aGUgdXBsb2FkIGFuZCB2YWxpZGF0aW9uIGZhaWx1cmUgdmlzaWJsZS5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH19Pktp4buDbSB0cmEgdHLGsOG7m2Mga2hpIG5o4bqtcDwvTXV0YXRpb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm1GaWVsZHM+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvUGFuZWw+XHJcbiAgICAgICAgPFBhbmVsIHRpdGxlPVwiVMOhYyB24bulIGfhuqduIMSRw6J5XCIgc3VidGl0bGU9XCJUw6xuaCB0cuG6oW5nIHjhu60gbMO9IGRvIEFQSSB0cuG6oyB24buBOyBk4buvIGxp4buHdSBt4bqrdSBjaOG7iSBjaOG6oXkgdHJvbmcgYuG7mSBuaOG7my5cIiBiZWZvcmVHYXA9e1wic2VjdGlvblwifT5cclxuICAgICAgICAgICAgPFF1ZXJ5U3RhdGUgcXVlcnk9e2pvYnN9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAge2pvYnMuZGF0YSAmJiA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgbGFiZWw9XCJUw6FjIHbhu6UgbuG7gW4gZ+G6p24gxJHDonlcIiByb3dzPXtqb2JzLmRhdGEuZGF0YX0gcm93S2V5PXtqb2IgPT4gam9iLmlkfSBlbXB0eT1cIkNoxrBhIGPDsyB0w6FjIHbhu6Ugbmjhuq1wLiBDaOG7jW4gdOG7h3Ag4bufIGJp4buDdSBt4bqrdSBwaMOtYSB0csOqbiDEkeG7gyBi4bqvdCDEkeG6p3UuXCIgY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2tpbmQnLCBsYWJlbDogJ0xv4bqhaSB0w6FjIHbhu6UnLCByZW5kZXI6IGpvYiA9PiBsYWJlbChqb2Iua2luZCkgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnTcOjIHTDoWMgduG7pScsIHJlbmRlcjogam9iID0+IGpvYi5pZCB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3N0YXR1cycsIGxhYmVsOiAnVHLhuqFuZyB0aMOhaScsIHJlbmRlcjogam9iID0+IDxTdGF0dXMgdmFsdWU9e2pvYi5zdGF0dXN9IC8+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAncHJvZ3Jlc3MnLCBsYWJlbDogJ8SQw6MgeOG7rSBsw70nLCByZW5kZXI6IGpvYiA9PiBTdHJpbmcoam9iLmNvbXBsZXRlZCkgKyAnIC8gJyArIChqb2IudG90YWwgPz8gJ0NoxrBhIHLDtScpIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXJyb3JzJywgbGFiZWw6ICdEw7JuZyBs4buXaScsIHJlbmRlcjogam9iID0+IGpvYi5lcnJvckNvdW50IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAndXBkYXRlZEF0JywgbGFiZWw6ICdD4bqtcCBuaOG6rXQnLCByZW5kZXI6IGpvYiA9PiBkYXRlVGltZShqb2IudXBkYXRlZEF0LCBzaG9wLnRpbWV6b25lKSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ2FjdGlvbicsIGxhYmVsOiAnJywgcmVuZGVyOiBqb2IgPT4gPFJvdXRlTGluayB0bz17am9iLmtpbmQgPT09ICdpbXBvcnQnID8gJy9zLycgKyBzaG9wLmlkICsgJy9pbXBvcnRzLycgKyBqb2IuaWQgOiAnL3MvJyArIHNob3AuaWQgKyAnL2pvYnMvJyArIGpvYi5pZH0+WGVtIGvhur90IHF14bqjPC9Sb3V0ZUxpbms+IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8UGFnZXIgcGFnZT17am9icy5kYXRhLnBhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICA8Lz59XHJcbiAgICAgICAgICAgIDwvUXVlcnlTdGF0ZT5cclxuICAgICAgICA8L1BhbmVsPlxyXG4gICAgPC8+O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBJbXBvcnRSZXN1bHRQYWdlKCkge1xyXG4gICAgY29uc3QgeyBzaG9wIH0gPSB1c2VTY29wZSgpO1xyXG4gICAgY29uc3QgeyBqb2JJZCA9ICcnIH0gPSB1c2VQYXJhbXMoKTtcclxuICAgIGNvbnN0IGpvYiA9IHVzZUFwaSgnZ2V0Sm9iJywgeyBwYXRoOiB7IGpvYklkIH0gfSk7XHJcbiAgICBjb25zdCBjb21taXQgPSB1c2VDb21tYW5kKCdjb21taXRQcm9kdWN0SW1wb3J0JywgWydnZXRKb2InLCAnbGlzdEpvYnMnLCAnbGlzdFByb2R1Y3RzJywgJ2xpc3RTdG9ja1NuYXBzaG90cyddKTtcclxuICAgIGNvbnN0IFtjb25maXJtLCBzZXRDb25maXJtXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IGogPSBqb2IuZGF0YT8uZGF0YTtcclxuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiS+G6v3QgcXXhuqMga2nhu4NtIHRyYSB04buHcFwiIHN1YnRpdGxlPVwiS2jDtG5nIG5o4bqtcCBk4buvIGxp4buHdSDDom0gdGjhuqdtIGtoaSBjw7JuIGzhu5dpOyB0b2tlbiBraeG7g20gdHJhIGfhuq9uIHbhu5tpIHBoacOqbiBi4bqjbiBk4buvIGxp4buHdS5cIiBhY3Rpb25zPXs8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9pbXBvcnRzYH0+RGFuaCBzw6FjaCB0w6FjIHbhu6U8L1JvdXRlTGluaz59Lz48UXVlcnlTdGF0ZSBxdWVyeT17am9ifSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57aiAmJiA8UGFuZWwgdGl0bGU9e2ouaWR9IGFjdGlvbj17PFN0YXR1cyB2YWx1ZT17ai5zdGF0dXN9Lz59IGJvZHlNb2RlPVwiaW5zZXRcIj48Rm9ybUZpZWxkcyA+PEVycm9yTm90aWNlIGVycm9yPXtjb21taXQuZXJyb3J9Lz48RGV0YWlsTGluZSBsYWJlbD1cIsSQw6MgeOG7rSBsw71cIj57ai5jb21wbGV0ZWR9IC8ge2oudG90YWwgPz8gJ0NoxrBhIHLDtSd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTOG7l2lcIj57ai5lcnJvckNvdW50fTwvRGV0YWlsTGluZT48RGF0YVRhYmxlIGxhYmVsPVwiTOG7l2kgdOG7q25nIGTDsm5nIHRyb25nIHThu4dwIG5o4bqtcFwiIHJvd3M9e2oucm93RXJyb3JzLm1hcCgoZSwgaSkgPT4gKHsgLi4uZSwga2V5OiBTdHJpbmcoaSkgfSkpfSByb3dLZXk9e2UgPT4gZS5rZXl9IGVtcHR5PVwiS2jDtG5nIGPDsyBkw7JuZyBs4buXaSB0cm9uZyBiw6FvIGPDoW8ga2nhu4NtIHRyYS5cIiBjb2x1bW5zPXtbeyBrZXk6ICdyb3cnLCBsYWJlbDogJ0TDsm5nJywgcmVuZGVyOiBlID0+IGUucm93IH0sIHsga2V5OiAnZmllbGQnLCBsYWJlbDogJ0Phu5l0JywgcmVuZGVyOiBlID0+IGUuZmllbGQgfSwgeyBrZXk6ICdtZXNzYWdlJywgbGFiZWw6ICdM4buXaScsIHJlbmRlcjogZSA9PiBlLm1lc3NhZ2UgfV19Lz57ai52YWxpZGF0aW9uVG9rZW4gJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPljDoWMgbmjhuq1uIGNo4buJIG5o4bqtcCBuaOG7r25nIGTDsm5nIMSRw6MgaOG7o3AgbOG7hy4gRMOybmcgbOG7l2kgxJHGsOG7o2MgZ2nhu68gdHJvbmcgYsOhbyBjw6FvLCBraMO0bmcgY29pIGzDoCBuaOG6rXAgdGjDoG5oIGPDtG5nLjwvQWxlcnQ+fTxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiY2F0YWxvZy5pbXBvcnRcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFqLnZhbGlkYXRpb25Ub2tlbiB8fCBqLnN0YXR1cyAhPT0gJ2F3YWl0aW5nX2NvbmZpcm1hdGlvbid9IG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm0odHJ1ZSl9PljDoWMgbmjhuq1uIG5o4bqtcCBjw6FjIGTDsm5nIGjhu6NwIGzhu4c8L011dGF0aW9uQnV0dG9uPjxSb3V0ZUxpbmsgdG89e2Avcy8ke3Nob3AuaWR9L2ltcG9ydHNgfT5DaOG7jW4gdOG7h3Aga2jDoWM8L1JvdXRlTGluaz48L0Zvcm1GaWVsZHM+PC9QYW5lbD59PC9RdWVyeVN0YXRlPjxDb25maXJtRGlhbG9nIG9wZW49e2NvbmZpcm19IHRpdGxlPVwiR2hpIGThu68gbGnhu4d1IMSRw6Mga2nhu4NtIHRyYVwiIGNvbmZpcm1MYWJlbD1cIk5o4bqtcCBjw6FjIGTDsm5nIGjhu6NwIGzhu4dcIiBkZXNjcmlwdGlvbj17YFThu4dwIMSRw6Mga2nhu4NtIHRyb25nIGPDtG5nIHZp4buHYyAke2pvYklkfTogY2jhu4kgZ2hpIGPDoWMgZMOybmcgaOG7o3AgbOG7hzsgZMOybmcgbOG7l2kga2jDtG5nIMSRxrDhu6NjIG5o4bqtcC4gTuG6v3UgZGFuaCBt4bulYyDEkcOjIHRoYXkgxJHhu5VpLCBwaOG6o2kga2nhu4NtIHRyYSB04buHcCBs4bqhaS5gfSBvbkNsb3NlPXsoKSA9PiBzZXRDb25maXJtKGZhbHNlKX0gZXJyb3I9e2NvbW1pdC5lcnJvcn0gYnVzeT17Y29tbWl0LnBlbmRpbmd9IG9uQ29uZmlybT17KCkgPT4gY29tbWl0LmV4ZWN1dGUoeyBwYXRoOiB7IGpvYklkIH0sIGJvZHk6IHsgdmFsaWRhdGlvblRva2VuOiBqPy52YWxpZGF0aW9uVG9rZW4gfHwgJycsIGNvbmZpcm1WYWxpZFJvd3NPbmx5OiB0cnVlIH0gfSl9Lz48Lz47XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9Kb2tlci1QQy9Eb2N1bWVudHMvUHJvamVjdHMvQm90LUFJLUJhbi1oYW5nLUZCL0JvdFNhbGVzQUlfRnJvbnRlbmQvYXBwcy93ZWIvc3JjL21vZHVsZXMvY2F0YWxvZy9pbXBvcnRzLnRzeCJ9