"use client";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-TJQ5SMJY.js?v=f6dfd721";
import {
  createSvgIcon
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-YVU6SLE6.js?v=f6dfd721";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-TQYMLHGU.js?v=f6dfd721";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-FJYLEWCQ.js?v=f6dfd721";
import {
  require_jsx_runtime
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-QF5IVN5P.js?v=f6dfd721";
import "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-QU3FZV7L.js?v=f6dfd721";
import {
  __toESM
} from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-32184-1c826525-c5ed-412e-8f07-ed954a7758a0/deps/chunk-PX6F3LHL.js?v=f6dfd721";

// ../../node_modules/@mui/icons-material/esm/AddRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var AddRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M18 13h-5v5c0 .55-.45 1-1 1s-1-.45-1-1v-5H6c-.55 0-1-.45-1-1s.45-1 1-1h5V6c0-.55.45-1 1-1s1 .45 1 1v5h5c.55 0 1 .45 1 1s-.45 1-1 1"
}), "AddRounded");
export {
  AddRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_AddRounded.js.map
