"use client";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-TJQ5SMJY.js?v=f9568e8d";
import {
  createSvgIcon
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-BYBKOQBC.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-LTFVV63V.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-UAZB53LO.js?v=f9568e8d";
import {
  require_jsx_runtime
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-YMMUPFRD.js?v=f9568e8d";
import "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-GAYUPZDI.js?v=f9568e8d";
import {
  __toESM
} from "/@fs/tmp/botsales-vite-cache/2fbc71299afedf720605/test-demo/playwright-5663-41250a86-6c09-47fc-b7b7-16a41612dac9/deps/chunk-PX6F3LHL.js?v=f9568e8d";

// ../../node_modules/@mui/icons-material/esm/DeleteOutlineRounded.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var DeleteOutlineRounded_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2zM9 9h6c.55 0 1 .45 1 1v8c0 .55-.45 1-1 1H9c-.55 0-1-.45-1-1v-8c0-.55.45-1 1-1m6.5-5-.71-.71c-.18-.18-.44-.29-.7-.29H9.91c-.26 0-.52.11-.7.29L8.5 4H6c-.55 0-1 .45-1 1s.45 1 1 1h12c.55 0 1-.45 1-1s-.45-1-1-1z"
}), "DeleteOutlineRounded");
export {
  DeleteOutlineRounded_default as default
};
//# sourceMappingURL=@mui_icons-material_DeleteOutlineRounded.js.map
