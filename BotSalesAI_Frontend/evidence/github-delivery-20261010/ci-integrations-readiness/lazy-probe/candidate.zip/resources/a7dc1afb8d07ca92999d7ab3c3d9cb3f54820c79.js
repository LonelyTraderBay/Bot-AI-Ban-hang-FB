import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/modules/integrations/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30580-b16acde8-27bd-4aa8-bc38-cc5356cea86b-integrations-lazy-probe/deps/react_jsx-dev-runtime.js?v=f7d02c73"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ActionGroup, FormFields, PageSections, SectionGrid, SurfaceContent } from "/src/shared/ui/composition.tsx";
import __vite__cjsImport4_react from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30580-b16acde8-27bd-4aa8-bc38-cc5356cea86b-integrations-lazy-probe/deps/react.js?v=f7d02c73"; const useState = __vite__cjsImport4_react["useState"];
import { capabilityName } from "/src/shared/model/labels.ts";
import { layoutSx } from "/src/shared/ui/layout.ts";
import { Alert, Box, Button, Chip, MenuItem, TextField } from "/@fs/C:/Users/Joker-PC/AppData/Local/Temp/botsales-vite-cache/ea27c7577456f6009d55/test-demo/manual-30580-b16acde8-27bd-4aa8-bc38-cc5356cea86b-integrations-lazy-probe/deps/@mui_material.js?v=be86412c";
import { useApi, useCommand } from "/src/shared/api/hooks.ts";
import { useScope } from "/src/shared/model/scope.tsx";
import { limitCodePoints, dateTime } from "/src/shared/model/format.ts";
import { ConfirmDialog, DetailLine, EditDialog, Empty, ErrorNotice, MutationButton, PageHeader, Panel, QueryState, RouteLink, Status } from "/src/shared/ui/components.tsx";
function authorize(url) {
  const target = new URL(url, location.origin);
  if (target.protocol !== "https:" && !(__MOCK__ && target.origin === location.origin))
    throw new Error("Đường dẫn xác thực không dùng HTTPS.");
  location.assign(target.href);
}
export function ChannelsPage() {
  _s();
  const { shop } = useScope();
  const list = useApi("listChannels");
  const connect = useCommand("beginChannelConnect", []), reconnect = useCommand("reconnectChannel", []), disconnect = useCommand("disconnectChannel", ["listChannels"]), check = useCommand("checkChannelHealth", ["listChannels"]);
  const [selected, setSelected] = useState(null), [jobId, setJob] = useState(""), [error, setError] = useState(null);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const connectButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", busy: connect.pending, onClick: () => void start(), children: "Kết nối Page" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 39,
    columnNumber: 25
  }, this);
  const start = async (channelId) => {
    setError(null);
    try {
      const body = { returnPath: `/s/${shop.id}/integrations/channels`, channelKind: "facebook_messenger" };
      const r = channelId ? await reconnect.execute({ path: { channelId }, body }) : await connect.execute({ body });
      authorize(r.data.authorizationUrl);
    } catch (e) {
      setError(e instanceof Error ? e : new Error("Không thể bắt đầu xác thực."));
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Kết nối Facebook", subtitle: "Kết nối bằng luồng cấp quyền. Page token chỉ được giữ ở backend.", actions: !isEmpty && connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: error || connect.error || reconnect.error || check.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 163
    }, this),
    __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "info", sx: layoutSx.notice.afterGap, children: "Đây là mô phỏng. Không đăng nhập Facebook và không gửi tin thật." }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 256
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có Page kết nối. Dùng nút bên dưới để bắt đầu.", action: connectButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 481
    }, this) : /* @__PURE__ */ jsxDEV(PageSections, { children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: __MOCK__ ? /* @__PURE__ */ jsxDEV(Chip, { label: "Mô phỏng, chưa liên kết thật", color: "warning", variant: "outlined" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 686
    }, this) : /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 769
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Page ID", children: c.externalPageId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 803
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Webhook gần nhất", children: dateTime(c.lastWebhookAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 862
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Chính sách", children: c.policyVersion || "Chưa xác minh" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 954
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Kiểm chính sách lúc", children: dateTime(c.policyVerifiedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 1034
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", beforeGap: "surface", afterGap: "notice", children: c.capabilities.map((cap) => /* @__PURE__ */ jsxDEV(Chip, { label: capabilityName(cap), title: cap }, cap, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 1228
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 1132
      }, this),
      c.warnings.map((w) => /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", sx: layoutSx.notice.afterGap, children: w }, w, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 1325
      }, this)),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: check.pending, onClick: async () => {
          try {
            setJob((await check.execute({ path: { channelId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 48,
          columnNumber: 1431
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: reconnect.pending, onClick: () => void start(c.id), children: "Kết nối lại" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 51,
          columnNumber: 70
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setSelected(c), children: "Ngắt kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 51,
          columnNumber: 205
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 48,
        columnNumber: 1402
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 798
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 617
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 575
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 48,
      columnNumber: 382
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Xem kết quả kiểm tra" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 51,
      columnNumber: 397
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!selected, title: "Ngắt kết nối Page", confirmLabel: "Ngắt kết nối Page", description: `Page ${selected?.name || ""} (${selected?.externalPageId || ""}): dừng gửi mới qua kết nối. Lịch sử đơn hàng và hội thoại được giữ; tin đã tiếp nhận không thể thu hồi.`, requireReason: true, onClose: () => setSelected(null), busy: disconnect.pending, error: disconnect.error, onConfirm: (reason) => disconnect.execute({ path: { channelId: selected?.id || "" }, body: { expectedVersion: selected?.version || 1, reason } }) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 51,
      columnNumber: 476
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 48,
    columnNumber: 10
  }, this);
}
_s(ChannelsPage, "ZavHqp2lD+aTYBQU4i5iyqgpR8Q=", false, function() {
  return [useScope, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c = ChannelsPage;
export function AIProvidersPage() {
  _s2();
  const { shop } = useScope();
  const list = useApi("listAIConnections"), catalog = useApi("getProviderCatalog");
  const create = useCommand("createAIConnection", ["listAIConnections"]), update = useCommand("updateAIConnection", ["listAIConnections"]), remove = useCommand("deleteAIConnection", ["listAIConnections"]), test = useCommand("testAIConnection", ["listAIConnections"]);
  const [open, setOpen] = useState(false), [editing, setEditing] = useState(null), [name, setName] = useState(""), [provider, setProvider] = useState(""), [model, setModel] = useState(""), [endpoint, setEndpoint] = useState(""), [key, setKey] = useState(""), [formError, setFormError] = useState(null), [deleting, setDeleting] = useState(null), [jobId, setJob] = useState("");
  const descriptor = catalog.data?.data.find((p) => p.providerId === provider);
  const isEmpty = !list.isError && list.data?.data.length === 0;
  const addConnectionButton = /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", variant: "contained", onClick: () => start(null), children: "Thêm kết nối AI" }, void 0, false, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 60,
    columnNumber: 31
  }, this);
  const start = (connection) => {
    setEditing(connection);
    setName(connection?.name || "");
    setProvider(connection?.providerId || catalog.data?.data[0]?.providerId || "");
    setModel(connection?.modelId || "");
    setEndpoint(connection?.endpointUrl || "");
    setKey("");
    setFormError(null);
    setOpen(true);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Nhà cung cấp AI", subtitle: "Mỗi adapter công bố khả năng; không giả định mọi API key có thể thay thế nhau.", actions: !isEmpty && addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 12
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotice, { error: test.error }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 182
    }, this),
    /* @__PURE__ */ jsxDEV(QueryState, { query: list, pendingProfile: "section", children: list.data?.data.length === 0 && !list.isError ? /* @__PURE__ */ jsxDEV(Empty, { text: "Chưa có kết nối AI. Thêm một kết nối để cấu hình nhà cung cấp.", action: addConnectionButton }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 315
    }, this) : /* @__PURE__ */ jsxDEV(SectionGrid, { columns: { xs: "minmax(0, 1fr)", lg: list.data?.data.length === 1 ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))" }, children: list.data?.data.map((c) => /* @__PURE__ */ jsxDEV(Panel, { title: c.name, bodyMode: "inset", action: /* @__PURE__ */ jsxDEV(Status, { value: c.status }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 643
    }, this), children: /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Provider / adapter", children: [
        c.providerId,
        " / ",
        c.adapterId
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 677
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Model", children: c.modelId }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 759
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Khóa", children: c.hasCredential ? `•••• ${c.keyLast4 || ""}` : "Chưa có" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 809
      }, this),
      /* @__PURE__ */ jsxDEV(DetailLine, { label: "Lần kiểm gần nhất", children: dateTime(c.lastCheckedAt, shop.timezone) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 905
      }, this),
      /* @__PURE__ */ jsxDEV(SurfaceContent, { rhythm: "dividedRows", beforeGap: "surface", afterGap: "notice", children: Object.entries(c.capabilities).filter(([k]) => k !== "lastVerifiedAt").map(([k, v]) => /* @__PURE__ */ jsxDEV(DetailLine, { label: capabilityName(k), children: typeof v === "string" ? /* @__PURE__ */ jsxDEV(Status, { value: v, domain: "capability", density: "compact" }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 1232
      }, this) : "Chưa xác minh" }, k, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 1161
      }, this)) }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 998
      }, this),
      /* @__PURE__ */ jsxDEV(ActionGroup, { direction: "row", children: [
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", onClick: () => start(c), children: "Sửa / xoay khóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 62,
          columnNumber: 1370
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", busy: test.pending, onClick: async () => {
          try {
            setJob((await test.execute({ path: { connectionId: c.id } })).data.id);
          } catch {
          }
        }, children: "Kiểm kết nối" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 62,
          columnNumber: 1476
        }, this),
        /* @__PURE__ */ jsxDEV(MutationButton, { permission: "integrations.manage", color: "error", onClick: () => setDeleting(c), children: "Xóa" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 65,
          columnNumber: 70
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 62,
        columnNumber: 1341
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 672
    }, this) }, c.id, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 585
    }, this)) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 426
    }, this) }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 62,
      columnNumber: 216
    }, this),
    jobId && /* @__PURE__ */ jsxDEV(RouteLink, { to: `/s/${shop.id}/jobs/${jobId}`, children: "Kết quả kiểm tra kết nối" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 65,
      columnNumber: 252
    }, this),
    /* @__PURE__ */ jsxDEV(EditDialog, { open, title: editing ? "Sửa kết nối / xoay khóa" : "Kết nối AI mới", onClose: () => {
      setKey("");
      setFormError(null);
      setOpen(false);
    }, busy: create.pending || update.pending, actions: /* @__PURE__ */ jsxDEV(Button, { variant: "contained", disabled: !name.trim() || !model.trim() || !editing && (!descriptor || !key) || create.pending || update.pending, onClick: async () => {
      setFormError(null);
      const submittedCredential = key;
      try {
        if (__MOCK__ && submittedCredential && !submittedCredential.startsWith("demo-"))
          throw new Error("Chỉ nhập khóa giả bắt đầu bằng demo- trong bản mô phỏng.");
        if (editing)
          await update.execute({ path: { connectionId: editing.id }, version: editing.version, body: { name: name.trim(), modelId: model.trim(), ...submittedCredential ? { credential: submittedCredential } : {} } });
        else
          await create.execute({ body: { name: name.trim(), providerId: provider, adapterId: descriptor?.adapterId || "", modelId: model.trim(), endpointUrl: endpoint || null, credential: submittedCredential } });
        setOpen(false);
      } catch (e) {
        const message = e instanceof Error ? e.message : "Không lưu được cấu hình kết nối.";
        setFormError(new Error(submittedCredential && message.includes(submittedCredential) ? message.replaceAll(submittedCredential, "[đã ẩn]") : message));
      } finally {
        setKey("");
      }
    }, children: "Lưu cấu hình" }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 66,
      columnNumber: 202
    }, this), children: [
      /* @__PURE__ */ jsxDEV(ErrorNotice, { error: formError || create.error || update.error }, void 0, false, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 85,
        columnNumber: 31
      }, this),
      /* @__PURE__ */ jsxDEV(FormFields, { children: [
        __MOCK__ && /* @__PURE__ */ jsxDEV(Alert, { severity: "warning", children: "Không nhập khóa thật. Dùng demo-key; request mô phỏng chỉ kiểm tra giao diện, không giữ khóa và không kết nối AI thật." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 121
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Tên kết nối", value: name, onChange: (e) => setName(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 274
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { select: true, label: "Provider đã có adapter", value: provider, disabled: !!editing, onChange: (e) => {
          setProvider(e.target.value);
          setModel("");
        }, children: catalog.data?.data.map((p) => /* @__PURE__ */ jsxDEV(MenuItem, { value: p.providerId, children: p.label }, p.providerId, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 542
        }, this)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 362
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: "Model ID được adapter hỗ trợ", value: model, onChange: (e) => setModel(e.target.value), helperText: descriptor?.models.map((m) => m.modelId).join(", ") || "Xem catalog từ backend" }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 626
        }, this),
        !editing && descriptor?.endpointEditable && /* @__PURE__ */ jsxDEV(TextField, { label: "Endpoint HTTPS được backend cho phép", value: endpoint, onChange: (e) => setEndpoint(e.target.value) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 871
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { label: editing ? "Khóa mới (để trống để giữ nguyên)" : "Khóa API", type: "password", autoComplete: "new-password", value: key, onChange: (e) => setKey(limitCodePoints(e.target.value, 16384)) }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 993
        }, this),
        /* @__PURE__ */ jsxDEV(Alert, { severity: "info", children: "Secret chỉ được gửi theo trường writeOnly của contract. Response và danh sách không trả secret gốc." }, void 0, false, {
          fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
          lineNumber: 85,
          columnNumber: 1194
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
        lineNumber: 85,
        columnNumber: 96
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 66,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV(ConfirmDialog, { open: !!deleting, title: "Xóa kết nối AI", confirmLabel: "Xóa kết nối AI", description: `Kết nối AI ${deleting?.name || ""} (${deleting?.id || ""}), model ${deleting?.modelId || ""}: chỉ xóa khi không còn cấu hình đang sử dụng. Không tự chuyển dữ liệu sang nhà cung cấp khác.`, requireReason: true, onClose: () => setDeleting(null), error: remove.error, busy: remove.pending, onConfirm: async () => {
      if (!deleting) return;
      await remove.execute({ path: { connectionId: deleting.id }, version: deleting.version });
    } }, void 0, false, {
      fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
      lineNumber: 86,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
}
_s2(AIProvidersPage, "MnwpftGyLZzRVfWHEZz/v/QjesE=", false, function() {
  return [useScope, useApi, useApi, useCommand, useCommand, useCommand, useCommand];
});
_c2 = AIProvidersPage;
var _c, _c2;
$RefreshReg$(_c, "ChannelsPage");
$RefreshReg$(_c2, "AIProvidersPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Joker-PC/Documents/Projects/Bot-AI-Ban-hang-FB/BotSalesAI_Frontend/apps/web/src/modules/integrations/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUIwQixTQVNmLFVBVGU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbkIxQixTQUFTQSxhQUFhQyxZQUFZQyxjQUFjQyxhQUFhQyxzQkFBc0I7QUFDbkYsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVFDLHNCQUFxQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsS0FBS0MsUUFBUUMsTUFBTUMsVUFBVUMsaUJBQWlCO0FBRTlELFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCQyxnQkFBZ0I7QUFDMUMsU0FBU0MsZUFBZUMsWUFBWUMsWUFBWUMsT0FBT0MsYUFBYUMsZ0JBQWdCQyxZQUFZQyxPQUFPQyxZQUFZQyxXQUFXQyxjQUFjO0FBRTVJLFNBQVNDLFVBQVVDLEtBQWE7QUFBRSxRQUFNQyxTQUFTLElBQUlDLElBQUlGLEtBQUtHLFNBQVNDLE1BQU07QUFBRyxNQUFJSCxPQUFPSSxhQUFhLFlBQVksRUFBRUMsWUFBWUwsT0FBT0csV0FBV0QsU0FBU0M7QUFDekosVUFBTSxJQUFJRyxNQUFNLHNDQUFzQztBQUFHSixXQUFTSyxPQUFPUCxPQUFPUSxJQUFJO0FBQUc7QUFDcEYsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUMzQixRQUFNLEVBQUVDLEtBQUssSUFBSTNCLFNBQVM7QUFDMUIsUUFBTTRCLE9BQU85QixPQUFPLGNBQWM7QUFDbEMsUUFBTStCLFVBQVU5QixXQUFXLHVCQUF1QixFQUFFLEdBQUcrQixZQUFZL0IsV0FBVyxvQkFBb0IsRUFBRSxHQUFHZ0MsYUFBYWhDLFdBQVcscUJBQXFCLENBQUMsY0FBYyxDQUFDLEdBQUdpQyxRQUFRakMsV0FBVyxzQkFBc0IsQ0FBQyxjQUFjLENBQUM7QUFDaE8sUUFBTSxDQUFDa0MsVUFBVUMsV0FBVyxJQUFJN0MsU0FBeUIsSUFBSSxHQUFHLENBQUM4QyxPQUFPQyxNQUFNLElBQUkvQyxTQUFTLEVBQUUsR0FBRyxDQUFDZ0QsT0FBT0MsUUFBUSxJQUFJakQsU0FBdUIsSUFBSTtBQUMvSSxRQUFNa0QsVUFBVSxDQUFDWCxLQUFLWSxXQUFXWixLQUFLYSxNQUFNQSxLQUFLQyxXQUFXO0FBQzVELFFBQU1DLGdCQUFnQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFRLGFBQVksTUFBTWQsUUFBUWUsU0FBUyxTQUFTLE1BQU0sS0FBS0MsTUFBTSxHQUFHLDRCQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFJO0FBQzNKLFFBQU1BLFFBQVEsT0FBT0MsY0FBdUI7QUFBRVIsYUFBUyxJQUFJO0FBQUcsUUFBSTtBQUM5RCxZQUFNUyxPQUFPLEVBQUVDLFlBQVksTUFBTXJCLEtBQUtzQixFQUFFLDBCQUEwQkMsYUFBYSxxQkFBOEI7QUFDN0csWUFBTUMsSUFBSUwsWUFBWSxNQUFNaEIsVUFBVXNCLFFBQVEsRUFBRUMsTUFBTSxFQUFFUCxVQUFVLEdBQUdDLEtBQUssQ0FBQyxJQUFJLE1BQU1sQixRQUFRdUIsUUFBUSxFQUFFTCxLQUFLLENBQUM7QUFDN0dqQyxnQkFBVXFDLEVBQUVWLEtBQUthLGdCQUFnQjtBQUFBLElBQ3JDLFNBQ09DLEdBQUc7QUFDTmpCLGVBQVNpQixhQUFhakMsUUFBUWlDLElBQUksSUFBSWpDLE1BQU0sNkJBQTZCLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQUU7QUFDRixTQUFPLG1DQUFFO0FBQUEsMkJBQUMsY0FBVyxPQUFNLG9CQUFtQixVQUFTLG9FQUFtRSxTQUFTLENBQUNpQixXQUFXSSxpQkFBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvSjtBQUFBLElBQUUsdUJBQUMsZUFBWSxPQUFPTixTQUFTUixRQUFRUSxTQUFTUCxVQUFVTyxTQUFTTCxNQUFNSyxTQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZFO0FBQUEsSUFBR2hCLFlBQVksdUJBQUMsU0FBTSxVQUFTLFFBQU8sSUFBSTlCLFNBQVNpRSxPQUFPQyxVQUFVLGdGQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFIO0FBQUEsSUFBUyx1QkFBQyxjQUFXLE9BQU83QixNQUFNLGdCQUFlLFdBQVdBLGVBQUthLE1BQU1BLEtBQUtDLFdBQVcsS0FBSyxDQUFDZCxLQUFLWSxVQUFVLHVCQUFDLFNBQU0sTUFBSyx1REFBc0QsUUFBUUcsaUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0YsSUFBSyx1QkFBQyxnQkFBZWYsZUFBS2EsTUFBTUEsS0FBS2lCLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFpQixPQUFPQSxFQUFFQyxNQUFNLFVBQVMsU0FBUSxRQUFRdkMsV0FBVyx1QkFBQyxRQUFLLE9BQU0sZ0NBQStCLE9BQU0sV0FBVSxTQUFRLGNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkUsSUFBSyx1QkFBQyxVQUFPLE9BQU9zQyxFQUFFRSxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCLEdBQUksaUNBQUMsT0FBSTtBQUFBLDZCQUFDLGNBQVcsT0FBTSxXQUFXRixZQUFFRyxrQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLG9CQUFvQjVELG1CQUFTeUQsRUFBRUksZUFBZXBDLEtBQUtxQyxRQUFRLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0U7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSxjQUFjTCxZQUFFTSxpQkFBaUIsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxNQUFhLHVCQUFDLGNBQVcsT0FBTSx1QkFBdUIvRCxtQkFBU3lELEVBQUVPLGtCQUFrQnZDLEtBQUtxQyxRQUFRLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUFhLHVCQUFDLGVBQVksV0FBVSxPQUFNLFdBQVUsV0FBVSxVQUFTLFVBQVVMLFlBQUVRLGFBQWFULElBQUksQ0FBQVUsUUFBTyx1QkFBQyxRQUFLLE9BQU85RSxlQUFlOEUsR0FBRyxHQUFHLE9BQU9BLE9BQVVBLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQsQ0FBRSxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlKO0FBQUEsTUFBZVQsRUFBRVUsU0FBU1gsSUFBSSxDQUFBWSxNQUFLLHVCQUFDLFNBQU0sVUFBUyxXQUFrQixJQUFJL0UsU0FBU2lFLE9BQU9DLFVBQVdhLGVBQWxDQSxHQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FLENBQVE7QUFBQSxNQUFFLHVCQUFDLGVBQVksV0FBVSxPQUFPO0FBQUEsK0JBQUMsa0JBQWUsWUFBVyx1QkFBc0IsTUFBTXRDLE1BQU1ZLFNBQVMsU0FBUyxZQUFZO0FBQUUsY0FBSTtBQUN2K0NSLG9CQUFRLE1BQU1KLE1BQU1vQixRQUFRLEVBQUVDLE1BQU0sRUFBRVAsV0FBV2EsRUFBRVYsR0FBRyxFQUFFLENBQUMsR0FBR1IsS0FBS1EsRUFBRTtBQUFBLFVBQ3ZFLFFBQ007QUFBQSxVQUFFO0FBQUEsUUFBZ0IsR0FBRyw0QkFIKzJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHbjJDO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsTUFBTW5CLFVBQVVjLFNBQVMsU0FBUyxNQUFNLEtBQUtDLE1BQU1jLEVBQUVWLEVBQUUsR0FBRywyQkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQWlCLHVCQUFDLGtCQUFlLFlBQVcsdUJBQXNCLE9BQU0sU0FBUSxTQUFTLE1BQU1mLFlBQVl5QixDQUFDLEdBQUcsNEJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEc7QUFBQSxXQUhta0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdsakM7QUFBQSxTQUgyZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRzdjLEtBSHNTQSxFQUFFVixJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHcFIsQ0FBUSxLQUhtTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR2pPLEtBSGlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHakI7QUFBQSxJQUFjZCxTQUFTLHVCQUFDLGFBQVUsSUFBSSxNQUFNUixLQUFLc0IsRUFBRSxTQUFTZCxLQUFLLElBQUksb0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxJQUFhLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDRixVQUFVLE9BQU0scUJBQW9CLGNBQWEscUJBQW9CLGFBQWEsUUFBUUEsVUFBVTJCLFFBQVEsRUFBRSxLQUFLM0IsVUFBVTZCLGtCQUFrQixFQUFFLDRHQUE0RyxlQUFhLE1BQUMsU0FBUyxNQUFNNUIsWUFBWSxJQUFJLEdBQUcsTUFBTUgsV0FBV2EsU0FBUyxPQUFPYixXQUFXTSxPQUFPLFdBQVcsQ0FBQWtDLFdBQVV4QyxXQUFXcUIsUUFBUSxFQUFFQyxNQUFNLEVBQUVQLFdBQVdiLFVBQVVnQixNQUFNLEdBQUcsR0FBR0YsTUFBTSxFQUFFeUIsaUJBQWlCdkMsVUFBVXdDLFdBQVcsR0FBR0YsT0FBTyxFQUFFLENBQUMsS0FBcmdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdWdCO0FBQUEsT0FIOThCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHZzlCO0FBQzM5QjtBQUFDN0MsR0FuQmVELGNBQVk7QUFBQSxVQUNQekIsVUFDSkYsUUFDR0MsWUFBbURBLFlBQWlEQSxZQUEyREEsVUFBVTtBQUFBO0FBQUEsS0FIN0swQjtBQW9CVCxnQkFBU2lELGtCQUFrQjtBQUFBQyxNQUFBO0FBQzlCLFFBQU0sRUFBRWhELEtBQUssSUFBSTNCLFNBQVM7QUFDMUIsUUFBTTRCLE9BQU85QixPQUFPLG1CQUFtQixHQUFHOEUsVUFBVTlFLE9BQU8sb0JBQW9CO0FBQy9FLFFBQU0rRSxTQUFTOUUsV0FBVyxzQkFBc0IsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHK0UsU0FBUy9FLFdBQVcsc0JBQXNCLENBQUMsbUJBQW1CLENBQUMsR0FBR2dGLFNBQVNoRixXQUFXLHNCQUFzQixDQUFDLG1CQUFtQixDQUFDLEdBQUdpRixPQUFPakYsV0FBVyxvQkFBb0IsQ0FBQyxtQkFBbUIsQ0FBQztBQUN2USxRQUFNLENBQUNrRixNQUFNQyxPQUFPLElBQUk3RixTQUFTLEtBQUssR0FBRyxDQUFDOEYsU0FBU0MsVUFBVSxJQUFJL0YsU0FBOEIsSUFBSSxHQUFHLENBQUN1RSxNQUFNeUIsT0FBTyxJQUFJaEcsU0FBUyxFQUFFLEdBQUcsQ0FBQ2lHLFVBQVVDLFdBQVcsSUFBSWxHLFNBQVMsRUFBRSxHQUFHLENBQUNtRyxPQUFPQyxRQUFRLElBQUlwRyxTQUFTLEVBQUUsR0FBRyxDQUFDcUcsVUFBVUMsV0FBVyxJQUFJdEcsU0FBUyxFQUFFLEdBQUcsQ0FBQ3VHLEtBQUtDLE1BQU0sSUFBSXhHLFNBQVMsRUFBRSxHQUFHLENBQUN5RyxXQUFXQyxZQUFZLElBQUkxRyxTQUF1QixJQUFJLEdBQUcsQ0FBQzJHLFVBQVVDLFdBQVcsSUFBSTVHLFNBQThCLElBQUksR0FBRyxDQUFDOEMsT0FBT0MsTUFBTSxJQUFJL0MsU0FBUyxFQUFFO0FBQzVhLFFBQU02RyxhQUFhdEIsUUFBUW5DLE1BQU1BLEtBQUswRCxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLGVBQWVmLFFBQVE7QUFDekUsUUFBTS9DLFVBQVUsQ0FBQ1gsS0FBS1ksV0FBV1osS0FBS2EsTUFBTUEsS0FBS0MsV0FBVztBQUM1RCxRQUFNNEQsc0JBQXNCLHVCQUFDLGtCQUFlLFlBQVcsdUJBQXNCLFNBQVEsYUFBWSxTQUFTLE1BQU16RCxNQUFNLElBQUksR0FBRywrQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnSDtBQUM1SSxRQUFNQSxRQUFRQSxDQUFDMEQsZUFBb0M7QUFBRW5CLGVBQVdtQixVQUFVO0FBQUdsQixZQUFRa0IsWUFBWTNDLFFBQVEsRUFBRTtBQUFHMkIsZ0JBQVlnQixZQUFZRixjQUFjekIsUUFBUW5DLE1BQU1BLEtBQUssQ0FBQyxHQUFHNEQsY0FBYyxFQUFFO0FBQUdaLGFBQVNjLFlBQVlDLFdBQVcsRUFBRTtBQUFHYixnQkFBWVksWUFBWUUsZUFBZSxFQUFFO0FBQUdaLFdBQU8sRUFBRTtBQUFHRSxpQkFBYSxJQUFJO0FBQUdiLFlBQVEsSUFBSTtBQUFBLEVBQUc7QUFDOVQsU0FBTyxtQ0FBRTtBQUFBLDJCQUFDLGNBQVcsT0FBTSxtQkFBa0IsVUFBUyxrRkFBaUYsU0FBUyxDQUFDM0MsV0FBVytELHVCQUFuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVLO0FBQUEsSUFBRSx1QkFBQyxlQUFZLE9BQU90QixLQUFLM0MsU0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQjtBQUFBLElBQUUsdUJBQUMsY0FBVyxPQUFPVCxNQUFNLGdCQUFlLFdBQVdBLGVBQUthLE1BQU1BLEtBQUtDLFdBQVcsS0FBSyxDQUFDZCxLQUFLWSxVQUFVLHVCQUFDLFNBQU0sTUFBSyxrRUFBaUUsUUFBUThELHVCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlHLElBQUssdUJBQUMsZUFBWSxTQUFTLEVBQUVJLElBQUksa0JBQWtCQyxJQUFJL0UsS0FBS2EsTUFBTUEsS0FBS0MsV0FBVyxJQUFJLG1CQUFtQiw0QkFBNEIsR0FBSWQsZUFBS2EsTUFBTUEsS0FBS2lCLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxTQUFpQixPQUFPQSxFQUFFQyxNQUFNLFVBQVMsU0FBUSxRQUFRLHVCQUFDLFVBQU8sT0FBT0QsRUFBRUUsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixHQUFJLGlDQUFDLE9BQUk7QUFBQSw2QkFBQyxjQUFXLE9BQU0sc0JBQXNCRjtBQUFBQSxVQUFFMEM7QUFBQUEsUUFBVztBQUFBLFFBQUkxQyxFQUFFaUQ7QUFBQUEsV0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFNBQVNqRCxZQUFFNkMsV0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLFFBQVE3QyxZQUFFa0QsZ0JBQWdCLFFBQVFsRCxFQUFFbUQsWUFBWSxFQUFFLEtBQUssYUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQWEsdUJBQUMsY0FBVyxPQUFNLHFCQUFxQjVHLG1CQUFTeUQsRUFBRW9ELGVBQWVwRixLQUFLcUMsUUFBUSxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsTUFBYSx1QkFBQyxrQkFBZSxRQUFPLGVBQWMsV0FBVSxXQUFVLFVBQVMsVUFBVWdELGlCQUFPQyxRQUFRdEQsRUFBRVEsWUFBWSxFQUFFK0MsT0FBTyxDQUFDLENBQUNDLENBQUMsTUFBTUEsTUFBTSxnQkFBZ0IsRUFBRXpELElBQUksQ0FBQyxDQUFDeUQsR0FBR0MsQ0FBQyxNQUFNLHVCQUFDLGNBQW1CLE9BQU85SCxlQUFlNkgsQ0FBQyxHQUFJLGlCQUFPQyxNQUFNLFdBQVcsdUJBQUMsVUFBTyxPQUFPQSxHQUFHLFFBQU8sY0FBYSxTQUFRLGFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQsSUFBSyxtQkFBbEhELEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUosQ0FBYSxLQUFuVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFVO0FBQUEsTUFBaUIsdUJBQUMsZUFBWSxXQUFVLE9BQU87QUFBQSwrQkFBQyxrQkFBZSxZQUFXLHVCQUFzQixTQUFTLE1BQU10RSxNQUFNYyxDQUFDLEdBQUcsK0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUFpQix1QkFBQyxrQkFBZSxZQUFXLHVCQUFzQixNQUFNcUIsS0FBS3BDLFNBQVMsU0FBUyxZQUFZO0FBQUUsY0FBSTtBQUN2aERSLG9CQUFRLE1BQU00QyxLQUFLNUIsUUFBUSxFQUFFQyxNQUFNLEVBQUVnRSxjQUFjMUQsRUFBRVYsR0FBRyxFQUFFLENBQUMsR0FBR1IsS0FBS1EsRUFBRTtBQUFBLFVBQ3pFLFFBQ007QUFBQSxVQUFFO0FBQUEsUUFBZ0IsR0FBRyw0QkFIZzZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHcDVDO0FBQUEsUUFBaUIsdUJBQUMsa0JBQWUsWUFBVyx1QkFBc0IsT0FBTSxTQUFRLFNBQVMsTUFBTWdELFlBQVl0QyxDQUFDLEdBQUcsbUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxXQUgwcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUd6b0M7QUFBQSxTQUg2ZTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRy9kLEtBSHFaQSxFQUFFVixJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHblksQ0FBUSxLQUg4TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRzVOLEtBSFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdJO0FBQUEsSUFBY2QsU0FBUyx1QkFBQyxhQUFVLElBQUksTUFBTVIsS0FBS3NCLEVBQUUsU0FBU2QsS0FBSyxJQUFJLHdDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNFO0FBQUEsSUFDdlQsdUJBQUMsY0FBVyxNQUFZLE9BQU9nRCxVQUFVLDRCQUE0QixrQkFBa0IsU0FBUyxNQUFNO0FBQUVVLGFBQU8sRUFBRTtBQUFHRSxtQkFBYSxJQUFJO0FBQUdiLGNBQVEsS0FBSztBQUFBLElBQUcsR0FBRyxNQUFNTCxPQUFPakMsV0FBV2tDLE9BQU9sQyxTQUFTLFNBQVMsdUJBQUMsVUFBTyxTQUFRLGFBQVksVUFBVSxDQUFDZ0IsS0FBSzBELEtBQUssS0FBSyxDQUFDOUIsTUFBTThCLEtBQUssS0FBTSxDQUFDbkMsWUFBWSxDQUFDZSxjQUFjLENBQUNOLFFBQVNmLE9BQU9qQyxXQUFXa0MsT0FBT2xDLFNBQVMsU0FBUyxZQUFZO0FBQzFXbUQsbUJBQWEsSUFBSTtBQUNqQixZQUFNd0Isc0JBQXNCM0I7QUFDNUIsVUFBSTtBQUNBLFlBQUl2RSxZQUFZa0csdUJBQXVCLENBQUNBLG9CQUFvQkMsV0FBVyxPQUFPO0FBQzFFLGdCQUFNLElBQUlsRyxNQUFNLDBEQUEwRDtBQUM5RSxZQUFJNkQ7QUFDQSxnQkFBTUwsT0FBTzFCLFFBQVEsRUFBRUMsTUFBTSxFQUFFZ0UsY0FBY2xDLFFBQVFsQyxHQUFHLEdBQUd3QixTQUFTVSxRQUFRVixTQUFTMUIsTUFBTSxFQUFFYSxNQUFNQSxLQUFLMEQsS0FBSyxHQUFHZCxTQUFTaEIsTUFBTThCLEtBQUssR0FBRyxHQUFJQyxzQkFBc0IsRUFBRUUsWUFBWUYsb0JBQW9CLElBQUksQ0FBQyxFQUFHLEVBQUUsQ0FBQztBQUFBO0FBRTlNLGdCQUFNMUMsT0FBT3pCLFFBQVEsRUFBRUwsTUFBTSxFQUFFYSxNQUFNQSxLQUFLMEQsS0FBSyxHQUFHakIsWUFBWWYsVUFBVXNCLFdBQVdWLFlBQVlVLGFBQWEsSUFBSUosU0FBU2hCLE1BQU04QixLQUFLLEdBQUdiLGFBQWFmLFlBQVksTUFBTStCLFlBQVlGLG9CQUFvQixFQUFFLENBQUM7QUFDN01yQyxnQkFBUSxLQUFLO0FBQUEsTUFDakIsU0FDTzNCLEdBQUc7QUFDTixjQUFNbUUsVUFBVW5FLGFBQWFqQyxRQUFRaUMsRUFBRW1FLFVBQVU7QUFDakQzQixxQkFBYSxJQUFJekUsTUFBTWlHLHVCQUF1QkcsUUFBUUMsU0FBU0osbUJBQW1CLElBQUlHLFFBQVFFLFdBQVdMLHFCQUFxQixTQUFTLElBQUlHLE9BQU8sQ0FBQztBQUFBLE1BQ3ZKLFVBQUM7QUFFRzdCLGVBQU8sRUFBRTtBQUFBLE1BQ2I7QUFBQSxJQUNKLEdBQUcsNEJBbkJzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUIxTCxHQUFXO0FBQUEsNkJBQUMsZUFBWSxPQUFPQyxhQUFhakIsT0FBT3hDLFNBQVN5QyxPQUFPekMsU0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BQUUsdUJBQUMsY0FBYWhCO0FBQUFBLG9CQUFZLHVCQUFDLFNBQU0sVUFBUyxXQUFVLHNJQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdKO0FBQUEsUUFBUyx1QkFBQyxhQUFVLE9BQU0sZUFBYyxPQUFPdUMsTUFBTSxVQUFVLENBQUFMLE1BQUs4QixRQUFROUIsRUFBRXZDLE9BQU82RyxLQUFLLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUFFLHVCQUFDLGFBQVUsUUFBTSxNQUFDLE9BQU0sMEJBQXlCLE9BQU92QyxVQUFVLFVBQVUsQ0FBQyxDQUFDSCxTQUFTLFVBQVUsQ0FBQTVCLE1BQUs7QUFBRWdDLHNCQUFZaEMsRUFBRXZDLE9BQU82RyxLQUFLO0FBQUdwQyxtQkFBUyxFQUFFO0FBQUEsUUFBRyxHQUFJYixrQkFBUW5DLE1BQU1BLEtBQUtpQixJQUFJLENBQUEwQyxNQUFLLHVCQUFDLFlBQVMsT0FBT0EsRUFBRUMsWUFBZ0NELFlBQUUwQixTQUFqQjFCLEVBQUVDLFlBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQsQ0FBVyxLQUF6UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJQO0FBQUEsUUFBWSx1QkFBQyxhQUFVLE9BQU0sZ0NBQStCLE9BQU9iLE9BQU8sVUFBVSxDQUFBakMsTUFBS2tDLFNBQVNsQyxFQUFFdkMsT0FBTzZHLEtBQUssR0FBRyxZQUFZM0IsWUFBWTZCLE9BQU9yRSxJQUFJLENBQUFzRSxNQUFLQSxFQUFFeEIsT0FBTyxFQUFFeUIsS0FBSyxJQUFJLEtBQUssNEJBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaU07QUFBQSxRQUFHLENBQUM5QyxXQUFXZSxZQUFZZ0Msb0JBQW9CLHVCQUFDLGFBQVUsT0FBTSx3Q0FBdUMsT0FBT3hDLFVBQVUsVUFBVSxDQUFBbkMsTUFBS29DLFlBQVlwQyxFQUFFdkMsT0FBTzZHLEtBQUssS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSDtBQUFBLFFBQUcsdUJBQUMsYUFBVSxPQUFPMUMsVUFBVSxzQ0FBc0MsWUFBWSxNQUFLLFlBQVcsY0FBYSxnQkFBZSxPQUFPUyxLQUFLLFVBQVUsQ0FBQXJDLE1BQUtzQyxPQUFPNUYsZ0JBQWdCc0QsRUFBRXZDLE9BQU82RyxPQUFPLEtBQUssQ0FBQyxLQUFsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9NO0FBQUEsUUFBRyx1QkFBQyxTQUFNLFVBQVMsUUFBTyxtSEFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBQXZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStyQztBQUFBLFNBbkI1eEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CeXlDO0FBQUEsSUFDenlDLHVCQUFDLGlCQUFjLE1BQU0sQ0FBQyxDQUFDN0IsVUFBVSxPQUFNLGtCQUFpQixjQUFhLGtCQUFpQixhQUFhLGNBQWNBLFVBQVVwQyxRQUFRLEVBQUUsS0FBS29DLFVBQVUvQyxNQUFNLEVBQUUsWUFBWStDLFVBQVVRLFdBQVcsRUFBRSxrR0FBa0csZUFBYSxNQUFDLFNBQVMsTUFBTVAsWUFBWSxJQUFJLEdBQUcsT0FBT2xCLE9BQU8xQyxPQUFPLE1BQU0wQyxPQUFPbkMsU0FBUyxXQUFXLFlBQVk7QUFDNVksVUFBSSxDQUFDb0QsU0FBVTtBQUNmLFlBQU1qQixPQUFPM0IsUUFBUSxFQUFFQyxNQUFNLEVBQUVnRSxjQUFjckIsU0FBUy9DLEdBQUcsR0FBR3dCLFNBQVN1QixTQUFTdkIsUUFBUSxDQUFDO0FBQUEsSUFDM0YsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0s7QUFBQSxPQTNCSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJIO0FBQ1I7QUFBQ0UsSUFyQ2VELGlCQUFlO0FBQUEsVUFDVjFFLFVBQ0pGLFFBQXVDQSxRQUNyQ0MsWUFBa0VBLFlBQWtFQSxZQUFnRUEsVUFBVTtBQUFBO0FBQUEsTUFIak4yRTtBQUFlLElBQUF5RCxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQWN0aW9uR3JvdXAiLCJGb3JtRmllbGRzIiwiUGFnZVNlY3Rpb25zIiwiU2VjdGlvbkdyaWQiLCJTdXJmYWNlQ29udGVudCIsInVzZVN0YXRlIiwiY2FwYWJpbGl0eU5hbWUiLCJsYXlvdXRTeCIsIkFsZXJ0IiwiQm94IiwiQnV0dG9uIiwiQ2hpcCIsIk1lbnVJdGVtIiwiVGV4dEZpZWxkIiwidXNlQXBpIiwidXNlQ29tbWFuZCIsInVzZVNjb3BlIiwibGltaXRDb2RlUG9pbnRzIiwiZGF0ZVRpbWUiLCJDb25maXJtRGlhbG9nIiwiRGV0YWlsTGluZSIsIkVkaXREaWFsb2ciLCJFbXB0eSIsIkVycm9yTm90aWNlIiwiTXV0YXRpb25CdXR0b24iLCJQYWdlSGVhZGVyIiwiUGFuZWwiLCJRdWVyeVN0YXRlIiwiUm91dGVMaW5rIiwiU3RhdHVzIiwiYXV0aG9yaXplIiwidXJsIiwidGFyZ2V0IiwiVVJMIiwibG9jYXRpb24iLCJvcmlnaW4iLCJwcm90b2NvbCIsIl9fTU9DS19fIiwiRXJyb3IiLCJhc3NpZ24iLCJocmVmIiwiQ2hhbm5lbHNQYWdlIiwiX3MiLCJzaG9wIiwibGlzdCIsImNvbm5lY3QiLCJyZWNvbm5lY3QiLCJkaXNjb25uZWN0IiwiY2hlY2siLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiam9iSWQiLCJzZXRKb2IiLCJlcnJvciIsInNldEVycm9yIiwiaXNFbXB0eSIsImlzRXJyb3IiLCJkYXRhIiwibGVuZ3RoIiwiY29ubmVjdEJ1dHRvbiIsInBlbmRpbmciLCJzdGFydCIsImNoYW5uZWxJZCIsImJvZHkiLCJyZXR1cm5QYXRoIiwiaWQiLCJjaGFubmVsS2luZCIsInIiLCJleGVjdXRlIiwicGF0aCIsImF1dGhvcml6YXRpb25VcmwiLCJlIiwibm90aWNlIiwiYWZ0ZXJHYXAiLCJtYXAiLCJjIiwibmFtZSIsInN0YXR1cyIsImV4dGVybmFsUGFnZUlkIiwibGFzdFdlYmhvb2tBdCIsInRpbWV6b25lIiwicG9saWN5VmVyc2lvbiIsInBvbGljeVZlcmlmaWVkQXQiLCJjYXBhYmlsaXRpZXMiLCJjYXAiLCJ3YXJuaW5ncyIsInciLCJyZWFzb24iLCJleHBlY3RlZFZlcnNpb24iLCJ2ZXJzaW9uIiwiQUlQcm92aWRlcnNQYWdlIiwiX3MyIiwiY2F0YWxvZyIsImNyZWF0ZSIsInVwZGF0ZSIsInJlbW92ZSIsInRlc3QiLCJvcGVuIiwic2V0T3BlbiIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwic2V0TmFtZSIsInByb3ZpZGVyIiwic2V0UHJvdmlkZXIiLCJtb2RlbCIsInNldE1vZGVsIiwiZW5kcG9pbnQiLCJzZXRFbmRwb2ludCIsImtleSIsInNldEtleSIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsImRlbGV0aW5nIiwic2V0RGVsZXRpbmciLCJkZXNjcmlwdG9yIiwiZmluZCIsInAiLCJwcm92aWRlcklkIiwiYWRkQ29ubmVjdGlvbkJ1dHRvbiIsImNvbm5lY3Rpb24iLCJtb2RlbElkIiwiZW5kcG9pbnRVcmwiLCJ4cyIsImxnIiwiYWRhcHRlcklkIiwiaGFzQ3JlZGVudGlhbCIsImtleUxhc3Q0IiwibGFzdENoZWNrZWRBdCIsIk9iamVjdCIsImVudHJpZXMiLCJmaWx0ZXIiLCJrIiwidiIsImNvbm5lY3Rpb25JZCIsInRyaW0iLCJzdWJtaXR0ZWRDcmVkZW50aWFsIiwic3RhcnRzV2l0aCIsImNyZWRlbnRpYWwiLCJtZXNzYWdlIiwiaW5jbHVkZXMiLCJyZXBsYWNlQWxsIiwidmFsdWUiLCJsYWJlbCIsIm1vZGVscyIsIm0iLCJqb2luIiwiZW5kcG9pbnRFZGl0YWJsZSIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpb25Hcm91cCwgRm9ybUZpZWxkcywgUGFnZVNlY3Rpb25zLCBTZWN0aW9uR3JpZCwgU3VyZmFjZUNvbnRlbnQgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9zaXRpb24nO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge2NhcGFiaWxpdHlOYW1lfSBmcm9tICdAL3NoYXJlZC9tb2RlbC9sYWJlbHMnO1xuaW1wb3J0IHsgbGF5b3V0U3ggfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvbGF5b3V0JztcbmltcG9ydCB7IEFsZXJ0LCBCb3gsIEJ1dHRvbiwgQ2hpcCwgTWVudUl0ZW0sIFRleHRGaWVsZCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xuaW1wb3J0IHR5cGUgeyBBSUNvbm5lY3Rpb24sIENoYW5uZWwgfSBmcm9tICdAYm90c2FsZXMvY29udHJhY3RzJztcbmltcG9ydCB7IHVzZUFwaSwgdXNlQ29tbWFuZCB9IGZyb20gJy4uLy4uL3NoYXJlZC9hcGkvaG9va3MnO1xuaW1wb3J0IHsgdXNlU2NvcGUgfSBmcm9tICcuLi8uLi9zaGFyZWQvbW9kZWwvc2NvcGUnO1xuaW1wb3J0IHsgbGltaXRDb2RlUG9pbnRzLCBkYXRlVGltZSB9IGZyb20gJ0Avc2hhcmVkL21vZGVsL2Zvcm1hdCc7XG5pbXBvcnQgeyBDb25maXJtRGlhbG9nLCBEZXRhaWxMaW5lLCBFZGl0RGlhbG9nLCBFbXB0eSwgRXJyb3JOb3RpY2UsIE11dGF0aW9uQnV0dG9uLCBQYWdlSGVhZGVyLCBQYW5lbCwgUXVlcnlTdGF0ZSwgUm91dGVMaW5rLCBTdGF0dXMgfSBmcm9tICcuLi8uLi9zaGFyZWQvdWkvY29tcG9uZW50cyc7XG4vKiogVGhlIGJhY2tlbmQgc3VwcGxpZXMgdGhlIHByb3ZpZGVyIFVSTDsgdGhlIGJyb3dzZXIgc3RpbGwgcmVmdXNlcyB1bnNhZmUgc2NoZW1lcy4gKi9cbmZ1bmN0aW9uIGF1dGhvcml6ZSh1cmw6IHN0cmluZykgeyBjb25zdCB0YXJnZXQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24ub3JpZ2luKTsgaWYgKHRhcmdldC5wcm90b2NvbCAhPT0gJ2h0dHBzOicgJiYgIShfX01PQ0tfXyAmJiB0YXJnZXQub3JpZ2luID09PSBsb2NhdGlvbi5vcmlnaW4pKVxuICAgIHRocm93IG5ldyBFcnJvcignxJDGsOG7nW5nIGThuqtuIHjDoWMgdGjhu7FjIGtow7RuZyBkw7luZyBIVFRQUy4nKTsgbG9jYXRpb24uYXNzaWduKHRhcmdldC5ocmVmKTsgfVxuZXhwb3J0IGZ1bmN0aW9uIENoYW5uZWxzUGFnZSgpIHtcbiAgICBjb25zdCB7IHNob3AgfSA9IHVzZVNjb3BlKCk7XG4gICAgY29uc3QgbGlzdCA9IHVzZUFwaSgnbGlzdENoYW5uZWxzJyk7XG4gICAgY29uc3QgY29ubmVjdCA9IHVzZUNvbW1hbmQoJ2JlZ2luQ2hhbm5lbENvbm5lY3QnLCBbXSksIHJlY29ubmVjdCA9IHVzZUNvbW1hbmQoJ3JlY29ubmVjdENoYW5uZWwnLCBbXSksIGRpc2Nvbm5lY3QgPSB1c2VDb21tYW5kKCdkaXNjb25uZWN0Q2hhbm5lbCcsIFsnbGlzdENoYW5uZWxzJ10pLCBjaGVjayA9IHVzZUNvbW1hbmQoJ2NoZWNrQ2hhbm5lbEhlYWx0aCcsIFsnbGlzdENoYW5uZWxzJ10pO1xuICAgIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGU8Q2hhbm5lbCB8IG51bGw+KG51bGwpLCBbam9iSWQsIHNldEpvYl0gPSB1c2VTdGF0ZSgnJyksIFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBpc0VtcHR5ID0gIWxpc3QuaXNFcnJvciAmJiBsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAwO1xuICAgIGNvbnN0IGNvbm5lY3RCdXR0b24gPSA8TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiB2YXJpYW50PVwiY29udGFpbmVkXCIgYnVzeT17Y29ubmVjdC5wZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHN0YXJ0KCl9Pkvhur90IG7hu5FpIFBhZ2U8L011dGF0aW9uQnV0dG9uPjtcbiAgICBjb25zdCBzdGFydCA9IGFzeW5jIChjaGFubmVsSWQ/OiBzdHJpbmcpID0+IHsgc2V0RXJyb3IobnVsbCk7IHRyeSB7XG4gICAgICAgIGNvbnN0IGJvZHkgPSB7IHJldHVyblBhdGg6IGAvcy8ke3Nob3AuaWR9L2ludGVncmF0aW9ucy9jaGFubmVsc2AsIGNoYW5uZWxLaW5kOiAnZmFjZWJvb2tfbWVzc2VuZ2VyJyBhcyBjb25zdCB9O1xuICAgICAgICBjb25zdCByID0gY2hhbm5lbElkID8gYXdhaXQgcmVjb25uZWN0LmV4ZWN1dGUoeyBwYXRoOiB7IGNoYW5uZWxJZCB9LCBib2R5IH0pIDogYXdhaXQgY29ubmVjdC5leGVjdXRlKHsgYm9keSB9KTtcbiAgICAgICAgYXV0aG9yaXplKHIuZGF0YS5hdXRob3JpemF0aW9uVXJsKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZSA6IG5ldyBFcnJvcignS2jDtG5nIHRo4buDIGLhuq90IMSR4bqndSB4w6FjIHRo4buxYy4nKSk7XG4gICAgfSB9O1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiS+G6v3QgbuG7kWkgRmFjZWJvb2tcIiBzdWJ0aXRsZT1cIkvhur90IG7hu5FpIGLhurFuZyBsdeG7k25nIGPhuqVwIHF1eeG7gW4uIFBhZ2UgdG9rZW4gY2jhu4kgxJHGsOG7o2MgZ2nhu68g4bufIGJhY2tlbmQuXCIgYWN0aW9ucz17IWlzRW1wdHkgJiYgY29ubmVjdEJ1dHRvbn0vPjxFcnJvck5vdGljZSBlcnJvcj17ZXJyb3IgfHwgY29ubmVjdC5lcnJvciB8fCByZWNvbm5lY3QuZXJyb3IgfHwgY2hlY2suZXJyb3J9Lz57X19NT0NLX18gJiYgPEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiIHN4PXtsYXlvdXRTeC5ub3RpY2UuYWZ0ZXJHYXB9PsSQw6J5IGzDoCBtw7QgcGjhu49uZy4gS2jDtG5nIMSRxINuZyBuaOG6rXAgRmFjZWJvb2sgdsOgIGtow7RuZyBn4butaSB0aW4gdGjhuq10LjwvQWxlcnQ+fTxRdWVyeVN0YXRlIHF1ZXJ5PXtsaXN0fSBwZW5kaW5nUHJvZmlsZT1cInNlY3Rpb25cIj57bGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMCAmJiAhbGlzdC5pc0Vycm9yID8gPEVtcHR5IHRleHQ9XCJDaMawYSBjw7MgUGFnZSBr4bq/dCBu4buRaS4gRMO5bmcgbsO6dCBiw6puIGTGsOG7m2kgxJHhu4MgYuG6r3QgxJHhuqd1LlwiIGFjdGlvbj17Y29ubmVjdEJ1dHRvbn0vPiA6IDxQYWdlU2VjdGlvbnMgPntsaXN0LmRhdGE/LmRhdGEubWFwKGMgPT4gPFBhbmVsIGtleT17Yy5pZH0gdGl0bGU9e2MubmFtZX0gYm9keU1vZGU9XCJpbnNldFwiIGFjdGlvbj17X19NT0NLX18gPyA8Q2hpcCBsYWJlbD1cIk3DtCBwaOG7j25nLCBjaMawYSBsacOqbiBr4bq/dCB0aOG6rXRcIiBjb2xvcj1cIndhcm5pbmdcIiB2YXJpYW50PVwib3V0bGluZWRcIi8+IDogPFN0YXR1cyB2YWx1ZT17Yy5zdGF0dXN9Lz59PjxCb3g+PERldGFpbExpbmUgbGFiZWw9XCJQYWdlIElEXCI+e2MuZXh0ZXJuYWxQYWdlSWR9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiV2ViaG9vayBn4bqnbiBuaOG6pXRcIj57ZGF0ZVRpbWUoYy5sYXN0V2ViaG9va0F0LCBzaG9wLnRpbWV6b25lKX08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJDaMOtbmggc8OhY2hcIj57Yy5wb2xpY3lWZXJzaW9uIHx8ICdDaMawYSB4w6FjIG1pbmgnfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIktp4buDbSBjaMOtbmggc8OhY2ggbMO6Y1wiPntkYXRlVGltZShjLnBvbGljeVZlcmlmaWVkQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgYmVmb3JlR2FwPVwic3VyZmFjZVwiIGFmdGVyR2FwPVwibm90aWNlXCI+e2MuY2FwYWJpbGl0aWVzLm1hcChjYXAgPT4gPENoaXAgbGFiZWw9e2NhcGFiaWxpdHlOYW1lKGNhcCl9IHRpdGxlPXtjYXB9IGtleT17Y2FwfS8+KX08L0FjdGlvbkdyb3VwPntjLndhcm5pbmdzLm1hcCh3ID0+IDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIiBrZXk9e3d9IHN4PXtsYXlvdXRTeC5ub3RpY2UuYWZ0ZXJHYXB9Pnt3fTwvQWxlcnQ+KX08QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGJ1c3k9e2NoZWNrLnBlbmRpbmd9IG9uQ2xpY2s9e2FzeW5jICgpID0+IHsgdHJ5IHtcbiAgICAgICAgc2V0Sm9iKChhd2FpdCBjaGVjay5leGVjdXRlKHsgcGF0aDogeyBjaGFubmVsSWQ6IGMuaWQgfSB9KSkuZGF0YS5pZCk7XG4gICAgfVxuICAgIGNhdGNoIHsgLyogdmlzaWJsZSAqLyB9IH19Pktp4buDbSBr4bq/dCBu4buRaTwvTXV0YXRpb25CdXR0b24+PE11dGF0aW9uQnV0dG9uIHBlcm1pc3Npb249XCJpbnRlZ3JhdGlvbnMubWFuYWdlXCIgYnVzeT17cmVjb25uZWN0LnBlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3RhcnQoYy5pZCl9Pkvhur90IG7hu5FpIGzhuqFpPC9NdXRhdGlvbkJ1dHRvbj48TXV0YXRpb25CdXR0b24gcGVybWlzc2lvbj1cImludGVncmF0aW9ucy5tYW5hZ2VcIiBjb2xvcj1cImVycm9yXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQoYyl9Pk5n4bqvdCBr4bq/dCBu4buRaTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD48L0JveD48L1BhbmVsPil9PC9QYWdlU2VjdGlvbnM+fTwvUXVlcnlTdGF0ZT57am9iSWQgJiYgPFJvdXRlTGluayB0bz17YC9zLyR7c2hvcC5pZH0vam9icy8ke2pvYklkfWB9PlhlbSBr4bq/dCBxdeG6oyBraeG7g20gdHJhPC9Sb3V0ZUxpbms+fTxDb25maXJtRGlhbG9nIG9wZW49eyEhc2VsZWN0ZWR9IHRpdGxlPVwiTmfhuq90IGvhur90IG7hu5FpIFBhZ2VcIiBjb25maXJtTGFiZWw9XCJOZ+G6r3Qga+G6v3QgbuG7kWkgUGFnZVwiIGRlc2NyaXB0aW9uPXtgUGFnZSAke3NlbGVjdGVkPy5uYW1lIHx8IFwiXCJ9ICgke3NlbGVjdGVkPy5leHRlcm5hbFBhZ2VJZCB8fCBcIlwifSk6IGThu6tuZyBn4butaSBt4bubaSBxdWEga+G6v3QgbuG7kWkuIEzhu4tjaCBz4butIMSRxqFuIGjDoG5nIHbDoCBo4buZaSB0aG/huqFpIMSRxrDhu6NjIGdp4buvOyB0aW4gxJHDoyB0aeG6v3Agbmjhuq1uIGtow7RuZyB0aOG7gyB0aHUgaOG7k2kuYH0gcmVxdWlyZVJlYXNvbiBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX0gYnVzeT17ZGlzY29ubmVjdC5wZW5kaW5nfSBlcnJvcj17ZGlzY29ubmVjdC5lcnJvcn0gb25Db25maXJtPXtyZWFzb24gPT4gZGlzY29ubmVjdC5leGVjdXRlKHsgcGF0aDogeyBjaGFubmVsSWQ6IHNlbGVjdGVkPy5pZCB8fCAnJyB9LCBib2R5OiB7IGV4cGVjdGVkVmVyc2lvbjogc2VsZWN0ZWQ/LnZlcnNpb24gfHwgMSwgcmVhc29uIH0gfSl9Lz48Lz47XG59XG5leHBvcnQgZnVuY3Rpb24gQUlQcm92aWRlcnNQYWdlKCkge1xuICAgIGNvbnN0IHsgc2hvcCB9ID0gdXNlU2NvcGUoKTtcbiAgICBjb25zdCBsaXN0ID0gdXNlQXBpKCdsaXN0QUlDb25uZWN0aW9ucycpLCBjYXRhbG9nID0gdXNlQXBpKCdnZXRQcm92aWRlckNhdGFsb2cnKTtcbiAgICBjb25zdCBjcmVhdGUgPSB1c2VDb21tYW5kKCdjcmVhdGVBSUNvbm5lY3Rpb24nLCBbJ2xpc3RBSUNvbm5lY3Rpb25zJ10pLCB1cGRhdGUgPSB1c2VDb21tYW5kKCd1cGRhdGVBSUNvbm5lY3Rpb24nLCBbJ2xpc3RBSUNvbm5lY3Rpb25zJ10pLCByZW1vdmUgPSB1c2VDb21tYW5kKCdkZWxldGVBSUNvbm5lY3Rpb24nLCBbJ2xpc3RBSUNvbm5lY3Rpb25zJ10pLCB0ZXN0ID0gdXNlQ29tbWFuZCgndGVzdEFJQ29ubmVjdGlvbicsIFsnbGlzdEFJQ29ubmVjdGlvbnMnXSk7XG4gICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpLCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxBSUNvbm5lY3Rpb24gfCBudWxsPihudWxsKSwgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpLCBbcHJvdmlkZXIsIHNldFByb3ZpZGVyXSA9IHVzZVN0YXRlKCcnKSwgW21vZGVsLCBzZXRNb2RlbF0gPSB1c2VTdGF0ZSgnJyksIFtlbmRwb2ludCwgc2V0RW5kcG9pbnRdID0gdXNlU3RhdGUoJycpLCBba2V5LCBzZXRLZXldID0gdXNlU3RhdGUoJycpLCBbZm9ybUVycm9yLCBzZXRGb3JtRXJyb3JdID0gdXNlU3RhdGU8RXJyb3IgfCBudWxsPihudWxsKSwgW2RlbGV0aW5nLCBzZXREZWxldGluZ10gPSB1c2VTdGF0ZTxBSUNvbm5lY3Rpb24gfCBudWxsPihudWxsKSwgW2pvYklkLCBzZXRKb2JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGRlc2NyaXB0b3IgPSBjYXRhbG9nLmRhdGE/LmRhdGEuZmluZChwID0+IHAucHJvdmlkZXJJZCA9PT0gcHJvdmlkZXIpO1xuICAgIGNvbnN0IGlzRW1wdHkgPSAhbGlzdC5pc0Vycm9yICYmIGxpc3QuZGF0YT8uZGF0YS5sZW5ndGggPT09IDA7XG4gICAgY29uc3QgYWRkQ29ubmVjdGlvbkJ1dHRvbiA9IDxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIiBvbkNsaWNrPXsoKSA9PiBzdGFydChudWxsKX0+VGjDqm0ga+G6v3QgbuG7kWkgQUk8L011dGF0aW9uQnV0dG9uPjtcbiAgICBjb25zdCBzdGFydCA9IChjb25uZWN0aW9uOiBBSUNvbm5lY3Rpb24gfCBudWxsKSA9PiB7IHNldEVkaXRpbmcoY29ubmVjdGlvbik7IHNldE5hbWUoY29ubmVjdGlvbj8ubmFtZSB8fCAnJyk7IHNldFByb3ZpZGVyKGNvbm5lY3Rpb24/LnByb3ZpZGVySWQgfHwgY2F0YWxvZy5kYXRhPy5kYXRhWzBdPy5wcm92aWRlcklkIHx8ICcnKTsgc2V0TW9kZWwoY29ubmVjdGlvbj8ubW9kZWxJZCB8fCAnJyk7IHNldEVuZHBvaW50KGNvbm5lY3Rpb24/LmVuZHBvaW50VXJsIHx8ICcnKTsgc2V0S2V5KCcnKTsgc2V0Rm9ybUVycm9yKG51bGwpOyBzZXRPcGVuKHRydWUpOyB9O1xuICAgIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiTmjDoCBjdW5nIGPhuqVwIEFJXCIgc3VidGl0bGU9XCJN4buXaSBhZGFwdGVyIGPDtG5nIGLhu5Ega2jhuqMgbsSDbmc7IGtow7RuZyBnaeG6oyDEkeG7i25oIG3hu41pIEFQSSBrZXkgY8OzIHRo4buDIHRoYXkgdGjhur8gbmhhdS5cIiBhY3Rpb25zPXshaXNFbXB0eSAmJiBhZGRDb25uZWN0aW9uQnV0dG9ufS8+PEVycm9yTm90aWNlIGVycm9yPXt0ZXN0LmVycm9yfS8+PFF1ZXJ5U3RhdGUgcXVlcnk9e2xpc3R9IHBlbmRpbmdQcm9maWxlPVwic2VjdGlvblwiPntsaXN0LmRhdGE/LmRhdGEubGVuZ3RoID09PSAwICYmICFsaXN0LmlzRXJyb3IgPyA8RW1wdHkgdGV4dD1cIkNoxrBhIGPDsyBr4bq/dCBu4buRaSBBSS4gVGjDqm0gbeG7mXQga+G6v3QgbuG7kWkgxJHhu4MgY+G6pXUgaMOsbmggbmjDoCBjdW5nIGPhuqVwLlwiIGFjdGlvbj17YWRkQ29ubmVjdGlvbkJ1dHRvbn0vPiA6IDxTZWN0aW9uR3JpZCBjb2x1bW5zPXt7IHhzOiAnbWlubWF4KDAsIDFmciknLCBsZzogbGlzdC5kYXRhPy5kYXRhLmxlbmd0aCA9PT0gMSA/ICdtaW5tYXgoMCwgMWZyKScgOiAncmVwZWF0KDIsIG1pbm1heCgwLCAxZnIpKScgfX0+e2xpc3QuZGF0YT8uZGF0YS5tYXAoYyA9PiA8UGFuZWwga2V5PXtjLmlkfSB0aXRsZT17Yy5uYW1lfSBib2R5TW9kZT1cImluc2V0XCIgYWN0aW9uPXs8U3RhdHVzIHZhbHVlPXtjLnN0YXR1c30vPn0+PEJveD48RGV0YWlsTGluZSBsYWJlbD1cIlByb3ZpZGVyIC8gYWRhcHRlclwiPntjLnByb3ZpZGVySWR9IC8ge2MuYWRhcHRlcklkfTwvRGV0YWlsTGluZT48RGV0YWlsTGluZSBsYWJlbD1cIk1vZGVsXCI+e2MubW9kZWxJZH08L0RldGFpbExpbmU+PERldGFpbExpbmUgbGFiZWw9XCJLaMOzYVwiPntjLmhhc0NyZWRlbnRpYWwgPyBg4oCi4oCi4oCi4oCiICR7Yy5rZXlMYXN0NCB8fCAnJ31gIDogJ0NoxrBhIGPDsyd9PC9EZXRhaWxMaW5lPjxEZXRhaWxMaW5lIGxhYmVsPVwiTOG6p24ga2nhu4NtIGfhuqduIG5o4bqldFwiPntkYXRlVGltZShjLmxhc3RDaGVja2VkQXQsIHNob3AudGltZXpvbmUpfTwvRGV0YWlsTGluZT48U3VyZmFjZUNvbnRlbnQgcmh5dGhtPVwiZGl2aWRlZFJvd3NcIiBiZWZvcmVHYXA9XCJzdXJmYWNlXCIgYWZ0ZXJHYXA9XCJub3RpY2VcIj57T2JqZWN0LmVudHJpZXMoYy5jYXBhYmlsaXRpZXMpLmZpbHRlcigoW2tdKSA9PiBrICE9PSAnbGFzdFZlcmlmaWVkQXQnKS5tYXAoKFtrLCB2XSkgPT4gPERldGFpbExpbmUga2V5PXtrfSBsYWJlbD17Y2FwYWJpbGl0eU5hbWUoayl9Pnt0eXBlb2YgdiA9PT0gJ3N0cmluZycgPyA8U3RhdHVzIHZhbHVlPXt2fSBkb21haW49XCJjYXBhYmlsaXR5XCIgZGVuc2l0eT1cImNvbXBhY3RcIi8+IDogJ0NoxrBhIHjDoWMgbWluaCd9PC9EZXRhaWxMaW5lPil9PC9TdXJmYWNlQ29udGVudD48QWN0aW9uR3JvdXAgZGlyZWN0aW9uPVwicm93XCIgPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIG9uQ2xpY2s9eygpID0+IHN0YXJ0KGMpfT5T4butYSAvIHhvYXkga2jDs2E8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGJ1c3k9e3Rlc3QucGVuZGluZ30gb25DbGljaz17YXN5bmMgKCkgPT4geyB0cnkge1xuICAgICAgICBzZXRKb2IoKGF3YWl0IHRlc3QuZXhlY3V0ZSh7IHBhdGg6IHsgY29ubmVjdGlvbklkOiBjLmlkIH0gfSkpLmRhdGEuaWQpO1xuICAgIH1cbiAgICBjYXRjaCB7IC8qIHZpc2libGUgKi8gfSB9fT5LaeG7g20ga+G6v3QgbuG7kWk8L011dGF0aW9uQnV0dG9uPjxNdXRhdGlvbkJ1dHRvbiBwZXJtaXNzaW9uPVwiaW50ZWdyYXRpb25zLm1hbmFnZVwiIGNvbG9yPVwiZXJyb3JcIiBvbkNsaWNrPXsoKSA9PiBzZXREZWxldGluZyhjKX0+WMOzYTwvTXV0YXRpb25CdXR0b24+PC9BY3Rpb25Hcm91cD48L0JveD48L1BhbmVsPil9PC9TZWN0aW9uR3JpZD59PC9RdWVyeVN0YXRlPntqb2JJZCAmJiA8Um91dGVMaW5rIHRvPXtgL3MvJHtzaG9wLmlkfS9qb2JzLyR7am9iSWR9YH0+S+G6v3QgcXXhuqMga2nhu4NtIHRyYSBr4bq/dCBu4buRaTwvUm91dGVMaW5rPn1cbiA8RWRpdERpYWxvZyBvcGVuPXtvcGVufSB0aXRsZT17ZWRpdGluZyA/ICdT4butYSBr4bq/dCBu4buRaSAvIHhvYXkga2jDs2EnIDogJ0vhur90IG7hu5FpIEFJIG3hu5tpJ30gb25DbG9zZT17KCkgPT4geyBzZXRLZXkoJycpOyBzZXRGb3JtRXJyb3IobnVsbCk7IHNldE9wZW4oZmFsc2UpOyB9fSBidXN5PXtjcmVhdGUucGVuZGluZyB8fCB1cGRhdGUucGVuZGluZ30gYWN0aW9ucz17PEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgZGlzYWJsZWQ9eyFuYW1lLnRyaW0oKSB8fCAhbW9kZWwudHJpbSgpIHx8ICghZWRpdGluZyAmJiAoIWRlc2NyaXB0b3IgfHwgIWtleSkpIHx8IGNyZWF0ZS5wZW5kaW5nIHx8IHVwZGF0ZS5wZW5kaW5nfSBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgIHNldEZvcm1FcnJvcihudWxsKTtcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkQ3JlZGVudGlhbCA9IGtleTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChfX01PQ0tfXyAmJiBzdWJtaXR0ZWRDcmVkZW50aWFsICYmICFzdWJtaXR0ZWRDcmVkZW50aWFsLnN0YXJ0c1dpdGgoJ2RlbW8tJykpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDaOG7iSBuaOG6rXAga2jDs2EgZ2nhuqMgYuG6r3QgxJHhuqd1IGLhurFuZyBkZW1vLSB0cm9uZyBi4bqjbiBtw7QgcGjhu49uZy4nKTtcbiAgICAgICAgICAgIGlmIChlZGl0aW5nKVxuICAgICAgICAgICAgICAgIGF3YWl0IHVwZGF0ZS5leGVjdXRlKHsgcGF0aDogeyBjb25uZWN0aW9uSWQ6IGVkaXRpbmcuaWQgfSwgdmVyc2lvbjogZWRpdGluZy52ZXJzaW9uLCBib2R5OiB7IG5hbWU6IG5hbWUudHJpbSgpLCBtb2RlbElkOiBtb2RlbC50cmltKCksIC4uLihzdWJtaXR0ZWRDcmVkZW50aWFsID8geyBjcmVkZW50aWFsOiBzdWJtaXR0ZWRDcmVkZW50aWFsIH0gOiB7fSkgfSB9KTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBhd2FpdCBjcmVhdGUuZXhlY3V0ZSh7IGJvZHk6IHsgbmFtZTogbmFtZS50cmltKCksIHByb3ZpZGVySWQ6IHByb3ZpZGVyLCBhZGFwdGVySWQ6IGRlc2NyaXB0b3I/LmFkYXB0ZXJJZCB8fCAnJywgbW9kZWxJZDogbW9kZWwudHJpbSgpLCBlbmRwb2ludFVybDogZW5kcG9pbnQgfHwgbnVsbCwgY3JlZGVudGlhbDogc3VibWl0dGVkQ3JlZGVudGlhbCB9IH0pO1xuICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiAnS2jDtG5nIGzGsHUgxJHGsOG7o2MgY+G6pXUgaMOsbmgga+G6v3QgbuG7kWkuJztcbiAgICAgICAgICAgIHNldEZvcm1FcnJvcihuZXcgRXJyb3Ioc3VibWl0dGVkQ3JlZGVudGlhbCAmJiBtZXNzYWdlLmluY2x1ZGVzKHN1Ym1pdHRlZENyZWRlbnRpYWwpID8gbWVzc2FnZS5yZXBsYWNlQWxsKHN1Ym1pdHRlZENyZWRlbnRpYWwsICdbxJHDoyDhuqluXScpIDogbWVzc2FnZSkpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0S2V5KCcnKTtcbiAgICAgICAgfVxuICAgIH19PkzGsHUgY+G6pXUgaMOsbmg8L0J1dHRvbj59PjxFcnJvck5vdGljZSBlcnJvcj17Zm9ybUVycm9yIHx8IGNyZWF0ZS5lcnJvciB8fCB1cGRhdGUuZXJyb3J9Lz48Rm9ybUZpZWxkcyA+e19fTU9DS19fICYmIDxBbGVydCBzZXZlcml0eT1cIndhcm5pbmdcIj5LaMO0bmcgbmjhuq1wIGtow7NhIHRo4bqtdC4gRMO5bmcgZGVtby1rZXk7IHJlcXVlc3QgbcO0IHBo4buPbmcgY2jhu4kga2nhu4NtIHRyYSBnaWFvIGRp4buHbiwga2jDtG5nIGdp4buvIGtow7NhIHbDoCBraMO0bmcga+G6v3QgbuG7kWkgQUkgdGjhuq10LjwvQWxlcnQ+fTxUZXh0RmllbGQgbGFiZWw9XCJUw6puIGvhur90IG7hu5FpXCIgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXtlID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfS8+PFRleHRGaWVsZCBzZWxlY3QgbGFiZWw9XCJQcm92aWRlciDEkcOjIGPDsyBhZGFwdGVyXCIgdmFsdWU9e3Byb3ZpZGVyfSBkaXNhYmxlZD17ISFlZGl0aW5nfSBvbkNoYW5nZT17ZSA9PiB7IHNldFByb3ZpZGVyKGUudGFyZ2V0LnZhbHVlKTsgc2V0TW9kZWwoJycpOyB9fT57Y2F0YWxvZy5kYXRhPy5kYXRhLm1hcChwID0+IDxNZW51SXRlbSB2YWx1ZT17cC5wcm92aWRlcklkfSBrZXk9e3AucHJvdmlkZXJJZH0+e3AubGFiZWx9PC9NZW51SXRlbT4pfTwvVGV4dEZpZWxkPjxUZXh0RmllbGQgbGFiZWw9XCJNb2RlbCBJRCDEkcaw4bujYyBhZGFwdGVyIGjhu5cgdHLhu6NcIiB2YWx1ZT17bW9kZWx9IG9uQ2hhbmdlPXtlID0+IHNldE1vZGVsKGUudGFyZ2V0LnZhbHVlKX0gaGVscGVyVGV4dD17ZGVzY3JpcHRvcj8ubW9kZWxzLm1hcChtID0+IG0ubW9kZWxJZCkuam9pbignLCAnKSB8fCAnWGVtIGNhdGFsb2cgdOG7qyBiYWNrZW5kJ30vPnshZWRpdGluZyAmJiBkZXNjcmlwdG9yPy5lbmRwb2ludEVkaXRhYmxlICYmIDxUZXh0RmllbGQgbGFiZWw9XCJFbmRwb2ludCBIVFRQUyDEkcaw4bujYyBiYWNrZW5kIGNobyBwaMOpcFwiIHZhbHVlPXtlbmRwb2ludH0gb25DaGFuZ2U9e2UgPT4gc2V0RW5kcG9pbnQoZS50YXJnZXQudmFsdWUpfS8+fTxUZXh0RmllbGQgbGFiZWw9e2VkaXRpbmcgPyAnS2jDs2EgbeG7m2kgKMSR4buDIHRy4buRbmcgxJHhu4MgZ2nhu68gbmd1ecOqbiknIDogJ0tow7NhIEFQSSd9IHR5cGU9XCJwYXNzd29yZFwiIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiIHZhbHVlPXtrZXl9IG9uQ2hhbmdlPXtlID0+IHNldEtleShsaW1pdENvZGVQb2ludHMoZS50YXJnZXQudmFsdWUsIDE2Mzg0KSl9IC8+PEFsZXJ0IHNldmVyaXR5PVwiaW5mb1wiPlNlY3JldCBjaOG7iSDEkcaw4bujYyBn4butaSB0aGVvIHRyxrDhu51uZyB3cml0ZU9ubHkgY+G7p2EgY29udHJhY3QuIFJlc3BvbnNlIHbDoCBkYW5oIHPDoWNoIGtow7RuZyB0cuG6oyBzZWNyZXQgZ+G7kWMuPC9BbGVydD48L0Zvcm1GaWVsZHM+PC9FZGl0RGlhbG9nPlxuIDxDb25maXJtRGlhbG9nIG9wZW49eyEhZGVsZXRpbmd9IHRpdGxlPVwiWMOzYSBr4bq/dCBu4buRaSBBSVwiIGNvbmZpcm1MYWJlbD1cIljDs2Ega+G6v3QgbuG7kWkgQUlcIiBkZXNjcmlwdGlvbj17YEvhur90IG7hu5FpIEFJICR7ZGVsZXRpbmc/Lm5hbWUgfHwgXCJcIn0gKCR7ZGVsZXRpbmc/LmlkIHx8IFwiXCJ9KSwgbW9kZWwgJHtkZWxldGluZz8ubW9kZWxJZCB8fCBcIlwifTogY2jhu4kgeMOzYSBraGkga2jDtG5nIGPDsm4gY+G6pXUgaMOsbmggxJFhbmcgc+G7rSBk4bulbmcuIEtow7RuZyB04buxIGNodXnhu4NuIGThu68gbGnhu4d1IHNhbmcgbmjDoCBjdW5nIGPhuqVwIGtow6FjLmB9IHJlcXVpcmVSZWFzb24gb25DbG9zZT17KCkgPT4gc2V0RGVsZXRpbmcobnVsbCl9IGVycm9yPXtyZW1vdmUuZXJyb3J9IGJ1c3k9e3JlbW92ZS5wZW5kaW5nfSBvbkNvbmZpcm09e2FzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFkZWxldGluZykgcmV0dXJuO1xuICAgICAgICBhd2FpdCByZW1vdmUuZXhlY3V0ZSh7IHBhdGg6IHsgY29ubmVjdGlvbklkOiBkZWxldGluZy5pZCB9LCB2ZXJzaW9uOiBkZWxldGluZy52ZXJzaW9uIH0pO1xuICAgIH19Lz48Lz47XG59XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0pva2VyLVBDL0RvY3VtZW50cy9Qcm9qZWN0cy9Cb3QtQUktQmFuLWhhbmctRkIvQm90U2FsZXNBSV9Gcm9udGVuZC9hcHBzL3dlYi9zcmMvbW9kdWxlcy9pbnRlZ3JhdGlvbnMvaW5kZXgudHN4In0=